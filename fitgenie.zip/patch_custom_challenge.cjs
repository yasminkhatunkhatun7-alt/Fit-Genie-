const fs = require('fs');
let code = fs.readFileSync('src/components/CustomChallengeDetailScreen.tsx', 'utf8');

// We need to inject cooldown states and update addRepsInternal
const importsReplacement = `import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Trophy, Target, ShieldAlert, Timer, Play, AlertTriangle, Crosshair, Sword, Activity } from "lucide-react";
import { playSound } from "../utils/audio";
import { useAuth } from "../context/AuthContext";
import { ActiveChallenge } from "./StrengthChallengeScreen";
import MuscleSelector from "./MuscleSelector";`;

// Add states
const stateAddition = `
  const [cooldowns1, setCooldowns1] = useState<Record<number, number>>({});
  const [cooldowns10, setCooldowns10] = useState<Record<number, number>>({});
  const [showCheatWarning, setShowCheatWarning] = useState(false);
  const [pendingAmount, setPendingAmount] = useState({ index: 0, amount: 0 });
  const [lastActionTime, setLastActionTime] = useState(0);

  useEffect(() => {
    const cdTimer = setInterval(() => {
      setCooldowns1(prev => {
        const next = { ...prev };
        let changed = false;
        for (const k in next) {
          if (next[k] > 0) {
            next[k] -= 1;
            changed = true;
          }
        }
        return changed ? next : prev;
      });
      setCooldowns10(prev => {
        const next = { ...prev };
        let changed = false;
        for (const k in next) {
          if (next[k] > 0) {
            next[k] -= 1;
            changed = true;
          }
        }
        return changed ? next : prev;
      });
    }, 1000);
    return () => clearInterval(cdTimer);
  }, []);
`;

code = code.replace(/const \[hasClaimed, setHasClaimed\] = useState\(\(\) => {/g, stateAddition + '\n  const [hasClaimed, setHasClaimed] = useState(() => {');

// Update addRepsInternal
const addRepsFn = `
  const addRepsInternal = (exerciseIndex: number, amount: number) => {
    if (amount === 1) {
      setCooldowns1(prev => ({ ...prev, [exerciseIndex]: 1 }));
    } else if (amount === 10) {
      setCooldowns10(prev => ({ ...prev, [exerciseIndex]: 10 }));
    }

    playSound("timer_tick");
    
    const id = Date.now() + "_" + Math.random();
    setFloatingTexts(prev => [...prev, { id, text: \`+\${amount}\`, x: Math.random() * 40 - 20 }]);
    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== id));
    }, 1000);

    const updated = { ...challenge };
    const ex = updated.exercises[exerciseIndex];
    ex.completedReps = Math.min(ex.targetReps, ex.completedReps + amount);
    onUpdate(updated);
    saveProgress(updated.exercises);
    setLastActionTime(Date.now());
  };

  const handleAddReps = (exerciseIndex: number, amount: number) => {
    if (isCompleted || hasClaimed || showCheatWarning) return;
    
    if (amount === 1 && (cooldowns1[exerciseIndex] || 0) > 0) return;
    if (amount === 10 && (cooldowns10[exerciseIndex] || 0) > 0) return;

    const now = Date.now();
    const timeSinceLastAction = now - lastActionTime;
    
    if (lastActionTime > 0 && timeSinceLastAction < 500 && amount > 1) {
       setPendingAmount({ index: exerciseIndex, amount });
       playSound("countdown");
       setShowCheatWarning(true);
       return;
    }

    addRepsInternal(exerciseIndex, amount);
  };
`;

code = code.replace(/const addRepsInternal = \(exerciseIndex: number, amount: number\) => {[\s\S]*?saveProgress\(updated\.exercises\);\n  };/, addRepsFn);

// Add cheat warning UI
const cheatWarningUI = `
  if (showCheatWarning) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/95 flex flex-col items-center justify-center p-6 backdrop-blur-md">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-[#050B1A] border border-red-500/50 shadow-[0_0_40px_rgba(249,115,22,0.2)] rounded-3xl p-6 text-center max-w-sm w-full relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
          <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4 relative z-10" />
          <div className="relative z-10">
            <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-4">⚠️ Hold Up Warrior!</h2>
            <p className="text-neutral-300 text-sm leading-relaxed font-medium mb-4">
              ⚠ Slow down warrior.<br/><br/>
              Fit Genie trust system par kaam karta hai.<br/>
              <span className="text-[#14F1E1] font-bold">Real effort = Real progress.</span>
            </p>
          </div>
          <div className="relative z-10 mt-6 grid grid-cols-1 gap-3">
            <button 
              onClick={() => { 
                playSound("click"); 
                setShowCheatWarning(false);
                addRepsInternal(pendingAmount.index, pendingAmount.amount);
              }} 
              className="py-4 w-full bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black rounded-xl text-xs uppercase tracking-widest transition-colors shadow-[0_0_20px_rgba(20,241,225,0.4)]"
            >
              Yes, Continue
            </button>
            <button 
              onClick={() => { 
                playSound("click"); 
                setShowCheatWarning(false); 
              }} 
              className="py-4 w-full bg-white/5 hover:bg-white/10 text-white font-bold rounded-xl text-xs uppercase tracking-widest border border-white/10 transition-colors"
            >
              Cancel
            </button>
          </div>
        </motion.div>
      </div>
    );
  }
`;

code = code.replace(/if \(showHonorValidation\) {/, cheatWarningUI + '\n  if (showHonorValidation) {');

// Replace the exercise buttons with cooldown UI
const buttonsRegex = /<div className="flex gap-2">[\s\S]*?<\/div>\n                \)}/g;

const buttonsReplacement = `
                  <div className="flex gap-2 relative">
                    <motion.button 
                      whileTap={(cooldowns1[index] || 0) > 0 ? {} : { scale: 0.95 }}
                      onClick={() => handleAddReps(index, 1)}
                      disabled={isDone || (cooldowns1[index] || 0) > 0}
                      className={\`flex-1 relative overflow-hidden text-sm font-black py-3 rounded-xl transition-all uppercase tracking-widest \${(cooldowns1[index] || 0) > 0 ? 'bg-white/5 border border-white/10 text-white/30' : 'bg-white/5 hover:bg-white/10 border border-white/10 text-white'}\`}
                    >
                      +1 REP
                      {(cooldowns1[index] || 0) > 0 && <div className="absolute inset-0 bg-black/60 flex items-center justify-center text-xs text-white">Wait {(cooldowns1[index] || 0)}s</div>}
                    </motion.button>
                    <motion.button 
                      whileTap={(cooldowns10[index] || 0) > 0 ? {} : { scale: 0.95 }}
                      onClick={() => handleAddReps(index, 10)}
                      disabled={isDone || (cooldowns10[index] || 0) > 0}
                      className={\`flex-1 relative overflow-hidden text-sm font-black py-3 rounded-xl transition-all uppercase tracking-widest \${(cooldowns10[index] || 0) > 0 ? 'bg-[#14F1E1]/5 border border-[#14F1E1]/10 text-[#14F1E1]/30' : 'bg-[#14F1E1]/10 hover:bg-[#14F1E1]/20 border border-[#14F1E1]/30 text-[#14F1E1]'}\`}
                    >
                      +10 REPS
                      {(cooldowns10[index] || 0) > 0 && <div className="absolute inset-0 bg-black/60 flex items-center justify-center text-xs text-[#14F1E1]">Wait {(cooldowns10[index] || 0)}s</div>}
                    </motion.button>
                  </div>
                )}
`;

code = code.replace(buttonsRegex, buttonsReplacement);

// Modify showHonorValidation logic to ensure it doesn't trigger when cheat warning is open
code = code.replace(
  `if (isCompleted && !showCompletion && !showHonorValidation && !hasClaimed) {`,
  `if (isCompleted && !showCompletion && !showHonorValidation && !showCheatWarning && !hasClaimed) {`
);
code = code.replace(
  `[isCompleted, showCompletion, showHonorValidation, hasClaimed]`,
  `[isCompleted, showCompletion, showHonorValidation, showCheatWarning, hasClaimed]`
);

// Ensure imports have everything needed
if(!code.includes("import { motion, AnimatePresence } from")) {
    // Should be there, but just in case
}

fs.writeFileSync('src/components/CustomChallengeDetailScreen.tsx', code);
