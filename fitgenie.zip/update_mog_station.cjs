const fs = require('fs');
let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

const oldDecl = `export default function MoggedStation({ onSaveSmartSession }: MoggedStationProps) {
  const [completedExercises, setCompletedExercises] = useState<string[]>([]);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);`;

const newDecl = `export default function MoggedStation({ onSaveSmartSession }: MoggedStationProps) {
  const [completedExercises, setCompletedExercises] = useState<string[]>([]);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const handleExerciseComplete = (ex: any) => {
    if (completedExercises.includes(ex.name)) return;
    setCompletedExercises(prev => [...prev, ex.name]);
    playSound("success");

    if (onSaveSmartSession) {
      const durationMin = parseInt(ex.duration) || 2;
      const repsNum = parseInt(ex.reps) || 15;
      
      onSaveSmartSession({
        id: \`mogged_\${Date.now()}\`,
        date: new Date().toISOString(),
        muscles: [ex.target],
        equipment: ["Bodyweight"],
        exercisesCount: 1,
        totalDurationMin: durationMin,
        exercises: [{
          id: Date.now(),
          name_en: ex.name,
          name_hi: "Mewing / Facial Exercise",
          sets: ex.sets || 3,
          reps: repsNum,
          difficulty: ex.difficulty?.toLowerCase() || "beginner",
        }],
        notes: "MoggedStation Routine",
        rating: 5,
        isSmartValidation: true
      });
    }
  };`;

code = code.replace(oldDecl, newDecl);

const mapOld = `{area.exercises.map((ex, i) => (
                            <div key={i} className="bg-neutral-800/40 rounded-xl p-3 border border-neutral-700/50 flex gap-3 relative overflow-hidden group cursor-pointer hover:border-[#14F1E1]/50 transition-colors">`;
const mapNew = `{area.exercises.map((ex, i) => {
                            const isCompleted = completedExercises.includes(ex.name);
                            return (
                            <div 
                              key={i} 
                              onClick={() => handleExerciseComplete(ex)}
                              className={\`rounded-xl p-3 border flex gap-3 relative overflow-hidden group cursor-pointer transition-colors \${isCompleted ? 'bg-[#14F1E1]/10 border-[#14F1E1]/50' : 'bg-neutral-800/40 border-neutral-700/50 hover:border-[#14F1E1]/50'}\`}
                            >
                              {isCompleted && <div className="absolute inset-0 bg-[#14F1E1]/5" />}`;

code = code.replace(mapOld, mapNew);

const iconOld = `<div className="flex items-center justify-center w-5 h-5 rounded-full bg-neutral-800 group-hover:bg-[#14F1E1]/20 transition-colors border border-neutral-700 group-hover:border-[#14F1E1]/50 shrink-0">
                                    <CheckCircle2 className="w-3.5 h-3.5 text-neutral-500 group-hover:text-[#14F1E1] transition-colors" />
                                  </div>`;

const iconNew = `<div className={\`flex items-center justify-center w-5 h-5 rounded-full transition-colors border shrink-0 \${isCompleted ? 'bg-[#14F1E1]/20 border-[#14F1E1] text-[#14F1E1]' : 'bg-neutral-800 border-neutral-700 text-neutral-500 group-hover:bg-[#14F1E1]/20 group-hover:border-[#14F1E1]/50 group-hover:text-[#14F1E1]'}\`}>
                                    <CheckCircle2 className="w-3.5 h-3.5 transition-colors" />
                                  </div>`;
code = code.replace(iconOld, iconNew);

const pbOld = `<div className="w-full bg-neutral-800 rounded-full h-1 mt-2.5 overflow-hidden">
                                   <div className="bg-[#14F1E1] h-1 w-0 group-hover:w-full transition-all duration-[2000ms] ease-out" />
                                </div>
                              </div>
                            </div>
                          ))}`;

const pbNew = `<div className="w-full bg-neutral-800 rounded-full h-1 mt-2.5 overflow-hidden">
                                   <div className={\`bg-[#14F1E1] h-1 transition-all duration-[2000ms] ease-out \${isCompleted ? 'w-full' : 'w-0 group-hover:w-full'}\`} />
                                </div>
                              </div>
                            </div>
                          );
                          })}`;
code = code.replace(pbOld, pbNew);

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done mogging update');
