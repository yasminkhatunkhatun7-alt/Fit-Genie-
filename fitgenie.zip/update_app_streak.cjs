const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// replace local calculateStreakForList with reading from profile
code = code.replace(/const streakCount = calculateStreakForList\(history\);/, 'const streakCount = profile?.streak || 0;');

fs.writeFileSync('src/App.tsx', code);
