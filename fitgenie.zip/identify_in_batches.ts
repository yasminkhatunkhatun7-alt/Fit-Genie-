import { GoogleGenAI } from "@google/genai";
import fs from "fs";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const videos = [
  "62sm1cJzivQ", "vCWcYF5PiQg", "0kU-IJQs6Bk", "bmqSJSB0C8E", "ewSCQSE-kEM",
  "IGssbfjjc1Q", "Ou4mFyMmwE4", "tTIV6qVB59Y", "tIyMLHcJ_xQ", "RRQQgW9t--k",
  "fF0IgM71dUM", "B2UXMlFw-Mk", "XglujyVx-SI", "Vorr1jRrb9w", "ruu8XBkLVhg",
  "y-bxF4PCOJo", "MTJxrViWPj4", "Q2ClBRiRzJo", "-9rMGYdJwPE", "TCtuwk35bmk"
];

const EXERCISE_LIST = [
  "Wall Push Up", "Knee Push Up", "Dead Hang (10 sec)", "Assisted Squat", "Plank (10 sec)",
  "Negative Pull Up", "Plank (30 sec)", "Hollow Body Hold", "Diamond Push Up", "L-Sit (5 sec)",
  "Parallel Bar Dips", "Pike Push Up", "Chest to Bar Pull Up", "Pistol Squat (assisted)", "L-Sit (15 sec)",
  "Dragon Flag (negative)", "Handstand Push Up (wall)", "Muscle Up", "Full Pistol Squat", "Front Lever (tuck)",
  "Back Lever (tuck)", "Free Handstand Push Up", "One Arm Pull Up", "Front Lever (full)", "Human Flag",
  "Planche (tuck)", "One Arm Push Up", "Full Planche", "Iron Cross", "Manna", "Archer pull up", "Elevated Pike Push ups"
];

async function runBatch(batch: string[]) {
  const prompt = `
You are tasked with identifying which calisthenics exercises are shown in these YouTube Shorts video IDs:
${batch.map((id, index) => `${index + 1}) ID: "${id}"`).join("\n")}

Please use Google Search to find descriptions, playlist titles, social media mentions, blog posts, comments, or any cached details linking these YouTube video IDs to specific exercises.
Match each video ID to one of the following calisthenics exercise names from our application (choose the closest matching exercise from this list):
${EXERCISE_LIST.map(e => `- ${e}`).join("\n")}

Respond with only a JSON block containing the mapping from video ID to the exercise name, without any other conversational text or markdown wrappers. Example structure:
{
  "VIDEO_ID_1": "Exercise Name",
  "VIDEO_ID_2": "Another Exercise Name"
}
`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.1-flash-lite',
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  return response.text?.trim() || "";
}

async function main() {
  let results: Record<string, string> = {};
  if (fs.existsSync("./batch_identified_videos.json")) {
    try {
      results = JSON.parse(fs.readFileSync("./batch_identified_videos.json", "utf-8"));
    } catch (e) {}
  }

  // Find the first batch of 4 that doesn't have all videos in results
  const batchSize = 4;
  let batchToRun: string[] = [];

  for (let i = 0; i < videos.length; i += batchSize) {
    const chunk = videos.slice(i, i + batchSize);
    const chunkUnresolved = chunk.filter(id => !results[id]);
    if (chunkUnresolved.length > 0) {
      batchToRun = chunk;
      break;
    }
  }

  if (batchToRun.length === 0) {
    console.log("All videos already identified!");
    console.log(JSON.stringify(results, null, 2));
    return;
  }

  console.log(`Running batch: ${batchToRun.join(", ")}...`);
  try {
    const text = await runBatch(batchToRun);
    console.log(`Response:\n${text}`);
    try {
      const cleanJson = text.replace(/```json/g, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleanJson);
      Object.assign(results, parsed);
      fs.writeFileSync("./batch_identified_videos.json", JSON.stringify(results, null, 2));
      console.log("Saved batch results!");
    } catch (err) {
      console.log("Could not parse JSON from response:", err);
    }
  } catch (err: any) {
    console.error(`Error processing batch:`, err.message);
  }
}

main();
