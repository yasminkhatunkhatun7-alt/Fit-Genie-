const fs = require('fs');
let content = fs.readFileSync('src/components/SidebarSections.tsx', 'utf8');

const originalEnd = `        <div className="grid grid-cols-2 gap-4 w-full">
          <div className="bg-[#111] p-3 rounded-2xl border border-zinc-900 text-left">
            <span className="block text-[8px] uppercase text-zinc-500 font-bold font-mono">Distance Traveled</span>
            <span className="block text-xs font-black text-zinc-100 mt-1 uppercase font-mono">{distanceKm} KM</span>
          </div>
          <div className="bg-[#111] p-3 rounded-2xl border border-zinc-900 text-left">
            <span className="block text-[8px] uppercase text-zinc-500 font-bold font-mono">Active Energy Burn</span>
            <span className="block text-xs font-black text-zinc-100 mt-1 uppercase font-mono">{kcalBurned} KCAL</span>
          </div>
        </div>
      </div>
    </div>
  );
}`;

const newEnd = `        <div className="grid grid-cols-2 gap-4 w-full">
          <div className="bg-[#111] p-3 rounded-2xl border border-zinc-900 text-left">
            <span className="block text-[8px] uppercase text-zinc-500 font-bold font-mono">Distance Traveled</span>
            <span className="block text-xs font-black text-zinc-100 mt-1 uppercase font-mono">{distanceKm} KM</span>
          </div>
          <div className="bg-[#111] p-3 rounded-2xl border border-zinc-900 text-left">
            <span className="block text-[8px] uppercase text-zinc-500 font-bold font-mono">Active Energy Burn</span>
            <span className="block text-xs font-black text-zinc-100 mt-1 uppercase font-mono">{kcalBurned} KCAL</span>
          </div>
        </div>

        {/* Step Tracking Notice */}
        <div className="bg-neutral-900/50 border border-brand-accent/30 rounded-2xl p-4 w-full">
          <h3 className="text-white font-bold text-[11px] flex items-center gap-1.5 mb-2.5 uppercase tracking-wider">
            <span className="text-brand-accent text-sm">⚠️</span> Step Tracking Information
          </h3>
          <div className="text-[10px] text-zinc-400 space-y-2.5 leading-relaxed font-medium">
            <p>Fit Genie tracks steps only while the app is open and active.</p>
            <p>Because Fit Genie currently runs as a PWA (Progressive Web App), background step tracking is not supported.</p>
            <div className="bg-neutral-950/50 p-2.5 rounded-xl border border-white/5">
              <p className="font-bold text-zinc-200 mb-1.5">For accurate step counting:</p>
              <ul className="list-disc pl-4 space-y-1 text-zinc-400">
                <li>Keep Fit Genie open during walking.</li>
                <li>Avoid closing the app while tracking steps.</li>
                <li>Step count may pause when the app is minimized or closed.</li>
              </ul>
            </div>
            <p>Future updates may include enhanced background tracking support.</p>
            <p className="font-bold text-brand-accent pt-1 text-center italic tracking-wider text-[11px]">Stay moving, Warrior. 💪🔥</p>
          </div>
        </div>
      </div>
    </div>
  );
}`;

content = content.replace(originalEnd, newEnd);

fs.writeFileSync('src/components/SidebarSections.tsx', content);
