const fs = require('fs');

let wh = fs.readFileSync('src/components/WorkoutHistory.tsx', 'utf8');
const lines = wh.split('\n');

const sleepLogsStart = lines.findIndex(l => l.includes('const [sleepLogs] = useLocalStorageSync<any[]>("fitgenie_sleep_logs"'));
const sleepLogsEnd = lines.findIndex((l, i) => i > sleepLogsStart && l.includes('  ]);'));

if (sleepLogsStart > 0 && sleepLogsEnd > sleepLogsStart) {
  lines.splice(sleepLogsStart, sleepLogsEnd - sleepLogsStart + 1);
}

// Find sleepStats
const sleepStatsStart = lines.findIndex(l => l.includes('const sleepStats = useMemo(() => {'));
const sleepStatsEnd = lines.findIndex((l, i) => i > sleepStatsStart && l.includes('  }, [sleepLogs]);'));

if (sleepStatsStart > 0 && sleepStatsEnd > sleepStatsStart) {
  lines.splice(sleepStatsStart, sleepStatsEnd - sleepStatsStart + 1);
}

// Write it back
wh = lines.join('\n');

// Also remove Profile Sleep Stats
const sleepBlockRegex = /                \{\/\* Profile Sleep Stats \*\/\}[\s\S]*?                <\/div>\n/g;
wh = wh.replace(sleepBlockRegex, "");

fs.writeFileSync('src/components/WorkoutHistory.tsx', wh);
