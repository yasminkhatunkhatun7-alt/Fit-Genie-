const fs = require('fs');

let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf8');

if (!code.includes('triggerEvent("challenge_complete")')) {
  if (!code.includes('useGuardianContext')) {
    code = code.replace(/import \{ useAuth \} from "\.\.\/context\/AuthContext";/, 'import { useAuth } from "../context/AuthContext";\nimport { useGuardianContext } from "../context/GuardianContext";');
  }

  code = code.replace(/const \{ updateProfileStats \} = useAuth\(\);/, 'const { updateProfileStats } = useAuth();\n  const { triggerEvent } = useGuardianContext();');
  
  code = code.replace(/console\.log\(\`\[Challenges\] Challenge completed: \$\{activeChallenge\.title\}\`\);/, 'console.log(`[Challenges] Challenge completed: ${activeChallenge.title}`);\n    triggerEvent("challenge_complete");');

  fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
}
