const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace('profile: 19', 'profile: 19, contact: 20, terms: 21');
content = content.replace('Info, Mail, FileText} from "lucide-react";', 'Mail, FileText} from "lucide-react";');

fs.writeFileSync('src/App.tsx', content);
