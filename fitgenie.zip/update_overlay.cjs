const fs = require('fs');

let code = fs.readFileSync('src/components/AntiCheatOverlay.tsx', 'utf8');

code = code.replace(/const msgs = \[[\s\S]*?\];/, `const msgs = [
      "Bro... even superheroes need time.",
      "You're training buttons.",
      "Physics disagrees.",
      "Nice try 😏",
      "Genie is not convinced."
    ];`);

code = code.replace(/⚠ Suspicious Activity Detected/, 'GENIE IS SUSPICIOUS');
code = code.replace(/<AlertTriangle className="w-20 h-20 text-red-500 mx-auto animate-pulse" \/>/, `<div className="flex justify-center mb-4">
              <div className="w-20 h-20 rounded-full relative flex items-center justify-center shadow-[0_0_20px_rgba(239,68,68,0.6),inset_0_0_20px_rgba(239,68,68,0.6)] bg-black">
                <div className="flex gap-2 z-20">
                  <div className="w-2.5 h-4 bg-white rounded-full shadow-[0_0_10px_white] transform rotate-12 scale-y-[0.4]" />
                  <div className="w-2.5 h-4 bg-white rounded-full shadow-[0_0_10px_white] transform -rotate-12 scale-y-[0.4]" />
                </div>
              </div>
            </div>`);

fs.writeFileSync('src/components/AntiCheatOverlay.tsx', code);
