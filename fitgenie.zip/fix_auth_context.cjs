const fs = require('fs');

let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

const regex = /updateProfileStats: \(stats: \{\s*xpGained\?: number;\s*workoutCompleted\?: boolean;\s*challengeWon\?: boolean;/;
const replacement = `updateProfileStats: (stats: { 
    xpGained?: number; 
    workoutCompleted?: boolean; 
    workoutCompletedOnTime?: boolean;
    dailyGoalCompleted?: boolean;
    challengeWon?: boolean;`;

content = content.replace(regex, replacement);

fs.writeFileSync('src/context/AuthContext.tsx', content);
