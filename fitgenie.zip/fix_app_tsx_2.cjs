const fs = require('fs');
let appContent = fs.readFileSync('src/App.tsx', 'utf8');
appContent = appContent.replace(
  'profile: 18, contact: 19, terms: 20,',
  'profile: 18, contact: 19, terms: 20, settings: 21,'
);
fs.writeFileSync('src/App.tsx', appContent);
