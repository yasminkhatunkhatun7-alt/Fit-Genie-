const fs = require('fs');
let code = fs.readFileSync('src/components/StrengthChallengeScreen.tsx', 'utf-8');

const controlsRegex = /<div className="grid grid-cols-2 gap-4 relative">[\s\S]*?\{showAiCounter && \(/;
const controlsReplacement = `<div className="grid grid-cols-1 gap-4 relative">
            {(exercise.name.toLowerCase().includes('pushup') || exercise.name.toLowerCase().includes('squat')) ? (
               <motion.button 
                 whileTap={{ scale: 0.95 }}
                 onClick={() => setShowAiCounter(true)}
                 disabled={isCompleted || hasClaimedToday}
                 className="bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-lg py-5 rounded-2xl flex justify-center items-center gap-2 shadow-[0_0_20px_rgba(20,241,225,0.4)] transition-all disabled:opacity-50"
               >
                 <Camera className="w-6 h-6" />
                 START AI TRACKER
               </motion.button>
             ) : (
               <div className="bg-white/5 border border-white/10 text-neutral-400 font-bold text-sm py-5 rounded-2xl flex justify-center items-center text-center px-4">
                 Manual tracking disabled. AI Tracker is available for Pushups and Squats.
               </div>
             )}
            
            {/* FLOATING TEXTS */}
            <AnimatePresence>
              {floatingTexts.map((ft) => (
                <motion.div
                  key={ft.id}
                  initial={{ opacity: 1, y: 0, x: ft.x, scale: 1 }}
                  animate={{ opacity: 0, y: -50, scale: 1.5 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                  className="absolute pointer-events-none left-1/2 -translate-x-1/2 -top-10 text-white font-black text-2xl z-20"
                >
                  {ft.text}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

      {/* STATS */}
      <div className="bg-[#050B1A] border border-white/10 rounded-2xl p-5 flex items-center justify-between mt-4">
        <div className="flex items-center gap-3">
          <div className="bg-yellow-500/20 p-2 rounded-xl">
            <Star className="w-5 h-5 text-yellow-500" />
          </div>
          <div>
            <h4 className="text-white font-black uppercase text-sm">Reward XP</h4>
            <p className="text-neutral-400 text-xs font-bold">Upon Defeating Boss</p>
          </div>
        </div>
        <div className="text-yellow-400 font-black text-2xl">
          {challenge.xp}
        </div>
      </div>

      {showAiCounter && (`;

if (code.match(controlsRegex)) {
  code = code.replace(controlsRegex, controlsReplacement);
  fs.writeFileSync('src/components/StrengthChallengeScreen.tsx', code);
  console.log('Re-fixed Strength');
} else {
  console.log('Failed to re-fix Strength');
}

