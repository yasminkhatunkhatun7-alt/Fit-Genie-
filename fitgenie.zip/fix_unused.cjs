const fs = require('fs');

let content = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

// Remove from interface
content = content.replace(/  onNavigateToGenerator: \(\) => void;\n/, '');
// Remove from props destructuring
content = content.replace(/  onNavigateToGenerator,\n/, '');

fs.writeFileSync('src/components/HomeDashboard.tsx', content);

let appContent = fs.readFileSync('src/App.tsx', 'utf8');
appContent = appContent.replace(/onNavigateToGenerator=\{.*?\}\n/g, '');
appContent = appContent.replace(/onNavigateToGenerator=\{.*?\}/g, '');
fs.writeFileSync('src/App.tsx', appContent);
