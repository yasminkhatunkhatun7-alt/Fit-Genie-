const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

if (!code.includes('import { motion, AnimatePresence }')) {
  code = code.replace(
    'import { Globe, Send, ShieldAlert, Zap, Loader2 } from "lucide-react";',
    'import { Globe, Send, ShieldAlert, Zap, Loader2 } from "lucide-react";\nimport { motion, AnimatePresence } from "motion/react";'
  );
}

const targetTernaryBlockStart = `        ) : (
          messages.map((msg) => {`;
const replaceTernaryBlockStart = `        ) : (
          <AnimatePresence initial={false}>
            {messages.map((msg) => {`;

const targetDivStart = `              <div key={msg.id} className={\`flex gap-3 max-w-[85%] \${isMe ? 'self-end flex-row-reverse' : 'self-start'}\`}>`;
const replaceDivStart = `              <motion.div 
                layout 
                initial={{ opacity: 0, y: 15, scale: 0.95 }} 
                animate={{ opacity: 1, y: 0, scale: 1 }} 
                exit={{ opacity: 0, scale: 0.9 }} 
                transition={{ duration: 0.25, ease: "easeOut" }} 
                key={msg.id} 
                className={\`flex gap-3 max-w-[85%] \${isMe ? 'self-end flex-row-reverse' : 'self-start'}\`}
              >`;

const targetDivEnd = `              </div>
            );
          })
        )}`;

const replaceDivEnd = `              </motion.div>
            );
            })}
          </AnimatePresence>
        )}`;

code = code.replace(targetTernaryBlockStart, replaceTernaryBlockStart);
code = code.replace(targetDivStart, replaceDivStart);
code = code.replace(targetDivEnd, replaceDivEnd);

fs.writeFileSync('src/components/WorldChat.tsx', code);
console.log("Patched WorldChat.tsx animations");
