const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

// The endpoint starts with `app.post("/api/face-scan", async (req, res) => {` and ends before `app.post("/api/fitness-insight",`
const faceScanRegex = /  app\.post\("\/api\/face-scan"[\s\S]*?\}\);(?=\s*app\.post\("\/api\/fitness-insight")/m;
code = code.replace(faceScanRegex, '');

fs.writeFileSync('server.ts', code);
console.log("Removed /api/face-scan from server.ts");
