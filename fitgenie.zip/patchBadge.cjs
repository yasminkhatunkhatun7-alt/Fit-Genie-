const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

// 1. Add an initial fetch for friendRequests
const initEffect = `
  useEffect(() => {
    if (currentUserId && currentUserId !== "local_user") {
      fetchFriendRequests();
    }
  }, [currentUserId]);
`;
code = code.replace(
  /  const fetchFriendRequests = async \(\) => \{/,
  initEffect + '\n  const fetchFriendRequests = async () => {'
);

// 2. Add the badge to the Friends tab button
const oldButton = `<button 
            onClick={() => setActiveTab("friends")}
            className={\`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all \${activeTab === 'friends' ? 'bg-emerald-500 text-white' : 'text-neutral-500 hover:text-white'}\`}
          >
            Friends
          </button>`;

const newButton = `<button 
            onClick={() => setActiveTab("friends")}
            className={\`relative px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all \${activeTab === 'friends' ? 'bg-emerald-500 text-white' : 'text-neutral-500 hover:text-white'}\`}
          >
            Friends
            {friendRequests.length > 0 && (
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500 border border-[#050B1A]"></span>
              </span>
            )}
          </button>`;

code = code.replace(oldButton, newButton);

fs.writeFileSync('src/components/WorldChat.tsx', code);
