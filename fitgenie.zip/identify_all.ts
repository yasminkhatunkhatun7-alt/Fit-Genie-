import { GoogleGenAI } from "@google/genai";
import fs from "fs";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const videos = [
  "62sm1cJzivQ", "vCWcYF5PiQg", "0kU-IJQs6Bk", "bmqSJSB0C8E", "ewSCQSE-kEM",
  "IGssbfjjc1Q", "Ou4mFyMmwE4", "tTIV6qVB59Y", "tIyMLHcJ_xQ", "RRQQgW9t--k",
  "fF0IgM71dUM", "B2UXMlFw-Mk", "XglujyVx-SI", "Vorr1jRrb9w", "ruu8XBkLVhg",
  "y-bxF4PCOJo", "MTJxrViWPj4", "Q2ClBRiRzJo", "-9rMGYdJwPE", "TCtuwk35bmk"
];

const EXERCISES_MAP = {
  "cal_1_1": "Wall Push Up",
  "cal_1_2": "Knee Push Up",
  "cal_1_3": "Dead Hang (10 sec)",
  "cal_1_4": "Assisted Squat",
  "cal_1_5": "Plank (10 sec)",
  "cal_1_6": "Surya Namaskar",
  "cal_2_1": "Full Push Up / दंड",
  "cal_2_2": "Negative Pull Up",
  "cal_2_3": "Bodyweight Squat / बैठक",
  "cal_2_4": "Plank (30 sec)",
  "cal_2_5": "Hollow Body Hold",
  "cal_3_1": "Diamond Push Up",
  "cal_3_2": "Full Pull Up",
  "cal_3_3": "Jump Squat",
  "cal_3_4": "L-Sit (5 sec)",
  "cal_3_5": "Parallel Bar Dips",
  "cal_4_1": "Pike Push Up",
  "cal_4_2": "Chest to Bar Pull Up",
  "cal_4_3": "Pistol Squat (assisted)",
  "cal_4_4": "L-Sit (15 sec)",
  "cal_4_5": "Dragon Flag (negative)",
  "cal_5_1": "Handstand Push Up (wall)",
  "cal_5_2": "Muscle Up",
  "cal_5_3": "Full Pistol Squat",
  "cal_5_4": "Front Lever (tuck)",
  "cal_5_5": "Back Lever (tuck)",
  "cal_6_1": "Free Handstand Push Up",
  "cal_6_2": "One Arm Pull Up",
  "cal_6_3": "Front Lever (full)",
  "cal_6_4": "Human Flag",
  "cal_6_5": "Planche (tuck)",
  "cal_7_1": "One Arm Push Up",
  "cal_7_2": "Full Planche",
  "cal_7_3": "Iron Cross",
  "cal_7_4": "Manna"
};

async function main() {
  const prompt = `
Search Google to find out which specific calisthenics exercise is shown in each of these 20 YouTube Shorts videos uploaded under the channel "Fit_Genie Wale" as standard "Caleshthenics excersize made by fit Genie" demonstration/progression videos.
Find the titles or keywords for each of the following 20 video IDs:
${videos.map((id, idx) => `${idx + 1}. ID: "${id}" (URL https://youtube.com/shorts/${id})`).join("\n")}

Then, map each of these 20 video IDs to the closest exercise ID from this specific list:
${Object.entries(EXERCISES_MAP).map(([id, name]) => `- ${id}: ${name}`).join("\n")}

Return ONLY a valid JSON object string. Do NOT include markdown code blocks or any other explanation. It must look exactly like this:
{
  "62sm1cJzivQ": "cal_3_2",
  "vCWcYF5PiQg": "cal_5_2"
}
`;

  console.log("Calling Grounded Gemini API with googleSearch...");
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json"
      }
    });

    const text = response.text?.trim() || "";
    console.log("Response text:");
    console.log(text);
    
    const parsed = JSON.parse(text);
    fs.writeFileSync("./final_grounded_videos.json", JSON.stringify(parsed, null, 2));
    console.log("Successfully wrote results to final_grounded_videos.json!");
  } catch (err: any) {
    console.error("Error executing Gemini mapping:", err.message);
  }
}

main();
