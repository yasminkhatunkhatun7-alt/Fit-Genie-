const fs = require('fs');

let serverCode = fs.readFileSync('server.ts', 'utf-8');

const targetStr = `  const BAD_WORDS = ["fuck", "shit", "bitch", "asshole", "cunt", "dick", "pussy", "chutiya", "madarchod", "bhenchod", "gaandu", "saala", "kutta", "randi", "bhosdike", "harami"];
  function containsProfanity(text: string) {
    const lower = text.toLowerCase();
    return BAD_WORDS.some(word => lower.includes(word));
  }`;

const replaceStr = `  const BAD_WORDS = [
    // English
    "fuck", "shit", "bitch", "asshole", "cunt", "dick", "pussy", "whore", "slut", "bastard", "motherfucker", 
    "nigger", "nigga", "faggot", "rape", "porn", "cock", "dickhead",
    // Hindi / Hinglish
    "chutiya", "chutiye", "madarchod", "bhenchod", "behenchod", "gaandu", "gandu", "saala", "kutta", "randi", 
    "bhosdike", "bhosdi", "bhosada", "harami", "kamina", "kaminey", "suar", "bsdk", "mc", "bc", "tmkb", "mkb", 
    "raand", "bhadwa", "lodu", "lode", "laude", "chod", "chud", "maderchod", "banchod", "muth", "muthiya", "chut", "chooth",
    "kuttiya", "teri maa ki", "teri mkc", "maa ki chut"
  ];
  
  function containsProfanity(text: string) {
    const lower = text.toLowerCase();
    
    // Remove punctuation for exact word matching
    const cleanText = lower.replace(/[^a-z0-9\\s]/g, '');
    const words = cleanText.split(/\\s+/);
    
    // 1. Exact word match (prevents "class" from triggering "ass")
    if (words.some(word => BAD_WORDS.includes(word))) return true;

    // 2. Continuous string match for longer words without spaces (e.g., "tuchutiyahai")
    const longBadWords = BAD_WORDS.filter(w => w.length >= 6);
    if (longBadWords.some(bw => cleanText.includes(bw))) return true;

    // 3. Raw includes for original text (catches multi-word strings like "maa ki chut")
    if (BAD_WORDS.some(bw => lower.includes(bw) && bw.includes(' '))) return true;

    return false;
  }`;

serverCode = serverCode.replace(targetStr, replaceStr);

fs.writeFileSync('server.ts', serverCode);
console.log("Profanity filter upgraded");
