const fs = require('fs');

let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf-8');

const missingFuncs = `
  const signUpWithEmail = async () => {};
  const signInWithEmail = async () => {};
  const resetPassword = async () => {};
  const completeProfileSetup = async () => { return {} as any; };
  const refreshProfile = async () => {};
  const logMoggedExercise = async () => {};

  return (
`;

code = code.replace('  return (', missingFuncs);

fs.writeFileSync('src/context/AuthContext.tsx', code);
