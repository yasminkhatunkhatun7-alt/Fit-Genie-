const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf-8');

if (!code.includes('import { db }')) {
  code = code.replace(
    'import { createContext, useContext, useState, useEffect, ReactNode } from "react";',
    'import { createContext, useContext, useState, useEffect, ReactNode } from "react";\nimport { db } from "../lib/firebase";\nimport { doc, setDoc } from "firebase/firestore";'
  );
}

const saveTarget = `  const saveProfile = (updatedProfile: UserProfile) => {
    setProfile(updatedProfile);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedProfile));
  };`;

const saveReplace = `  const saveProfile = (updatedProfile: UserProfile) => {
    setProfile(updatedProfile);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedProfile));
    
    // Sync to Firestore
    try {
      if (updatedProfile.uid) {
        const avatarStyles = ["bg-blue-500", "bg-pink-500", "bg-purple-500", "bg-emerald-500", "bg-orange-500", "bg-indigo-500"];
        const avatarIndex = updatedProfile.uid.length % avatarStyles.length;
        const avatarBg = \`\${avatarStyles[avatarIndex]} text-white border-\${avatarStyles[avatarIndex].replace('bg-', '')}\`;
        
        const userRef = doc(db, 'users', updatedProfile.uid);
        setDoc(userRef, {
          userId: updatedProfile.uid,
          userName: updatedProfile.username || 'Anonymous Genin',
          xp: updatedProfile.xp || 0,
          rank: updatedProfile.rank || 'Beginner',
          streak: updatedProfile.streak || 0,
          avatarBg: avatarBg,
          lastUpdated: Date.now()
        }, { merge: true }).catch(console.error);
      }
    } catch (e) {
      console.error('Failed to sync profile to Firebase', e);
    }
  };`;

if (!code.includes('doc(db, \'users\', updatedProfile.uid)')) {
  code = code.replace(saveTarget, saveReplace);
  fs.writeFileSync('src/context/AuthContext.tsx', code);
  console.log("Patched AuthContext.tsx");
} else {
  console.log("Already patched.");
}
