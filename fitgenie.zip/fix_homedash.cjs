const fs = require('fs');
let code = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf-8');

// Remove the misplaced block
const misplacedRegex = /  const dailyCalories = useMemo\(\(\) => \{[\s\S]*?const xpPercent = Math\.min\(100, Math\.max\(0, \(dailyXP \/ dailyXPTarget\) \* 100\)\);\s*return \(/;
code = code.replace(misplacedRegex, '  return (');

// Reinsert right before the main return statement
const mainReturnRegex = /  \}, \[stepLogs\]\);\s*return \(/;
const correctCalculations = `  }, [stepLogs]);

  const dailyCalories = useMemo(() => {
    const sessionsToday = history.filter((s) => s.date.startsWith(todayStr));
    const totalMinutes = sessionsToday.reduce((sum, s) => sum + s.totalDurationMin, 0);
    return Math.round(totalMinutes * 8.5);
  }, [history, todayStr]);
  const dailyCalorieTarget = profile?.dailyCalorieTarget || 500;
  const caloriePercent = Math.min(100, Math.max(0, (dailyCalories / dailyCalorieTarget) * 100));

  const dailyXP = profile?.dailyXP || 0;
  const dailyXPTarget = 200;
  const xpPercent = Math.min(100, Math.max(0, (dailyXP / dailyXPTarget) * 100));

  return (`;

if (code.match(mainReturnRegex)) {
  code = code.replace(mainReturnRegex, correctCalculations);
  fs.writeFileSync('src/components/HomeDashboard.tsx', code);
  console.log("Fixed insertion");
} else {
  console.log("Could not find main return statement");
}
