const fs = require('fs');

let orbContent = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

orbContent = orbContent.replace(
  'import { useAuth, getTrustGrade } from "../context/AuthContext";',
  'import { useAuth, getIntegrityData } from "../context/AuthContext";'
);

// We need to replace the Trust Score card content.
const cardRegex = /<div className="glass-card p-5 rounded-2xl border border-\[rgba\(77,168,255,0\.2\)\] bg-\[rgba\(77,168,255,0\.05\)\]">[\s\S]*?<\/div>/;

const newCard = `<div className="glass-card p-5 rounded-2xl border border-[rgba(77,168,255,0.2)] bg-[rgba(77,168,255,0.05)]">
                    <div className="flex items-center gap-3 mb-2">
                      <Shield className="w-5 h-5 text-[#4DA8FF]" />
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider">Trust Score</h3>
                    </div>
                    <div className="flex items-end gap-2 mb-2">
                      <span className="text-4xl font-black font-mono text-[#4DA8FF]">{profile?.integrityScore || 100}%</span>
                    </div>
                    {(() => {
                      const data = getIntegrityData(profile?.integrityScore || 100);
                      return (
                        <>
                          <p className="text-sm font-bold text-white mb-1">{data.status}</p>
                          <p className="text-xs text-neutral-300 font-medium mb-1">Mood: {data.mood}</p>
                          <p className="text-xs text-[#4DA8FF] font-medium italic">"{data.message}"</p>
                        </>
                      );
                    })()}
                  </div>`;

orbContent = orbContent.replace(cardRegex, newCard);
fs.writeFileSync('src/components/GuardianOrb.tsx', orbContent);
