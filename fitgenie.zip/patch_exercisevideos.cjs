const fs = require('fs');
let code = fs.readFileSync('src/components/ExerciseVideos.tsx', 'utf-8');

// Add restTimerLeft state
if (!code.includes("const [restTimerLeft, setRestTimerLeft] = useState<number | null>(null);")) {
  code = code.replace(
    'const [confirmCompleteState, setConfirmCompleteState] = useState<{ isOpen: boolean } | null>(null);',
    'const [confirmCompleteState, setConfirmCompleteState] = useState<{ isOpen: boolean } | null>(null);\n  const [restTimerLeft, setRestTimerLeft] = useState<number | null>(null);\n\n  useEffect(() => {\n    if (restTimerLeft === null) return;\n    if (restTimerLeft <= 0) {\n      playSound("timer_complete");\n      setRestTimerLeft(null);\n      return;\n    }\n    const timerId = setInterval(() => {\n      setRestTimerLeft(prev => (prev ? prev - 1 : 0));\n    }, 1000);\n    return () => clearInterval(timerId);\n  }, [restTimerLeft]);'
  );
}

// Modify the UI to make the rest timer clickable
const restTimerRegex = /<div className="bg-\[#0C0F17\] p-2\.5 rounded-xl border border-cyan-950\/50 text-left">\s*<span className="block text-\[8px\] uppercase text-cyan-600 font-bold">Resting Timer<\/span>\s*<span className="block text-xs font-black text-white mt-1 uppercase">\{selectedExercise\.restTime\}<\/span>\s*<\/div>/;

const newRestTimerUI = `<button 
                        onClick={() => {
                          if (restTimerLeft !== null) {
                            playSound("timer_pause");
                            setRestTimerLeft(null);
                          } else {
                            playSound("timer_start");
                            const timeMatch = selectedExercise.restTime.match(/(\\d+)/);
                            const secs = timeMatch ? parseInt(timeMatch[1], 10) : 45;
                            setRestTimerLeft(secs);
                          }
                        }}
                        className={\`bg-[#0C0F17] p-2.5 rounded-xl border transition-colors duration-300 text-left \${restTimerLeft !== null ? 'border-cyan-500 bg-cyan-950/30' : 'border-cyan-950/50 hover:border-cyan-800'}\`}
                      >
                        <span className="block text-[8px] uppercase text-cyan-600 font-bold flex justify-between items-center">
                          Resting Timer
                          {restTimerLeft === null && <Play className="w-2.5 h-2.5" />}
                        </span>
                        <span className={\`block text-xs font-black mt-1 uppercase \${restTimerLeft !== null ? 'text-cyan-400' : 'text-white'}\`}>
                          {restTimerLeft !== null ? \`\${restTimerLeft} SECS\` : selectedExercise.restTime}
                        </span>
                      </button>`;

code = code.replace(restTimerRegex, newRestTimerUI);

fs.writeFileSync('src/components/ExerciseVideos.tsx', code);
console.log("Patched ExerciseVideos");
