const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');

code = code.replace(/\\n      <React\.Fragment>\\n/g, '\n      </React.Fragment>\n');

// Wait, I messed up the start tag `<React.Fragment>` too, but earlier I did:
// `.replace(/return \(/, 'return (\\n      <React.Fragment>')`
// So let's replace `return (\n      <React.Fragment>` ... wait, `\n` literal vs `\\n`
code = code.replace(/return \(\\n      <React\.Fragment>/g, 'return (\n      <React.Fragment>');

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
