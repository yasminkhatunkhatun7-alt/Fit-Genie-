import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { GuardianProvider } from './context/GuardianContext';
import { GenieTrackerProvider } from './context/GenieTrackerContext.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      
        <GuardianProvider>
          <App />
        </GuardianProvider>
      
    </ErrorBoundary>
  </StrictMode>,
);
