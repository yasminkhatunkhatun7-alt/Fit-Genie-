import { doc, getDoc, setDoc, onSnapshot, collection, increment } from '../lib/firestore';
import { db } from '../lib/firebase';
export function getLocalDateString() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export async function fetchOrGenerateMissions(todayStr: string, history: string[] | any[], userId?: string) {
  try {
    // If we have a user, try to fetch from daily_missions in Firestore
    if (userId) {
      // First, attempt to load from daily_missions collection
      
      
      
      const docRef = doc(db, 'users', userId, 'daily_missions', todayStr);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        return snap.data().missions;
      }
    }

    // Otherwise, generate new missions using our backend API (Gemini AI)
    const response = await fetch('/api/missions/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ history })
    });

    if (!response.ok) {
      throw new Error("Failed to generate missions");
    }

    let missions = await response.json();
    
    // Add boss and genie logic dynamically
    const d = new Date();
    if (d.getDay() === 0) {
      missions.boss = { id: 'b_weekly', title: 'Sunday Boss Challenge', xp: 500, type: 'BOSS' };
    }
    if (Math.random() < 0.15) {
      missions.genie = { id: 'g_random', title: 'Random Genie Challenge', xp: 150, type: 'GENIE' };
    }

    // Store the newly generated missions in Firestore if user is signed in
    if (userId) {
      
      
      const docRef = doc(db, 'users', userId, 'daily_missions', todayStr);
      await setDoc(docRef, { missions }, { merge: true });
    }

    return missions;
  } catch (error) {
    console.error("Error generating missions:", error);
    // Fallback static missions in case of failure
    return {
      easy: { id: 'fallback_e', title: 'Walk 5,000 steps', xp: 20, type: 'STEP' },
      medium: { id: 'fallback_m', title: 'Complete Home Workout', xp: 50, type: 'WORKOUT' },
      hard: { id: 'fallback_h', title: 'Walk 10,000 steps', xp: 100, type: 'STEP' }
    };
  }
}

