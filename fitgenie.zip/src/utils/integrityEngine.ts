import { ActiveChallenge } from "../components/ChallengesScreen";

export const EXERCISE_MIN_TIMES: Record<string, number> = {
  'Pushups': 1,
  'Squats': 0.8,
  'Crunches': 0.7,
  'Burpees': 2,
  'Plank': 1, 
  'Mountain Climbers': 0.5,
  'Jumping Jacks': 0.5,
  'Calf Raises': 0.8,
  'Dips': 1,
  'Pike Pushups': 1.2,
  'Pullups': 1.5,
  'Situps': 0.8,
  'Lunges': 1,
  'Russian Twists': 0.5,
  'High Knees': 0.4
};

export function calculateExpectedMinimumTime(exercises: { name: string; targetReps: number }[]): number {
  let expectedTimeSecs = 0;
  for (const ex of exercises) {
    const timePerRep = EXERCISE_MIN_TIMES[ex.name] || 0.5;
    expectedTimeSecs += timePerRep * ex.targetReps;
  }
  return expectedTimeSecs;
}

export function validateRepSpeed(exerciseName: string, addedReps: number, elapsedTimeSecs: number): boolean {
    const minTimePerRep = EXERCISE_MIN_TIMES[exerciseName] || 0.5;
    const requiredTime = addedReps * minTimePerRep;
    if (elapsedTimeSecs < requiredTime) {
        return false; // Suspicious!
    }
    return true;
}

export function getIntegrityRank(score: number): { title: string, color: string, badge: string } {
    if (score >= 95) return { title: "Elite Athlete", color: "text-[#B66DFF]", badge: "🏆" };
    if (score >= 80) return { title: "Dedicated Warrior", color: "text-[#14F1E1]", badge: "💪" };
    if (score >= 60) return { title: "Consistent Trainer", color: "text-[#4DA8FF]", badge: "⚡" };
    if (score >= 40) return { title: "Needs Improvement", color: "text-yellow-500", badge: "⚠" };
    return { title: "Untrusted Progress", color: "text-red-500", badge: "🚫" };
}

export function applyIntegrityMultiplier(xp: number, score: number): number {
    if (score < 30) return Math.floor(xp * 0.5);
    if (score < 50) return Math.floor(xp * 0.75);
    return xp;
}
