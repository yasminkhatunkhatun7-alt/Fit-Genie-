export const DAILY_SCHEDULE = [
  { 
    day: 0, 
    title: "Full Body Burnout", 
    xp: 250, 
    time: "45 Minutes", 
    muscles: ["Full Body", "Cardio"], 
    boss: "JUMP MASTER",
    exercises: [
      { name: "Jumping Jacks", targetReps: 200, completedReps: 0 },
      { name: "Burpees", targetReps: 100, completedReps: 0 },
      { name: "Squats", targetReps: 200, completedReps: 0 }
    ]
  },
  { 
    day: 1, 
    title: "Chest & Triceps Gauntlet", 
    xp: 200, 
    time: "45 Minutes", 
    muscles: ["Chest", "Triceps", "Front Delts"], 
    boss: "PUSHUP TITAN",
    exercises: [
      { name: "Pushups", targetReps: 200, completedReps: 0 },
      { name: "Diamond Pushups", targetReps: 100, completedReps: 0 },
      { name: "Pike Pushups", targetReps: 50, completedReps: 0 }
    ]
  },
  { 
    day: 2, 
    title: "Leg Day Massacre", 
    xp: 220, 
    time: "45 Minutes", 
    muscles: ["Quads", "Glutes", "Hamstrings"], 
    boss: "SQUAT KING",
    exercises: [
      { name: "Squats", targetReps: 300, completedReps: 0 },
      { name: "Lunges (Each Leg)", targetReps: 100, completedReps: 0 },
      { name: "Jump Squats", targetReps: 100, completedReps: 0 }
    ]
  },
  { 
    day: 3, 
    title: "Core Crusher", 
    xp: 180, 
    time: "40 Minutes", 
    muscles: ["Full Body", "Core", "Cardio"], 
    boss: "BURPEE BEAST",
    exercises: [
      { name: "Crunches", targetReps: 200, completedReps: 0 },
      { name: "Leg Raises", targetReps: 150, completedReps: 0 },
      { name: "Plank (Seconds)", targetReps: 180, completedReps: 0 }
    ]
  },
  { 
    day: 4, 
    title: "Back & Biceps Titan", 
    xp: 200, 
    time: "45 Minutes", 
    muscles: ["Back", "Biceps", "Lats"], 
    boss: "PULL UP DEMON",
    exercises: [
      { name: "Pull Ups", targetReps: 100, completedReps: 0 },
      { name: "Chin Ups", targetReps: 50, completedReps: 0 },
      { name: "Superman Raises", targetReps: 100, completedReps: 0 }
    ]
  },
  { 
    day: 5, 
    title: "Spartan Conditioning", 
    xp: 300, 
    time: "50 Minutes", 
    muscles: ["Full Body", "Cardio", "Core"], 
    boss: "SPARTAN GENERAL",
    exercises: [
      { name: "Burpees", targetReps: 150, completedReps: 0 },
      { name: "Mountain Climbers", targetReps: 200, completedReps: 0 },
      { name: "Jump Squats", targetReps: 150, completedReps: 0 }
    ]
  },
  { 
    day: 6, 
    title: "The 1000 Rep Challenge", 
    xp: 500, 
    time: "60 Minutes", 
    muscles: ["Full Body", "Endurance"], 
    boss: "GRAVITY DEFIER",
    exercises: [
      { name: "Pushups", targetReps: 250, completedReps: 0 },
      { name: "Squats", targetReps: 250, completedReps: 0 },
      { name: "Sit-ups", targetReps: 250, completedReps: 0 },
      { name: "Jumping Jacks", targetReps: 250, completedReps: 0 }
    ]
  }
];

export function getTodayChallenge() {
  const day = new Date().getDay();
  const schedule = DAILY_SCHEDULE.find(s => s.day === day) || DAILY_SCHEDULE[1];
  return {
    id: "daily",
    title: schedule.title,
    desc: `${schedule.exercises.length} Stage Challenge`,
    xp: schedule.xp,
    difficulty: "Extreme",
    exercises: JSON.parse(JSON.stringify(schedule.exercises)),
    time: schedule.time,
    muscles: schedule.muscles,
    boss: schedule.boss
  };
}

export function getTodayDateString() {
  return new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD
}
