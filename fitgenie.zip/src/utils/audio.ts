/**
 * Web Audio API based Synthesizer
 * Synthesizes short, premium-grade audio assets dynamically in real-time.
 * Avoids any static asset loading bottlenecks or CORS constraints.
 */

// Shared AudioContext instance initialized lazily
let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === "suspended") {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export type SoundType = 
  | "click" 
  | "success" 
  | "timer_complete" 
  | "countdown" 
  | "toggle"
  | "timer_tick"
  | "timer_start"
  | "timer_pause"
  | "timer_reset"
  | "error"
  | "rest_chime"
  | "box_breath_inhale"
  | "box_breath_hold"
  | "box_breath_exhale";

export type SoundPack = "cyber" | "iron_gym" | "arcade_8bit";
export type AmbientSoundscapeType = "off" | "iron_gym" | "lofi_beast" | "rain_focus";

const STORAGE_SOUND_PACK_KEY = "fitgenie_sound_pack";
let currentSoundPack: SoundPack = "cyber";

export function getSoundPack(): SoundPack {
  if (typeof window === "undefined") return "cyber";
  try {
    const saved = localStorage.getItem(STORAGE_SOUND_PACK_KEY);
    if (saved === "iron_gym" || saved === "arcade_8bit" || saved === "cyber") {
      currentSoundPack = saved;
      return saved;
    }
  } catch {}
  return currentSoundPack;
}

export function setSoundPack(pack: SoundPack): void {
  currentSoundPack = pack;
  try {
    localStorage.setItem(STORAGE_SOUND_PACK_KEY, pack);
  } catch {}
}

// Procedural Ambient Soundscape Engine (100% Free, Zero-Network)
let ambientNodes: { oscList: OscillatorNode[]; gain: GainNode; filter?: BiquadFilterNode } | null = null;
let activeAmbientType: AmbientSoundscapeType = "off";

export function getActiveAmbientSoundscape(): AmbientSoundscapeType {
  return activeAmbientType;
}

export function stopAmbientSoundscape() {
  if (ambientNodes) {
    try {
      ambientNodes.gain.gain.linearRampToValueAtTime(0.0001, (audioCtx?.currentTime || 0) + 0.5);
      setTimeout(() => {
        ambientNodes?.oscList.forEach(osc => {
          try { osc.stop(); osc.disconnect(); } catch {}
        });
        ambientNodes = null;
      }, 550);
    } catch {
      ambientNodes = null;
    }
  }
  activeAmbientType = "off";
}

export function startAmbientSoundscape(type: AmbientSoundscapeType) {
  stopAmbientSoundscape();
  if (type === "off") return;

  const ctx = getAudioContext();
  if (!ctx) return;
  const now = ctx.currentTime;
  activeAmbientType = type;

  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0.001, now);
  masterGain.connect(ctx.destination);

  const oscList: OscillatorNode[] = [];

  if (type === "lofi_beast") {
    // Relaxed warm binaural alpha drone (108 Hz + 118 Hz = 10 Hz alpha wave)
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(320, now);

    osc1.type = "sine";
    osc1.frequency.setValueAtTime(108, now);
    osc2.type = "sine";
    osc2.frequency.setValueAtTime(118, now);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(masterGain);

    masterGain.gain.exponentialRampToValueAtTime(0.04, now + 1.2);

    osc1.start(now);
    osc2.start(now);
    oscList.push(osc1, osc2);
    ambientNodes = { oscList, gain: masterGain, filter };
  } else if (type === "rain_focus") {
    // Calming filtered pink noise simulation
    const bufferSize = ctx.sampleRate * 2;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      output[i] = (b0 + b1 + b2) * 0.08;
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(800, now);

    whiteNoise.connect(filter);
    filter.connect(masterGain);

    masterGain.gain.exponentialRampToValueAtTime(0.05, now + 1.2);
    whiteNoise.start(now);
    // Cast to oscillator structure for uniform cleanup
    oscList.push(whiteNoise as any);
    ambientNodes = { oscList, gain: masterGain, filter };
  } else if (type === "iron_gym") {
    // Deep sub-bass iron pump hum (55 Hz low rumble)
    const subOsc = ctx.createOscillator();
    subOsc.type = "triangle";
    subOsc.frequency.setValueAtTime(55, now);

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(160, now);

    subOsc.connect(filter);
    filter.connect(masterGain);

    masterGain.gain.exponentialRampToValueAtTime(0.035, now + 1.0);
    subOsc.start(now);
    oscList.push(subOsc);
    ambientNodes = { oscList, gain: masterGain, filter };
  }
}

/**
 * Audio ducking: Smoothly dips ambient audio volume when coach speaks
 */
export function duckAudioForVoice(durationMs = 2500) {
  if (!ambientNodes || !audioCtx) return;
  const now = audioCtx.currentTime;
  try {
    ambientNodes.gain.gain.cancelScheduledValues(now);
    ambientNodes.gain.gain.linearRampToValueAtTime(0.01, now + 0.1);
    ambientNodes.gain.gain.linearRampToValueAtTime(0.045, now + (durationMs / 1000));
  } catch {}
}

export function playSound(type: SoundType) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    switch (type) {
      case "click": {
        // High-frequency, extremely fast decay organic woodblock-style tick
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = "sine";
        osc.frequency.setValueAtTime(1400, now);
        // Exponential ramp to simulate a physical strike
        osc.frequency.exponentialRampToValueAtTime(800, now + 0.04);

        gain.gain.setValueAtTime(0.04, now); // Super subtle volume
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.04);

        osc.start(now);
        osc.stop(now + 0.05);
        break;
      }

      case "toggle": {
        // Double micro pluck (low high) for switch toggles
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = "triangle";
        osc.frequency.setValueAtTime(400, now);
        osc.frequency.setValueAtTime(600, now + 0.05);

        gain.gain.setValueAtTime(0.03, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);

        osc.start(now);
        osc.stop(now + 0.15);
        break;
      }

      case "countdown": {
        // Dull, low-frequency warning wood block beep for 3, 2, 1
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = "sine";
        osc.frequency.setValueAtTime(520, now);

        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.08);

        osc.start(now);
        osc.stop(now + 0.1);
        break;
      }

      case "timer_complete": {
        // Dual oscillator harmony chime representing gym round completion
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        // Major chord interval (Root 783.99 Hz [G5] & 3rd 987.77 Hz [B5])
        osc1.type = "sine";
        osc1.frequency.setValueAtTime(783.99, now);
        osc2.type = "sine";
        osc2.frequency.setValueAtTime(987.77, now);

        // Chime sequence with secondary ring
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.03, now + 0.15);
        gain.gain.setValueAtTime(0.1, now + 0.2);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.6);

        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + 0.65);
        osc2.stop(now + 0.65);
        break;
      }

      case "success": {
        // Energizing rising scale with feedback loops
        const synth = (freq: number, start: number, duration: number) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);

          osc.type = "sine";
          osc.frequency.setValueAtTime(freq, start);
          gain.gain.setValueAtTime(0.08, start);
          gain.gain.exponentialRampToValueAtTime(0.001, start + duration);

          osc.start(start);
          osc.stop(start + duration);
        };

        // Arpeggio chords
        synth(523.25, now, 0.15);       // C5
        synth(659.25, now + 0.1, 0.15); // E5
        synth(783.99, now + 0.2, 0.2);  // G5
        synth(1046.50, now + 0.35, 0.45); // C6 Premium wrap-up chime
        break;
      }
      case "error": {
        // A harsh discordant double beep
        const playBeep = (start: number) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.type = "sawtooth";
          osc.frequency.setValueAtTime(150, start);
          osc.frequency.exponentialRampToValueAtTime(100, start + 0.1);
          gain.gain.setValueAtTime(0.1, start);
          gain.gain.exponentialRampToValueAtTime(0.001, start + 0.15);
          osc.start(start);
          osc.stop(start + 0.2);
        };
        playBeep(now);
        playBeep(now + 0.15);
        break;
      }

      case "timer_tick": {
        // High-frequency, ultra-short, soft organic clock-tick transient
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = "sine";
        osc.frequency.setValueAtTime(1800, now);
        osc.frequency.exponentialRampToValueAtTime(1200, now + 0.012);

        gain.gain.setValueAtTime(0.015, now); // Quiet background tick
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.015);

        osc.start(now);
        osc.stop(now + 0.02);
        break;
      }

      case "timer_start": {
        // Energizing sweet double upward chirp for rest start
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.type = "sine";
        osc1.frequency.setValueAtTime(600, now);
        osc1.frequency.exponentialRampToValueAtTime(900, now + 0.08);

        osc2.type = "sine";
        osc2.frequency.setValueAtTime(750, now + 0.04);
        osc2.frequency.exponentialRampToValueAtTime(1100, now + 0.12);

        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.03, now + 0.05);
        gain.gain.setValueAtTime(0.04, now + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);

        osc1.start(now);
        osc1.stop(now + 0.15);
        osc2.start(now + 0.04);
        osc2.stop(now + 0.16);
        break;
      }

      case "timer_pause": {
        // Subdued double downward slide for pausing rest
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = "triangle";
        osc.frequency.setValueAtTime(520, now);
        osc.frequency.exponentialRampToValueAtTime(320, now + 0.12);

        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.14);

        osc.start(now);
        osc.stop(now + 0.15);
        break;
      }

      case "timer_reset": {
        // Crisp laser-like high-to-low clean reset sweep
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = "sine";
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.exponentialRampToValueAtTime(220, now + 0.15);

        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.16);

        osc.start(now);
        osc.stop(now + 0.18);
        break;
      }

      case "rest_chime": {
        // A crystal clear double chime (high-low harmonized chime) for rest completion
        const playChime = (freq: number, startTime: number) => {
          const osc1 = ctx.createOscillator();
          const osc2 = ctx.createOscillator();
          const gainNode = ctx.createGain();

          osc1.connect(gainNode);
          osc2.connect(gainNode);
          gainNode.connect(ctx.destination);

          osc1.type = "sine";
          osc1.frequency.setValueAtTime(freq, startTime);
          // Add a major third (factor of 1.25) for a premium rich harmonic chime
          osc2.type = "sine";
          osc2.frequency.setValueAtTime(freq * 1.25, startTime);

          gainNode.gain.setValueAtTime(0, startTime);
          // Quick elegant attack
          gainNode.gain.linearRampToValueAtTime(0.12, startTime + 0.015);
          // Smooth exponential decay
          gainNode.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.82);

          osc1.start(startTime);
          osc1.stop(startTime + 0.85);
          osc2.start(startTime);
          osc2.stop(startTime + 0.85);
        };

        // Two sequential high-contrast harmonic chimes
        playChime(523.25, now); // C5
        playChime(659.25, now + 0.22); // E5
        break;
      }

      case "box_breath_inhale": {
        // Soft ascending harmonic tone (Inhale expansion)
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = "sine";
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.exponentialRampToValueAtTime(330, now + 0.6);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.06, now + 0.2);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.9);

        osc.start(now);
        osc.stop(now + 0.95);
        break;
      }

      case "box_breath_hold": {
        // Soft Tibetan bell chime
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = "sine";
        osc.frequency.setValueAtTime(440, now);

        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.8);

        osc.start(now);
        osc.stop(now + 0.85);
        break;
      }

      case "box_breath_exhale": {
        // Soft descending grounding tone (Exhale release)
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = "sine";
        osc.frequency.setValueAtTime(330, now);
        osc.frequency.exponentialRampToValueAtTime(165, now + 0.7);

        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.9);

        osc.start(now);
        osc.stop(now + 0.95);
        break;
      }
    }
  } catch (error) {
    // Fail silently to avoid crash when autoplay policies block AudioContext
    console.debug("Synthesizer playback blocked or unsupported by host context active rules:", error);
  }
}
