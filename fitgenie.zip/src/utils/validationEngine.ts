export const EXERCISE_MIN_TIMES: Record<string, number> = {
  'Pushups': 1,
  'Squats': 0.8,
  'Crunches': 0.7,
  'Burpees': 2,
  'Plank': 1, // time-based hold? Assuming 1 sec per unit if passed as reps, or maybe passed as seconds
  'Mountain Climbers': 0.5,
  'Jumping Jacks': 0.5,
  'Calf Raises': 0.8,
  'Dips': 1,
  'Pike Pushups': 1.2,
  'Pullups': 1.5,
  'Situps': 0.8,
  'Lunges': 1,
  'Russian Twists': 0.5,
  'High Knees': 0.4
};

export function calculateExpectedMinimumTime(exercises: { name: string; targetReps: number }[]): number {
  let expectedTimeSecs = 0;
  
  for (const ex of exercises) {
    const timePerRep = EXERCISE_MIN_TIMES[ex.name] || 0.5; // fallback to 0.5 sec
    // If it's a timed hold (e.g., Plank), the targetReps is likely the duration in seconds
    expectedTimeSecs += timePerRep * ex.targetReps;
  }
  
  return expectedTimeSecs; // in seconds
}
