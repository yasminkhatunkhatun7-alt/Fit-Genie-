import { useState } from "react";
import { db } from "../lib/firebase";
import { collection, addDoc } from "firebase/firestore";
import { UserProfile } from "../context/AuthContext";

export interface ChallengeTarget {
  userId: string;
  userName: string;
  score: number;
  exercise: "Squats" | "Pushups";
}

export function useGhostChallenge(profile: UserProfile | null) {
  const [isProcessing, setIsProcessing] = useState(false);

  const processChallengeResult = async (
    target: ChallengeTarget | null,
    reps: number
  ) => {
    if (!target || !profile) return false;
    
    const isWin = reps > target.score;
    
    if (isWin) {
      setIsProcessing(true);
      try {
        // Notify beaten user
        await addDoc(collection(db, "notifications"), {
          toUserId: target.userId,
          fromUserId: profile.uid || "local_user",
          fromUserName: profile.username || "Someone",
          type: "record_beaten",
          exerciseType: target.exercise.toLowerCase(),
          oldScore: target.score,
          newScore: reps,
          timestamp: Date.now(),
          read: false
        });

        // Activity feed post
        await addDoc(collection(db, "activityFeed"), {
          userId: profile.uid || "local_user",
          userName: profile.username || "Someone",
          userAvatar: profile.photoURL || "",
          userAvatarBg: profile.avatarBg || "bg-blue-500",
          type: "challenge_win",
          title: `Beat ${target.userName}'s ${target.exercise} record!`,
          description: `Scored ${reps} reps (vs ${target.score}) in the 1-Min Test.`,
          timestamp: Date.now(),
          likes: 0
        });
      } catch (e) {
        console.error("Failed to post challenge notifications/feed", e);
      } finally {
        setIsProcessing(false);
      }
    }
    
    return isWin;
  };

  return { processChallengeResult, isProcessing };
}
