import { useState, useRef, useEffect } from "react";
import { useGuardianContext } from "../context/GuardianContext";
import { useAuth } from "../context/AuthContext";

export type SuspiciousPhase =
  | "none"
  | "alert"
  | "apology"
  | "locked"
  | "motivation";

const MIN_SECONDS_PER_REP: Record<string, number> = {
  burpee: 1.2,
  pullup: 1.1,
  "pull-up": 1.1,
  "pull up": 1.1,
  chinup: 1.1,
  squat: 0.7,
  lunge: 0.85,
  pushup: 0.65,
  "push-up": 0.65,
  "push up": 0.65,
  dip: 0.7,
  crunch: 0.55,
  situp: 0.65,
  plank: 0.75,
  hold: 0.75,
  default: 0.65,
};

function getMinTimeForReps(exerciseName: string, reps: number): number {
  const lower = exerciseName.toLowerCase();
  const key =
    Object.keys(MIN_SECONDS_PER_REP).find((k) => lower.includes(k)) ||
    "default";
  return reps * MIN_SECONDS_PER_REP[key];
}

export function useGenieIntelligence(challengeId: string) {
  const { triggerEvent, addObservation, reportSuspiciousActivity } =
    useGuardianContext();
  const { updateProfileStats } = useAuth();

  // Initialize lastActionTime 10s in the past so a user's first honest small set (+1, +5, +10) is allowed after doing the set
  const sessionMountTimeRef = useRef<number>(Date.now());
  const lastActionTimeRef = useRef<number>(Date.now() - 10000);
  const tapHistoryRef = useRef<{ time: number; amount: number }[]>([]);
  const cheatStrikesRef = useRef<number>(0);

  const [suspiciousPhase, setSuspiciousPhase] =
    useState<SuspiciousPhase>("none");
  const [lockEndTime, setLockEndTime] = useState<number | null>(null);

  useEffect(() => {
    sessionMountTimeRef.current = Date.now();
    lastActionTimeRef.current = Date.now() - 10000;
    tapHistoryRef.current = [];
    cheatStrikesRef.current = 0;
    setSuspiciousPhase("none");
    setLockEndTime(null);
    triggerEvent("focused");
  }, [challengeId]);

  const applyCheatPenalty = (reason: string, severity: "warning" | "critical") => {
    cheatStrikesRef.current += 1;
    const strikes = cheatStrikesRef.current;

    reportSuspiciousActivity(reason, severity);
    updateProfileStats?.({
      integrityScoreChange: severity === "critical" ? -10 : -6,
    });

    if (strikes === 1) {
      setSuspiciousPhase("alert");
    } else if (strikes === 2) {
      setSuspiciousPhase("apology");
    } else {
      setLockEndTime(Date.now() + 30000);
      setSuspiciousPhase("locked");
    }
  };

  const checkCheat = (
    exerciseName: string,
    amount: number,
    timeSpentMs?: number
  ): boolean => {
    const now = Date.now();
    const timeSinceMountSec = (now - sessionMountTimeRef.current) / 1000;
    const timeSinceLastTapSec = timeSpentMs
      ? timeSpentMs / 1000
      : (now - lastActionTimeRef.current) / 1000;

    // Record tap in 4-second rolling window
    tapHistoryRef.current = [
      ...tapHistoryRef.current.filter((t) => now - t.time < 4000),
      { time: now, amount },
    ];

    const recentTaps = tapHistoryRef.current;
    const recentTotalReps = recentTaps.reduce((sum, t) => sum + t.amount, 0);
    const minBiomechanicalSec = getMinTimeForReps(exerciseName, amount);

    // 1. Instant Max / Bulk Cheat right after opening screen (e.g., clicking +15, +25, or Max within a few seconds of opening)
    if (amount >= 15 && timeSinceMountSec < Math.min(minBiomechanicalSec * 0.65, 18)) {
      applyCheatPenalty(
        `Screen kholte hi ${Math.round(timeSinceMountSec)}s me +${amount} ${exerciseName}? Orb ne instant cheat pakad liya bro! 🛑`,
        "critical"
      );
      return true;
    }

    // 2. Rapid Button Spamming (3+ taps within 2.6 seconds, or 4+ taps in 4 seconds)
    const tapsIn2_5s = recentTaps.filter((t) => now - t.time < 2600);
    if (tapsIn2_5s.length >= 3 || recentTaps.length >= 4) {
      applyCheatPenalty(
        `Lagataar button spam (${recentTotalReps} ${exerciseName} in 3s)! Buttons dabane se body nahi banti bro 👀`,
        "critical"
      );
      return true;
    }

    // 3. Impossible Rep Velocity between consecutive sets (e.g. clicking +10 or +15 twice within 4 seconds)
    if (
      recentTaps.length >= 2 &&
      (recentTotalReps >= 16 ||
        (amount >= 5 && timeSinceLastTapSec < Math.min(minBiomechanicalSec * 0.5, 6)))
    ) {
      applyCheatPenalty(
        `Sirf ${Math.max(1, Math.round(timeSinceLastTapSec))}s me +${amount} ${exerciseName}? Physics aur Orb dono ko pata hai ye fake tap hai! ⚠️`,
        "warning"
      );
      return true;
    }

    // Honest set logged
    lastActionTimeRef.current = now;
    addObservation(
      `Verified +${amount} reps of ${exerciseName} (${Math.round(
        timeSinceLastTapSec
      )}s interval).`
    );
    triggerEvent("happy");
    updateProfileStats?.({ integrityScoreChange: 1 });
    return false;
  };

  const evaluateWorkout = (
    exerciseName: string,
    amount: number,
    timeSpentMs?: number
  ): number => {
    const isCheating = checkCheat(exerciseName, amount, timeSpentMs);
    return isCheating ? 0 : 1;
  };

  const proceedFromAlert = () => {
    setSuspiciousPhase("none");
    lastActionTimeRef.current = Date.now();
    tapHistoryRef.current = [];
  };

  const submitApology = (msg: string) => {
    if (msg.trim().toLowerCase().includes("sorry")) {
      setSuspiciousPhase("motivation");
      lastActionTimeRef.current = Date.now();
      tapHistoryRef.current = [];
    }
  };

  const proceedFromMotivation = () => {
    setSuspiciousPhase("none");
    lastActionTimeRef.current = Date.now();
    tapHistoryRef.current = [];
  };

  const resetSessionTime = () => {
    sessionMountTimeRef.current = Date.now();
    lastActionTimeRef.current = Date.now() - 10000;
    tapHistoryRef.current = [];
  };

  return {
    cooldown: 0,
    suspiciousPhase,
    lockEndTime,
    evaluateWorkout,
    checkCheat,
    proceedFromAlert,
    proceedFromMotivation,
    submitApology,
    resetSessionTime,
  };
}
