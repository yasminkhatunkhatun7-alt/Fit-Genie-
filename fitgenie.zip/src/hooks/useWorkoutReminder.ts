import { useEffect, useState } from "react";
import { CompletedSession } from "../types";

export function useWorkoutReminder() {
  const [permission, setPermission] = useState<NotificationPermission | "default">("default");

  useEffect(() => {
    if ("Notification" in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const requestPermission = async () => {
    if ("Notification" in window) {
      const perm = await Notification.requestPermission();
      setPermission(perm);
      return perm;
    }
    return "denied";
  };

  useEffect(() => {
    const checkAndRemind = async () => {
      // Check if reminders are enabled by user
      const rawReminders = localStorage.getItem("fitgenie_reminders_enabled");
      const remindersEnabled = rawReminders ? JSON.parse(rawReminders) : false;
      if (!remindersEnabled) return;

      const rawPrefTime = localStorage.getItem("fitgenie_preferred_workout_time");
      const preferredTimeStr = rawPrefTime ? JSON.parse(rawPrefTime) : "18:00";
      const [prefHour, prefMin] = preferredTimeStr.split(":").map(Number);
      
      const now = new Date();
      // Check if it's past the preferred workout time
      if (now.getHours() > prefHour || (now.getHours() === prefHour && now.getMinutes() >= prefMin)) {
        const todayStr = now.toLocaleDateString("en-CA");
        const rawLastReminder = localStorage.getItem("fitgenie_last_reminder_date");
        const lastReminder = rawLastReminder ? JSON.parse(rawLastReminder) : null;
        
        // Already reminded today?
        if (lastReminder === todayStr) return;

        // Check workout history
        const historyStr = localStorage.getItem("fitgenie_history");
        const history: CompletedSession[] = historyStr ? JSON.parse(historyStr) : [];
        
        const hasWorkoutToday = history.some(session => {
          try {
            const sessionDate = new Date(session.date).toLocaleDateString("en-CA");
            return sessionDate === todayStr;
          } catch (e) {
            return false;
          }
        });

        if (!hasWorkoutToday) {
          // Trigger notification
          let currentPerm = permission;
          if (currentPerm === "default" && "Notification" in window) {
            currentPerm = await requestPermission();
          }

          if (currentPerm === "granted") {
            try {
              const notification = new Notification("Time to crush your goal! 💪", {
                body: "You haven't logged a workout yet today. Don't break your streak!",
                icon: "/icon.png"
              });
              
              notification.onclick = () => {
                window.focus();
                notification.close();
              };
              
              // Mark as sent for today
              localStorage.setItem("fitgenie_last_reminder_date", JSON.stringify(todayStr));
            } catch (error) {
              console.error("Failed to show notification:", error);
            }
          }
        }
      }
    };

    // Check immediately
    checkAndRemind();

    // Then check every minute
    const interval = setInterval(checkAndRemind, 60 * 1000);
    return () => clearInterval(interval);
  }, [permission]);

  return { requestPermission, permission };
}
