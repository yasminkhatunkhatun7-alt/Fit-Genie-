import { useEffect, useRef, useState } from 'react';
import { db, auth } from '../lib/firebase';
import { collection, query, where, onSnapshot, getDoc, doc } from 'firebase/firestore';
import { useAuth } from '../context/AuthContext';
import { playSound } from '../utils/audio';

export function useFollowNotifications() {
  const { profile } = useAuth();
  const isInitialRender = useRef(true);
  const mountTime = useRef(Date.now());
  const [inAppNotification, setInAppNotification] = useState<{title: string, body: string, id: number} | null>(null);

  useEffect(() => {
    if (!profile?.uid || profile.uid === 'local_user' || !auth.currentUser) return;

    // Request Notification permission if not already granted/denied
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }

    const q = query(
      collection(db, "follows"),
      where("followingId", "==", profile.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      snapshot.docChanges().forEach(async (change) => {
        if (change.type === "added") {
          const data = change.doc.data();
          
          // Prevent notifications for existing follows on mount
          if (data.timestamp && data.timestamp < mountTime.current) {
             return;
          }

          if (!isInitialRender.current) {
            try {
              const followerDoc = await getDoc(doc(db, "users", data.followerId));
              const followerName = followerDoc.exists() ? (followerDoc.data().username || "Someone") : "Someone";
              
              const title = "New Follower!";
              const body = `${followerName} started following you.`;

              // Trigger Web/System Notification
              if ("Notification" in window && Notification.permission === "granted") {
                new Notification(title, { body });
              }

              // Play a sound if available
              try { playSound("success"); } catch(e){}

              // Trigger In-App Notification
              setInAppNotification({ title, body, id: Date.now() });
              
              // Auto-hide in-app notification after 5 seconds
              setTimeout(() => {
                setInAppNotification(null);
              }, 5000);

            } catch (err) {
              console.error("Error triggering follow notification", err);
            }
          }
        }
      });
      isInitialRender.current = false;
    }, (error) => {
      console.warn("[useFollowNotifications] onSnapshot error:", error.message);
    });

    return () => unsubscribe();
  }, [profile?.uid]);

  return { inAppNotification, setInAppNotification };
}
