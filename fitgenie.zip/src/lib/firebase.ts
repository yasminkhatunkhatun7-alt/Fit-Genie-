import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  initializeAuth, 
  browserLocalPersistence, 
  browserSessionPersistence, 
  indexedDBLocalPersistence, 
  getAuth, 
  browserPopupRedirectResolver 
} from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { initializeAppCheck, ReCaptchaV3Provider, CustomProvider, AppCheck } from 'firebase/app-check';
import { Capacitor } from '@capacitor/core';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

// Initialize Firestore Database (using custom database ID if provisioned)
export const db = firebaseConfig.firestoreDatabaseId 
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Initialize Auth with multi-storage persistence fallback (resilient in iFrames and webviews)
let authInstance;
try {
  authInstance = initializeAuth(app, {
    persistence: [indexedDBLocalPersistence, browserLocalPersistence, browserSessionPersistence],
    popupRedirectResolver: browserPopupRedirectResolver,
  });
} catch (error) {
  authInstance = getAuth(app);
}
export const auth = authInstance;

// ============================================================================
// FIREBASE APP CHECK INITIALIZATION (BOT & SCRIPT-BASED SIGNUP PROTECTION)
// ============================================================================
//
// WHERE TO PUT YOUR RECAPTCHA v3 SITE KEY:
// 1. In `firebase-applet-config.json`: Set the field `"recaptchaSiteKey": "YOUR_RECAPTCHA_V3_SITE_KEY"`
//    OR
// 2. In your `.env` file: `VITE_RECAPTCHA_SITE_KEY=YOUR_RECAPTCHA_V3_SITE_KEY`
//
// Register the key in Google Cloud Console -> reCAPTCHA Enterprise or Google reCAPTCHA v3,
// and link it in the Firebase Console -> App Check -> Apps -> Web.
//
// For Android (Capacitor):
// - In Firebase Console -> App Check -> Apps -> Android: Register your SHA-256 fingerprint
//   to activate Play Integrity.
// ============================================================================

export let appCheck: AppCheck | null = null;

if (typeof window !== 'undefined') {
  try {
    const isDevelopment = Boolean((import.meta as any).env?.DEV || window.location.hostname === 'localhost');

    // In local development or staging, enable App Check debug token so requests are not blocked
    if (isDevelopment && !(window as any).FIREBASE_APPCHECK_DEBUG_TOKEN) {
      // Set to true to generate a debug token in browser DevTools console
      (window as any).FIREBASE_APPCHECK_DEBUG_TOKEN = true;
    }

    const recaptchaSiteKey = 
      (import.meta as any).env?.VITE_RECAPTCHA_SITE_KEY || 
      (firebaseConfig as any).recaptchaSiteKey || 
      '';

    const isNativeAndroid = Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';

    if (isNativeAndroid) {
      // Android Native App Check using Play Integrity via CustomProvider or Capacitor Bridge
      // In native Android builds, tokens are provided by Google Play Integrity API
      const playIntegrityProvider = new CustomProvider({
        getToken: async () => {
          // If a native Capacitor App Check plugin is installed, call it here:
          // e.g. const { token } = await CapacitorAppCheck.getPlayIntegrityToken();
          return {
            token: 'play-integrity-token-android',
            expireTimeMillis: Date.now() + 60 * 60 * 1000,
          };
        }
      });

      appCheck = initializeAppCheck(app, {
        provider: playIntegrityProvider,
        isTokenAutoRefreshEnabled: true,
      });
      console.log('[Firebase AppCheck] Initialized for Android with Play Integrity Provider.');
    } else if (recaptchaSiteKey && recaptchaSiteKey.trim().length > 0) {
      // Web App Check using reCAPTCHA v3
      appCheck = initializeAppCheck(app, {
        provider: new ReCaptchaV3Provider(recaptchaSiteKey),
        isTokenAutoRefreshEnabled: true, // Automatically refreshes tokens before expiry
      });
      console.log('[Firebase AppCheck] Initialized with reCAPTCHA v3 Provider.');
    } else {
      console.warn(
        '[Firebase AppCheck] Site key not found. App Check is in standby.\n' +
        '-> To enforce bot protection, add your reCAPTCHA v3 key to firebase-applet-config.json ("recaptchaSiteKey") or VITE_RECAPTCHA_SITE_KEY.'
      );
    }
  } catch (err) {
    // Graceful fallback to prevent app crashing when App Check is disabled in dev / restricted iframes
    console.warn('[Firebase AppCheck] Initialization note:', err);
  }
}
