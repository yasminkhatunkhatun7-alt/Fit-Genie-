export { doc, getDoc, setDoc, onSnapshot, collection, increment } from 'firebase/firestore';
