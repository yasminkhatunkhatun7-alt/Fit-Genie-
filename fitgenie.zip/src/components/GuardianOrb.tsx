import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence, useMotionValue } from "motion/react";
import { useGuardianContext } from "../context/GuardianContext";
import {
  useAuth,
  getIntegrityData,
  getGenieVitality,
  GENIE_STAGES,
} from "../context/AuthContext";
import GlowUpAndRecoveryHub from "./GlowUpAndRecoveryHub";
import { beatSynth } from "../utils/beatSynth";
import { playSound } from "../utils/audio";
import { speakGenie } from "../utils/voiceCoach";
import {
  Shield,
  Flame,
  X,
  Zap,
  Sparkles,
  Heart,
  Crown,
  AlertTriangle,
  RotateCcw,
  Droplets,
  Timer,
  Music,
  Mic,
  MicOff,
  Sliders,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

export const orbFloatVariants: any = {
  idle: {
    y: [0, -7, 0, 2.5, 0],
    scale: [1, 1.045, 1, 0.985, 1],
    rotate: [0, 5, 0, -5, 0],
    rotateZ: [0, 5, 0, -5, 0],
    transition: {
      duration: 4.2,
      repeat: Infinity,
      ease: "easeInOut",
    },
  },
  focused: {
    y: [0, -7, 0, 2.5, 0],
    scale: [1, 1.045, 1, 0.985, 1],
    rotate: [0, 5, 0, -5, 0],
    rotateZ: [0, 5, 0, -5, 0],
    transition: {
      duration: 4.2,
      repeat: Infinity,
      ease: "easeInOut",
    },
  },
  happy: {
    y: [0, -10, 0],
    scale: [1, 1.07, 1],
    rotate: [0, 6, -6, 0],
    rotateZ: [0, 6, -6, 0],
    transition: { duration: 2.2, repeat: Infinity, ease: "easeInOut" },
  },
  thinking: {
    y: [0, -5, 0],
    scale: [1, 1.03, 1],
    rotate: [0, 7, -7, 0],
    rotateZ: [0, 7, -7, 0],
    transition: { duration: 2.6, repeat: Infinity, ease: "easeInOut" },
  },
  suspicious: {
    y: [0, 3, 0],
    scaleX: 1.05,
    scaleY: 0.95,
    rotate: [0, -3, 3, 0],
    rotateZ: [0, -3, 3, 0],
    transition: { duration: 1.5, repeat: Infinity, ease: "easeInOut" },
  },
  angry: {
    x: [-2.5, 2.5, -2.5, 2.5, 0],
    y: 0,
    scale: 1.08,
    rotate: [-4, 4, -4, 4, 0],
    rotateZ: [-4, 4, -4, 4, 0],
    transition: { duration: 0.28, repeat: Infinity, ease: "linear" },
  },
  sleepy: {
    y: [2, 7, 2],
    scale: [0.92, 0.95, 0.92],
    rotate: [0, 2.5, -2.5, 0],
    rotateZ: [0, 2.5, -2.5, 0],
    transition: { duration: 5.5, repeat: Infinity, ease: "easeInOut" },
  },
  sick: {
    y: [3, 8, 3],
    scale: [0.88, 0.91, 0.88],
    rotate: [0, -2.5, 2.5, 0],
    rotateZ: [0, -2.5, 2.5, 0],
    transition: { duration: 6, repeat: Infinity, ease: "easeInOut" },
  },
  celebrating: {
    y: [0, -12, 0],
    scale: [1, 1.1, 1],
    rotate: [0, 10, -10, 0],
    rotateZ: [0, 10, -10, 0],
    transition: { duration: 1.2, repeat: Infinity, ease: "easeInOut" },
  },
};

/**
 * 3D Cyber-Optic Visor Eyes with inner plasma pupil, cursor tracking,
 * blinking, stage-based angular evolution, and drooping low-trust/sick state.
 */
const GenieVisorEyes = ({
  emotion,
  cursorPos,
  isBlinking,
  stage = 1,
  isSickOrLowTrust = false,
  compact = false,
}: {
  emotion: string;
  cursorPos: { x: number; y: number };
  isBlinking: boolean;
  stage?: 1 | 2 | 3;
  isSickOrLowTrust?: boolean;
  compact?: boolean;
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  let eyeOffsetX = 0;
  let eyeOffsetY = 0;

  if (containerRef.current) {
    const rect = containerRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const dx = cursorPos.x - centerX;
    const dy = cursorPos.y - centerY;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const maxEyeMove = compact ? 3.4 : 4.8;

    if (
      distance > 0 &&
      emotion !== "sleepy" &&
      emotion !== "angry" &&
      !isSickOrLowTrust
    ) {
      eyeOffsetX = (dx / distance) * Math.min(maxEyeMove, distance * 0.055);
      eyeOffsetY = (dy / distance) * Math.min(maxEyeMove, distance * 0.055);
    }
  }

  let leftTransform = {
    scaleY: isBlinking ? 0.08 : 1,
    rotate: stage === 1 ? -5 : stage === 2 ? -11 : -15,
    y: eyeOffsetY,
    x: eyeOffsetX,
  };
  let rightTransform = {
    scaleY: isBlinking ? 0.08 : 1,
    rotate: stage === 1 ? 5 : stage === 2 ? 11 : 15,
    y: eyeOffsetY,
    x: eyeOffsetX,
  };

  if (isSickOrLowTrust) {
    leftTransform.scaleY = isBlinking ? 0.05 : 0.28;
    rightTransform.scaleY = isBlinking ? 0.05 : 0.28;
    leftTransform.rotate = 14;
    rightTransform.rotate = -14;
    leftTransform.y += 1.5;
    rightTransform.y += 1.5;
  } else {
    switch (emotion) {
      case "sleepy":
        leftTransform.scaleY = 0.2;
        rightTransform.scaleY = 0.2;
        leftTransform.rotate = 8;
        rightTransform.rotate = -8;
        break;
      case "happy":
        if (!isBlinking) {
          leftTransform.scaleY = 0.78;
          rightTransform.scaleY = 0.78;
        }
        leftTransform.y -= 1;
        rightTransform.y -= 1;
        break;
      case "focused":
      case "idle":
        if (!isBlinking) {
          leftTransform.scaleY = stage === 3 ? 1.15 : 1;
          rightTransform.scaleY = stage === 3 ? 1.15 : 1;
        }
        break;
      case "thinking":
        if (!isBlinking) {
          leftTransform.scaleY = 1.08;
          rightTransform.scaleY = 0.48;
        }
        break;
      case "suspicious":
        if (!isBlinking) {
          leftTransform.scaleY = 0.36;
          rightTransform.scaleY = 0.36;
        }
        leftTransform.rotate = -15;
        rightTransform.rotate = 15;
        break;
      case "angry":
        leftTransform.rotate = 22;
        rightTransform.rotate = -22;
        if (!isBlinking) {
          leftTransform.scaleY = 0.48;
          rightTransform.scaleY = 0.48;
        }
        break;
      case "celebrating":
        if (!isBlinking) {
          leftTransform.scaleY = 1.25;
          rightTransform.scaleY = 1.25;
        }
        leftTransform.y -= 1.5;
        rightTransform.y -= 1.5;
        break;
    }
  }

  let visorFill = "#00F5D4";
  let visorCore = "#FFFFFF";
  let visorGlow = "0 0 8px #00F5D4, 0 0 16px rgba(0,245,212,0.9)";

  if (isSickOrLowTrust) {
    visorFill = "#A8A29E";
    visorCore = "#D6D3D1";
    visorGlow = "0 0 4px rgba(120,113,108,0.45)";
  } else if (emotion === "angry") {
    visorFill = "#FF2A5F";
    visorCore = "#FFE4E6";
    visorGlow = "0 0 12px #FF2A5F, 0 0 22px rgba(255,42,95,0.95)";
  } else if (emotion === "suspicious") {
    visorFill = "#FFB703";
    visorCore = "#FEF3C7";
    visorGlow = "0 0 10px #FFB703, 0 0 18px rgba(255,183,3,0.9)";
  } else if (stage === 3) {
    visorFill = "#FFB703";
    visorCore = "#FFFFFF";
    visorGlow = "0 0 10px #FFB703, 0 0 20px rgba(255,183,3,0.95)";
  } else if (stage === 2) {
    visorFill = "#38BDF8";
    visorCore = "#F0F9FF";
    visorGlow = "0 0 10px #00F5D4, 0 0 18px rgba(192,132,252,0.9)";
  }

  const visorWidth = compact
    ? stage === 3
      ? "w-3"
      : stage === 2
      ? "w-2.5"
      : "w-2.5"
    : "w-3.5";
  const visorHeight = compact ? "h-1.5" : "h-2";

  return (
    <div
      ref={containerRef}
      className={`flex ${compact ? "gap-1.5" : "gap-2.5"} z-20 items-center justify-center pointer-events-none`}
    >
      {/* Left 3D Cyber Optic Eye */}
      <motion.div
        animate={leftTransform}
        transition={{ duration: isBlinking ? 0.06 : 0.18 }}
        style={{
          background: `radial-gradient(circle at 50% 45%, ${visorCore} 0%, ${visorFill} 55%, ${visorFill}CC 100%)`,
          boxShadow: visorGlow,
          clipPath:
            stage === 1
              ? "polygon(8% 0%, 100% 14%, 92% 100%, 0% 86%)"
              : "polygon(0% 18%, 100% 0%, 88% 100%, 10% 88%)",
          willChange: "transform",
        }}
        className={`${visorWidth} ${visorHeight} rounded-[2px] relative`}
      />
      {/* Right 3D Cyber Optic Eye */}
      <motion.div
        animate={rightTransform}
        transition={{ duration: isBlinking ? 0.06 : 0.18 }}
        style={{
          background: `radial-gradient(circle at 50% 45%, ${visorCore} 0%, ${visorFill} 55%, ${visorFill}CC 100%)`,
          boxShadow: visorGlow,
          clipPath:
            stage === 1
              ? "polygon(0% 14%, 92% 0%, 100% 86%, 8% 100%)"
              : "polygon(0% 0%, 100% 18%, 90% 88%, 12% 100%)",
          willChange: "transform",
        }}
        className={`${visorWidth} ${visorHeight} rounded-[2px] relative`}
      />
    </div>
  );
};

/**
 * 3D Quantum Prismatic Arc-Reactor Sphere
 * Multi-layered 3D volumetric shader gradients, metallic beveled gimbals,
 * sacred icosahedron/tesseract core, curved glass refraction dome, and 3D recessed optic visor.
 */
export const HolographicOrbCore = ({
  stage = 1,
  emotion = "idle",
  isSickOrLowTrust = false,
  cursorPos = { x: 0, y: 0 },
  isBlinking = false,
  activeSkin,
  size = "floating",
}: {
  stage?: 1 | 2 | 3;
  emotion?: string;
  isSickOrLowTrust?: boolean;
  cursorPos?: { x: number; y: number };
  isBlinking?: boolean;
  activeSkin?: string;
  size?: "floating" | "header";
}) => {
  // Curated 3D Quantum Palette
  let coreHighlight = "#E0FBFC";
  let primaryHex = "#00F5D4"; // Bioluminescent Quantum Cyan
  let secondaryHex = "#00BBF9"; // Deep Hyper Sapphire
  let tertiaryHex = "#9B5DE5"; // Ultraviolet Rim
  let rimMetalHex = "#38BDF8";

  if (isSickOrLowTrust) {
    coreHighlight = "#D6D3D1";
    primaryHex = "#78716C"; // Volcanic Ash
    secondaryHex = "#57534E";
    tertiaryHex = "#44403C";
    rimMetalHex = "#78716C";
  } else if (emotion === "angry") {
    coreHighlight = "#FFE4E6";
    primaryHex = "#FF2A5F";
    secondaryHex = "#E11D48";
    tertiaryHex = "#FB7185";
    rimMetalHex = "#FDA4AF";
  } else if (emotion === "suspicious") {
    coreHighlight = "#FEF3C7";
    primaryHex = "#FFB703";
    secondaryHex = "#FB8500";
    tertiaryHex = "#EF4444";
    rimMetalHex = "#FDE047";
  } else if (activeSkin === "shadow_flame") {
    coreHighlight = "#FCE7F3";
    primaryHex = "#F72585";
    secondaryHex = "#7209B7";
    tertiaryHex = "#4CC9F0";
    rimMetalHex = "#F472B6";
  } else if (activeSkin === "solar_gold" || stage === 3) {
    // Stage 3 Celestial Singularity: Molten Solar Gold, Supernova Rose-Crimson & Quantum Cyan
    coreHighlight = "#FFFBEB";
    primaryHex = "#FFB703";
    secondaryHex = "#FF006E";
    tertiaryHex = "#00F5D4";
    rimMetalHex = "#FDE047";
  } else if (stage === 2) {
    // Stage 2 Hyperion Warrior: Electric Cyan, Cyber Indigo & Neon Magenta
    coreHighlight = "#ECFEFF";
    primaryHex = "#00F5D4";
    secondaryHex = "#6366F1";
    tertiaryHex = "#EC4899";
    rimMetalHex = "#818CF8";
  }

  // Rotation speeds tuned by stage & vitality
  const gimbalSpeed1 = isSickOrLowTrust ? 24 : stage === 3 ? 4.2 : stage === 2 ? 5.8 : 8.5;
  const gimbalSpeed2 = isSickOrLowTrust ? 30 : stage === 3 ? 5.4 : stage === 2 ? 7.2 : 11;
  const gimbalSpeed3 = isSickOrLowTrust ? 36 : stage === 3 ? 6.8 : 9.5;

  const sphereRadius = stage === 3 ? 28.5 : stage === 2 ? 27 : 25.5;
  const uid = size === "floating" ? "q_orb_flt" : "q_orb_hdr";

  // Orbiting quantum satellites
  const satellites =
    stage === 3
      ? [0, 60, 120, 180, 240, 300]
      : stage === 2
      ? [0, 90, 180, 270]
      : [30, 150, 270];

  return (
    <div
      className="relative w-full h-full flex items-center justify-center pointer-events-none select-none"
      style={{ willChange: "transform" }}
    >
      {/* LAYER 0: Deep 3D Volumetric Corona & Backlight Halo */}
      <motion.div
        animate={
          isSickOrLowTrust
            ? { scale: [0.92, 0.98, 0.92], opacity: [0.22, 0.34, 0.22] }
            : { scale: [0.94, 1.16, 0.94], opacity: [0.55, 0.9, 0.55] }
        }
        transition={{
          duration: isSickOrLowTrust ? 5.5 : stage === 3 ? 2.4 : 3.4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute inset-0 rounded-full pointer-events-none"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${primaryHex}66 0%, ${secondaryHex}38 45%, ${tertiaryHex}18 68%, transparent 82%)`,
          filter: "blur(6px)",
          willChange: "transform, opacity",
        }}
      />

      {/* LAYER 1: Multi-Layered 3D SVG Arc-Reactor & Refractive Glass Sphere */}
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full overflow-visible pointer-events-none relative z-10"
      >
        <defs>
          {/* 3D Physically-Based Sphere Shading (Top-Left Light Source + Deep Void Core + Bottom-Right Rim Bounce) */}
          <radialGradient
            id={`${uid}_pbr_sphere`}
            cx="50%"
            cy="50%"
            r="52%"
            fx="32%"
            fy="28%"
          >
            <stop offset="0%" stopColor={coreHighlight} stopOpacity={isSickOrLowTrust ? "0.5" : "0.98"} />
            <stop offset="22%" stopColor={primaryHex} stopOpacity={isSickOrLowTrust ? "0.6" : "0.95"} />
            <stop offset="56%" stopColor={secondaryHex} stopOpacity={isSickOrLowTrust ? "0.55" : "0.88"} />
            <stop offset="82%" stopColor="#040816" stopOpacity="0.96" />
            <stop offset="100%" stopColor={tertiaryHex} stopOpacity={isSickOrLowTrust ? "0.35" : "0.85"} />
          </radialGradient>

          {/* Inner Plasma Singularity Nucleus Gradient */}
          <radialGradient id={`${uid}_nucleus`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity={isSickOrLowTrust ? "0.4" : "1"} />
            <stop offset="45%" stopColor={primaryHex} stopOpacity={isSickOrLowTrust ? "0.35" : "0.85"} />
            <stop offset="100%" stopColor={secondaryHex} stopOpacity="0" />
          </radialGradient>

          {/* 3D Metallic Bevel Gimbal Gradient */}
          <linearGradient id={`${uid}_gimbal_metal`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={coreHighlight} stopOpacity="0.95" />
            <stop offset="35%" stopColor={primaryHex} stopOpacity="0.85" />
            <stop offset="70%" stopColor={secondaryHex} stopOpacity="0.65" />
            <stop offset="100%" stopColor={tertiaryHex} stopOpacity="0.95" />
          </linearGradient>

          {/* Top-Left Glass Dome Specular Gradient */}
          <linearGradient id={`${uid}_glass_gloss`} x1="15%" y1="10%" x2="65%" y2="65%">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity={isSickOrLowTrust ? "0.25" : "0.75"} />
            <stop offset="45%" stopColor="#FFFFFF" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* BACK-HEMISPHERE ORBITAL RINGS (creates true 3D depth behind the sphere) */}
        <motion.g
          animate={{ rotate: 360 }}
          transition={{ duration: gimbalSpeed1, repeat: Infinity, ease: "linear" }}
          style={{ transformOrigin: "50px 50px", willChange: "transform" }}
        >
          <ellipse
            cx="50"
            cy="50"
            rx={stage === 3 ? "46" : stage === 2 ? "44" : "41"}
            ry={stage === 3 ? "16" : "14"}
            fill="none"
            stroke={`url(#${uid}_gimbal_metal)`}
            strokeWidth={stage === 3 ? "2.1" : "1.6"}
            strokeDasharray="24 6 4 6"
            opacity={isSickOrLowTrust ? 0.3 : 0.85}
          />
          {/* Glowing Power Node on Gimbal A */}
          <circle
            cx={stage === 3 ? "96" : stage === 2 ? "94" : "91"}
            cy="50"
            r={stage === 3 ? "2.6" : "2"}
            fill={coreHighlight}
            stroke={primaryHex}
            strokeWidth="1"
            opacity={isSickOrLowTrust ? 0.35 : 1}
          />
          <circle
            cx={stage === 3 ? "4" : stage === 2 ? "6" : "9"}
            cy="50"
            r="1.8"
            fill={tertiaryHex}
            opacity={isSickOrLowTrust ? 0.3 : 0.9}
          />
        </motion.g>

        {/* COUNTER-ROTATING 3D GIMBAL RING B (62° Tilt) */}
        <motion.g
          animate={{ rotate: -360 }}
          transition={{ duration: gimbalSpeed2, repeat: Infinity, ease: "linear" }}
          style={{ transformOrigin: "50px 50px", willChange: "transform" }}
        >
          <ellipse
            cx="50"
            cy="50"
            rx="15"
            ry={stage === 3 ? "46" : stage === 2 ? "43" : "39"}
            fill="none"
            stroke={secondaryHex}
            strokeWidth={stage >= 2 ? "1.7" : "1.2"}
            strokeDasharray="16 8 3 8"
            opacity={isSickOrLowTrust ? 0.25 : 0.8}
          />
          <circle
            cx="50"
            cy={stage === 3 ? "4" : stage === 2 ? "7" : "11"}
            r="2.1"
            fill={primaryHex}
            opacity={isSickOrLowTrust ? 0.3 : 0.95}
          />
        </motion.g>

        {/* OUTER PRECISION CHRONO BEZEL RING (Stage 2 & 3) */}
        {stage >= 2 && (
          <motion.g
            animate={{ rotate: 360 }}
            transition={{ duration: gimbalSpeed3, repeat: Infinity, ease: "linear" }}
            style={{ transformOrigin: "50px 50px", willChange: "transform" }}
          >
            <circle
              cx="50"
              cy="50"
              r={stage === 3 ? "41" : "37"}
              fill="none"
              stroke={tertiaryHex}
              strokeWidth={stage === 3 ? "1.4" : "1"}
              strokeDasharray={stage === 3 ? "2 5 10 5" : "2 8"}
              opacity={isSickOrLowTrust ? 0.2 : 0.72}
            />
          </motion.g>
        )}

        {/* CORE 3D REFRACTIVE SPHERE BODY */}
        <motion.g
          animate={{
            scale: isSickOrLowTrust ? [0.97, 1, 0.97] : [0.97, 1.04, 0.97],
          }}
          transition={{
            duration: isSickOrLowTrust ? 4.5 : 2.4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          style={{ transformOrigin: "50px 50px", willChange: "transform" }}
        >
          {/* Outer Dark Metallic Rim Ring */}
          <circle
            cx="50"
            cy="50"
            r={sphereRadius + 1.2}
            fill="#030712"
            stroke={`url(#${uid}_gimbal_metal)`}
            strokeWidth="1.2"
            opacity={isSickOrLowTrust ? 0.6 : 0.95}
          />

          {/* Main 3D Shaded Sphere */}
          <circle
            cx="50"
            cy="50"
            r={sphereRadius}
            fill={`url(#${uid}_pbr_sphere)`}
          />

          {/* Pulsing Internal Plasma Singularity Nucleus */}
          <circle
            cx="50"
            cy="50"
            r={sphereRadius * 0.78}
            fill={`url(#${uid}_nucleus)`}
          />
        </motion.g>

        {/* INTERNAL 3D SACRED POLYHEDRON / TESSERACT LATTICE */}
        <motion.g
          animate={{ rotate: isSickOrLowTrust ? 180 : 360 }}
          transition={{
            duration: isSickOrLowTrust ? 38 : 15,
            repeat: Infinity,
            ease: "linear",
          }}
          style={{ transformOrigin: "50px 50px", willChange: "transform" }}
          opacity={isSickOrLowTrust ? 0.2 : 0.58}
        >
          {/* Geodesic Equatorial & Meridional Rings */}
          <ellipse
            cx="50"
            cy="50"
            rx={sphereRadius - 1}
            ry={(sphereRadius - 1) * 0.44}
            fill="none"
            stroke={coreHighlight}
            strokeWidth="0.75"
            strokeDasharray="4 3"
          />
          <ellipse
            cx="50"
            cy="50"
            rx={(sphereRadius - 1) * 0.44}
            ry={sphereRadius - 1}
            fill="none"
            stroke={coreHighlight}
            strokeWidth="0.75"
            strokeDasharray="4 3"
          />
          {/* 3D Octahedral / Hexagonal Facet Lines inside Sphere */}
          <polygon
            points="50,25 72,37 72,63 50,75 28,63 28,37"
            fill="none"
            stroke={primaryHex}
            strokeWidth="0.8"
          />
          {stage >= 2 && (
            <polygon
              points="50,75 72,63 72,37 50,25 28,37 28,63"
              transform="rotate(30 50 50)"
              fill="none"
              stroke={tertiaryHex}
              strokeWidth="0.7"
              strokeOpacity="0.8"
            />
          )}
        </motion.g>

        {/* FOREGROUND 3D CURVED GLASS SPECULAR HIGHLIGHT & RIM CRESCENT */}
        {/* Top-left 3D glass dome reflection */}
        <ellipse
          cx="40"
          cy="36"
          rx={sphereRadius * 0.48}
          ry={sphereRadius * 0.25}
          transform="rotate(-26 40 36)"
          fill={`url(#${uid}_glass_gloss)`}
        />
        {/* Secondary pinpoint lens reflection */}
        <circle
          cx="33"
          cy="31"
          r="2.2"
          fill="#FFFFFF"
          opacity={isSickOrLowTrust ? 0.2 : 0.85}
        />
        {/* Bottom-right 3D bounce rim crescent */}
        <path
          d={`M ${50 + sphereRadius * 0.25} ${50 + sphereRadius * 0.82} A ${sphereRadius * 0.88} ${sphereRadius * 0.88} 0 0 0 ${50 + sphereRadius * 0.84} ${50 + sphereRadius * 0.2}`}
          fill="none"
          stroke={coreHighlight}
          strokeWidth="1.5"
          strokeLinecap="round"
          opacity={isSickOrLowTrust ? 0.15 : 0.65}
        />

        {/* LAYER 6: Orbiting Quantum Satellites */}
        <motion.g
          animate={{ rotate: -360 }}
          transition={{
            duration: isSickOrLowTrust ? 32 : stage === 3 ? 6.5 : 10,
            repeat: Infinity,
            ease: "linear",
          }}
          style={{ transformOrigin: "50px 50px", willChange: "transform" }}
        >
          {satellites.map((deg, idx) => {
            const rad = (deg * Math.PI) / 180;
            const orbitR = stage === 3 ? 44 : stage === 2 ? 41 : 37;
            const px = 50 + Math.cos(rad) * orbitR;
            const py = 50 + Math.sin(rad) * orbitR;
            return (
              <g key={idx}>
                <circle
                  cx={px}
                  cy={py}
                  r={idx % 2 === 0 ? "1.9" : "1.3"}
                  fill={idx % 2 === 0 ? coreHighlight : primaryHex}
                  opacity={isSickOrLowTrust ? 0.25 : 0.95}
                />
                <circle
                  cx={px}
                  cy={py}
                  r={idx % 2 === 0 ? "3.4" : "2.4"}
                  fill={idx % 2 === 0 ? primaryHex : tertiaryHex}
                  opacity={isSickOrLowTrust ? 0.1 : 0.35}
                />
              </g>
            );
          })}
        </motion.g>
      </svg>

      {/* 3D RECESSED CURVED OBSIDIAN VISOR CHAMBER + CYBER-OPTIC EYES */}
      <div
        className="absolute z-20 rounded-full bg-[#030712]/88 border flex items-center justify-center pointer-events-none overflow-hidden"
        style={{
          width: size === "floating" ? "46%" : "50%",
          height: size === "floating" ? "33%" : "36%",
          borderColor: `${rimMetalHex}66`,
          boxShadow: `inset 0 2px 6px rgba(0,0,0,0.95), inset 0 -1px 4px ${primaryHex}44, 0 0 12px ${primaryHex}40`,
        }}
      >
        {/* Subtle Visor Glass Gloss Strip */}
        <div
          className="absolute top-0 left-1 right-1 h-[35%] rounded-t-full pointer-events-none"
          style={{
            background:
              "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0) 100%)",
          }}
        />
        <GenieVisorEyes
          emotion={emotion}
          cursorPos={cursorPos}
          isBlinking={isBlinking}
          stage={stage}
          isSickOrLowTrust={isSickOrLowTrust}
          compact={true}
        />
      </div>
    </div>
  );
};

const ORB_POS_STORAGE_KEY = "fitgenie_orb_offset_v2";

function getTodayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
}

export default function GuardianOrb() {
  const {
    emotion,
    message,
    isPanelOpen,
    setIsPanelOpen,
    activeWarning,
    setActiveWarning,
    observations,
    setEmotion,
    setMessage,
  } = useGuardianContext();

  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState<"hud" | "shield">("hud");
  const [showRecoveryStudio, setShowRecoveryStudio] = useState(false);

  const [apology, setApology] = useState("");
  const [apologyError, setApologyError] = useState(false);

  // Quick Radial Menu, 60s Rest Timer, Beat Synth & Voice Mic States
  const [isRadialOpen, setIsRadialOpen] = useState(false);
  const [restSecondsLeft, setRestSecondsLeft] = useState<number | null>(null);
  const [beatPlaying, setBeatPlaying] = useState(
    () => beatSynth.getState().isPlaying
  );
  const [isVoiceListening, setIsVoiceListening] = useState(false);
  const [todayWaterMl, setTodayWaterMl] = useState<number>(() => {
    try {
      const today = getTodayKey();
      const logs = JSON.parse(localStorage.getItem("fitgenie_nutrition_logs") || "{}");
      return Number(logs[today]?.water || 0);
    } catch {
      return 0;
    }
  });

  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const syncWater = () => {
      try {
        const today = getTodayKey();
        const logs = JSON.parse(localStorage.getItem("fitgenie_nutrition_logs") || "{}");
        setTodayWaterMl(Number(logs[today]?.water || 0));
      } catch {}
    };
    window.addEventListener("storage", syncWater);
    return () => window.removeEventListener("storage", syncWater);
  }, []);

  useEffect(() => {
    return beatSynth.subscribe(() => {
      setBeatPlaying(beatSynth.getState().isPlaying);
    });
  }, []);

  // 60s Rest Timer Countdown
  useEffect(() => {
    if (restSecondsLeft === null) return;
    if (restSecondsLeft <= 0) {
      playSound("rest_chime");
      setEmotion("happy");
      setMessage("60s Rest Complete! Next set shuru karo warrior", 3500);
      speakGenie("Rest complete warrior! Next set shuru karo!");
      setRestSecondsLeft(null);
      return;
    }
    const tid = setInterval(() => {
      setRestSecondsLeft((s) => (s !== null ? s - 1 : null));
    }, 1000);
    return () => clearInterval(tid);
  }, [restSecondsLeft, setEmotion, setMessage]);

  const handleQuickWater = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    playSound("success");
    try {
      const today = getTodayKey();
      const rawLogs = localStorage.getItem("fitgenie_nutrition_logs");
      const logs = rawLogs ? JSON.parse(rawLogs) : {};
      if (!logs[today]) {
        logs[today] = { date: today, items: [], water: 0 };
      }
      const nextWaterMl = Number(logs[today].water || 0) + 250;
      logs[today].water = nextWaterMl;
      localStorage.setItem("fitgenie_nutrition_logs", JSON.stringify(logs));
      localStorage.setItem("fitgenie_water_glasses", String(Math.round(nextWaterMl / 250)));
      setTodayWaterMl(nextWaterMl);
      window.dispatchEvent(new Event("storage"));
      setEmotion("happy");
      setMessage(`+250ml Water Synced (${nextWaterMl}ml today)`, 2600);
    } catch {}
  };

  const handleQuickTimer = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    playSound("click");
    if (restSecondsLeft !== null) {
      setRestSecondsLeft(null);
      setMessage("Rest Timer Reset", 2000);
    } else {
      setRestSecondsLeft(60);
      setEmotion("focused");
      setMessage("60s Rest Timer Started", 2500);
    }
  };

  const handleToggleBeats = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    playSound("click");
    beatSynth.toggle();
    const nextState = beatSynth.getState();
    setMessage(
      nextState.isPlaying
        ? `${nextState.style.toUpperCase()} Beats ON (${nextState.bpm} BPM)`
        : "Workout Beats Paused",
      2500
    );
  };

  const handleToggleVoiceMic = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    playSound("click");
    const SpeechRec =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (!SpeechRec) {
      setMessage("Browser voice recognition unavailable on this device", 3000);
      return;
    }

    if (isVoiceListening && recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
      setIsVoiceListening(false);
      setMessage("Voice Commands OFF", 2000);
      return;
    }

    try {
      const rec = new SpeechRec();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = "en-IN";

      rec.onstart = () => {
        setIsVoiceListening(true);
        setEmotion("thinking");
        setMessage(
          'Listening... Say "Start Timer", "Water", "Play Beats", or "Status"',
          4000
        );
      };

      rec.onresult = (event: any) => {
        const transcript = (
          event?.results?.[0]?.[0]?.transcript || ""
        ).toLowerCase();
        if (transcript.includes("timer") || transcript.includes("rest")) {
          if (transcript.includes("stop") || transcript.includes("reset")) {
            setRestSecondsLeft(null);
            setMessage("Voice: Timer Stopped", 2500);
          } else {
            setRestSecondsLeft(60);
            setMessage("Voice: 60s Rest Timer Started", 3000);
          }
        } else if (
          transcript.includes("water") ||
          transcript.includes("pani")
        ) {
          handleQuickWater();
        } else if (
          transcript.includes("beat") ||
          transcript.includes("music") ||
          transcript.includes("phonk")
        ) {
          if (transcript.includes("stop") || transcript.includes("off")) {
            beatSynth.stop();
            setMessage("Voice: Beats Stopped", 2500);
          } else {
            beatSynth.start("phonk");
            setMessage("Voice: Gym Phonk Beats ON", 2800);
          }
        } else if (
          transcript.includes("status") ||
          transcript.includes("xp")
        ) {
          const xpVal = profile?.xp || 0;
          const strk = profile?.streak || 0;
          speakGenie(
            `Current XP is ${xpVal} and active streak is ${strk} days!`
          );
          setMessage(`XP: ${xpVal} • Streak: ${strk}d`, 3500);
        } else {
          setMessage(`Heard: "${transcript}"`, 2800);
        }
      };

      rec.onerror = () => {
        setIsVoiceListening(false);
      };
      rec.onend = () => {
        setIsVoiceListening(false);
        setEmotion("focused");
      };

      recognitionRef.current = rec;
      rec.start();
    } catch {
      setIsVoiceListening(false);
    }
  };

  const handleOrbTap = () => {
    if (hasDraggedRef.current) return;
    playSound("click");
    setIsPanelOpen(true);
  };

  const dragX = useMotionValue(0);
  const dragY = useMotionValue(0);
  const hasDraggedRef = useRef(false);

  const [viewportBounds, setViewportBounds] = useState(() => ({
    left: typeof window !== "undefined" ? -(window.innerWidth - 80) : -300,
    right: 8,
    top: typeof window !== "undefined" ? -(window.innerHeight - 160) : -600,
    bottom: 64,
  }));

  useEffect(() => {
    const updateBounds = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const newBounds = {
        left: -(w - 80),
        right: 8,
        top: -(h - 160),
        bottom: 64,
      };
      setViewportBounds(newBounds);

      const curX = dragX.get();
      const curY = dragY.get();
      if (curX < newBounds.left) dragX.set(newBounds.left);
      if (curX > newBounds.right) dragX.set(newBounds.right);
      if (curY < newBounds.top) dragY.set(newBounds.top);
      if (curY > newBounds.bottom) dragY.set(newBounds.bottom);
    };

    try {
      const savedPos = localStorage.getItem(ORB_POS_STORAGE_KEY);
      if (savedPos) {
        const parsed = JSON.parse(savedPos);
        const w = window.innerWidth;
        const h = window.innerHeight;
        const clampedX = Math.max(-(w - 80), Math.min(8, parsed.x || 0));
        const clampedY = Math.max(-(h - 160), Math.min(64, parsed.y || 0));
        dragX.set(clampedX);
        dragY.set(clampedY);
      }
    } catch {}

    updateBounds();
    window.addEventListener("resize", updateBounds);
    return () => window.removeEventListener("resize", updateBounds);
  }, [dragX, dragY]);

  const handleResetOrbPosition = () => {
    dragX.set(0);
    dragY.set(0);
    try {
      localStorage.removeItem(ORB_POS_STORAGE_KEY);
    } catch {}
  };

  // Eye tracking & blinking
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 });
  const [isBlinking, setIsBlinking] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setCursorPos({ x: e.clientX, y: e.clientY });
    };
    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches && e.touches[0]) {
        setCursorPos({
          x: e.touches[0].clientX,
          y: e.touches[0].clientY,
        });
      }
    };
    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    window.addEventListener("touchmove", handleTouchMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("touchmove", handleTouchMove);
    };
  }, []);

  useEffect(() => {
    let timeoutId: ReturnType<typeof setTimeout>;
    const blinkCycle = () => {
      const nextBlink = Math.random() * 3800 + 2000;
      timeoutId = setTimeout(() => {
        setIsBlinking(true);
        setTimeout(() => {
          setIsBlinking(false);
          blinkCycle();
        }, 140);
      }, nextBlink);
    };
    blinkCycle();
    return () => clearTimeout(timeoutId);
  }, []);

  const prevRankRef = useRef(profile?.rank || "Beginner");
  const prevStreakRef = useRef(profile?.streak || 0);

  useEffect(() => {
    if (profile) {
      if (profile.rank !== prevRankRef.current) {
        setEmotion("celebrating");
        setMessage(`Rank Up: ${profile.rank}!`, 3500);
        prevRankRef.current = profile.rank;
      }

      if (profile.streak !== prevStreakRef.current) {
        if (
          profile.streak === 7 ||
          profile.streak === 30 ||
          profile.streak === 90
        ) {
          setEmotion("celebrating");
          setMessage(`${profile.streak}-Day Streak Unlocked!`, 3500);
        }
        prevStreakRef.current = profile.streak;
      }
    }
  }, [profile?.rank, profile?.streak, setEmotion, setMessage]);

  const { isSick, daysInactive } = getGenieVitality(
    profile?.lastActiveDate,
    profile?.last_workout_date
  );
  const currentStage: 1 | 2 | 3 = (profile?.genieStage || 1) as 1 | 2 | 3;
  const stageData = GENIE_STAGES[currentStage];
  const trustScore = profile?.integrityScore ?? 100;
  const isSickOrLowTrust = isSick || trustScore < 60;

  useEffect(() => {
    if (isSickOrLowTrust) {
      setEmotion("sick");
    } else if (profile?.last_workout_date) {
      const lastWorkout = new Date(profile.last_workout_date).getTime();
      const diff = Date.now() - lastWorkout;
      if (diff > 24 * 60 * 60 * 1000) {
        setEmotion("sleepy");
      }
    }
  }, [isSickOrLowTrust, profile?.last_workout_date, setEmotion]);

  const handleDragStart = () => {
    hasDraggedRef.current = true;
  };

  const handleDragEnd = () => {
    const curX = Math.max(
      viewportBounds.left,
      Math.min(viewportBounds.right, dragX.get())
    );
    const curY = Math.max(
      viewportBounds.top,
      Math.min(viewportBounds.bottom, dragY.get())
    );
    dragX.set(curX);
    dragY.set(curY);

    try {
      localStorage.setItem(
        ORB_POS_STORAGE_KEY,
        JSON.stringify({ x: curX, y: curY })
      );
    } catch {}

    setTimeout(() => {
      hasDraggedRef.current = false;
    }, 100);
  };

  const handleApology = (e: React.FormEvent) => {
    e.preventDefault();
    const normalizedInput = apology.toLowerCase().replace(/[^a-z]/g, "");
    const target = "sorrygenieabsehonestworkoutkarunga";
    if (
      normalizedInput === target ||
      normalizedInput.includes("sorry")
    ) {
      setActiveWarning(false);
      setApology("");
      setApologyError(false);
      setEmotion("focused");
      setMessage("", 0);
    } else {
      setApologyError(true);
      setTimeout(() => setApologyError(false), 2000);
    }
  };

  const isWarningMessage =
    emotion === "suspicious" ||
    emotion === "angry" ||
    message.includes("⚠️") ||
    message.includes("🚨");

  return (
    <>
      {activeWarning && (
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[10000] bg-black/90 backdrop-blur-md flex items-center justify-center p-6"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-[#050B1A] border border-red-500/30 rounded-3xl p-8 max-w-sm w-full text-center relative overflow-hidden shadow-[0_0_50px_rgba(239,68,68,0.2)]"
            >
              <div className="absolute top-0 left-0 right-0 h-1 bg-red-500 animate-pulse" />
              <div className="flex justify-center mb-6">
                <div className="w-24 h-24 relative flex items-center justify-center">
                  <HolographicOrbCore
                    stage={currentStage}
                    emotion="angry"
                    isSickOrLowTrust={false}
                    cursorPos={cursorPos}
                    isBlinking={isBlinking}
                    activeSkin={profile?.activeOrbSkin}
                    size="floating"
                  />
                </div>
              </div>
              <h2 className="text-2xl font-black text-red-500 uppercase tracking-wider mb-2">
                Suspicious Activity Alert
              </h2>
              <p className="text-neutral-300 font-medium mb-6 text-sm">
                {message ||
                  "Unusual speed ya button spamming detect hui hai. Honest workout karo warrior!"}
              </p>
              <div className="space-y-4">
                <p className="text-xs text-neutral-400 font-bold uppercase tracking-widest">
                  Type SORRY to Resume
                </p>
                <form onSubmit={handleApology}>
                  <input
                    type="text"
                    value={apology}
                    onChange={(e) => setApology(e.target.value)}
                    placeholder="SORRY"
                    className={`w-full bg-black/50 border ${
                      apologyError ? "border-red-500" : "border-neutral-800"
                    } rounded-xl px-4 py-4 text-center font-mono text-white uppercase outline-none focus:border-red-500 transition-colors mb-4`}
                  />
                  <button
                    type="submit"
                    className="w-full bg-red-500 text-white font-black uppercase tracking-widest py-4 rounded-xl active:scale-95 transition-transform"
                  >
                    Confirm & Resume
                  </button>
                </form>
              </div>
            </motion.div>
          </motion.div>
        </AnimatePresence>
      )}

      {/* OVERLAP-SAFE 3D QUANTUM PRISMATIC ORB
          Outer wrapper is strictly pointer-events-none so buttons behind it are NEVER blocked.
          Only the 62x62 Orb core hitbox has pointer-events-auto! */}
      <div
        data-genie-orb="true"
        className="fixed bottom-20 right-3.5 sm:bottom-7 sm:right-7 z-[9998] pointer-events-none flex items-end justify-end"
      >
        {!activeWarning && (
          <motion.div
            drag
            style={{
              x: dragX,
              y: dragY,
              width: 62,
              height: 62,
              willChange: "transform",
            }}
            dragConstraints={viewportBounds}
            dragElastic={0.08}
            dragMomentum={false}
            onDragStart={handleDragStart}
            onDragEnd={handleDragEnd}
            whileDrag={{ scale: 1.1 }}
            whileTap={{ scale: 0.92 }}
            onClick={handleOrbTap}
            className="cursor-grab active:cursor-grabbing pointer-events-auto rounded-full flex items-center justify-center relative touch-none select-none"
          >
            {/* Quick Radial Satellite Trigger Button */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                playSound("click");
                setIsRadialOpen((prev) => !prev);
              }}
              title="Toggle Quick Radial Actions"
              className={`pointer-events-auto absolute -top-0.5 -right-0.5 w-5 h-5 rounded-full border flex items-center justify-center z-40 transition-all cursor-pointer ${
                isRadialOpen
                  ? "bg-[#00F5D4] text-[#030712] border-white shadow-[0_0_12px_#00F5D4]"
                  : "bg-[#030712]/95 text-[#00F5D4] border-[#00F5D4]/60 hover:scale-110"
              }`}
            >
              <Zap className="w-2.5 h-2.5" />
            </button>

            {/* RADIAL ACTION MENU AROUND ORB */}
            <AnimatePresence>
              {isRadialOpen && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.6 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.6 }}
                  onClick={(e) => e.stopPropagation()}
                  className="absolute inset-0 pointer-events-none z-40"
                >
                  {/* Top-Left: +250ml Water */}
                  <button
                    type="button"
                    onClick={handleQuickWater}
                    title="Quick Log +250ml Water"
                    className="pointer-events-auto absolute -top-11 -left-11 w-10 h-10 rounded-full bg-[#07162c]/95 border border-sky-400/70 text-sky-300 shadow-[0_0_15px_rgba(56,189,248,0.45)] flex flex-col items-center justify-center hover:scale-110 active:scale-95 transition-transform cursor-pointer"
                  >
                    <Droplets className="w-3.5 h-3.5" />
                    <span className="text-[7px] font-mono font-black">+250ml</span>
                  </button>

                  {/* Top-Right: 60s Rest Timer */}
                  <button
                    type="button"
                    onClick={handleQuickTimer}
                    title="Toggle 60s Rest Timer"
                    className={`pointer-events-auto absolute -top-12 left-2 w-10 h-10 rounded-full border shadow-lg flex flex-col items-center justify-center hover:scale-110 active:scale-95 transition-transform cursor-pointer ${
                      restSecondsLeft !== null
                        ? "bg-amber-500 text-black border-amber-300 animate-pulse"
                        : "bg-[#07162c]/95 border-[#00F5D4]/70 text-[#00F5D4] shadow-[0_0_15px_rgba(0,245,212,0.45)]"
                    }`}
                  >
                    <Timer className="w-3.5 h-3.5" />
                    <span className="text-[7px] font-mono font-black">
                      {restSecondsLeft !== null ? `${restSecondsLeft}s` : "60s"}
                    </span>
                  </button>

                  {/* Bottom-Left: Gym Phonk Beat Synth */}
                  <button
                    type="button"
                    onClick={handleToggleBeats}
                    title="Toggle Offline Gym Phonk Beats"
                    className={`pointer-events-auto absolute top-2 -left-12 w-10 h-10 rounded-full border shadow-lg flex flex-col items-center justify-center hover:scale-110 active:scale-95 transition-transform cursor-pointer ${
                      beatPlaying
                        ? "bg-purple-500 text-white border-purple-300 shadow-[0_0_16px_rgba(168,85,247,0.65)] animate-pulse"
                        : "bg-[#07162c]/95 border-purple-400/70 text-purple-300"
                    }`}
                  >
                    <Music className="w-3.5 h-3.5" />
                    <span className="text-[7px] font-mono font-black">
                      {beatPlaying ? "ON" : "Beats"}
                    </span>
                  </button>

                  {/* Bottom-Right: Hands-Free Voice Mic */}
                  <button
                    type="button"
                    onClick={handleToggleVoiceMic}
                    title="Hands-Free Voice Workout Command"
                    className={`pointer-events-auto absolute -bottom-11 -left-8 w-10 h-10 rounded-full border shadow-lg flex flex-col items-center justify-center hover:scale-110 active:scale-95 transition-transform cursor-pointer ${
                      isVoiceListening
                        ? "bg-red-500 text-white border-red-300 animate-ping"
                        : "bg-[#07162c]/95 border-emerald-400/70 text-emerald-300"
                    }`}
                  >
                    {isVoiceListening ? (
                      <Mic className="w-3.5 h-3.5" />
                    ) : (
                      <MicOff className="w-3.5 h-3.5" />
                    )}
                    <span className="text-[7px] font-mono font-black">Voice</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Live Circular Rest Timer Ring around Orb */}
            {restSecondsLeft !== null && (
              <svg
                className="absolute -inset-1.5 w-[74px] h-[74px] -rotate-90 pointer-events-none z-30"
                viewBox="0 0 100 100"
              >
                <circle
                  cx="50"
                  cy="50"
                  r="46"
                  fill="none"
                  stroke="rgba(255,255,255,0.12)"
                  strokeWidth="3.5"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="46"
                  fill="none"
                  stroke="#00F5D4"
                  strokeWidth="4.5"
                  strokeLinecap="round"
                  strokeDasharray={289}
                  strokeDashoffset={289 - (289 * restSecondsLeft) / 60}
                  className="transition-all duration-500"
                />
              </svg>
            )}

            {/* Warning / Milestone Bubble (pointer-events-none so it never blocks clicks) */}
            <AnimatePresence>
              {message && (
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.9 }}
                  animate={{ opacity: 1, y: -6, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.9 }}
                  className={`absolute bottom-[68px] right-0 w-max max-w-[210px] backdrop-blur-xl border px-3 py-2 rounded-xl text-[10.5px] font-bold tracking-wide pointer-events-none z-50 shadow-2xl leading-snug ${
                    isWarningMessage
                      ? "bg-amber-950/95 border-amber-500/70 text-amber-100"
                      : "bg-[#030712]/95 border-[#00F5D4]/40 text-white"
                  }`}
                >
                  {message}
                </motion.div>
              )}
            </AnimatePresence>

            {/* 3D QUANTUM PRISMATIC ENERGY CORE WITH IDLE FLOATING & Z-ROTATION */}
            <motion.div
              className="w-[62px] h-[62px] relative flex items-center justify-center origin-center pointer-events-none"
              variants={orbFloatVariants}
              animate={
                isSickOrLowTrust
                  ? "sick"
                  : emotion === "focused" || !emotion
                  ? "idle"
                  : emotion
              }
              style={{ willChange: "transform" }}
            >
              <HolographicOrbCore
                stage={currentStage}
                emotion={emotion}
                isSickOrLowTrust={isSickOrLowTrust}
                cursorPos={cursorPos}
                isBlinking={isBlinking}
                activeSkin={profile?.activeOrbSkin}
                size="floating"
              />
            </motion.div>

            {/* Synchronized 3D Floor Projection Shadow beneath Orb */}
            <motion.div
              animate={{
                scaleX: [1, 0.72, 1, 1.08, 1],
                opacity: isSickOrLowTrust
                  ? [0.22, 0.12, 0.22, 0.26, 0.22]
                  : [0.6, 0.25, 0.6, 0.7, 0.6],
              }}
              transition={{
                duration: isSickOrLowTrust ? 6 : 4.2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="absolute -bottom-1.5 w-10 h-2.5 rounded-full pointer-events-none"
              style={{
                background: isSickOrLowTrust
                  ? "radial-gradient(ellipse at center, rgba(120,113,108,0.55) 0%, transparent 75%)"
                  : currentStage === 3
                  ? "radial-gradient(ellipse at center, rgba(255,183,3,0.75) 0%, rgba(0,245,212,0.35) 50%, transparent 75%)"
                  : "radial-gradient(ellipse at center, rgba(0,245,212,0.75) 0%, rgba(99,102,241,0.35) 50%, transparent 75%)",
                filter: "blur(3px)",
                willChange: "transform, opacity",
              }}
            />
          </motion.div>
        )}
      </div>

      {/* SLEEK 2-TAB CYBER COMMAND DECK */}
      <AnimatePresence>
        {isPanelOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsPanelOpen(false)}
              className="fixed inset-0 z-[9999] bg-black/75 backdrop-blur-md"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 26, stiffness: 240 }}
              className="fixed bottom-0 left-0 right-0 z-[10000] bg-[#04091A] border-t border-[#00F5D4]/35 rounded-t-3xl max-h-[82vh] overflow-y-auto shadow-[0_-15px_50px_rgba(0,245,212,0.16)]"
            >
              <div className="p-5 pb-20 space-y-4 max-w-md mx-auto relative">
                {/* Compact Header with 3D Quantum Core Preview */}
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-13 h-13 rounded-2xl bg-[#071026] border border-[#00F5D4]/35 relative flex items-center justify-center shrink-0 overflow-hidden shadow-[inset_0_0_15px_rgba(0,245,212,0.15)]">
                      <HolographicOrbCore
                        stage={currentStage}
                        emotion={emotion}
                        isSickOrLowTrust={isSickOrLowTrust}
                        cursorPos={cursorPos}
                        isBlinking={isBlinking}
                        activeSkin={profile?.activeOrbSkin}
                        size="header"
                      />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-lg font-black text-white uppercase tracking-wider">
                          GUARDIAN CORE
                        </h2>
                        <span
                          className={`text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full border ${
                            isSickOrLowTrust
                              ? "bg-stone-500/20 border-stone-500 text-stone-300"
                              : currentStage === 3
                              ? "bg-amber-500/20 border-amber-400 text-amber-300"
                              : "bg-[#00F5D4]/15 border-[#00F5D4]/40 text-[#00F5D4]"
                          }`}
                        >
                          {isSick
                            ? `Dormant (${daysInactive}d)`
                            : trustScore < 60
                            ? "Low Trust"
                            : stageData.badge}
                        </span>
                      </div>
                      <p className="text-[10px] text-neutral-400 font-mono">
                        {stageData.name} • Trust:{" "}
                        <strong
                          className={
                            trustScore < 60 ? "text-amber-400" : "text-[#00F5D4]"
                          }
                        >
                          {trustScore}%
                        </strong>{" "}
                        • Water: <strong className="text-sky-400">{todayWaterMl}ml</strong>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={handleResetOrbPosition}
                      title="Reset Floating Orb Position"
                      className="p-2 rounded-xl bg-white/5 border border-white/10 text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setIsPanelOpen(false)}
                      className="p-2 rounded-xl bg-white/5 border border-white/10 text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* 2-TAB SWITCHER (Quick HUD & Evolution | Trust Shield) */}
                <div className="grid grid-cols-2 gap-2 bg-black/50 p-1 rounded-2xl border border-white/10">
                  <button
                    onClick={() => setActiveTab("hud")}
                    className={`py-2.5 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      activeTab === "hud"
                        ? "bg-[#00F5D4] text-[#030712] shadow-[0_0_15px_rgba(0,245,212,0.35)]"
                        : "text-neutral-400 hover:text-white"
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" /> Quick HUD & Stage
                  </button>
                  <button
                    onClick={() => setActiveTab("shield")}
                    className={`py-2.5 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      activeTab === "shield"
                        ? "bg-[#6366F1] text-white shadow-[0_0_15px_rgba(99,102,241,0.35)]"
                        : "text-neutral-400 hover:text-white"
                    }`}
                  >
                    <Shield className="w-3.5 h-3.5" /> Trust Shield
                  </button>
                </div>

                {/* TAB 1: QUICK HUD, 3D STAGE EVOLUTION & COLLAPSIBLE RECOVERY STUDIO */}
                {activeTab === "hud" && (
                  <div className="space-y-4">
                    {/* Sickness / Low-Trust Alert Banner if active */}
                    {isSickOrLowTrust && (
                      <div className="bg-stone-900/80 border border-stone-500/40 rounded-2xl p-3.5 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2.5">
                          <Heart className="w-4 h-4 text-stone-400 animate-pulse shrink-0" />
                          <p className="text-xs text-stone-200 font-bold">
                            {isSick
                              ? `${daysInactive} days inactive — Core energy low! Complete 1 workout to recharge.`
                              : `Trust Score (${trustScore}%) low hai — Honest reps log karke Core glow wapas lao.`}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* 4-Action Cyber Tactical Grid */}
                    <div className="grid grid-cols-4 gap-2">
                      <button
                        type="button"
                        onClick={handleQuickWater}
                        className="p-3 rounded-2xl bg-sky-500/10 border border-sky-400/30 hover:border-sky-400/60 flex flex-col items-center justify-center gap-1 active:scale-95 transition-all cursor-pointer"
                      >
                        <Droplets className="w-4 h-4 text-sky-400" />
                        <span className="text-[10px] font-black text-white uppercase">
                          +250ml
                        </span>
                        <span className="text-[8px] font-mono text-sky-300">
                          {todayWaterMl}ml
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={handleQuickTimer}
                        className={`p-3 rounded-2xl border flex flex-col items-center justify-center gap-1 active:scale-95 transition-all cursor-pointer ${
                          restSecondsLeft !== null
                            ? "bg-amber-500/20 border-amber-400 text-amber-300"
                            : "bg-[#00F5D4]/10 border-[#00F5D4]/30 hover:border-[#00F5D4]/60 text-[#00F5D4]"
                        }`}
                      >
                        <Timer className="w-4 h-4" />
                        <span className="text-[10px] font-black text-white uppercase">
                          {restSecondsLeft !== null ? `${restSecondsLeft}s` : "60s Rest"}
                        </span>
                        <span className="text-[8px] font-mono text-neutral-400">
                          {restSecondsLeft !== null ? "Tap Reset" : "Start"}
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={handleToggleBeats}
                        className={`p-3 rounded-2xl border flex flex-col items-center justify-center gap-1 active:scale-95 transition-all cursor-pointer ${
                          beatPlaying
                            ? "bg-purple-500/25 border-purple-400 text-purple-200"
                            : "bg-purple-500/10 border-purple-400/30 hover:border-purple-400/60 text-purple-300"
                        }`}
                      >
                        <Music className="w-4 h-4" />
                        <span className="text-[10px] font-black text-white uppercase">
                          {beatPlaying ? "Beats ON" : "Phonk"}
                        </span>
                        <span className="text-[8px] font-mono text-purple-300">
                          Synth
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={handleToggleVoiceMic}
                        className={`p-3 rounded-2xl border flex flex-col items-center justify-center gap-1 active:scale-95 transition-all cursor-pointer ${
                          isVoiceListening
                            ? "bg-red-500/25 border-red-400 text-red-200 animate-pulse"
                            : "bg-emerald-500/10 border-emerald-400/30 hover:border-emerald-400/60 text-emerald-300"
                        }`}
                      >
                        {isVoiceListening ? (
                          <Mic className="w-4 h-4" />
                        ) : (
                          <MicOff className="w-4 h-4" />
                        )}
                        <span className="text-[10px] font-black text-white uppercase">
                          Voice
                        </span>
                        <span className="text-[8px] font-mono text-emerald-300">
                          {isVoiceListening ? "Listening" : "Command"}
                        </span>
                      </button>
                    </div>

                    {/* 3-Stage Holographic Core Evolution Bar */}
                    <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-black uppercase tracking-widest text-[#00F5D4] flex items-center gap-1.5">
                          <Crown className="w-3.5 h-3.5 text-amber-400" />
                          COMPANION EVOLUTION
                        </span>
                        <span className="text-[10px] font-mono text-neutral-400">
                          Stage {currentStage} / 3
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-2">
                        {([1, 2, 3] as const).map((st) => {
                          const stInfo = GENIE_STAGES[st];
                          const unlocked = currentStage >= st;
                          const isCurrent = currentStage === st;
                          return (
                            <div
                              key={st}
                              className={`p-2.5 rounded-xl border text-center transition-all ${
                                isCurrent
                                  ? "bg-[#00F5D4]/15 border-[#00F5D4] shadow-[0_0_15px_rgba(0,245,212,0.2)]"
                                  : unlocked
                                  ? "bg-white/5 border-white/20"
                                  : "bg-black/40 border-white/5 opacity-45"
                              }`}
                            >
                              <div className="text-[10px] font-black text-white uppercase">
                                {st === 1
                                  ? "Stage 1 • Baby"
                                  : st === 2
                                  ? "Stage 2 • Warrior"
                                  : "Stage 3 • Legend"}
                              </div>
                              <div className="text-[8px] font-mono text-[#00F5D4] mt-0.5">
                                {stInfo.minStreak}d Streak • {stInfo.minTrust}% Trust
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Collapsible Recovery, Beat Studio & Orb Skins */}
                    <div className="border border-white/10 rounded-2xl overflow-hidden bg-white/[0.02]">
                      <button
                        type="button"
                        onClick={() => setShowRecoveryStudio((prev) => !prev)}
                        className="w-full p-3.5 flex items-center justify-between text-left hover:bg-white/5 transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <Sliders className="w-4 h-4 text-[#6366F1]" />
                          <div>
                            <span className="text-xs font-black text-white uppercase tracking-wider block">
                              Recovery, Workout Beats & Themes
                            </span>
                            <span className="text-[10px] text-neutral-400">
                              Muscle Recovery, BPM Studio & Companion Themes
                            </span>
                          </div>
                        </div>
                        {showRecoveryStudio ? (
                          <ChevronUp className="w-4 h-4 text-neutral-400" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-neutral-400" />
                        )}
                      </button>

                      {showRecoveryStudio && (
                        <div className="p-3 border-t border-white/10">
                          <GlowUpAndRecoveryHub />
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* TAB 2: TRUST SHIELD & ANTI-CHEAT LOGS */}
                {activeTab === "shield" && (
                  <div className="space-y-4">
                    {(() => {
                      const score = profile?.integrityScore ?? 100;
                      const integrity = getIntegrityData(score);
                      const statusColor =
                        score >= 90
                          ? "text-[#00F5D4]"
                          : score >= 70
                          ? "text-sky-400"
                          : score >= 40
                          ? "text-amber-400"
                          : "text-rose-400";
                      return (
                        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3">
                          <div className="flex justify-between items-center">
                            <div>
                              <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400 block">
                                WORKOUT INTEGRITY SCORE
                              </span>
                              <span
                                className={`text-sm font-black uppercase ${statusColor}`}
                              >
                                {integrity.status}
                              </span>
                            </div>
                            <div className="text-right">
                              <span className="text-2xl font-black text-white font-mono">
                                {score}%
                              </span>
                              <span className="text-[10px] font-bold text-[#00F5D4] block">
                                {integrity.mood}
                              </span>
                            </div>
                          </div>
                          <div className="h-2 bg-black/60 rounded-full overflow-hidden p-0.5 border border-white/5">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-[#00F5D4] to-[#6366F1] transition-all duration-500"
                              style={{ width: `${score}%` }}
                            />
                          </div>
                          <p className="text-[11px] text-neutral-400 leading-relaxed">
                            {integrity.message}
                          </p>
                        </div>
                      );
                    })()}

                    <div className="bg-white/5 border border-white/10 rounded-2xl p-4">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-neutral-400 mb-2.5 flex items-center gap-1.5">
                        <Flame className="w-3.5 h-3.5 text-[#00F5D4]" /> Recent
                        Core Observations
                      </h4>
                      <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                        {observations.length === 0 ? (
                          <p className="text-neutral-500 text-xs italic">
                            Watching silently. Start a workout or challenge!
                          </p>
                        ) : (
                          observations.slice(0, 8).map((obs, idx) => (
                            <div
                              key={idx}
                              className="text-xs text-neutral-300 bg-black/40 border border-white/5 rounded-xl px-3 py-2 flex items-center gap-2"
                            >
                              <div className="w-1.5 h-1.5 rounded-full bg-[#00F5D4] shrink-0" />
                              <span>{obs}</span>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
