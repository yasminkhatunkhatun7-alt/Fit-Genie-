import React, { useState, useRef, useEffect } from "react";
import { 
  Send, 
  Sparkles, 
  Bot, 
  Activity, 
  ShieldAlert, 
  ShieldCheck, 
  RotateCcw, 
  Cpu,
  Box
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useAuth, getRankDetails } from "../context/AuthContext";
import { useGuardianContext } from "../context/GuardianContext";
import { generateGenieReply, UserContext, Intent } from "../utils/nlpEngine";
import { playSound } from "../utils/audio";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";

interface ChatMessage {
  id: string;
  sender: "user" | "genie";
  text: string;
  timestamp: number;
  intent?: Intent;
  isSuspicious?: boolean;
  detectedExercise?: {
    name: string;
    muscles: string[];
  };
}

const CHAT_STORAGE_KEY = "fitgenie_nlp_chat_history_v2";

const QUICK_MODULE_PROMPTS = [
  { label: "💪 Pushup 3D Form", query: "How to do pushups with perfect form" },
  { label: "🦵 Squat 3D Form", query: "Squats karne ka sahi form aur depth batao" },
  { label: "🥗 Diet & Macros", query: "Best diet plan for protein and calorie deficit" },
  { label: "🔥 Fat Loss", query: "Belly fat kam karne ke effective tips" },
  { label: "⚡ Muscle Gain", query: "Biceps aur chest ka size kaise badhayein" },
  { label: "🛡️ Trust & XP", query: "Mera Trust Score aur XP kaise badhega" },
];

function detectExerciseFromText(text: string): { name: string; muscles: string[] } | undefined {
  const lower = text.toLowerCase();
  if (lower.includes("pushup") || lower.includes("push-up") || lower.includes("push up") || lower.includes("chest")) {
    return { name: "Push Ups", muscles: ["Chest", "Triceps", "Shoulders"] };
  }
  if (lower.includes("squat") || lower.includes("leg") || lower.includes("quad")) {
    return { name: "Squats", muscles: ["Quads", "Glutes", "Hamstrings"] };
  }
  if (lower.includes("pullup") || lower.includes("pull-up") || lower.includes("pull up") || lower.includes("lat") || lower.includes("back")) {
    return { name: "Pull Ups", muscles: ["Back", "Biceps", "Lats"] };
  }
  if (lower.includes("plank") || lower.includes("abs") || lower.includes("core") || lower.includes("belly")) {
    return { name: "Plank Hold", muscles: ["Abs", "Core", "Obliques"] };
  }
  if (lower.includes("burpee") || lower.includes("cardio") || lower.includes("fat loss")) {
    return { name: "Burpees", muscles: ["Full Body", "Core", "Legs"] };
  }
  if (lower.includes("bicep") || lower.includes("curl") || lower.includes("arm")) {
    return { name: "Dumbbell Bicep Curls", muscles: ["Biceps", "Forearms"] };
  }
  if (lower.includes("dip") || lower.includes("tricep")) {
    return { name: "Parallel Bar Dips", muscles: ["Triceps", "Chest", "Shoulders"] };
  }
  return undefined;
}

// Typewriter component for Genie messages
function TypewriterText({ text, onComplete }: { text: string; onComplete?: () => void }) {
  const [displayedText, setDisplayedText] = useState("");
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    let index = 0;
    const charDelay = Math.max(8, Math.min(20, Math.floor(550 / text.length)));
    setDisplayedText("");

    const interval = setInterval(() => {
      if (!isMounted.current) {
        clearInterval(interval);
        return;
      }
      index++;
      setDisplayedText(text.slice(0, index));
      if (index >= text.length) {
        clearInterval(interval);
        if (onComplete) onComplete();
      }
    }, charDelay);

    return () => {
      isMounted.current = false;
      clearInterval(interval);
    };
  }, [text]);

  return (
    <span className="whitespace-pre-wrap leading-relaxed">
      {displayedText}
      {displayedText.length < text.length && (
        <span className="inline-block w-1.5 h-3.5 ml-1 bg-[#14F1E1] animate-pulse align-middle" />
      )}
    </span>
  );
}

export default function GenieChat() {
  const { profile } = useAuth();
  const { setEmotion } = useGuardianContext();
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(CHAT_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    const athleteName = profile?.name || profile?.username || "Athlete";
    const initialXP = profile?.xp || 0;
    return [
      {
        id: "init_1",
        sender: "genie",
        text: `Namaste ${athleteName}! Fit Genie Neural HUD active hai (XP: ${initialXP.toLocaleString()}). Diet, pushup/squat 3D form, hypertrophy, ya recovery—kisi bhi topic pe command do!`,
        timestamp: Date.now(),
        intent: "greetings"
      }
    ];
  });

  const [input, setInput] = useState("");
  const [genieStatus, setGenieStatus] = useState<"ONLINE" | "THINKING">("ONLINE");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(messages));
    } catch (e) {
      console.warn("Could not save chat history to localStorage", e);
    }
  }, [messages]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, genieStatus]);

  const userXP = Number(profile?.xp || 0);
  const rankInfo = getRankDetails(userXP);
  const userTrustScore = profile?.integrityScore !== undefined ? profile.integrityScore : 100;
  const userStreak = profile?.streak || 0;
  const athleteName = profile?.name || profile?.username || "Warrior";

  const userContext: UserContext = {
    name: athleteName,
    xp: userXP,
    rank: rankInfo.title || "Novice",
    level: profile?.level || (userXP < 500 ? "Beginner" : userXP < 2500 ? "Intermediate" : "Advanced"),
    streak: userStreak,
    trustScore: userTrustScore
  };

  const processUserQuery = (rawQuery: string) => {
    const trimmed = rawQuery.trim();
    if (!trimmed || genieStatus === "THINKING") return;

    playSound("click");

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      sender: "user",
      text: trimmed,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setGenieStatus("THINKING");
    setEmotion("thinking");

    setTimeout(() => {
      const response = generateGenieReply(trimmed, userContext);
      playSound("toggle");

      if (response.isSuspicious) {
        setEmotion("suspicious");
      } else {
        setEmotion("happy");
      }

      const detectedExercise = detectExerciseFromText(trimmed + " " + response.reply);

      const genieMsg: ChatMessage = {
        id: `genie_${Date.now()}`,
        sender: "genie",
        text: response.reply,
        timestamp: Date.now(),
        intent: response.intent,
        isSuspicious: response.isSuspicious,
        detectedExercise
      };

      setMessages(prev => [...prev, genieMsg]);
      setGenieStatus("ONLINE");
    }, 420);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    processUserQuery(input);
  };

  const handlePromptClick = (queryText: string) => {
    processUserQuery(queryText);
  };

  const handleResetChat = () => {
    playSound("click");
    const fresh: ChatMessage[] = [
      {
        id: `init_${Date.now()}`,
        sender: "genie",
        text: `Chat memory refreshed, ${athleteName}! Batao aaj kaunse workout ya 3D exercise form pe focus karna hai?`,
        timestamp: Date.now(),
        intent: "greetings"
      }
    ];
    setMessages(fresh);
    localStorage.removeItem(CHAT_STORAGE_KEY);
  };

  return (
    <div 
      className="flex flex-col h-[50vh] min-h-[420px] max-h-[60vh] rounded-2xl relative border border-[#14F1E1]/20 overflow-hidden select-none"
      style={{
        boxShadow: "0 0 30px rgba(20,241,225,0.08), inset 0 0 20px rgba(0,0,0,0.85)",
        background: "linear-gradient(to bottom, #050b14 0%, #020408 100%)",
      }}
    >
      {/* Cyber Header Bar */}
      <div 
        className="relative z-20 px-4 py-2.5 border-b border-[#14F1E1]/15 flex items-center justify-between backdrop-blur-md"
        style={{ background: "rgba(3, 7, 16, 0.85)" }}
      >
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className="w-7 h-7 rounded-lg bg-[#080d1a] border border-[#14F1E1]/30 flex items-center justify-center shadow-[0_0_10px_rgba(20,241,225,0.25)]">
              <Bot className="w-3.5 h-3.5 text-[#14F1E1]" />
            </div>
            <span 
              className={`absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full ${
                genieStatus === "THINKING"
                  ? "bg-amber-400 animate-ping"
                  : "bg-emerald-400 shadow-[0_0_6px_#34d399]"
              }`} 
            />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-black uppercase tracking-wider text-white flex items-center gap-1 font-mono">
                <Cpu className="w-3 h-3 text-[#14F1E1]" /> NEURAL COACH 3D
              </span>
              <span 
                className={`text-[8px] font-black tracking-widest px-1.5 py-0.5 rounded-full uppercase border font-mono ${
                  genieStatus === "THINKING"
                    ? "bg-amber-500/10 border-amber-500/40 text-amber-300 animate-pulse"
                    : "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                }`}
              >
                {genieStatus === "THINKING" ? "SYNCING..." : "READY"}
              </span>
            </div>
            <p className="text-[8.5px] text-[#A89F8C] font-mono tracking-tight flex items-center gap-1.5">
              <span>XP: <strong className="text-[#14F1E1]">{userXP.toLocaleString()}</strong></span>
              <span>•</span>
              <span className="flex items-center gap-0.5">
                {userTrustScore < 80 ? (
                  <span className="text-amber-400 font-bold flex items-center gap-0.5">
                    <ShieldAlert className="w-2.5 h-2.5" /> {userTrustScore}%
                  </span>
                ) : (
                  <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                    <ShieldCheck className="w-2.5 h-2.5" /> {userTrustScore}%
                  </span>
                )}
              </span>
            </p>
          </div>
        </div>

        <button
          onClick={handleResetChat}
          title="Reset conversation"
          className="p-1.5 rounded-lg bg-white/5 border border-white/10 hover:border-[#14F1E1]/40 text-zinc-400 hover:text-white transition-all active:scale-95 text-[9px] font-mono flex items-center gap-1 cursor-pointer"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto px-3.5 py-4 space-y-4 custom-scrollbar relative z-10 scroll-smooth">
        <AnimatePresence initial={false}>
          {messages.map((m, index) => {
            const isLastMessage = index === messages.length - 1;
            const isLatestGenie = m.sender === "genie" && isLastMessage;
            const exPreview = m.detectedExercise || (m.sender === "genie" ? detectExerciseFromText(m.text) : undefined);

            return (
              <motion.div 
                key={m.id} 
                initial={{ opacity: 0, y: 12, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ type: "spring", stiffness: 450, damping: 28 }}
                className={`flex ${m.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                {m.sender === "genie" && (
                  <div 
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0 mt-auto relative"
                    style={{
                      background: m.isSuspicious ? "#190b0b" : "#080c16",
                      border: m.isSuspicious 
                        ? "1px solid rgba(239,68,68,0.4)" 
                        : "1px solid rgba(20,241,225,0.3)"
                    }}
                  >
                    {m.isSuspicious ? (
                      <ShieldAlert className="w-3.5 h-3.5 text-amber-400 relative z-10" />
                    ) : (
                      <Bot className="w-3.5 h-3.5 text-[#14F1E1] relative z-10" />
                    )}
                  </div>
                )}
                
                <div className={`flex flex-col relative z-10 max-w-[88%] ${m.sender === "user" ? "items-end" : "items-start"}`}>
                  <div className="flex items-center gap-1.5 mb-1 mx-1">
                    <span className="text-[8.5px] font-black uppercase tracking-[0.18em] font-mono text-[#14F1E1]/70">
                      {m.sender === "user" ? athleteName : "GENIE AI"}
                    </span>
                    {exPreview && m.sender === "genie" && (
                      <span className="text-[7.5px] px-1.5 py-0.5 rounded bg-[#14F1E1]/15 text-[#14F1E1] font-mono font-bold uppercase flex items-center gap-1">
                        <Box className="w-2.5 h-2.5" /> 3D HOLOGRAM
                      </span>
                    )}
                  </div>

                  <div 
                    className={`px-3.5 py-2.5 rounded-2xl text-[12.5px] sm:text-[13.5px] leading-relaxed relative overflow-hidden backdrop-blur-md ${
                      m.sender === "user" 
                        ? "text-[#050B1A] font-black rounded-br-sm shadow-[0_4px_14px_rgba(20,241,225,0.2)]" 
                        : m.isSuspicious
                          ? "text-amber-100 rounded-bl-sm font-medium border border-amber-500/30 bg-[#160c0c]/90"
                          : "text-white rounded-bl-sm font-medium tracking-wide border border-[#14F1E1]/15 bg-[#090f1d]/85"
                    }`}
                    style={
                      m.sender === "user"
                        ? { background: "linear-gradient(135deg, #14F1E1 0%, #00B4D8 100%)" }
                        : undefined
                    }
                  >
                    {m.sender === "genie" && isLatestGenie ? (
                      <TypewriterText text={m.text} />
                    ) : (
                      <span className="relative z-10 whitespace-pre-wrap">{m.text}</span>
                    )}

                    {/* Inline 3D Hologram Exercise Preview inside Genie Reply */}
                    {m.sender === "genie" && exPreview && (
                      <div className="mt-3 pt-2.5 border-t border-[#14F1E1]/20">
                        <Exercise3DCharacterLoop
                          exerciseName={exPreview.name}
                          targetMuscles={exPreview.muscles}
                          difficulty="intermediate"
                          heightClass="h-[185px]"
                          showControls={true}
                        />
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
          
          {genieStatus === "THINKING" && (
            <motion.div 
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex justify-start items-center gap-2"
            >
              <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 bg-[#080c16] border border-[#14F1E1]/40">
                <Activity className="w-3.5 h-3.5 text-[#14F1E1] animate-spin" />
              </div>
              <div className="px-3.5 py-2 rounded-2xl rounded-bl-sm flex gap-1.5 items-center border border-[#14F1E1]/20 bg-[#090f1d]/90">
                <span className="text-[10px] font-mono text-[#14F1E1] font-bold">
                  Synthesizing
                </span>
                <span className="w-1.5 h-1.5 bg-[#14F1E1] rounded-full animate-bounce" />
                <span className="w-1.5 h-1.5 bg-[#14F1E1] rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-1.5 h-1.5 bg-[#14F1E1] rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={endRef} className="h-1" />
      </div>

      {/* Cyber Input & Module Chips Area */}
      <div 
        className="relative z-20 p-2.5 sm:p-3 border-t border-[#14F1E1]/15 backdrop-blur-xl"
        style={{ background: "rgba(3, 6, 14, 0.92)" }}
      >
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-1 no-scrollbar scroll-smooth">
          <span className="text-[9px] font-black uppercase tracking-widest text-[#14F1E1] flex items-center gap-1 flex-shrink-0 pl-1 font-mono">
            <Sparkles className="w-3 h-3" /> Quick
          </span>
          {QUICK_MODULE_PROMPTS.map((qp, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handlePromptClick(qp.query)}
              disabled={genieStatus === "THINKING"}
              className="flex-shrink-0 text-[9.5px] font-bold text-[#14F1E1] hover:text-white px-2.5 py-1 transition-all active:scale-95 uppercase tracking-wider rounded-lg border border-[#14F1E1]/25 bg-[#14F1E1]/5 cursor-pointer disabled:opacity-50"
            >
              {qp.label}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="flex gap-2 relative">
          <input 
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            disabled={genieStatus === "THINKING"}
            placeholder="Ask diet, pushup 3D form, ya workout..."
            className="flex-1 rounded-xl pl-3.5 pr-12 py-2.5 text-xs text-white focus:outline-none transition-all placeholder:text-neutral-500 font-medium bg-black/70 border border-[#14F1E1]/25"
          />
          <button 
            type="submit" 
            disabled={!input.trim() || genieStatus === "THINKING"}
            className="absolute right-1.5 top-1.5 bottom-1.5 aspect-square rounded-lg flex items-center justify-center transition-all disabled:opacity-30 active:scale-90 cursor-pointer"
            style={{
              background: "linear-gradient(135deg, #14F1E1 0%, #00B4D8 100%)",
            }}
          >
            <Send className="w-3.5 h-3.5 text-[#050B1A]" />
          </button>
        </form>
      </div>
    </div>
  );
}