import { useEffect } from 'react';

export default function CompletionValidationModal({ onValid }: any) {
  useEffect(() => {
    onValid();
  }, [onValid]);
  return null;
}
