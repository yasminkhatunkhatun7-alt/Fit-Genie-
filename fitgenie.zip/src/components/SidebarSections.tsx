import { Calculator, Droplet, Footprints, Target, Crown, Bell, HelpCircle, Share2, Star, Shield, Plus, Minus, Scale, Check, Info, Award, AlertCircle, Copy, Zap, Heart, Activity, TrendingDown, TrendingUp } from "lucide-react";
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";

import { playSound } from "../utils/audio";
import { useAuth } from "../context/AuthContext";
import { handleSubscription } from "./PremiumGuard";
import { db } from "../lib/firebase";
import { collection, query, where, getDocs, orderBy, limit, doc, updateDoc, setDoc, getDoc } from "firebase/firestore";

// ==========================================
// 1. DYNAMIC NUTRITIVE CALORIE CALCULATOR
// ==========================================
export function CalorieCalculator() {
  const { profile } = useAuth();
  const [weight, setWeight] = useState(() => (profile?.weight ? String(profile.weight) : ""));
  const [height, setHeight] = useState(() => (profile?.height ? String(profile.height) : ""));
  const [age, setAge] = useState(() => (profile?.age ? String(profile.age) : "22"));
  const [gender, setGender] = useState(() => (profile?.gender ? profile.gender.toLowerCase() : "male"));
  const [activity, setActivity] = useState("1.55");
  const [results, setResults] = useState<{ maint: number; cut: number; bulk: number; proteinGoal: number; waterGoal: number } | null>(null);
  const [syncedNotice, setSyncedNotice] = useState(false);

  useEffect(() => {
    if (profile?.weight && !weight) setWeight(String(profile.weight));
    if (profile?.height && !height) setHeight(String(profile.height));
    if (profile?.age && !age) setAge(String(profile.age));
  }, [profile]);

  const calculateCal = () => {
    playSound("click");
    if (!weight || !height || !age) return;
    const w = parseFloat(weight);
    const h = parseFloat(height);
    const a = parseFloat(age);
    
    let bmr = 0;
    if (gender === "male") {
      bmr = 10 * w + 6.25 * h - 5 * a + 5;
    } else {
      bmr = 10 * w + 6.25 * h - 5 * a - 161;
    }
    
    const maint = Math.round(bmr * parseFloat(activity));
    const proteinGoal = Math.round(w * 1.8);
    const waterGoal = Math.min(4500, Math.max(2500, Math.round(w * 45)));
    setResults({
      maint,
      cut: maint - 500,
      bulk: maint + 300,
      proteinGoal,
      waterGoal,
    });
    setSyncedNotice(false);
  };

  const syncToDailyTargets = () => {
    if (!results) return;
    playSound("toggle");
    try {
      localStorage.setItem(
        "fitgenie_nutrition_goals",
        JSON.stringify({
          proteinGoal: results.proteinGoal,
          waterGoal: results.waterGoal,
          caloriesGoal: results.maint,
        })
      );
      setSyncedNotice(true);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="bg-[#050B1A] border border-[#14F1E1]/20 p-6 md:p-8 rounded-[2rem] text-left max-w-2xl mx-auto shadow-[0_0_40px_rgba(20,241,225,0.05)] relative select-none">
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#14F1E1]/5 rounded-full blur-[80px] pointer-events-none" />
      
      <div className="relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#14F1E1]/10 border border-[#14F1E1]/30 rounded-full mb-3">
          <Calculator className="w-3.5 h-3.5 text-[#14F1E1]" />
          <span className="text-[9px] font-black uppercase tracking-[0.2em] text-[#14F1E1]">Nutritional Algorithms</span>
        </div>
        
        <h2 className="text-2xl font-black text-white uppercase tracking-tight flex items-center gap-2">
          Macro <span className="text-[#14F1E1]">Calculator</span>
        </h2>
        <p className="text-neutral-400 text-xs font-medium mt-1 mb-6">
          Precision metabolic targeting based on advanced biometric telemetry.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase text-neutral-400 tracking-widest ml-1">Gender Profiling</label>
            <select 
              value={gender} 
              onChange={(e) => setGender(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-sm font-bold text-white focus:outline-none focus:border-[#14F1E1]/50 appearance-none focus:ring-1 focus:ring-[#14F1E1]/50"
            >
              <option value="male">Male Physiology</option>
              <option value="female">Female Physiology</option>
            </select>
          </div>
          
          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase text-neutral-400 tracking-widest ml-1">Kinetic Load</label>
            <select 
              value={activity} 
              onChange={(e) => setActivity(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-sm font-bold text-white focus:outline-none focus:border-[#14F1E1]/50 appearance-none focus:ring-1 focus:ring-[#14F1E1]/50"
            >
              <option value="1.2">Sedentary (No Training)</option>
              <option value="1.375">Light (1-3 days/wk)</option>
              <option value="1.55">Moderate (3-5 days/wk)</option>
              <option value="1.725">Active (6-7 days/wk)</option>
              <option value="1.9">Elite (2x Daily)</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase text-neutral-400 tracking-widest ml-1">Mass (KG)</label>
            <input 
              type="number" placeholder="0.0" 
              value={weight} onChange={(e) => setWeight(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-sm font-bold text-white placeholder:text-neutral-600 focus:outline-none focus:border-[#14F1E1]/50 focus:ring-1 focus:ring-[#14F1E1]/50" 
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase text-neutral-400 tracking-widest ml-1">Vertical (CM)</label>
            <input 
              type="number" placeholder="0.0" 
              value={height} onChange={(e) => setHeight(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-sm font-bold text-white placeholder:text-neutral-600 focus:outline-none focus:border-[#14F1E1]/50 focus:ring-1 focus:ring-[#14F1E1]/50" 
            />
          </div>
          <div className="space-y-1.5 md:col-span-2">
            <label className="text-[10px] font-black uppercase text-neutral-400 tracking-widest ml-1">Chronology (Years)</label>
            <input 
              type="number" placeholder="Age" 
              value={age} onChange={(e) => setAge(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-sm font-bold text-white placeholder:text-neutral-600 focus:outline-none focus:border-[#14F1E1]/50 focus:ring-1 focus:ring-[#14F1E1]/50" 
            />
          </div>
        </div>

        <button 
          onClick={calculateCal}
          className="w-full py-4 mt-6 bg-gradient-to-r from-[#14F1E1] to-[#1DE9B6] text-black rounded-xl text-sm font-black uppercase tracking-[0.2em] hover:scale-[1.02] active:scale-95 transition-all shadow-[0_0_20px_rgba(20,241,225,0.4)] flex items-center justify-center gap-2"
        >
          <Activity className="w-5 h-5" /> Calculate Telemetry
        </button>

        {results && (
          <div className="mt-8 space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-5 text-center flex flex-col items-center justify-center shadow-inner relative overflow-hidden group">
                <div className="absolute inset-0 bg-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                <TrendingDown className="w-6 h-6 text-blue-400 mb-2 relative z-10" />
                <span className="text-[10px] font-black text-neutral-400 uppercase tracking-widest mb-1 relative z-10">Cutting Protocol</span>
                <span className="text-2xl font-black text-blue-400 relative z-10">{results.cut} <span className="text-[10px] text-blue-400/50">KCAL</span></span>
              </div>
              
              <div className="bg-[#14F1E1]/10 border border-[#14F1E1]/30 rounded-2xl p-5 text-center flex flex-col items-center justify-center shadow-[0_0_15px_rgba(20,241,225,0.1)] relative overflow-hidden transform md:scale-105 z-10">
                <div className="absolute top-0 right-0 w-16 h-16 bg-[#14F1E1]/20 rounded-full blur-xl -mr-8 -mt-8" />
                <Activity className="w-6 h-6 text-[#14F1E1] mb-2 relative z-10" />
                <span className="text-[10px] font-black text-[#14F1E1] uppercase tracking-widest mb-1 relative z-10">Maintenance</span>
                <span className="text-3xl font-black text-white relative z-10">{results.maint} <span className="text-[10px] text-[#14F1E1]/50">KCAL</span></span>
              </div>

              <div className="bg-white/5 border border-white/10 rounded-2xl p-5 text-center flex flex-col items-center justify-center shadow-inner relative overflow-hidden group">
                <div className="absolute inset-0 bg-rose-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                <TrendingUp className="w-6 h-6 text-rose-400 mb-2 relative z-10" />
                <span className="text-[10px] font-black text-neutral-400 uppercase tracking-widest mb-1 relative z-10">Bulking Protocol</span>
                <span className="text-2xl font-black text-rose-400 relative z-10">{results.bulk} <span className="text-[10px] text-rose-400/50">KCAL</span></span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#0A1328] border border-[#14F1E1]/30 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-[#14F1E1]">
                  Recommended Bio-Targets: {results.proteinGoal}g Protein • {results.waterGoal}ml Water
                </p>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  Sync these calculated macro & hydration goals directly to your Daily Nutrition Log.
                </p>
              </div>
              <button
                onClick={syncToDailyTargets}
                className="px-4 py-2.5 rounded-xl bg-[#B66DFF] hover:bg-[#A352FF] text-white text-[10px] font-black uppercase tracking-widest shrink-0 transition-all cursor-pointer shadow-[0_0_15px_rgba(182,109,255,0.4)]"
              >
                {syncedNotice ? "✅ Synced to Daily Targets!" : "⚡ Sync to My Daily Targets"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ==========================================
// 2. ADVANCED LIQUID WATER TRACKER
// ==========================================
export function WaterTrackerSection() {
  const { profile } = useAuth();
  const [errorAlert, setErrorAlert] = useState("");
  const [waterGoal, setWaterGoal] = useState(() => {
    try {
      const saved = localStorage.getItem("fitgenie_nutrition_goals");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.waterGoal) return parsed.waterGoal;
      }
    } catch {}
    return 3000;
  });

  // Sync waterGoal with profile.waterIntakeGoal if it exists
  useEffect(() => {
    if (profile?.waterIntakeGoal) {
      setWaterGoal(profile.waterIntakeGoal);
    }
  }, [profile]);

  const [waterIntake, setWaterIntake] = useState(() => {
    try {
      const today = new Date().toISOString().split("T")[0];
      const saved = localStorage.getItem("fitgenie_nutrition_logs");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed[today] && parsed[today].water !== undefined) {
          return parsed[today].water;
        }
      }
    } catch {}
    return 0;
  });

  useEffect(() => {
    try {
      const today = new Date().toISOString().split("T")[0];
      const savedLogs = localStorage.getItem("fitgenie_nutrition_logs");
      const logs = savedLogs ? JSON.parse(savedLogs) : {};
      
      if (!logs[today]) {
        logs[today] = { protein: 0, water: 0 };
      }
      logs[today].water = waterIntake;
      localStorage.setItem("fitgenie_nutrition_logs", JSON.stringify(logs));
    } catch {}
  }, [waterIntake]);

  const addWater = (amount: number) => {
    setWaterIntake(prev => {
      const nextWater = prev + amount;
      if (nextWater > 5000) {
        playSound("timer_pause");
        setErrorAlert("mujhe vishwas nahi ho raha hai ki aapne isse jyada consum kiya hoga");
        setTimeout(() => setErrorAlert(""), 4000);
        return prev;
      }
      playSound("click");
      return nextWater;
    });
  };

  const pct = Math.min(100, Math.round((waterIntake / waterGoal) * 100)) || 0;

  return (
    <div className="bg-[#050B1A] border border-[#14F1E1]/25 p-6 rounded-3xl text-left max-w-md mx-auto shadow-[0_0_35px_rgba(20,241,225,0.08)] relative select-none">
      <div className="absolute top-0 right-0 w-28 h-28 bg-[#14F1E1]/10 rounded-full blur-2xl pointer-events-none" />
      
      <AnimatePresence>
        {errorAlert && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-4 left-4 right-4 z-50 bg-red-500/90 backdrop-blur text-white px-4 py-3 rounded-xl text-xs font-black uppercase tracking-wider shadow-lg border border-red-400 text-center leading-relaxed"
          >
            {errorAlert}
          </motion.div>
        )}
      </AnimatePresence>

      <div>
        <span className="text-[10px] font-black uppercase text-[#14F1E1] tracking-widest bg-[#14F1E1]/10 px-2.5 py-1 rounded-md border border-[#14F1E1]/30">
          💧 CELLULAR HYDRATION TELEMETRY
        </span>
        <h2 className="text-xl font-black text-white mt-2 flex items-center gap-2">
          <Droplet className="w-5 h-5 text-[#14F1E1]" />
          CYBER WATER TRACKER
        </h2>
        <p className="text-zinc-400 text-[10px] uppercase font-bold font-mono mt-0.5">
          Real-time plasma & cellular hydration reservoir
        </p>
      </div>

      {/* Interactive 3D Holographic Hydro-Chamber Column */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-center pt-5">
        {/* 3D Glass Hydro-Chamber Left */}
        <div className="sm:col-span-5 flex flex-col items-center">
          <div className="relative w-32 h-48 flex items-center justify-center">
            {/* Outer Ambient Cyan Aura */}
            <div
              className="absolute inset-2 rounded-full blur-2xl pointer-events-none transition-opacity duration-500"
              style={{
                background: "radial-gradient(circle, rgba(20,241,225,0.32) 0%, rgba(182,109,255,0.12) 60%, transparent 100%)",
                opacity: Math.max(0.25, pct / 100),
              }}
            />

            {/* 3D Cylindrical Glass Chamber */}
            <div className="relative w-28 h-44 rounded-[28px] bg-gradient-to-r from-[#071126] via-[#0B1B3D] to-[#050C1C] border-2 border-[#14F1E1]/45 overflow-hidden shadow-[0_15px_35px_rgba(0,0,0,0.85),inset_0_0_22px_rgba(20,241,225,0.2)] flex items-end">
              {/* Top 3D Elliptical Metallic Cap Ring */}
              <div className="absolute top-1.5 left-2 right-2 h-3.5 rounded-full border border-[#14F1E1]/45 bg-[#14F1E1]/10 z-20 pointer-events-none" />

              {/* Left Glass Specular Highlight Strip */}
              <div className="absolute top-3 bottom-3 left-2.5 w-2 rounded-full bg-gradient-to-b from-white/30 via-white/10 to-transparent z-20 pointer-events-none" />

              {/* Measurement Tick Marks */}
              <div className="absolute right-2 top-6 bottom-6 flex flex-col justify-between z-20 pointer-events-none opacity-60">
                {[100, 75, 50, 25].map((mark) => (
                  <div key={mark} className="flex items-center gap-1 justify-end">
                    <span className="text-[6.5px] font-mono font-bold text-[#14F1E1]">{mark}%</span>
                    <span className="w-2 h-[1px] bg-[#14F1E1]" />
                  </div>
                ))}
              </div>

              {/* Dynamic 3D Liquid Column */}
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: `${pct}%` }}
                transition={{ duration: 0.7, ease: "easeOut" }}
                className="w-full bg-gradient-to-t from-[#0369A1] via-[#06B6D4] to-[#14F1E1] relative flex items-center justify-center shadow-[0_-6px_20px_rgba(20,241,225,0.55),inset_0_4px_15px_rgba(255,255,255,0.45)]"
              >
                {/* 3D Meniscus Wave Top Rim */}
                <div className="absolute -top-2 left-0 right-0 h-4 rounded-full bg-[#72F7ED]/70 blur-[1px] border-t border-white/70" />

                {/* Rising Plasma Bubbles */}
                {pct > 5 && (
                  <div className="absolute inset-0 overflow-hidden pointer-events-none">
                    <motion.span
                      animate={{ y: [0, -90], opacity: [0.8, 0] }}
                      transition={{ duration: 2.4, repeat: Infinity, ease: "easeOut" }}
                      className="absolute bottom-2 left-4 w-2 h-2 rounded-full bg-white/80 shadow-[0_0_6px_#fff]"
                    />
                    <motion.span
                      animate={{ y: [0, -110], opacity: [0.7, 0] }}
                      transition={{ duration: 3.1, repeat: Infinity, delay: 0.7, ease: "easeOut" }}
                      className="absolute bottom-4 right-6 w-2.5 h-2.5 rounded-full bg-white/70 shadow-[0_0_8px_#fff]"
                    />
                    <motion.span
                      animate={{ y: [0, -75], opacity: [0.85, 0] }}
                      transition={{ duration: 1.9, repeat: Infinity, delay: 1.2, ease: "easeOut" }}
                      className="absolute bottom-3 left-11 w-1.5 h-1.5 rounded-full bg-white/90"
                    />
                  </div>
                )}
              </motion.div>

              {/* Bottom 3D Base Ring */}
              <div className="absolute bottom-1 left-2 right-2 h-3 rounded-full border border-[#14F1E1]/35 bg-black/30 z-20 pointer-events-none" />

              {/* Glowing Telemetry Overlay */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none z-30 drop-shadow-[0_2px_10px_rgba(0,0,0,0.9)]">
                <span className="text-2xl font-black font-mono text-white leading-none">
                  {pct}%
                </span>
                <span className="text-[8px] font-black uppercase text-[#14F1E1] font-mono tracking-widest mt-1 px-1.5 py-0.5 rounded bg-black/65 border border-[#14F1E1]/30">
                  {waterIntake} / {waterGoal} ml
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Logger Controls Right */}
        <div className="sm:col-span-7 space-y-3.5">
          <div className="bg-[#0A1128] p-3 rounded-2xl border border-[#14F1E1]/20 text-left">
            <span className="block text-[8px] uppercase text-[#14F1E1] font-bold font-mono">Current Bio-Status</span>
            <span className="block text-xs font-black text-white mt-1 uppercase">
              {pct >= 100 ? "🎉 PEAK CELLULAR HYDRATION!" : "💧 Hydration Reservoir Active"}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => addWater(250)}
              className="bg-[#0A1128] border border-[#14F1E1]/30 hover:bg-[#14F1E1]/15 p-3 rounded-xl transition-all cursor-pointer font-black text-[10.5px] uppercase tracking-wide text-[#14F1E1]"
            >
              +250 ml (Glass)
            </button>
            <button
              onClick={() => addWater(500)}
              className="bg-[#0A1128] border border-[#B66DFF]/30 hover:bg-[#B66DFF]/15 p-3 rounded-xl transition-all cursor-pointer font-black text-[10.5px] uppercase tracking-wide text-[#B66DFF]"
            >
              +500 ml (Shaker)
            </button>
          </div>

          <button
            onClick={() => { playSound("click"); setWaterIntake(0); }}
            className="w-full bg-[#0A1128] border border-white/10 hover:border-rose-500/40 text-[10px] font-black uppercase tracking-widest py-2.5 rounded-xl text-zinc-400 hover:text-rose-400 transition-all cursor-pointer"
          >
            Reset Hydration Counter
          </button>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 3. DIAL STEP TRACKER & SIMULATOR
// ==========================================
export function StepCounterSection() {
  const [steps, setSteps] = useState(() => {
    try {
      const saved = localStorage.getItem("fitgenie_steps_today");
      return saved ? parseInt(saved) : 0;
    } catch {
      return 0;
    }
  });

  const stepGoal = 10000;

  useEffect(() => {
    localStorage.setItem("fitgenie_steps_today", String(steps));
  }, [steps]);

  const addSteps = (amount: number) => {
    playSound("click");
    setSteps(prev => Math.max(0, prev + amount));
  };

  const pct = Math.min(100, Math.round((steps / stepGoal) * 100)) || 0;
  const distanceKm = (steps * 0.00075).toFixed(2);
  const kcalBurned = Math.round(steps * 0.04);

  return (
    <div className="bg-[#050B1A] border border-[#14F1E1]/25 p-6 rounded-3xl text-left max-w-md mx-auto shadow-[0_0_35px_rgba(20,241,225,0.08)] relative select-none">
      <div className="absolute top-0 right-0 w-28 h-28 bg-[#14F1E1]/10 rounded-full blur-2xl pointer-events-none" />

      <div>
        <span className="text-[10px] font-black uppercase text-[#14F1E1] tracking-widest bg-[#14F1E1]/10 px-2.5 py-1 rounded-md border border-[#14F1E1]/30">
          👟 KINETIC PEDOMETER HUD
        </span>
        <h2 className="text-xl font-black text-white mt-2 flex items-center gap-2">
          <Footprints className="w-5 h-5 text-[#14F1E1] animate-bounce" />
          ACTIVE STEP TELEMETRY
        </h2>
        <p className="text-zinc-400 text-[10px] uppercase font-bold font-mono mt-0.5">
          Achieve 10,000 daily steps to maximize NEAT fat oxidation
        </p>
      </div>

      <div className="flex flex-col items-center pt-4 space-y-5">
        {/* Glowing Dial Meter Ring */}
        <div className="relative w-44 h-44 rounded-full border-4 border-[#0A1128] flex flex-col items-center justify-center p-3 shadow-[0_0_25px_rgba(20,241,225,0.12)]">
          <svg className="absolute inset-0 w-full h-full transform -rotate-90">
            <circle
              cx="88"
              cy="88"
              r="80"
              stroke="#14F1E1"
              strokeWidth="6"
              fill="transparent"
              strokeDasharray="502"
              strokeDashoffset={502 - (502 * pct / 100)}
              className="transition-all duration-1000 ease-out"
            />
          </svg>

          <div className="text-center relative z-10">
            <Footprints className="w-6 h-6 text-[#14F1E1] mx-auto animate-pulse" />
            <span className="block text-3xl font-black text-white mt-1 leading-none font-mono">
              {steps.toLocaleString()}
            </span>
            <span className="block text-[8px] font-black uppercase text-zinc-400 tracking-widest mt-1">
              GOAL: {stepGoal.toLocaleString()}
            </span>
            <span className="inline-block mt-1 bg-[#14F1E1]/15 border border-[#14F1E1]/30 text-[#14F1E1] text-[8.5px] font-black font-mono px-2 py-0.5 rounded-full">
              {pct}% Reached
            </span>
          </div>
        </div>

        {/* Quick Manual Step Loggers */}
        <div className="w-full space-y-2">
          <span className="block text-[9px] font-black uppercase tracking-widest text-[#B66DFF] text-center">
            ⚡ Quick Walk / Cardio Step Logger
          </span>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => addSteps(500)}
              className="py-2.5 px-2 rounded-xl bg-[#0A1128] border border-[#14F1E1]/30 hover:bg-[#14F1E1]/15 text-[#14F1E1] text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer"
            >
              +500 Steps
            </button>
            <button
              onClick={() => addSteps(1000)}
              className="py-2.5 px-2 rounded-xl bg-[#0A1128] border border-[#14F1E1]/30 hover:bg-[#14F1E1]/15 text-[#14F1E1] text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer"
            >
              +1,000 Steps
            </button>
            <button
              onClick={() => addSteps(2500)}
              className="py-2.5 px-2 rounded-xl bg-[#0A1128] border border-[#B66DFF]/30 hover:bg-[#B66DFF]/15 text-[#B66DFF] text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer"
            >
              +2,500 Steps
            </button>
          </div>
        </div>

        {/* Grid data specs */}
        <div className="grid grid-cols-2 gap-4 w-full">
          <div className="bg-[#0A1128] p-3 rounded-2xl border border-[#14F1E1]/20 text-left">
            <span className="block text-[8px] uppercase text-zinc-400 font-bold font-mono">Distance Traveled</span>
            <span className="block text-sm font-black text-[#14F1E1] mt-1 uppercase font-mono">{distanceKm} KM</span>
          </div>
          <div className="bg-[#0A1128] p-3 rounded-2xl border border-[#B66DFF]/20 text-left">
            <span className="block text-[8px] uppercase text-zinc-400 font-bold font-mono">Active Energy Burn</span>
            <span className="block text-sm font-black text-[#B66DFF] mt-1 uppercase font-mono">{kcalBurned} KCAL</span>
          </div>
        </div>

        <button
          onClick={() => { playSound("click"); setSteps(0); }}
          className="w-full py-2 rounded-xl bg-[#0A1128] border border-white/10 hover:border-rose-500/40 text-[9px] font-black uppercase tracking-widest text-zinc-400 hover:text-rose-400 transition-all cursor-pointer"
        >
          Reset Daily Step Counter
        </button>
      </div>
    </div>
  );
}

// ==========================================
// 4. GOALS CHECKLIST PANEL
// ==========================================
export function GoalsSection() {
  const [goals, setGoals] = useState([
    { id: 1, title: "100 Push-ups continuous", completed: false },
    { id: 2, title: "Sub 20-min 5K Run", completed: true },
    { id: 3, title: "Deadlift 2x Bodyweight", completed: false },
  ]);
  const [newGoal, setNewGoal] = useState("");

  const addGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoal.trim()) return;
    playSound("click");
    setGoals([{ id: Date.now(), title: newGoal, completed: false }, ...goals]);
    setNewGoal("");
  };

  const toggleGoal = (id: number) => {
    playSound("toggle");
    setGoals(goals.map(g => g.id === id ? { ...g, completed: !g.completed } : g));
  };

  return (
    <div className="bg-[#050B1A] border border-[#B66DFF]/20 p-6 md:p-8 rounded-[2rem] text-left max-w-2xl mx-auto shadow-[0_0_40px_rgba(182,109,255,0.05)] relative select-none">
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#B66DFF]/5 rounded-full blur-[80px] pointer-events-none" />
      
      <div className="relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#B66DFF]/10 border border-[#B66DFF]/30 rounded-full mb-3">
          <Target className="w-3.5 h-3.5 text-[#B66DFF]" />
          <span className="text-[9px] font-black uppercase tracking-[0.2em] text-[#B66DFF]">Strategic Objectives</span>
        </div>
        
        <h2 className="text-2xl font-black text-white uppercase tracking-tight flex items-center gap-2">
          Set <span className="text-[#B66DFF]">Targets & Goals</span>
        </h2>
        <p className="text-neutral-400 text-xs font-medium mt-1 mb-8">
          Define your ultimate athletic milestones. Lock them in and execute.
        </p>

        <form onSubmit={addGoal} className="relative mb-8">
          <input
            type="text"
            value={newGoal}
            onChange={(e) => setNewGoal(e.target.value)}
            placeholder="Define a new operational objective..."
            className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-5 pr-14 text-sm font-medium text-white placeholder:text-neutral-600 focus:outline-none focus:border-[#B66DFF]/50 focus:ring-1 focus:ring-[#B66DFF]/50 transition-all"
          />
          <button 
            type="submit"
            disabled={!newGoal.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-[#B66DFF] text-black rounded-xl hover:bg-[#C285FF] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Plus className="w-5 h-5" />
          </button>
        </form>

        <div className="space-y-3">
          {goals.map((goal) => (
            <div 
              key={goal.id}
              onClick={() => toggleGoal(goal.id)}
              className={`group flex items-center gap-4 p-4 rounded-2xl border cursor-pointer transition-all ${
                goal.completed 
                  ? "bg-emerald-500/10 border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]" 
                  : "bg-white/5 border-white/10 hover:border-[#B66DFF]/40 hover:bg-white/10"
              }`}
            >
              <div className={`w-6 h-6 shrink-0 rounded-lg flex items-center justify-center transition-all ${
                goal.completed ? "bg-emerald-500 text-black shadow-[0_0_10px_rgba(16,185,129,0.5)]" : "bg-black/50 border border-white/20 text-transparent"
              }`}>
                <Check className="w-4 h-4 stroke-[3]" />
              </div>
              <span className={`text-sm font-bold tracking-wide transition-all ${goal.completed ? "text-emerald-400 line-through opacity-70" : "text-white group-hover:text-[#B66DFF]"}`}>
                {goal.title}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 5. PREMIUM PASS VIP SHEET
// ==========================================
export function PremiumSection() {
  return (
    <div className="bg-[#0A0A0A] border border-brand-border p-6 rounded-3xl text-left max-w-md mx-auto shadow-2xl relative select-none overflow-hidden font-sans">
      <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(201,243,29,0.02)_0%,rgba(0,0,0,0)_70%)] pointer-events-none" />
      <div className="absolute top-0 right-0 w-28 h-28 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10 flex flex-col items-center text-center space-y-4">
        <div className="w-12 h-12 rounded-full bg-brand-accent/10 border border-brand-accent/20 flex items-center justify-center text-xl">
          ⚡
        </div>
        
        <div className="space-y-1">
          <span className="text-[9px] font-black uppercase text-brand-accent tracking-widest bg-brand-accent/15 px-2.5 py-1 rounded">
            FIT GENIE ACCESS
          </span>
          <h2 className="text-sm font-black text-white mt-2 uppercase tracking-wider">
            All Features Unlocked
          </h2>
        </div>

        <p className="text-zinc-400 text-[10.5px] leading-relaxed uppercase tracking-wider">
          Enjoy fully unlocked calisthenics routines, diet logs, water counters, gym ranking leaderboards, and step trackers with no subscriptions required!
        </p>

        <div className="w-full text-[10px] space-y-2 bg-brand-surface p-4 rounded-xl border border-brand-border/60 font-semibold text-zinc-300 text-left">
          <div className="flex gap-2 items-center">
            <Check className="w-4 h-4 text-brand-accent shrink-0 stroke-[3]" />
            <span>Complete Calisthenics Videos & workout splits</span>
          </div>
          <div className="flex gap-2 items-center">
            <Check className="w-4 h-4 text-brand-accent shrink-0 stroke-[3]" />
            <span>Personal nutrition and calorie dynamic calculators</span>
          </div>
          <div className="flex gap-2 items-center">
            <Check className="w-4 h-4 text-brand-accent shrink-0 stroke-[3]" />
            <span>Real-time local step counter and water logs</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 6. HEALTH NOTIFICATIONS BOX
// ==========================================
export function NotificationsSection() {
  const [alerts, setAlerts] = useState({
    workoutReminders: true,
    streakWarnings: true,
    socialUpdates: false,
    promotions: false
  });

  const toggle = (key: keyof typeof alerts) => {
    playSound("toggle");
    setAlerts(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="bg-[#050B1A] border border-[#14F1E1]/20 p-6 md:p-8 rounded-[2rem] text-left max-w-2xl mx-auto shadow-[0_0_40px_rgba(20,241,225,0.05)] relative select-none">
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#14F1E1]/5 rounded-full blur-[80px] pointer-events-none" />
      
      <div className="relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#14F1E1]/10 border border-[#14F1E1]/30 rounded-full mb-3">
          <Bell className="w-3.5 h-3.5 text-[#14F1E1]" />
          <span className="text-[9px] font-black uppercase tracking-[0.2em] text-[#14F1E1]">Comms Hub</span>
        </div>
        
        <h2 className="text-2xl font-black text-white uppercase tracking-tight flex items-center gap-2">
          System <span className="text-[#14F1E1]">Alerts</span>
        </h2>
        <p className="text-neutral-400 text-xs font-medium mt-1 mb-8">
          Configure operational telemetry and push notifications.
        </p>

        <div className="space-y-4">
          <AlertToggle 
            title="Training Directives" 
            desc="Daily notifications reminding you of scheduled masterclasses."
            active={alerts.workoutReminders}
            onClick={() => toggle('workoutReminders')}
          />
          <AlertToggle 
            title="Streak Diagnostics" 
            desc="Critical alerts when your training consistency is at risk of resetting."
            active={alerts.streakWarnings}
            onClick={() => toggle('streakWarnings')}
          />
          <AlertToggle 
            title="Squad Telemetry" 
            desc="Updates when squad members achieve new PRs or challenge you."
            active={alerts.socialUpdates}
            onClick={() => toggle('socialUpdates')}
          />
          <AlertToggle 
            title="System Intel" 
            desc="News on upcoming app updates, new AI features, and events."
            active={alerts.promotions}
            onClick={() => toggle('promotions')}
          />
        </div>
      </div>
    </div>
  );
}

function AlertToggle({ title, desc, active, onClick }: { title: string, desc: string, active: boolean, onClick: () => void }) {
  return (
    <div 
      onClick={onClick}
      className="flex items-center justify-between p-5 bg-white/5 border border-white/10 rounded-2xl cursor-pointer hover:bg-white/10 transition-all group"
    >
      <div className="pr-4">
        <h3 className="text-sm font-bold text-white mb-1 tracking-wide">{title}</h3>
        <p className="text-xs text-neutral-500 font-medium leading-relaxed">{desc}</p>
      </div>
      <div className={`w-12 h-6 shrink-0 rounded-full relative transition-all duration-300 ${active ? "bg-[#14F1E1] shadow-[0_0_15px_rgba(20,241,225,0.4)]" : "bg-black/50 border border-white/20"}`}>
        <div className={`absolute top-1 left-1 w-4 h-4 rounded-full transition-all duration-300 ${active ? "translate-x-6 bg-black" : "bg-neutral-500"}`} />
      </div>
    </div>
  );
}

// ==========================================
// 7. FREQUENTLY ASKED HELP & FAQ
// ==========================================
export function HelpSupportSection() {
  const [openedTab, setOpenedTab] = useState<number | null>(0);

  const faqs = [
    {
      q: "What is the specialized Desi Calisthenics Academy?",
      a: "It is a standard workout routine utilizing age-old gravity compound methods like Surya Namaskars, Hindu pushups (Dand), squats (Baithak), and full-body postures with minimal traditional tools for density gains."
    },
    {
      q: "How does the anatomical muscle visualization work?",
      a: "When you select cards on the Exercise Database or the custom Videos catalogs, target muscles are automatically highlighted on our Interactive body schematic in glowing green neon to check primary loading points."
    },
    {
      q: "Is my personal logs information private?",
      a: "Absolutely! All historical training journals, calorie configurations, step counter indexes, and water records are stored safe locally on your device storage with optional sync to Firestore."
    },
    {
      q: "Can I use the AI coaching consult offline?",
      a: "The Bro Coach utilizes online Gemini intelligence structures to compute recommendations, which requires active internet capabilities."
    }
  ];

  return (
    <div className="bg-[#0A0A0A] border border-[#1A1A1A] p-6 rounded-3xl text-left max-w-md mx-auto shadow-2xl relative select-none">
      <div className="absolute top-0 right-0 w-24 h-24 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />

      <div>
        <span className="text-[10px] font-black uppercase text-brand-accent tracking-widest bg-brand-accent/10 px-2.5 py-1 rounded-md border border-brand-accent/20">
          ❓ COACH DESK HELP
        </span>
        <h2 className="text-xl font-black text-white mt-2 flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-brand-accent" />
          HELP & SUPPORT DESK
        </h2>
        <p className="text-zinc-500 text-[10px] uppercase font-bold font-mono mt-0.5">
          Ask questions or explore documentation summaries instantly
        </p>
      </div>

      <div className="space-y-2.5 pt-4">
        {faqs.map((faq, idx) => {
          const isO = openedTab === idx;
          return (
            <div 
              key={idx}
              className="bg-brand-surface border border-brand-border/60 rounded-2xl overflow-hidden transition-all"
            >
              <button
                onClick={() => { playSound("click"); setOpenedTab(isO ? null : idx); }}
                className="w-full text-left p-3.5 flex justify-between items-center gap-3 font-black text-zinc-200 hover:text-white text-xs uppercase cursor-pointer"
              >
                <span>{faq.q}</span>
                <span className="text-brand-accent shrink-0">{isO ? "−" : "+"}</span>
              </button>
              
              {isO && (
                <div className="px-3.5 pb-4 text-[10.5px] leading-relaxed text-zinc-400 font-semibold border-t border-zinc-950 pt-2 bg-black/20">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ==========================================
// 8. LUXURY APP SHARE OVERLAY
// ==========================================
interface ShareModalProps {
  onClose: () => void;
}

export function ShareModal({ onClose }: ShareModalProps) {
  const [copied, setCopied] = useState(false);
  const shareLink = window.location.href;

  const copyToClipboard = () => {
    playSound("click");
    navigator.clipboard.writeText(`Join me on Fit Genie - the ultimate customized fitness partner! ⚡ ${shareLink}`);
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
    }, 2005);
  };

  return (
    <div className="fixed inset-0 z-[200] bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-sm bg-[#0D0D0D] border border-brand-border rounded-3xl p-6 space-y-5 text-left relative overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />

        <div className="flex justify-between items-start">
          <div>
            <span className="text-[9px] font-black text-brand-accent uppercase tracking-widest font-mono">APP SHARING NETWORK</span>
            <h3 className="text-base font-black text-white mt-1 uppercase flex items-center gap-1.5Packed font-sans">
              <Share2 className="w-4 h-4 text-brand-accent" /> SHARE APP WITH BROS
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-zinc-950 border border-zinc-900 text-zinc-500 hover:text-white flex items-center justify-center cursor-pointer font-mono"
          >
            ✕
          </button>
        </div>

        <div className="text-center bg-[#111] p-5 rounded-2xl border border-zinc-900/60 flex flex-col items-center gap-2">
          <span className="text-2xl animate-spin">📡</span>
          <p className="text-[10.5px] text-zinc-400 font-bold uppercase font-mono">Fit Genie Dev Applet URL</p>
          <p className="text-[9.5px] text-neutral-500 line-clamp-2 break-words font-mono">{shareLink}</p>
        </div>

        {/* Action button copy */}
        <button
          onClick={copyToClipboard}
          className="w-full bg-brand-accent text-[#0A0A0A] p-3 text-xs font-black uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer hover:bg-white"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 stroke-[3]" />
              <span>LAUNCH LINK COPIED!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4 stroke-[3]" />
              <span>COPY SHARE LINK CARD</span>
            </>
          )}
        </button>

        {/* Traditional Social channels list */}
        <div className="grid grid-cols-4 gap-2 text-[9px] font-mono font-black uppercase tracking-widest text-zinc-500 text-center">
          <button onClick={copyToClipboard} className="bg-zinc-950 p-2 border border-zinc-900 hover:bg-[#111] hover:text-white rounded-lg cursor-pointer">WhatsApp</button>
          <button onClick={copyToClipboard} className="bg-zinc-950 p-2 border border-zinc-900 hover:bg-[#111] hover:text-white rounded-lg cursor-pointer">Twitter</button>
          <button onClick={copyToClipboard} className="bg-zinc-950 p-2 border border-zinc-900 hover:bg-[#111] hover:text-white rounded-lg cursor-pointer">Telegram</button>
          <button onClick={copyToClipboard} className="bg-zinc-950 p-2 border border-zinc-900 hover:bg-[#111] hover:text-white rounded-lg cursor-pointer">SMS Message</button>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 9. HIGH CONTRAST FEEDBACK RATE MODULE
// ==========================================
interface RateModalProps {
  onClose: () => void;
}

export function RateModal({ onClose }: RateModalProps) {
  const [stars, setStars] = useState(5);
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playSound("click");
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-[200] bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-sm bg-[#0D0D0D] border border-brand-border rounded-3xl p-6 space-y-5 text-left relative overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />

        <div className="flex justify-between items-start">
          <div>
            <span className="text-[9px] font-black text-brand-accent uppercase tracking-widest font-mono">AUDIENCE ENGAGEMENT</span>
            <h3 className="text-base font-black text-white mt-1 uppercase flex items-center gap-1.5 font-sans">
              <Star className="w-4 h-4 text-brand-accent" /> RATE EXPERIENCES
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-zinc-950 border border-zinc-900 text-zinc-500 hover:text-white flex items-center justify-center cursor-pointer font-mono"
          >
            ✕
          </button>
        </div>

        {!submitted ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Interactive Stars Selection Row */}
            <div className="flex justify-center gap-2.5 py-2">
              {[1, 2, 3, 4, 5].map((val) => {
                const isActive = stars >= val;
                return (
                  <button
                    key={val}
                    type="button"
                    onClick={() => { playSound("toggle"); setStars(val); }}
                    className="text-3xl focus:outline-none transition-transform hover:scale-110 cursor-pointer"
                  >
                    <Star className={`w-8 h-8 ${isActive ? "text-[#C9F31D] fill-[#C9F31D]" : "text-zinc-700"}`} />
                  </button>
                );
              })}
            </div>

            <div className="text-center">
              <span className="text-[9.5px] font-mono text-zinc-500 uppercase font-black">
                {stars === 5 ? "👑 ULTIMATE EXCELLENT!" : stars === 4 ? "⭐ Very Good progress!" : "★ Build support feedback"}
              </span>
            </div>

            <textarea
              placeholder="Leave descriptive reviews/suggestions to coach developers..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="w-full bg-black rounded-xl border border-neutral-900 focus:border-brand-accent focus:outline-none p-3 text-xs text-white placeholder-zinc-700 font-mono resize-none h-24"
            />

            <button
              type="submit"
              className="w-full bg-brand-accent text-[#0A0A0A] p-3 text-xs font-black uppercase tracking-widest rounded-xl hover:bg-white transition-all cursor-pointer shadow-lg"
            >
              SUBMIT 5-STAR REVIEW
            </button>
          </form>
        ) : (
          <div className="text-center py-6 space-y-3.5">
            <span className="text-4xl animate-bounce inline-block">🏵️</span>
            <p className="text-xs font-black text-white uppercase font-mono tracking-wider">REVIEW RECORDED SUCCESFULLY!</p>
            <p className="text-[10px] leading-relaxed text-zinc-500 font-semibold max-w-xs mx-auto">
              Shabash! Thank you for leaving helpful validation metrics. We monitor reviews continuously to adjust algorithmic layouts.
            </p>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-neutral-900 text-zinc-400 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-[#111] transition-all"
            >
              Close Window
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ==========================================
// 10. COMPREHENSIVE PRIVACY POLICY SHEET
// ==========================================
export function PrivacySection() {
  return (
    <div className="bg-[#0A0A0A] border border-[#1A1A1A] p-6 rounded-3xl text-left max-w-2xl mx-auto shadow-2xl relative select-none">
      <div className="absolute top-0 right-0 w-24 h-24 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />

      <div>
        <span className="text-[10px] font-black uppercase text-brand-accent tracking-widest bg-brand-accent/10 px-2.5 py-1 rounded-md border border-brand-accent/20">
          🛡️ REGULATORY COMPLIANCE
        </span>
        <h2 className="text-xl font-black text-white mt-2 flex items-center gap-2">
          <Shield className="w-5 h-5 text-brand-accent" />
          PRIVACY POLICY SHEET
        </h2>
        <p className="text-zinc-500 text-[10px] uppercase font-bold font-mono mt-0.5 animate-pulse">
          Read terms regarding local data isolation practices
        </p>
      </div>

      <div className="space-y-4 pt-4 text-xs text-zinc-400 leading-relaxed font-semibold">
        <p>
          Last updated: June 17, 2026. This legal brief describes the storage practices implemented in the <span className="text-white font-bold">Fit Genie Application</span> suite. We prioritize data sovereignty.
        </p>

        <div className="bg-brand-surface p-4 rounded-2xl border border-brand-border/60 space-y-2 text-[10.5px]">
          <span className="block font-black text-zinc-200 uppercase tracking-wide">1. LOCAL-FIRST OFF-LINE GUARANTEES</span>
          <p>
            All exercises completed logged on the Workout Generator calendar, consecutive water drink quantities, calories calculated outputs, and step dials are stored instantly on-device in LocalStorage.
          </p>
        </div>

        <div className="bg-[#080808] p-4 rounded-2xl border border-neutral-900 space-y-2 text-[10.5px]">
          <span className="block font-black text-zinc-200 uppercase tracking-wide">2. GOOGLE AUTHS & FIRESTORE CLOUD</span>
          <p>
            Optional user registration uses secured, sandboxed Firebase Authentication SDK gates. Firestore database storage isolates logs securely per profile ID so cache clearances do not result in lost history.
          </p>
        </div>

        <p className="text-[10px] text-zinc-500 font-mono uppercase text-center mt-2 font-black">
          © FIT GENIE INC • SECURE ANATOMICAL SCHEMATICS 2026
        </p>
      </div>
    </div>
  );
}
