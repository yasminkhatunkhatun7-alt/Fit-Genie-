import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Trophy, Ghost, ChevronLeft, Loader2, RefreshCw, Crown } from "lucide-react";
import { db } from "../lib/firebase";
import { collection, query, orderBy, limit, getDocs } from "firebase/firestore";
import { useAuth } from "../context/AuthContext";
import { AiRepCounter } from "./AiRepCounter";

interface LeaderboardEntry {
  userId: string;
  userName: string;
  xp: number;
  avatarBg: string;
  squats_all?: number;
  squats_1min?: number;
  pushups_all?: number;
  pushups_1min?: number;
}

export default function Leaderboards({ onClose }: { onClose: () => void }) {
  const { profile } = useAuth();
  const currentUserId = profile?.uid;

  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [leaderboardLoading, setLeaderboardLoading] = useState(true);
  const [leaderboardType, setLeaderboardType] = useState<"xp" | "squats_all" | "squats_1min" | "pushups_all" | "pushups_1min">("xp");
  
  const [showAiCounter, setShowAiCounter] = useState(false);
  const [challengeTarget, setChallengeTarget] = useState<{userId: string, userName: string, score: number, exercise: "Squats"|"Pushups"} | null>(null);

  const LEADERBOARD_CACHE_TTL = 5 * 60 * 1000; // 5 minutes in milliseconds

  useEffect(() => {
    fetchLeaderboard(leaderboardType);
  }, [leaderboardType]);

  const fetchLeaderboard = async (
    overrideType?: "xp" | "squats_all" | "squats_1min" | "pushups_all" | "pushups_1min",
    forceRefresh = false
  ) => {
    const type = overrideType || leaderboardType;
    const cacheKey = `fitgenie_leaderboard_${type}`;

    // 1. Check 5-minute LocalStorage cache to avoid 100 Firestore reads
    if (!forceRefresh) {
      try {
        const raw = localStorage.getItem(cacheKey);
        if (raw) {
          const cached = JSON.parse(raw);
          if (Date.now() - cached.timestamp < LEADERBOARD_CACHE_TTL && Array.isArray(cached.data)) {
            console.log(`[Leaderboard Cache Hit] Using 5-min cached leaderboard for ${type} (0 Firestore reads)`);
            setLeaderboard(cached.data);
            setLeaderboardLoading(false);
            return;
          }
        }
      } catch (err) {
        console.warn("Failed reading leaderboard cache:", err);
      }
    }

    setLeaderboardLoading(true);

    // 2. Offline fallback: If offline, use cached data even if older than 5 minutes
    if (!navigator.onLine) {
      const raw = localStorage.getItem(cacheKey);
      if (raw) {
        try {
          const cached = JSON.parse(raw);
          setLeaderboard(cached.data || []);
          setLeaderboardLoading(false);
          return;
        } catch {}
      }
    }

    try {
      let q;
      if (type === "xp") {
        q = query(collection(db, "users"), orderBy("xp", "desc"), limit(100));
      } else {
        q = query(collection(db, "users"), orderBy(`stats.${type}`, "desc"), limit(100));
      }

      const querySnapshot = await getDocs(q);
      const fetched: LeaderboardEntry[] = [];
      querySnapshot.forEach((docSnap) => {
        const data = docSnap.data() as any;
        let value = 0;
        if (type === "xp") value = data.xp || 0;
        else value = data.stats?.[type] || 0;
        
        if (value > 0) {
          fetched.push({
            userId: docSnap.id,
            userName: data.userName || "Athlete",
            xp: data.xp || 0,
            avatarBg: data.avatarBg || "bg-gradient-to-br from-zinc-700 to-zinc-900",
            squats_all: data.stats?.squats_all || 0,
            squats_1min: data.stats?.squats_1min || 0,
            pushups_all: data.stats?.pushups_all || 0,
            pushups_1min: data.stats?.pushups_1min || 0,
          });
        }
      });

      setLeaderboard(fetched);

      // Cache the result in LocalStorage for 5 minutes
      try {
        localStorage.setItem(cacheKey, JSON.stringify({
          timestamp: Date.now(),
          data: fetched
        }));
      } catch (err) {
        console.warn("Failed saving leaderboard cache:", err);
      }
    } catch (e) {
      console.error("Error fetching leaderboard", e);
    } finally {
      setLeaderboardLoading(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="absolute inset-0 bg-[#050B1A] z-50 flex flex-col"
    >
      {showAiCounter && (
        <AiRepCounter
          initialExercise={challengeTarget ? challengeTarget.exercise : "Squats"}
          challengeTarget={challengeTarget || undefined}
          onClose={() => {
            setShowAiCounter(false);
            setChallengeTarget(null);
            fetchLeaderboard(); // refresh in case they won
          }}
          onComplete={() => {
            setShowAiCounter(false);
            setChallengeTarget(null);
            fetchLeaderboard();
          }}
        />
      )}

      {/* Header */}
      <div className="p-4 border-b border-[#1A2642] bg-[#0A1128] flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/5 text-white transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-xl font-black uppercase tracking-tight text-white leading-none">Leaderboards</h1>
            <p className="text-[10px] uppercase font-bold tracking-widest text-brand-muted mt-0.5">Top Athletes Worldwide</p>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col min-h-0">
        <div className="p-4 shrink-0 bg-[#0A1128] border-b border-[#1A2642]">
          <div className="flex bg-[#050B1A] p-1 rounded-xl mb-4 shadow-inner">
            <button onClick={() => setLeaderboardType("xp")} className={`flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${leaderboardType === "xp" ? "bg-[#B66DFF] text-white" : "text-neutral-500 hover:text-white"}`}>XP</button>
            <button onClick={() => setLeaderboardType("squats_all")} className={`flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${leaderboardType.startsWith("squats") ? "bg-[#14F1E1] text-[#050B1A]" : "text-neutral-500 hover:text-white"}`}>Squats</button>
            <button onClick={() => setLeaderboardType("pushups_all")} className={`flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${leaderboardType.startsWith("pushups") ? "bg-[#FF5A5F] text-white" : "text-neutral-500 hover:text-white"}`}>Pushups</button>
          </div>

          {leaderboardType.startsWith("squats") && (
            <div className="flex bg-[#14F1E1]/10 p-1 rounded-xl mb-4 border border-[#14F1E1]/20">
              <button onClick={() => setLeaderboardType("squats_all")} className={`flex-1 py-1.5 text-[9px] font-bold uppercase tracking-widest rounded-lg transition-all ${leaderboardType === "squats_all" ? "bg-[#14F1E1] text-[#050B1A]" : "text-[#14F1E1]/70"}`}>All-Time Highest</button>
              <button onClick={() => setLeaderboardType("squats_1min")} className={`flex-1 py-1.5 text-[9px] font-bold uppercase tracking-widest rounded-lg transition-all ${leaderboardType === "squats_1min" ? "bg-[#14F1E1] text-[#050B1A]" : "text-[#14F1E1]/70"}`}>1-Min Best</button>
            </div>
          )}

          {leaderboardType.startsWith("pushups") && (
            <div className="flex bg-[#FF5A5F]/10 p-1 rounded-xl mb-4 border border-[#FF5A5F]/20">
              <button onClick={() => setLeaderboardType("pushups_all")} className={`flex-1 py-1.5 text-[9px] font-bold uppercase tracking-widest rounded-lg transition-all ${leaderboardType === "pushups_all" ? "bg-[#FF5A5F] text-white" : "text-[#FF5A5F]/70"}`}>All-Time Highest</button>
              <button onClick={() => setLeaderboardType("pushups_1min")} className={`flex-1 py-1.5 text-[9px] font-bold uppercase tracking-widest rounded-lg transition-all ${leaderboardType === "pushups_1min" ? "bg-[#FF5A5F] text-white" : "text-[#FF5A5F]/70"}`}>1-Min Best</button>
            </div>
          )}

          <div className="flex items-center justify-between">
            <h2 className="text-[10px] font-black uppercase tracking-widest text-brand-muted">
              {leaderboardType === "xp" ? "Global Athlete Leaderboard. Ranked by total XP." : 
               leaderboardType === "squats_all" ? "Most Squats completed in a single session." :
               leaderboardType === "squats_1min" ? "Most Squats completed in 60 seconds." :
               leaderboardType === "pushups_all" ? "Most Pushups completed in a single session." :
               "Most Pushups completed in 60 seconds."}
            </h2>
            <button onClick={() => fetchLeaderboard(undefined, true)} className="p-2 bg-neutral-800 rounded-lg text-[#B66DFF] hover:bg-neutral-700 transition-colors" title="Force Refresh from Cloud">
              <RefreshCw className={`w-4 h-4 ${leaderboardLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
          {leaderboardLoading ? (
            <div className="flex-1 flex flex-col items-center justify-center text-brand-muted opacity-50 py-12">
              <Loader2 className="w-8 h-8 text-[#B66DFF] animate-spin mb-4" />
              <p className="text-xs uppercase font-bold tracking-widest">Loading Rankings...</p>
            </div>
          ) : leaderboard.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-brand-muted opacity-50 py-12">
              <Trophy className="w-12 h-12 mb-4 opacity-50" />
              <p className="text-xs uppercase font-bold tracking-widest text-center">No athletes ranked yet.</p>
            </div>
          ) : (
            <AnimatePresence initial={false}>
              {leaderboard.map((athlete, index) => {
                const isMe = currentUserId === athlete.userId;
                return (
                  <motion.div
                    layout
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05, duration: 0.3, ease: "easeOut" }}
                    key={athlete.userId}
                    className={`flex items-center gap-4 p-3 rounded-2xl border transition-all ${isMe ? 'bg-[#B66DFF]/20 border-[#B66DFF] shadow-[0_0_20px_rgba(182,109,255,0.4)] ring-1 ring-[#B66DFF]/50 z-10 relative scale-[1.02]' : leaderboardType.endsWith('_1min') ? 'bg-[#14F1E1]/5 border-[#14F1E1]/20 shadow-[0_0_10px_rgba(20,241,225,0.05)]' : 'bg-brand-surface border-brand-border'}`}
                  >
                    <div className="w-8 flex justify-center font-black text-xl text-neutral-500 italic">
                      #{index + 1}
                    </div>
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shrink-0 border-2 shadow-lg ${athlete.avatarBg}`}>
                      {athlete.userName.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <h4 className="font-bold text-white truncate text-sm">{athlete.userName}</h4>
                        {index < 3 && (
                          <div className="flex items-center gap-1 bg-gradient-to-r from-amber-400/20 to-amber-600/20 border border-amber-500/30 text-amber-400 px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-widest shrink-0">
                            <Crown className="w-2.5 h-2.5" />
                            Top {index + 1}
                          </div>
                        )}
                        {leaderboardType.endsWith('_1min') && (
                          <Ghost className="w-3.5 h-3.5 text-[#14F1E1] opacity-90 animate-pulse" />
                        )}
                        {isMe && <span className="bg-[#B66DFF] text-white text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded-sm shrink-0">You</span>}
                      </div>
                      <p className="text-[11px] uppercase font-bold tracking-widest text-brand-muted">
                        {leaderboardType === "xp" ? `${athlete.xp.toLocaleString()} XP` :
                         leaderboardType === "squats_all" ? `${athlete.squats_all} Squats Max` :
                         leaderboardType === "squats_1min" ? `${athlete.squats_1min} in 60s` :
                         leaderboardType === "pushups_all" ? `${athlete.pushups_all} Pushups Max` :
                         `${athlete.pushups_1min} in 60s`}
                      </p>
                    </div>

                    {!isMe && leaderboardType.endsWith('_1min') && (
                      <button 
                        onClick={() => {
                          setChallengeTarget({
                            userId: athlete.userId,
                            userName: athlete.userName,
                            score: leaderboardType === "squats_1min" ? (athlete.squats_1min || 0) : (athlete.pushups_1min || 0),
                            exercise: leaderboardType === "squats_1min" ? "Squats" : "Pushups"
                          });
                          setShowAiCounter(true);
                        }}
                        className="bg-[#14F1E1]/10 hover:bg-[#14F1E1]/20 border border-[#14F1E1]/30 text-[#14F1E1] px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-1 transition-colors shrink-0"
                      >
                        <Ghost className="w-3 h-3" />
                        Beat
                      </button>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          )}
        </div>
      </div>
    </motion.div>
  );
}
