import { doc, getDoc, setDoc, onSnapshot, collection, increment } from '../lib/firestore';
import { db } from '../lib/firebase';
import React, { useEffect, useState } from "react";

interface Props {
  exerciseName: string;
  isCompletedByUser?: boolean;
}

export function GlobalCompletionCounter({ exerciseName, isCompletedByUser }: Props) {
  const [count, setCount] = useState<number | null>(null);

  if (!exerciseName) return null;

  const getDocId = () => "exercise_completions";
  const getFieldKey = () => {
    let key = exerciseName.toLowerCase().replace(/[^a-z0-9]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
    // Remove variations like 10_sec
    key = key.replace(/_\d+_sec/g, '');
    return key + "_completed";
  };

  useEffect(() => {
    if (!db || !exerciseName) return;
    const unsub = onSnapshot(doc(db, "stats", getDocId()), (docSnap) => {
      if (docSnap.exists()) {
        setCount(docSnap.data()[getFieldKey()] || 0);
      } else {
        setCount(0);
      }
    }, (err) => {
      console.error("Error fetching completions:", err);
    });
    return () => unsub();
  }, [exerciseName]);

  const eliteSkills = ["muscle up", "human flag", "front lever", "full planche", "iron cross", "manna"];
  const isElite = eliteSkills.some(skill => exerciseName.toLowerCase().includes(skill));

  const getMotivationalText = (c: number, elite: boolean) => {
    if (elite) {
      if (c === 0) return "Be the very first legend to conquer this elite move.";
      if (c < 10) return "Join an exclusive handful of athletes who mastered this.";
      if (c < 100) return "You are among the rare elite to achieve this skill.";
      return "Join the elite ranks of masters.";
    }

    if (c === 0) return "Pave the way! Be the first to complete this.";
    if (c < 50) return "Be part of the early wave of athletes crushing this.";
    if (c < 500) return "Hundreds are pushing their limits with this exercise.";
    if (c < 5000) return "Join thousands of athletes mastering this.";
    return "A community favorite! Keep pushing your limits.";
  };

  if (count === null) return null;

  return (
    <div className="bg-[#0A0A0B]/60 border border-zinc-800/60 rounded-xl p-3 my-3">
      {isElite && isCompletedByUser && (
        <div className="flex items-center gap-3 bg-amber-500/10 border border-amber-500/20 p-2.5 rounded-lg mb-3">
          <div className="bg-amber-500/20 p-2 rounded-full flex-shrink-0">
            <span className="text-xl leading-none">🏆</span>
          </div>
          <div>
            <div className="text-xs font-black text-amber-400 uppercase tracking-widest">Personal Best</div>
            <div className="text-[10px] text-amber-500/80 font-bold uppercase mt-0.5">You have mastered this Elite Skill</div>
          </div>
        </div>
      )}
      {isElite ? (
        <>
          <div className="text-sm font-black text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
            <span>🏆</span> {count === 0 ? "No one has completed this yet" : `Only ${count.toLocaleString()} users have completed this skill`}
          </div>
          <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider mt-1">
            {getMotivationalText(count, isElite)}
          </div>
        </>
      ) : (
        <>
          <div className="text-sm font-black text-orange-400 uppercase tracking-widest flex items-center gap-1.5">
            <span>🔥</span> {count === 0 ? "0 Completions" : `Completed by ${count.toLocaleString()} users`}
          </div>
          <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider mt-1">
            {getMotivationalText(count, isElite)}
          </div>
        </>
      )}
    </div>
  );
}

export const incrementCompletionCount = async (exerciseName: string) => {
  if (!db || !exerciseName) return;
  let key = exerciseName.toLowerCase().replace(/[^a-z0-9]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
  key = key.replace(/_\d+_sec/g, '');
  const fieldKey = key + "_completed";

  const ref = doc(db, "stats", "exercise_completions");
  try {
    await setDoc(ref, { [fieldKey]: increment(1) }, { merge: true });
  } catch (err) {
    console.error("Error updating completions:", err);
  }
};
