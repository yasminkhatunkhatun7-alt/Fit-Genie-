import { useState } from "react";
import { Exercise } from "../types";
import { Activity, Flame, ShieldAlert } from "lucide-react";
import { motion } from "motion/react";

interface MuscleHeatmapProps {
  exercises: Exercise[];
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.15,
    },
  },
};

const itemVariants: any = {
  hidden: { opacity: 0, scale: 0.92, originX: 0.5, originY: 0.5 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.45,
      ease: [0.16, 1, 0.3, 1], // easeOutQuint style curve
    },
  },
};

interface MuscleAnalysis {
  muscleId: string;
  name: string;
  hindiName: string;
  primarySets: number;
  secondarySets: number;
  totalSets: number;
  exercisesList: {
    id: number;
    name_en: string;
    isPrimary: boolean;
    sets: number;
  }[];
}

const MUSCLE_DEFAULTS: { id: string; name: string; hindi: string }[] = [
  { id: "chest", name: "Chest", hindi: "छाती" },
  { id: "back", name: "Back", hindi: "पीठ" },
  { id: "shoulders", name: "Shoulders", hindi: "कंधे" },
  { id: "biceps", name: "Biceps", hindi: "बाइसेप्स" },
  { id: "triceps", name: "Triceps", hindi: "ट्राइसेप्स" },
  { id: "core", name: "Core", hindi: "एब्स" },
  { id: "glutes", name: "Glutes", hindi: "कूल्हे" },
  { id: "legs", name: "Legs", hindi: "जांघें" },
  { id: "calves", name: "Calves", hindi: "पिंडलियां" },
];

export default function MuscleHeatmap({ exercises }: MuscleHeatmapProps) {
  const [view, setView] = useState<"front" | "back">("front");
  const [hoveredMuscle, setHoveredMuscle] = useState<string | null>(null);
  const [selectedDetails, setSelectedDetails] = useState<string | null>(null);

  // 1. Calculate training volume per muscle group
  const analysis: Record<string, MuscleAnalysis> = {};
  MUSCLE_DEFAULTS.forEach((m) => {
    analysis[m.id] = {
      muscleId: m.id,
      name: m.name,
      hindiName: m.hindi,
      primarySets: 0,
      secondarySets: 0,
      totalSets: 0,
      exercisesList: [],
    };
  });

  exercises.forEach((ex) => {
    const sets = ex.sets || 3;
    // Primary Muscle (index 0)
    const primaryMuscle = ex.muscles[0];
    if (primaryMuscle && analysis[primaryMuscle]) {
      analysis[primaryMuscle].primarySets += sets;
      analysis[primaryMuscle].totalSets += sets;
      analysis[primaryMuscle].exercisesList.push({
        id: ex.id,
        name_en: ex.name_en,
        isPrimary: true,
        sets,
      });
    }

    // Secondary Muscles (index 1+)
    const secondaryMuscles = ex.muscles.slice(1);
    secondaryMuscles.forEach((sec) => {
      if (sec && analysis[sec]) {
        // Secondary muscle counts as half set volume for structural heatmap
        analysis[sec].secondarySets += sets;
        analysis[sec].totalSets += sets * 0.5;
        analysis[sec].exercisesList.push({
          id: ex.id,
          name_en: ex.name_en,
          isPrimary: false,
          sets,
        });
      }
    });
  });

  // Helper to choose color based on calculated engagement sets
  const getHeatmapColor = (muscle: string) => {
    const data = analysis[muscle];
    if (!data || data.totalSets === 0) return "#141414"; // No engagement (Deep, dark gray)
    
    const sets = data.totalSets;
    if (sets <= 3) {
      // Light / Secondary Helper (Green-Teal Accent)
      return "#0d9488"; 
    } else if (sets <= 7) {
      // Moderate engagement (Brilliant Amber/Orange)
      return "#d97706";
    } else {
      // Overload engagement (Crimson Red / High Intensity)
      return "#dc2626";
    }
  };

  const getStrokeColor = (muscle: string) => {
    const data = analysis[muscle];
    if (!data || data.totalSets === 0) return "#2a2a2a";
    
    const sets = data.totalSets;
    if (sets <= 3) return "#14b8a6"; // Teal
    if (sets <= 7) return "#f59e0b"; // Amber
    return "#f43f5e"; // Crimson
  };

  const getGlowFilter = (muscle: string) => {
    const data = analysis[muscle];
    if (!data || data.totalSets === 0) return "none";
    
    const sets = data.totalSets;
    if (sets <= 3) return "url(#teal-glow)";
    if (sets <= 7) return "url(#amber-glow)";
    return "url(#crimson-glow)";
  };

  const activeMuscleId = hoveredMuscle || selectedDetails || null;
  const activeMuscleData = activeMuscleId ? analysis[activeMuscleId] : null;

  return (
    <div className="bg-brand-surface border border-brand-border/80 rounded-3xl p-5 space-y-6 flex flex-col justify-between" id="muscle-heatmap-container">
      <div>
        <div className="flex items-center justify-between border-b border-brand-border pb-3.5">
          <div className="space-y-0.5">
            <h3 className="font-extrabold text-[#F3F3F3] text-sm uppercase tracking-wider flex items-center gap-2">
              <Flame className="w-4 h-4 text-brand-accent fill-brand-accent/20 animate-pulse" />
              <span>LIVE MUSCLE HEATMAP</span>
            </h3>
            <p className="text-[10px] text-brand-muted uppercase tracking-widest">
              Live engagement & volume overlay
            </p>
          </div>

          {/* Front / Back Toggle Buttons */}
          <div className="flex bg-neutral-900 border border-brand-border/60 p-0.5 rounded-lg text-[9px] font-bold">
            <button
              onClick={() => setView("front")}
              className={`px-3 py-1 rounded-md uppercase tracking-wider transition-all cursor-pointer ${
                view === "front"
                  ? "bg-brand-accent text-brand-bg font-black"
                  : "text-brand-muted hover:text-white"
              }`}
            >
              Front
            </button>
            <button
              onClick={() => setView("back")}
              className={`px-3 py-1 rounded-md uppercase tracking-wider transition-all cursor-pointer ${
                view === "back"
                  ? "bg-brand-accent text-brand-bg font-black"
                  : "text-brand-muted hover:text-white"
              }`}
            >
              Back
            </button>
          </div>
        </div>

        {/* Diagnostic heatmap key */}
        <div className="flex flex-wrap items-center justify-between gap-2 py-3 bg-[#111] px-3.5 rounded-xl border border-brand-border/40 mt-3 text-[10px] font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-[#141414] border border-[#2a2a2a]" />
            <span className="text-zinc-500">Unworked</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-[#0d9488] border border-[#14b8a6] shadow-[0_0_4px_rgba(20,184,166,0.5)]" />
            <span className="text-teal-400">Helper (1-3s)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-[#d97706] border border-[#f59e0b] shadow-[0_0_4px_rgba(245,158,11,0.5)]" />
            <span className="text-amber-400">Target (4-7s)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-[#dc2626] border border-[#f43f5e] shadow-[0_0_4px_rgba(244,63,94,0.5)] animate-pulse" />
            <span className="text-red-400 font-extrabold text-[9px]">High (8s+)</span>
          </div>
        </div>

        {/* SVG Heatmap Stage */}
        <div className="relative w-full aspect-[4/5] bg-[#0c0c0c] border border-brand-border/40 rounded-2xl flex items-center justify-center p-3 overflow-hidden mt-4 group">
          {/* Schematic lines */}
          <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
            <div className="w-full h-full bg-[linear-gradient(to_right,#888_1px,transparent_1px),linear-gradient(to_bottom,#888_1px,transparent_1px)] bg-[size:15px_15px]"></div>
          </div>

          <svg
            viewBox="0 0 200 300"
            className="w-full h-full max-w-[200px] drop-shadow-[0_0_15px_rgba(0,0,0,0.65)]"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              {/* Heatmap color neon glowing filters */}
              <filter id="teal-glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="amber-glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3.5" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="crimson-glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="4.5" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Symmetry guide */}
            <line x1="100" y1="10" x2="100" y2="290" stroke="#222" strokeWidth="0.5" strokeDasharray="2 2" />

            {/* HEAD & NECK (Decorative) */}
            <g stroke="#262626" strokeWidth="1" fill="#0d0d0d">
              <ellipse cx="100" cy="30" rx="14" ry="18" />
              <rect x="95" y="47" width="10" height="10" rx="2" />
            </g>

            {/* FRONT VIEW */}
            {view === "front" && (
              <motion.g
                id="front-body-heat"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {/* SHOULDERS */}
                <motion.g
                  variants={itemVariants}
                  className="cursor-pointer transition-all duration-300"
                  onMouseEnter={() => setHoveredMuscle("shoulders")}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  onClick={() => setSelectedDetails(selectedDetails === "shoulders" ? null : "shoulders")}
                >
                  <path
                    d="M 68,52 C 58,52 50,60 50,72 C 50,78 54,84 57,87 L 66,74 Z"
                    fill={getHeatmapColor("shoulders")}
                    stroke={getStrokeColor("shoulders")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("shoulders")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                  <path
                    d="M 132,52 C 142,52 150,60 150,72 C 150,78 146,84 143,87 L 134,74 Z"
                    fill={getHeatmapColor("shoulders")}
                    stroke={getStrokeColor("shoulders")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("shoulders")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                </motion.g>

                {/* CHEST */}
                <motion.g
                  variants={itemVariants}
                  className="cursor-pointer transition-all duration-300"
                  onMouseEnter={() => setHoveredMuscle("chest")}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  onClick={() => setSelectedDetails(selectedDetails === "chest" ? null : "chest")}
                >
                  <path
                    d="M 100,68 L 68,68 L 68,90 C 68,98 84,98 100,90 Z"
                    fill={getHeatmapColor("chest")}
                    stroke={getStrokeColor("chest")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("chest")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                  <path
                    d="M 100,68 L 132,68 L 132,90 C 132,98 116,98 100,90 Z"
                    fill={getHeatmapColor("chest")}
                    stroke={getStrokeColor("chest")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("chest")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                </motion.g>

                {/* BICEPS */}
                <motion.g
                  variants={itemVariants}
                  className="cursor-pointer transition-all duration-300"
                  onMouseEnter={() => setHoveredMuscle("biceps")}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  onClick={() => setSelectedDetails(selectedDetails === "biceps" ? null : "biceps")}
                >
                  <path
                    d="M 49,76 C 45,82 42,90 42,100 C 42,108 46,112 49,112 C 51,104 53,88 49,76 Z"
                    fill={getHeatmapColor("biceps")}
                    stroke={getStrokeColor("biceps")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("biceps")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                  <path
                    d="M 151,76 C 155,82 158,90 158,100 C 158,108 154,112 151,112 C 149,104 147,88 151,76 Z"
                    fill={getHeatmapColor("biceps")}
                    stroke={getStrokeColor("biceps")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("biceps")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                </motion.g>

                {/* CORE / ABS */}
                <motion.g
                  variants={itemVariants}
                  className="cursor-pointer transition-all duration-300"
                  onMouseEnter={() => setHoveredMuscle("core")}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  onClick={() => setSelectedDetails(selectedDetails === "core" ? null : "core")}
                >
                  <path
                    d="M 72,96 L 128,96 L 122,148 L 78,148 Z"
                    fill={getHeatmapColor("core")}
                    stroke={getStrokeColor("core")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("core")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                </motion.g>

                {/* LEGS / QUADS */}
                <motion.g
                  variants={itemVariants}
                  className="cursor-pointer transition-all duration-300"
                  onMouseEnter={() => setHoveredMuscle("legs")}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  onClick={() => setSelectedDetails(selectedDetails === "legs" ? null : "legs")}
                >
                  <path
                    d="M 74,152 Q 62,185 70,225 L 88,225 Q 94,185 94,152 Z"
                    fill={getHeatmapColor("legs")}
                    stroke={getStrokeColor("legs")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("legs")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                  <path
                    d="M 126,152 Q 138,185 130,225 L 112,225 Q 106,185 106,152 Z"
                    fill={getHeatmapColor("legs")}
                    stroke={getStrokeColor("legs")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("legs")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                </motion.g>
              </motion.g>
            )}

            {/* BACK VIEW */}
            {view === "back" && (
              <motion.g
                id="back-body-heat"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {/* SHOULDERS */}
                <motion.g
                  variants={itemVariants}
                  className="cursor-pointer transition-all duration-300"
                  onMouseEnter={() => setHoveredMuscle("shoulders")}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  onClick={() => setSelectedDetails(selectedDetails === "shoulders" ? null : "shoulders")}
                >
                  <path
                    d="M 68,52 C 54,54 48,64 48,74 L 59,85 Z"
                    fill={getHeatmapColor("shoulders")}
                    stroke={getStrokeColor("shoulders")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("shoulders")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                  <path
                    d="M 132,52 C 146,54 152,64 152,74 L 141,85 Z"
                    fill={getHeatmapColor("shoulders")}
                    stroke={getStrokeColor("shoulders")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("shoulders")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                </motion.g>

                {/* BACK */}
                <motion.g
                  variants={itemVariants}
                  className="cursor-pointer transition-all duration-300"
                  onMouseEnter={() => setHoveredMuscle("back")}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  onClick={() => setSelectedDetails(selectedDetails === "back" ? null : "back")}
                >
                  <path
                    d="M 100,54 L 68,68 L 74,142 L 100,128 L 126,142 L 132,68 Z"
                    fill={getHeatmapColor("back")}
                    stroke={getStrokeColor("back")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("back")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                </motion.g>

                {/* TRICEPS */}
                <motion.g
                  variants={itemVariants}
                  className="cursor-pointer transition-all duration-300"
                  onMouseEnter={() => setHoveredMuscle("triceps")}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  onClick={() => setSelectedDetails(selectedDetails === "triceps" ? null : "triceps")}
                >
                  <path
                    d="M 43,84 C 40,94 40,104 46,112 C 48,112 49,94 47,84 Z"
                    fill={getHeatmapColor("triceps")}
                    stroke={getStrokeColor("triceps")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("triceps")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                  <path
                    d="M 157,84 C 160,94 160,104 154,112 C 152,112 151,94 153,84 Z"
                    fill={getHeatmapColor("triceps")}
                    stroke={getStrokeColor("triceps")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("triceps")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                </motion.g>

                {/* GLUTES */}
                <motion.g
                  variants={itemVariants}
                  className="cursor-pointer transition-all duration-300"
                  onMouseEnter={() => setHoveredMuscle("glutes")}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  onClick={() => setSelectedDetails(selectedDetails === "glutes" ? null : "glutes")}
                >
                  <path
                    d="M 100,146 L 76,146 C 73,158 84,178 100,178 Z"
                    fill={getHeatmapColor("glutes")}
                    stroke={getStrokeColor("glutes")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("glutes")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                  <path
                    d="M 100,146 L 124,146 C 127,158 116,178 100,178 Z"
                    fill={getHeatmapColor("glutes")}
                    stroke={getStrokeColor("glutes")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("glutes")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                </motion.g>

                {/* HAMS/LEGS */}
                <motion.g
                  variants={itemVariants}
                  className="cursor-pointer transition-all duration-300"
                  onMouseEnter={() => setHoveredMuscle("legs")}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  onClick={() => setSelectedDetails(selectedDetails === "legs" ? null : "legs")}
                >
                  <path
                    d="M 76,180 C 65,198 67,215 72,230 L 96,230 C 98,206 98,190 100,180 Z"
                    fill={getHeatmapColor("legs")}
                    stroke={getStrokeColor("legs")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("legs")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                  <path
                    d="M 124,180 C 135,198 133,215 128,230 L 104,230 C 102,206 102,190 100,180 Z"
                    fill={getHeatmapColor("legs")}
                    stroke={getStrokeColor("legs")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("legs")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                </motion.g>

                {/* CALVES */}
                <motion.g
                  variants={itemVariants}
                  className="cursor-pointer transition-all duration-300"
                  onMouseEnter={() => setHoveredMuscle("calves")}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  onClick={() => setSelectedDetails(selectedDetails === "calves" ? null : "calves")}
                >
                  <path
                    d="M 74,234 C 68,245 68,265 77,282 L 85,282 C 88,272 88,242 86,234 Z"
                    fill={getHeatmapColor("calves")}
                    stroke={getStrokeColor("calves")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("calves")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                  <path
                    d="M 126,234 C 132,245 132,265 123,282 L 115,282 C 112,272 112,242 114,234 Z"
                    fill={getHeatmapColor("calves")}
                    stroke={getStrokeColor("calves")}
                    strokeWidth="1.5"
                    filter={getGlowFilter("calves")}
                    className="transition-all duration-300 hover:brightness-125"
                  />
                </motion.g>
              </motion.g>
            )}
          </svg>

          {/* Prompt labels overlay */}
          <div className="absolute top-2 left-2 bg-[#121212]/80 border border-brand-border/60 p-2 rounded-lg text-[9px] text-[#888] font-semibold leading-normal pointer-events-none uppercase">
            <span>💡 Mode: </span>
            <span className="text-brand-accent font-extrabold">HEATMAP ACCENTS</span>
          </div>
        </div>
      </div>

      {/* Interactive Floating / Bottom Muscle Details Panel */}
      <div className="bg-[#0f0f0f] border border-brand-border/70 rounded-2xl p-4 min-h-[140px] flex flex-col justify-center relative transition-all duration-300">
        {activeMuscleData ? (
          <div className="space-y-3.5 animate-fade-in">
            {/* Header info */}
            <div className="flex items-center justify-between border-b border-brand-border/50 pb-2">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-black text-white uppercase tracking-tight">
                    {activeMuscleData.name}
                  </span>
                  <span className="text-[10px] text-brand-accent px-2 py-0.5 bg-brand-accent/10 border border-brand-accent/20 rounded-md font-bold">
                    {activeMuscleData.hindiName}
                  </span>
                </div>
                <div className="text-[9px] text-brand-muted uppercase tracking-widest font-bold">
                  Active volume coverage
                </div>
              </div>

              {/* Total volume indicator */}
              <div className="text-right">
                <span className="text-sm font-black text-[#F3F3F3] block leading-none font-mono">
                  {Math.round(activeMuscleData.totalSets * 10) / 10} Sets
                </span>
                <span className="text-[9px] uppercase tracking-wider text-brand-muted font-bold font-mono">
                  Total Volume
                </span>
              </div>
            </div>

            {/* List of active exercises targeting this muscle */}
            <div className="space-y-2">
              <span className="text-[9px] uppercase tracking-wider font-extrabold text-white block">
                Exercises in Current Session:
              </span>
              
              {activeMuscleData.exercisesList.length === 0 ? (
                <div className="text-[11px] text-neutral-500 py-1.5 px-3 bg-neutral-900 border border-brand-border/40 rounded-lg italic flex items-center gap-1.5 uppercase">
                  <ShieldAlert className="w-3.5 h-3.5 text-zinc-600" />
                  <span>No direct actions targeting this group</span>
                </div>
              ) : (
                <div className="max-h-[90px] overflow-y-auto space-y-1 pr-1 custom-scrollbar">
                  {activeMuscleData.exercisesList.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between bg-zinc-900/60 border border-brand-border/40 px-2.5 py-1.5 rounded-lg text-[10px]"
                    >
                      <div className="flex items-center gap-2 text-white line-clamp-2 break-words">
                        <span className="text-brand-accent shrink-0">🎯</span>
                        <span className="font-bold truncate">{item.name_en}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`text-[8px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded ${
                            item.isPrimary
                              ? "bg-brand-accent/10 text-brand-accent border border-brand-accent/20"
                              : "bg-teal-500/10 text-teal-400 border border-teal-500/20"
                          }`}
                        >
                          {item.isPrimary ? "Primary" : "Secondary"}
                        </span>
                        <span className="font-bold font-mono text-[#888]">({item.sets}s)</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center space-y-1.5 py-4">
            <Activity className="w-6 h-6 text-brand-muted/50 mx-auto animate-pulse" />
            <h4 className="text-[11px] uppercase tracking-widest font-black text-neutral-400">
              Hover/Touch regions
            </h4>
            <p className="text-[10px] text-neutral-500 max-w-[200px] mx-auto uppercase tracking-wider font-medium leading-relaxed">
              Hover muscles on the schematic model above to view volume analysis and targeted list
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
