import { useState, useEffect, useMemo } from "react";
import {
  Flame,
  Calendar,
  Award,
  Activity,
  Dumbbell,
  Clock,
  Trash2,
  ChevronDown,
  ChevronUp,
  Sparkles,
  BookOpen,
  ArrowRight,
  TrendingUp,
  RotateCcw,
  Star,
  CheckCircle,
  HelpCircle,
  ClipboardList,
  Droplet,
  Plus,
  Minus,
  Trophy,
  Zap,
  Lock,
  Sunrise,
  Apple,
  AlertTriangle,
  LayoutList,
  List,
Loader2 } from "lucide-react";
import { CompletedSession } from "../types";
import WorkoutProgressChart from "./WorkoutProgressChart";
import { motion, AnimatePresence } from "motion/react";
import AboutPage from "./AboutPage";
import StatsView from "./StatsView";
import Badges from "./Badges";
import NutritionLog from "./NutritionLog";
import { playSound } from "../utils/audio";
import { useLocalStorageSync } from "../hooks/useLocalStorageSync";
import { ConfirmModal } from "./ConfirmModal";
import { ExerciseLoopPreview } from "./ExerciseLoopPreview";

interface WorkoutHistoryProps {
  history: CompletedSession[];
  onDeleteSession: (id: string) => void;
  onClearAll: () => void;
  onUpdateSession: (updated: CompletedSession) => void;
  onSeedMockData: () => void;
  onNavigateToExercises: () => void;
}

interface IntensityBadge {
  label: string;
  emoji: string;
  style: string;
  description: string;
}

export function getIntensityBadge(duration: number, exercisesCount: number): IntensityBadge {
  if (duration >= 60 || exercisesCount >= 6) {
    return {
      label: "Iron Titan",
      emoji: "🏋️‍♂️",
      style: "text-amber-400 border-amber-500/35 bg-amber-500/10 shadow-[0_0_8px_rgba(234,179,8,0.15)]",
      description: "Ultra intense high-volume routine. True championship performance!"
    };
  } else if (duration >= 40 || exercisesCount >= 4) {
    return {
      label: "Beast Mode",
      emoji: "💪",
      style: "text-red-400 border-red-500/35 bg-red-500/10 shadow-[0_0_8px_rgba(239,68,68,0.15)]",
      description: "Heavy compound load and focused core training."
    };
  } else if (duration >= 20) {
    return {
      label: "Steady Pacer",
      emoji: "🏃‍♂️",
      style: "text-cyan-400 border-cyan-500/35 bg-cyan-500/10 shadow-[0_0_8px_rgba(34,211,238,0.15)]",
      description: "Highly productive moderate-intensity performance."
    };
  } else if (duration > 0) {
    return {
      label: "Quick Burn",
      emoji: "⚡",
      style: "text-yellow-400 border-yellow-500/35 bg-yellow-500/10 shadow-[0_0_8px_rgba(234,179,8,0.15)]",
      description: "Fast-paced fat destruction routine."
    };
  } else {
    return {
      label: "Warmup / Move",
      emoji: "🌱",
      style: "text-emerald-400 border-emerald-500/35 bg-emerald-500/10",
      description: "Active recovery and flexibility development."
    };
  }
}

export default function WorkoutHistory({
  history,
  onDeleteSession,
  onClearAll,
  onUpdateSession,
  onSeedMockData,
  onNavigateToExercises,
}: WorkoutHistoryProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [editingNotesId, setEditingNotesId] = useState<string | null>(null);
  const [notesTempText, setNotesTempText] = useState("");
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [confirmDeleteState, setConfirmDeleteState] = useState<{isOpen: boolean, sessionId: string} | null>(null);
  const [subTab, setSubTab] = useState<"progress" | "stats" | "about" | "badges" | "nutrition">("progress");

  // Sync and track nutrition logs & goals reactively
  const [nutritionLogs, setNutritionLogs] = useLocalStorageSync<Record<string, { protein: number; water: number }>>("fitgenie_nutrition_logs", {});
  const [nutritionGoals] = useLocalStorageSync<{ proteinGoal: number; waterGoal: number }>("fitgenie_nutrition_goals", { proteinGoal: 100, waterGoal: 2500 });

  const [viewMode, setViewMode] = useState<"detailed" | "compact">("detailed");
  const [editingExercise, setEditingExercise] = useState<{ sessionId: string, exIdx: number, weight: number, reps: number } | null>(null);

  const handleSaveExercise = (sessionId: string, exIdx: number, weight: number, reps: number) => {
    const session = history.find(s => s.id === sessionId);
    if (!session) return;
    const updated = { ...session, exercises: [...session.exercises] };
    updated.exercises[exIdx] = { ...updated.exercises[exIdx], weight, reps };
    onUpdateSession(updated);
    setEditingExercise(null);
  };

  const [user] = useLocalStorageSync<{ name: string; target: string; level: string; gender: string; experience: string } | null>("fitgenie_user", null);
  const [animationsEnabled, setAnimationsEnabled] = useLocalStorageSync<boolean>("celebratory_animations_enabled", true);
  const [remindersEnabled, setRemindersEnabled] = useLocalStorageSync<boolean>("fitgenie_reminders_enabled", false);
  const [preferredTime, setPreferredTime] = useLocalStorageSync<string>("fitgenie_preferred_workout_time", "18:00");

  // Dynamic Personal Records (PR) Detector Hook
  const personalRecords = useMemo(() => {
    if (!history || history.length === 0) {
      return {} as Record<string, { type: string; label: string; icon: string; style: string; valueText: string }[]>;
    }

    let maxDuration = 0;
    let maxExercisesCount = 0;
    let maxSingleReps = 0;
    let maxTotalVolume = 0;

    const sessionStats = history.map((session) => {
      const duration = session.totalDurationMin || 0;
      const exCount = session.exercisesCount || 0;
      let singleReps = 0;
      let totalVolume = 0;

      if (session.exercises && session.exercises.length > 0) {
        session.exercises.forEach((ex) => {
          if ((ex.reps || 0) > singleReps) {
            singleReps = ex.reps || 0;
          }
          totalVolume += (ex.sets || 0) * (ex.reps || 0);
        });
      }

      if (duration > maxDuration) maxDuration = duration;
      if (exCount > maxExercisesCount) maxExercisesCount = exCount;
      if (singleReps > maxSingleReps) maxSingleReps = singleReps;
      if (totalVolume > maxTotalVolume) maxTotalVolume = totalVolume;

      return {
        id: session.id,
        duration,
        exCount,
        singleReps,
        totalVolume,
      };
    });

    const recordBadges: Record<string, { type: string; label: string; icon: string; style: string; valueText: string }[]> = {};

    sessionStats.forEach((stat) => {
      const badges: { type: string; label: string; icon: string; style: string; valueText: string }[] = [];

      if (stat.duration > 0 && stat.duration === maxDuration) {
        badges.push({
          type: "duration",
          label: "Longest Session",
          icon: "⏱️",
          style: "text-amber-400 border-amber-500/35 bg-amber-500/10",
          valueText: `${stat.duration} Min`,
        });
      }
      if (stat.exCount > 0 && stat.exCount === maxExercisesCount) {
        badges.push({
          type: "exCount",
          label: "Volume Peak",
          icon: "⚡",
          style: "text-purple-400 border-purple-500/35 bg-purple-500/10",
          valueText: `${stat.exCount} Exercises`,
        });
      }
      if (stat.singleReps > 0 && stat.singleReps === maxSingleReps) {
        badges.push({
          type: "singleReps",
          label: "Max Reps Record",
          icon: "🔥",
          style: "text-emerald-400 border-emerald-500/35 bg-emerald-500/10",
          valueText: `${stat.singleReps} Reps`,
        });
      }
      if (stat.totalVolume > 0 && stat.totalVolume === maxTotalVolume) {
        badges.push({
          type: "totalVolume",
          label: "Iron Mass Record",
          icon: "🏋️‍♂️",
          style: "text-cyan-400 border-cyan-500/35 bg-cyan-500/10",
          valueText: `${stat.totalVolume} Rep-Sets`,
        });
      }

      if (badges.length > 0) {
        recordBadges[stat.id] = badges;
      }
    });

    return recordBadges;
  }, [history]);

  // Extract separate all-time records for user display
  const allTimePRs = useMemo(() => {
    if (!history || history.length === 0) return null;
    let maxDuration = 0;
    let maxExercises = 0;
    let maxReps = 0;
    let maxVol = 0;

    history.forEach((session) => {
      if (session.totalDurationMin > maxDuration) maxDuration = session.totalDurationMin;
      if (session.exercisesCount > maxExercises) maxExercises = session.exercisesCount;
      if (session.exercises) {
        let vol = 0;
        session.exercises.forEach((ex) => {
          if (ex.reps > maxReps) maxReps = ex.reps;
          vol += (ex.sets || 0) * (ex.reps || 0);
        });
        if (vol > maxVol) maxVol = vol;
      }
    });

    return { maxDuration, maxExercises, maxReps, maxVol };
  }, [history]);


  const todayStr = new Date().toISOString().split("T")[0];
  const todayNutrition = nutritionLogs[todayStr] || { protein: 0, water: 0 };
  const currentWater = todayNutrition.water || 0;
  const targetWater = nutritionGoals.waterGoal || 2500;
  
  const waterProgressPercent = Math.min(Math.round((currentWater / targetWater) * 100), 100);
  const currentGlasses = Math.floor(currentWater / 250);
  const targetGlasses = Math.ceil(targetWater / 250);

  const currentProtein = todayNutrition.protein || 0;
  const targetProtein = nutritionGoals.proteinGoal || 100;
  const proteinProgressPercent = Math.min(Math.round((currentProtein / targetProtein) * 100), 100);

  const handleModifyWater = (amountDiff: number) => {
    playSound("click");
    const updated = { ...nutritionLogs };
    const current = updated[todayStr] || { protein: 0, water: 0 };
    const nextWater = Math.max(0, current.water + amountDiff);
    
    updated[todayStr] = {
      ...current,
      water: nextWater
    };
    
    setNutritionLogs(updated);

    // Play a motivational success chime when the goal is newly reached
    if (current.water < targetWater && nextWater >= targetWater) {
      setTimeout(() => playSound("success"), 150);
    }
  };

  const handleModifyProtein = (amountDiff: number) => {
    playSound("click");
    const updated = { ...nutritionLogs };
    const current = updated[todayStr] || { protein: 0, water: 0 };
    const nextProtein = Math.max(0, current.protein + amountDiff);
    
    updated[todayStr] = {
      ...current,
      protein: nextProtein
    };
    
    setNutritionLogs(updated);

    // Play a motivational success chime when the goal is newly reached
    if (current.protein < targetProtein && nextProtein >= targetProtein) {
      setTimeout(() => playSound("success"), 150);
    }
  };

  // Stats computation
  const totalWorkouts = history.length;
  
  const totalMinutes = history.reduce((sum, s) => sum + s.totalDurationMin, 0);
  const totalExercises = history.reduce((sum, s) => sum + s.exercisesCount, 0);

  // Compute Current Streak
  // (Consecutive calendar days where at least 1 workout exists)
  const calculateStreak = () => {
    if (history.length === 0) return 0;
    
    // Extract unique dates as YYYY-MM-DD
    const uniqueDates = Array.from(
      new Set(
        history.map((s) => {
          const dateObj = new Date(s.date);
          return `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, "0")}-${String(dateObj.getDate()).padStart(2, "0")}`;
        })
      )
    ).sort((a, b) => new Date(b).getTime() - new Date(a).getTime()); // sort desc (most recent first)

    let streak = 0;
    const today = new Date();
    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
    
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, "0")}-${String(yesterday.getDate()).padStart(2, "0")}`;

    // If there is no workout today or yesterday, the active streak has broken/is 0
    if (uniqueDates[0] !== todayStr && uniqueDates[0] !== yesterdayStr) {
      return 0;
    }

    let currentCheck = new Date(uniqueDates[0]);
    streak = 1;

    for (let i = 1; i < uniqueDates.length; i++) {
      const prevDate = new Date(uniqueDates[i]);
      // Difference in days
      const diffTime = Math.abs(currentCheck.getTime() - prevDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays === 1) {
        streak++;
        currentCheck = prevDate;
      } else if (diffDays > 1) {
        break; // Streak broken
      }
    }

    return streak;
  };

  const streakCount = calculateStreak();

  // Longest streak calculation dynamically (bestStreak)
  const calculateLongestStreak = (sessions: CompletedSession[]): number => {
    if (sessions.length === 0) return 0;
    const uniqueDates = Array.from(
      new Set(
        sessions.map((s) => {
          const dateObj = new Date(s.date);
          return `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, "0")}-${String(dateObj.getDate()).padStart(2, "0")}`;
        })
      )
    ).sort((a, b) => new Date(a).getTime() - new Date(b).getTime());

    if (uniqueDates.length === 0) return 0;

    let maxStreak = 1;
    let currentStreak = 1;

    for (let i = 1; i < uniqueDates.length; i++) {
      const prev = new Date(uniqueDates[i - 1]);
      const curr = new Date(uniqueDates[i]);
      
      const diffTime = Math.abs(curr.getTime() - prev.getTime());
      const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays === 1) {
        currentStreak++;
        if (currentStreak > maxStreak) {
          maxStreak = currentStreak;
        }
      } else if (diffDays > 1) {
        currentStreak = 1;
      }
    }
    return maxStreak;
  };

  const bestStreak = Math.max(streakCount, calculateLongestStreak(history));

  const hasEarlyMorningWorkout = history.some((s) => {
    const hours = new Date(s.date).getHours();
    return hours >= 4 && hours < 8; // between 4:00 AM and 7:59 AM
  });

  // Weekly distribution chart data (Mon-Sun)
  const getWeeklyDistribution = () => {
    const days = [
      { name: "Mon", count: 0 },
      { name: "Tue", count: 0 },
      { name: "Wed", count: 0 },
      { name: "Thu", count: 0 },
      { name: "Fri", count: 0 },
      { name: "Sat", count: 0 },
      { name: "Sun", count: 0 },
    ];
    
    // Look at past 7 days or map based on day of week
    history.forEach((session) => {
      const dateObj = new Date(session.date);
      let dayIdx = dateObj.getDay(); // 0 is Sunday, 1 is Monday ...
      // Map so 1=Mon, 2=Tue... 0=Sun
      let targetIdx = dayIdx === 0 ? 6 : dayIdx - 1;
      if (targetIdx >= 0 && targetIdx < 7) {
        days[targetIdx].count += 1;
      }
    });

    return days;
  };

  const weeklyData = getWeeklyDistribution();
  const maxSessionsInDay = Math.max(...weeklyData.map((d) => d.count), 1);

  // Edit / Update functions for rating and notes
  const handleSetRating = (session: CompletedSession, rating: number) => {
    onUpdateSession({
      ...session,
      rating,
    });
  };

  const startEditingNotes = (session: CompletedSession) => {
    setEditingNotesId(session.id);
    setNotesTempText(session.notes || "");
  };

  const saveNotes = (session: CompletedSession) => {
    onUpdateSession({
      ...session,
      notes: notesTempText.trim(),
    });
    setEditingNotesId(null);
  };

  // Human date helper
  const formatSessionDate = (dateStr: string) => {
    const dateObj = new Date(dateStr);
    return dateObj.toLocaleDateString("en-US", {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const fiveStarWorkouts = history.filter((s) => s.rating === 5).length;
  const hasLateNightWorkout = history.some((s) => {
    const hours = new Date(s.date).getHours();
    return hours >= 20 || (hours >= 0 && hours < 3); // after 8:00 PM or before 3:00 AM
  });

  const rawBadgesData = [
    {
      id: "pehla_kadam",
      title: "Pehla Kadam",
      isUnlocked: totalWorkouts >= 1,
      icon: "🏆",
      color: "text-emerald-400 border-emerald-500/30 bg-emerald-500/10",
      description: "Log your first workout session (पहला कदम)"
    },
    {
      id: "consistency_warrior",
      title: "Consistency Warrior",
      isUnlocked: bestStreak >= 3,
      icon: "🔥",
      color: "text-orange-400 border-orange-500/30 bg-orange-500/10",
      description: "Reach a 3-day active streak (कंसिस्टेंसी वारियर)"
    },
    {
      id: "consistency_king",
      title: "Consistency King",
      isUnlocked: bestStreak >= 7,
      icon: "⚡",
      color: "text-red-400 border-red-500/30 bg-red-500/10",
      description: "Reach a 7-day active streak (कंसिस्टेंसी किंग)"
    },
    {
      id: "shaktiman",
      title: "Loha (Iron Body)",
      isUnlocked: totalWorkouts >= 5,
      icon: "🛡️",
      color: "text-sky-400 border-sky-500/30 bg-sky-500/10",
      description: "Complete 5 total workouts (लोहा)"
    },
    {
      id: "first_50_workouts",
      title: "Akhara Legend",
      isUnlocked: totalWorkouts >= 50,
      icon: "⭐",
      color: "text-indigo-400 border-indigo-500/30 bg-indigo-500/10",
      description: "Complete 50 total workouts (अखाड़ा लेजेंड)"
    },
    {
      id: "early_bird",
      title: "Subah ka Veer",
      isUnlocked: hasEarlyMorningWorkout,
      icon: "🌅",
      color: "text-amber-400 border-amber-500/30 bg-amber-500/10",
      description: "Workout before 8:00 AM (सुबह का वीर)"
    },
    {
      id: "night_warrior",
      title: "Raat ka Yodha",
      isUnlocked: hasLateNightWorkout,
      icon: "🌙",
      color: "text-purple-400 border-purple-500/30 bg-purple-500/10",
      description: "Workout after 8:00 PM (रात का योद्धा)"
    },
    {
      id: "fivestar_champ",
      title: "Sona (Golden Form)",
      isUnlocked: fiveStarWorkouts >= 3,
      icon: "✨",
      color: "text-yellow-400 border-yellow-500/30 bg-yellow-500/10",
      description: "Log 3 perfect 5-star workouts (सोना)"
    },
    {
      id: "mahavir",
      title: "Mahavir Endurance",
      isUnlocked: totalMinutes >= 120,
      icon: "🏅",
      color: "text-rose-400 border-rose-500/30 bg-rose-500/10",
      description: "Accumulate 120 minutes of training (महावीर)"
    }
  ];

  const unlockedBadges = rawBadgesData.filter((b) => b.isUnlocked);

  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#4DA8FF]/30">
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
         <div className="flex items-center gap-3">
             <div className="p-2.5 bg-white/5 border border-white/10 rounded-xl">
                 <LayoutList className="w-5 h-5 text-[#4DA8FF]" />
             </div>
             <div>
                 <h1 className="text-sm md:text-base font-black text-white uppercase tracking-widest">Workout Logs & Stats</h1>
                 <p className="text-[10px] text-neutral-500 font-bold tracking-widest uppercase mt-0.5">Performance Telemetry</p>
             </div>
         </div>
      </div>
      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative" id="workout-history-page">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#4DA8FF]/5 rounded-full blur-[100px] pointer-events-none" />
          <div className="max-w-4xl mx-auto space-y-8 relative z-10 pb-24">
      <ConfirmModal
        isOpen={!!confirmDeleteState?.isOpen}
        message="Are you sure you want to delete this workout log?"
        onCancel={() => setConfirmDeleteState(null)}
        onConfirm={() => {
          if (confirmDeleteState) {
            onDeleteSession(confirmDeleteState.sessionId);
            setConfirmDeleteState(null);
          }
        }}
      />
      {/* Title Header */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-brand-border pb-5">
        <div className="space-y-1 text-center md:text-left">
          <span className="text-xs uppercase font-extrabold tracking-widest text-brand-accent px-3 py-1 bg-brand-surface border border-brand-border rounded-full inline-flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 fill-brand-accent animate-pulse" /> Workout Tracker
          </span>
          <h2 className="text-3xl md:text-4xl font-black uppercase text-white tracking-tight">
            My Fitness Progress
          </h2>
          <p className="text-brand-muted text-xs uppercase tracking-wider">
            Review completed sessions, check stats, streaks, and reflections
          </p>
        </div>

        {/* Header Tools */}
        {history.length > 0 && (
          <button
            onClick={() => setShowClearConfirm(true)}
            className="px-4 py-2 border border-brand-danger/30 hover:border-brand-danger text-xs uppercase font-extrabold tracking-widest text-red-400 hover:bg-brand-danger/5 rounded-xl transition-all duration-300 flex items-center gap-1.5 cursor-pointer"
            id="btn-clear-history-trigger"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset History</span>
          </button>
        )}
      </div>

      {/* Confirmation Modal to Clear All */}
      <AnimatePresence>
        {showClearConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" id="clear-confirm-modal">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-brand-surface border border-brand-border p-6 rounded-3xl max-w-md w-full text-center space-y-6 relative"
            >
              <div className="w-14 h-14 bg-red-500/10 text-red-500 border border-red-500/20 rounded-full flex items-center justify-center mx-auto text-2xl">
                ⚠️
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black uppercase text-white">Reset All Progress Data?</h3>
                <p className="text-xs text-brand-muted leading-relaxed">
                  This action is permanent and will completely erase your completed workouts log, streak data, and personalized coaching logs.
                </p>
              </div>

              <div className="flex gap-3 justify-center">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="px-5 py-2.5 bg-neutral-800 text-white hover:bg-neutral-700 rounded-xl text-xs uppercase font-extrabold tracking-wider transition-all cursor-pointer"
                  id="btn-confirm-cancel"
                >
                  No, Keep It
                </button>
                <button
                  onClick={() => {
                    onClearAll();
                    setShowClearConfirm(false);
                    setExpandedId(null);
                  }}
                  className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs uppercase font-extrabold tracking-wider transition-all cursor-pointer"
                  id="btn-confirm-reset-all"
                >
                  Yes, Erase Everything
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Tab Segment Selector */}
      <div className="flex bg-[#0A1128] p-1 rounded-xl border border-[#14F1E1]/25 max-w-xl mx-auto sm:mx-0 shrink-0 overflow-x-auto scrollbar-none" id="profile-sub-tabs">
        <button
          onClick={() => {
            playSound("click");
            setSubTab("progress");
          }}
          className={`flex-grow py-2 px-3 text-center text-[10px] uppercase font-black tracking-wider rounded-lg transition-all cursor-pointer whitespace-nowrap ${
            subTab === "progress"
              ? "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_12px_rgba(20,241,225,0.3)]"
              : "text-brand-muted hover:text-white"
          }`}
          id="profile-tab-progress"
        >
          📜 Workout Logs
        </button>
        <button
          onClick={() => {
            playSound("click");
            setSubTab("stats");
          }}
          className={`flex-grow py-2 px-3 text-center text-[10px] uppercase font-black tracking-wider rounded-lg transition-all cursor-pointer whitespace-nowrap ${
            subTab === "stats"
              ? "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_12px_rgba(20,241,225,0.3)]"
              : "text-brand-muted hover:text-white"
          }`}
          id="profile-tab-stats"
        >
          📈 30D Telemetry
        </button>
        <button
          onClick={() => {
            playSound("click");
            setSubTab("badges");
          }}
          className={`flex-grow py-2 px-3 text-center text-[10px] uppercase font-black tracking-wider rounded-lg transition-all cursor-pointer whitespace-nowrap ${
            subTab === "badges"
              ? "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_12px_rgba(20,241,225,0.3)]"
              : "text-brand-muted hover:text-white"
          }`}
          id="profile-tab-badges"
        >
          🏆 PR & Trophies
        </button>
      </div>

      {subTab === "stats" ? (
        <StatsView 
          history={history} 
          onSeedMockData={onSeedMockData} 
          onNavigateToExercises={onNavigateToExercises} 
        />
      ) : subTab === "badges" ? (
        <Badges history={history} streakCount={streakCount} />
      ) : (
        <div className="space-y-6">
          {/* Daily Nutrition Log Card */}
          <div className="bg-brand-surface border border-brand-border p-5 rounded-3xl relative overflow-hidden group transition-all hover:border-brand-accent/25" id="profile-daily-nutrition-card">
            {/* Ambient Water and Metabolic glowing effects */}
            <div className="absolute top-0 right-0 w-36 h-36 bg-blue-500/5 rounded-full blur-2xl pointer-events-none animate-pulse" />
            <div className="absolute bottom-0 left-0 w-36 h-36 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none animate-pulse" />

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-brand-border/40 pb-4 mb-4">
              <div className="space-y-1 text-left">
                <h4 className="text-sm font-black uppercase text-brand-accent tracking-widest flex items-center gap-1.5 font-mono">
                  <Apple className="w-4 h-4 text-brand-accent" />
                  <span>Daily Nutrition Log</span>
                </h4>
                <p className="text-[10px] text-brand-muted uppercase font-mono">
                  Track your recovery fuel and hydration. Resets automatically each day!
                </p>
              </div>
              <span className="text-[9px] uppercase font-black tracking-wider text-[#14F1E1] bg-[#14F1E1]/10 border border-[#14F1E1]/30 py-1 px-3 rounded-lg font-mono">
                ⚡ Synced With Diet & Thali Builder
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 divide-y lg:divide-y-0 lg:divide-x divide-brand-border/30">
              {/* ======= WATER (HYDRATION) COLUMN ======= */}
              <div className="space-y-4 pt-4 lg:pt-0">
                <div className="flex items-center justify-between gap-2 text-left">
                  <div className="flex items-center gap-3">
                    {/* Water rising animation container */}
                    <div className="relative w-12 h-12 bg-neutral-900 border border-brand-border rounded-xl flex items-center justify-center shrink-0 overflow-hidden shadow-inner">
                      <motion.div
                        className="absolute bottom-0 left-0 right-0 bg-blue-500/30"
                        initial={{ height: 0 }}
                        animate={{ height: `${waterProgressPercent}%` }}
                        transition={{ type: "spring", stiffness: 60, damping: 15 }}
                      />
                      <Droplet 
                        className={`w-6 h-6 relative z-10 transition-colors ${
                          waterProgressPercent >= 100 
                            ? "text-blue-300 fill-blue-300/30" 
                            : "text-blue-500 fill-blue-500/10"
                        }`} 
                      />
                    </div>
                    
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] uppercase font-bold tracking-wider text-blue-400 font-mono">💧 Hydration Target</span>
                        {waterProgressPercent >= 100 && (
                          <span className="text-[7.5px] uppercase font-black text-green-400 bg-green-500/15 px-1.5 py-0.5 rounded border border-green-500/20">
                            HIT! 🎉
                          </span>
                        )}
                      </div>
                      <h5 className="text-sm font-black text-white uppercase tracking-tight">
                        {currentWater} ml / {targetWater} ml
                      </h5>
                      <span className="text-[8.5px] text-zinc-500 block font-mono">
                        {currentGlasses} of {targetGlasses} Glasses (250ml units)
                      </span>
                    </div>
                  </div>

                  {/* Actions for Water */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => handleModifyWater(-250)}
                      disabled={currentWater <= 0}
                      className={`w-9 h-9 bg-neutral-900 border border-brand-border rounded-lg flex items-center justify-center transition-all cursor-pointer ${
                        currentWater <= 0 
                          ? "opacity-40 cursor-not-allowed text-zinc-700" 
                          : "text-zinc-400 hover:text-white hover:border-zinc-700 active:scale-95"
                      }`}
                      title="Remove 1 Glass (-250 ml)"
                    >
                      <Minus className="w-4 h-4 font-black" />
                    </button>

                    <button
                      onClick={() => handleModifyWater(250)}
                      className="px-3 h-9 bg-blue-500 text-black hover:bg-blue-400 rounded-lg flex items-center gap-1 text-[10px] sm:text-xs uppercase font-black tracking-widest transition-all shadow-[0_0_10px_rgba(59,130,246,0.2)] hover:shadow-[0_0_15px_rgba(59,130,246,0.4)] active:scale-95 cursor-pointer"
                      title="Drink 1 Glass (+250 ml)"
                    >
                      <Plus className="w-3.5 h-3.5 font-black text-black" />
                      <span>Glass</span>
                    </button>
                  </div>
                </div>

                {/* Progress bar container for Water */}
                <div className="space-y-1 text-left">
                  <div className="flex items-center justify-between text-[8px] uppercase font-mono font-bold tracking-wider text-brand-muted">
                    <span>Water Intake progress</span>
                    <span className="text-blue-400">{waterProgressPercent}% Complete</span>
                  </div>
                  <div className="w-full h-2.5 bg-neutral-900 border border-brand-border rounded-full overflow-hidden p-0.5 shadow-inner">
                    <motion.div
                      className="h-full bg-gradient-to-r from-blue-600 to-blue-400 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${waterProgressPercent}%` }}
                      transition={{ type: "spring", stiffness: 60, damping: 15 }}
                    />
                  </div>
                </div>
              </div>


              {/* ======= PROTEIN (RECOVERY POWER) COLUMN ======= */}
              <div className="space-y-4 pt-4 lg:pt-0 lg:pl-5">
                <div className="flex items-center justify-between gap-1 text-left">
                  <div className="flex items-center gap-3">
                    {/* Protein rising animation container */}
                    <div className="relative w-12 h-12 bg-neutral-900 border border-brand-border rounded-xl flex items-center justify-center shrink-0 overflow-hidden shadow-inner">
                      <motion.div
                        className="absolute bottom-0 left-0 right-0 bg-cyan-500/20"
                        initial={{ height: 0 }}
                        animate={{ height: `${proteinProgressPercent}%` }}
                        transition={{ type: "spring", stiffness: 60, damping: 15 }}
                      />
                      <Flame 
                        className={`w-6 h-6 relative z-10 transition-colors ${
                          proteinProgressPercent >= 100 
                            ? "text-cyan-300 fill-cyan-300/30" 
                            : "text-cyan-500 fill-cyan-500/10"
                        }`} 
                      />
                    </div>
                    
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] uppercase font-bold tracking-wider text-cyan-400 font-mono">💪 Muscle Recovery Goal</span>
                        {proteinProgressPercent >= 100 && (
                          <span className="text-[7.5px] uppercase font-black text-green-400 bg-green-500/15 px-1.5 py-0.5 rounded border border-green-500/20">
                            HIT! 👑
                          </span>
                        )}
                      </div>
                      <h5 className="text-sm font-black text-white uppercase tracking-tight">
                        {currentProtein}g / {targetProtein}g
                      </h5>
                      <span className="text-[8.5px] text-zinc-500 block font-mono">
                        Supports rebuilding broken down fibres
                      </span>
                    </div>
                  </div>

                  {/* Actions for Protein */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => handleModifyProtein(-10)}
                      disabled={currentProtein <= 0}
                      className={`w-9 h-9 bg-neutral-900 border border-brand-border rounded-lg flex items-center justify-center transition-all cursor-pointer ${
                        currentProtein <= 0 
                          ? "opacity-40 cursor-not-allowed text-zinc-700" 
                          : "text-zinc-400 hover:text-white hover:border-zinc-700 active:scale-95"
                      }`}
                      title="Remove 10g Protein"
                    >
                      <Minus className="w-4 h-4 font-black" />
                    </button>

                    <button
                      onClick={() => handleModifyProtein(10)}
                      className="px-3 h-9 bg-cyan-500 text-black hover:bg-cyan-400 rounded-lg flex items-center gap-1 text-[10px] sm:text-xs uppercase font-black tracking-widest transition-all shadow-[0_0_10px_rgba(34,211,238,0.2)] hover:shadow-[0_0_15px_rgba(34,211,238,0.4)] active:scale-95 cursor-pointer"
                      title="Log +10g Protein"
                    >
                      <Plus className="w-3.5 h-3.5 font-black text-black" />
                      <span>+10g</span>
                    </button>
                  </div>
                </div>

                {/* Progress bar container for Protein */}
                <div className="space-y-1 text-left">
                  <div className="flex items-center justify-between text-[8px] uppercase font-mono font-bold tracking-wider text-brand-muted">
                    <span>Protein build progress</span>
                    <span className="text-cyan-400">{proteinProgressPercent}% Complete</span>
                  </div>
                  <div className="w-full h-2.5 bg-neutral-900 border border-brand-border rounded-full overflow-hidden p-0.5 shadow-inner">
                    <motion.div
                      className="h-full bg-gradient-to-r from-cyan-600 to-cyan-400 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${proteinProgressPercent}%` }}
                      transition={{ type: "spring", stiffness: 60, damping: 15 }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bespoke achievements wall overview */}
          <div className="bg-brand-surface border border-brand-border p-5 rounded-3xl relative overflow-hidden group transition-all hover:border-brand-accent/20" id="profile-achievements-quick-wall">
            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />
            
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-brand-border/40 pb-4 mb-4">
              <div className="space-y-1 text-left">
                <h4 className="text-sm font-black uppercase text-brand-accent tracking-widest flex items-center gap-1.5 font-mono">
                  <Trophy className="w-4 h-4 text-brand-accent" />
                  <span>Akhara Trophy & Badge Wall</span>
                </h4>
                <p className="text-[10px] text-brand-muted uppercase">
                  ACTIVE REGISTRATION RECORD SECURED ON LOCALSTORAGE HISTORY
                </p>
              </div>
              <button 
                onClick={() => {
                  playSound("click");
                  setSubTab("badges");
                }}
                className="text-[9.5px] uppercase font-black tracking-wider text-brand-accent hover:text-white bg-brand-accent/15 hover:bg-brand-accent/25 border border-brand-accent/30 py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer"
              >
                View All Achievements &rarr;
              </button>
            </div>

            {/* Quick Badge Milestones Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Milestone 1: Consistency King */}
              <div 
                onClick={() => { playSound("click"); setSubTab("badges"); }}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer relative ${
                  bestStreak >= 7 
                    ? "bg-[#131711] border-red-500/30 hover:border-red-500/50" 
                    : "bg-neutral-900/40 border-brand-border/40 hover:border-[#333]"
                }`}
              >
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${
                    bestStreak >= 7 ? "bg-red-500/10 border-red-500/20" : "bg-neutral-900 border-neutral-800"
                  }`}>
                    {bestStreak >= 7 ? (
                      <Zap className="w-4 h-4 text-red-400 fill-red-400/10 animate-pulse" />
                    ) : (
                      <Lock className="w-3.5 h-3.5 text-neutral-600" />
                    )}
                  </div>
                  <div className="text-left">
                    <h5 className="text-[11px] font-black uppercase tracking-tight text-white flex items-center gap-1">
                      <span>Consistency King</span>
                      {bestStreak >= 7 && <span className="text-[8px] bg-red-500/20 text-red-400 px-1 rounded">ON</span>}
                    </h5>
                    <p className="text-[8px] text-brand-muted uppercase font-mono tracking-wider">
                      Best Streak: {bestStreak} / 7
                    </p>
                  </div>
                </div>
                {/* Micro-progress */}
                <div className="mt-2.5 w-full h-1 bg-neutral-900 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${bestStreak >= 7 ? "bg-red-500" : "bg-neutral-700"}`} 
                    style={{ width: `${Math.min((bestStreak / 7) * 100, 100)}%` }} 
                  />
                </div>
              </div>

              {/* Milestone 2: First 50 Workouts */}
              <div 
                onClick={() => { playSound("click"); setSubTab("badges"); }}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer relative ${
                  totalWorkouts >= 50 
                    ? "bg-[#131711] border-indigo-500/30 hover:border-indigo-500/50" 
                    : "bg-neutral-900/40 border-brand-border/40 hover:border-[#333]"
                }`}
              >
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${
                    totalWorkouts >= 50 ? "bg-indigo-500/10 border-indigo-500/20" : "bg-neutral-900 border-neutral-800"
                  }`}>
                    {totalWorkouts >= 50 ? (
                      <Trophy className="w-4 h-4 text-indigo-400 fill-indigo-400/10" />
                    ) : (
                      <Lock className="w-3.5 h-3.5 text-neutral-600" />
                    )}
                  </div>
                  <div className="text-left">
                    <h5 className="text-[11px] font-black uppercase tracking-tight text-white flex items-center gap-1">
                      <span>50 Workouts</span>
                      {totalWorkouts >= 50 && <span className="text-[8px] bg-indigo-500/20 text-indigo-400 px-1 rounded">LEGEND</span>}
                    </h5>
                    <p className="text-[8px] text-brand-muted uppercase font-mono tracking-wider">
                      Workouts: {totalWorkouts} / 50
                    </p>
                  </div>
                </div>
                {/* Micro-progress */}
                <div className="mt-2.5 w-full h-1 bg-neutral-900 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${totalWorkouts >= 50 ? "bg-indigo-500" : "bg-neutral-700"}`} 
                    style={{ width: `${Math.min((totalWorkouts / 50) * 100, 100)}%` }} 
                  />
                </div>
              </div>

              {/* Milestone 3: Early Bird (workouts before 8 AM) */}
              <div 
                onClick={() => { playSound("click"); setSubTab("badges"); }}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer relative ${
                  hasEarlyMorningWorkout 
                    ? "bg-[#131711] border-amber-500/30 hover:border-amber-500/50" 
                    : "bg-neutral-900/40 border-brand-border/40 hover:border-[#333]"
                }`}
              >
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${
                    hasEarlyMorningWorkout ? "bg-amber-500/10 border-amber-500/20" : "bg-neutral-900 border-neutral-800"
                  }`}>
                    {hasEarlyMorningWorkout ? (
                      <Sunrise className="w-4 h-4 text-amber-400" />
                    ) : (
                      <Lock className="w-3.5 h-3.5 text-neutral-600" />
                    )}
                  </div>
                  <div className="text-left">
                    <h5 className="text-[11px] font-black uppercase tracking-tight text-white flex items-center gap-1">
                      <span>Early Bird</span>
                      {hasEarlyMorningWorkout && <span className="text-[8px] bg-amber-500/20 text-amber-400 px-1 rounded">RISE</span>}
                    </h5>
                    <p className="text-[8px] text-brand-muted uppercase font-mono tracking-wider">
                      Before 8 AM: {hasEarlyMorningWorkout ? "Yes" : "No"}
                    </p>
                  </div>
                </div>
                {/* Micro-progress */}
                <div className="mt-2.5 w-full h-1 bg-neutral-900 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${hasEarlyMorningWorkout ? "bg-amber-500" : "bg-neutral-700"}`} 
                    style={{ width: `${hasEarlyMorningWorkout ? 100 : 0}%` }} 
                  />
                </div>
              </div>
            </div>
          </div>

          {history.length === 0 ? (
        /* ============================== EMPTY STATE ============================== */
        <div className="text-center py-20 bg-brand-surface border border-brand-border rounded-3xl p-8 space-y-8 max-w-2xl mx-auto" id="history-empty-state">
          <div className="relative inline-flex items-center justify-center">
            <div className="w-20 h-20 bg-[#1A1A1A] border border-brand-border rounded-full flex items-center justify-center text-brand-accent animate-pulse">
              <ClipboardList className="w-10 h-10 text-brand-accent/70" />
            </div>
            <div className="absolute -top-1 -right-1 w-6 h-6 bg-brand-accent text-brand-bg rounded-full flex items-center justify-center font-black text-xs">
              0
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-xl font-black uppercase text-white tracking-widest">No Workouts Completed Yet</h3>
            <p className="text-xs text-brand-muted max-w-md mx-auto leading-relaxed uppercase">
              Your generated workouts diary is empty. Generate a bespoke plan, complete the exercises, and save your progress!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-2">
            <button
              onClick={onNavigateToExercises}
              className="px-8 py-4 bg-brand-accent text-brand-bg hover:bg-brand-accent-hover font-extrabold text-xs uppercase tracking-widest rounded-xl transition-all duration-300 shadow-[0_0_20px_rgba(201,243,29,0.3)] hover:scale-[1.03] flex items-center justify-center gap-2 cursor-pointer"
              id="btn-empty-goto-gen"
            >
              <span>View Exercises</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onSeedMockData}
              className="px-6 py-4 bg-brand-card hover:bg-[#1f1f1f] text-brand-accent border border-brand-accent/20 rounded-xl text-xs uppercase font-extrabold tracking-widest transition-all duration-300 hover:border-brand-accent flex items-center justify-center gap-2 cursor-pointer"
              id="btn-seed-sample-history"
            >
              <Sparkles className="w-4 h-4" />
              <span>Seed Sample Sessions</span>
            </button>
          </div>
        </div>
      ) : (
        /* ============================== DASHBOARD CONTENT ============================== */
        <div className="space-y-8" id="history-dashboard">
          {/* Athlete Profile Passport Card */}
          <div className="bg-gradient-to-r from-neutral-950 to-neutral-900 border border-brand-border/80 rounded-3xl p-5 md:p-6 relative overflow-hidden flex flex-col md:flex-row items-stretch justify-between gap-6 shadow-[0_4px_30px_rgba(0,0,0,0.4)]" id="athlete-profile-identity-card">
            {/* Ambient neon backdrop pulse */}
            <div className="absolute -right-10 -bottom-10 w-44 h-44 bg-brand-accent/5 rounded-full blur-3xl pointer-events-none" />
            
            {/* Athlete Bio Details */}
            <div className="flex items-center gap-4 z-10">
              <div className="w-16 h-16 rounded-2xl bg-brand-accent/10 border-2 border-brand-accent/40 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(201,243,29,0.1)] relative">
                <span className="text-3xl">🦁</span>
                <span className="absolute -bottom-1.5 -right-1.5 bg-brand-accent text-brand-bg rounded-md px-1 py-0.5 text-[7px] font-black uppercase tracking-widest font-mono">PRO</span>
              </div>
              
              <div className="text-left space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-black uppercase tracking-wide text-white font-mono">
                    {user?.name || "Bhai / Sher"}
                  </h3>
                  <span className="text-[8px] bg-neutral-800 text-brand-accent border border-brand-accent/20 px-1.5 py-0.5 rounded font-black font-sans uppercase">
                    {user?.level || "Beginner"} Pehelwan
                  </span>
                </div>
                <div className="flex flex-wrap gap-x-3 gap-y-1 text-[9.5px] text-brand-muted uppercase tracking-wider font-semibold">
                  <span className="flex items-center gap-1">🎯 Target: <strong className="text-white">{user?.target || "Fitness"}</strong></span>
                  <span className="flex items-center gap-1">🏋️ Exp: <strong className="text-white">{user?.experience || "Standard"}</strong></span>
                </div>
              </div>
            </div>

            {/* Unlocked Badges Shelf */}
            <div className="flex-1 flex flex-col justify-center gap-2 text-left bg-neutral-950/45 border border-brand-border/40 px-5 py-3.5 rounded-2xl z-10">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-black uppercase tracking-widest text-white font-mono flex items-center gap-1.5">
                  <span>🏆 Unlocked Akhara Badges</span>
                  <span className="text-brand-accent">({unlockedBadges.length} / {rawBadgesData.length})</span>
                </span>
                <button 
                  onClick={() => { playSound("click"); setSubTab("badges"); }} 
                  className="text-[8px] uppercase font-black tracking-wider text-brand-accent hover:underline cursor-pointer"
                >
                  View Details &rarr;
                </button>
              </div>

              {unlockedBadges.length === 0 ? (
                <div className="text-[9.5px] text-neutral-500 italic uppercase py-1">
                  Har ik badge se badhegi shaan bhai! Apni pehli workout complete karo aur unlocked portal daryaft karo!
                </div>
              ) : (
                <div className="flex flex-wrap gap-2 pt-1 max-h-[50px] overflow-y-auto scrollbar-none">
                  {unlockedBadges.map((badge) => (
                    <div 
                      key={badge.id}
                      onClick={() => { playSound("success"); setSubTab("badges"); }}
                      className="inline-flex items-center gap-1.5 bg-[#131711] border border-brand-accent/20 rounded-xl px-2.5 py-1 cursor-pointer hover:scale-105 transition-all text-[10px] font-black uppercase tracking-tight text-white"
                      title={badge.description}
                    >
                      <span className="text-xs">{badge.icon}</span>
                      <span className="text-[8.5px] font-mono text-neutral-300">{badge.title}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Profile Preferences & Settings */}
          <div className="bg-brand-surface border border-brand-border p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4" id="profile-settings-preferences">
            <div className="flex items-center gap-3 text-left">
              <div className="w-10 h-10 rounded-xl bg-brand-accent/10 border border-brand-accent/10 flex items-center justify-center text-brand-accent text-xl shrink-0">
                🎉
              </div>
              <div>
                <h4 className="text-xs uppercase font-black text-white tracking-wide">Celebratory Milestone Animations</h4>
                <p className="text-[10px] text-brand-muted uppercase font-bold tracking-tight">Show confetti and star showers upon workout completion</p>
              </div>
            </div>
            
            <button
              onClick={() => {
                playSound("toggle");
                setAnimationsEnabled(!animationsEnabled);
              }}
              className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                animationsEnabled ? "bg-brand-accent" : "bg-neutral-850"
              }`}
              id="profile-toggle-celebrations"
              title="Toggle Celebratory Confetti & Star Shower Animations"
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  animationsEnabled ? "translate-x-5 bg-[#0C0C0C]" : "translate-x-0"
                }`}
              />
            </button>
          </div>

          {/* Reminder Settings */}
          <div className="bg-brand-surface border border-brand-border p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4" id="profile-settings-reminders">
            <div className="flex flex-col gap-3 flex-1 w-full">
              <div className="flex items-center gap-3 text-left">
                <div className="w-10 h-10 rounded-xl bg-brand-accent/10 border border-brand-accent/10 flex items-center justify-center text-brand-accent text-xl shrink-0">
                  🔔
                </div>
                <div className="flex-1">
                  <h4 className="text-xs uppercase font-black text-white tracking-wide">Daily Push Notifications</h4>
                  <p className="text-[10px] text-brand-muted uppercase font-bold tracking-tight">Gentle reminder if no workout is logged</p>
                </div>
              </div>
              
              <AnimatePresence>
                {remindersEnabled && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }} 
                    animate={{ opacity: 1, height: "auto" }} 
                    exit={{ opacity: 0, height: 0 }}
                    className="flex items-center gap-3 bg-[#0A1128] border border-brand-border/50 p-2.5 rounded-xl ml-12"
                  >
                    <span className="text-[10px] uppercase font-bold text-brand-muted shrink-0">Preferred Time</span>
                    <input 
                      type="time" 
                      value={preferredTime}
                      onChange={(e) => setPreferredTime(e.target.value)}
                      className="bg-transparent text-white text-xs font-black outline-none w-full text-right"
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
            <button
              onClick={() => {
                playSound("toggle");
                const newVal = !remindersEnabled;
                setRemindersEnabled(newVal);
                if (newVal && "Notification" in window) {
                  Notification.requestPermission();
                }
              }}
              className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none sm:self-center self-end ${
                remindersEnabled ? "bg-brand-accent" : "bg-neutral-850"
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  remindersEnabled ? "translate-x-5 bg-[#0C0C0C]" : "translate-x-0"
                }`}
              />
            </button>
          </div>

          {/* Bento Stats Counters Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="history-bento-grid">
            
            {/* Total Workouts */}
            <div className="bg-brand-surface border border-brand-border p-6 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-brand-accent/35 transition-all">
              <div className="absolute top-0 right-0 w-16 h-16 bg-brand-accent/3 rounded-full blur-xl"></div>
              <div className="flex items-center justify-between text-brand-muted">
                <span className="text-[10px] uppercase font-bold tracking-wider">Completed</span>
                <Award className="w-4 h-4 text-brand-accent" />
              </div>
              <div className="mt-4">
                <div className="text-4xl font-black text-white">{totalWorkouts}</div>
                <div className="text-[10px] text-brand-muted uppercase tracking-widest font-black mt-1">Sessions logged</div>
              </div>
            </div>

            {/* Total Minutes */}
            <div className="bg-brand-surface border border-brand-border p-6 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-brand-accent/35 transition-all">
              <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/2 rounded-full blur-xl"></div>
              <div className="flex items-center justify-between text-brand-muted">
                <span className="text-[10px] uppercase font-bold tracking-wider">Total Time</span>
                <Clock className="w-4 h-4 text-blue-400" />
              </div>
              <div className="mt-4">
                <div className="text-4xl font-black text-white">~{totalMinutes}</div>
                <div className="text-[10px] text-brand-muted uppercase tracking-widest font-black mt-1">Minutes Trained</div>
              </div>
            </div>

            {/* Exercises Target */}
            <div className="bg-brand-surface border border-brand-border p-6 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-brand-accent/35 transition-all">
              <div className="absolute top-0 right-0 w-16 h-16 bg-pink-500/2 rounded-full blur-xl"></div>
              <div className="flex items-center justify-between text-brand-muted">
                <span className="text-[10px] uppercase font-bold tracking-wider">Total Reps Set</span>
                <Dumbbell className="w-4 h-4 text-pink-400" />
              </div>
              <div className="mt-4">
                <div className="text-4xl font-black text-white">{totalExercises}</div>
                <div className="text-[10px] text-brand-muted uppercase tracking-widest font-black mt-1">Exercises Done</div>
              </div>
            </div>

            {/* Daily Streak */}
            <div className="bg-brand-surface border border-brand-border p-6 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-brand-accent/40 transition-all">
              <div className="absolute top-0 right-0 w-20 h-20 bg-brand-accent/5 rounded-full blur-xl"></div>
              <div className="flex items-center justify-between text-brand-accent">
                <span className="text-[10px] uppercase font-bold tracking-wider text-brand-muted">Current Streak</span>
                <Flame className="w-5 h-5 fill-brand-accent animate-bounce" />
              </div>
              <div className="mt-4">
                <div className="text-4xl font-black text-brand-accent">{streakCount} Days</div>
                <div className="text-[10px] text-brand-muted uppercase tracking-widest font-black mt-1">
                  {streakCount > 0 ? "🔥 Keep the fire burning!" : "No streak active yet"}
                </div>
              </div>
            </div>

          </div>

          {/* 30-Day D3 Line Chart */}
          <WorkoutProgressChart history={history} />

          {/* Interactive Chart Component and Quick Insights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="history-analytics-block">
            {/* Custom SVG Weekly Chart */}
            <div className="md:col-span-2 bg-brand-surface border border-brand-border p-5 md:p-6 rounded-2xl space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs uppercase font-extrabold tracking-wider text-white">Weekly Exercise Consistency</h3>
                  <p className="text-[10px] text-brand-muted uppercase">workouts logged per calendar day</p>
                </div>
                <TrendingUp className="w-4 h-4 text-brand-accent" />
              </div>

              {/* Chart Visualizer */}
              <div className="pt-4 flex items-end justify-between h-40 border-b border-brand-border/60 pb-2 px-2">
                {weeklyData.map((d, index) => {
                  const barHeightPercent = (d.count / maxSessionsInDay) * 100;
                  return (
                    <div key={d.name} className="flex flex-col items-center gap-2 w-12 group">
                      {/* Tooltip on hover */}
                      <span className="opacity-0 group-hover:opacity-100 transition-opacity bg-[#1A1A1A] border border-brand-border text-[9px] font-black text-brand-accent py-0.5 px-2 rounded-md absolute -translate-y-8 select-none">
                        {d.count} {d.count === 1 ? "workout" : "workouts"}
                      </span>
                      
                      {/* Visual Bar element */}
                      <div className="w-5 bg-neutral-800 rounded-t-md h-28 flex items-end overflow-hidden relative">
                        <div
                          className="w-full bg-gradient-to-t from-brand-accent/60 to-brand-accent transition-all duration-700 rounded-t-md group-hover:lime-glow"
                          style={{ height: `${barHeightPercent}%` }}
                        />
                      </div>
                      
                      {/* Label */}
                      <span className="text-[10px] uppercase tracking-wider text-brand-muted font-bold group-hover:text-white transition-colors">
                        {d.name}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Legend bar */}
              <div className="flex items-center justify-center gap-4 text-[10px] text-brand-muted uppercase pt-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 bg-brand-accent rounded" /> Workouts Logged
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 bg-neutral-800 rounded" /> Rest Days / No Logs
                </span>
              </div>
            </div>

            {/* Desi Fuel & Performance Insights section */}
            <div className="bg-brand-surface border border-brand-border p-5 md:p-6 rounded-2xl flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <div className="flex items-center gap-1 text-brand-accent">
                  <Sparkles className="w-4 h-4 fill-brand-accent" />
                  <h3 className="text-xs uppercase font-extrabold tracking-wider text-white">Desi Genie Coaching</h3>
                </div>
                <p className="text-[11px] text-brand-muted leading-relaxed uppercase">
                  Based on your {totalWorkouts} sessions, the Genie recommends:
                </p>
              </div>

              {/* Coaching Message feedback */}
              <div className="p-3 bg-[#111] border-l-2 border-brand-accent rounded-r-xl space-y-1">
                <h4 className="text-[10px] font-black text-white uppercase text-brand-accent">
                  {streakCount >= 2 ? "🥇 Streak Champion!" : "💪 Keep It Going!"}
                </h4>
                <p className="text-[11px] text-brand-muted leading-relaxed">
                  {streakCount >= 2
                    ? "Fantastic! Consuming dry fruits (Badaam, Kaju, Kishmish) before training provides healthy natural glycogen streams without digestion fatigue."
                    : "Consistency is key. Try setting a reminder. After your next session, consume Kela + Doodh for instant cellular energy."}
                </p>
              </div>

              {/* Personal Records Milestones Mini Dashboard */}
              {allTimePRs && (
                <div className="p-3 bg-[#0c0c0c] rounded-xl border border-brand-border/60 space-y-2">
                  <div className="flex items-center gap-1.5 text-amber-500">
                    <Trophy className="w-3.5 h-3.5" />
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-300">All-Time Personal Records</h4>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div className="p-2 bg-amber-500/5 rounded border border-amber-500/10 flex flex-col justify-between">
                      <span className="text-[#888] uppercase text-[8px] font-bold">⏱️ Peak Session</span>
                      <span className="text-white font-black uppercase text-[11px]">{allTimePRs.maxDuration} Min</span>
                    </div>
                    <div className="p-2 bg-purple-500/5 rounded border border-purple-500/10 flex flex-col justify-between">
                      <span className="text-[#888] uppercase text-[8px] font-bold">⚡ Max Exercises</span>
                      <span className="text-white font-black uppercase text-[11px]">{allTimePRs.maxExercises} Ex</span>
                    </div>
                    <div className="p-2 bg-emerald-500/5 rounded border border-emerald-500/10 flex flex-col justify-between">
                      <span className="text-[#888] uppercase text-[8px] font-bold">🔥 Max Reps Set</span>
                      <span className="text-white font-black uppercase text-[11px]">{allTimePRs.maxReps} reps</span>
                    </div>
                    <div className="p-2 bg-cyan-500/5 rounded border border-cyan-500/10 flex flex-col justify-between">
                      <span className="text-[#888] uppercase text-[8px] font-bold">🏋️ Peak Volume</span>
                      <span className="text-white font-black uppercase text-cyan-400 text-[11px]">{allTimePRs.maxVol} Vol</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Seed status info block */}
              <div className="text-[10px] text-[#666666] uppercase leading-relaxed pt-2 flex items-center justify-between">
                <span>Data stored offline in safe client storage.</span>
              </div>
            </div>
          </div>

          {/* Session Feed List */}
          <div className="space-y-4" id="history-session-feed">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-900 pb-3 mb-2">
              <h3 className="font-extrabold text-sm uppercase tracking-widest text-[#CCCCCC] flex items-center gap-2">
                <span>Workout Log History ({totalWorkouts} total)</span>
              </h3>
              <div className="flex items-center gap-4">
                <div className="flex items-center bg-black/40 rounded-lg p-0.5 border border-brand-border/30">
                  <button
                    onClick={() => { playSound("click"); setViewMode("detailed"); }}
                    className={`p-1.5 rounded-md transition-colors ${
                      viewMode === "detailed"
                        ? "bg-brand-accent/20 text-brand-accent"
                        : "text-brand-muted hover:text-white"
                    }`}
                    title="Detailed Card View"
                  >
                    <LayoutList className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => { playSound("click"); setViewMode("compact"); }}
                    className={`p-1.5 rounded-md transition-colors ${
                      viewMode === "compact"
                        ? "bg-brand-accent/20 text-brand-accent"
                        : "text-brand-muted hover:text-white"
                    }`}
                    title="Compact List View"
                  >
                    <List className="w-4 h-4" />
                  </button>
                </div>
                {viewMode === "detailed" && (
                  <p className="text-[10px] text-brand-muted uppercase font-bold flex items-center gap-1.5 animate-pulse font-mono">
                    <span className="text-red-400 font-extrabold">💡 Gesture:</span>
                    <span>Swipe to delete!</span>
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-3">
              <AnimatePresence mode="popLayout">
                {history.map((session, sIdx) => {
                  const isExpanded = expandedId === session.id;
                  const intensity = getIntensityBadge(session.totalDurationMin || 0, session.exercisesCount || 0);

                  if (viewMode === "compact") {
                    return (
                      <motion.div
                        key={session.id}
                        layout
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                        className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-brand-surface border border-brand-border rounded-xl gap-3 hover:border-brand-accent/30 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-[#222222] border border-brand-border flex items-center justify-center text-xs text-brand-accent font-black shrink-0">
                            {history.length - sIdx}
                          </div>
                          <div className="min-w-0">
                            <p className="text-white font-bold text-sm tracking-wider flex items-center gap-2 truncate">
                              {session.isSmartValidation 
                                ? (session.exercises[0]?.name_en || "Smart Track Session")
                                : `Targeted: ${session.muscles.join(", ")}`}
                            </p>
                            <div className="flex flex-wrap items-center gap-2 text-[10px] text-brand-muted uppercase font-bold mt-0.5">
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {formatSessionDate(session.date)}
                              </span>
                              {session.rating && (
                                <span className="flex items-center gap-0.5 text-brand-accent">
                                  <span>|</span>
                                  <Star className="w-3 h-3 fill-brand-accent ml-1" />
                                  <span>{session.rating}</span>
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 justify-between sm:justify-end border-t sm:border-t-0 border-neutral-800 pt-2 sm:pt-0">
                          <div className="flex items-center gap-3 text-[10px] sm:text-xs text-brand-muted font-mono font-bold uppercase shrink-0">
                            <span className="flex items-center gap-1 bg-neutral-900 px-2 py-1 rounded-md border border-neutral-800"><Dumbbell className="w-3.5 h-3.5 text-brand-accent" /> {session.exercisesCount} Ex</span>
                            <span className="flex items-center gap-1 bg-neutral-900 px-2 py-1 rounded-md border border-neutral-800"><Clock className="w-3.5 h-3.5 text-brand-accent" /> {session.totalDurationMin}m</span>
                          </div>
                          <button
                            onClick={() => {
                              playSound("click");
                              setConfirmDeleteState({ isOpen: true, sessionId: session.id });
                            }}
                            className="p-1.5 text-brand-muted hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors shrink-0"
                            title="Delete Session"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </motion.div>
                    );
                  }

                  return (
                    <motion.div 
                      key={session.id} 
                      layout
                      initial={{ opacity: 0, y: 20, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                      transition={{
                        type: "spring",
                        stiffness: 220,
                        damping: 19,
                        delay: animationsEnabled ? Math.min(sIdx * 0.05, 0.4) : 0,
                      }}
                      className="relative group overflow-hidden rounded-xl" 
                      style={{ touchAction: "pan-y" }}
                    >
                      {/* Swipe Action Indicator Layer */}
                      <div className="absolute inset-0 bg-red-650/15 text-red-400 flex items-center justify-between px-5 rounded-xl select-none z-0">
                        <div className="flex items-center gap-2 font-mono text-[9px] font-black uppercase tracking-widest">
                          <Trash2 className="w-3.5 h-3.5 animate-bounce" />
                          <span>Swipe to Delete Entry</span>
                        </div>
                        <div className="flex items-center gap-2 font-mono text-[9px] font-black uppercase tracking-widest">
                          <span>Swipe to Delete Entry</span>
                          <Trash2 className="w-3.5 h-3.5 animate-bounce" />
                        </div>
                      </div>

                      <motion.div
                        drag="x"
                        dragConstraints={{ left: 0, right: 0 }}
                        dragElastic={0.4}
                        onDragEnd={(event, info) => {
                          if (Math.abs(info.offset.x) > 110) {
                            playSound("click");
                            setConfirmDeleteState({ isOpen: true, sessionId: session.id });
                          }
                        }}
                        className={`bg-brand-surface border rounded-xl overflow-hidden transition-colors duration-300 relative z-10 ${
                          isExpanded
                            ? "border-brand-accent/60 bg-[#161616]"
                            : personalRecords[session.id] && personalRecords[session.id].length > 0
                              ? "border-amber-500/30 hover:border-amber-500/60 bg-gradient-to-r from-brand-surface to-[#201d14]"
                              : "border-brand-border hover:border-brand-accent/30"
                        }`}
                      >
                    {/* Header bar row */}
                    <div className="p-4 md:p-5 flex items-center justify-between gap-4 cursor-pointer select-none" onClick={() => setExpandedId(isExpanded ? null : session.id)}>
                      
                      {/* Left Info */}
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-[#222222] border border-brand-border flex items-center justify-center text-xs text-brand-accent font-black relative">
                          {totalWorkouts - sIdx}
                          {personalRecords[session.id] && personalRecords[session.id].length > 0 && (
                            <span className="absolute -top-1.5 -right-1.5 text-[9px] animate-pulse w-4 h-4 bg-amber-500 text-neutral-950 rounded-full flex items-center justify-center font-black shadow-[0_0_8px_rgba(245,158,11,0.5)]">👑</span>
                          )}
                        </div>
 
                        <div>
                          <div className="text-[11px] text-brand-muted uppercase font-bold flex flex-wrap items-center gap-x-2 gap-y-0.5">
                            <span>{formatSessionDate(session.date)}</span>
                            {session.rating && (
                              <span className="flex items-center gap-0.5 text-brand-accent text-[10px]" title={`Self Rating: ${session.rating}/5 stars`}>
                                <span className="text-xs">|</span>
                                <span className="flex">
                                  {Array.from({ length: 5 }).map((_, i) => (
                                    <Star
                                      key={i}
                                      className={`w-2.5 h-2.5 ${i < (session.rating || 0) ? "text-brand-accent fill-brand-accent" : "text-neutral-700"}`}
                                    />
                                  ))}
                                </span>
                              </span>
                            )}
                          </div>
                          
                          {session.isSmartValidation ? (
                            <h4 className="text-sm md:text-base font-black text-white uppercase mt-0.5 tracking-tight flex items-center gap-1.5 flex-wrap">
                              <span className="bg-brand-accent/20 text-brand-accent border border-brand-accent/50 px-1.5 py-0.5 rounded text-[8px] tracking-widest">SMART TRACK</span>
                              {session.exercises[0]?.name_en || "Exercise"}
                            </h4>
                          ) : (
                            <h4 className="text-sm md:text-base font-black text-white uppercase mt-0.5 tracking-tight">
                              Targeted: {session.muscles.join(", ")}
                            </h4>
                          )}
 
                          <div className="flex flex-wrap items-center gap-1.5 mt-2">
                            <span 
                              className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[8.5px] font-black uppercase tracking-wider pointer-events-none ${intensity.style}`} 
                              title={intensity.description}
                            >
                              <span>{intensity.emoji}</span>
                              <span>{intensity.label}</span>
                            </span>
 
                            {/* Personal Record (PR) Badges */}
                            {personalRecords[session.id]?.map((badge) => (
                              <span
                                key={badge.type}
                                className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border text-[8.5px] font-black uppercase tracking-wider pointer-events-none ${badge.style} shadow-[0_0_10px_rgba(245,158,11,0.1)]`}
                                title={`Personal Record: ${badge.label} (${badge.valueText})`}
                              >
                                <span>{badge.icon}</span>
                                <span className="text-white">{badge.label}</span>
                                <span>{badge.valueText}</span>
                              </span>
                            ))}
 
                            {/* Mobile responsive helper stats pills visible only on mobile/small screens */}
                            <span className="sm:hidden bg-[#111] px-2 py-0.5 rounded text-[8px] font-mono font-black uppercase text-brand-muted border border-brand-border">
                              {session.exercisesCount} Exercises
                            </span>
                            <span className="sm:hidden bg-[#111] px-2 py-0.5 rounded text-[8px] font-mono font-black uppercase text-brand-muted border border-brand-border">
                              ~{session.totalDurationMin} Min
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      {/* Right Details Indicators */}
                      <div className="flex items-center gap-4">
                        {/* Compact Stats */}
                        <div className="hidden sm:flex items-center gap-3 text-xs">
                          <span className="bg-brand-card py-1 px-2.5 rounded-lg border border-brand-border text-brand-muted uppercase tracking-widest text-[9px] font-black">
                            {session.exercisesCount} Exercises
                          </span>
                          <span className="bg-brand-card py-1 px-2.5 rounded-lg border border-brand-border text-brand-muted uppercase tracking-widest text-[9px] font-black">
                            ~{session.totalDurationMin} Min
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          {/* Trash Delete */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setConfirmDeleteState({ isOpen: true, sessionId: session.id });
                            }}
                            className="p-1.5 text-neutral-500 hover:text-red-400 bg-black/30 hover:bg-red-500/10 border border-brand-border hover:border-red-500/20 rounded-lg transition-colors cursor-pointer"
                            title="Delete completed workout entry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>

                          {/* Expand Toggle Chevron */}
                          <div className="text-neutral-500">
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4 text-brand-accent" />
                            ) : (
                              <ChevronDown className="w-4 h-4" />
                            )}
                          </div>
                        </div>

                      </div>

                    </div>

                    {/* Expandable exercises log details and notes reflections */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          className="border-t border-brand-border bg-black/40 p-4 md:p-5 space-y-5"
                        >
                          {/* Exercises checklist log */}
                          <div className="space-y-2">
                            <h5 className="text-[10px] uppercase font-black tracking-widest text-[#999999] flex items-center gap-1">
                              <Dumbbell className="w-3 h-3 text-brand-accent" />
                              <span>{session.isSmartValidation ? "Smart Verification Stats" : "Exercises Completed"}</span>
                            </h5>
                            
                            {session.isSmartValidation ? (
                               <div className="p-4 bg-[#121212] border border-brand-border/60 rounded-xl grid grid-cols-1 md:grid-cols-[1fr_195px] gap-4 items-center">
                                 <div className="space-y-3">
                                   <div className="flex justify-between items-center pb-3 border-b border-brand-border/30">
                                     <div className="space-y-1">
                                       <span className="text-[10px] text-neutral-400 uppercase font-bold tracking-widest block">Goal Match</span>
                                       <span className="text-xl font-black font-mono text-white">{session.completedReps} <span className="text-xs text-neutral-500">/ {session.targetReps} Reps</span></span>
                                     </div>
                                     <div className="text-right space-y-1">
                                       <span className="text-[10px] text-neutral-400 uppercase font-bold tracking-widest block">Progress</span>
                                       <span className={`text-xl font-black font-mono ${session.unverified ? "text-red-400" : "text-brand-accent"}`}>{session.progressPercentage}%</span>
                                     </div>
                                   </div>
                                   {session.unverified && (
                                     <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-[10px] p-2 rounded-lg font-bold uppercase tracking-wider flex items-center gap-2">
                                       <AlertTriangle className="w-3 h-3" />
                                       Flagged: Unusual result logged (Unverified)
                                     </div>
                                   )}
                                 </div>
                                 <ExerciseLoopPreview
                                   name={session.exercises[0]?.name_en || "Workout"}
                                   muscles={session.muscles}
                                   equipment={session.equipment}
                                   compact
                                 />
                               </div>
                            ) : (
                              <div className="grid grid-cols-1 gap-3">
                                {session.exercises.map((ex, exIdx) => (
                                  <div
                                    key={ex.id || exIdx}
                                    className="p-3 bg-[#121212] border border-brand-border/60 rounded-xl flex flex-col justify-between text-xs cursor-pointer hover:border-brand-accent/30 transition-colors gap-3"
                                    onClick={() => {
                                      if (editingExercise?.sessionId !== session.id || editingExercise?.exIdx !== exIdx) {
                                        setEditingExercise({ sessionId: session.id, exIdx, weight: ex.weight || 0, reps: ex.reps });
                                      }
                                    }}
                                  >
                                    <div className="grid grid-cols-1 sm:grid-cols-[1fr_185px] gap-3 items-center">
                                      <div className="flex items-center justify-between gap-2">
                                        <div className="flex items-center gap-2.5">
                                          <span className="w-5 h-5 bg-brand-accent/10 rounded-full border border-brand-accent/20 flex items-center justify-center text-[9px] text-brand-accent font-black shrink-0">
                                            {exIdx + 1}
                                          </span>
                                          <div>
                                            <p className="font-bold text-white text-sm">{ex.name_en}</p>
                                            <p className="text-[10px] text-brand-muted">{ex.name_hi}</p>
                                          </div>
                                        </div>
                                        {!(editingExercise?.sessionId === session.id && editingExercise?.exIdx === exIdx) && (
                                          <div className="text-right shrink-0">
                                            <span className="text-[11px] font-mono font-black text-brand-accent uppercase bg-brand-accent/10 border border-brand-accent/20 px-2 py-0.5 rounded-md">
                                              {ex.sets}s × {ex.reps}r {ex.weight ? `@ ${ex.weight}kg` : ''}
                                            </span>
                                          </div>
                                        )}
                                      </div>

                                      {/* Responsive Looping GIF / Video Preview Column */}
                                      <ExerciseLoopPreview
                                        name={ex.name_en}
                                        muscles={session.muscles}
                                        equipment={session.equipment}
                                        compact
                                      />
                                    </div>
                                    
                                    {(editingExercise?.sessionId === session.id && editingExercise?.exIdx === exIdx) && (
                                      <div className="pt-3 border-t border-brand-border/40 flex items-end gap-2" onClick={e => e.stopPropagation()}>
                                        <div className="flex-1">
                                          <label className="text-[9px] text-brand-muted uppercase font-bold tracking-widest block mb-1">Reps per set</label>
                                          <input 
                                            type="number" 
                                            className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg px-2 py-2 text-white font-mono focus:border-brand-accent outline-none"
                                            value={editingExercise.reps}
                                            onChange={e => setEditingExercise(prev => prev ? {...prev, reps: Number(e.target.value)} : null)}
                                          />
                                        </div>
                                        <div className="flex-1">
                                          <label className="text-[9px] text-brand-muted uppercase font-bold tracking-widest block mb-1">Weight (kg)</label>
                                          <input 
                                            type="number" 
                                            className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg px-2 py-2 text-white font-mono focus:border-brand-accent outline-none"
                                            value={editingExercise.weight}
                                            onChange={e => setEditingExercise(prev => prev ? {...prev, weight: Number(e.target.value)} : null)}
                                          />
                                        </div>
                                        <div className="flex gap-2 ml-2 pb-0.5">
                                          <button 
                                            onClick={(e) => { e.stopPropagation(); setEditingExercise(null); }}
                                            className="px-3 py-2 rounded-lg bg-[#222] text-white hover:bg-[#333] transition-colors font-bold uppercase tracking-widest text-[10px]"
                                          >
                                            Cancel
                                          </button>
                                          <button 
                                            onClick={(e) => { e.stopPropagation(); handleSaveExercise(session.id, exIdx, editingExercise.weight, editingExercise.reps); }}
                                            className="px-3 py-2 rounded-lg bg-brand-accent text-brand-bg hover:bg-white transition-colors font-bold uppercase tracking-widest text-[10px]"
                                          >
                                            Save
                                          </button>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>

                          {/* Detailed rating feedback inputs and personal diary notes */}
                          <hr className="border-brand-border/40" />

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            
                            {/* Star Rating Selection */}
                            <div className="p-4 bg-[#111111] rounded-xl border border-brand-border/55 space-y-2.5">
                              <div>
                                <h6 className="text-[10px] uppercase font-black tracking-widest text-brand-accent">
                                  Workout Performance Effort
                                </h6>
                                <p className="text-[10px] text-brand-muted uppercase">Rate how demanding your muscles felt</p>
                              </div>

                              <div className="flex items-center gap-2 pt-1">
                                {Array.from({ length: 5 }).map((_, i) => {
                                  const ratingValue = i + 1;
                                  const isSelected = ratingValue <= (session.rating || 0);
                                  return (
                                    <button
                                      key={i}
                                      onClick={() => handleSetRating(session, ratingValue)}
                                      className="p-1 border border-brand-border hover:border-brand-accent rounded-lg transition-colors cursor-pointer relative group"
                                      title={`Rate ${ratingValue} of 5 stars`}
                                    >
                                      <Star
                                        className={`w-6 h-6 ${
                                          isSelected ? "text-brand-accent fill-brand-accent" : "text-neutral-700"
                                        }`}
                                      />
                                    </button>
                                  );
                                })}
                                <span className="text-xs font-black text-white pl-1 uppercase font-mono">
                                  {session.rating ? `${session.rating}/5 stars` : "No rating"}
                                </span>
                              </div>
                            </div>

                            {/* Custom Diary Notes Area */}
                            <div className="p-4 bg-[#111111] rounded-xl border border-brand-border/55 space-y-2.5">
                              <div className="flex items-center justify-between">
                                <div>
                                  <h6 className="text-[10px] uppercase font-black tracking-widest text-white">
                                    Workout Notes & Personal Reflections
                                  </h6>
                                  <p className="text-[10px] text-brand-muted uppercase">Add target sets, fatigue, diet reflections</p>
                                </div>
                                {editingNotesId !== session.id && (
                                  <button
                                    onClick={() => startEditingNotes(session)}
                                    className="text-[9px] uppercase tracking-widest text-brand-accent hover:underline font-bold cursor-pointer"
                                  >
                                    {session.notes ? "Edit Note" : "Write Custom Note"}
                                  </button>
                                )}
                              </div>

                              {editingNotesId === session.id ? (
                                <div className="space-y-2">
                                  <textarea
                                    value={notesTempText}
                                    onChange={(e) => setNotesTempText(e.target.value)}
                                    placeholder="e.g. Completed all sets on Chest Flyes. Felt solid physical connection. Drank banana shake afterwards..."
                                    className="w-full bg-[#1A1A1A] border border-brand-border rounded-xl p-2 text-xs text-white focus:outline-none focus:border-brand-accent"
                                    rows={3}
                                  />
                                  <div className="flex gap-2 justify-end">
                                    <button
                                      onClick={() => setEditingNotesId(null)}
                                      className="px-3 py-1 bg-zinc-800 text-white rounded-lg text-[10px] uppercase font-bold"
                                    >
                                      Cancel
                                    </button>
                                    <button
                                      onClick={() => saveNotes(session)}
                                      className="px-3 py-1 bg-brand-accent text-brand-bg rounded-lg text-[10px] uppercase font-black"
                                    >
                                      Save Note
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div className="text-xs text-brand-muted italic min-h-[40px] flex items-center">
                                  {session.notes ? (
                                    <span className="text-white font-normal not-italic">{session.notes}</span>
                                  ) : (
                                    <span>No notes recorded for this session. Log details for later evaluation.</span>
                                  )}
                                </div>
                              )}
                            </div>

                          </div>

                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                </motion.div>
                );
              })}
            </AnimatePresence>
            </div>
          </div>
        </div>
      )}
        </div>
      )}
          </div>
      </div>
    </div>
  );
}
