import { motion } from "motion/react";

interface FormAnimationProps {
  mainMuscle: string;
  phase: "stretch" | "squeeze";
  equipment: string;
}

export function FormAnimation({ mainMuscle, phase, equipment }: FormAnimationProps) {
  const isSqueeze = phase === "squeeze";

  // Biomechanical coordinate calculators for different anatomical blueprints
  const renderArmAnimation = (isTriceps: boolean) => {
    // Shoulder is fixed
    const shoulderX = 100;
    const shoulderY = 55;

    // Elbow is fixed
    const elbowX = 100;
    const elbowY = 105;

    // Wrist moves along an arc tracking curl or extension
    // Bicep Squeeze -> wrist is high (bent elbow)
    // Bicep Stretch -> wrist is low (straight elbow)
    // Tricep Squeeze -> wrist is low (full lockout extension)
    // Tricep Stretch -> wrist is high (bent elbow at forehead)
    let wristX = 100;
    let wristY = 160;

    if (isTriceps) {
      // Triceps: squeeze is locked out straight down or forward, stretch is close to shoulder
      wristX = isSqueeze ? 100 : 135;
      wristY = isSqueeze ? 160 : 85;
    } else {
      // Biceps/Pulls: squeeze is bent elbow, stretch is straight down
      wristX = isSqueeze ? 135 : 100;
      wristY = isSqueeze ? 80 : 160;
    }

    const isBicepActive = !isTriceps && isSqueeze;
    const isTricepActive = isTriceps && isSqueeze;

    return (
      <svg className="w-full h-full" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Anatomical background grids */}
        <circle cx="100" cy="105" r="55" stroke="#333" strokeDasharray="3 3" className="opacity-40" />

        {/* Highlight Zone Glow */}
        {isBicepActive && (
          <circle cx="112" cy="72" r="16" fill="rgba(239, 68, 68, 0.15)" className="animate-pulse" />
        )}
        {isTricepActive && (
          <circle cx="85" cy="85" r="16" fill="rgba(6, 182, 212, 0.15)" className="animate-pulse" />
        )}

        {/* Shoulder stabilizer anchor */}
        <line x1={shoulderX - 15} y1={shoulderY} x2={shoulderX + 15} y2={shoulderY} stroke="#444" strokeWidth="2" />
        <circle cx={shoulderX} cy={shoulderY} r="5" fill="#555" />

        {/* Humerus (Upper arm) */}
        <line x1={shoulderX} y1={shoulderY} x2={elbowX} y2={elbowY} stroke="#888" strokeWidth="5" strokeLinecap="round" />

        {/* Bicep Muscle (front of humerus) */}
        <motion.path
          d="M 100 58 Q 115 80 100 102"
          stroke={isBicepActive ? "#EF4444" : "#444"}
          strokeWidth={isBicepActive ? "11" : "4"}
          strokeLinecap="round"
          animate={{ strokeWidth: isBicepActive ? 11 : 4 }}
          transition={{ duration: 0.8 }}
        />
        {/* Tricep Muscle (back of humerus) */}
        <motion.path
          d="M 100 58 Q 85 80 100 102"
          stroke={isTricepActive ? "#22D3EE" : "#444"}
          strokeWidth={isTricepActive ? "11" : "4"}
          strokeLinecap="round"
          animate={{ strokeWidth: isTricepActive ? 11 : 4 }}
          transition={{ duration: 0.8 }}
        />

        {/* Elbow Joint (Hinge point) */}
        <circle cx={elbowX} cy={elbowY} r="6" fill="#3B82F6" stroke="#111" strokeWidth="2" />

        {/* Forearm bone */}
        <motion.line
          x1={elbowX}
          y1={elbowY}
          x2={wristX}
          y2={wristY}
          stroke="#CCC"
          strokeWidth="4"
          strokeLinecap="round"
          animate={{ x2: wristX, y2: wristY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />

        {/* Hand Joint */}
        <motion.circle
          cx={wristX}
          cy={wristY}
          r="4.5"
          fill="#3B82F6"
          animate={{ cx: wristX, cy: wristY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />

        {/* Dumbbell or Cable Handle */}
        {equipment === "dumbbells" && (
          <motion.g
            animate={{ x: wristX - 100, y: wristY - 100 }}
            transition={{ type: "spring", stiffness: 90, damping: 15 }}
          >
            {/* Dumbbell shaft */}
            <line x1="88" y1="100" x2="112" y2="100" stroke="#FFF" strokeWidth="3" />
            {/* Dumbbell plates */}
            <rect x="84" y="90" width="4" height="20" rx="1" fill="#C9F31D" />
            <rect x="80" y="93" width="4" height="14" rx="1" fill="#A8D314" />
            <rect x="112" y="90" width="4" height="20" rx="1" fill="#C9F31D" />
            <rect x="116" y="93" width="4" height="14" rx="1" fill="#A8D314" />
          </motion.g>
        )}

        {/* Biomechanical angles & data overlay inside SVG */}
        <motion.text
          x="145"
          y="155"
          fill="#888"
          fontSize="8"
          fontFamily="monospace"
          fontWeight="bold"
        >
          {isSqueeze ? "FLEX: Peak 165°" : "STRETCH: 80°"}
        </motion.text>
      </svg>
    );
  };

  const renderSquatAnimation = () => {
    // Floor level
    const floorY = 165;

    // Ankle is fixed just above floor
    const ankleX = 110;
    const ankleY = 155;

    // Animate Hips, Knees, and Shoulders depending on Squat depth
    // Squat Stretch = Fully down (bent knees, hips set back)
    // Squat Squeeze = Standing tall (straight knees, pelvis forward)
    const kneeX = isSqueeze ? 112 : 142;
    const kneeY = isSqueeze ? 115 : 128;

    const hipX = isSqueeze ? 82 : 68;
    const hipY = isSqueeze ? 76 : 118;

    const shoulderX = isSqueeze ? 80 : 78;
    const shoulderY = isSqueeze ? 32 : 72;

    const quadHighlighted = !isSqueeze; // quads loaded heavily under stretch/load

    return (
      <svg className="w-full h-full" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Floor platform */}
        <line x1="20" y1={floorY} x2="180" y2={floorY} stroke="#333" strokeWidth="4" strokeLinecap="round" />
        <line x1="20" y1={floorY + 4} x2="180" y2={floorY + 4} stroke="#111" strokeWidth="2" strokeDasharray="4 4" />

        {/* Stable Foot base anchor */}
        <line x1={ankleX - 10} y1={ankleY + 10} x2={ankleX + 20} y2={ankleY + 10} stroke="#FFF" strokeWidth="3" />
        <circle cx={ankleX} cy={ankleY + 10} r="4" fill="#3B82F6" />

        {/* Quad/Hamstring Tension Aura */}
        {quadHighlighted && (
          <path
            d={`M ${hipX} ${hipY} Q ${(hipX + kneeX)/2 - 12} ${(hipY + kneeY)/2} ${kneeX} ${kneeY}`}
            stroke="rgba(239, 68, 68, 0.2)"
            strokeWidth="15"
            strokeLinecap="round"
            className="animate-pulse"
          />
        )}

        {/* Shin (Ankle to Knee) */}
        <motion.line
          x1={ankleX}
          y1={ankleY}
          x2={kneeX}
          y2={kneeY}
          stroke="#CCC"
          strokeWidth="4.5"
          strokeLinecap="round"
          animate={{ x2: kneeX, y2: kneeY }}
          transition={{ type: "spring", stiffness: 80, damping: 14 }}
        />

        {/* Thigh / Femur (Knee to Hip) */}
        <motion.line
          x1={kneeX}
          y1={kneeY}
          x2={hipX}
          y2={hipY}
          stroke="#AAA"
          strokeWidth="5"
          strokeLinecap="round"
          animate={{ x1: kneeX, y1: kneeY, x2: hipX, y2: hipY }}
          transition={{ type: "spring", stiffness: 80, damping: 14 }}
        />

        {/* Loaded active muscle (Quad highlighted in red during squeeze/stretch transition) */}
        <motion.path
          d={`M ${kneeX} ${kneeY} Q ${(kneeX + hipX)/2 + 5} ${(kneeY + hipY)/2 - 10} ${hipX} ${hipY}`}
          stroke={quadHighlighted ? "#EF4444" : "#444"}
          strokeWidth={quadHighlighted ? "9" : "4"}
          strokeLinecap="round"
          animate={{
            d: `M ${kneeX} ${kneeY} Q ${(kneeX + hipX)/2 + 5} ${(kneeY + hipY)/2 - 10} ${hipX} ${hipY}`,
            strokeWidth: quadHighlighted ? 9 : 4
          }}
          transition={{ duration: 0.8 }}
        />

        {/* Torso/Spine (Hip to Head/Shoulder) */}
        <motion.line
          x1={hipX}
          y1={hipY}
          x2={shoulderX}
          y2={shoulderY}
          stroke="#FFF"
          strokeWidth="5.5"
          strokeLinecap="round"
          animate={{ x1: hipX, y1: hipY, x2: shoulderX, y2: shoulderY }}
          transition={{ type: "spring", stiffness: 80, damping: 14 }}
        />

        {/* Knee Joint pivot */}
        <motion.circle
          cx={kneeX}
          cy={kneeY}
          r="5"
          fill="#3B82F6"
          stroke="#111"
          strokeWidth="1.5"
          animate={{ cx: kneeX, cy: kneeY }}
          transition={{ type: "spring", stiffness: 80, damping: 14 }}
        />

        {/* Hip Joint pivot */}
        <motion.circle
          cx={hipX}
          cy={hipY}
          r="5"
          fill="#3B82F6"
          stroke="#111"
          strokeWidth="1.5"
          animate={{ cx: hipX, cy: hipY }}
          transition={{ type: "spring", stiffness: 80, damping: 14 }}
        />

        {/* Head representation */}
        <motion.circle
          cx={shoulderX + (isSqueeze ? 0 : 5)}
          cy={shoulderY - 14}
          r="10"
          fill="#FFF"
          stroke="#444"
          strokeWidth="1"
          animate={{ cx: shoulderX + (isSqueeze ? 0 : 5), cy: shoulderY - 14 }}
          transition={{ type: "spring", stiffness: 80, damping: 14 }}
        />

        {/* Barbell on back for Squat loading profile */}
        {equipment === "barbell" && (
          <motion.g
            animate={{ x: shoulderX - 80, y: shoulderY - 7 }}
            transition={{ type: "spring", stiffness: 80, damping: 14 }}
          >
            {/* Barbell metal rod */}
            <line x1="45" y1="0" x2="115" y2="0" stroke="#777" strokeWidth="3" />
            <rect x="40" y="-10" width="5" height="20" rx="1" fill="#C9F31D" />
            <rect x="33" y="-8" width="7" height="16" rx="1" fill="#A8D314" />
            <rect x="115" y="-10" width="5" height="20" rx="1" fill="#C9F31D" />
            <rect x="120" y="-8" width="7" height="16" rx="1" fill="#A8D314" />
          </motion.g>
        )}

        {/* Squat depth lines */}
        <line x1="30" y1="128" x2="170" y2="128" stroke="#EF4444" strokeWidth="1" strokeDasharray="3 3" className="opacity-60" />
        <text x="35" y="124" fill="#EF4444" fontSize="6" fontFamily="monospace" fontWeight="bold">OP-PARALLEL TARGET</text>
      </svg>
    );
  };

  const renderPressAnimation = () => {
    // Horizontal view of chest press
    // Torso lying down flat on a bench
    const benchY = 120;
    const chestY = 95;

    // Squeeze: weights are high up (straight arms)
    // Stretch: weights are heavy on chest (bent elbows)
    const weightY = isSqueeze ? 40 : 90;
    // Elbow flare outward
    const elbowLeftX = isSqueeze ? 80 : 55;
    const elbowRightX = isSqueeze ? 120 : 145;
    const elbowY = isSqueeze ? 68 : 108;

    const chestHighlighted = isSqueeze;

    return (
      <svg className="w-full h-full" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Bench base support frame */}
        <rect x="60" y={benchY} width="80" height="8" rx="2" fill="#222" stroke="#444" />
        <line x1="100" y1={benchY + 8} x2="100" y2="170" stroke="#333" strokeWidth="6" />
        <line x1="70" y1="170" x2="130" y2="170" stroke="#333" strokeWidth="4" />

        {/* Torso profile (Chest segment lying flat) */}
        <rect x="65" y={chestY} width="70" height="24" rx="4" fill="#181818" stroke="#333" strokeWidth="1.5" />

        {/* Glowing Chest Core pectoral muscle load indicator */}
        <motion.rect
          x="75"
          y={chestY + 2}
          width="50"
          height="12"
          rx="2"
          fill={chestHighlighted ? "rgba(201, 243, 29, 0.12)" : "rgba(59, 130, 246, 0.05)"}
          stroke={chestHighlighted ? "#C9F31D" : "#444"}
          strokeWidth="1.5"
          animate={{
            fill: chestHighlighted ? "rgba(201, 243, 29, 0.15)" : "rgba(59, 130, 246, 0.05)",
            stroke: chestHighlighted ? "#C9F31D" : "#444"
          }}
          transition={{ duration: 0.8 }}
        />

        {/* Left Arm Skeletal Links (Shoulder: 75, 105) */}
        {/* Upper arm */}
        <motion.line
          x1="75"
          y1="105"
          x2={elbowLeftX}
          y2={elbowY}
          stroke="#888"
          strokeWidth="4"
          strokeLinecap="round"
          animate={{ x2: elbowLeftX, y2: elbowY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />
        {/* Forearm */}
        <motion.line
          x1={elbowLeftX}
          y1={elbowY}
          x2="75"
          y2={weightY}
          stroke="#CCC"
          strokeWidth="3.5"
          strokeLinecap="round"
          animate={{ x1: elbowLeftX, y1: elbowY, y2: weightY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />

        {/* Right Arm Skeletal Links (Shoulder: 125, 105) */}
        {/* Upper arm */}
        <motion.line
          x1="125"
          y1="105"
          x2={elbowRightX}
          y2={elbowY}
          stroke="#888"
          strokeWidth="4"
          strokeLinecap="round"
          animate={{ x2: elbowRightX, y2: elbowY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />
        {/* Forearm */}
        <motion.line
          x1={elbowRightX}
          y1={elbowY}
          x2="125"
          y2={weightY}
          stroke="#CCC"
          strokeWidth="3.5"
          strokeLinecap="round"
          animate={{ x1: elbowRightX, y1: elbowY, y2: weightY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />

        {/* Elbow Joint rings */}
        <motion.circle
          cx={elbowLeftX}
          cy={elbowY}
          r="4.5"
          fill="#3B82F6"
          stroke="#111"
          animate={{ cx: elbowLeftX, cy: elbowY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />
        <motion.circle
          cx={elbowRightX}
          cy={elbowY}
          r="4.5"
          fill="#3B82F6"
          stroke="#111"
          animate={{ cx: elbowRightX, cy: elbowY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />

        {/* Heavy Barbell load weight */}
        {equipment === "barbell" ? (
          <motion.g
            animate={{ y: weightY }}
            transition={{ type: "spring", stiffness: 90, damping: 15 }}
          >
            {/* Barbell bar */}
            <line x1="30" y1="0" x2="170" y2="0" stroke="#FFF" strokeWidth="3" />
            {/* End weights */}
            <rect x="24" y="-12" width="6" height="24" rx="1.5" fill="#C9F31D" />
            <rect x="18" y="-9" width="6" height="18" rx="1" fill="#A8D314" />
            <rect x="170" y="-12" width="6" height="24" rx="1.5" fill="#C9F31D" />
            <rect x="176" y="-9" width="6" height="18" rx="1" fill="#A8D314" />
          </motion.g>
        ) : (
          /* Dumbbells on wrist axes */
          <motion.g
            animate={{ y: weightY }}
            transition={{ type: "spring", stiffness: 90, damping: 15 }}
          >
            {/* Left Dumbbell */}
            <line x1="63" y1="0" x2="87" y2="0" stroke="#FFF" strokeWidth="2.5" />
            <rect x="59" y="-7" width="4" height="14" rx="1" fill="#C9F31D" />
            <rect x="87" y="-7" width="4" height="14" rx="1" fill="#C9F31D" />

            {/* Right Dumbbell */}
            <line x1="113" y1="0" x2="137" y2="0" stroke="#FFF" strokeWidth="2.5" />
            <rect x="109" y="-7" width="4" height="14" rx="1" fill="#C9F31D" />
            <rect x="137" y="-7" width="4" height="14" rx="1" fill="#C9F31D" />
          </motion.g>
        )}
      </svg>
    );
  };

  const renderOverheadPressAnimation = () => {
    // Front/Side Overhead shoulder pressing
    // Squeeze: overhead straight arms lock
    // Stretch: barbell/dumbbells sitting at chin height
    const weightY = isSqueeze ? 35 : 85;

    // Elbows flared down
    const elbowLx = isSqueeze ? 80 : 55;
    const elbowRx = isSqueeze ? 120 : 145;
    const elbowY = isSqueeze ? 68 : 100;

    const shoulderActive = isSqueeze;

    return (
      <svg className="w-full h-full" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Head & Neck */}
        <circle cx="100" cy="85" r="12" fill="#222" stroke="#444" />
        <line x1="100" y1="97" x2="100" y2="120" stroke="#222" strokeWidth="6" />

        {/* Torso / Shoulders line */}
        <path d="M 65 110 Q 100 100 135 110" stroke="#333" strokeWidth="8" strokeLinecap="round" />

        {/* Shoulder highlights */}
        {shoulderActive && (
          <g>
            <circle cx="68" cy="110" r="10" fill="rgba(201, 243, 29, 0.15)" className="animate-pulse" />
            <circle cx="132" cy="110" r="10" fill="rgba(201, 243, 29, 0.15)" className="animate-pulse" />
          </g>
        )}

        {/* Left Arm Upper / Lower */}
        <motion.line
          x1="68"
          y1="110"
          x2={elbowLx}
          y2={elbowY}
          stroke="#888"
          strokeWidth="4"
          strokeLinecap="round"
          animate={{ x2: elbowLx, y2: elbowY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />
        <motion.line
          x1={elbowLx}
          y1={elbowY}
          x2="68"
          y2={weightY}
          stroke="#CCC"
          strokeWidth="3.5"
          strokeLinecap="round"
          animate={{ x1: elbowLx, y1: elbowY, y2: weightY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />

        {/* Right Arm Upper / Lower */}
        <motion.line
          x1="132"
          y1="110"
          x2={elbowRx}
          y2={elbowY}
          stroke="#888"
          strokeWidth="4"
          strokeLinecap="round"
          animate={{ x2: elbowRx, y2: elbowY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />
        <motion.line
          x1={elbowRx}
          y1={elbowY}
          x2="132"
          y2={weightY}
          stroke="#CCC"
          strokeWidth="3.5"
          strokeLinecap="round"
          animate={{ x1: elbowRx, y1: elbowY, y2: weightY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />

        {/* Elbow joints */}
        <motion.circle
          cx={elbowLx}
          cy={elbowY}
          r="4.5"
          fill="#3B82F6"
          stroke="#111"
          animate={{ cx: elbowLx, cy: elbowY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />
        <motion.circle
          cx={elbowRx}
          cy={elbowY}
          r="4.5"
          fill="#3B82F6"
          stroke="#111"
          animate={{ cx: elbowRx, cy: elbowY }}
          transition={{ type: "spring", stiffness: 90, damping: 15 }}
        />

        {/* Dumbbells or Barbell overhead */}
        {equipment === "barbell" ? (
          <motion.g
            animate={{ y: weightY }}
            transition={{ type: "spring", stiffness: 90, damping: 15 }}
          >
            <line x1="30" y1="0" x2="170" y2="0" stroke="#FFF" strokeWidth="3" />
            <rect x="24" y="-12" width="6" height="24" rx="1.5" fill="#C9F31D" />
            <rect x="170" y="-12" width="6" height="24" rx="1.5" fill="#C9F31D" />
          </motion.g>
        ) : (
          <motion.g
            animate={{ y: weightY }}
            transition={{ type: "spring", stiffness: 90, damping: 15 }}
          >
            {/* Left DB */}
            <line x1="56" y1="0" x2="80" y2="0" stroke="#FFF" strokeWidth="2.5" />
            <rect x="52" y="-7" width="4" height="14" rx="1" fill="#C9F31D" />
            <rect x="80" y="-7" width="4" height="14" rx="1" fill="#C9F31D" />

            {/* Right DB */}
            <line x1="120" y1="0" x2="144" y2="0" stroke="#FFF" strokeWidth="2.5" />
            <rect x="116" y="-7" width="4" height="14" rx="1" fill="#C9F31D" />
            <rect x="144" y="-7" width="4" height="14" rx="1" fill="#C9F31D" />
          </motion.g>
        )}
      </svg>
    );
  };

  const renderDefaultHUDEngine = () => {
    // Beautiful medical scan circular telemetry with rotating radar and wave patterns
    return (
      <svg className="w-full h-full" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Core dynamic breathing star / atom style */}
        <motion.circle
          cx="100"
          cy="100"
          r="30"
          fill="none"
          stroke="#C9F31D"
          strokeWidth="1.5"
          animate={{
            r: isSqueeze ? [30, 48, 30] : [30, 18, 30],
            strokeWidth: isSqueeze ? [1.5, 3, 1.5] : [1.5, 0.8, 1.5],
            boxShadow: "0 0 15px rgba(201,243,29,0.3)"
          }}
          transition={{ duration: 2, ease: "easeInOut" }}
        />

        <motion.circle
          cx="100"
          cy="100"
          r="48"
          fill="none"
          stroke="#3B82F6"
          strokeWidth="1"
          strokeDasharray="4 4"
          animate={{
            rotate: isSqueeze ? 360 : -360
          }}
          transition={{ duration: 8, ease: "linear", repeat: Infinity }}
        />

        {/* Energy nodes revolving */}
        <motion.g
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
          style={{ transformOrigin: "100px 100px" }}
        >
          <circle cx="100" cy="52" r="4.5" fill="#C9F31D" />
          <circle cx="100" cy="148" r="3.5" fill="#3B82F6" />
        </motion.g>

        <motion.path
          d="M 40 100 Q 70 80, 100 100 T 160 100"
          stroke="rgba(255,255,255,0.08)"
          strokeWidth="2.5"
          animate={{
            d: isSqueeze 
              ? "M 40 100 Q 70 60, 100 100 T 160 100" 
              : "M 40 100 Q 70 120, 100 100 T 160 100"
          }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
        />

        {/* Concentric waves */}
        <circle cx="100" cy="100" r="65" stroke="#222" strokeWidth="1" />
        <circle cx="100" cy="100" r="78" stroke="#1c1c1c" strokeWidth="0.8" />
        <line x1="100" y1="20" x2="100" y2="180" stroke="#333" strokeWidth="0.5" strokeDasharray="2 2" />
        <line x1="20" y1="100" x2="180" y2="100" stroke="#333" strokeWidth="0.5" strokeDasharray="2 2" />
      </svg>
    );
  };

  // Branching algorithm matching specific muscles and form profiles
  if (mainMuscle === "biceps" || mainMuscle === "triceps" || mainMuscle === "back") {
    const isTriceps = mainMuscle === "triceps";
    return renderArmAnimation(isTriceps);
  } else if (mainMuscle === "legs" || mainMuscle === "glutes" || mainMuscle === "calves") {
    return renderSquatAnimation();
  } else if (mainMuscle === "chest" || mainMuscle === "triceps_push") {
    return renderPressAnimation();
  } else if (mainMuscle === "shoulders") {
    // If lateral raises or shoulder pressing, overhead is perfect
    return renderOverheadPressAnimation();
  } else {
    return renderDefaultHUDEngine();
  }
}
