import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowRight,
  ArrowLeft,
  Check,
  Sparkles,
  Dumbbell,
  Flame,
  Zap,
  User,
  Scale,
  Camera,
  Fingerprint,
  ShieldCheck,
  Utensils,
  Target,
  Activity,
  X,
} from "lucide-react";
import { playSound } from "../utils/audio";
import { useAuth } from "../context/AuthContext";
import { speakGenie } from "../utils/voiceCoach";
import { useAppLanguage, AppLanguage } from "../utils/language";

export interface GlowUpOnboardingData {
  name: string;
  gender: string;
  dateOfBirth: string;
  height: number;
  weight: number;
  targetWeight: number;
  bodyType: string;
  activityLevel: string;
  mainGoal: string;
  progressPace: string;
  bmi: number;
  bmr: number;
  dailyCalorieTarget: number;
  waterIntakeGoal: number;
  onboardingCompleted: boolean;
  // New 1-8 Glow-Up Personalization Fields + Bilingual Language
  appLanguage: "hinglish" | "english";
  trainingPath: "calisthenics" | "gym" | "home_jugaad" | "aesthetics";
  dietPreference: "veg" | "egg" | "nonveg";
  kitchenSetup: "hostel" | "home";
  currentBfPercent: number;
  dreamPhysique: string;
  warriorClass: string;
  glowUpStartDate: string;
  aiBaselineScore: number;
}

interface OnboardingProps {
  onComplete: (userData: GlowUpOnboardingData) => void;
  isRecalibrating?: boolean;
  onCancelRecalibrate?: () => void;
}

const WARRIOR_PATHS = [
  {
    id: "calisthenics" as const,
    emoji: "🤸",
    title: "Street Calisthenics Ninja",
    badge: "BODYWEIGHT & BAR ONLY",
    warriorClass: "Shadow Calisthenics Assassin",
    color: "from-[#14F1E1]/20 to-black border-[#14F1E1]",
    desc: "Pull-ups, Push-up progressions, Handstands, Planche & Core mastery.",
    filterNote: "Hides Gym Machines, Barbells & Dumbbells automatically.",
  },
  {
    id: "gym" as const,
    emoji: "🏋️",
    title: "Iron Titan (Gym Lifter)",
    badge: "DUMBBELLS, BARBELLS & MACHINES",
    warriorClass: "Iron Vanguard Titan",
    color: "from-[#4DA8FF]/20 to-black border-[#4DA8FF]",
    desc: "Heavy compound lifts, hypertrophy splits, 1RM & Plate Calculator.",
    filterNote: "Prioritizes Gym Iron workouts & hides Hostel Jugaad drills.",
  },
  {
    id: "home_jugaad" as const,
    emoji: "🎒",
    title: "Hostel / Home Spartan",
    badge: "ZERO EQUIPMENT • DESI JUGAAD",
    warriorClass: "Hostel Jugaad Spartan",
    color: "from-amber-500/20 to-black border-amber-400",
    desc: "Train in your room using College Backpacks, 20L Water Buckets & Floor drills.",
    filterNote: "Hides all Gym Equipment & Pull-up Bar requirements.",
  },
  {
    id: "aesthetics" as const,
    emoji: "✨",
    title: "Aesthetic & Mogging Glow-Up",
    badge: "FACE + POSTURE + V-TAPER",
    warriorClass: "Aesthetic Sovereign",
    color: "from-[#B66DFF]/20 to-black border-[#B66DFF]",
    desc: "Jawline definition, Face De-Bloat, Neck Posture Height Gain & 1.618 V-Taper.",
    filterNote: "Pins Mogged Station, Posture Lab & V-Taper sculpting first.",
  },
];

const DREAM_PHYSIQUES = [
  { id: "cali_shred", label: "Calisthenics Shredded (8-10% BF)", emoji: "⚡", targetBf: 10 },
  { id: "greek_vtaper", label: "Greek God 1.618 V-Taper (11-12% BF)", emoji: "🏛️", targetBf: 11 },
  { id: "lean_fighter", label: "Lean MMA / Boxer Frame (12% BF)", emoji: "🥊", targetBf: 12 },
  { id: "mass_titan", label: "Dense Power Titan (14% BF)", emoji: "🦍", targetBf: 14 },
];

export default function Onboarding({
  onComplete,
  isRecalibrating = false,
  onCancelRecalibrate,
}: OnboardingProps) {
  const { user, profile, signInWithGoogle } = useAuth();
  const { lang: appLanguage, setLang: setAppLanguage, t } = useAppLanguage();
  const [step, setStep] = useState(user || isRecalibrating ? 1 : 0);

  // Core Identity & Biometrics
  const [name, setName] = useState(profile?.name || profile?.username || "");
  const [gender, setGender] = useState(profile?.gender || "male");
  const [dateOfBirth, setDateOfBirth] = useState(profile?.dateOfBirth || "2002-01-01");
  const [height, setHeight] = useState(profile?.height || 174);
  const [weight, setWeight] = useState(profile?.weight || 68);
  const [targetWeight, setTargetWeight] = useState(profile?.targetWeight || 72);
  const [bodyType, setBodyType] = useState(profile?.bodyType || "mesomorph");
  const [activityLevel, setActivityLevel] = useState(profile?.activityLevel || "moderate");
  const [mainGoal, setMainGoal] = useState(profile?.mainGoal || "muscle");
  const [progressPace, setProgressPace] = useState(profile?.progressPace || "moderate");

  // New Features #1, #3, #4, #6, #7 States
  const [trainingPath, setTrainingPath] = useState<"calisthenics" | "gym" | "home_jugaad" | "aesthetics">(
    profile?.trainingPath ||
      (localStorage.getItem("fitgenie_training_path") as any) ||
      "calisthenics"
  );
  const [dietPreference, setDietPreference] = useState<"veg" | "egg" | "nonveg">(
    profile?.dietPreference ||
      (localStorage.getItem("fitgenie_diet_pref") as any) ||
      "veg"
  );
  const [kitchenSetup, setKitchenSetup] = useState<"hostel" | "home">(
    profile?.kitchenSetup || "home"
  );
  const [currentBfPercent, setCurrentBfPercent] = useState<number>(profile?.currentBfPercent || 18);
  const [dreamPhysique, setDreamPhysique] = useState<string>(
    profile?.dreamPhysique || "greek_vtaper"
  );

  // Feature #3: 10-Sec AI Camera Baseline Check State
  const [cameraScanning, setCameraScanning] = useState(false);
  const [cameraProgress, setCameraProgress] = useState(0);
  const [aiBaselineScore, setAiBaselineScore] = useState<number>(profile?.aiBaselineScore || 84);
  const [baselineScanned, setBaselineScanned] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Feature #7: Biometric Fingerprint Blood Oath Hold State
  const [oathProgress, setOathProgress] = useState(0);
  const [isHoldingOath, setIsHoldingOath] = useState(false);
  const oathTimerRef = useRef<number | null>(null);

  const nameInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user && step === 0) {
      setStep(1);
    }
  }, [user, step]);

  useEffect(() => {
    if (step === 1) {
      setTimeout(() => nameInputRef.current?.focus(), 300);
    }
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
    };
  }, [step]);

  // Age, BMI, BMR, Calories & Water Math
  const calculateAge = (dobString: string): number => {
    const today = new Date();
    const birthDate = new Date(dobString);
    let a = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) a--;
    return Math.max(12, a || 21);
  };
  const age = calculateAge(dateOfBirth);
  const bmi = parseFloat((weight / (height / 100) ** 2).toFixed(1));

  const bmr = Math.round(
    Math.max(
      800,
      gender === "male"
        ? 10 * weight + 6.25 * height - 5 * age + 5
        : 10 * weight + 6.25 * height - 5 * age - 161
    )
  );

  const calculateDailyCalorieTarget = (): number => {
    const mult: Record<string, number> = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
    };
    const tdee = bmr * (mult[activityLevel] || 1.5);
    const rate = progressPace === "slow" ? 250 : progressPace === "aggressive" ? 600 : 400;
    const adj = mainGoal === "fatburn" ? -rate : mainGoal === "muscle" || mainGoal === "strength" ? rate : 0;
    return Math.round(Math.max(1200, tdee + adj));
  };
  const dailyCalorieTarget = calculateDailyCalorieTarget();
  const waterIntakeGoal = Math.round(weight * 38);

  const selectedPathObj =
    WARRIOR_PATHS.find((p) => p.id === trainingPath) || WARRIOR_PATHS[0];
  const selectedDreamObj =
    DREAM_PHYSIQUES.find((d) => d.id === dreamPhysique) || DREAM_PHYSIQUES[1];

  // Calculate Target 90-Day Glow-Up Date (Feature #2)
  const target90DateStr = (() => {
    const d = new Date();
    d.setDate(d.getDate() + 90);
    return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
  })();

  // Silhouette Description for Feature #4
  const getBfDescription = (bf: number) => {
    if (bf <= 11) return { label: "Shredded Abs Visible", icon: "⚡", color: "text-[#14F1E1]" };
    if (bf <= 16) return { label: "Athletic / Lean Frame", icon: "🐆", color: "text-emerald-400" };
    if (bf <= 22) return { label: "Soft / Skinny-Fat or Average", icon: "🔥", color: "text-amber-400" };
    return { label: "Heavy Bulk / High Fat Store", icon: "🐻", color: "text-red-400" };
  };

  // Feature #3: Run 10-Second AI Camera Calibration
  const startAiCameraCalibration = async () => {
    playSound("click");
    setCameraScanning(true);
    setCameraProgress(0);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
    } catch {
      // Camera unavailable or denied; runs biometric simulation seamlessly
    }

    speakGenie(
      t(
        "Seedha khada reh bhai! Tera shoulder alignment, posture aur Day-1 power scan ho raha hai.",
        "Hold steady warrior! Scanning shoulder alignment, cervical posture, and starting power potential."
      ),
      { lang: appLanguage === "english" ? "en-IN" : "hi-IN" }
    );

    let p = 0;
    const timerId = window.setInterval(() => {
      p += 10;
      setCameraProgress(p);
      if (p >= 100) {
        clearInterval(timerId);
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((tr) => tr.stop());
          streamRef.current = null;
        }
        const computedScore = Math.floor(81 + Math.random() * 12);
        setAiBaselineScore(computedScore);
        setCameraScanning(false);
        setBaselineScanned(true);
        playSound("success");
        speakGenie(
          t(
            `Calibration complete! Tera starting biometric score ${computedScore} percent hai! 90 din me isko 96 percent Greek God level pe le jayenge!`,
            `Calibration complete! Your starting biometric score is ${computedScore} percent! In 90 days we will take it to 96 percent elite level!`
          ),
          { lang: appLanguage === "english" ? "en-IN" : "hi-IN" }
        );
      }
    }, 280);
  };

  // Feature #7: Biometric Fingerprint Blood Oath Hold Handler
  const startHoldingOath = () => {
    if (oathProgress >= 100) return;
    setIsHoldingOath(true);
    playSound("click");
    if (navigator.vibrate) navigator.vibrate(40);

    if (oathTimerRef.current) clearInterval(oathTimerRef.current);
    oathTimerRef.current = window.setInterval(() => {
      setOathProgress((prev) => {
        const next = Math.min(100, prev + 8);
        if (next >= 100) {
          if (oathTimerRef.current) clearInterval(oathTimerRef.current);
          completeGlowUpOnboarding();
        }
        return next;
      });
    }, 90);
  };

  const stopHoldingOath = () => {
    setIsHoldingOath(false);
    if (oathTimerRef.current) {
      clearInterval(oathTimerRef.current);
      oathTimerRef.current = null;
    }
  };

  const completeGlowUpOnboarding = () => {
    if (oathTimerRef.current) {
      clearInterval(oathTimerRef.current);
      oathTimerRef.current = null;
    }
    playSound("success");
    if (navigator.vibrate) navigator.vibrate([80, 40, 120]);

    // Persist path, diet & language in localStorage for instant app-wide filtering
    localStorage.setItem("fitgenie_app_lang", appLanguage);
    localStorage.setItem("fitgenie_training_path", trainingPath);
    localStorage.setItem("fitgenie_diet_pref", dietPreference);
    localStorage.setItem("fitgenie_kitchen_setup", kitchenSetup);
    localStorage.setItem("fitgenie_main_goal", mainGoal);
    localStorage.setItem("fitgenie_dream_physique", dreamPhysique);

    speakGenie(
      t(
        `90-Day Glow-Up Contract lock ho gaya! Swagat hai ${name || "Warrior"}, ab poora app tere ${trainingPath} aur ${dietPreference} plan pe set hai! Plus 100 XP mila!`,
        `90-Day Glow-Up Contract Locked! Welcome ${name || "Warrior"}, the entire app is now customized to your ${trainingPath} and ${dietPreference} plan! Plus 100 Starter XP credited!`
      ),
      { lang: appLanguage === "english" ? "en-IN" : "hi-IN" }
    );

    onComplete({
      name: name.trim() || "Warrior",
      gender,
      dateOfBirth,
      height,
      weight,
      targetWeight,
      bodyType,
      activityLevel,
      mainGoal,
      progressPace,
      bmi,
      bmr,
      dailyCalorieTarget,
      waterIntakeGoal,
      onboardingCompleted: true,
      appLanguage,
      trainingPath,
      dietPreference,
      kitchenSetup,
      currentBfPercent,
      dreamPhysique,
      warriorClass: selectedPathObj.warriorClass,
      glowUpStartDate: new Date().toISOString(),
      aiBaselineScore,
    });
  };

  const [isSigningIn, setIsSigningIn] = useState(false);
  const [authNotice, setAuthNotice] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    if (isSigningIn) return;
    setIsSigningIn(true);
    setAuthNotice(null);
    try {
      await signInWithGoogle();
      setStep(1);
    } catch (err: any) {
      if (
        err?.code === "auth/popup-closed-by-user" ||
        err?.code === "auth/cancelled-popup-request" ||
        err?.message === "POPUP_CLOSED_BY_USER"
      ) {
        setAuthNotice(
          t(
            "Sign-in window band ho gayi thi. Shuru karne ke liye dobara button dabayein.",
            "Sign-in popup was closed before completing. Tap 'Continue with Google' to try again."
          )
        );
      } else if (err?.code === "auth/popup-blocked") {
        setAuthNotice(
          t(
            "Browser ne popup block kar diya. Kripya popup allow karke dobara try karein.",
            "Sign-in popup was blocked by your browser. Please allow popups and try again."
          )
        );
      } else {
        setAuthNotice(
          t(
            "Google Sign-In me dikkat aayi. Kripya dobara try karein.",
            "Could not complete Google Sign-In. Please try again."
          )
        );
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  // STEP 0: GOOGLE AUTH LANDING SCREEN
  if (step === 0 && !isRecalibrating) {
    return (
      <div className="min-h-screen bg-[#030610] text-white flex flex-col items-center justify-center p-6 relative overflow-hidden font-sans">
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
          <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] max-w-[600px] max-h-[600px] bg-[#14F1E1] rounded-full blur-[120px] opacity-15 animate-pulse" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] max-w-[600px] max-h-[600px] bg-[#B66DFF] rounded-full blur-[120px] opacity-15 animate-pulse" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          className="z-10 w-full max-w-md rounded-[2.5rem] bg-[#0D1328]/80 backdrop-blur-2xl border border-[#14F1E1]/30 p-8 sm:p-10 text-center space-y-8 shadow-[0_0_60px_rgba(20,241,225,0.15)]"
        >
          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-br from-[#14F1E1]/20 to-[#B66DFF]/20 border border-[#14F1E1]/50 flex items-center justify-center shadow-[0_0_25px_rgba(20,241,225,0.4)]">
            <Zap className="w-10 h-10 text-[#14F1E1]" />
          </div>

          <div className="space-y-2">
            <span className="text-[10px] font-mono font-black uppercase tracking-[0.25em] px-3 py-1 rounded-full bg-[#14F1E1]/15 text-[#14F1E1] border border-[#14F1E1]/30">
              90-DAY CYBER GLOW-UP SYSTEM
            </span>
            <h1 className="text-4xl font-black uppercase tracking-tight text-white pt-2">
              FIT <span className="text-[#14F1E1]">GENIE</span>
            </h1>
            <p className="text-neutral-400 text-xs sm:text-sm leading-relaxed">
              {t(
                "Calisthenics, Gym Iron, Hostel Jugaad & Aesthetics — 100% teri body, equipment aur diet ke hisaab se customized.",
                "Calisthenics, Gym Iron, Hostel Jugaad & Facial Aesthetics — tailored 100% to your body, equipment, and diet."
              )}
            </p>
          </div>

          {/* LANGUAGE SELECTOR ON LANDING */}
          <div className="bg-black/50 border border-white/15 rounded-2xl p-3 space-y-2">
            <span className="text-[10px] font-mono uppercase tracking-widest text-[#14F1E1] block">
              🌐 Select Your App Language (Apni Bhasha Chunein)
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  playSound("click");
                  setAppLanguage("hinglish");
                }}
                className={`py-2.5 px-3 rounded-xl text-xs font-black uppercase border transition-all cursor-pointer ${
                  appLanguage === "hinglish"
                    ? "bg-[#14F1E1] text-black border-[#14F1E1]"
                    : "bg-white/5 border-white/10 text-neutral-400"
                }`}
              >
                🇮🇳 Hinglish (Desi Bro)
              </button>
              <button
                type="button"
                onClick={() => {
                  playSound("click");
                  setAppLanguage("english");
                }}
                className={`py-2.5 px-3 rounded-xl text-xs font-black uppercase border transition-all cursor-pointer ${
                  appLanguage === "english"
                    ? "bg-[#14F1E1] text-black border-[#14F1E1]"
                    : "bg-white/5 border-white/10 text-neutral-400"
                }`}
              >
                🌐 English (Global Pro)
              </button>
            </div>
          </div>

          {authNotice && (
            <div className="rounded-2xl bg-amber-500/15 border border-amber-400/40 px-4 py-3 text-xs font-bold text-amber-200">
              {authNotice}
            </div>
          )}

          <button
            onClick={handleGoogleSignIn}
            disabled={isSigningIn}
            className="w-full flex items-center justify-center gap-3 bg-white text-black py-4 rounded-2xl font-black text-sm uppercase tracking-wider hover:scale-[1.02] active:scale-[0.98] disabled:opacity-60 transition-all cursor-pointer shadow-lg"
          >
            <span>
              {isSigningIn
                ? t("Google Se Connect Ho Raha Hai...", "Connecting to Google...")
                : t("Google Se Shuru Karo", "Continue with Google")}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-[120] bg-[#050B1A] text-white flex flex-col font-sans overflow-y-auto"
      id="onboarding-container"
    >
      {/* Top Progress Header */}
      <div className="px-5 py-4 flex items-center justify-between border-b border-white/10 bg-[#0D1328]/90 backdrop-blur-md sticky top-0 z-30">
        <div className="flex items-center gap-2">
          {step > 1 ? (
            <button
              onClick={() => {
                playSound("click");
                setStep((s) => s - 1);
              }}
              className="flex items-center gap-1 text-xs font-black uppercase text-neutral-300 hover:text-white px-2.5 py-1.5 rounded-xl bg-white/5 border border-white/10 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 text-[#14F1E1]" />
              <span>{t("Piche", "Back")}</span>
            </button>
          ) : isRecalibrating && onCancelRecalibrate ? (
            <button
              onClick={onCancelRecalibrate}
              className="flex items-center gap-1 text-xs font-black uppercase text-neutral-400 hover:text-white px-2.5 py-1.5 rounded-xl bg-white/5 border border-white/10 cursor-pointer"
            >
              <X className="w-4 h-4" />
              <span>{t("Band Karo", "Close")}</span>
            </button>
          ) : (
            <span className="text-[10px] font-mono font-black uppercase tracking-widest text-[#14F1E1]">
              ⚡ GLOW-UP PROTOCOL
            </span>
          )}
        </div>

        {/* 6-Step Progress Bar */}
        <div className="flex items-center gap-1.5">
          {[1, 2, 3, 4, 5, 6].map((idx) => (
            <div
              key={idx}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                step === idx
                  ? "w-8 bg-[#14F1E1] shadow-[0_0_10px_#14F1E1]"
                  : idx < step
                  ? "w-3 bg-[#14F1E1]/50"
                  : "w-2 bg-white/10"
              }`}
            />
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              playSound("click");
              setAppLanguage(appLanguage === "hinglish" ? "english" : "hinglish");
            }}
            className="px-2.5 py-1 rounded-lg bg-[#14F1E1]/15 border border-[#14F1E1]/40 text-[#14F1E1] text-[10px] font-black uppercase cursor-pointer"
          >
            {appLanguage === "hinglish" ? "🇮🇳 Hinglish" : "🌐 English"}
          </button>
          <span className="text-[10px] font-mono font-black uppercase text-neutral-400">
            {step}/6
          </span>
        </div>
      </div>

      {/* Main Content Container */}
      <div className="flex-1 max-w-xl w-full mx-auto px-4 sm:px-6 py-6 flex flex-col justify-between">
        <AnimatePresence mode="wait">
          {/* ════════════════════════════════════════════════════════════════
              STAGE 1: LANGUAGE SELECTION + WARRIOR IDENTITY
             ════════════════════════════════════════════════════════════════ */}
          {step === 1 && (
            <motion.div
              key="stage-1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-2">
                <span className="text-[10px] font-mono font-black uppercase tracking-widest px-3 py-1 rounded-full bg-[#14F1E1]/15 text-[#14F1E1] border border-[#14F1E1]/30">
                  {t("STAGE 1 • BHASHA AUR PEHCHAN", "STAGE 1 • LANGUAGE & IDENTITY")}
                </span>
                <h2 className="text-2xl sm:text-3xl font-black uppercase tracking-tight mt-2">
                  {t("Apni Bhasha Aur ", "Choose Language & ")}
                  <span className="text-[#14F1E1]">
                    {t("90-Day Glow-Up Shuru Kar", "Start 90-Day Glow-Up")}
                  </span>
                </h2>
                <p className="text-xs text-neutral-400 max-w-md mx-auto">
                  {t(
                    "Jo language aur details tu select karega, poora app (Exercises, Diet, AI Voice aur Dashboard) 100% usi hisaab se chalega!",
                    "Everything in the app (Exercises, Diet, AI Voice, and Dashboard) will automatically adapt 100% to the language and profile you choose here!"
                  )}
                </p>
              </div>

              {/* STEP 1A: CHOOSE APP LANGUAGE (HINGLISH VS ENGLISH) */}
              <div className="bg-[#0D1328] border-2 border-[#14F1E1]/40 rounded-3xl p-4 space-y-2.5 shadow-[0_0_25px_rgba(20,241,225,0.1)]">
                <label className="block text-[10px] font-mono font-black uppercase text-[#14F1E1] tracking-widest">
                  1. {t("App Kis Language Me Chahiye? (Select Language)", "Choose Your App Language")}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      playSound("click");
                      setAppLanguage("hinglish");
                      speakGenie("Desi Hinglish mode set ho gaya bhai! Ab poora app tere se Hinglish me baat karega.", { lang: "hi-IN" });
                    }}
                    className={`p-3.5 rounded-2xl border-2 text-left transition-all cursor-pointer ${
                      appLanguage === "hinglish"
                        ? "bg-[#14F1E1]/20 border-[#14F1E1] text-white shadow-[0_0_15px_rgba(20,241,225,0.25)]"
                        : "bg-black/40 border-white/10 text-neutral-400"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xl">🇮🇳</span>
                      {appLanguage === "hinglish" && <Check className="w-4 h-4 text-[#14F1E1]" />}
                    </div>
                    <p className="text-sm font-black uppercase mt-1 text-white">Hinglish</p>
                    <p className="text-[10px] text-neutral-300 mt-0.5 leading-snug">
                      Desi Gym-Bro Vibe (&quot;Bhai aaj Chest aur Pushups phodte hain!&quot;)
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      playSound("click");
                      setAppLanguage("english");
                      speakGenie("Clean English mode activated! Every screen, exercise, and voice prompt will now be in English.", { lang: "en-IN" });
                    }}
                    className={`p-3.5 rounded-2xl border-2 text-left transition-all cursor-pointer ${
                      appLanguage === "english"
                        ? "bg-[#14F1E1]/20 border-[#14F1E1] text-white shadow-[0_0_15px_rgba(20,241,225,0.25)]"
                        : "bg-black/40 border-white/10 text-neutral-400"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xl">🌐</span>
                      {appLanguage === "english" && <Check className="w-4 h-4 text-[#14F1E1]" />}
                    </div>
                    <p className="text-sm font-black uppercase mt-1 text-white">English</p>
                    <p className="text-[10px] text-neutral-300 mt-0.5 leading-snug">
                      Pro Athlete English (&quot;Let&apos;s crush your hypertrophy &amp; calisthenics goals!&quot;)
                    </p>
                  </button>
                </div>
              </div>

              <div className="bg-[#0D1328] border border-white/10 rounded-3xl p-5 space-y-4">
                <div>
                  <label className="block text-[10px] font-mono font-black uppercase text-neutral-400 tracking-widest mb-1.5">
                    2. {t("Tera Naam (Warrior Name)", "Your Name (Warrior Name)")}
                  </label>
                  <input
                    ref={nameInputRef}
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={t("e.g. Aarav Sher", "e.g. Alex Titan")}
                    className="w-full bg-black/60 border border-white/15 focus:border-[#14F1E1] rounded-2xl px-4 py-3.5 text-white font-bold text-sm focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-mono font-black uppercase text-neutral-400 tracking-widest mb-1.5">
                      {t(`Janam Tarikh (${age} Saal)`, `Date of Birth (${age} Yrs)`)}
                    </label>
                    <input
                      type="date"
                      value={dateOfBirth}
                      onChange={(e) => setDateOfBirth(e.target.value)}
                      className="w-full bg-black/60 border border-white/15 focus:border-[#14F1E1] rounded-2xl px-3.5 py-3 text-white font-mono text-xs focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono font-black uppercase text-neutral-400 tracking-widest mb-1.5">
                      {t("Gender Chuno", "Select Gender")}
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: "male", label: t("Bhai", "Male"), icon: "👨" },
                        { id: "female", label: t("Behen", "Female"), icon: "👩" },
                        { id: "other", label: "Warrior", icon: "⚡" },
                      ].map((g) => (
                        <button
                          key={g.id}
                          type="button"
                          onClick={() => {
                            playSound("click");
                            setGender(g.id);
                          }}
                          className={`py-2.5 rounded-xl border text-xs font-black uppercase flex flex-col items-center cursor-pointer ${
                            gender === g.id
                              ? "bg-[#14F1E1]/20 border-[#14F1E1] text-[#14F1E1]"
                              : "bg-black/40 border-white/10 text-neutral-400"
                          }`}
                        >
                          <span>{g.icon}</span>
                          <span className="text-[10px] mt-0.5">{g.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  if (!name.trim()) setName("Warrior");
                  playSound("click");
                  speakGenie(
                    t(
                      `Swagat hai ${name.trim() || "Warrior"}! Ab apna training path select kar taaki tujhe sirf tere kaam ki exercises dikhein.`,
                      `Welcome ${name.trim() || "Warrior"}! Now select your training path so we only show exercises tailored to your equipment.`
                    ),
                    { lang: appLanguage === "english" ? "en-IN" : "hi-IN" }
                  );
                  setStep(2);
                }}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#14F1E1] to-[#4DA8FF] text-black font-black text-xs uppercase tracking-widest shadow-[0_0_25px_rgba(20,241,225,0.3)] flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{t("Agla Step: Training Path Chuno", "Next: Choose Training Path")}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {/* ════════════════════════════════════════════════════════════════
              STAGE 2 (FEATURE #1): CHOOSE YOUR WARRIOR ARCHETYPE (APP FILTER)
             ════════════════════════════════════════════════════════════════ */}
          {step === 2 && (
            <motion.div
              key="stage-2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1.5">
                <span className="text-[10px] font-mono font-black uppercase tracking-widest px-3 py-1 rounded-full bg-[#B66DFF]/20 text-[#B66DFF] border border-[#B66DFF]/40">
                  {t("STAGE 2 • SMART APP FILTERING", "STAGE 2 • SMART EQUIPMENT FILTER")}
                </span>
                <h2 className="text-2xl sm:text-3xl font-black uppercase tracking-tight">
                  {t("Tera ", "What Is Your ")}
                  <span className="text-[#14F1E1]">
                    {t("Training Weapon", "Training Style")}
                  </span>
                  {t(" Kya Hai?", "?")}
                </h2>
                <p className="text-xs text-neutral-400">
                  {t(
                    "Jo path tu chunega, app me sirf wahi workouts aur tools dikhenge (Calisthenics wale ko Gym machine nahi dikhegi!).",
                    "Your entire app will lock onto this mode — Calisthenics users won't see Gym machine clutter, and Hostel users get Zero-Equipment drills!"
                  )}
                </p>
              </div>

              <div className="grid grid-cols-1 gap-3">
                {WARRIOR_PATHS.map((path) => {
                  const selected = trainingPath === path.id;
                  return (
                    <button
                      key={path.id}
                      type="button"
                      onClick={() => {
                        playSound("click");
                        setTrainingPath(path.id);
                      }}
                      className={`p-4 rounded-3xl border-2 text-left transition-all cursor-pointer relative overflow-hidden ${
                        selected
                          ? `bg-gradient-to-r ${path.color} shadow-[0_0_25px_rgba(20,241,225,0.2)] scale-[1.01]`
                          : "bg-[#0D1328]/70 border-white/10 hover:border-white/25"
                      }`}
                    >
                      <div className="flex items-start gap-3.5">
                        <div className="w-12 h-12 rounded-2xl bg-black/60 border border-white/15 flex items-center justify-center text-2xl shrink-0">
                          {path.emoji}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded bg-white/10 text-[#14F1E1]">
                              {path.badge}
                            </span>
                            {selected && (
                              <span className="text-[9px] font-mono font-black uppercase text-emerald-400 flex items-center gap-1">
                                <Check className="w-3.5 h-3.5" /> Selected
                              </span>
                            )}
                          </div>
                          <h3 className="text-base font-black text-white uppercase mt-1">{path.title}</h3>
                          <p className="text-xs text-neutral-300 mt-0.5 leading-snug">{path.desc}</p>
                          <p className="text-[10px] font-mono text-amber-300 mt-1.5">
                            🎯 Filter Rule: {path.filterNote}
                          </p>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              <button
                onClick={() => {
                  playSound("click");
                  setStep(3);
                }}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#14F1E1] to-[#4DA8FF] text-black font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Lock {selectedPathObj.title} Path</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {/* ════════════════════════════════════════════════════════════════
              STAGE 3 (FEATURE #4): VISUAL BODYFAT SILHOUETTE & DREAM PHYSIQUE
             ════════════════════════════════════════════════════════════════ */}
          {step === 3 && (
            <motion.div
              key="stage-3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1">
                <span className="text-[10px] font-mono font-black uppercase tracking-widest px-3 py-1 rounded-full bg-[#14F1E1]/15 text-[#14F1E1] border border-[#14F1E1]/30">
                  STAGE 3 • CURRENT VS DREAM PHYSIQUE
                </span>
                <h2 className="text-2xl font-black uppercase tracking-tight">
                  Body Metrics & <span className="text-[#14F1E1]">Dream Frame</span>
                </h2>
              </div>

              {/* Height, Weight, Target Weight */}
              <div className="bg-[#0D1328] border border-white/10 rounded-3xl p-4 space-y-3">
                <div>
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-neutral-400 uppercase">Height (Lambaee)</span>
                    <span className="text-[#14F1E1] font-black">{height} CM</span>
                  </div>
                  <input
                    type="range"
                    min={135}
                    max={215}
                    value={height}
                    onChange={(e) => setHeight(Number(e.target.value))}
                    className="w-full accent-[#14F1E1] mt-1"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-neutral-400 uppercase">Current KG</span>
                      <span className="text-white font-black">{weight} KG</span>
                    </div>
                    <input
                      type="range"
                      min={38}
                      max={150}
                      value={weight}
                      onChange={(e) => setWeight(Number(e.target.value))}
                      className="w-full accent-[#14F1E1] mt-1"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-neutral-400 uppercase">90-Day Target</span>
                      <span className="text-[#B66DFF] font-black">{targetWeight} KG</span>
                    </div>
                    <input
                      type="range"
                      min={40}
                      max={150}
                      value={targetWeight}
                      onChange={(e) => setTargetWeight(Number(e.target.value))}
                      className="w-full accent-[#B66DFF] mt-1"
                    />
                  </div>
                </div>
              </div>

              {/* Feature #4: Interactive Body Fat Silhouette Slider */}
              <div className="bg-[#0D1328] border border-white/10 rounded-3xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[9px] font-mono uppercase text-neutral-400 block">
                      CURRENT BODY FAT SILHOUETTE
                    </span>
                    <span className={`text-sm font-black ${getBfDescription(currentBfPercent).color}`}>
                      {getBfDescription(currentBfPercent).icon} ~{currentBfPercent}% Bodyfat ({getBfDescription(currentBfPercent).label})
                    </span>
                  </div>
                  <span className="text-xs font-mono font-black text-white bg-black/50 px-2.5 py-1 rounded-xl border border-white/10">
                    BMI: {bmi}
                  </span>
                </div>
                <input
                  type="range"
                  min={8}
                  max={34}
                  value={currentBfPercent}
                  onChange={(e) => setCurrentBfPercent(Number(e.target.value))}
                  className="w-full accent-amber-400"
                />
                <div className="flex justify-between text-[9px] font-mono text-neutral-500">
                  <span>8% Shredded</span>
                  <span>15% Athletic</span>
                  <span>22% Soft</span>
                  <span>32% Heavy</span>
                </div>
              </div>

              {/* Dream Physique Selector */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono font-black uppercase text-neutral-400 tracking-widest block">
                  Select Your 90-Day Dream Physique Target:
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  {DREAM_PHYSIQUES.map((dp) => {
                    const active = dreamPhysique === dp.id;
                    return (
                      <button
                        key={dp.id}
                        type="button"
                        onClick={() => {
                          playSound("click");
                          setDreamPhysique(dp.id);
                        }}
                        className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center gap-2.5 ${
                          active
                            ? "bg-[#14F1E1]/15 border-[#14F1E1] text-white"
                            : "bg-[#0D1328] border-white/10 text-neutral-400"
                        }`}
                      >
                        <span className="text-2xl">{dp.emoji}</span>
                        <span className="text-xs font-black uppercase leading-tight">{dp.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <button
                onClick={() => {
                  playSound("click");
                  setStep(4);
                }}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#14F1E1] to-[#4DA8FF] text-black font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Next: Diet & Kitchen Filter</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {/* ════════════════════════════════════════════════════════════════
              STAGE 4 (FEATURE #6): DIET & KITCHEN AUTO-FILTER
             ════════════════════════════════════════════════════════════════ */}
          {step === 4 && (
            <motion.div
              key="stage-4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1.5">
                <span className="text-[10px] font-mono font-black uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  {t("STAGE 4 • DESI DIET & KITCHEN FILTER", "STAGE 4 • DIET & KITCHEN SETUP")}
                </span>
                <h2 className="text-2xl font-black uppercase tracking-tight">
                  {t("Tera ", "Your ")}
                  <span className="text-emerald-400">
                    {t("Fuel & Kitchen", "Diet & Kitchen")}
                  </span>
                  {t(" Scene Kya Hai?", " Setup")}
                </h2>
                <p className="text-xs text-neutral-400">
                  {t(
                    "Pure Veg select karne par app me se Eggs aur Chicken apne aap hide ho jayenge!",
                    "Selecting Pure Veg automatically hides all Egg and Meat items across the app!"
                  )}
                </p>
              </div>

              {/* Veg / Egg / Non-Veg Selector */}
              <div className="space-y-2.5">
                <label className="text-[10px] font-mono font-black uppercase text-neutral-400 tracking-widest block">
                  1. Dietary Preference (Auto-Filters Nutrition & Thali Builder)
                </label>
                <div className="grid grid-cols-3 gap-2.5">
                  {[
                    {
                      id: "veg" as const,
                      icon: "🌱",
                      title: "Pure Veg",
                      sub: "Paneer, Soya, Chana, Dahi, Whey (No Egg/Meat)",
                    },
                    {
                      id: "egg" as const,
                      icon: "🥚",
                      title: "Eggetarian",
                      sub: "Veg + Boiled Eggs & Omelette (No Chicken)",
                    },
                    {
                      id: "nonveg" as const,
                      icon: "🍗",
                      title: "Non-Veg",
                      sub: "Chicken, Eggs, Fish + All Desi Veg Sources",
                    },
                  ].map((d) => {
                    const sel = dietPreference === d.id;
                    return (
                      <button
                        key={d.id}
                        type="button"
                        onClick={() => {
                          playSound("click");
                          setDietPreference(d.id);
                        }}
                        className={`p-3.5 rounded-2xl border-2 text-center transition-all cursor-pointer flex flex-col items-center ${
                          sel
                            ? "bg-emerald-500/15 border-emerald-400 text-white shadow-[0_0_15px_rgba(16,185,129,0.2)]"
                            : "bg-[#0D1328] border-white/10 text-neutral-400"
                        }`}
                      >
                        <span className="text-2xl mb-1">{d.icon}</span>
                        <span className="text-xs font-black uppercase">{d.title}</span>
                        <span className="text-[9px] text-neutral-400 mt-1 leading-tight">{d.sub}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Hostel Mess vs Home Kitchen */}
              <div className="space-y-2.5">
                <label className="text-[10px] font-mono font-black uppercase text-neutral-400 tracking-widest block">
                  2. Living & Kitchen Setup
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    {
                      id: "home" as const,
                      icon: "🏠",
                      title: "Home Kitchen",
                      desc: "Full access to home-cooked Roti, Dal, Paneer & family meals",
                    },
                    {
                      id: "hostel" as const,
                      icon: "🛏️",
                      title: "Hostel / PG Mess",
                      desc: "Student budget macros: Soya Chunks, Peanuts, Curd, Boiled Eggs & Mess Dal",
                    },
                  ].map((k) => (
                    <button
                      key={k.id}
                      type="button"
                      onClick={() => {
                        playSound("click");
                        setKitchenSetup(k.id);
                      }}
                      className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                        kitchenSetup === k.id
                          ? "bg-[#14F1E1]/15 border-[#14F1E1] text-white"
                          : "bg-[#0D1328] border-white/10 text-neutral-400"
                      }`}
                    >
                      <span className="text-xl">{k.icon}</span>
                      <p className="text-xs font-black uppercase mt-1">{k.title}</p>
                      <p className="text-[10px] text-neutral-400 mt-0.5 leading-snug">{k.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Primary Goal */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono font-black uppercase text-neutral-400 tracking-widest block">
                  3. Calorie & Recomposition Direction
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: "muscle", label: "💪 Lean Bulk" },
                    { id: "fatburn", label: "🔥 Shred / Cut" },
                    { id: "strength", label: "⚡ Recomp / Power" },
                  ].map((g) => (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => {
                        playSound("click");
                        setMainGoal(g.id);
                      }}
                      className={`py-3 rounded-xl border text-xs font-black uppercase cursor-pointer ${
                        mainGoal === g.id
                          ? "bg-[#B66DFF]/20 border-[#B66DFF] text-white"
                          : "bg-[#0D1328] border-white/10 text-neutral-400"
                      }`}
                    >
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => {
                  playSound("click");
                  setStep(5);
                }}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#14F1E1] to-[#4DA8FF] text-black font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Next: 10-Sec AI Power Scan</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {/* ════════════════════════════════════════════════════════════════
              STAGE 5 (FEATURE #3): LIVE 10-SEC AI CAMERA BASELINE SCAN
             ════════════════════════════════════════════════════════════════ */}
          {step === 5 && (
            <motion.div
              key="stage-5"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1.5">
                <span className="text-[10px] font-mono font-black uppercase tracking-widest px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  STAGE 5 • AI VISION CALIBRATION
                </span>
                <h2 className="text-2xl font-black uppercase tracking-tight">
                  10-Second <span className="text-[#14F1E1]">AI Power & Posture</span> Check
                </h2>
                <p className="text-xs text-neutral-400">
                  Test Fit Genie&apos;s AI Camera right now to lock your Day-1 Posture & Symmetry baseline score!
                </p>
              </div>

              <div className="relative aspect-[4/3] max-h-64 w-full mx-auto bg-black rounded-3xl border-2 border-[#14F1E1]/40 overflow-hidden flex items-center justify-center">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`w-full h-full object-cover -scale-x-100 ${cameraScanning ? "opacity-90" : "hidden"}`}
                />

                {!cameraScanning && !baselineScanned && (
                  <div className="text-center p-6 space-y-2">
                    <Camera className="w-12 h-12 text-[#14F1E1] mx-auto animate-pulse" />
                    <p className="text-sm font-black uppercase text-white">AI Biometric Reticle Ready</p>
                    <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                      Click scan below for a quick Day-1 posture & frame calibration (or skip if you&apos;re in public).
                    </p>
                  </div>
                )}

                {baselineScanned && !cameraScanning && (
                  <div className="text-center p-6 space-y-2 bg-[#0D1328]/90 inset-0 absolute flex flex-col items-center justify-center">
                    <ShieldCheck className="w-12 h-12 text-emerald-400 mx-auto" />
                    <span className="text-[10px] font-mono uppercase text-emerald-300 font-bold">
                      DAY-1 BASELINE VERIFIED
                    </span>
                    <div className="text-4xl font-black font-mono text-[#14F1E1]">
                      {aiBaselineScore}/100
                    </div>
                    <p className="text-xs text-neutral-300 max-w-xs">
                      Starting frame calibrated! Target Day-90 Biometric Rating: <strong className="text-amber-300">96/100</strong>
                    </p>
                  </div>
                )}

                {/* Laser Scan Line */}
                {cameraScanning && (
                  <motion.div
                    initial={{ top: "8%" }}
                    animate={{ top: ["8%", "90%", "8%"] }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                    className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#14F1E1] to-transparent shadow-[0_0_20px_#14F1E1]"
                  />
                )}
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  onClick={startAiCameraCalibration}
                  disabled={cameraScanning}
                  className="flex-1 py-4 rounded-2xl bg-[#14F1E1]/20 hover:bg-[#14F1E1]/30 border border-[#14F1E1] text-[#14F1E1] font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  {cameraScanning
                    ? `Calibrating AI (${cameraProgress}%)...`
                    : baselineScanned
                    ? "Re-Scan AI Baseline"
                    : "⚡ Run 3-Sec AI Camera Scan"}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    playSound("click");
                    setStep(6);
                  }}
                  className="flex-1 py-4 rounded-2xl bg-gradient-to-r from-[#14F1E1] to-[#B66DFF] text-black font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Reveal My 90-Day Glow-Up</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}

          {/* ════════════════════════════════════════════════════════════════
              STAGE 6 (FEATURES #2 & #7): 90-DAY GLOW-UP BLUEPRINT & BLOOD OATH
             ════════════════════════════════════════════════════════════════ */}
          {step === 6 && (
            <motion.div
              key="stage-6"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1">
                <span className="text-[10px] font-mono font-black uppercase tracking-widest px-3 py-1 rounded-full bg-[#14F1E1]/20 text-[#14F1E1] border border-[#14F1E1]/40">
                  90-DAY TRANSFORMATION BLUEPRINT READY
                </span>
                <h2 className="text-2xl sm:text-3xl font-black uppercase tracking-tight mt-1">
                  {name || "Warrior"}&apos;s <span className="text-[#14F1E1]">Glow-Up Contract</span>
                </h2>
                <p className="text-xs text-neutral-400 font-mono">
                  Assigned Class: <strong className="text-amber-300">{selectedPathObj.warriorClass}</strong> • Target Date:{" "}
                  <strong className="text-[#14F1E1]">{target90DateStr}</strong>
                </p>
              </div>

              {/* FEATURE #2: DAY 1 VS DAY 90 GLOW-UP PROJECTION CARD */}
              <div className="bg-gradient-to-br from-[#0D1328] via-[#090F22] to-black border-2 border-[#14F1E1]/40 rounded-3xl p-5 space-y-4 shadow-[0_0_40px_rgba(20,241,225,0.15)]">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div>
                    <span className="text-[9px] font-mono uppercase text-neutral-400 block">ACTIVE APP MODE</span>
                    <span className="text-sm font-black text-white uppercase flex items-center gap-1.5">
                      {selectedPathObj.emoji} {selectedPathObj.title}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] font-mono uppercase text-neutral-400 block">DIET FILTER</span>
                    <span className="text-xs font-black text-emerald-400 uppercase">
                      {dietPreference === "veg"
                        ? "🌱 Pure Veg Only"
                        : dietPreference === "egg"
                        ? "🥚 Eggetarian"
                        : "🍗 Non-Veg"}
                    </span>
                  </div>
                </div>

                {/* Day 1 vs Day 90 Projection Bars */}
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-[11px] font-mono font-bold mb-1">
                      <span className="text-neutral-400">Overall Aesthetic & Physique Score</span>
                      <span className="text-[#14F1E1]">Day 1: 54% ➔ Day 90: 94% 🔥</span>
                    </div>
                    <div className="w-full h-2.5 bg-black rounded-full overflow-hidden border border-white/10 flex">
                      <div className="w-[54%] bg-neutral-600 h-full" />
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: "40%" }}
                        transition={{ duration: 1, delay: 0.2 }}
                        className="bg-gradient-to-r from-[#14F1E1] to-[#B66DFF] h-full"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] font-mono font-bold mb-1">
                      <span className="text-neutral-400">Pushup / Upper-Body Endurance</span>
                      <span className="text-amber-300">12 Reps ➔ 50+ Non-Stop Reps ⚡</span>
                    </div>
                    <div className="w-full h-2.5 bg-black rounded-full overflow-hidden border border-white/10">
                      <motion.div
                        initial={{ width: "20%" }}
                        animate={{ width: "92%" }}
                        transition={{ duration: 1.1, delay: 0.3 }}
                        className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] font-mono font-bold mb-1">
                      <span className="text-neutral-400">Posture Height & Jawline Definition</span>
                      <span className="text-[#B66DFF]">+1.8cm Posture & {selectedDreamObj.label}</span>
                    </div>
                    <div className="w-full h-2.5 bg-black rounded-full overflow-hidden border border-white/10">
                      <motion.div
                        initial={{ width: "30%" }}
                        animate={{ width: "95%" }}
                        transition={{ duration: 1.2, delay: 0.4 }}
                        className="bg-gradient-to-r from-[#B66DFF] to-[#14F1E1] h-full"
                      />
                    </div>
                  </div>
                </div>

                {/* Daily Fuel Telemetry Grid */}
                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/10 text-center">
                  <div className="bg-black/50 rounded-2xl p-2.5 border border-white/5">
                    <span className="text-[9px] font-mono text-neutral-400 uppercase block">
                      {t("Roz Ki Calories", "Daily Calories")}
                    </span>
                    <span className="text-sm font-black font-mono text-white">{dailyCalorieTarget} kcal</span>
                  </div>
                  <div className="bg-black/50 rounded-2xl p-2.5 border border-white/5">
                    <span className="text-[9px] font-mono text-neutral-400 uppercase block">
                      {t("Protein Goal", "Protein Target")}
                    </span>
                    <span className="text-sm font-black font-mono text-[#14F1E1]">{Math.max(weight * 2, 90)}g</span>
                  </div>
                  <div className="bg-black/50 rounded-2xl p-2.5 border border-white/5">
                    <span className="text-[9px] font-mono text-neutral-400 uppercase block">
                      {t("Paani Target", "Hydration")}
                    </span>
                    <span className="text-sm font-black font-mono text-[#4DA8FF]">{waterIntakeGoal} ml</span>
                  </div>
                </div>

                {/* CUSTOM PERSONAL EXERCISE BLUEPRINT BASED ON ONBOARDING CHOICES */}
                <div className="pt-3 border-t border-white/10 space-y-2">
                  <span className="text-[9px] font-mono font-black uppercase tracking-widest text-[#14F1E1] block">
                    🎯 {t(
                      `Tere Selection (${selectedPathObj.title} + ${mainGoal.toUpperCase()}) Ke Hisaab Se Custom Exercises:`,
                      `Your Custom Exercise Split (${selectedPathObj.title} + ${mainGoal.toUpperCase()}):`
                    )}
                  </span>
                  <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                    {(trainingPath === "calisthenics"
                      ? [
                          "🤸 Explosive Pushup & Diamond Progression",
                          "🧗 Pull-Up / Scapular Bar Mastery",
                          "📐 Pike Handstand Shoulder Press",
                          "⚡ Hollow Body & L-Sit Core Lock",
                        ]
                      : trainingPath === "gym"
                      ? [
                          "🏋️ Incline Barbell / Dumbbell Press",
                          "🦍 Wide Lat Pulldown & Heavy Row",
                          "🔱 Overhead Press & Cable Lateral Raise",
                          "🦵 Barbell Squat & Romanian Deadlift",
                        ]
                      : trainingPath === "home_jugaad"
                      ? [
                          "🎒 Loaded College Backpack Pushups",
                          "🪣 20L Water Bucket Rows & Curls",
                          "🚪 Door-Frame Towel Back Pulls",
                          "🔥 Desi Dand-Baithak & Floor Core",
                        ]
                      : [
                          "🗿 1.618 V-Taper Lateral Delt & Lat Width",
                          "📐 Upper Clavicular Chest Shelf Push",
                          "🧬 Cervical Posture & Jawline De-Bloat",
                          "⚡ Stomach Vacuum Waist Tightener",
                        ]
                    ).map((drill, idx) => (
                      <div
                        key={idx}
                        className="p-2 rounded-xl bg-white/5 border border-white/10 text-neutral-200 font-bold"
                      >
                        {drill}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* FEATURE #7: BIOMETRIC FINGERPRINT BLOOD OATH BUTTON */}
              <div className="bg-[#0D1328] border border-[#14F1E1]/30 rounded-3xl p-5 text-center space-y-3">
                <p className="text-[11px] font-mono uppercase tracking-wider text-neutral-300">
                  {t(
                    "Apna 90-Day Contract lock karne ke liye Fingerprint hold ya tap kar (+100 XP)",
                    "Press & Hold Fingerprint (or Tap) to Sign Your 90-Day Blood Oath (+100 XP)"
                  )}
                </p>

                <button
                  type="button"
                  onMouseDown={startHoldingOath}
                  onMouseUp={stopHoldingOath}
                  onMouseLeave={stopHoldingOath}
                  onTouchStart={startHoldingOath}
                  onTouchEnd={stopHoldingOath}
                  onClick={() => {
                    // Instant accessibility boost if user taps instead of holding
                    setOathProgress((prev) => {
                      const next = Math.min(100, prev + 35);
                      if (next >= 100) completeGlowUpOnboarding();
                      return next;
                    });
                  }}
                  className="relative w-24 h-24 mx-auto rounded-full bg-black border-2 border-[#14F1E1] flex flex-col items-center justify-center shadow-[0_0_30px_rgba(20,241,225,0.35)] active:scale-95 transition-all cursor-pointer select-none overflow-hidden"
                >
                  <div
                    className="absolute bottom-0 left-0 right-0 bg-[#14F1E1]/30 transition-all"
                    style={{ height: `${oathProgress}%` }}
                  />
                  <Fingerprint
                    className={`w-11 h-11 relative z-10 ${
                      isHoldingOath ? "text-[#14F1E1] animate-pulse scale-110" : "text-white"
                    }`}
                  />
                  <span className="text-[9px] font-mono font-black text-[#14F1E1] relative z-10 mt-0.5">
                    {oathProgress}%
                  </span>
                </button>

                <button
                  type="button"
                  onClick={completeGlowUpOnboarding}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#14F1E1] via-[#4DA8FF] to-[#B66DFF] text-black font-black text-xs uppercase tracking-widest shadow-[0_0_20px_rgba(20,241,225,0.3)] cursor-pointer"
                >
                  ⚡ {t("Mera Custom Dashboard Kholo (+100 XP)", "Activate My Custom Dashboard (+100 XP)")}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
