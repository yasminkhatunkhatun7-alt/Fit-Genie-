import React, { useState, useMemo, useEffect } from "react";
import { RotateCw, Box, Layers } from "lucide-react";
import Model, { IExerciseData, IMuscleStats } from "react-body-highlighter";
import { playSound } from "../utils/audio";
import { AnimatePresence, motion } from "motion/react";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";

export interface MuscleSelectorProps {
  selectedMuscles: string[];
  toggleMuscle: (muscle: string) => void;
  readonly?: boolean;
  initialSide?: "front" | "back";
  side?: "front" | "back";
  onSideChange?: (side: "front" | "back") => void;
  customData?: IExerciseData[];
  highlightedColors?: string[];
  hidePills?: boolean;
  exerciseType?: "STRETCH" | "WORKOUT" | "EXERCISE" | string;
  category?: string;
  exerciseName?: string;
}

export const INTERNAL_TO_DISPLAY: Record<string, string> = {
  "chest": "Chest",
  "front-deltoids": "Shoulders",
  "back-deltoids": "Shoulders",
  "biceps": "Biceps",
  "triceps": "Triceps",
  "forearm": "Forearms",
  "abs": "Abs",
  "obliques": "Obliques",
  "quadriceps": "Quads",
  "hamstring": "Hamstrings",
  "calves": "Calves",
  "gluteal": "Glutes",
  "upper-back": "Back",
  "lower-back": "Back",
  "trapezius": "Traps",
  "neck": "Neck",
};

export const DISPLAY_TO_INTERNAL: Record<string, string[]> = {
  "Chest": ["chest"],
  "Shoulders": ["front-deltoids", "back-deltoids"],
  "Biceps": ["biceps"],
  "Triceps": ["triceps"],
  "Forearms": ["forearm"],
  "Abs": ["abs"],
  "Obliques": ["obliques"],
  "Quads": ["quadriceps"],
  "Hamstrings": ["hamstring"],
  "Calves": ["calves"],
  "Glutes": ["gluteal"],
  "Back": ["upper-back", "lower-back"],
  "Traps": ["trapezius"],
  "Neck": ["neck"],
  "Core": ["abs", "obliques"],
  "Core & Abs": ["abs", "obliques"],
  "Legs": ["quadriceps", "hamstring"],
  "Quads & Legs": ["quadriceps"],
  "Lats & Back": ["upper-back", "lower-back"],
  "Lats": ["upper-back"],
  "Lower Back": ["lower-back"],
  "Rear Delts": ["back-deltoids"],
};

export const MUSCLE_SIDE_MAP: Record<string, "front" | "back" | "both"> = {
  "Chest": "front",
  "Shoulders": "both",
  "Biceps": "front",
  "Triceps": "back",
  "Forearms": "both",
  "Abs": "front",
  "Obliques": "front",
  "Quads": "front",
  "Hamstrings": "back",
  "Calves": "both",
  "Glutes": "back",
  "Back": "back",
  "Traps": "back",
  "Neck": "front",
};

const MUSCLE_DEMO_EXERCISE: Record<string, string> = {
  "Chest": "Push Ups",
  "Shoulders": "Pike Push Ups",
  "Biceps": "Dumbbell Bicep Curls",
  "Triceps": "Parallel Bar Dips",
  "Forearms": "Dead Hang",
  "Abs": "Plank Hold",
  "Obliques": "Russian Twists",
  "Quads": "Squats",
  "Hamstrings": "Romanian Deadlifts",
  "Calves": "Calf Raises",
  "Glutes": "Hip Thrusts",
  "Back": "Pull Ups",
  "Traps": "Shoulder Shrugs",
  "Neck": "Neck Flexion",
};

const PILL_MUSCLES = [
  "Chest",
  "Shoulders",
  "Biceps",
  "Triceps",
  "Forearms",
  "Abs",
  "Obliques",
  "Quads",
  "Hamstrings",
  "Calves",
  "Glutes",
  "Back",
  "Traps",
  "Neck",
];

export default function MuscleSelector({
  selectedMuscles,
  toggleMuscle,
  readonly = false,
  initialSide,
  side: controlledSide,
  onSideChange,
  customData,
  highlightedColors = ["#14F1E1"],
  hidePills = false,
  exerciseType,
  category,
  exerciseName,
}: MuscleSelectorProps) {
  const [scanMode, setScanMode] = useState<"3d" | "2d">("3d");

  const computedInitialFront = useMemo(() => {
    if (initialSide) return initialSide === "front";
    if (selectedMuscles.length > 0) {
      const first = selectedMuscles[0];
      if (MUSCLE_SIDE_MAP[first] === "back") return false;
    }
    return true;
  }, [initialSide, selectedMuscles]);

  const [internalIsFront, setInternalIsFront] = useState<boolean>(computedInitialFront);

  useEffect(() => {
    if (controlledSide) {
      setInternalIsFront(controlledSide === "front");
    }
  }, [controlledSide]);

  const isFront = controlledSide ? controlledSide === "front" : internalIsFront;

  const setSide = (front: boolean) => {
    playSound("toggle");
    setInternalIsFront(front);
    if (onSideChange) {
      onSideChange(front ? "front" : "back");
    }
  };

  const flipModel = () => {
    setSide(!isFront);
  };

  const data: IExerciseData[] = useMemo(() => {
    if (customData) return customData;
    const mappedMuscles: string[] = [];
    selectedMuscles.forEach((m) => {
      const mapped = DISPLAY_TO_INTERNAL[m];
      if (mapped) {
        mappedMuscles.push(...mapped);
      } else {
        mappedMuscles.push(m.toLowerCase());
      }
    });
    return [{ name: "Workout", muscles: mappedMuscles as any }];
  }, [customData, selectedMuscles]);

  const handleClick = (stats: IMuscleStats) => {
    if (readonly) return;
    const displayName = INTERNAL_TO_DISPLAY[stats.muscle] || stats.muscle;
    toggleMuscle(displayName);
  };

  const handlePillClick = (muscleName: string) => {
    if (readonly) return;
    const preferredSide = MUSCLE_SIDE_MAP[muscleName];
    if (preferredSide === "front" && !isFront) {
      setInternalIsFront(true);
      onSideChange?.("front");
    } else if (preferredSide === "back" && isFront) {
      setInternalIsFront(false);
      onSideChange?.("back");
    }
    toggleMuscle(muscleName);
  };

  const activeDemoExercise = useMemo(() => {
    if (selectedMuscles.length === 0) return "Push Ups";
    const lastSelected = selectedMuscles[selectedMuscles.length - 1];
    return MUSCLE_DEMO_EXERCISE[lastSelected] || "Squats";
  }, [selectedMuscles]);

  return (
    <div className="flex flex-col items-center justify-center w-full select-none">
      {/* Header + 3D Hologram / 2D Vector Mode Switcher */}
      <div className="flex flex-wrap items-center justify-between w-full mb-3 px-2 gap-2 relative z-10">
        <div className="flex items-center gap-1.5 bg-[#0A1128] p-1 rounded-xl border border-[#14F1E1]/30">
          <button
            type="button"
            onClick={() => {
              playSound("click");
              setScanMode("3d");
            }}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all ${
              scanMode === "3d"
                ? "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_10px_rgba(20,241,225,0.5)]"
                : "text-neutral-400 hover:text-white"
            }`}
          >
            <Box className="w-3 h-3" /> 3D Hologram
          </button>
          <button
            type="button"
            onClick={() => {
              playSound("click");
              setScanMode("2d");
            }}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all ${
              scanMode === "2d"
                ? "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_10px_rgba(20,241,225,0.5)]"
                : "text-neutral-400 hover:text-white"
            }`}
          >
            <Layers className="w-3 h-3" /> Tap Map
          </button>
        </div>

        {scanMode === "2d" && (
          <div className="flex items-center gap-2">
            <div className="flex bg-black/50 p-1 rounded-xl border border-[#14F1E1]/25">
              <button
                type="button"
                onClick={() => setSide(true)}
                className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider cursor-pointer ${
                  isFront
                    ? "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_10px_rgba(20,241,225,0.5)]"
                    : "text-neutral-400 hover:text-white"
                }`}
              >
                Front
              </button>
              <button
                type="button"
                onClick={() => setSide(false)}
                className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider cursor-pointer ${
                  !isFront
                    ? "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_10px_rgba(20,241,225,0.5)]"
                    : "text-neutral-400 hover:text-white"
                }`}
              >
                Back
              </button>
            </div>

            <button
              type="button"
              onClick={flipModel}
              title="Flip Front / Back"
              className="bg-[#14F1E1]/10 hover:bg-[#14F1E1]/25 p-2 rounded-full border border-[#14F1E1]/30 flex items-center justify-center text-[#14F1E1] active:scale-90 cursor-pointer"
            >
              <RotateCw className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* 3D HOLOGRAM ANATOMY SCANNER vs 2D TAP MAP */}
      {scanMode === "3d" ? (
        <div className="w-full max-w-md mx-auto rounded-2xl overflow-hidden border border-[#14F1E1]/30 bg-[#050B1A] shadow-[0_0_30px_rgba(20,241,225,0.12)]">
          <Exercise3DCharacterLoop
            exerciseName={activeDemoExercise}
            targetMuscles={selectedMuscles.length > 0 ? selectedMuscles : ["Chest", "Core", "Quads"]}
            difficulty="intermediate"
            category={category}
            exerciseType={exerciseType}
            heightClass="h-[290px]"
            showControls={true}
          />
        </div>
      ) : (
        <div className="relative w-[260px] h-[340px] mx-auto bg-transparent flex items-center justify-center">
          <div className="absolute inset-0 bg-[#14F1E1]/5 rounded-full blur-[40px] pointer-events-none" />

          <div
            className={`relative z-10 w-full h-full flex items-center justify-center drop-shadow-[0_0_12px_rgba(20,241,225,0.35)] ${
              isFront ? "block" : "hidden"
            }`}
          >
            <Model
              type="anterior"
              data={data}
              bodyColor="#1a2333"
              highlightedColors={highlightedColors}
              onClick={handleClick}
              style={{ width: "100%", height: "100%" }}
            />
          </div>

          <div
            className={`relative z-10 w-full h-full flex items-center justify-center drop-shadow-[0_0_12px_rgba(20,241,225,0.35)] ${
              !isFront ? "block" : "hidden"
            }`}
          >
            <Model
              type="posterior"
              data={data}
              bodyColor="#1a2333"
              highlightedColors={highlightedColors}
              onClick={handleClick}
              style={{ width: "100%", height: "100%" }}
            />
          </div>
        </div>
      )}

      {!readonly && (() => {
        const isStretch =
          exerciseType?.toUpperCase() === "STRETCH" ||
          category?.toLowerCase().includes("stretch") ||
          category?.toLowerCase().includes("flexibility") ||
          category?.toLowerCase().includes("mobility") ||
          exerciseName?.toLowerCase().includes("stretch");

        const formattedMuscles = selectedMuscles.map((m) => m.toUpperCase()).join(", ");
        const headerText = isStretch
          ? selectedMuscles.length > 1
            ? `TARGET AREAS: ${formattedMuscles}`
            : `TARGET AREA: ${formattedMuscles}`
          : `MUSCLES TARGETED: ${formattedMuscles}`;

        const emptyText = isStretch
          ? "Tap Muscles Below to Select Stretch Target Area"
          : "Tap Muscles Below to Select Target Anatomy";

        return (
          <div className="mt-2.5 text-center h-6">
            <AnimatePresence mode="popLayout">
              {selectedMuscles.length > 0 ? (
                <motion.p
                  key="selected"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  className="text-[#14F1E1] text-xs font-bold uppercase tracking-widest drop-shadow-[0_0_8px_rgba(20,241,225,0.5)]"
                >
                  {headerText}
                </motion.p>
              ) : (
                <motion.p
                  key="none"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  className="text-neutral-400 text-xs font-bold uppercase tracking-widest"
                >
                  {emptyText}
                </motion.p>
              )}
            </AnimatePresence>
          </div>
        );
      })()}

      {!readonly && !hidePills && (
        <div className="mt-3 flex flex-wrap justify-center gap-2 px-2">
          {PILL_MUSCLES.map((m) => (
            <button
              type="button"
              key={m}
              onClick={() => handlePillClick(m)}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all cursor-pointer ${
                selectedMuscles.includes(m)
                  ? "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_12px_rgba(20,241,225,0.5)] scale-105"
                  : "bg-[#0A1128] border border-[#14F1E1]/20 text-neutral-300 hover:text-white hover:border-[#14F1E1]/50"
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
