import { doc, getDoc, setDoc, onSnapshot, collection, increment } from '../lib/firestore';
import { db } from '../lib/firebase';
import React, { useState, useEffect } from "react";
import { 
  Play, Search, Heart, Clock, ChevronDown, ChevronRight, 
  Dumbbell, Youtube, Activity, Video, Award, Info, 
  AlertCircle, Filter, ArrowLeft, HeartOff, Sparkles, Check,
  Archive, Trash2, Undo, ShieldAlert, Plus, Trash
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import InteractiveBody from "./InteractiveBody";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";
import { playSound } from "../utils/audio";
import { useAuth } from "../context/AuthContext";
import { MARTIAL_LESSONS, DEFAULT_MARTIAL_VIDEO_URLS, MARTIAL_LESSONS_MUSCLES } from "./MartialArts";
import { HEIGHT_EXERCISES } from "./HeightIncrease";
import { useLocalStorageSync } from "../hooks/useLocalStorageSync";
import { GlobalCompletionCounter, incrementCompletionCount } from "./GlobalCompletionCounter";
import { ConfirmModal } from "./ConfirmModal";

// Helper function to extract 11-character YouTube video ID
export function getYouTubeId(url: string | undefined): string | null {
  if (!url) return null;
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|shorts\/)([^#\&\?]*).*/;
  const match = url.match(regExp);
  return (match && match[2] && match[2].length === 11) ? match[2] : null;
}

// Exercise Interface for the Video Player Catalog
interface VideoExercise {
  id: string;
  name: string;
  youtubeId: string; // Used as fallback backward compatible but we cleared static IDs
  muscles: string[]; // for InteractiveBody highlights (should match chest, back, shoulders, biceps, triceps, core, glutes, legs, calves)
  targetMuscleLabel: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  duration: string;
  equipment: "home" | "gym";
  instructions: string[];
  mistakes: string[];
  tips: string[];
  recommendedSets: number;
  recommendedReps: string;
  restTime: string;
  categories: string[]; // chest, back, shoulders, biceps, triceps, legs, abs, full_body, home, gym, warm_up, stretching
}

// Complete rich local store mockup dataset featuring all default exercises but cleanly stripped of hardcoded YouTube links
const VIDEO_DATABASE: VideoExercise[] = [
  // --- ABS EXERCISES ---
  {
    id: "v_abs_1",
    name: "Crunches",
    youtubeId: "",
    muscles: ["core"],
    targetMuscleLabel: "Upper Abs",
    difficulty: "beginner",
    duration: "4 Mins",
    equipment: "home",
    instructions: [
      "Lie on your back with knees bent and feet flat on the floor, hip-width apart.",
      "Place your hands lightly behind your head or cross them over your chest.",
      "Engage your core and slowly lift your shoulders off the floor, keeping your lower back pressed down.",
      "Squeeze your abs at the top of the movement for a second, then lower back down with control."
    ],
    mistakes: [
      "Pulling on your neck with your hands, which causes strain.",
      "Lifting the core too high like a full sit-up."
    ],
    tips: [
      "Exhale as you crunch upward; inhale as you slowly lower.",
      "Focus on sliding your ribs down towards your hips."
    ],
    recommendedSets: 3,
    recommendedReps: "15-20 Reps",
    restTime: "45 Secs",
    categories: ["abs", "home"]
  },
  {
    id: "v_abs_2",
    name: "Reverse Crunches",
    youtubeId: "",
    muscles: ["core"],
    targetMuscleLabel: "Lower Abs",
    difficulty: "beginner",
    duration: "5 Mins",
    equipment: "home",
    instructions: [
      "Lie on your back with knees bent at 90 degrees and hands at your sides.",
      "Contract your lower abs to pull your knees toward your chest.",
      "Raise your hips slightly off the floor at the peak of the movement.",
      "Slowly lower your legs back to starting position without letting your lower back arch."
    ],
    mistakes: [
      "Using momentum and swinging your legs rapidly.",
      "Letting your knees go completely straight, stressing the hip flexors."
    ],
    tips: [
      "Press your palms flat into the carpet for support.",
      "Initiate the movement purely with your lower core muscles."
    ],
    recommendedSets: 3,
    recommendedReps: "12-15 Reps",
    restTime: "45 Secs",
    categories: ["abs", "home"]
  },
  {
    id: "v_abs_3",
    name: "Bicycle Crunches",
    youtubeId: "",
    muscles: ["core", "obliques"],
    targetMuscleLabel: "Obliques & Core",
    difficulty: "intermediate",
    duration: "6 Mins",
    equipment: "home",
    instructions: [
      "Lie flat on the floor with your lower back pressed to the ground.",
      "Put your hands behind your head, elbow bent widely.",
      "Lift knees up and alternate bringing opposite elbow to opposite knee (left elbow to right knee) while fully extending the other leg.",
      "Switch sides in a smooth, continuous pedaling motion."
    ],
    mistakes: [
      "Rotate from your elbows rather than from your shoulders/shoulder blade.",
      "Pedaling too fast without getting full oblique extension."
    ],
    tips: [
      "Maintain a slow tempo to maximize time under tension.",
      "Keep your shoulders elevated off the floor throughout the sets."
    ],
    recommendedSets: 3,
    recommendedReps: "20 Reps (10/side)",
    restTime: "50 Secs",
    categories: ["abs", "cardio", "home"]
  },
  {
    id: "v_abs_4",
    name: "Lying Leg Raises",
    youtubeId: "",
    muscles: ["core"],
    targetMuscleLabel: "Lower Rectus Abdominis",
    difficulty: "beginner",
    duration: "4 Mins",
    equipment: "home",
    instructions: [
      "Lie flat on your back, legs straight, and hands placed flat under your glutes for tailbone support.",
      "Keeping your legs as straight as possible, slowly raise them up to a 90-degree angle.",
      "Lower your legs back down slowly towards the floor, stopping just an inch above the ground.",
      "Raise them back up immediately, maintaining abdominal tension throughout."
    ],
    mistakes: [
      "Arching the lower back off the floor, which causes lumbar strain.",
      "Letting legs drop rapidly with gravity."
    ],
    tips: [
      "Inhale as you lower; exhale as you raise your feet.",
      "Press your navel down into the floor to lock your lumbar spine."
    ],
    recommendedSets: 3,
    recommendedReps: "12-15 Reps",
    restTime: "60 Secs",
    categories: ["abs", "home"]
  },
  {
    id: "v_abs_5",
    name: "Hanging Leg Raises",
    youtubeId: "",
    muscles: ["core"],
    targetMuscleLabel: "Entire Lower Core & Hip Flexors",
    difficulty: "advanced",
    duration: "6 Mins",
    equipment: "gym",
    instructions: [
      "Hang from a pull-up bar with an overhand grip, arms completely straight.",
      "Keeping your legs straight, engage your core and lift your feet up until legs are parallel to the floor.",
      "Hold the contraction for a split second, then lower your legs with deep control.",
      "Avoid swinging your torso or using momentum."
    ],
    mistakes: [
      "Swinging the body back and forth like a pendulum.",
      "Shrugging shoulders into the ears during the hanging state."
    ],
    tips: [
      "Keep your shoulder blades pulled down and back (active hang).",
      "Squeeze your quad muscles to help maintain fully straight knees."
    ],
    recommendedSets: 3,
    recommendedReps: "8-12 Reps",
    restTime: "75 Secs",
    categories: ["abs", "gym"]
  },
  {
    id: "v_abs_6",
    name: "Mountain Climbers",
    youtubeId: "",
    muscles: ["core", "shoulders"],
    targetMuscleLabel: "Cardio Abs & Shoulders",
    difficulty: "beginner",
    duration: "5 Mins",
    equipment: "home",
    instructions: [
      "Start in a solid plank position with hands directly under shoulders and weight on toes.",
      "Drive your right knee forward towards your chest, keeping your hips level.",
      "Quickly step the right foot back while simultaneously driving your left knee forward.",
      "Alternate legs quickly in a running motion, maintaining a flat back."
    ],
    mistakes: [
      "Piking the hips high up in the air.",
      "Bouncing the body up and down while pumping legs."
    ],
    tips: [
      "Keep your shoulders directly over your wrists throughout.",
      "Keep your target abs braced as if preparing for a punch."
    ],
    recommendedSets: 3,
    recommendedReps: "45 Seconds Work",
    restTime: "45 Secs",
    categories: ["abs", "cardio", "home"]
  },
  {
    id: "v_abs_7",
    name: "Russian Twists",
    youtubeId: "",
    muscles: ["core", "obliques"],
    targetMuscleLabel: "Oblique Rotational Strength",
    difficulty: "intermediate",
    duration: "5 Mins",
    equipment: "home",
    instructions: [
      "Sit on the floor with knees bent and feet flat. Lean your torso back at a 45-degree angle.",
      "Clasp your hands together in front of your chest and lift your feet dynamic off the floor, balancing on your tailbone.",
      "Rotate your torso to the right, tapping your hands on the ground next to your right hip.",
      "Rotate all the way over to the left side and tap. Repeat in a controlled, rhythmic pattern."
    ],
    mistakes: [
      "Only moving the arms back and forth without rotating the actual shoulders.",
      "Hunching the back instead of keeping a proud chest."
    ],
    tips: [
      "Follow your hands with your eyes to ensure true thoracic rotation.",
      "Squeeze knees together to stabilize the lower hip structure."
    ],
    recommendedSets: 3,
    recommendedReps: "20 Twists (10/side)",
    restTime: "45 Secs",
    categories: ["abs", "home"]
  },
  {
    id: "v_abs_8",
    name: "Flutter Kicks",
    youtubeId: "",
    muscles: ["core"],
    targetMuscleLabel: "Lower Ab Endurance",
    difficulty: "beginner",
    duration: "4 Mins",
    equipment: "home",
    instructions: [
      "Lie on your back with legs straight and hands under glutes or extended at your sides.",
      "Lift both feet about 6 inches off the floor and flatten your spine against the floor.",
      "Make small, rapid up-and-down scissor-like kicks with your legs.",
      "Keep your knees straight and core tight throughout the duration."
    ],
    mistakes: [
      "Lifting the legs too high, which removes core activation.",
      "Bending knees and doing a cycling motion."
    ],
    tips: [
      "Point your toes forward to maintain leg extension.",
      "Lift your head and shoulders slightly to increase upper abs tension."
    ],
    recommendedSets: 3,
    recommendedReps: "45 Seconds Work",
    restTime: "45 Secs",
    categories: ["abs", "cardio", "home"]
  },
  {
    id: "v_abs_9",
    name: "V-Ups (Jackknife Crunches)",
    youtubeId: "",
    muscles: ["core"],
    targetMuscleLabel: "Total Rectus Abdominis",
    difficulty: "advanced",
    duration: "5 Mins",
    equipment: "home",
    instructions: [
      "Lie flat on your back, legs straight and arms extended straight behind your head.",
      "In one explosive movement, contract your core and lift your legs and torso together, forming a 'V' shape.",
      "Reach your hands towards your toes or shins at the top of the movement.",
      "Slowly lower back down to the starting flat position with controlled decelerating force."
    ],
    mistakes: [
      "Bending knees excessively during the hinge.",
      "Letting the limbs crash back down to the floor without safety resist."
    ],
    tips: [
      "Initiate the curl-up with your abs, not by swinging your arms.",
      "Keep your body tight to maintain solid balance on your seat."
    ],
    recommendedSets: 3,
    recommendedReps: "10-12 Reps",
    restTime: "60 Secs",
    categories: ["abs", "home"]
  },
  {
    id: "v_abs_10",
    name: "Forearm Plank",
    youtubeId: "",
    muscles: ["core"],
    targetMuscleLabel: "Isometric Deep Core Stability",
    difficulty: "beginner",
    duration: "4 Mins",
    equipment: "home",
    instructions: [
      "Place your forearms flat on the floor, elbows aligned directly beneath your shoulders.",
      "Extend your legs straight behind you, toes tucked under, raising your entire body off the floor.",
      "Create a perfectly straight line from your head to your heels.",
      "Hold this rigid position while breathing deeply and continuously."
    ],
    mistakes: [
      "Letting your lower back sag towards the ground.",
      "Heaving your hips up like a mountain peak."
    ],
    tips: [
      "Squeeze your glutes and pull your kneecaps upward to lock your legs.",
      "Actively drag your elbows towards your toes to maximize core tension."
    ],
    recommendedSets: 3,
    recommendedReps: "60 Seconds Hold",
    restTime: "45 Secs",
    categories: ["abs", "home"]
  },
  {
    id: "v_abs_11",
    name: "Side Plank",
    youtubeId: "",
    muscles: ["core", "obliques"],
    targetMuscleLabel: "Lateral Core & Obliques",
    difficulty: "intermediate",
    duration: "5 Mins",
    equipment: "home",
    instructions: [
      "Lie on your right side with your legs straight, stacked directly on top of each other.",
      "Prop your torso up on your right elbow, which should be directly beneath your shoulder.",
      "Raise your hips off the floor until your body forms a straight diagonal line.",
      "Hold the position, then repeat on the opposite side."
    ],
    mistakes: [
      "Letting your top shoulder rotate forward towards the floor.",
      "Letting your hips sag towards the ground."
    ],
    tips: [
      "Reach your top hand straight up towards the ceiling to maintain structural line.",
      "Keep your neck aligned with the rest of your spine."
    ],
    recommendedSets: 3,
    recommendedReps: "30s Hold per Side",
    restTime: "45 Secs",
    categories: ["abs", "home"]
  },
  {
    id: "v_abs_12",
    name: "Lying Toe Touches",
    youtubeId: "",
    muscles: ["core"],
    targetMuscleLabel: "Upper Abs Concentration",
    difficulty: "beginner",
    duration: "4 Mins",
    equipment: "home",
    instructions: [
      "Lie flat on your back and raise both legs straight up towards the ceiling, soles of feet parallel to ceiling.",
      "Extend your arms straight up towards your toes.",
      "Contract your upper abs to raise your shoulder blades off the floor and reach your fingertips up to touch your toes.",
      "Slowly lower your shoulders back to the floor with control."
    ],
    mistakes: [
      "Lending momentum by swinging your arms back and forth.",
      "Letting your hips rock off the floor."
    ],
    tips: [
      "Keep your chin tucked slightly to prevent neck strain.",
      "Exhale sharply at the peak of the crunch."
    ],
    recommendedSets: 3,
    recommendedReps: "15-20 Reps",
    restTime: "45 Secs",
    categories: ["abs", "home"]
  },
  {
    id: "v_abs_13",
    name: "Lying Heel Touches (Alternate)",
    youtubeId: "",
    muscles: ["core", "obliques"],
    targetMuscleLabel: "Lower Obliques Sweep",
    difficulty: "beginner",
    duration: "5 Mins",
    equipment: "home",
    instructions: [
      "Lie flat on your back, knees bent, feet flat on the floor, about 12 inches away from your glutes.",
      "Lift your head and shoulders slightly off the ground, arms extended straight along your sides.",
      "Squeeze your obliques to slide horizontally, reaching your right finger to touch your right heel.",
      "Return to center and switch, reaching your left finger to touch your left heel."
    ],
    mistakes: [
      "Lifting your lower back off the floor.",
      "Straining your chin up; keep it tucked like a peach under your chin."
    ],
    tips: [
      "Maintain continuous upper ab contraction throughout the entire set.",
      "Widen your feet slightly to make the oblique sweep more challenging."
    ],
    recommendedSets: 3,
    recommendedReps: "24 Reps (12/side)",
    restTime: "45 Secs",
    categories: ["abs", "home"]
  },
  {
    id: "v_abs_14",
    name: "Dead Bug",
    youtubeId: "",
    muscles: ["core"],
    targetMuscleLabel: "Deep Multifidus & Transverse Abs",
    difficulty: "beginner",
    duration: "5 Mins",
    equipment: "home",
    instructions: [
      "Lie on your back with arms pointing straight up and knees bent at 90 degrees (tabletop position).",
      "Engage your core to press your flat lower back down into the floor.",
      "Slowly lower your right arm straight back behind your head while simultaneously extending your left leg straight forward.",
      "Bring both back to tabletop and repeat with your left arm and right leg."
    ],
    mistakes: [
      "Allowing the lower back to arch off the floor as limbs extend.",
      "Moving too fast and losing coordination."
    ],
    tips: [
      "Go as slow as humanly possible; pause for a second in the extended state.",
      "Keep the non-moving limbs dead still and vertical."
    ],
    recommendedSets: 3,
    recommendedReps: "16 Reps (8/side)",
    restTime: "45 Secs",
    categories: ["abs", "home"]
  },
  {
    id: "v_abs_15",
    name: "Hollow Body Hold",
    youtubeId: "",
    muscles: ["core"],
    targetMuscleLabel: "Gymnastics Anterior Core",
    difficulty: "advanced",
    duration: "5 Mins",
    equipment: "home",
    instructions: [
      "Lie flat on your back, arms extended straight overhead, legs straight and together.",
      "Squeeze your abs, thighs, and glutes tightly.",
      "Simultaneously lift your legs, head, shoulders, and arms about 3-6 inches off the floor.",
      "Ensure your lower back is pressed completely flat against the floor. Hold this curved banana shape."
    ],
    mistakes: [
      "Letting the lower back arch, creating space under your lumbar spine.",
      "Raising the legs too high to avoid core stress."
    ],
    tips: [
      "If too hard, modify by bending your knees or placing hands at your sides.",
      "Squeeze your inner thighs and ankles together to lock your alignment."
    ],
    recommendedSets: 3,
    recommendedReps: "30 Seconds Hold",
    restTime: "60 Secs",
    categories: ["abs", "home"]
  },

  // --- CHEST EXERCISES ---
  {
    id: "v_chest_1",
    name: "Classic Push-ups",
    youtubeId: "",
    muscles: ["chest", "triceps", "shoulders"],
    targetMuscleLabel: "Middle & Upper Pectorals",
    difficulty: "beginner",
    duration: "5 Mins",
    equipment: "home",
    instructions: [
      "Set your hands slightly wider than shoulder-width apart, fingers pointed slightly outward.",
      "Lower your chest down to the floor, tucking elbows back at 45 degrees.",
      "Press the floor away explosively until your arms are fully locked.",
      "Keep your body in a rigid straight plank line throughout the movement."
    ],
    mistakes: [
      "Flaring elbows straight out to 90 degrees, stressing shoulders.",
      "Letting core sag or head droop down before the chest taps."
    ],
    tips: [
      "Squeeze your shoulder blades together as you lower.",
      "Imagine twisting your hands into the floor to lock in shoulder torque."
    ],
    recommendedSets: 3,
    recommendedReps: "15-20 Reps",
    restTime: "60 Secs",
    categories: ["chest", "home"]
  },
  {
    id: "v_chest_2",
    name: "Incline Barbell Bench Press",
    youtubeId: "",
    muscles: ["chest", "shoulders", "triceps"],
    targetMuscleLabel: "Clavicular Head (Upper Chest)",
    difficulty: "intermediate",
    duration: "8 Mins",
    equipment: "gym",
    instructions: [
      "Lie on an incline bench angled at 30-45 degrees, feet pressed flat to floor.",
      "Unrack the barbell with a medium-wide grip directly over your upper chest line.",
      "Slowly lower the bar to your upper sternum, maintaining vertical forearm angles.",
      "Press the barbell straight up with control until lock out."
    ],
    mistakes: ["Setting bench too high, shifting stress to anterior deltoids.", "Bouncing the bar heavy off the sternum."],
    tips: ["Retract your shoulders into the bench pads before unracking.", "Maintain a slight arch in your lower spine but keep glutes down."],
    recommendedSets: 4,
    recommendedReps: "8-12 Reps",
    restTime: "90 Secs",
    categories: ["chest", "gym"]
  },

  // --- BACK EXERCISES ---
  {
    id: "v_back_1",
    name: "Standard Deadhang & Pull-ups",
    youtubeId: "",
    muscles: ["back", "biceps"],
    targetMuscleLabel: "Latismus Dorsi width & Scapulars",
    difficulty: "intermediate",
    duration: "7 Mins",
    equipment: "gym",
    instructions: [
      "Hang from a bar with a wide overhand grip, eyes pointing forward.",
      "Depress your scapular shoulders, then raise your whole body up dynamically.",
      "Lift yourself up until your chin clears the bar, pulling elbows down.",
      "Lower slowly back to a full dead hang stretch."
    ],
    mistakes: ["Using dynamic leg bobs or kicking motions.", "Failing to go all the way down, leaving short ranges."],
    tips: ["Think of pulling the bar down to your collarbones rather than pulling yourself up.", "Keep core completely tight during vertical ascents."],
    recommendedSets: 3,
    recommendedReps: "8-10 Reps",
    restTime: "90 Secs",
    categories: ["back", "gym"]
  },
  {
    id: "v_back_2",
    name: "One-Arm Dumbbell Row",
    youtubeId: "",
    muscles: ["back", "biceps"],
    targetMuscleLabel: "Mid-Back and Rhomboids",
    difficulty: "beginner",
    duration: "6 Mins",
    equipment: "gym",
    instructions: [
      "Set your left knee and left hand flat on a flat exercise bench. Back flat parallel to floor.",
      "Hold a heavy dumbbell in your right hand, letting it hang down.",
      "Row the dumbbell straight up to your right hip pocket, driving your elbow high.",
      "Lower with deep stretching force to starting pose."
    ],
    mistakes: ["Rounding the thoracic back on let down.", "Twisting hips or entire trunk outwards to make pulling easier."],
    tips: ["Pull with your elbow, keep your wrist relaxed.", "Get a deep stretch at bottom to unlock maximum lat activation."],
    recommendedSets: 3,
    recommendedReps: "10-12/side",
    restTime: "60 Secs",
    categories: ["back", "gym"]
  },

  // --- SHOULDER EXERCISES ---
  {
    id: "v_sh_1",
    name: "Pike Pushups",
    youtubeId: "",
    muscles: ["shoulders", "triceps"],
    targetMuscleLabel: "Anterior & Lateral Deltoids",
    difficulty: "intermediate",
    duration: "6 Mins",
    equipment: "home",
    instructions: [
      "Get into a classic downward-facing dog position with hands flat and feet hip-width.",
      "Walk feet in closer, elevating hips high in the air to shift weight to hands.",
      "Lower your head forward, building a tripod shape between head and hands.",
      "Push up through your palms back to your start position."
    ],
    mistakes: ["Lowering head straight down between hands instead of forward.", "Letting elbows flare out out too wide laterally."],
    tips: ["Elevate your feet on a chair or bench to make this much harder.", "Keep neck neutral throughout the sets."],
    recommendedSets: 3,
    recommendedReps: "8-12 Reps",
    restTime: "60 Secs",
    categories: ["shoulders", "home"]
  },
  {
    id: "v_sh_2",
    name: "Seated Dumbbell Shoulder Press",
    youtubeId: "",
    muscles: ["shoulders", "triceps"],
    targetMuscleLabel: "Total Deltoid Development",
    difficulty: "beginner",
    duration: "7 Mins",
    equipment: "gym",
    instructions: [
      "Sit upright on a vertical utility bench with back supported, holding dumbbells.",
      "Position dumbbells at ear level, elbows stacked under wrists.",
      "Press dumbbells up in a slight arc path until arms are locked.",
      "Lower with slow, controlled safety down to ear height."
    ],
    mistakes: ["Excessive back Arching, turning this into an upper chest press.", "Hitting the dumbbells together loudly at the top."],
    tips: ["Keep your wrists upright and completely straight, do not bend them back.", "Control the lowering phase strictly for 2 seconds."],
    recommendedSets: 3,
    recommendedReps: "12 Reps",
    restTime: "60 Secs",
    categories: ["shoulders", "gym"]
  },

  // --- BICEPS ---
  {
    id: "v_bic_1",
    name: "Barbell Bicep Curl",
    youtubeId: "",
    muscles: ["biceps"],
    targetMuscleLabel: "Long & Short Head of Bicep",
    difficulty: "beginner",
    duration: "5 Mins",
    equipment: "gym",
    instructions: [
      "Stand straight with feet hip-width, holding a barbell with underhand shoulder-width grip.",
      "Keep elbows pinned to your sides, curl the bar up toward your shoulders directly.",
      "Squeeze your biceps maximally at the peak for half a second.",
      "Lower bar slowly, fully stretching your arms."
    ],
    mistakes: ["Swinging the hips to build momentum.", "Allowing the elbows to travel far forward during curling."],
    tips: ["Keep your wrist straight and flexed slightly inward.", "Press your shoulder blades down to isolate upper arms."],
    recommendedSets: 3,
    recommendedReps: "12-15 Reps",
    restTime: "45 Secs",
    categories: ["biceps", "gym"]
  },

  // --- TRICEPS ---
  {
    id: "v_tri_1",
    name: "Diamond Push-ups",
    youtubeId: "",
    muscles: ["triceps", "chest"],
    targetMuscleLabel: "Lateral & Long Head of Tricep",
    difficulty: "intermediate",
    duration: "5 Mins",
    equipment: "home",
    instructions: [
      "Form a push-up position with hands touching under your chest, thumbs & index fingers sharing a diamond shape.",
      "Lower your chest down to your hands with control, keeping elbows tight to your ribs.",
      "Press the floor away aggressively back to high plank.",
      "Keep your shoulders depressed throughout the sets."
    ],
    mistakes: ["Letting the elbows flare out to sides.", "Sagging hips or locking lower spine."],
    tips: ["Squeeze your triceps maximally at top lockout.", "If too hard, start on a box or bench with elevated arms."],
    recommendedSets: 3,
    recommendedReps: "12 Reps",
    restTime: "60 Secs",
    categories: ["triceps", "home"]
  },

  // --- LEGS ---
  {
    id: "v_leg_1",
    name: "Walking & Reverse Lunges",
    youtubeId: "",
    muscles: ["legs"],
    targetMuscleLabel: "Quadriceps & Glute Isolation",
    difficulty: "beginner",
    duration: "6 Mins",
    equipment: "home",
    instructions: [
      "Stand tall, then take a big step back or forward with your right foot.",
      "Lower your hips until your rear knee is just an inch off the floor.",
      "Both knees should have bent to 90 degrees.",
      "Push off through your front heel back to straight posture."
    ],
    mistakes: ["Letting the front knee cave inwards.", "Taking a step too short, causing front knee forward shear."],
    tips: ["Keep your torso upright like a soldier.", "Place hands on hips or hold bottles for extra load."],
    recommendedSets: 3,
    recommendedReps: "20 Steps (10/leg)",
    restTime: "45 Secs",
    categories: ["legs", "home"]
  },
  {
    id: "v_leg_2",
    name: "Barbell Back Squats",
    youtubeId: "",
    muscles: ["legs"],
    targetMuscleLabel: "Quadriceps, Glutes, Lower Back",
    difficulty: "advanced",
    duration: "9 Mins",
    equipment: "gym",
    instructions: [
      "Rest the barbell on your upper traps. Stand tall with feet slightly wider than shoulders.",
      "Send your hips back and down, bending knees to squat.",
      "Go down past parallel (crease of hips below top of knee).",
      "Drive back up dynamically to standing, pushing knees out."
    ],
    mistakes: ["Valgus knee cave (knees snapping inward on ascent).", "Heels lifting off the ground, shifting weight to toes."],
    tips: ["Inhale deep at top, brace abs like an iron corset.", "Keep chest up and push bar into your traps for stability."],
    recommendedSets: 4,
    recommendedReps: "8-10 Reps",
    restTime: "120 Secs",
    categories: ["legs", "gym"]
  },

  // --- RECOVERY WARMUPS AND STRETCHES ---
  {
    id: "v_warm_1",
    name: "Surya Namaskar Sun Salutations",
    youtubeId: "",
    muscles: ["shoulders", "legs", "core", "back"],
    targetMuscleLabel: "Dynamic Global Mobility Warmup",
    difficulty: "beginner",
    duration: "10 Mins",
    equipment: "home",
    instructions: [
      "Flow smoothly through the 12 classical posture sequences.",
      "Breathe deeply, syncing each ascent with an inhale, descent with an exhale.",
      "Focus on the hamstring stretch, downward dog, and cobra transition steps.",
      "Complete 5 rounds at a progressive tempo to ready the body."
    ],
    mistakes: ["Forcing deep flexibility range before body is warm.", "Moving with fast jerky breaths."],
    tips: ["Press palms flat into earth.", "Align feet properly in lunges."],
    recommendedSets: 1,
    recommendedReps: "5 Full Rounds",
    restTime: "30 Secs",
    categories: ["warm_up", "home"]
  },
  {
    id: "v_warm_2",
    name: "Dynamic Joint Mobility Routine",
    youtubeId: "",
    muscles: ["shoulders", "legs"],
    targetMuscleLabel: "Joint Lubrication & Synovial Warmup",
    difficulty: "beginner",
    duration: "5 Mins",
    equipment: "home",
    instructions: [
      "Perform gentle neck circles, arm swings, and shoulder rotations.",
      "Perform hip hula loops, leg swings, and ankle rolls sequentially.",
      "Perform 15 gentle bodyweight squats and standing arm reaches."
    ],
    mistakes: ["Straining joints past comfort.", "Skipping ankle/wrist focus."],
    tips: ["Spend extra time on areas that feel stiff.", "Breathe through nose."],
    recommendedSets: 1,
    recommendedReps: "1 Continuous Flow",
    restTime: "0 Secs",
    categories: ["warm_up", "home"]
  },
  {
    id: "v_str_1",
    name: "Deep Post-Workout Static Stretch",
    youtubeId: "",
    muscles: ["legs", "back", "shoulders"],
    targetMuscleLabel: "Myofascial Stretching & Restoration",
    difficulty: "beginner",
    duration: "8 Mins",
    equipment: "home",
    instructions: [
      "Hold static stretching poses for 30 seconds each.",
      "Perform seated hamstring stretch, deep chest door opens, and child's pose.",
      "Relax your nervous system by breathing slowly and deeply."
    ],
    mistakes: ["Bouncing in static poses, which triggers tendon reflexes.", "Stretching to immediate heavy pain threshold."],
    tips: ["Relax deeper with every slow exhalation.", "Close eyes to activate parasit sympathetic state."],
    recommendedSets: 1,
    recommendedReps: "1 Complete Sequence",
    restTime: "0 Secs",
    categories: ["stretching", "home"]
  },
  {
    id: "v_fb_1",
    name: "Full Body Fat Burning HIIT",
    youtubeId: "",
    muscles: ["legs", "core", "shoulders", "chest"],
    targetMuscleLabel: "Total Body Metabolic Burn",
    difficulty: "intermediate",
    duration: "15 Mins",
    equipment: "home",
    instructions: [
      "Work in a circuit format: 40 seconds of intense movement, 20 seconds rest.",
      "Run jumping jacks, followed by bodyweight squats, followed by pushups.",
      "Finish each round with maximum burpees or mountain climbers."
    ],
    mistakes: ["Losing form as fatigue hits.", "Skipping warm-up first."],
    tips: ["Match your heart rate monitor.", "Drink small sips of water."],
    recommendedSets: 3,
    recommendedReps: "45s Work / 15s Rest",
    restTime: "120 Secs",
    categories: ["full_body", "cardio", "home"]
  }
];

// Display Category mapping info
const HEIGHT_VIDEO_IDS: Record<string, string> = {
  height_b_1: "sg_kcfi7viI", // Hanging
  height_b_2: "wFGPBqG1Y28", // Cat-Cow
  height_b_3: "N2DjxljbWdY", // Cobra Pose
  height_i_1: "UsBkxSgaXts", // Standing Forward Bend
  height_i_2: "WNzxyVAo4vw", // Pilates Roll Up
  height_i_3: "mDTRqLApvhc", // Wall Stretch
  height_a_1: "RmLMW2bSFZo", // Inversion Hang
  height_a_2: "JKhAxJZmBQo", // Bridge Pose
  height_a_3: "MrElduIWQec"  // Superman Stretch
};

// Map existing 27 Martial Arts videos
const mappedMartialLessons: VideoExercise[] = MARTIAL_LESSONS.map((lesson) => ({
  id: lesson.id,
  name: `${lesson.category} - ${lesson.name}`,
  youtubeId: DEFAULT_MARTIAL_VIDEO_URLS[lesson.id] || "",
  muscles: MARTIAL_LESSONS_MUSCLES[lesson.id] || ["core"],
  targetMuscleLabel: lesson.category,
  difficulty: lesson.level.toLowerCase() as "beginner" | "intermediate" | "advanced",
  duration: "5 Mins",
  equipment: "home" as "home" | "gym",
  instructions: [lesson.description, lesson.benefits],
  mistakes: ["Improper balance or posture", "Dropping your hands or guard"],
  tips: [lesson.tips],
  recommendedSets: 3,
  recommendedReps: "10-12 Reps",
  restTime: "45 Secs",
  categories: ["martial_arts"]
}));

// Map existing 9 Height Increase videos
const mappedHeightExercises: VideoExercise[] = HEIGHT_EXERCISES.map((ex) => {
  const videoId = HEIGHT_VIDEO_IDS[ex.id] || "";
  const youtubeUrl = videoId ? `https://www.youtube.com/watch?v=${videoId}` : "";
  return {
    id: ex.id,
    name: ex.name,
    youtubeId: youtubeUrl,
    muscles: ["back", "core"],
    targetMuscleLabel: ex.targetPhysiology.join(", "),
    difficulty: ex.level.toLowerCase() as "beginner" | "intermediate" | "advanced",
    duration: "5 Mins",
    equipment: "home" as "home" | "gym",
    instructions: [ex.description, ex.benefits],
    mistakes: ["Forcing range beyond natural comfort", "Improper posture alignment"],
    tips: [ex.tips],
    recommendedSets: 3,
    recommendedReps: "10-12 Reps",
    restTime: "45 Secs",
    categories: ["height_increase"]
  };
});

const CATEGORIES_LIST = [
  { id: "favorites", name: "Favorites Only", icon: "❤️" },
  { id: "recent", name: "Recently Watched", icon: "🕒" },
  { id: "chest", name: "Chest Exercises", icon: "🔥" },
  { id: "back", name: "Back Exercises", icon: "🪵" },
  { id: "shoulders", name: "Shoulder Exercises", icon: "🛡️" },
  { id: "biceps", name: "Biceps Exercises", icon: "💪" },
  { id: "triceps", name: "Triceps Exercises", icon: "⚡" },
  { id: "legs", name: "Leg Exercises", icon: "🦵" },
  { id: "abs", name: "Abs Exercises", icon: "🍫" },
  { id: "full_body", name: "Full Body Workouts", icon: "🫁" },
  { id: "cardio", name: "Cardio Exercises", icon: "🏃‍♂️" },
  { id: "home", name: "Home Workouts", icon: "🏡" },
  { id: "gym", name: "Gym Workouts", icon: "🏋🏽" },
  { id: "warm_up", name: "Warm-up Videos", icon: "🥵" },
  { id: "stretching", name: "Stretching Videos", icon: "🧘🏿" },
  { id: "martial_arts", name: "Martial Arts", icon: "🥋" },
  { id: "height_increase", name: "Height Increase", icon: "📏" }
];

const ACCORDION_GROUPS = [
  {
    key: "saved",
    title: "Saved Content",
    description: "Your favorites & history",
    icon: "❤️",
    categoryIds: ["favorites", "recent"]
  },
  {
    key: "muscle",
    title: "Muscle Targeted Group",
    description: "Chest, Legs, Back, Abs",
    icon: "💪",
    categoryIds: ["chest", "back", "shoulders", "biceps", "triceps", "legs", "abs"]
  },
  {
    key: "setup",
    title: "Routines & Venues",
    description: "Home, Gym, or Cardio setups",
    icon: "🏡",
    categoryIds: ["full_body", "cardio", "home", "gym"]
  },
  {
    key: "recovery",
    title: "Stretch & Recovery",
    description: "Warmups & flexibility",
    icon: "🧘🏿",
    categoryIds: ["warm_up", "stretching"]
  },
  {
    key: "specialty",
    title: "Specialty Training",
    description: "Martial Arts & Height",
    icon: "💎",
    categoryIds: ["martial_arts", "height_increase"]
  }
];

export default function ExerciseVideos() {
  const { user, profile, updateProfileStats } = useAuth();
  
  // Real-time states mapped from firestore
  const [videoUrlsMap, setVideoUrlsMap] = useState<Record<string, string>>({});
  const [searchQuery, setSearchQuery] = useState("");
  const [confirmCompleteState, setConfirmCompleteState] = useState<{ isOpen: boolean } | null>(null);
  const [restTimerLeft, setRestTimerLeft] = useState<number | null>(null);

  useEffect(() => {
    if (restTimerLeft === null) return;
    if (restTimerLeft <= 0) {
      playSound("timer_complete");
      setRestTimerLeft(null);
      return;
    }
    const timerId = setInterval(() => {
      setRestTimerLeft(prev => (prev ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timerId);
  }, [restTimerLeft]);

  // Listen to Firestore real-time updates!
  useEffect(() => {
    if (!user) return;
    // Listen to admin URL maps
    const unsubUrls = onSnapshot(collection(db, "exercise_videos"), (snapshot) => {
      const map: Record<string, string> = {};
      snapshot.forEach((doc) => {
        map[doc.id] = doc.data().youtubeUrl || "";
      });
      setVideoUrlsMap(map);
    }, (error) => {
      console.warn("Firestore 'exercise_videos' connection warning / offline:", error);
    });

    return () => {
      unsubUrls();
    };
  }, [user]);

  // Merge default exercises with mapped specialty exercises
  const COMBINED_DATABASE = [
    ...VIDEO_DATABASE,
    ...mappedMartialLessons,
    ...mappedHeightExercises
  ];

  const [activeCategory, setActiveCategory] = useState<string | null>("abs"); // default tab abs to show off custom work
  const [topCategory, setTopCategory] = useState<"all" | "warm_up" | "strength" | "cardio" | "recovery">("strength");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  const [selectedEquipment, setSelectedEquipment] = useState<string>("all"); // all, home, gym
  
  // Accordion open/collapse state
  const [expandedAccordions, setExpandedAccordions] = useState<Record<string, boolean>>({
    saved: true,
    muscle: true,
    setup: true,
    recovery: false
  });

  const toggleAccordionGroup = (groupKey: string) => {
    playSound("click");
    setExpandedAccordions(prev => ({
      ...prev,
      [groupKey]: !prev[groupKey]
    }));
  };
  
  // Selection / Detail view State
  const [selectedExercise, setSelectedExercise] = useState<VideoExercise | null>(null);
  
  // Persistent Storage for Favorites & History using synchronized helper hooks
  const [favorites, setFavorites] = useLocalStorageSync<string[]>("fitgenie_fav_videos", []);
  const [recentlyWatched, setRecentlyWatched] = useLocalStorageSync<string[]>("fitgenie_recent_videos", []);
  const [archivedVideos, setArchivedVideos] = useLocalStorageSync<string[]>("fitgenie_archived_videos", []);
  const [showArchivedList, setShowArchivedList] = useState(false);
  const [autoPlayNext, setAutoPlayNext] = useLocalStorageSync<boolean>("fitgenie_autoplay_next", true);

  const [martialProgress, setMartialProgress] = useLocalStorageSync<{
    completed: Record<string, boolean>;
    streak: number;
    lastCompletedDate: string;
  }>("fitgenie_martial_arts_progress", {
    completed: {},
    streak: 0,
    lastCompletedDate: ""
  });

  const handleArchiveVideo = (id: string) => {
    playSound("click");
    if (!archivedVideos.includes(id)) {
      setArchivedVideos(prev => [...prev, id]);
    }
  };

  const handleUnarchiveVideo = (id: string) => {
    playSound("click");
    setArchivedVideos(prev => prev.filter(v => v !== id));
  };

  // Track Watch Event
  const trackWatched = (id: string) => {
    setRecentlyWatched(prev => {
      const filtered = prev.filter(item => item !== id);
      return [id, ...filtered].slice(0, 8); // Keep last 8 watched
    });
  };

  const toggleFavorite = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    playSound("click");
    setFavorites(prev => {
      if (prev.includes(id)) {
        return prev.filter(item => item !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const requestCompleteVideoAndClose = () => {
    if (!selectedExercise) return;
    setConfirmCompleteState({ isOpen: true });
  };

  const executeCompleteVideoAndClose = async () => {
    if (!selectedExercise) return;

    playSound("success");
    incrementCompletionCount(selectedExercise.name);

    const isMartial = selectedExercise.categories.includes("martial_arts");
    const matchingLesson = MARTIAL_LESSONS.find(l => l.id === selectedExercise.id);
    const xpReward = isMartial && matchingLesson ? matchingLesson.xpReward : 50;
    const completedName = isMartial && matchingLesson
      ? `Martial Arts: ${matchingLesson.category} - ${matchingLesson.name}`
      : `Video: ${selectedExercise.name}`;

    if (updateProfileStats) {
      await updateProfileStats({
        xpGained: xpReward,
        completedWorkoutName: completedName,
        workoutCompleted: true
      });
    }

    if (isMartial) {
      const todayStr = new Date().toISOString().split("T")[0];
      let currentStreak = martialProgress.streak;
      let lastDate = martialProgress.lastCompletedDate;
      
      if (lastDate === "") {
        currentStreak = 1;
      } else {
        const last = new Date(lastDate);
        const today = new Date(todayStr);
        const diffTime = Math.abs(today.getTime() - last.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) {
          currentStreak += 1;
        } else if (diffDays > 1) {
          currentStreak = 1; // broken streak
        }
      }

      setMartialProgress({
        completed: {
          ...martialProgress.completed,
          [selectedExercise.id]: true
        },
        streak: currentStreak,
        lastCompletedDate: todayStr
      });
    }

    if (autoPlayNext) {
      const idx = filteredItems.findIndex(ex => ex.id === selectedExercise.id);
      if (idx !== -1 && idx < filteredItems.length - 1) {
        const nextExercise = filteredItems[idx + 1];
        trackWatched(nextExercise.id);
        setSelectedExercise(nextExercise);
        return;
      }
    }

    setSelectedExercise(null);
  };

  // Helper to highlight matching text query snippet inside exercise title
  const highlightText = (text: string, query: string) => {
    if (!query) return <span>{text}</span>;
    const escapedQuery = query.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
    const parts = text.split(new RegExp(`(${escapedQuery})`, "gi"));
    return (
      <>
        {parts.map((part, index) => {
          const isMatch = part.toLowerCase() === query.toLowerCase();
          return isMatch ? (
            <mark
              key={index}
              className="bg-brand-accent/25 text-brand-accent font-extrabold px-1 py-0.5 rounded shadow-[0_0_8px_rgba(201,243,29,0.2)] select-all"
            >
              {part}
            </mark>
          ) : (
            <span key={index}>{part}</span>
          );
        })}
      </>
    );
  };

  // Filters calculation
  const getFilteredExercises = () => {
    return COMBINED_DATABASE.filter(ex => {
      const matchesSearch = searchQuery === "" || 
        ex.name.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory = activeCategory === "favorites" 
        ? favorites.includes(ex.id) 
        : activeCategory === "recent"
          ? recentlyWatched.includes(ex.id)
          : (activeCategory ? ex.categories.includes(activeCategory) : true);

      // Apply top level category filtering
      if (topCategory !== "all") {
        if (topCategory === "warm_up") {
          if (!ex.categories.includes("warm_up")) return false;
        } else if (topCategory === "recovery") {
          if (!ex.categories.includes("stretching")) return false;
        } else if (topCategory === "cardio") {
          if (!ex.categories.includes("cardio")) return false;
        } else if (topCategory === "strength") {
          const strengthCats = ["chest", "back", "shoulders", "biceps", "triceps", "legs", "abs", "full_body"];
          if (!ex.categories.some(c => strengthCats.includes(c))) return false;
        }
      }

      const matchesDifficulty = selectedDifficulty === "all" || ex.difficulty === selectedDifficulty;
      const matchesEquipment = selectedEquipment === "all" || ex.equipment === selectedEquipment;

      return matchesSearch && matchesCategory && matchesDifficulty && matchesEquipment;
    });
  };

  let filteredItems = getFilteredExercises();
  if (activeCategory === "recent") {
    filteredItems = [...filteredItems].sort((a, b) => {
      const idxA = recentlyWatched.indexOf(a.id);
      const idxB = recentlyWatched.indexOf(b.id);
      return idxA - idxB;
    });
  }
  const activeRecentlyWatched = recentlyWatched.filter(id => !archivedVideos.includes(id));

  // Determine if a selected category has absolutely zero videos
  const activeCategoryItem = activeCategory ? CATEGORIES_LIST.find(c => c.id === activeCategory) : null;
  const activeCategoryVideosCount = activeCategory 
    ? (activeCategory === "favorites" 
      ? COMBINED_DATABASE.filter(ex => favorites.includes(ex.id)).length
      : activeCategory === "recent"
        ? COMBINED_DATABASE.filter(ex => recentlyWatched.includes(ex.id)).length
        : COMBINED_DATABASE.filter(ex => ex.categories.includes(activeCategory) && (videoUrlsMap[ex.id] || ex.youtubeId)).length)
    : 0;
  const showComingSoon = !searchQuery && !!activeCategory && activeCategory !== "favorites" && activeCategory !== "recent" && activeCategoryVideosCount === 0;

  // Category counts
  const getCategoryCount = (catId: string) => {
    return COMBINED_DATABASE.filter(ex => {
      const matchesDifficulty = selectedDifficulty === "all" || ex.difficulty === selectedDifficulty;
      const matchesEquipment = selectedEquipment === "all" || ex.equipment === selectedEquipment;
      const matchesCategory = catId === "favorites" 
        ? favorites.includes(ex.id) 
        : catId === "recent"
          ? recentlyWatched.includes(ex.id)
          : ex.categories.includes(catId);
      return matchesCategory && matchesDifficulty && matchesEquipment;
    }).length;
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6" id="exercise-videos-viewport">
      <ConfirmModal
        isOpen={!!confirmCompleteState?.isOpen}
        message="Kya aapne sach me kiya hai? Agar ha to bahut achi bat hai great progress, agar app ese hi complete tap kar rahe ho to aap apne aap ko dhokha doge."
        onCancel={() => setConfirmCompleteState(null)}
        onConfirm={() => {
          executeCompleteVideoAndClose();
          setConfirmCompleteState(null);
        }}
      />
      {/* Search and Title Grid */}
      <div className="relative mb-8 bg-[#0F0F0F]/60 border border-[#1A1A1A] p-6 rounded-3xl overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-black uppercase text-brand-accent tracking-widest bg-brand-accent/10 px-2.5 py-1 rounded-md border border-brand-accent/20">
              ⚡ COMPLIANT DYNAMIC CHANNEL
            </span>
            <h1 className="text-2xl md:text-3xl font-black uppercase text-white mt-2 flex items-center gap-2">
              <Video className="w-7 h-7 text-brand-accent transform hover:rotate-6 transition-transform" />
              EXERCISE TUTORIALS
            </h1>
            <p className="text-zinc-400 text-xs mt-1 uppercase font-semibold font-mono">
              100% Admin Approved Video Demonstrations
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <div className="text-xs bg-[#111] border border-neutral-900 rounded-xl px-3.5 py-2.5 flex items-center gap-2">
              <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
              <span className="font-bold text-zinc-300 font-mono">FAVORITES: {favorites.length}</span>
            </div>
            <div className="text-xs bg-[#111] border border-neutral-900 rounded-xl px-3.5 py-2.5 flex items-center gap-2 hidden sm:flex">
              <Clock className="w-4 h-4 text-[#38bdf8]" />
              <span className="font-bold text-zinc-300 font-mono">RECENT: {recentlyWatched.length}</span>
            </div>
          </div>
        </div>
      </div>



      {/* Beautiful Dynamic Recently Watched Top Section */}
      {activeRecentlyWatched.length > 0 && (
        <div className="mb-8 bg-[#0B0B0B]/40 border border-[#141414] rounded-3xl p-5 md:p-6 shadow-xl relative overflow-hidden" id="recent-watched-top-section">
          <div className="absolute top-0 left-0 w-40 h-40 bg-brand-accent/5 rounded-full blur-3xl pointer-events-none" />
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 relative z-10">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-brand-accent/10 border border-brand-accent/20 flex items-center justify-center text-brand-accent shadow-sm animate-pulse">
                <Clock className="w-4 h-4" />
              </div>
              <div className="text-left">
                <h2 className="text-xs md:text-sm font-black uppercase text-white tracking-widest font-mono flex items-center gap-2">
                  <span>Recently Watched</span>
                  <span className="text-[9px] font-mono bg-zinc-900 border border-zinc-800 text-zinc-400 px-1.5 py-0.5 rounded-md">
                    {activeRecentlyWatched.length} ACTIVE
                  </span>
                </h2>
                <p className="text-[9px] text-[#38bdf8] uppercase font-black tracking-wider flex items-center gap-1.5">
                  <span>Quick Access • Last 5 Demos Viewed</span>
                  <span className="text-neutral-500">•</span>
                  <span className="text-brand-accent/80 font-mono text-[8px] animate-pulse">← Click item to load tutorial →</span>
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            {activeRecentlyWatched.slice(0, 8).map(id => {
              const ex = COMBINED_DATABASE.find(item => item.id === id);
              if (!ex) return null;
              const hasUrl = videoUrlsMap[ex.id];
              const ytId = getYouTubeId(hasUrl);
              const thumbUrl = ytId ? `https://img.youtube.com/vi/${ytId}/mqdefault.jpg` : null;

              return (
                <div
                  key={id}
                  onClick={() => { playSound("click"); setSelectedExercise(ex); }}
                  className="bg-[#050505] p-2 border border-zinc-900 hover:border-brand-accent rounded-xl text-center group cursor-pointer transition text-left relative aspect-video overflow-hidden flex flex-col justify-end"
                >
                  {thumbUrl ? (
                    <img 
                      src={thumbUrl} 
                      className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:scale-105 group-hover:opacity-60 transition"
                      alt=""
                    />
                  ) : (
                    <div className="absolute inset-0 bg-[#0f0f11]/40" />
                  )}
                  <span className="text-[8px] uppercase font-mono text-brand-accent block truncate relative z-10">{ex.targetMuscleLabel}</span>
                  <span className="text-[9px] font-black text-white uppercase block truncate relative z-10 mt-0.5">{ex.name}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Grid containing Sidebar layout & categories on left, cards on right */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        
        {/* Left column: Expanded categories listing & smart tags filters */}
        <div className="lg:col-span-1 space-y-6">
          
          {/* Quick Filters Group */}
          <div className="bg-[#0C0C0C] border border-[#151515] p-5 rounded-2xl space-y-4">
            <span className="text-[10px] font-black text-brand-accent uppercase tracking-widest flex items-center gap-1.5 border-b border-neutral-950 pb-2">
              <Filter className="w-3.5 h-3.5" /> SMART FILTERS
            </span>

            {/* Difficulty Level Selectors */}
            <div className="space-y-1.5 text-left">
              <label className="text-[9px] uppercase font-bold text-zinc-400 font-mono">Difficulty Range</label>
              <div className="grid grid-cols-4 bg-[#070707] border border-[#1E1E1E] p-0.5 rounded-lg text-[9px]">
                {["all", "beginner", "intermediate", "advanced"].map((diff) => {
                  const isS = selectedDifficulty === diff;
                  return (
                    <button
                      key={diff}
                      onClick={() => { playSound("toggle"); setSelectedDifficulty(diff); }}
                      className={`py-1 hover:text-white rounded capitalize font-black ${
                        isS ? "bg-brand-accent text-[#0A0A0A]" : "text-zinc-500"
                      }`}
                    >
                      {diff === "all" ? "All" : diff.slice(0, 3)}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Venue Level Selectors */}
            <div className="space-y-1.5 text-left">
              <label className="text-[9px] uppercase font-bold text-zinc-400 font-mono">Workout Zone</label>
              <div className="grid grid-cols-3 bg-[#070707] border border-[#1E1E1E] p-0.5 rounded-lg text-[10px]">
                {[{ id: "all", label: "Any" }, { id: "home", label: "Home" }, { id: "gym", label: "Gym" }].map((v) => {
                  const isS = selectedEquipment === v.id;
                  return (
                    <button
                      key={v.id}
                      onClick={() => { playSound("toggle"); setSelectedEquipment(v.id); }}
                      className={`py-1 hover:text-white rounded font-black ${
                        isS ? "bg-brand-accent text-[#0A0A0A]" : "text-zinc-500"
                      }`}
                    >
                      {v.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Auto-Play Toggle Selector */}
            <div className="space-y-2 text-left pt-3 border-t border-zinc-900">
              <div className="flex items-center justify-between">
                <label className="text-[9px] uppercase font-bold text-zinc-400 font-mono flex items-center gap-1">
                  ⚡ Auto-Play Next
                </label>
                <div 
                  onClick={() => { playSound("toggle"); setAutoPlayNext(prev => !prev); }}
                  className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    autoPlayNext ? "bg-cyan-500" : "bg-zinc-800"
                  }`}
                  id="autoplay-toggle"
                >
                  <span
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full shadow-md ring-0 transition duration-200 ease-in-out ${
                      autoPlayNext ? "translate-x-4 bg-slate-950" : "translate-x-0 bg-zinc-400"
                    }`}
                  />
                </div>
              </div>
              <p className="text-[7.5px] text-cyan-400/80 leading-relaxed uppercase font-mono tracking-wide">
                {autoPlayNext 
                  ? "Plays next workout demo in queue instantly on completion" 
                  : "Stops playing after single workout demo."}
              </p>
            </div>
          </div>

          {/* Interactive Accordion Accordion Tab selector */}
          <div className="bg-[#0C0C0C] border border-[#151515] p-4 rounded-2xl space-y-3">
            <span className="text-[10px] font-black text-brand-accent uppercase tracking-widest flex items-center gap-1.5 border-b border-neutral-950 pb-2 mb-1">
              <Activity className="w-3.5 h-3.5" /> EXERCISES CABINET ({CATEGORIES_LIST.length})
            </span>

            <div className="space-y-3 max-h-[480px] lg:max-h-none overflow-y-auto pr-1">
              {ACCORDION_GROUPS.map((gro) => {
                const isOpen = expandedAccordions[gro.key];
                return (
                  <div key={gro.key} className="border border-[#1A1A1A] rounded-xl overflow-hidden bg-zinc-950/40" id={`accordion-group-${gro.key}`}>
                    {/* Header bar */}
                    <button
                      onClick={() => toggleAccordionGroup(gro.key)}
                      className="w-full flex items-center justify-between p-3 bg-neutral-900/40 hover:bg-neutral-900/80 transition-all text-left cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-sm">{gro.icon}</span>
                        <div>
                          <h4 className="text-[10px] font-black uppercase tracking-wider text-zinc-100">{gro.title}</h4>
                          <span className="text-[8px] text-zinc-500 uppercase tracking-tight font-semibold block mt-0.5">{gro.description}</span>
                        </div>
                      </div>
                      <div className="text-zinc-500">
                        {isOpen ? (
                          <ChevronDown className="w-3.5 h-3.5 text-brand-accent" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5 text-zinc-500" />
                        )}
                      </div>
                    </button>

                    {/* Sub-categories */}
                    {isOpen && (
                      <div className="p-1.5 bg-black/30 border-t border-[#161616] space-y-1">
                        {gro.categoryIds.map((id) => {
                          const cat = CATEGORIES_LIST.find((c) => c.id === id);
                          if (!cat) return null;
                          const isActive = activeCategory === cat.id && searchQuery === "";
                          const filteredCount = getCategoryCount(cat.id);
                          return (
                            <button
                              key={cat.id}
                              onClick={() => {
                                playSound("click");
                                setSearchQuery(""); // Clear search so category loads
                                setActiveCategory(cat.id);
                                if (cat.id === "favorites" || cat.id === "recent") {
                                  setTopCategory("all");
                                } else if (cat.id === "warm_up") {
                                  setTopCategory("warm_up");
                                } else if (cat.id === "stretching") {
                                  setTopCategory("recovery");
                                } else if (cat.id === "cardio") {
                                  setTopCategory("cardio");
                                } else if (cat.id === "martial_arts" || cat.id === "height_increase") {
                                  setTopCategory("all");
                                } else {
                                  setTopCategory("strength");
                                }
                              }}
                              className={`w-full text-left p-2 rounded-lg transition-all flex items-center justify-between border ${
                                isActive 
                                  ? "bg-brand-accent/5 border-brand-accent/25 text-brand-accent font-black shadow-[0_0_12px_rgba(201,243,29,0.03)]" 
                                  : "border-transparent text-zinc-400 hover:bg-zinc-900/60 hover:text-white"
                              } cursor-pointer`}
                            >
                              <div className="flex items-center gap-2 text-xs">
                                <span className="text-xs">{cat.icon}</span>
                                <span className="uppercase font-bold tracking-tight text-[10px]">{cat.name}</span>
                              </div>
                              
                              <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded-md ${
                                isActive 
                                  ? "bg-brand-accent/15 text-brand-accent border border-brand-accent/20" 
                                  : "bg-zinc-950 text-zinc-500 border border-neutral-900"
                              }`}>
                                {filteredCount}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right column: Search, Favorites/Recent quick carousel, and exercise lists */}
        <div className="lg:col-span-3 space-y-6">

          {/* New Top Level Category Filter */}
          <div className="bg-[#0C0C0C] border border-[#161616] p-5 rounded-3xl space-y-3.5 shadow-2xl relative overflow-hidden" id="top-high-level-category-filter">
            <div className="absolute top-0 right-0 w-24 h-24 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black text-brand-accent uppercase tracking-widest flex items-center gap-1.5 font-mono">
                <Filter className="w-3.5 h-3.5" /> ROUTINE GOALS
              </span>
              <span className="text-[9px] text-zinc-500 uppercase font-black font-mono tracking-wider">
                QUICK CATEGORY NAVIGATION
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-2.5">
              {[
                { id: "all", label: "Show All", icon: "💎", desc: "All techniques" },
                { id: "warm_up", label: "Warm-up", icon: "🥵", desc: "Prep & activate" },
                { id: "cardio", label: "Cardio", icon: "🏃‍♂️", desc: "Burn & sweat" },
                { id: "strength", label: "Strength", icon: "💪", desc: "Build & sculpt" },
                { id: "recovery", label: "Recovery", icon: "🧘", desc: "Stretch & restore" }
              ].map((tab) => {
                const isActive = topCategory === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => {
                      playSound("click");
                      setTopCategory(tab.id as any);
                      // Adjust subcategory selection to keep UX highly robust
                      if (tab.id === "all") {
                        setActiveCategory(null);
                      } else if (tab.id === "warm_up") {
                        setActiveCategory("warm_up");
                      } else if (tab.id === "recovery") {
                        setActiveCategory("stretching");
                      } else if (tab.id === "cardio") {
                        setActiveCategory("cardio");
                      } else if (tab.id === "strength") {
                        // If activeCategory is not a strength category, reset to null
                        const strengthCats = ["chest", "back", "shoulders", "biceps", "triceps", "legs", "abs", "full_body"];
                        if (!activeCategory || !strengthCats.includes(activeCategory)) {
                          setActiveCategory(null); // Show all strength
                        }
                      }
                    }}
                    className={`p-3.5 rounded-2xl border text-left transition-all duration-300 relative overflow-hidden flex flex-col justify-between cursor-pointer ${
                      isActive
                        ? "bg-brand-accent/5 border-brand-accent/80 text-white shadow-[0_0_15px_rgba(201,243,29,0.1)]"
                        : "bg-zinc-950 border-zinc-900 text-zinc-400 hover:text-white hover:border-zinc-800"
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="text-sm select-none">{tab.icon}</span>
                      {isActive && (
                        <div className="w-1.5 h-1.5 rounded-full bg-brand-accent animate-ping" />
                      )}
                    </div>
                    <div className="mt-3 text-left">
                      <span className="block text-xs font-black uppercase tracking-wider select-none">
                        {tab.label}
                      </span>
                      <span className="block text-[8.5px] text-zinc-500 uppercase tracking-tight font-mono font-semibold mt-0.5 select-none">
                        {tab.desc}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Search Box */}
          <div className="relative">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <Search className="w-5 h-5 text-zinc-500" />
            </div>
            <input
              type="text"
              placeholder="Search by exercise name within selected category..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#0C0C0C] border-2 border-brand-border hover:border-zinc-700 focus:border-brand-accent focus:outline-none focus:ring-0 text-white rounded-2xl py-3.5 pl-12 pr-4 text-xs font-mono font-medium transition-all shadow-xl"
              id="exercise-search-input-videos"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-1 text-zinc-500 hover:text-white uppercase font-black text-[10px]"
              >
                Clear
              </button>
            )}
          </div>

          {/* Saved quick access row */}
          {favorites.length > 0 && searchQuery === "" && (
            <div className="bg-[#0C0C0C] border border-[#161616] p-4 rounded-2xl relative overflow-hidden">
              <span className="text-[9px] font-black tracking-widest text-[#ef4444] uppercase flex items-center gap-1 mb-2.5">
                <Heart className="w-3 h-3 fill-current" /> SAVED QUICK ACCESS
              </span>
              
              <div className="flex flex-wrap gap-1.5 max-h-[85px] overflow-y-auto pr-1">
                {favorites.map((favId) => {
                  const ex = COMBINED_DATABASE.find(item => item.id === favId);
                  if (!ex) return null;
                  return (
                    <button
                      key={favId}
                      onClick={() => { playSound("click"); setSelectedExercise(ex); trackWatched(ex.id); }}
                      className="bg-[#070707]/95 hover:bg-brand-accent/5 border border-zinc-800 hover:border-brand-accent/30 rounded-xl px-2.5 py-1.5 text-[10px] font-bold text-zinc-300 hover:text-white flex items-center gap-1.5 transition-all text-left cursor-pointer"
                    >
                      <span className="text-[#ef4444] shrink-0">❤️</span>
                      <span className="line-clamp-2 break-words">{ex.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Heading dynamic state indicator */}
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-black uppercase text-zinc-400 font-mono tracking-widest">
              {searchQuery ? `Searching for "${searchQuery}"` : `${CATEGORIES_LIST.find(c => c.id === activeCategory)?.name || "All Videos"}`}
              <span className="text-zinc-650 ml-1">({filteredItems.length})</span>
            </h2>

            {searchQuery === "" && (
              <span className="text-[10px] text-zinc-500 uppercase font-bold font-mono">
                Tab: {activeCategory?.toUpperCase()}
              </span>
            )}
          </div>

          {/* Substantial Grid representation of Exercises */}
          {showComingSoon ? (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#0C0C0C]/80 border border-zinc-900 rounded-3xl p-12 text-center my-6 relative overflow-hidden"
              id="category-coming-soon-panel"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />
              <div className="w-20 h-20 bg-zinc-950 border border-zinc-800 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl relative">
                <Sparkles className="w-8 h-8 text-brand-accent animate-pulse" />
                <span className="absolute -top-1 -right-1 text-[8px] bg-brand-accent text-zinc-950 font-black px-1.5 py-0.5 rounded uppercase tracking-wider scale-90">Elite</span>
              </div>
              <h3 className="text-lg md:text-xl font-black uppercase text-white tracking-widest font-sans">
                {activeCategoryItem?.name || "Category"} Demonstration Videos
              </h3>
              <p className="text-zinc-500 uppercase text-[9px] tracking-widest font-bold mt-1 font-mono">
                ⚡ Content Cooking in Fit Genie Lab ⚡
              </p>
              <div className="h-px bg-zinc-900 my-5 max-w-sm mx-auto" />
              <p className="text-zinc-400 text-xs max-w-lg mx-auto leading-relaxed">
                Bro! Our elite master trainers are currently designing, filming, and cataloging professional demonstration tutorials for <strong>{activeCategoryItem?.name || "this category"}</strong>.
              </p>
              <p className="text-zinc-500 text-[10.5px] max-w-sm mx-auto leading-relaxed mt-2 uppercase font-mono">
                Expect pristine postures, detailed alignment cues, and common mistake walkthroughs soon!
              </p>
              <div className="pt-6">
                <button 
                  onClick={() => {
                    playSound("click");
                    setActiveCategory("martial_arts");
                    setTopCategory("all");
                  }}
                  className="bg-brand-accent hover:bg-white text-zinc-950 text-[10px] font-black uppercase tracking-widest px-5 py-2.5 rounded-xl transition-all font-mono duration-200 cursor-pointer"
                >
                  🥋 Explore Martial Arts Videos
                </button>
              </div>
            </motion.div>
          ) : filteredItems.length === 0 ? (
            <div className="bg-[#0C0C0C] border border-[#151515] p-16 rounded-3xl text-center space-y-4">
              <div className="w-16 h-16 bg-neutral-900 rounded-full flex items-center justify-center mx-auto text-zinc-650 text-2xl">
                {activeCategory === "favorites" ? "❤️" : activeCategory === "recent" ? "🕒" : "🔎"}
              </div>
              <p className="text-zinc-400 font-bold text-sm uppercase">
                {activeCategory === "favorites" 
                  ? "No favorited exercises found!" 
                  : activeCategory === "recent"
                    ? "No recently watched exercises found!"
                    : "NO DIRECT EXERCISE MATCHES FOUND"}
              </p>
              <p className="text-xs text-zinc-600 max-w-md mx-auto font-mono">
                {activeCategory === "favorites" 
                  ? "Bro! Tap the heart button on any exercise card anytime to collect your favorite workouts in this tab."
                  : activeCategory === "recent"
                    ? "Bro! Complete some demonstration tutorials or click on some cards to populate your watch history list."
                    : "No matching videos matched your combination of keywords or filters inside Fit Genie core."}
              </p>
              {activeCategory !== "favorites" && activeCategory !== "recent" ? (
                <button 
                  onClick={() => { playSound("click"); setSearchQuery(""); setSelectedDifficulty("all"); setSelectedEquipment("all"); }}
                  className="bg-brand-accent text-[#0A0A0A] hover:bg-white text-[10px] font-black uppercase tracking-widest px-4 py-2 rounded-xl transition-all"
                >
                  Reset All Query Filters
                </button>
              ) : (
                <button 
                  onClick={() => { playSound("click"); setActiveCategory("chest"); setTopCategory("strength"); }}
                  className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-[10px] font-black uppercase tracking-widest px-5 py-2.5 rounded-xl transition-all font-mono"
                >
                  🔥 Check out chest exercises
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredItems.map((ex) => {
                const isFav = favorites.includes(ex.id);
                
                const assignedUrl = videoUrlsMap[ex.id];
                const ytId = getYouTubeId(assignedUrl);
                const thumbUrl = ytId ? `https://img.youtube.com/vi/${ytId}/mqdefault.jpg` : null;

                return (
                  <div
                    key={ex.id}
                    onClick={() => { playSound("click"); setSelectedExercise(ex); trackWatched(ex.id); }}
                    className="bg-[#0C0E14] border border-cyan-500/20 hover:border-cyan-400 hover:shadow-[0_15px_30px_-5px_rgba(6,182,212,0.22),0_0_20px_rgba(6,182,212,0.12)] hover:scale-[1.03] hover:-translate-y-1.5 rounded-2xl overflow-hidden group cursor-pointer transition-all duration-300 ease-out flex flex-col justify-between shadow-lg relative select-none"
                  >
                    {/* Header Image box with Video Preview Layer overlay */}
                    <div className="relative aspect-video w-full overflow-hidden bg-[#07090E]">
                      {thumbUrl ? (
                        <img 
                          src={thumbUrl} 
                          alt={ex.name} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-80 animate-fade-in"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-[#061024] via-[#09152E] to-[#050B1A] flex flex-col items-center justify-center p-4 text-center relative overflow-hidden">
                          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(20,241,225,0.14)_0%,transparent_70%)] pointer-events-none" />
                          <div className="w-10 h-10 rounded-xl bg-[#14F1E1]/15 border border-[#14F1E1]/40 flex items-center justify-center mb-1.5 shadow-[0_0_15px_rgba(20,241,225,0.3)]">
                            <Activity className="w-5 h-5 text-[#14F1E1] animate-pulse" />
                          </div>
                          <span className="text-[9px] font-black tracking-[0.2em] text-[#14F1E1] uppercase font-mono">
                            INTERACTIVE FORM GUIDE
                          </span>
                          <span className="text-[8px] font-mono text-neutral-400 uppercase mt-0.5">
                            Step-by-Step Movement Demo Ready
                          </span>
                        </div>
                      )}

                      {/* Accent play action badge center */}
                      <div className="absolute inset-0 bg-black/45 group-hover:bg-black/20 flex items-center justify-center transition-all">
                        <div className="w-11 h-11 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 group-hover:scale-110 shadow-[0_0_15px_rgba(6,182,212,0.5)] flex items-center justify-center transition-transform">
                          <Play className="w-5 h-5 fill-current ml-0.5" />
                        </div>
                      </div>

                      {/* Equipment tag */}
                      <span className="absolute bottom-2.5 left-2.5 bg-slate-950/85 backdrop-blur-md text-[9px] font-black tracking-widest text-cyan-400 uppercase border border-cyan-500/30 px-2 py-0.5 rounded">
                        🏠 {ex.equipment === "home" ? "Home Friendly" : "Gym Lift"}
                      </span>

                      {/* Duration tag right bottom */}
                      <span className="absolute bottom-2.5 right-2.5 bg-slate-950/90 backdrop-blur text-[9px] font-bold text-zinc-300 px-1.5 py-0.5 rounded flex items-center gap-1 font-mono">
                        <Clock className="w-3 h-3 text-cyan-400" />
                        {ex.duration}
                      </span>

                      {/* Quick Favorite Heart top right */}
                      <button
                        onClick={(e) => toggleFavorite(ex.id, e)}
                        className="absolute top-2.5 right-2.5 p-1.5 rounded-full bg-slate-950/80 backdrop-blur border border-cyan-500/25 hover:bg-slate-900 hover:border-cyan-400 transition-all cursor-pointer z-10"
                        title={isFav ? "Remove from Favorites" : "Save to Favorites"}
                      >
                        <Heart className={`w-3.5 h-3.5 transition-colors ${
                          isFav ? "text-[#ef4444] fill-current" : "text-zinc-400 hover:text-white"
                        }`} />
                      </button>
                    </div>

                    {/* Meta info bottom card body */}
                    <div className="p-4 flex-grow flex flex-col justify-between space-y-3">
                      <div>
                        {/* Muscle groups list */}
                        <span className="block text-[10px] font-mono font-black uppercase text-cyan-400 tracking-widest">
                          {ex.targetMuscleLabel}
                        </span>

                        <h3 className="text-zinc-100 font-black text-sm uppercase tracking-wide group-hover:text-white mt-1">
                          {highlightText(ex.name, searchQuery)}
                        </h3>
                      </div>

                      {/* Sets & Actions Row */}
                      <div className="flex items-center justify-between pt-2.5 border-t border-cyan-950/50 text-[10px]">
                        <div className="flex items-center gap-2">
                          {/* Difficulty badge */}
                          <span className={`px-2 py-0.5 rounded font-black uppercase tracking-wider text-[8px] ${
                            ex.difficulty === "beginner" 
                              ? "bg-[#0C120C] text-emerald-400 border border-emerald-500/20" 
                              : ex.difficulty === "intermediate"
                                ? "bg-amber-400/5 text-amber-300 border border-amber-400/20"
                                : "bg-rose-500/5 text-rose-400 border border-rose-500/20"
                          }`}>
                            {ex.difficulty}
                          </span>
                        </div>

                        <div className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 transition-colors">
                          <span className="font-black uppercase tracking-wider text-[9px] font-mono">WATCH DEMO</span>
                          <Play className="w-2.5 h-2.5 fill-current" />
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Full-screen overlay Detail Page Modal Dialog */}
      {selectedExercise && (() => {
        const mappedUrl = videoUrlsMap[selectedExercise.id] || "";
        const ytId = getYouTubeId(mappedUrl);

        return (
          <div 
            className="fixed inset-0 z-[150] bg-black/92 backdrop-blur-md flex items-center justify-center p-4 md:p-6 select-none overflow-y-auto animate-fade-in"
            id="exercise-video-detail-modal"
            onClick={() => setSelectedExercise(null)}
          >
            {/* Main Modal Box card layout */}
            <div 
              className="w-full max-w-4xl bg-[#07090E] border border-cyan-500/30 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(6,182,212,0.18)] relative flex flex-col max-h-[90vh]"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Upper action header */}
              <div className="flex items-center justify-between p-4 border-b border-cyan-950/50 bg-[#0B0D14] z-10">
                <button 
                  onClick={() => { playSound("click"); setSelectedExercise(null); }}
                  className="flex items-center gap-1.5 text-xs text-cyan-400 hover:text-white uppercase font-black tracking-widest bg-cyan-950/20 px-3 py-2 border border-cyan-500/20 hover:border-cyan-450 transition-all rounded-xl cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Return</span>
                </button>

                <div className="flex items-center gap-2">
                  {/* Heart Save button in modal */}
                  <button
                    onClick={() => toggleFavorite(selectedExercise.id)}
                    className="bg-cyan-950/20 p-2 border border-cyan-500/20 rounded-xl text-cyan-400 hover:text-[#ef4444] hover:border-cyan-400 transition-all cursor-pointer flex items-center gap-1.5 text-xs font-black uppercase"
                  >
                    <Heart className={`w-3.5 h-3.5 ${favorites.includes(selectedExercise.id) ? "text-[#ef4444] fill-current" : ""}`} />
                    <span>{favorites.includes(selectedExercise.id) ? "Saved" : "Save"}</span>
                  </button>

                  <button 
                    onClick={() => { playSound("click"); setSelectedExercise(null); }}
                    className="w-8 h-8 rounded-xl bg-cyan-950/20 border border-cyan-500/20 text-cyan-400 hover:text-white flex items-center justify-center cursor-pointer transition-all uppercase font-mono font-semibold"
                  >
                    ✕
                  </button>
                </div>
              </div>

              {/* Scrollable multi-pane core block */}
              <div className="overflow-y-auto flex-grow p-4 md:p-6 space-y-6">
                
                <GlobalCompletionCounter 
                  exerciseName={selectedExercise.name} 
                  isCompletedByUser={selectedExercise.categories.includes("martial_arts") ? !!martialProgress.completed[selectedExercise.id] : false}
                />

                {/* Upper video panel */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  
                  {/* Visual Section: Left Column */}
                  <div className="lg:col-span-7 space-y-4">
                    
                    {/* 3D Hologram / Video Stream Switcher */}
                    <div className="relative w-full rounded-2xl overflow-hidden bg-[#050B1A] border-2 border-[#14F1E1]/30 shadow-[0_0_25px_rgba(20,241,225,0.2)]">
                      {ytId && navigator.onLine ? (
                        <div className="space-y-0">
                          <div className="relative aspect-video w-full">
                            <iframe
                              src={`https://www.youtube.com/embed/${ytId}?autoplay=1&rel=0&modestbranding=1&vq=hd720`}
                              title={`Fitting Demonstration for ${selectedExercise?.name || "Exercise"}`}
                              className="absolute inset-0 w-full h-full"
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                              allowFullScreen
                            ></iframe>
                          </div>
                          <div className="p-2.5 bg-[#080F24] border-t border-[#14F1E1]/20">
                            <Exercise3DCharacterLoop
                              exerciseName={selectedExercise.name}
                              targetMuscles={selectedExercise.muscles}
                              difficulty={selectedExercise.difficulty}
                              category={selectedExercise.categories?.[0] || ""}
                              exerciseType={selectedExercise.categories?.some((c) => c.toLowerCase().includes("stretch")) ? "STRETCH" : "WORKOUT"}
                              heightClass="h-[210px]"
                              showControls={true}
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="p-2">
                          <Exercise3DCharacterLoop
                            exerciseName={selectedExercise.name}
                            targetMuscles={selectedExercise.muscles}
                            difficulty={selectedExercise.difficulty}
                            category={selectedExercise.categories?.[0] || ""}
                            exerciseType={selectedExercise.categories?.some((c) => c.toLowerCase().includes("stretch")) ? "STRETCH" : "WORKOUT"}
                            heightClass="h-[270px] sm:h-[310px]"
                            showControls={true}
                          />
                        </div>
                      )}
                    </div>

                    {/* Title & Stats */}
                    <div className="space-y-1.5 text-left">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] uppercase font-black tracking-wider text-cyan-400 px-2 py-0.5 bg-cyan-950/40 border border-cyan-500/35 rounded-md">
                          {selectedExercise.targetMuscleLabel}
                        </span>
                        <span className="text-[9px] uppercase font-bold text-cyan-600 font-mono tracking-wider">
                          LIVE FORM GUIDE ACTIVE
                        </span>
                      </div>

                      <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-tight">
                        {selectedExercise.name}
                      </h2>
                    </div>

                    {/* Workout Specs Pills Row */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1.5 font-mono">
                      <div className="bg-[#0C0F17] p-2.5 rounded-xl border border-cyan-950/50 text-left">
                        <span className="block text-[8px] uppercase text-cyan-600 font-bold">Recommended Sets</span>
                        <span className="block text-xs font-black text-white mt-1 uppercase">{selectedExercise.recommendedSets} Sets</span>
                      </div>
                      <div className="bg-[#0C0F17] p-2.5 rounded-xl border border-cyan-950/50 text-left">
                        <span className="block text-[8px] uppercase text-cyan-600 font-bold">Target Reps</span>
                        <span className="block text-xs font-black text-white mt-1 uppercase">{selectedExercise.recommendedReps}</span>
                      </div>
                      <button 
                        onClick={() => {
                          if (restTimerLeft !== null) {
                            playSound("timer_pause");
                            setRestTimerLeft(null);
                          } else {
                            playSound("timer_start");
                            const timeMatch = selectedExercise.restTime.match(/(\d+)/);
                            const secs = timeMatch ? parseInt(timeMatch[1], 10) : 45;
                            setRestTimerLeft(secs);
                          }
                        }}
                        className={`bg-[#0C0F17] p-2.5 rounded-xl border transition-colors duration-300 text-left ${restTimerLeft !== null ? 'border-cyan-500 bg-cyan-950/30' : 'border-cyan-950/50 hover:border-cyan-800'}`}
                      >
                        <span className="block text-[8px] uppercase text-cyan-600 font-bold flex justify-between items-center">
                          Resting Timer
                          {restTimerLeft === null && <Play className="w-2.5 h-2.5" />}
                        </span>
                        <span className={`block text-xs font-black mt-1 uppercase ${restTimerLeft !== null ? 'text-cyan-400' : 'text-white'}`}>
                          {restTimerLeft !== null ? `${restTimerLeft} SECS` : selectedExercise.restTime}
                        </span>
                      </button>
                      <div className="bg-[#0C0F17] p-2.5 rounded-xl border border-cyan-950/50 text-left">
                        <span className="block text-[8px] uppercase text-cyan-600 font-bold">Demo Duration</span>
                        <span className="block text-xs font-black text-cyan-400 mt-1 uppercase">{selectedExercise.duration}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Cyberpunk Biomechanical Recruitment HUD */}
                  <div className="lg:col-span-5 space-y-4">
                    <div className="bg-[#080F24] border border-[#14F1E1]/30 p-5 rounded-2xl relative space-y-4 shadow-[0_0_25px_rgba(20,241,225,0.08)]">
                      <div className="flex items-center justify-between border-b border-white/10 pb-3">
                        <div className="text-[10px] uppercase font-black text-[#14F1E1] tracking-widest font-mono flex items-center gap-1.5">
                          <Activity className="w-3.5 h-3.5 text-[#14F1E1] animate-pulse" /> BIOMECHANICAL HUD
                        </div>
                        <span className="text-[8px] font-mono uppercase px-2 py-0.5 rounded bg-[#B66DFF]/20 text-[#B66DFF] border border-[#B66DFF]/40 font-black">
                          2-1-2 TEMPO SYNC
                        </span>
                      </div>

                      <div className="space-y-2.5">
                        <div className="bg-black/40 border border-white/10 rounded-xl p-3">
                          <div className="flex justify-between text-[9px] font-mono uppercase font-bold text-neutral-400 mb-1">
                            <span>Primary Muscle Fiber Load</span>
                            <span className="text-[#14F1E1]">96% PEAK</span>
                          </div>
                          <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                            <div className="h-full w-[96%] bg-gradient-to-r from-[#14F1E1] to-[#B66DFF]" />
                          </div>
                        </div>

                        <div className="bg-black/40 border border-white/10 rounded-xl p-3">
                          <div className="flex justify-between text-[9px] font-mono uppercase font-bold text-neutral-400 mb-1">
                            <span>Core & Joint Stabilization</span>
                            <span className="text-emerald-400">89% LOCKED</span>
                          </div>
                          <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                            <div className="h-full w-[89%] bg-emerald-400" />
                          </div>
                        </div>

                        <div className="bg-black/40 border border-white/10 rounded-xl p-3">
                          <div className="flex justify-between text-[9px] font-mono uppercase font-bold text-neutral-400 mb-1">
                            <span>Eccentric Tension Control</span>
                            <span className="text-amber-400">2.0s NEGATIVE</span>
                          </div>
                          <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                            <div className="h-full w-[84%] bg-amber-400" />
                          </div>
                        </div>
                      </div>

                      <div className="pt-1">
                        <span className="block text-[9px] font-mono uppercase text-neutral-400 font-bold mb-2">
                          Activated Anatomical Zones:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {selectedExercise.muscles.map((m) => (
                            <span
                              key={m}
                              className="px-2.5 py-1 rounded-lg bg-[#14F1E1]/10 border border-[#14F1E1]/30 text-[#14F1E1] text-[10px] font-mono font-black uppercase tracking-wider"
                            >
                              ⚡ {m}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Steps Instructions */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 bg-[#0B0D14] p-5 rounded-2xl border border-cyan-950/30">
                  <div className="md:col-span-7 space-y-4 text-left">
                    <h3 className="text-xs font-black uppercase text-cyan-400 tracking-widest flex items-center gap-1 border-b border-cyan-950 pb-2">
                      <Info className="w-4 h-4 text-cyan-400" /> Step-by-Step Tutorial
                    </h3>
                    
                    <ol className="space-y-3">
                      {selectedExercise.instructions.map((step, idx) => (
                        <li key={idx} className="flex gap-3 text-xs leading-relaxed text-zinc-300">
                          <span className="flex-shrink-0 w-5 h-5 rounded-full bg-cyan-500 text-slate-950 text-[10px] font-black font-mono flex items-center justify-center shrink-0">
                            {idx + 1}
                          </span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>

                  <div className="md:col-span-5 space-y-5 text-left">
                    {/* Common mistakes */}
                    <div className="space-y-2.5">
                      <h4 className="text-[10px] font-black uppercase text-rose-500 tracking-widest flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5 text-rose-500" /> Common Mistakes
                      </h4>
                      <ul className="space-y-1.5 pl-1">
                        {selectedExercise.mistakes?.map((mis, idx) => (
                          <li key={idx} className="text-[10.5px] leading-relaxed text-zinc-400 flex items-start gap-1.5">
                            <span className="text-rose-500 font-mono mt-0.5 shrink-0">✕</span>
                            <span>{partString(mis)}</span>
                          </li>
                        )) || (
                          <li className="text-[10.5px] text-zinc-500 uppercase">None logged bro. Work safe!</li>
                        )}
                      </ul>
                    </div>

                    {/* Pro Tip */}
                    <div className="space-y-2.5 border-t border-cyan-950/50 pt-3">
                      <h4 className="text-[10px] font-black uppercase text-cyan-400 tracking-widest flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Hardcore Coach Tips
                      </h4>
                      <ul className="space-y-1.5 pl-1">
                        {selectedExercise.tips?.map((tip, idx) => (
                          <li key={idx} className="text-[10.5px] leading-relaxed text-zinc-400 flex items-start gap-1.5">
                            <span className="text-cyan-400 font-mono mt-0.5 shrink-0">★</span>
                            <span>{partString(tip)}</span>
                          </li>
                        )) || (
                          <li className="text-[10.5px] text-zinc-500 uppercase">Work with explosive contraction and slow negative resist.</li>
                        )}
                      </ul>
                    </div>
                  </div>
                </div>

              </div>

              {/* Complete video completion action */}
              <div className="px-6 py-4 bg-[#06080D] border-t border-cyan-950/60 flex flex-col items-center gap-2">
                {selectedExercise && selectedExercise.categories.includes("martial_arts") && martialProgress.completed[selectedExercise.id] ? (
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 w-full">
                    <button
                      onClick={() => {
                        playSound("click");
                        const updated = { ...martialProgress.completed };
                        delete updated[selectedExercise.id];
                        setMartialProgress({
                          ...martialProgress,
                          completed: updated
                        });
                      }}
                      className="px-4 py-2 bg-transparent hover:bg-neutral-900 border border-neutral-800 text-zinc-400 hover:text-white rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer font-mono"
                    >
                      Reset Progress
                    </button>
                    <div className="px-5 py-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 flex-grow w-full sm:w-auto">
                      <Check className="w-4 h-4 text-emerald-400" /> MISSION COMPLETE
                    </div>
                  </div>
                ) : (
                  <>
                    <button
                      onClick={requestCompleteVideoAndClose}
                      className="w-full py-3.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs uppercase tracking-widest rounded-xl transition-all duration-300 shadow-[0_0_20px_rgba(6,182,212,0.3)] hover:scale-[1.02] cursor-pointer flex items-center justify-center gap-2 animate-fade-in"
                      id="btn-complete-video-demo"
                    >
                      <Award className="w-4 h-4 text-slate-950 shrink-0" />
                      <span>🏆 COMPLETE VIDEO DEMO (+50 XP)</span>
                    </button>
                    <p className="text-[8px] text-cyan-600 font-black uppercase tracking-widest text-center font-mono">
                      Logs watch completion to local streak counter & rewards 50 XP
                    </p>
                  </>
                )}
              </div>

              {/* Sticky bottom */}
              <div className="p-4 bg-[#0B0D14] border-t border-cyan-950/50 flex justify-between items-center text-[10px] uppercase font-black tracking-widest font-mono text-cyan-600">
                <div className="flex items-center gap-2 text-cyan-500">
                  <Youtube className="w-4 h-4 text-[#ef4444]" />
                  <span>Dynamic YouTube Stream Layer</span>
                </div>
                <span className="text-[9px] text-cyan-400 bg-[#07090E] p-1 border border-cyan-500/20 rounded font-mono">
                  Fit Genie certified
                </span>
              </div>

            </div>
          </div>
        );
      })()}
    </div>
  );
}

function partString(val: any): string {
  if (typeof val === "string") return val;
  return JSON.stringify(val);
}
