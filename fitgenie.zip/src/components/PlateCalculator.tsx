import { useState } from "react";
import { Dumbbell, Plus, Minus, Scale, Zap, Flame, Layers } from "lucide-react";
import { playSound } from "../utils/audio";

export default function PlateCalculator() {
  const [targetWeight, setTargetWeight] = useState<number>(100);
  const [barbellWeight, setBarbellWeight] = useState<number>(20);
  const [repsFor1RM, setRepsFor1RM] = useState<number>(5);

  // Available Olympic plates (kg)
  const AVAILABLE_PLATES = [25, 20, 15, 10, 5, 2.5, 1.25];

  const calculatePlatesForWeight = (totalLoad: number, barW: number) => {
    const remainingWeight = totalLoad - barW;
    if (remainingWeight <= 0) return [];

    let weightPerSide = remainingWeight / 2;
    const plates: number[] = [];

    for (const plate of AVAILABLE_PLATES) {
      while (weightPerSide >= plate) {
        plates.push(plate);
        weightPerSide -= plate;
        weightPerSide = Math.round(weightPerSide * 100) / 100;
      }
    }
    return plates;
  };

  const getPlateColor = (weight: number) => {
    switch (weight) {
      case 25:
        return "border-rose-500 text-rose-400 bg-rose-500/20 shadow-[0_0_15px_rgba(244,63,94,0.35)]";
      case 20:
        return "border-blue-500 text-blue-400 bg-blue-500/20 shadow-[0_0_15px_rgba(59,130,246,0.35)]";
      case 15:
        return "border-amber-400 text-amber-300 bg-amber-500/20 shadow-[0_0_15px_rgba(245,158,11,0.35)]";
      case 10:
        return "border-emerald-500 text-emerald-400 bg-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.35)]";
      case 5:
        return "border-white/90 text-white bg-white/15 shadow-[0_0_15px_rgba(255,255,255,0.2)]";
      case 2.5:
        return "border-[#14F1E1]/60 text-[#14F1E1] bg-[#14F1E1]/15";
      case 1.25:
        return "border-[#B66DFF]/60 text-[#B66DFF] bg-[#B66DFF]/15";
      default:
        return "border-[#333] text-white bg-[#222]";
    }
  };

  const getPlateSleeveStyle = (weight: number) => {
    switch (weight) {
      case 25:
        return { h: "h-36 sm:h-44", w: "w-5 sm:w-6", bg: "bg-gradient-to-b from-rose-500 via-rose-600 to-rose-800 border-rose-300/60 shadow-[0_0_15px_rgba(244,63,94,0.5)]" };
      case 20:
        return { h: "h-36 sm:h-44", w: "w-4 sm:w-5", bg: "bg-gradient-to-b from-blue-500 via-blue-600 to-blue-800 border-blue-300/60 shadow-[0_0_15px_rgba(59,130,246,0.5)]" };
      case 15:
        return { h: "h-32 sm:h-38", w: "w-4 sm:w-4.5", bg: "bg-gradient-to-b from-amber-400 via-amber-500 to-amber-700 border-amber-200/60 shadow-[0_0_12px_rgba(245,158,11,0.4)]" };
      case 10:
        return { h: "h-28 sm:h-32", w: "w-3.5 sm:w-4", bg: "bg-gradient-to-b from-emerald-400 via-emerald-500 to-emerald-700 border-emerald-200/60 shadow-[0_0_12px_rgba(16,185,129,0.4)]" };
      case 5:
        return { h: "h-22 sm:h-26", w: "w-3 sm:w-3.5", bg: "bg-gradient-to-b from-zinc-100 via-zinc-300 to-zinc-500 border-white text-black" };
      case 2.5:
        return { h: "h-18 sm:h-20", w: "w-2.5 sm:w-3", bg: "bg-gradient-to-b from-[#14F1E1] to-cyan-700 border-[#14F1E1] text-black" };
      default:
        return { h: "h-14 sm:h-16", w: "w-2 sm:w-2.5", bg: "bg-gradient-to-b from-[#B66DFF] to-purple-800 border-[#B66DFF]" };
    }
  };

  const platesNeeded = calculatePlatesForWeight(targetWeight, barbellWeight);
  const actualWeight = barbellWeight + platesNeeded.reduce((a, b) => a + b, 0) * 2;
  const estimated1RM = Math.round(actualWeight * (1 + repsFor1RM / 30));

  // Generate Warmup Pyramid Sets
  const warmupPyramid = [
    { stage: "Set 1 • Neural Primer", pct: 0, reps: "10 Reps", weight: barbellWeight },
    { stage: "Set 2 • Blood Flow", pct: 50, reps: "8 Reps", weight: Math.max(barbellWeight, Math.round((actualWeight * 0.5) / 2.5) * 2.5) },
    { stage: "Set 3 • Force Acclimation", pct: 70, reps: "5 Reps", weight: Math.max(barbellWeight, Math.round((actualWeight * 0.7) / 2.5) * 2.5) },
    { stage: "Set 4 • CNS Potentiation", pct: 85, reps: "2-3 Reps", weight: Math.max(barbellWeight, Math.round((actualWeight * 0.85) / 2.5) * 2.5) },
    { stage: "Working Set • Top Load", pct: 100, reps: `${repsFor1RM} Reps`, weight: actualWeight },
  ];

  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#14F1E1]/30">
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#14F1E1]/10 border border-[#14F1E1]/30 rounded-xl">
            <Scale className="w-5 h-5 text-[#14F1E1]" />
          </div>
          <div>
            <h1 className="text-sm md:text-base font-black text-white uppercase tracking-widest">
              Cyber Plate & Warmup Rig
            </h1>
            <p className="text-[10px] text-[#14F1E1] font-bold tracking-widest uppercase mt-0.5 font-mono">
              Olympic Barbell Sleeve Visualizer & 1RM Telemetry
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#14F1E1]/5 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-3xl mx-auto space-y-6 relative z-10 pb-24">
          {/* Main Controls Card */}
          <div className="bg-gradient-to-br from-[#081026] to-[#050B1A] border border-[#14F1E1]/25 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
              {/* Target Weight Input */}
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#14F1E1] flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#14F1E1]" /> Target Barbell Load
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={targetWeight || ""}
                    onChange={(e) => setTargetWeight(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-black/50 border border-[#14F1E1]/30 rounded-2xl py-4 px-5 text-3xl font-black font-mono text-white focus:outline-none focus:border-[#14F1E1] transition-all"
                  />
                  <span className="absolute right-5 top-1/2 -translate-y-1/2 text-[#14F1E1] font-black uppercase text-sm tracking-widest font-mono">
                    KG
                  </span>
                </div>

                {/* Quick Add/Sub */}
                <div className="grid grid-cols-4 gap-2">
                  <button
                    onClick={() => { playSound("click"); setTargetWeight((prev) => Math.max(barbellWeight, prev - 5)); }}
                    className="py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl flex items-center justify-center text-neutral-300 hover:text-white text-xs font-black font-mono transition-colors cursor-pointer"
                  >
                    -5kg
                  </button>
                  <button
                    onClick={() => { playSound("click"); setTargetWeight((prev) => prev + 2.5); }}
                    className="py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl flex items-center justify-center text-neutral-300 hover:text-white text-xs font-black font-mono transition-colors cursor-pointer"
                  >
                    +2.5kg
                  </button>
                  <button
                    onClick={() => { playSound("click"); setTargetWeight((prev) => prev + 5); }}
                    className="py-2.5 bg-[#14F1E1]/10 hover:bg-[#14F1E1]/20 border border-[#14F1E1]/30 rounded-xl flex items-center justify-center text-[#14F1E1] text-xs font-black font-mono transition-colors cursor-pointer"
                  >
                    +5kg
                  </button>
                  <button
                    onClick={() => { playSound("click"); setTargetWeight((prev) => prev + 10); }}
                    className="py-2.5 bg-[#B66DFF]/15 hover:bg-[#B66DFF]/25 border border-[#B66DFF]/40 rounded-xl flex items-center justify-center text-[#B66DFF] text-xs font-black font-mono transition-colors cursor-pointer"
                  >
                    +10kg
                  </button>
                </div>
              </div>

              {/* Barbell Selection */}
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-neutral-400 flex items-center gap-2">
                  <Dumbbell className="w-3.5 h-3.5 text-[#14F1E1]" /> Barbell Spec
                </label>
                <div className="space-y-2">
                  {[
                    { w: 20, label: "20kg Standard Olympic Bar" },
                    { w: 15, label: "15kg Women's / CrossFit Bar" },
                    { w: 10, label: "10kg EZ-Curl / Technique Bar" },
                  ].map((bar) => (
                    <button
                      key={bar.w}
                      onClick={() => { playSound("toggle"); setBarbellWeight(bar.w); }}
                      className={`w-full flex items-center justify-between p-3.5 rounded-xl border transition-all cursor-pointer ${
                        barbellWeight === bar.w
                          ? "bg-[#14F1E1]/15 border-[#14F1E1]/50 shadow-[0_0_15px_rgba(20,241,225,0.15)]"
                          : "bg-black/40 border-white/10 hover:border-white/20"
                      }`}
                    >
                      <span className={`text-xs font-bold uppercase tracking-wide ${barbellWeight === bar.w ? "text-white" : "text-neutral-400"}`}>
                        {bar.label}
                      </span>
                      <span className="text-xs font-mono font-black text-[#14F1E1]">{bar.w} KG</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* LIVE VISUAL OLYMPIC BARBELL SLEEVE GRAPHIC */}
          <div className="bg-[#070E20] border border-[#14F1E1]/35 rounded-3xl p-6 md:p-8 relative overflow-hidden text-center shadow-[0_0_40px_rgba(20,241,225,0.08)]">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-white/10 pb-5 mb-6">
              <div className="text-left">
                <span className="text-[10px] font-mono font-black uppercase tracking-[0.25em] text-[#14F1E1] block">
                  LIVE SLEEVE LOADOUT (ONE SIDE SHOWN)
                </span>
                <h2 className="text-4xl sm:text-5xl font-black font-mono text-white tracking-tight mt-1">
                  {actualWeight} <span className="text-xl text-[#14F1E1]">KG TOTAL</span>
                </h2>
              </div>
              <div className="flex gap-3">
                <div className="bg-black/50 border border-white/10 rounded-2xl px-4 py-2.5 text-right">
                  <span className="text-[9px] font-mono uppercase text-neutral-400 block">Per Side Load</span>
                  <span className="text-lg font-mono font-black text-[#B66DFF]">
                    {Math.max(0, (actualWeight - barbellWeight) / 2)} KG
                  </span>
                </div>
                <div className="bg-black/50 border border-[#14F1E1]/30 rounded-2xl px-4 py-2.5 text-right">
                  <span className="text-[9px] font-mono uppercase text-neutral-400 block">Est. 1RM ({repsFor1RM}RM)</span>
                  <span className="text-lg font-mono font-black text-[#14F1E1]">{estimated1RM} KG</span>
                </div>
              </div>
            </div>

            {/* Interactive Visual Barbell Graphic */}
            <div className="relative h-52 bg-[#040814] border border-white/10 rounded-2xl flex items-center justify-start px-4 sm:px-10 overflow-x-auto">
              {/* Inner Barbell Shaft */}
              <div className="w-16 sm:w-28 h-3.5 bg-gradient-to-b from-slate-300 via-slate-500 to-slate-700 rounded-l-full shrink-0 border-y border-white/30" />
              {/* Barbell Sleeve Collar Stop */}
              <div className="w-3.5 h-12 bg-gradient-to-b from-slate-200 via-slate-400 to-slate-700 rounded-sm shrink-0 border border-white/40 shadow-lg" />

              {/* Stacked Plates on Sleeve */}
              <div className="flex items-center gap-1 px-1 shrink-0 z-10">
                {platesNeeded.map((plate, idx) => {
                  const st = getPlateSleeveStyle(plate);
                  return (
                    <div
                      key={idx}
                      className={`${st.h} ${st.w} ${st.bg} rounded-md border flex flex-col items-center justify-center text-[8px] font-mono font-black select-none transition-all hover:scale-105`}
                      title={`${plate}kg Plate`}
                    >
                      <span className="rotate-[-90deg] whitespace-nowrap tracking-tighter">{plate}</span>
                    </div>
                  );
                })}
              </div>

              {/* Lock Collar */}
              {platesNeeded.length > 0 && (
                <div className="w-3 h-9 bg-[#14F1E1] border border-white rounded-sm shrink-0 shadow-[0_0_12px_rgba(20,241,225,0.6)]" title="2.5kg Competition Collar" />
              )}

              {/* Outer Barbell Sleeve Tip */}
              <div className="flex-1 min-w-[40px] max-w-[180px] h-6 bg-gradient-to-b from-slate-300 via-slate-500 to-slate-800 rounded-r-md border-y border-r border-white/30" />
            </div>

            {/* Plate Badges List */}
            {platesNeeded.length > 0 && (
              <div className="flex flex-wrap justify-center gap-2.5 mt-6">
                {platesNeeded.map((plate, idx) => (
                  <div
                    key={idx}
                    className={`px-3.5 py-2 rounded-xl border-2 flex items-center gap-1.5 font-mono ${getPlateColor(plate)}`}
                  >
                    <span className="font-black text-base">{plate}</span>
                    <span className="text-[9px] font-bold uppercase opacity-80">KG</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* WARMUP PYRAMID SET GENERATOR & 1RM TUNER */}
          <div className="bg-[#070E20] border border-[#B66DFF]/30 rounded-3xl p-6 md:p-8 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
              <div className="text-left">
                <span className="text-[10px] font-mono font-black uppercase tracking-[0.2em] text-[#B66DFF] flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-[#B66DFF]" /> AUTO WARMUP PYRAMID PROTOCOL
                </span>
                <h3 className="text-lg font-black text-white uppercase tracking-tight mt-0.5">
                  Ramp-Up Sets to {actualWeight} KG
                </h3>
              </div>

              <div className="flex items-center gap-1.5 bg-black/50 p-1 rounded-xl border border-white/10">
                <span className="text-[9px] font-mono uppercase text-neutral-400 px-2 font-bold">Target Reps:</span>
                {[1, 3, 5, 8, 10].map((r) => (
                  <button
                    key={r}
                    onClick={() => { playSound("toggle"); setRepsFor1RM(r); }}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-black cursor-pointer ${
                      repsFor1RM === r ? "bg-[#B66DFF] text-black" : "text-neutral-400 hover:text-white"
                    }`}
                  >
                    {r}R
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2.5">
              {warmupPyramid.map((setItem, i) => {
                const setPlates = calculatePlatesForWeight(setItem.weight, barbellWeight);
                return (
                  <div
                    key={i}
                    className={`p-3.5 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${
                      setItem.pct === 100
                        ? "bg-[#14F1E1]/10 border-[#14F1E1]/40"
                        : "bg-black/40 border-white/10"
                    }`}
                  >
                    <div className="text-left">
                      <span className="text-xs font-black uppercase text-white block">{setItem.stage}</span>
                      <span className="text-[10px] font-mono text-neutral-400">
                        {setPlates.length > 0 ? `Plates/side: ${setPlates.join("kg + ")}kg` : "Empty Barbell Only"}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-[10px] font-mono font-bold text-neutral-300">
                        {setItem.reps}
                      </span>
                      <span className="text-base font-mono font-black text-[#14F1E1] min-w-[70px] text-right">
                        {setItem.weight} KG
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

