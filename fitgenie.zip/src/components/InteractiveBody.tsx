import { useState } from "react";

interface InteractiveBodyProps {
  selectedMuscles: string[];
  onToggleMuscle: (muscle: string) => void;
}

export default function InteractiveBody({
  selectedMuscles,
  onToggleMuscle,
}: InteractiveBodyProps) {
  const [view, setView] = useState<"front" | "back">("front");

  // Helper to check if a muscle is selected
  const isSelected = (muscle: string) => selectedMuscles.includes(muscle);

  // Styling helpers
  const getFillColor = (muscle: string) => {
    return isSelected(muscle) ? "#C9F31D" : "#1A1A1A";
  };

  const getStrokeColor = (muscle: string) => {
    return isSelected(muscle) ? "#C9F31D" : "#333333";
  };

  const getFilter = (muscle: string) => {
    return isSelected(muscle) ? "url(#neon-glow)" : "none";
  };

  return (
    <div className="flex flex-col items-center select-none w-full max-w-md mx-auto">
      {/* Front / Back Toggle Buttons */}
      <div className="flex bg-brand-surface border border-brand-border p-1 rounded-full mb-6">
        <button
          onClick={() => setView("front")}
          className={`px-6 py-2 rounded-full text-xs font-semibold uppercase tracking-wider transition-all duration-300 ${
            view === "front"
              ? "bg-brand-accent text-brand-bg shadow-[0_0_15px_rgba(201,243,29,0.4)]"
              : "text-brand-muted hover:text-white"
          }`}
          id="btn-toggle-front"
        >
          Front View
        </button>
        <button
          onClick={() => setView("back")}
          className={`px-6 py-2 rounded-full text-xs font-semibold uppercase tracking-wider transition-all duration-300 ${
            view === "back"
              ? "bg-brand-accent text-brand-bg shadow-[0_0_15px_rgba(201,243,29,0.4)]"
              : "text-brand-muted hover:text-white"
          }`}
          id="btn-toggle-back"
        >
          Back View
        </button>
      </div>

      {/* SVG Canvas Container */}
      <div className="relative w-full aspect-[2/3] max-h-[380px] bg-brand-surface rounded-3xl border border-brand-border p-6 flex items-center justify-center overflow-hidden">
        {/* Ambient background grid lines to make it look like a sci-fi schematic */}
        <div className="absolute inset-0 opacity-5 pointer-events-none">
          <div className="w-full h-full bg-[linear-gradient(to_right,#888_1px,transparent_1px),linear-gradient(to_bottom,#888_1px,transparent_1px)] bg-[size:20px_20px]"></div>
        </div>

        <svg
          viewBox="0 0 200 300"
          className="w-full h-full max-w-full drop-shadow-[0_0_20px_rgba(0,0,0,0.8)]"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* SVG Neon Glow Filter */}
            <filter id="neon-glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>

            {/* Subtle card grid gradient */}
            <linearGradient id="bodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1C1C1C" />
              <stop offset="100%" stopColor="#111111" />
            </linearGradient>
          </defs>

          {/* Symmetrical outline scaffold (subtle guide) */}
          <g opacity="0.15" stroke="#FFFFFF" strokeWidth="0.5" strokeDasharray="3 3">
            <line x1="100" y1="10" x2="100" y2="290" />
            <circle cx="100" cy="150" r="130" fill="none" />
          </g>

          {/* HEAD & NECK (Non-clickable, decorative) */}
          <g stroke="#333333" strokeWidth="1" fill="#151515" opacity="0.8">
            {/* Head */}
            <ellipse cx="100" cy="30" rx="14" ry="18" />
            {/* Neck */}
            <rect x="95" y="47" width="10" height="10" rx="2" />
          </g>

          {/* --- FRONT VIEW --- */}
          {view === "front" && (
            <g id="front-body">
              {/* SHOULDERS */}
              <g
                className="cursor-pointer transition-all duration-300 group"
                onClick={() => onToggleMuscle("shoulders")}
              >
                {/* Left Shoulder */}
                <path
                  d="M 68,52 C 58,52 50,60 50,72 C 50,78 54,84 57,87 L 66,74 Z"
                  fill={getFillColor("shoulders")}
                  stroke={getStrokeColor("shoulders")}
                  strokeWidth="1.5"
                  filter={getFilter("shoulders")}
                />
                {/* Right Shoulder */}
                <path
                  d="M 132,52 C 142,52 150,60 150,72 C 150,78 146,84 143,87 L 134,74 Z"
                  fill={getFillColor("shoulders")}
                  stroke={getStrokeColor("shoulders")}
                  strokeWidth="1.5"
                  filter={getFilter("shoulders")}
                />
                <title>Shoulders (कंधे)</title>
              </g>

              {/* CHEST */}
              <g
                className="cursor-pointer transition-all duration-300"
                onClick={() => onToggleMuscle("chest")}
              >
                {/* Left Chest */}
                <path
                  d="M 100,68 L 68,68 L 68,90 C 68,98 84,98 100,90 Z"
                  fill={getFillColor("chest")}
                  stroke={getStrokeColor("chest")}
                  strokeWidth="1.5"
                  filter={getFilter("chest")}
                />
                {/* Right Chest */}
                <path
                  d="M 100,68 L 132,68 L 132,90 C 132,98 116,98 100,90 Z"
                  fill={getFillColor("chest")}
                  stroke={getStrokeColor("chest")}
                  strokeWidth="1.5"
                  filter={getFilter("chest")}
                />
                <title>Chest (छाती)</title>
              </g>

              {/* BICEPS */}
              <g
                className="cursor-pointer transition-all duration-300"
                onClick={() => onToggleMuscle("biceps")}
              >
                {/* Left Bicep */}
                <path
                  d="M 49,76 C 45,82 42,90 42,100 C 42,108 46,112 49,112 C 51,104 53,88 49,76 Z"
                  fill={getFillColor("biceps")}
                  stroke={getStrokeColor("biceps")}
                  strokeWidth="1.5"
                  filter={getFilter("biceps")}
                />
                {/* Right Bicep */}
                <path
                  d="M 151,76 C 155,82 158,90 158,100 C 158,108 154,112 151,112 C 149,104 147,88 151,76 Z"
                  fill={getFillColor("biceps")}
                  stroke={getStrokeColor("biceps")}
                  strokeWidth="1.5"
                  filter={getFilter("biceps")}
                />
                <title>Biceps (द्विशिर पेशी)</title>
              </g>

              {/* CORE / ABS */}
              <g
                className="cursor-pointer transition-all duration-300"
                onClick={() => onToggleMuscle("core")}
              >
                {/* Six Pack / Core Block */}
                <path
                  d="M 72,96 L 128,96 L 122,148 L 78,148 Z"
                  fill={getFillColor("core")}
                  stroke={getStrokeColor("core")}
                  strokeWidth="1.5"
                  filter={getFilter("core")}
                />
                <title>Core/Abs (एब्स)</title>
              </g>

              {/* LEGS (Quadriceps) */}
              <g
                className="cursor-pointer transition-all duration-300"
                onClick={() => onToggleMuscle("legs")}
              >
                {/* Left Quad */}
                <path
                  d="M 74,152 Q 62,185 70,225 L 88,225 Q 94,185 94,152 Z"
                  fill={getFillColor("legs")}
                  stroke={getStrokeColor("legs")}
                  strokeWidth="1.5"
                  filter={getFilter("legs")}
                />
                {/* Right Quad */}
                <path
                  d="M 126,152 Q 138,185 130,225 L 112,225 Q 106,185 106,152 Z"
                  fill={getFillColor("legs")}
                  stroke={getStrokeColor("legs")}
                  strokeWidth="1.5"
                  filter={getFilter("legs")}
                />
                <title>Legs/Quads (पैर)</title>
              </g>
            </g>
          )}

          {/* --- BACK VIEW --- */}
          {view === "back" && (
            <g id="back-body">
              {/* SHOULDERS (Rear delts) */}
              <g
                className="cursor-pointer transition-all duration-300"
                onClick={() => onToggleMuscle("shoulders")}
              >
                {/* Left Rear Shoulder */}
                <path
                  d="M 68,52 C 54,54 48,64 48,74 L 59,85 Z"
                  fill={getFillColor("shoulders")}
                  stroke={getStrokeColor("shoulders")}
                  strokeWidth="1.5"
                  filter={getFilter("shoulders")}
                />
                {/* Right Rear Shoulder */}
                <path
                  d="M 132,52 C 146,54 152,64 152,74 L 141,85 Z"
                  fill={getFillColor("shoulders")}
                  stroke={getStrokeColor("shoulders")}
                  strokeWidth="1.5"
                  filter={getFilter("shoulders")}
                />
                <title>Shoulders (पीछे के कंधे)</title>
              </g>

              {/* BACK */}
              <g
                className="cursor-pointer transition-all duration-300"
                onClick={() => onToggleMuscle("back")}
              >
                {/* Trapezium & Latissimus Dorsi */}
                <path
                  d="M 100,54 L 68,68 L 74,142 L 100,128 L 126,142 L 132,68 Z"
                  fill={getFillColor("back")}
                  stroke={getStrokeColor("back")}
                  strokeWidth="1.5"
                  filter={getFilter("back")}
                />
                <title>Back (पीठ)</title>
              </g>

              {/* TRICEPS */}
              <g
                className="cursor-pointer transition-all duration-300"
                onClick={() => onToggleMuscle("triceps")}
              >
                {/* Left Tricep */}
                <path
                  d="M 43,84 C 40,94 40,104 46,112 C 48,112 49,94 47,84 Z"
                  fill={getFillColor("triceps")}
                  stroke={getStrokeColor("triceps")}
                  strokeWidth="1.5"
                  filter={getFilter("triceps")}
                />
                {/* Right Tricep */}
                <path
                  d="M 157,84 C 160,94 160,104 154,112 C 152,112 151,94 153,84 Z"
                  fill={getFillColor("triceps")}
                  stroke={getStrokeColor("triceps")}
                  strokeWidth="1.5"
                  filter={getFilter("triceps")}
                />
                <title>Triceps (त्रिशिर पेशी)</title>
              </g>

              {/* GLUTES */}
              <g
                className="cursor-pointer transition-all duration-300"
                onClick={() => onToggleMuscle("glutes")}
              >
                {/* Left Glute */}
                <path
                  d="M 100,146 L 76,146 C 73,158 84,178 100,178 Z"
                  fill={getFillColor("glutes")}
                  stroke={getStrokeColor("glutes")}
                  strokeWidth="1.5"
                  filter={getFilter("glutes")}
                />
                {/* Right Glute */}
                <path
                  d="M 100,146 L 124,146 C 127,158 116,178 100,178 Z"
                  fill={getFillColor("glutes")}
                  stroke={getStrokeColor("glutes")}
                  strokeWidth="1.5"
                  filter={getFilter("glutes")}
                />
                <title>Glutes (कूल्हे)</title>
              </g>

              {/* HAMS/LEGS (Back Thighs) */}
              <g
                className="cursor-pointer transition-all duration-300"
                onClick={() => onToggleMuscle("legs")}
              >
                {/* Left Hamstring */}
                <path
                  d="M 76,180 C 65,198 67,215 72,230 L 96,230 C 98,206 98,190 100,180 Z"
                  fill={getFillColor("legs")}
                  stroke={getStrokeColor("legs")}
                  strokeWidth="1.5"
                  filter={getFilter("legs")}
                />
                {/* Right Hamstring */}
                <path
                  d="M 124,180 C 135,198 133,215 128,230 L 104,230 C 102,206 102,190 100,180 Z"
                  fill={getFillColor("legs")}
                  stroke={getStrokeColor("legs")}
                  strokeWidth="1.5"
                  filter={getFilter("legs")}
                />
                <title>Back Legs/Hamstrings (जांघ)</title>
              </g>

              {/* CALVES */}
              <g
                className="cursor-pointer transition-all duration-300"
                onClick={() => onToggleMuscle("calves")}
              >
                {/* Left Calf */}
                <path
                  d="M 74,234 C 68,245 68,265 77,282 L 85,282 C 88,272 88,242 86,234 Z"
                  fill={getFillColor("calves")}
                  stroke={getStrokeColor("calves")}
                  strokeWidth="1.5"
                  filter={getFilter("calves")}
                />
                {/* Right Calf */}
                <path
                  d="M 126,234 C 132,245 132,265 123,282 L 115,282 C 112,272 112,242 114,234 Z"
                  fill={getFillColor("calves")}
                  stroke={getStrokeColor("calves")}
                  strokeWidth="1.5"
                  filter={getFilter("calves")}
                />
                <title>Calves (पिंडलियां)</title>
              </g>
            </g>
          )}
        </svg>

        {/* Floating instructional note */}
        <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 bg-[#0A0A0A]/90 border border-brand-border/60 px-3 py-1 rounded-full text-[10px] text-brand-muted uppercase tracking-wider text-center flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-brand-accent animate-ping" />
          Click areas to toggle targets
        </div>
      </div>
    </div>
  );
}
