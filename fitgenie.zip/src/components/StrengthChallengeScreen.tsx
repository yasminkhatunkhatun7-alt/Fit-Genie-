import { useGenieIntelligence } from '../hooks/useGenieIntelligence';
import GeniePenaltyModal from './GeniePenaltyModal';
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Trophy, Target, ShieldAlert, Timer, Play, AlertTriangle, Star } from "lucide-react";
import { playSound } from "../utils/audio";
import { AiRepCounter } from "./AiRepCounter";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";
import { Camera } from "lucide-react";
import CompletionValidationModal from "./CompletionValidationModal";
import { calculateExpectedMinimumTime } from "../utils/integrityEngine";
import { useAuth } from "../context/AuthContext";
import { getTodayDateString } from "../utils/dailyChallenge";

export interface ActiveChallenge {
  id: string;
  title: string;
  xp: number;
  exercises: { name: string; targetReps: number; completedReps: number }[];
  desc?: string;
  startTime: number;
  difficulty?: string;
  time?: string;
  muscles?: string[];
  boss?: string;
}

interface StrengthChallengeScreenProps {
  challenge: ActiveChallenge;
  onUpdate: (updated: ActiveChallenge) => void;
  onBack: () => void;
  onComplete: (xpToAward: number) => Promise<boolean> | boolean | void;
}

export default function StrengthChallengeScreen({ challenge, onUpdate, onBack, onComplete }: StrengthChallengeScreenProps) {
  const {
    cooldown,
    suspiciousPhase,
    lockEndTime,
    checkCheat,
    proceedFromAlert,
    proceedFromMotivation,
    submitApology,
    resetSessionTime
  } = useGenieIntelligence(challenge.id);
  const { profile } = useAuth();
  const [showCompletion, setShowCompletion] = useState(false);
  const [showHonorValidation, setShowHonorValidation] = useState(false);
  const [honorChecked, setHonorChecked] = useState(false);
  const [floatingTexts, setFloatingTexts] = useState<{ id: number, text: string, x: number }[]>([]);
  const [textCounter, setTextCounter] = useState(0);

  const todayStr = getTodayDateString();
  const progressKey = `${challenge.id}_challenge_progress_${profile?.uid}`;
  const claimedKey = `${challenge.id}_challenge_claimed_${profile?.uid}`;

  const [hasClaimedToday, setHasClaimedToday] = useState(false);
  const [justClaimed, setJustClaimed] = useState(false);
  const [showAiCounter, setShowAiCounter] = useState(false);

  // Anti-cheat & Session State
  const [isStarted, setIsStarted] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [cooldown1, setCooldown1] = useState(0);
  const [cooldown10, setCooldown10] = useState(0);
  
  useEffect(() => {
    const claimedDate = localStorage.getItem(claimedKey);
    if (claimedDate === todayStr) {
      setHasClaimedToday(true);
    }

    const saved = localStorage.getItem(progressKey);
    if (saved) {
      try {
        const { date, completedReps, elapsed, started } = JSON.parse(saved);
        if (date === todayStr) {
          if (completedReps > challenge.exercises[0].completedReps) {
            const updated = { ...challenge };
            updated.exercises[0].completedReps = Math.min(updated.exercises[0].targetReps, completedReps);
            onUpdate(updated);
          }
          if (elapsed) setElapsedTime(elapsed);
          if (started) setIsStarted(started);
        } else {
          localStorage.removeItem(progressKey);
          const updated = { ...challenge };
          updated.exercises[0].completedReps = 0;
          onUpdate(updated);
        }
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const exercise = challenge.exercises[0] || { name: "Squats", targetReps: 150, completedReps: 0 };
  const progressPercent = Math.min(100, Math.round((exercise.completedReps / exercise.targetReps) * 100));
  const isCompleted = progressPercent >= 100;

  const bossMaxHP = exercise.targetReps;
  const bossCurrentHP = Math.max(0, bossMaxHP - exercise.completedReps);

  useEffect(() => {
    let timerId: NodeJS.Timeout;
    if (isStarted && !isCompleted && !hasClaimedToday) {
      timerId = setInterval(() => {
        setElapsedTime(prev => {
          const next = prev + 1;
          saveProgress(exercise.completedReps, next, true);
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(timerId);
  }, [isStarted, isCompleted, hasClaimedToday, exercise.completedReps]);

  useEffect(() => {
    let cdTimer: NodeJS.Timeout;
    if (cooldown1 > 0 || cooldown10 > 0) {
      cdTimer = setInterval(() => {
        setCooldown1(prev => Math.max(0, prev - 1));
        setCooldown10(prev => Math.max(0, prev - 1));
      }, 1000);
    }
    return () => clearInterval(cdTimer);
  }, [cooldown1, cooldown10]);

  useEffect(() => {
    if (isCompleted && !showCompletion && !showHonorValidation && !hasClaimedToday) {
      const timer = setTimeout(() => setShowHonorValidation(true), 500);
      return () => clearTimeout(timer);
    }
  }, [isCompleted, showCompletion, showHonorValidation, hasClaimedToday]);

  const saveProgress = (reps: number, elapsed: number, started: boolean) => {
    localStorage.setItem(progressKey, JSON.stringify({
      date: todayStr,
      completedReps: reps,
      elapsed: elapsed,
      started: started
    }));
  };

  const handleStart = () => {
    playSound("click");
    setIsStarted(true);
    saveProgress(exercise.completedReps, elapsedTime, true);
  };

  const handleAddReps = (amount: number, fromAI: boolean = false) => {
    if (isCompleted || hasClaimedToday) return;

    if (amount === 1 && cooldown > 0) return;
    if (amount === 10 && cooldown > 0) return;

    if (!fromAI && checkCheat(exercise.name, amount)) {
      const updated = { ...challenge };
      updated.exercises[0].completedReps = 0;
      onUpdate(updated);
      return;
    }

    const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);

    if (amount === 1) {
      setCooldown1(1); // 1 sec cooldown
    } else if (amount === 10) {
      setCooldown10(10); // 10 sec cooldown
    }

    playSound("timer_tick");
    
    const id = textCounter;
    setTextCounter(prev => prev + 1);
    setFloatingTexts(prev => [...prev, { id, text: `+${amount}`, x: Math.random() * 40 - 20 }]);
    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== id));
    }, 1000);

    const updated = { ...challenge };
    updated.exercises[0].completedReps = newCompleted;
    
    saveProgress(newCompleted, elapsedTime, isStarted);
    onUpdate(updated);
  };


  const handleFinish = () => {
    onBack();
  };

  const [showReviewModal, setShowReviewModal] = useState(false);

  const handleClaimXP = async () => {
    if (!honorChecked) return;
    setShowHonorValidation(false);
    await finalizeClaimXP();
  };

  const finalizeClaimXP = async () => {
    setShowReviewModal(false);
    playSound("success");
    if (!hasClaimedToday) {
      const result = await onComplete(challenge.xp);
      if (result === false) return; // Validation failed
      localStorage.setItem(claimedKey, todayStr);
      setHasClaimedToday(true);
      setJustClaimed(true);
    }
    setShowCompletion(true);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const getMotivationMessage = () => {
    if (progressPercent >= 90) return "👑 Boss almost defeated!";
    if (progressPercent >= 75) return "💪 Beast mode activated!";
    if (progressPercent >= 50) return "⚡ Halfway there warrior!";
    if (progressPercent >= 25) {
      return exercise.name.toLowerCase().includes("push")
        ? "🔥 Chest & triceps firing up!"
        : "🔥 Legs warming up!";
    }
    return "";
  };

  if (suspiciousPhase !== 'none') {
    return (
      <GeniePenaltyModal 
        suspiciousPhase={suspiciousPhase as any}
        lockEndTime={lockEndTime}
        onProceedFromAlert={proceedFromAlert}
        onProceedFromMotivation={proceedFromMotivation}
        onSubmitApology={submitApology}
      />
    );
  }

  if (showReviewModal) {
    return (
      <CompletionValidationModal
        durationSeconds={elapsedTime}
        expectedSeconds={calculateExpectedMinimumTime(challenge.exercises)}
        exerciseName={challenge.exercises[0].name}
        targetReps={challenge.exercises[0].targetReps}
        onValid={finalizeClaimXP}
        onInvalid={() => {
            setShowReviewModal(false);
            setElapsedTime(0);
            const updated = { ...challenge };
            updated.exercises[0].completedReps = 0;
            saveProgress(0, 0, false);
            setIsStarted(false);
            onUpdate(updated);
        }}
      />
    );
  }

  if (showHonorValidation) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/90 flex flex-col items-center justify-center p-6 backdrop-blur-sm">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-[#050B1A] border border-[#14F1E1]/30 shadow-[0_0_30px_rgba(20,241,225,0.15)] rounded-3xl p-6 text-center max-w-sm w-full relative"
        >
          <Trophy className="w-16 h-16 text-[#14F1E1] mx-auto mb-4" />
          <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-4">🏆 Challenge Complete</h2>
          <p className="text-neutral-300 text-sm mb-6 leading-relaxed">
            {exercise.targetReps} {exercise.name} Completed?<br/><br/>
            Please confirm that you completed this challenge honestly.<br/>
            Fit Genie trust system par kaam karta hai.<br/><br/>
            <span className="text-[#14F1E1] font-bold">Real effort = Real progress. 💪</span>
          </p>
          
          <label className="flex items-center gap-3 p-4 bg-white/5 border border-white/10 rounded-xl cursor-pointer mb-6 text-left hover:bg-white/10 transition-colors">
            <input 
              type="checkbox" 
              checked={honorChecked}
              onChange={(e) => setHonorChecked(e.target.checked)}
              className="w-5 h-5 accent-[#14F1E1] rounded border-white/20 bg-white/10"
            />
            <span className="text-sm font-bold text-white leading-tight">Yes, I completed these reps honestly.</span>
          </label>

          <button 
            onClick={handleClaimXP}
            disabled={!honorChecked}
            className={`w-full py-4 font-black text-sm uppercase tracking-widest rounded-xl transition-all ${honorChecked ? 'bg-[#14F1E1] text-[#050B1A] shadow-[0_0_20px_rgba(20,241,225,0.4)]' : 'bg-white/10 text-neutral-500 cursor-not-allowed'}`}
          >
            🎁 Claim XP
          </button>
        </motion.div>
      </div>
    );
  }

  if (showCompletion || hasClaimedToday) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }} 
        animate={{ opacity: 1, scale: 1 }} 
        className="fixed inset-0 z-50 bg-[#050B1A] flex flex-col items-center justify-center p-6"
      >
        {/* Simple Confetti */}
        {justClaimed && Array.from({ length: 30 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: Math.random() * window.innerWidth, 
              y: -20, 
              opacity: 1,
              rotate: 0 
            }}
            animate={{ 
              y: window.innerHeight + 20,
              rotate: 360,
              opacity: 0
            }}
            transition={{ 
              duration: 2 + Math.random() * 2, 
              ease: "linear", 
              repeat: Infinity 
            }}
            className="absolute w-2 h-4 rounded-sm"
            style={{ 
              backgroundColor: ['#14F1E1', '#B66DFF', '#F97316', '#FFFFFF'][Math.floor(Math.random() * 4)],
              left: `${Math.random() * 95}%`
            }}
          />
        ))}

        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center space-y-6 max-w-sm w-full relative z-10"
        >
          <div className="w-32 h-32 mx-auto bg-red-500/20 rounded-full flex items-center justify-center relative">
            <div className="absolute inset-0 bg-red-500 rounded-full blur-xl opacity-50 animate-pulse" />
            <Trophy className="w-16 h-16 text-white relative z-10" />
          </div>
          
          <div>
            <h1 className="text-4xl font-black uppercase text-white tracking-tight">🎉 BOSS DEFEATED!</h1>
            <p className="text-red-400 text-lg font-bold mt-2">{exercise.name.toUpperCase()} DESTROYER has fallen.</p>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-4">
            {justClaimed ? (
              <>
                <div className="flex justify-between items-center">
                  <span className="text-neutral-400 font-bold uppercase tracking-widest text-xs">Reward Claimed</span>
                  <span className="text-[#14F1E1] font-black text-xl">+{challenge.xp} XP Earned</span>
                </div>
                <div className="text-sm font-medium text-neutral-300 mt-4 leading-relaxed">
                  🔥 Amazing Work Warrior!<br/><br/>
                  Challenge completed successfully.<br/><br/>
                  Kal naye mission ke saath wapas aana.<br/>
                </div>
              </>
            ) : (
              <div className="text-center">
                <span className="text-neutral-400 font-bold uppercase tracking-widest text-xs leading-relaxed">
                  Aaj ka {challenge.title} complete ho gaya.<br/>
                  Kal naye mission ke saath wapas aana.<br/>
                </span>
              </div>
            )}
          </div>

          <div className="pt-4 space-y-4">
            <button
              onClick={() => {
                playSound("click");
                onBack();
              }}
              className="w-full py-4 bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-sm uppercase tracking-widest rounded-xl transition-all shadow-[0_0_20px_rgba(20,241,225,0.4)]"
            >
              Return To Challenges
            </button>
          </div>
        </motion.div>
      </motion.div>
    );
  }

  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  const motivationMsg = getMotivationMessage();

  return (
    <div className="max-w-md mx-auto p-4 space-y-8 pb-24 min-h-screen relative">
      {/* HEADER */}
      <div className="flex items-center justify-between mb-2">
        <button onClick={() => { playSound("click"); onBack(); }} className="flex items-center gap-2 text-[#B66DFF]">
          <ChevronLeft className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs">Back to List</span>
        </button>
        <div className="flex flex-col items-end text-neutral-400">
          <div className="flex items-center gap-1.5">
            <Timer className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-widest">Time</span>
          </div>
          {isStarted && (
            <span className="text-white font-mono text-sm font-bold">{formatTime(elapsedTime)}</span>
          )}
        </div>
      </div>

      {/* APEX CYBER BOSS SHIELD TELEMETRY */}
      <div className="bg-gradient-to-br from-[#200A14] via-[#12071A] to-[#050B1A] border border-red-500/40 rounded-2xl p-4 relative overflow-hidden shadow-[0_0_25px_rgba(239,68,68,0.15)]">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-red-500/15 border border-red-500/40 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(239,68,68,0.25)]">
              <ShieldAlert className="w-6 h-6 text-red-400 animate-pulse" />
            </div>
            <div className="text-left">
              <span className="text-[9px] font-mono font-black uppercase tracking-[0.2em] text-red-400 block">
                TITAN ARMOR • MAX VOLUME
              </span>
              <h2 className="text-lg font-black uppercase tracking-tight text-white">
                {exercise.name.toUpperCase()} DESTROYER
              </h2>
            </div>
          </div>
          <div className="text-right font-mono">
            <span className="text-xs font-black text-red-400 block">{bossCurrentHP} / {bossMaxHP} HP</span>
            <span className="text-[9px] text-neutral-400 uppercase font-bold">{progressPercent}% CRUSHED</span>
          </div>
        </div>
        <div className="h-3 w-full bg-black/70 rounded-full overflow-hidden relative border border-red-500/30 mt-3 p-0.5">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-red-600 via-orange-500 to-amber-400 shadow-[0_0_12px_rgba(239,68,68,0.6)]"
            initial={{ width: '100%' }}
            animate={{ width: `${(bossCurrentHP / bossMaxHP) * 100}%` }}
            transition={{ duration: 0.4 }}
          />
        </div>
      </div>

      {/* LIVE 3D HOLOGRAM ATHLETE & PACER */}
      <div className="rounded-2xl overflow-hidden border border-[#14F1E1]/25 bg-[#050B1A] shadow-[0_0_25px_rgba(20,241,225,0.08)]">
        <Exercise3DCharacterLoop
          exerciseName={exercise.name}
          targetMuscles={exercise.name.toLowerCase().includes("push") ? ["Chest", "Triceps", "Shoulders"] : ["Legs", "Quads", "Glutes"]}
          difficulty="advanced"
          heightClass="h-[230px]"
          showControls={true}
        />
      </div>

      {/* REP COUNTER TELEMETRY BAR */}
      <div className="bg-[#0B1226] border border-[#B66DFF]/30 rounded-2xl p-4 flex items-center justify-between">
        <div className="text-left">
          <span className="text-[10px] font-mono font-black uppercase tracking-widest text-[#B66DFF] block">
            ACTIVE TARGET: {exercise.name.toUpperCase()}
          </span>
          <span className="text-2xl font-black font-mono text-white">
            {exercise.completedReps} <span className="text-sm text-neutral-400">/ {exercise.targetReps} REPS</span>
          </span>
        </div>
        <div className="text-right">
          <span className="text-3xl font-black font-mono text-[#14F1E1]">{progressPercent}%</span>
          {motivationMsg && (
            <span className="block text-[9px] font-black uppercase tracking-wider text-amber-300 mt-0.5">
              {motivationMsg}
            </span>
          )}
        </div>
      </div>

      {/* CONTROLS */}
      {!isStarted ? (
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleStart}
          className="w-full py-5 bg-[#B66DFF] text-white rounded-2xl font-black text-lg uppercase tracking-widest flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(182,109,255,0.4)]"
        >
          <Play className="w-6 h-6 fill-current" />
          START CHALLENGE
        </motion.button>
      ) : (
        <div className="grid grid-cols-1 gap-3 relative">
            <div className="grid grid-cols-4 gap-2.5 w-full">
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(1)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl cursor-pointer">+1</motion.button>
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(5)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl cursor-pointer">+5</motion.button>
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(10)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl cursor-pointer">+10</motion.button>
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(15)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl cursor-pointer">+15</motion.button>
            </div>
            {(exercise.name.toLowerCase().includes('pushup') || exercise.name.toLowerCase().includes('push up') || exercise.name.toLowerCase().includes('squat')) && (
               <motion.button 
                 whileTap={{ scale: 0.95 }}
                 onClick={() => setShowAiCounter(true)}
                 disabled={isCompleted || hasClaimedToday}
                 className="bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-sm py-4 rounded-2xl flex justify-center items-center gap-2 shadow-[0_0_20px_rgba(20,241,225,0.4)] transition-all disabled:opacity-50 cursor-pointer"
               >
                 <Camera className="w-5 h-5" />
                 AI CAMERA REP TRACKER
               </motion.button>
             )}
            
            {/* FLOATING TEXTS */}
            <AnimatePresence>
              {floatingTexts.map((ft) => (
                <motion.div
                  key={ft.id}
                  initial={{ opacity: 1, y: 0, x: ft.x, scale: 1 }}
                  animate={{ opacity: 0, y: -50, scale: 1.5 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                  className="absolute pointer-events-none left-1/2 -translate-x-1/2 -top-10 text-white font-black text-2xl z-20"
                >
                  {ft.text}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

      {/* STATS */}
      <div className="bg-[#050B1A] border border-white/10 rounded-2xl p-5 flex items-center justify-between mt-4">
        <div className="flex items-center gap-3">
          <div className="bg-yellow-500/20 p-2 rounded-xl">
            <Star className="w-5 h-5 text-yellow-500" />
          </div>
          <div>
            <h4 className="text-white font-black uppercase text-sm">Reward XP</h4>
            <p className="text-neutral-400 text-xs font-bold">Upon Defeating Boss</p>
          </div>
        </div>
        <div className="text-yellow-400 font-black text-2xl">
          {challenge.xp}
        </div>
      </div>

      {showAiCounter && (
        <AiRepCounter
          initialExercise={exercise.name.toLowerCase().includes('squat') ? "Squats" : "Pushups"}
          onClose={() => setShowAiCounter(false)}
          onComplete={(reps) => {
            if (reps > 0) {
              handleAddReps(reps, true);
            }
            setShowAiCounter(false);
          }}
        />
      )}
    </div>
  );
}
