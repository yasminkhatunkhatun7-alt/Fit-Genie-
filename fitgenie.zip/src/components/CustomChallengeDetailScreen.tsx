import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ChevronLeft,
  Trophy,
  Target,
  Crosshair,
  Sword,
  Activity,
  CheckCircle2,
  Edit2,
  Trash2,
  Calendar,
  Clock,
  Flame,
  Camera,
  Plus,
  X,
  RotateCcw,
} from "lucide-react";
import { playSound } from "../utils/audio";
import { AiRepCounter } from "./AiRepCounter";
import { useAuth } from "../context/AuthContext";
import { ActiveChallenge } from "./StrengthChallengeScreen";
import MuscleSelector from "./MuscleSelector";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";
import { useGenieIntelligence } from "../hooks/useGenieIntelligence";
import GeniePenaltyModal from "./GeniePenaltyModal";

interface Props {
  challenge: ActiveChallenge;
  onUpdate: (updated: ActiveChallenge) => void;
  onBack: () => void;
  onComplete: (xpToAward: number) => Promise<boolean> | boolean | void;
  onDelete?: () => void;
  onEditMuscles?: () => void;
}

const BOSS_MAP: Record<string, string> = {
  "Chest": "Iron Titan",
  "Back": "Shadow Beast",
  "Shoulders": "Deltoid Destroyer",
  "Biceps": "Peak Brawler",
  "Triceps": "Tricep Terror",
  "Forearms": "Grip Master",
  "Abs": "Core King",
  "Obliques": "Core King",
  "Legs": "Leg Destroyer",
  "Quads": "Leg Destroyer",
  "Hamstrings": "Hamstring Hammer",
  "Calves": "Calf Crusher",
  "Glutes": "Glute Giant",
  "Lats": "Shadow Beast",
  "Traps": "Shadow Beast",
  "Rear Delts": "Shadow Beast",
  "Lower Back": "Core King",
  "Neck": "Iron Atlas",
};

export default function CustomChallengeDetailScreen({
  challenge,
  onUpdate,
  onBack,
  onComplete,
  onDelete,
  onEditMuscles,
}: Props) {
  const { profile } = useAuth();
  const {
    suspiciousPhase,
    lockEndTime,
    checkCheat,
    proceedFromAlert,
    proceedFromMotivation,
    submitApology,
    resetSessionTime,
  } = useGenieIntelligence(`custom_${challenge.id}`);

  const [showCompletion, setShowCompletion] = useState(false);
  const [showHonorValidation, setShowHonorValidation] = useState(false);
  const [honorChecked, setHonorChecked] = useState(false);
  const [floatingTexts, setFloatingTexts] = useState<
    { id: string; text: string; x: number }[]
  >([]);
  const [bossHitDamage, setBossHitDamage] = useState<number | null>(null);

  // Edit Exercises Modal State
  const [showEditModal, setShowEditModal] = useState(false);
  const [newExName, setNewExName] = useState("");
  const [newExReps, setNewExReps] = useState("30");

  const progressKey = `custom_challenge_progress_${profile?.uid}_${challenge.id}`;
  const claimedKey = `custom_challenge_claimed_${profile?.uid}_${challenge.id}`;

  const [elapsedTime, setElapsedTime] = useState(0);
  const [isStarted, setIsStarted] = useState(false);

  const [hasClaimed, setHasClaimed] = useState(() => {
    return localStorage.getItem(claimedKey) === "true";
  });
  const [justClaimed, setJustClaimed] = useState(false);
  const [showAiCounter, setShowAiCounter] = useState(false);
  const [aiExerciseIndex, setAiExerciseIndex] = useState(0);

  useEffect(() => {
    const saved = localStorage.getItem(progressKey);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed) {
          if (parsed.elapsed) setElapsedTime(parsed.elapsed);
          if (parsed.started) setIsStarted(parsed.started);
        }
        if (parsed && parsed.exercises) {
          const updated = { ...challenge };
          let changed = false;
          updated.exercises = updated.exercises.map((ex, i) => {
            if (
              parsed.exercises[i] !== undefined &&
              parsed.exercises[i].completedReps !== undefined
            ) {
              if (ex.completedReps !== parsed.exercises[i].completedReps)
                changed = true;
              return { ...ex, completedReps: parsed.exercises[i].completedReps };
            }
            return ex;
          });
          if (changed) {
            onUpdate(updated);
          }
        }
      } catch (e) {
        console.error("Failed to restore progress", e);
      }
    }
  }, []);

  const totalTargetReps = Math.max(
    1,
    challenge.exercises.reduce((sum, ex) => sum + ex.targetReps, 0)
  );
  const totalCompletedReps = challenge.exercises.reduce(
    (sum, ex) => sum + ex.completedReps,
    0
  );
  const remainingReps = Math.max(0, totalTargetReps - totalCompletedReps);

  const progressPercent = Math.min(
    100,
    (totalCompletedReps / totalTargetReps) * 100
  );
  const isCompleted =
    challenge.exercises.length > 0 &&
    challenge.exercises.every((ex) => ex.completedReps >= ex.targetReps);

  useEffect(() => {
    let timerId: NodeJS.Timeout;
    if (isStarted && !isCompleted && !hasClaimed) {
      timerId = setInterval(() => {
        setElapsedTime((prev) => {
          const next = prev + 1;
          saveProgress(challenge.exercises, next, true);
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(timerId);
  }, [isStarted, isCompleted, hasClaimed, challenge.exercises]);

  const bossMaxHP = totalTargetReps;
  const bossCurrentHP = Math.max(0, bossMaxHP - totalCompletedReps);
  const primaryMuscle = challenge.muscles?.[0] || "Full Body";
  const bossName = BOSS_MAP[primaryMuscle] || "Iron Titan";
  const bossDesc = `Build your ${primaryMuscle.toLowerCase()} strength and defeat the ${bossName}.`;
  const rewardXp = challenge.xp && challenge.xp > 0 ? challenge.xp : Math.max(150, challenge.exercises.length * 75);

  useEffect(() => {
    if (isCompleted && !showCompletion && !showHonorValidation && !hasClaimed) {
      const timer = setTimeout(() => setShowHonorValidation(true), 400);
      return () => clearTimeout(timer);
    }
  }, [isCompleted, showCompletion, showHonorValidation, hasClaimed]);

  const saveProgress = (exercises: any[], elapsed: number, started: boolean) => {
    localStorage.setItem(
      progressKey,
      JSON.stringify({ exercises, elapsed, started })
    );
  };

  const handleAddReps = (
    exerciseIndex: number,
    amount: number,
    fromAI: boolean = false
  ) => {
    if (isCompleted || hasClaimed) return;
    const targetEx = challenge.exercises[exerciseIndex];
    if (!targetEx) return;

    if (!fromAI && checkCheat(targetEx.name, amount)) {
      return;
    }

    playSound("timer_tick");
    setBossHitDamage(amount);
    setTimeout(() => setBossHitDamage(null), 650);

    const id = Date.now() + "_" + Math.random();
    setFloatingTexts((prev) => [
      ...prev,
      { id, text: `+${amount}`, x: Math.random() * 40 - 20 },
    ]);
    setTimeout(() => {
      setFloatingTexts((prev) => prev.filter((t) => t.id !== id));
    }, 900);

    const updated = {
      ...challenge,
      exercises: challenge.exercises.map((ex, idx) =>
        idx === exerciseIndex
          ? {
              ...ex,
              completedReps: Math.min(ex.targetReps, ex.completedReps + amount),
            }
          : ex
      ),
    };

    onUpdate(updated);
    if (!isStarted) setIsStarted(true);
    saveProgress(updated.exercises, elapsedTime, true);
  };

  const handleResetProgress = () => {
    playSound("click");
    const updated = {
      ...challenge,
      exercises: challenge.exercises.map((ex) => ({ ...ex, completedReps: 0 })),
    };
    setElapsedTime(0);
    setIsStarted(false);
    resetSessionTime();
    localStorage.removeItem(progressKey);
    onUpdate(updated);
  };

  const handleDeleteChallenge = () => {
    playSound("click");
    localStorage.removeItem(progressKey);
    localStorage.removeItem(claimedKey);
    if (onDelete) {
      onDelete();
    } else {
      onBack();
    }
  };

  const handleUpdateTargetReps = (index: number, newTarget: number) => {
    const safeTarget = Math.max(5, newTarget);
    const updatedExercises = challenge.exercises.map((ex, i) =>
      i === index
        ? {
            ...ex,
            targetReps: safeTarget,
            completedReps: Math.min(ex.completedReps, safeTarget),
          }
        : ex
    );
    const updated = { ...challenge, exercises: updatedExercises };
    onUpdate(updated);
    saveProgress(updatedExercises, elapsedTime, isStarted);
  };

  const handleRemoveExercise = (index: number) => {
    if (challenge.exercises.length <= 1) return;
    playSound("click");
    const updatedExercises = challenge.exercises.filter((_, i) => i !== index);
    const updated = {
      ...challenge,
      exercises: updatedExercises,
      xp: Math.max(150, updatedExercises.length * 75),
    };
    onUpdate(updated);
    saveProgress(updatedExercises, elapsedTime, isStarted);
  };

  const handleAddCustomExercise = () => {
    const trimmed = newExName.trim();
    const reps = parseInt(newExReps, 10);
    if (!trimmed || isNaN(reps) || reps <= 0) return;
    playSound("success");
    const updatedExercises = [
      ...challenge.exercises,
      { name: trimmed, targetReps: reps, completedReps: 0 },
    ];
    const updated = {
      ...challenge,
      exercises: updatedExercises,
      xp: Math.max(150, updatedExercises.length * 75),
    };
    onUpdate(updated);
    saveProgress(updatedExercises, elapsedTime, isStarted);
    setNewExName("");
    setNewExReps("30");
  };

  const handleClaimXP = async () => {
    if (!honorChecked) return;
    setShowHonorValidation(false);
    playSound("success");
    if (!hasClaimed) {
      const result = await onComplete(rewardXp);
      if (result === false) return;
      localStorage.setItem(claimedKey, "true");
      setHasClaimed(true);
      setJustClaimed(true);
    }
    setShowCompletion(true);
  };

  const formatElapsed = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  };

  if (suspiciousPhase !== "none") {
    return (
      <GeniePenaltyModal
        suspiciousPhase={suspiciousPhase}
        lockEndTime={lockEndTime}
        onProceedFromAlert={proceedFromAlert}
        onProceedFromMotivation={proceedFromMotivation}
        onSubmitApology={submitApology}
      />
    );
  }

  if (showHonorValidation) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/95 flex flex-col items-center justify-center p-6 backdrop-blur-md">
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-[#050B1A] border border-[#14F1E1]/30 shadow-[0_0_40px_rgba(20,241,225,0.2)] rounded-3xl p-6 text-center max-w-sm w-full relative"
        >
          <Target className="w-16 h-16 text-[#14F1E1] mx-auto mb-4" />
          <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-2">
            🎯 CHALLENGE COMPLETED
          </h2>
          <p className="text-[#14F1E1] text-sm font-black uppercase tracking-widest mb-4">
            +{rewardXp} XP Reward Ready
          </p>

          <label className="flex items-center gap-3 p-4 bg-white/5 border border-white/10 rounded-xl cursor-pointer mb-6 text-left hover:bg-white/10 transition-colors">
            <input
              type="checkbox"
              checked={honorChecked}
              onChange={(e) => setHonorChecked(e.target.checked)}
              className="w-5 h-5 accent-[#14F1E1] rounded border-white/20 bg-white/10 flex-shrink-0"
            />
            <span className="text-sm font-bold text-white leading-tight">
              Yes, I completed this custom workout honestly.
            </span>
          </label>

          <button
            onClick={handleClaimXP}
            disabled={!honorChecked}
            className={`w-full py-4 font-black text-sm uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer ${
              honorChecked
                ? "bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] shadow-[0_0_20px_rgba(20,241,225,0.4)]"
                : "bg-white/10 text-neutral-500 cursor-not-allowed"
            }`}
          >
            <CheckCircle2 className="w-5 h-5" /> CLAIM +{rewardXp} XP
          </button>

          <p className="text-neutral-500 text-[10px] uppercase tracking-widest font-bold mt-6">
            Fit Genie trust system works on honesty.
            <br />
            Real effort = Real progress.
          </p>
        </motion.div>
      </div>
    );
  }

  if (showCompletion || hasClaimed) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="fixed inset-0 z-50 bg-[#050B1A] flex flex-col items-center justify-center p-6"
      >
        {justClaimed &&
          Array.from({ length: 35 }).map((_, i) => (
            <motion.div
              key={i}
              initial={{
                x: Math.random() * window.innerWidth,
                y: -20,
                opacity: 1,
                rotate: 0,
              }}
              animate={{
                y: window.innerHeight + 20,
                rotate: 360,
                opacity: 0,
              }}
              transition={{
                duration: 2 + Math.random() * 2,
                ease: "linear",
                repeat: Infinity,
              }}
              className="absolute w-2 h-4 rounded-sm"
              style={{
                backgroundColor: ["#14F1E1", "#B66DFF", "#F97316", "#FFFFFF"][
                  Math.floor(Math.random() * 4)
                ],
                left: `${Math.random() * 95}%`,
              }}
            />
          ))}

        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.15 }}
          className="text-center space-y-6 max-w-sm w-full relative z-10"
        >
          <div className="w-28 h-28 mx-auto bg-[#14F1E1]/20 rounded-full flex items-center justify-center relative">
            <div className="absolute inset-0 bg-[#14F1E1] rounded-full blur-xl opacity-40 animate-pulse" />
            <Crosshair className="w-14 h-14 text-[#14F1E1] relative z-10" />
          </div>

          <div>
            <h1 className="text-3xl font-black uppercase text-white tracking-tight leading-tight">
              🏆 MISSION COMPLETE
            </h1>
            <p className="text-[#14F1E1] text-base font-bold mt-2 uppercase tracking-widest">
              {bossName} DEFEATED! (+{rewardXp} XP)
            </p>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-4 relative overflow-hidden">
            <div className="text-center space-y-4 relative z-10">
              <div className="inline-block px-4 py-1.5 bg-[#14F1E1]/20 text-[#14F1E1] rounded-full text-xs font-black uppercase tracking-widest border border-[#14F1E1]/30">
                Personal Goal Achieved
              </div>
              <div className="space-y-3 mt-4 text-left border-t border-white/10 pt-4">
                <div className="flex items-center gap-3 bg-white/5 p-3 rounded-xl border border-white/10">
                  <Trophy className="w-5 h-5 text-yellow-400" />
                  <div>
                    <p className="text-white text-sm font-black uppercase">
                      Completion Certificate
                    </p>
                    <p className="text-neutral-400 text-[10px] font-bold uppercase tracking-widest">
                      {(challenge.muscles || [primaryMuscle]).join(", ")} Warrior
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3 bg-white/5 p-3 rounded-xl border border-white/10">
                  <Activity className="w-5 h-5 text-[#14F1E1]" />
                  <div>
                    <p className="text-white text-sm font-black uppercase">
                      Total Volume Crushed
                    </p>
                    <p className="text-neutral-400 text-[10px] font-bold uppercase tracking-widest">
                      {totalTargetReps} Total Reps Logged
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => {
                playSound("click");
                onBack();
              }}
              className="w-full py-4 bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-sm uppercase tracking-widest rounded-xl transition-all shadow-[0_0_20px_rgba(20,241,225,0.4)] cursor-pointer"
            >
              Return To Challenges
            </button>
          </div>
        </motion.div>
      </motion.div>
    );
  }

  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset =
    circumference - (progressPercent / 100) * circumference;

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen relative font-sans">
      <AnimatePresence>
        {floatingTexts.map((ft) => (
          <motion.div
            key={ft.id}
            initial={{ opacity: 1, y: 0, x: ft.x }}
            animate={{
              opacity: 0,
              y: -50,
              x: ft.x + (Math.random() * 20 - 10),
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.9 }}
            className="fixed top-1/2 left-1/2 text-[#14F1E1] font-black text-4xl pointer-events-none z-50 drop-shadow-[0_0_10px_rgba(20,241,225,0.8)]"
            style={{ transform: "translate(-50%, -50%)" }}
          >
            {ft.text}
          </motion.div>
        ))}
      </AnimatePresence>

      {/* TOP HEADER WITH WORKING EDIT, RESET & DELETE BUTTONS */}
      <div className="flex items-center justify-between mb-2">
        <button
          onClick={() => {
            playSound("click");
            onBack();
          }}
          className="flex items-center gap-2 text-[#14F1E1] hover:text-white transition-colors bg-white/5 px-3 py-2 rounded-xl border border-white/10 cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs">
            Back
          </span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              playSound("click");
              setShowEditModal(true);
            }}
            title="Edit Exercises & Target Reps"
            className="bg-white/5 p-2 rounded-xl border border-white/10 text-white hover:bg-white/15 transition-colors flex items-center gap-1.5 px-3 text-xs font-bold cursor-pointer"
          >
            <Edit2 className="w-3.5 h-3.5 text-[#14F1E1]" />
            <span>Edit</span>
          </button>

          <button
            onClick={handleResetProgress}
            title="Reset Reps to 0"
            className="bg-white/5 p-2 rounded-xl border border-white/10 text-neutral-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={handleDeleteChallenge}
            title="Delete Custom Challenge"
            className="bg-red-500/10 p-2 rounded-xl border border-red-500/20 text-red-400 hover:bg-red-500/20 transition-colors cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* MISSION OVERVIEW CARD */}
      <div className="bg-gradient-to-br from-[#050B1A] to-white/5 border border-white/10 rounded-2xl p-6 relative overflow-hidden shadow-[0_0_30px_rgba(0,0,0,0.5)]">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#14F1E1]/5 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
        <h2 className="text-2xl font-black text-white uppercase tracking-tight leading-tight">
          {challenge.title}
        </h2>

        <div className="flex flex-wrap gap-2 mt-3">
          <span className="bg-[#14F1E1]/20 text-[#14F1E1] px-2.5 py-1 rounded text-[10px] font-black uppercase tracking-widest border border-[#14F1E1]/30">
            +{rewardXp} XP Reward
          </span>
          <span className="bg-[#B66DFF]/20 text-[#B66DFF] px-2.5 py-1 rounded text-[10px] font-black uppercase tracking-widest border border-[#B66DFF]/30">
            {challenge.difficulty || "Custom Mission"}
          </span>
          {onEditMuscles && (
            <button
              onClick={() => {
                playSound("click");
                onEditMuscles();
              }}
              className="bg-white/10 hover:bg-white/15 text-neutral-200 px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-widest border border-white/10 flex items-center gap-1 cursor-pointer"
            >
              <Target className="w-3 h-3 text-[#14F1E1]" /> Change Muscles
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 gap-4 mt-5 pt-5 border-t border-white/10 relative z-10">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-1 text-neutral-500 text-[10px] uppercase font-bold tracking-widest">
              <Calendar className="w-3 h-3" /> Start Date
            </div>
            <p className="text-white text-xs font-bold">
              {new Date(challenge.startTime).toLocaleDateString()}
            </p>
          </div>
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-1 text-neutral-500 text-[10px] uppercase font-bold tracking-widest">
              <Clock className="w-3 h-3" /> Session Timer
            </div>
            <p className="text-[#14F1E1] text-xs font-mono font-bold">
              {formatElapsed(elapsedTime)}
            </p>
          </div>
        </div>
      </div>

      {/* TARGET MUSCLE 3D ANATOMY SECTION */}
      <div className="bg-gradient-to-b from-[#050B1A] to-white/5 border border-white/10 rounded-2xl p-5 flex flex-col items-center justify-center relative overflow-hidden shadow-[0_0_30px_rgba(20,241,225,0.05)]">
        <div className="w-full flex items-center justify-between mb-2 relative z-10">
          <h3 className="text-[#14F1E1] font-black text-xs uppercase tracking-widest flex items-center gap-2">
            <Target className="w-4 h-4" /> TARGET MUSCLES:{" "}
            {(challenge.muscles || [primaryMuscle]).join(", ").toUpperCase()}
          </h3>
        </div>

        <p className="text-neutral-300 text-xs italic text-center mb-3 relative z-10">
          "{bossDesc}"
        </p>

        <div className="w-full relative z-10 flex justify-center py-2">
          <MuscleSelector
            selectedMuscles={challenge.muscles || []}
            toggleMuscle={() => {}}
            readonly
          />
        </div>
      </div>

      {/* 3D CYBER-MECH BOSS BATTLE STAGE */}
      <motion.div
        animate={
          bossHitDamage
            ? { x: [0, -8, 8, -5, 5, 0], scale: [1, 0.98, 1.02, 1] }
            : { x: 0, scale: 1 }
        }
        transition={{ duration: 0.35 }}
        className={`bg-gradient-to-b from-[#1A050A] via-[#0D0408] to-[#050B1A] border rounded-3xl p-6 flex flex-col items-center text-center relative overflow-hidden transition-all ${
          bossHitDamage
            ? "border-red-400 shadow-[0_0_50px_rgba(239,68,68,0.55)]"
            : "border-red-500/35 shadow-[0_18px_45px_rgba(220,38,38,0.18)]"
        }`}
      >
        {/* Top Crimson Specular Rim */}
        <div className="absolute top-0 left-10 right-10 h-[2px] bg-gradient-to-r from-transparent via-red-500 to-transparent" />

        {/* Live Hit-Slash Laser Effect when user logs reps */}
        <AnimatePresence>
          {bossHitDamage && (
            <motion.div
              initial={{ opacity: 1, scale: 0.6, rotate: -25 }}
              animate={{ opacity: 0, scale: 1.5, rotate: -15 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.55 }}
              className="absolute inset-0 z-30 pointer-events-none flex items-center justify-center"
            >
              <div className="w-72 h-2 bg-gradient-to-r from-transparent via-[#14F1E1] to-transparent shadow-[0_0_25px_#14F1E1] rotate-[-28deg]" />
              <span className="absolute top-6 right-6 px-3 py-1 rounded-full bg-red-600 text-white font-mono font-black text-xs uppercase tracking-widest shadow-[0_0_20px_rgba(239,68,68,0.9)]">
                -{bossHitDamage} HP CRIT! ⚡
              </span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 3D Animated Cyber-Mech Boss Avatar */}
        <div className="relative w-44 h-44 flex items-center justify-center mb-2">
          {/* Outer Rotating 3D Combat Radar Ring */}
          <motion.div
            animate={{ rotateZ: 360 }}
            transition={{ duration: 14, repeat: Infinity, ease: "linear" }}
            className="absolute inset-2 rounded-full border border-dashed border-red-500/35 pointer-events-none"
          />
          <motion.div
            animate={{ rotateZ: -360 }}
            transition={{ duration: 9, repeat: Infinity, ease: "linear" }}
            className="absolute inset-6 rounded-full border border-orange-500/25 pointer-events-none"
          />

          {/* 3D Volumetric Cyber-Titan SVG */}
          <motion.svg
            viewBox="0 0 160 160"
            className="w-40 h-40 relative z-10 overflow-visible"
            animate={{ y: [0, -5, 0] }}
            transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut" }}
          >
            <defs>
              <radialGradient id="bossCoreGrad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#FFF" />
                <stop offset="35%" stopColor="#FF4D4D" />
                <stop offset="100%" stopColor="#7F1D1D" stopOpacity="0" />
              </radialGradient>
              <linearGradient id="bossArmorGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#450A0A" />
                <stop offset="50%" stopColor="#1F1218" />
                <stop offset="100%" stopColor="#09050A" />
              </linearGradient>
            </defs>

            {/* 3D Floor Shadow */}
            <ellipse cx="80" cy="148" rx="46" ry="8" fill="rgba(239,68,68,0.22)" />

            {/* Floating Cyber Wings / Shoulder Pauldrons */}
            <polygon
              points="18,52 48,38 52,78 24,88"
              fill="url(#bossArmorGrad)"
              stroke={bossHitDamage ? "#14F1E1" : "#EF4444"}
              strokeWidth="2"
            />
            <polygon
              points="142,52 112,38 108,78 136,88"
              fill="url(#bossArmorGrad)"
              stroke={bossHitDamage ? "#14F1E1" : "#EF4444"}
              strokeWidth="2"
            />

            {/* Armored Mech Torso Chassis */}
            <polygon
              points="46,44 114,44 102,116 58,116"
              fill="url(#bossArmorGrad)"
              stroke="#F87171"
              strokeWidth="2.2"
            />

            {/* Glowing Chest Singularity Reactor */}
            <circle cx="80" cy="78" r="18" fill="url(#bossCoreGrad)" />
            <polygon
              points="80,62 94,78 80,94 66,78"
              fill={bossHitDamage ? "#14F1E1" : "#FF2A5F"}
              stroke="#FFF"
              strokeWidth="1.5"
            />

            {/* Cyber-Titan Horned Helmet / Head */}
            <polygon
              points="56,22 66,38 94,38 104,22 98,48 62,48"
              fill="#111827"
              stroke="#EF4444"
              strokeWidth="2"
            />
            {/* Glowing Visor Eyes */}
            <polygon points="66,36 77,39 68,42" fill={bossHitDamage ? "#14F1E1" : "#FFBE0B"} />
            <polygon points="94,36 83,39 92,42" fill={bossHitDamage ? "#14F1E1" : "#FFBE0B"} />

            {/* Energy Claws / Gauntlets */}
            <polygon points="22,94 42,90 38,118 18,112" fill="#1F2937" stroke="#F97316" strokeWidth="1.6" />
            <polygon points="138,94 118,90 122,118 142,112" fill="#1F2937" stroke="#F97316" strokeWidth="1.6" />
          </motion.svg>
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-red-500/15 border border-red-500/40 text-red-400 text-[9px] font-mono font-black uppercase tracking-widest mb-1">
          <Sword className="w-3 h-3" />{" "}
          {bossCurrentHP < bossMaxHP * 0.35
            ? "CRITICAL ENRAGED PHASE 🔥"
            : bossCurrentHP < bossMaxHP * 0.75
            ? "ARMOR CRACKED • KEEP STRIKING"
            : "3D RAID BOSS ENGAGED"}
        </div>

        <h2 className="text-2xl font-black uppercase tracking-tight text-white relative z-10">
          BOSS: {bossName}
        </h2>
        <p className="text-[11px] text-neutral-400 mt-0.5 max-w-xs">
          Every rep you log deals direct kinetic damage to {bossName}&apos;s core!
        </p>

        <div className="w-full mt-4 relative z-10 bg-black/60 p-4 rounded-2xl border border-red-500/30 shadow-inner">
          <div className="flex justify-between items-end mb-2">
            <span className="text-red-400 text-xs font-black uppercase tracking-widest flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 animate-pulse" /> Boss Core HP
            </span>
            <span className="text-white font-black font-mono text-lg leading-none">
              {bossCurrentHP}{" "}
              <span className="text-neutral-500 text-xs">/ {bossMaxHP} HP</span>
            </span>
          </div>
          <div className="h-4 w-full bg-[#050B1A] rounded-full overflow-hidden relative border border-red-500/30 p-0.5">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-red-700 via-red-500 to-amber-400 shadow-[0_0_15px_rgba(239,68,68,0.8)]"
              initial={{ width: "100%" }}
              animate={{ width: `${(bossCurrentHP / bossMaxHP) * 100}%` }}
              transition={{ duration: 0.35 }}
            />
          </div>
        </div>
      </motion.div>

      {/* TOTAL PROGRESS CARD */}
      <div className="flex items-center gap-6 bg-white/5 border border-white/10 rounded-2xl p-6 shadow-lg">
        <div className="relative w-24 h-24 flex-shrink-0">
          <svg
            className="w-full h-full transform -rotate-90"
            viewBox="0 0 160 160"
          >
            <circle
              cx="80"
              cy="80"
              r={radius}
              stroke="currentColor"
              strokeWidth="12"
              fill="transparent"
              className="text-white/5"
            />
            <motion.circle
              cx="80"
              cy="80"
              r={radius}
              stroke="currentColor"
              strokeWidth="12"
              fill="transparent"
              strokeDasharray={circumference}
              animate={{ strokeDashoffset }}
              transition={{ duration: 0.5 }}
              className="text-[#14F1E1] drop-shadow-[0_0_12px_rgba(20,241,225,0.6)]"
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center flex-col">
            <span className="text-[#14F1E1] font-black text-2xl leading-none">
              {Math.round(progressPercent)}%
            </span>
          </div>
        </div>
        <div className="flex-1 space-y-3">
          <div>
            <h3 className="text-white font-black uppercase tracking-widest text-sm">
              Total Progress
            </h3>
            <p className="text-[#14F1E1] text-xs font-bold uppercase tracking-widest mt-1">
              {totalCompletedReps} / {totalTargetReps} Reps
            </p>
          </div>
          <div className="grid grid-cols-2 gap-2 text-left">
            <div className="bg-black/30 rounded p-2 border border-white/5">
              <p className="text-neutral-500 text-[9px] uppercase font-bold tracking-widest mb-1">
                Remaining
              </p>
              <p className="text-white text-xs font-black">{remainingReps}</p>
            </div>
            <div className="bg-black/30 rounded p-2 border border-white/5">
              <p className="text-neutral-500 text-[9px] uppercase font-bold tracking-widest mb-1">
                Time Elapsed
              </p>
              <p className="text-white text-xs font-mono font-black">
                {formatElapsed(elapsedTime)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* EXERCISES BREAKDOWN */}
      <div className="space-y-4 mt-8">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <h3 className="text-white font-black text-sm uppercase tracking-widest flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#14F1E1]" /> Exercise Breakdown
          </h3>
          <button
            onClick={() => setShowEditModal(true)}
            className="text-[10px] font-black uppercase tracking-wider text-[#14F1E1] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> Add / Edit Exercises
          </button>
        </div>

        {challenge.exercises.map((ex, index) => {
          const isDone = ex.completedReps >= ex.targetReps;
          const progress = Math.min(
            100,
            (ex.completedReps / Math.max(1, ex.targetReps)) * 100
          );
          const lowerName = ex.name.toLowerCase();
          const supportsAiCamera =
            lowerName.includes("pushup") ||
            lowerName.includes("push up") ||
            lowerName.includes("push-up") ||
            lowerName.includes("squat");

          return (
            <div
              key={index}
              className={`bg-[#050B1A] border rounded-2xl p-5 relative overflow-hidden transition-all shadow-lg ${
                isDone
                  ? "border-[#14F1E1]/50 shadow-[0_0_20px_rgba(20,241,225,0.15)]"
                  : "border-white/10"
              }`}
            >
              <div
                className="absolute left-0 top-0 bottom-0 bg-[#14F1E1]/10 transition-all duration-300 ease-out"
                style={{ width: `${progress}%` }}
              />
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center flex-shrink-0">
                      <Target className="w-5 h-5 text-[#14F1E1]" />
                    </div>
                    <div>
                      <h3 className="font-black text-white text-base uppercase tracking-tight leading-tight">
                        {ex.name}
                      </h3>
                      <p className="text-neutral-400 font-bold text-xs mt-1 tracking-widest uppercase">
                        {ex.completedReps} / {ex.targetReps} Reps
                      </p>
                    </div>
                  </div>
                  {isDone && (
                    <div className="bg-[#14F1E1]/20 border border-[#14F1E1]/40 text-[#14F1E1] text-[10px] font-black px-2 py-1 rounded uppercase tracking-widest flex items-center gap-1 shadow-[0_0_10px_rgba(20,241,225,0.3)]">
                      <CheckCircle2 className="w-3 h-3" /> Done
                    </div>
                  )}
                </div>

                {/* Live 3D Cyber-Anatomical Character Loop for this Exercise */}
                <div className="mb-4">
                  <Exercise3DCharacterLoop
                    name={ex.name}
                    muscles={challenge.muscles || [primaryMuscle]}
                    compact={true}
                    interactive={true}
                    onTempoRepCompleted={() => handleAddReps(index, 1)}
                  />
                </div>

                <div className="w-full h-1.5 bg-black/50 rounded-full mb-4 overflow-hidden">
                  <motion.div
                    className="h-full bg-[#14F1E1]"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>

                {!isDone && (
                  <div className="space-y-2.5">
                    {/* Always show manual +1, +5, +10, +15, Done buttons */}
                    <div className="grid grid-cols-5 gap-2">
                      <button
                        type="button"
                        onClick={() => handleAddReps(index, 1)}
                        className="bg-white/10 hover:bg-white/20 text-white font-black text-xs py-3 rounded-lg active:scale-95 transition cursor-pointer"
                      >
                        +1
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAddReps(index, 5)}
                        className="bg-white/10 hover:bg-white/20 text-white font-black text-xs py-3 rounded-lg active:scale-95 transition cursor-pointer"
                      >
                        +5
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAddReps(index, 10)}
                        className="bg-white/10 hover:bg-white/20 text-white font-black text-xs py-3 rounded-lg active:scale-95 transition cursor-pointer"
                      >
                        +10
                      </button>
                      <button
                        type="button"
                        onClick={() => handleAddReps(index, 15)}
                        className="bg-white/10 hover:bg-white/20 text-white font-black text-xs py-3 rounded-lg active:scale-95 transition cursor-pointer"
                      >
                        +15
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          handleAddReps(
                            index,
                            Math.max(1, ex.targetReps - ex.completedReps)
                          )
                        }
                        className="bg-[#14F1E1]/20 hover:bg-[#14F1E1]/30 border border-[#14F1E1]/40 text-[#14F1E1] font-black text-[10px] uppercase py-3 rounded-lg active:scale-95 transition cursor-pointer"
                      >
                        Max
                      </button>
                    </div>

                    {supportsAiCamera && (
                      <motion.button
                        type="button"
                        whileTap={{ scale: 0.97 }}
                        onClick={() => {
                          setAiExerciseIndex(index);
                          setShowAiCounter(true);
                        }}
                        className="w-full bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-xs py-3 rounded-xl flex justify-center items-center gap-2 shadow-[0_0_15px_rgba(20,241,225,0.3)] transition-all uppercase tracking-widest cursor-pointer"
                      >
                        <Camera className="w-4 h-4" />
                        AI Camera Rep Tracker
                      </motion.button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* EDIT CUSTOM WORKOUT MODAL */}
      <AnimatePresence>
        {showEditModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.92 }}
              className="bg-[#080E24] border border-[#14F1E1]/30 rounded-3xl p-5 w-full max-w-md space-y-4 max-h-[85vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h3 className="text-white font-black uppercase tracking-wider text-sm flex items-center gap-2">
                  <Edit2 className="w-4 h-4 text-[#14F1E1]" /> Edit Custom Workout
                </h3>
                <button
                  onClick={() => setShowEditModal(false)}
                  className="p-1.5 rounded-lg bg-white/10 text-neutral-300 hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Existing Exercises List */}
              <div className="space-y-2.5">
                {challenge.exercises.map((ex, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between gap-2 bg-white/5 border border-white/10 rounded-xl p-3"
                  >
                    <span className="text-xs font-bold text-white flex-1 truncate">
                      {ex.name}
                    </span>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min={5}
                        max={500}
                        value={ex.targetReps}
                        onChange={(e) =>
                          handleUpdateTargetReps(
                            idx,
                            parseInt(e.target.value, 10) || 10
                          )
                        }
                        className="w-16 bg-black/50 border border-white/15 rounded-lg px-2 py-1 text-white font-mono text-xs text-center font-bold"
                      />
                      <span className="text-[10px] text-neutral-400 font-bold uppercase">
                        Reps
                      </span>
                      {challenge.exercises.length > 1 && (
                        <button
                          onClick={() => handleRemoveExercise(idx)}
                          className="p-1.5 rounded-lg bg-red-500/15 text-red-400 hover:bg-red-500/25 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Add New Exercise Row */}
              <div className="bg-black/40 border border-white/10 rounded-2xl p-3.5 space-y-2.5">
                <span className="text-[10px] font-black uppercase tracking-wider text-[#14F1E1] block">
                  + Add Custom Exercise
                </span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Exercise name (e.g. Pull Ups)"
                    value={newExName}
                    onChange={(e) => setNewExName(e.target.value)}
                    className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#14F1E1]"
                  />
                  <input
                    type="number"
                    placeholder="Reps"
                    value={newExReps}
                    onChange={(e) => setNewExReps(e.target.value)}
                    className="w-20 bg-white/5 border border-white/10 rounded-xl px-2.5 py-2 text-xs font-mono text-white text-center focus:outline-none focus:border-[#14F1E1]"
                  />
                </div>
                <button
                  onClick={handleAddCustomExercise}
                  className="w-full py-2.5 rounded-xl bg-[#14F1E1]/20 hover:bg-[#14F1E1]/30 border border-[#14F1E1]/40 text-[#14F1E1] text-xs font-black uppercase tracking-wider cursor-pointer"
                >
                  + Add Exercise to Mission
                </button>
              </div>

              <button
                onClick={() => setShowEditModal(false)}
                className="w-full py-3 rounded-xl bg-[#14F1E1] text-[#050B1A] font-black text-xs uppercase tracking-widest cursor-pointer"
              >
                Save & Continue Workout
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {showAiCounter && (
        <AiRepCounter
          initialExercise={
            challenge.exercises[aiExerciseIndex]?.name
              .toLowerCase()
              .includes("squat")
              ? "Squats"
              : "Pushups"
          }
          onClose={() => setShowAiCounter(false)}
          onComplete={(reps) => {
            if (reps > 0) {
              handleAddReps(aiExerciseIndex, reps, true);
            }
            setShowAiCounter(false);
          }}
        />
      )}
    </div>
  );
}
