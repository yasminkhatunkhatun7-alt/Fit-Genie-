import React, { useState } from "react";
import { CompletedSession } from "../types";
import { Award, Flame, Zap, Shield, CheckCircle2, Lock, Star, Trophy, Clock, Sunrise, Moon, Heart } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { playSound } from "../utils/audio";

interface BadgesProps {
  history: CompletedSession[];
  streakCount: number;
}

export interface Badge {
  id: string;
  title_en: string;
  title_hi: string;
  description: string;
  desiPraise: string;
  icon: string | React.ReactNode;
  iconBg: string;
  borderColor: string;
  glowColor: string;
  reqDesc: string;
  isUnlocked: boolean;
  currentValue: number;
  targetValue: number;
  metricLabel: string;
}

export default function Badges({ history, streakCount }: BadgesProps) {
  const [filter, setFilter] = useState<"all" | "unlocked" | "locked">("all");
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);

  // Computations
  const totalWorkouts = history.length;
  const totalMinutes = history.reduce((sum, s) => sum + s.totalDurationMin, 0);
  const fiveStarWorkouts = history.filter((s) => s.rating === 5).length;

  // Calculate longest consecutive streak in history dynamically based on unique dates
  const calculateLongestStreak = (sessions: CompletedSession[]): number => {
    if (sessions.length === 0) return 0;
    
    // Sort oldest first and map to unique YYYY-MM-DD
    const uniqueDates = Array.from(
      new Set(
        sessions.map((s) => {
          const dateObj = new Date(s.date);
          return `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, "0")}-${String(dateObj.getDate()).padStart(2, "0")}`;
        })
      )
    ).sort((a, b) => new Date(a).getTime() - new Date(b).getTime());

    if (uniqueDates.length === 0) return 0;

    let maxStreak = 1;
    let currentStreak = 1;

    for (let i = 1; i < uniqueDates.length; i++) {
      const prev = new Date(uniqueDates[i - 1]);
      const curr = new Date(uniqueDates[i]);
      
      // Calculate diff in days
      const diffTime = Math.abs(curr.getTime() - prev.getTime());
      const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays === 1) {
        currentStreak++;
        if (currentStreak > maxStreak) {
          maxStreak = currentStreak;
        }
      } else if (diffDays > 1) {
        currentStreak = 1;
      }
    }
    return maxStreak;
  };

  const bestStreak = Math.max(streakCount, calculateLongestStreak(history));

  // Time-based checks (Early bird: before 8 AM)
  const hasEarlyMorningWorkout = history.some((s) => {
    const hours = new Date(s.date).getHours();
    return hours >= 4 && hours < 8; // between 4:00 AM and 7:59 AM
  });

  const hasLateNightWorkout = history.some((s) => {
    const hours = new Date(s.date).getHours();
    return hours >= 20 || (hours >= 0 && hours < 3); // after 8:00 PM or before 3:00 AM
  });

  // Master Badge Definitions
  const rawBadges: Badge[] = [
    {
      id: "pehla_kadam",
      title_en: "Pehla Kadam",
      title_hi: "पहला कदम",
      description: "Log your very first workout session in the diary.",
      desiPraise: "Arre wah bhai! Shuruat sabse mushkil hoti hai, aur tumne wo kar dikhaya. Ab piche mudke mat dekhna, bas aage badhte raho! Loha pighla ke dum lenge!",
      icon: <Award className="w-6 h-6 text-emerald-400" />,
      iconBg: "bg-emerald-500/10",
      borderColor: "border-emerald-500/30",
      glowColor: "shadow-emerald-500/20",
      reqDesc: "Complete 1 workout session",
      isUnlocked: totalWorkouts >= 1,
      currentValue: totalWorkouts,
      targetValue: 1,
      metricLabel: "Session logged"
    },
    {
      id: "consistency_warrior",
      title_en: "Consistency Warrior",
      title_hi: "कंसिस्टेंसी वारियर",
      description: "Maintain a consecutive training streak of 3 days or more.",
      desiPraise: "Bawaal macha diye ho! 3 din lagatar mehnat matlab tum mazaak nahi kar rahe ho. Tumhara commitment dekh ke body bhi bol rahi hai: 'Shukriya bhai, fit rakhne ke liye!'",
      icon: <Flame className="w-6 h-6 text-orange-400 fill-orange-400/20" />,
      iconBg: "bg-orange-500/10",
      borderColor: "border-orange-500/30",
      glowColor: "shadow-orange-500/20",
      reqDesc: "Reach a 3-day active streak",
      isUnlocked: bestStreak >= 3,
      currentValue: bestStreak,
      targetValue: 3,
      metricLabel: "Day streak"
    },
    {
      id: "consistency_king",
      title_en: "Consistency King",
      title_hi: "कंसिस्टेंसी किंग",
      description: "Keep the grind active for a solid consecutive streak of 7 days.",
      desiPraise: "Pure ek hafte ka continuous grind! 7 din bina ruke loha ghisne ka matlab hai tumhare andar ek saccha pehelwan jag chuka hai bhai. Shabaash!",
      icon: <Zap className="w-6 h-6 text-red-400 fill-red-400/20 animate-pulse" />,
      iconBg: "bg-red-500/10",
      borderColor: "border-red-500/30",
      glowColor: "shadow-red-500/25",
      reqDesc: "Reach a 7-day training streak",
      isUnlocked: bestStreak >= 7,
      currentValue: bestStreak,
      targetValue: 7,
      metricLabel: "Day streak"
    },
    {
      id: "shaktiman",
      title_en: "Loha (Iron Body)",
      title_hi: "लोहा",
      description: "Build robust habits by completing a total of 5 workout sessions.",
      desiPraise: "5 Sessions complete! Ab tum beginner nahi rahe bhai, muscles mature ho rahi hain. Soaked chana aur paneer chalu rakho, asli taqat yahin se aayegi!",
      icon: <Shield className="w-6 h-6 text-sky-400" />,
      iconBg: "bg-sky-500/10",
      borderColor: "border-sky-500/30",
      glowColor: "shadow-sky-500/20",
      reqDesc: "Complete 5 total workouts",
      isUnlocked: totalWorkouts >= 5,
      currentValue: totalWorkouts,
      targetValue: 5,
      metricLabel: "Workouts"
    },
    {
      id: "first_50_workouts",
      title_en: "Akhara Legend (50 Workouts)",
      title_hi: "अखाड़ा लेजेंड",
      description: "Tear through 50 training sessions in total as a seasoned veteran.",
      desiPraise: "50 workouts complete! Bhai tumne toh poora akhara hila ke rakh diya! Ye koi aam baat nahi hai, tum hardcore category me aa chuke ho. Loha ras ban chuka hai tumhare andar!",
      icon: <Trophy className="w-6 h-6 text-indigo-400 fill-indigo-400/20" />,
      iconBg: "bg-indigo-500/10",
      borderColor: "border-indigo-500/30",
      glowColor: "shadow-indigo-500/25",
      reqDesc: "Complete 50 total workouts",
      isUnlocked: totalWorkouts >= 50,
      currentValue: totalWorkouts,
      targetValue: 50,
      metricLabel: "Workouts"
    },
    {
      id: "early_bird",
      title_en: "Subah ka Veer",
      title_hi: "सुबह का वीर",
      description: "Log your training session early in the morning before 8:00 AM.",
      desiPraise: "Suraj ugne se pehle dumbbells utha liye? Tum toh sach me kismat badalne nikle ho! Subah ka training focus level 100x kar deta hai, shabaash mere Sher!",
      icon: <Sunrise className="w-6 h-6 text-amber-400" />,
      iconBg: "bg-amber-500/10",
      borderColor: "border-amber-500/30",
      glowColor: "shadow-amber-500/20",
      reqDesc: "Workout logged before 8:00 AM",
      isUnlocked: hasEarlyMorningWorkout,
      currentValue: hasEarlyMorningWorkout ? 1 : 0,
      targetValue: 1,
      metricLabel: "Morning workout"
    },
    {
      id: "night_warrior",
      title_en: "Raat ka Yodha",
      title_hi: "रात का योद्धा",
      description: "Keep the grind active late at night after 8:00 PM.",
      desiPraise: "Raat ko jab duniya so rahi hai, tum sweat drop kar rahe ho! Is bheed me aage nikalne ka yahi tareeqa hai. Is discipline ko salaam hai bhai, tum sach me yodha ho!",
      icon: <Moon className="w-6 h-6 text-purple-400" />,
      iconBg: "bg-purple-500/10",
      borderColor: "border-purple-500/30",
      glowColor: "shadow-purple-500/20",
      reqDesc: "Workout logged after 8:00 PM",
      isUnlocked: hasLateNightWorkout,
      currentValue: hasLateNightWorkout ? 1 : 0,
      targetValue: 1,
      metricLabel: "Late night workout"
    },
    {
      id: "fivestar_champ",
      title_en: "Sona (Golden Form)",
      title_hi: "सोना",
      description: "Complete 3 distinct training sessions with a perfect 5/5 rating.",
      desiPraise: "3 workouts me absolute perfect form aur intensity! Jab tum dil se feedback dete ho 5-star, toh samajh lo body me blood circulation aur nitrogen load peak level pe hai!",
      icon: <Star className="w-6 h-6 text-yellow-400 fill-yellow-400/20" />,
      iconBg: "bg-yellow-500/10",
      borderColor: "border-yellow-500/30",
      glowColor: "shadow-yellow-500/25",
      reqDesc: "Log 3 perfect 5-star workouts",
      isUnlocked: fiveStarWorkouts >= 3,
      currentValue: fiveStarWorkouts,
      targetValue: 3,
      metricLabel: "5-Star sessions"
    },
    {
      id: "mahavir",
      title_en: "Mahavir Endurance",
      title_hi: "महावीर",
      description: "Log aggregate workout durations exceeding 120 total minutes.",
      desiPraise: "120+ minutes of pure sweat, cardiac endurance & core stability. Tumhara stamina dekh ke lagta hai tum lambi race ke ghode ho bhai. Keep hydrating and keep tearing boundaries!",
      icon: <Trophy className="w-6 h-6 text-rose-400" />,
      iconBg: "bg-rose-500/10",
      borderColor: "border-rose-500/30",
      glowColor: "shadow-rose-500/20",
      reqDesc: "Accumulate 120 minutes of training",
      isUnlocked: totalMinutes >= 120,
      currentValue: totalMinutes,
      targetValue: 120,
      metricLabel: "Total minutes"
    }
  ];

  const badges = rawBadges.filter((b) => {
    if (filter === "unlocked") return b.isUnlocked;
    if (filter === "locked") return !b.isUnlocked;
    return true;
  });

  const unlockedCount = rawBadges.filter((b) => b.isUnlocked).length;
  const totalCount = rawBadges.length;
  const unlockPercentage = Math.round((unlockedCount / totalCount) * 100);

  const handleBadgeClick = (badge: Badge) => {
    if (badge.isUnlocked) {
      playSound("success");
    } else {
      playSound("click");
    }
    setSelectedBadge(badge);
  };

  return (
    <div className="bg-brand-surface border border-brand-border rounded-3xl p-5 md:p-6 space-y-6 relative overflow-hidden" id="badges-container-card">
      <div className="absolute top-0 right-0 w-32 h-32 bg-brand-accent/5 rounded-full blur-3xl pointer-events-none" />

      {/* Hero Badge Header Metrics */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-5 border-b border-brand-border/40 pb-5">
        <div className="space-y-1 text-center sm:text-left">
          <h3 className="text-sm font-black uppercase text-brand-accent tracking-widest flex items-center justify-center sm:justify-start gap-1.5 font-mono">
            <Trophy className="w-4 h-4 text-brand-accent animate-bounce" />
            <span>Akhara Badges & Achievements</span>
          </h3>
          <p className="text-[10px] text-brand-muted uppercase">
            Unlock premium titles and showcase your genuine dedication
          </p>
        </div>

        {/* Global Progress Indicator */}
        <div className="flex items-center gap-3 bg-[#111] px-4 py-2 rounded-2xl border border-brand-border">
          <div className="text-right">
            <div className="text-xs font-black text-white">{unlockedCount} / {totalCount}</div>
            <div className="text-[8px] text-brand-muted uppercase font-black tracking-wider">Badges Unlocked</div>
          </div>
          <div className="w-16 h-1.5 bg-neutral-800 rounded-full overflow-hidden relative">
            <motion.div 
              className="h-full bg-brand-accent"
              initial={{ width: 0 }}
              animate={{ width: `${unlockPercentage}%` }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            />
          </div>
          <div className="text-xs font-mono font-black text-brand-accent">{unlockPercentage}%</div>
        </div>
      </div>

      {/* FILTER TABS */}
      <div className="flex bg-[#111111] p-1 rounded-xl border border-brand-border max-w-xs shrink-0" id="badge-sorting-tabs">
        {(["all", "unlocked", "locked"] as const).map((opt) => (
          <button
            key={opt}
            onClick={() => {
              playSound("click");
              setFilter(opt);
            }}
            className={`flex-1 py-1 px-1.5 text-center text-[9px] uppercase font-black tracking-wider rounded-lg transition-all cursor-pointer ${
              filter === opt
                ? "bg-brand-accent text-brand-bg font-black shadow-[0_0_8px_rgba(201,243,29,0.15)]"
                : "text-brand-muted hover:text-white"
            }`}
            id={`tab-badges-filter-${opt}`}
          >
            {opt === "all" ? "🔥 All" : opt === "unlocked" ? "🟢 Earned" : "🔒 Locked"}
          </button>
        ))}
      </div>

      {/* BADGES DISPLAY GRID */}
      {badges.length === 0 ? (
        <div className="text-center py-8 bg-[#111] rounded-2xl border border-dashed border-brand-border/60">
          <p className="text-[10px] text-brand-muted uppercase font-black">Koi badges nahi mile is category me bhai!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" id="badges-grid-layout">
          {badges.map((badge) => {
            const progressRatio = Math.min(badge.currentValue / badge.targetValue, 1);
            const progressPercent = Math.round(progressRatio * 100);

            return (
              <motion.div
                key={badge.id}
                whileHover={{ scale: 1.015 }}
                onClick={() => handleBadgeClick(badge)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between h-[120px] ${
                  badge.isUnlocked
                    ? `bg-[#131711] ${badge.borderColor} shadow-[0_0_15px_rgba(0,0,0,0.4)] hover:${badge.glowColor}`
                    : "bg-brand-primary/20 border-brand-border/40 opacity-70 hover:opacity-100"
                }`}
                id={`badge-card-${badge.id}`}
              >
                {/* Highlight Glow bar for Unlocked Badges */}
                {badge.isUnlocked && (
                  <div className="absolute top-0 left-0 w-1.5 h-full bg-brand-accent" />
                )}

                <div className="flex items-start gap-3">
                  {/* Icon Circle */}
                  <div className={`w-10 h-10 rounded-xl shrink-0 flex items-center justify-center border relative ${
                    badge.isUnlocked 
                      ? `${badge.iconBg} ${badge.borderColor}` 
                      : "bg-[#111] border-neutral-800"
                  }`}>
                    {badge.isUnlocked ? (
                      badge.icon
                    ) : (
                      <Lock className="w-4 h-4 text-neutral-600" />
                    )}

                    {/* Checkmark overlay for Unlocked Badge */}
                    {badge.isUnlocked && (
                      <span className="absolute -bottom-1 -right-1 bg-brand-accent text-brand-bg rounded-full p-0.5 border border-brand-bg">
                        <CheckCircle2 className="w-2.5 h-2.5 text-brand-bg fill-brand-bg" />
                      </span>
                    )}
                  </div>

                  {/* Text Description */}
                  <div className="space-y-0.5 overflow-hidden">
                    <div className="flex items-center gap-1.5">
                      <h4 className={`text-xs font-black uppercase truncate ${badge.isUnlocked ? "text-white" : "text-neutral-400"}`}>
                        {badge.title_en}
                      </h4>
                      <span className="text-[9px] text-brand-accent font-black tracking-wider uppercase opacity-85 shrink-0 hidden xs:inline">
                        ({badge.title_hi})
                      </span>
                    </div>
                    <p className="text-[9px] text-brand-muted tracking-tight leading-snug line-clamp-2">
                      {badge.description}
                    </p>
                  </div>
                </div>

                {/* Progress Mini Bar & Requirement Label */}
                <div className="space-y-1 mt-2">
                  <div className="flex justify-between items-center text-[8px] font-mono font-bold">
                    <span className="text-brand-muted uppercase line-clamp-2 break-words" title={badge.reqDesc}>
                      🎯 {badge.reqDesc}
                    </span>
                    <span className={badge.isUnlocked ? "text-brand-accent font-black" : "text-neutral-500 font-black"}>
                      {badge.currentValue}/{badge.targetValue} {badge.metricLabel}
                    </span>
                  </div>
                  
                  {/* Tiny progress fill track */}
                  <div className="w-full h-1 bg-neutral-900 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${badge.isUnlocked ? "bg-brand-accent" : "bg-neutral-700"}`} 
                      style={{ width: `${progressPercent}%` }} 
                    />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Dynamic Intensity Levels Overview */}
      <div className="border-t border-brand-border/40 pt-6 space-y-4">
        <div>
          <h4 className="text-sm font-black uppercase text-brand-accent tracking-widest flex items-center gap-1.5 font-mono">
            <Zap className="w-4 h-4 text-brand-accent animate-pulse" />
            <span>Workout Intensity Badges System</span>
          </h4>
          <p className="text-[10px] text-brand-muted uppercase">
            Auto-assigned to daily log cards based on total duration and active count
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            {
              label: "Iron Titan",
              emoji: "🏋️‍♂️",
              style: "text-amber-400 border-amber-500/20 bg-amber-500/10",
              desc: "Duration ≥ 60m OR Exercises ≥ 6. Elite muscle hypertrophy workload.",
            },
            {
              label: "Beast Mode",
              emoji: "💪",
              style: "text-red-400 border-red-500/20 bg-red-500/10",
              desc: "Duration ≥ 40m OR Exercises ≥ 4. High-intensity power lifting.",
            },
            {
              label: "Steady Pacer",
              emoji: "🏃‍♂️",
              style: "text-cyan-400 border-cyan-500/20 bg-cyan-500/10",
              desc: "Duration ≥ 20m. Perfect calorie burning and cardiac conditioning.",
            },
            {
              label: "Quick Burn",
              emoji: "⚡",
              style: "text-yellow-400 border-yellow-500/20 bg-yellow-500/10",
              desc: "Duration < 20m & > 0m. Short, high-velocity fat loss trigger.",
            }
          ].map((tier) => (
            <div key={tier.label} className="p-3.5 rounded-2xl border bg-black/45 border-brand-border/40 flex flex-col gap-2 transition-all hover:border-brand-accent/20">
              <div className="flex items-center gap-1.5 font-black uppercase tracking-wider text-[10px]">
                <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[8.5px] ${tier.style}`}>
                  <span>{tier.emoji}</span>
                  <span>{tier.label}</span>
                </span>
              </div>
              <p className="text-[10px] text-zinc-400 leading-relaxed font-semibold">
                {tier.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* BADGE CONGRATS/DETAIL OVERLAY MODAL */}
      <AnimatePresence>
        {selectedBadge && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm"
            onClick={() => setSelectedBadge(null)}
            id="badge-detail-modal-backdrop"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className={`border bg-brand-surface p-6 rounded-3xl max-w-md w-full relative space-y-6 text-center overflow-hidden shadow-2xl ${
                selectedBadge.isUnlocked ? "border-brand-accent/40" : "border-brand-border"
              }`}
              id="badge-detail-modal-content"
            >
              {/* Decorative light ring */}
              <div className="absolute -top-10 -left-10 w-40 h-40 bg-brand-accent/3 rounded-full blur-3xl pointer-events-none" />

              {/* Big Animated Badge Icon Circle */}
              <div className="relative inline-flex flex-col items-center">
                <motion.div
                  animate={selectedBadge.isUnlocked ? {
                    scale: [0.95, 1.05, 0.95],
                    rotate: [0, 5, -5, 0],
                  } : {}}
                  transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                  className={`w-20 h-20 rounded-2xl border-2 flex items-center justify-center shadow-lg relative ${
                    selectedBadge.isUnlocked 
                      ? `${selectedBadge.iconBg} ${selectedBadge.borderColor} ${selectedBadge.glowColor}` 
                      : "bg-[#111] border-neutral-800"
                  }`}
                >
                  {selectedBadge.isUnlocked ? (
                    <span className="scale-[1.8] block">{selectedBadge.icon}</span>
                  ) : (
                    <Lock className="w-8 h-8 text-neutral-600" />
                  )}
                </motion.div>

                {/* Subtitle Badge Ribbon Tag */}
                {selectedBadge.isUnlocked ? (
                  <span className="mt-3.5 bg-brand-accent text-brand-bg px-3.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest block font-mono">
                    UNLOCKED // EARNED
                  </span>
                ) : (
                  <span className="mt-3.5 bg-neutral-800 text-neutral-500 px-3 py-0.5 rounded-full text-[8.5px] font-black uppercase tracking-widest block font-mono">
                    LOCKED // ATTAINABLE
                  </span>
                )}
              </div>

              {/* Badge General Text */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-center gap-2">
                  <h3 className="text-xl font-black uppercase text-white tracking-widest">
                    {selectedBadge.title_en}
                  </h3>
                  <span className="text-xs text-brand-accent font-black tracking-widest uppercase bg-[#111] px-2 py-0.5 rounded border border-brand-accent/20">
                    {selectedBadge.title_hi}
                  </span>
                </div>
                <p className="text-[10px] text-brand-muted uppercase tracking-wider font-mono">
                  {selectedBadge.reqDesc}
                </p>
                <p className="text-[11px] text-neutral-300 px-4 leading-relaxed mt-2 uppercase">
                  {selectedBadge.description}
                </p>
              </div>

              {/* Dynamic Desi Bro Coach Dialogue Box */}
              <div className="bg-[#111] border border-brand-border/40 p-4 rounded-2xl relative text-left space-y-1.5">
                <div className="text-[8.5px] font-black uppercase tracking-widest text-brand-accent flex items-center gap-1.5 font-mono">
                  <span className="animate-pulse">📻</span>
                  <span>BHAI KI BADHAAI / ADVICE:</span>
                </div>
                {selectedBadge.isUnlocked ? (
                  <p className="text-xs text-neutral-300 leading-relaxed font-semibold">
                    "{selectedBadge.desiPraise}"
                  </p>
                ) : (
                  <p className="text-xs text-neutral-400 font-medium leading-relaxed italic">
                    "Abhi ye badge lock hai bhai! Isko pane ke liye mehnat karni padegi. Jab tum target reach karoge, tab ye golden portal khulega! Sone se pehle dhyan rakhna, no excuses!"
                  </p>
                )}
              </div>

              {/* Back Button */}
              <button
                onClick={() => {
                  playSound("click");
                  setSelectedBadge(null);
                }}
                className="w-full py-3 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg text-xs font-black uppercase tracking-widest rounded-xl transition cursor-pointer"
                id="btn-close-badge-modal"
              >
                {selectedBadge.isUnlocked ? "SABASH BHAI! 👍" : "THEEK HAI BHAI, MEHNAT CHALU!"}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
