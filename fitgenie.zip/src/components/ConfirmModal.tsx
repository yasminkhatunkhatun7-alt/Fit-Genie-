import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle } from 'lucide-react';

interface ConfirmModalProps {
  isOpen: boolean;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export function ConfirmModal({ isOpen, message, onConfirm, onCancel }: ConfirmModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-neutral-900 border border-neutral-800 p-6 rounded-3xl max-w-sm w-full text-center space-y-6 shadow-2xl">
            <div className="w-16 h-16 bg-orange-500/10 rounded-full mx-auto flex items-center justify-center text-orange-500 shadow-[0_0_20px_rgba(249,115,22,0.2)]">
              <AlertTriangle className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-black uppercase text-white tracking-widest">Sach me kiya?</h3>
            <p className="text-sm text-neutral-400 font-medium leading-relaxed">{message}</p>
            <div className="flex gap-3 pt-2">
              <button onClick={onCancel} className="flex-1 py-3.5 bg-neutral-800 text-white rounded-xl font-bold uppercase tracking-wider hover:bg-neutral-700 transition-all text-xs">
                Nahi
              </button>
              <button onClick={onConfirm} className="flex-1 py-3.5 bg-orange-500 text-white rounded-xl font-bold uppercase tracking-wider hover:bg-orange-600 shadow-[0_0_15px_rgba(249,115,22,0.4)] transition-all text-xs">
                Haan, Kiya Hai
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
