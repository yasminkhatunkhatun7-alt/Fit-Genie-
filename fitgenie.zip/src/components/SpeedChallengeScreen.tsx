import { useGenieIntelligence } from '../hooks/useGenieIntelligence';
import GeniePenaltyModal from './GeniePenaltyModal';
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Trophy, Target, ShieldAlert, Timer, Play, AlertTriangle, Zap, XCircle } from "lucide-react";
import { playSound } from "../utils/audio";
import CompletionValidationModal from "./CompletionValidationModal";
import { calculateExpectedMinimumTime } from "../utils/integrityEngine";
import { useAuth } from "../context/AuthContext";
import { getTodayDateString } from "../utils/dailyChallenge";
import { ActiveChallenge } from "./StrengthChallengeScreen";
import { AiRepCounter } from "./AiRepCounter";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";
import { Camera } from "lucide-react";

interface SpeedChallengeScreenProps {
  challenge: ActiveChallenge;
  onUpdate: (updated: ActiveChallenge) => void;
  onBack: () => void;
  onComplete: (xpToAward: number) => Promise<boolean> | boolean | void;
}

const TOTAL_TIME = 180; // 3 minutes

export default function SpeedChallengeScreen({ challenge, onUpdate, onBack, onComplete }: SpeedChallengeScreenProps) {
  const {
    cooldown,
    suspiciousPhase,
    lockEndTime,
    checkCheat,
    proceedFromAlert,
    proceedFromMotivation,
    submitApology,
    resetSessionTime
  } = useGenieIntelligence(challenge.id);
  const { profile } = useAuth();
  const [showCompletion, setShowCompletion] = useState(false);
  const [showHonorValidation, setShowHonorValidation] = useState(false);
  const [honorChecked, setHonorChecked] = useState(false);
  const [justClaimed, setJustClaimed] = useState(false);
  const [showAiCounter, setShowAiCounter] = useState(false);
  const [showFail, setShowFail] = useState(false);
  const [floatingTexts, setFloatingTexts] = useState<{ id: number, text: string, x: number }[]>([]);
  const [textCounter, setTextCounter] = useState(0);

  const todayStr = getTodayDateString();
  const progressKey = `speed_challenge_progress_${profile?.uid}`;
  const claimedKey = `speed_challenge_claimed_${profile?.uid}`;

  const [hasClaimedToday, setHasClaimedToday] = useState(false);

  // Challenge State
  const [isStarted, setIsStarted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(TOTAL_TIME);
  const [elapsedTime, setElapsedTime] = useState(0);
  
  // Anti-cheat State
  const [cooldown1, setCooldown1] = useState(0);
  const [cooldown10, setCooldown10] = useState(0);

  useEffect(() => {
    const claimedDate = localStorage.getItem(claimedKey);
    if (claimedDate === todayStr) {
      setHasClaimedToday(true);
    }
  }, []);

  const exercise = challenge.exercises[0] || { name: "Burpees", targetReps: 50, completedReps: 0 };
  const progressPercent = Math.min(100, Math.round((exercise.completedReps / exercise.targetReps) * 100));
  const isCompleted = progressPercent >= 100;

  const bossMaxHP = exercise.targetReps;
  const bossCurrentHP = Math.max(0, bossMaxHP - exercise.completedReps);

  // Timer logic
  useEffect(() => {
    let timerId: NodeJS.Timeout;
    if (isStarted && !isCompleted && !showFail) {
      timerId = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            setShowFail(true);
            playSound("countdown");
            return 0;
          }
          return prev - 1;
        });
        setElapsedTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timerId);
  }, [isStarted, isCompleted, showFail]);

  // Cooldown logic
  useEffect(() => {
    let cdTimer: NodeJS.Timeout;
    if (cooldown1 > 0 || cooldown10 > 0) {
      cdTimer = setInterval(() => {
        setCooldown1(prev => Math.max(0, prev - 1));
        setCooldown10(prev => Math.max(0, prev - 1));
      }, 1000);
    }
    return () => clearInterval(cdTimer);
  }, [cooldown1, cooldown10]);

  // Completion check
  useEffect(() => {
    if (isCompleted && !showCompletion && !showHonorValidation && !showFail && !hasClaimedToday) {
      const timer = setTimeout(() => setShowHonorValidation(true), 500);
      return () => clearTimeout(timer);
    }
  }, [isCompleted, showCompletion, showHonorValidation, showFail, hasClaimedToday]);

  const handleStart = () => {
    playSound("click");
    setIsStarted(true);
  };

  const handleAddReps = (amount: number, fromAI: boolean = false) => {
    if (isCompleted || showFail || timeLeft === 0) return;

    if (amount === 1 && cooldown > 0) return;
    if (amount === 10 && cooldown > 0) return;

    if (!fromAI && checkCheat(exercise.name, amount)) {
      const updated = { ...challenge };
      updated.exercises[0].completedReps = 0;
      onUpdate(updated);
      return;
    }

    const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);

    if (amount === 1) {
      setCooldown1(1); // 1 sec cooldown
    } else if (amount === 10) {
      setCooldown10(10); // 8 sec cooldown for 10 burpees (prevent spam)
    }

    playSound("timer_tick");
    
    const id = textCounter;
    setTextCounter(prev => prev + 1);
    setFloatingTexts(prev => [...prev, { id, text: `+${amount}`, x: Math.random() * 40 - 20 }]);
    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== id));
    }, 1000);

    const updated = { ...challenge };
    updated.exercises[0].completedReps = newCompleted;
    onUpdate(updated);
  };


  const handleFinish = () => {
    onBack();
  };

  const [showReviewModal, setShowReviewModal] = useState(false);

  const handleClaimXP = async () => {
    if (!honorChecked) return;
    setShowHonorValidation(false);
    await finalizeClaimXP();
  };

  const finalizeClaimXP = async () => {
    setShowReviewModal(false);
    playSound("success");
    if (!hasClaimedToday) {
      const result = await onComplete(challenge.xp);
      if (result === false) return; // Validation failed
      localStorage.setItem(claimedKey, todayStr);
      setHasClaimedToday(true);
      setJustClaimed(true);
    }
    setShowCompletion(true);
  };

  const handleRestart = () => {
    playSound("click");
    setShowFail(false);
    setTimeLeft(TOTAL_TIME);
    setElapsedTime(0);
    setIsStarted(true);
    const updated = { ...challenge };
    updated.exercises[0].completedReps = 0;
    onUpdate(updated);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const bpm = elapsedTime > 0 ? Math.round((exercise.completedReps / elapsedTime) * 60) : 0;
  const estFinishSecs = exercise.completedReps > 0 ? Math.round((exercise.targetReps / exercise.completedReps) * elapsedTime) : 0;

  if (suspiciousPhase !== 'none') {
    return (
      <GeniePenaltyModal 
        suspiciousPhase={suspiciousPhase as any}
        lockEndTime={lockEndTime}
        onProceedFromAlert={proceedFromAlert}
        onProceedFromMotivation={proceedFromMotivation}
        onSubmitApology={submitApology}
      />
    );
  }

  if (showReviewModal) {
    return (
      <CompletionValidationModal
        durationSeconds={elapsedTime}
        expectedSeconds={calculateExpectedMinimumTime(challenge.exercises)}
        exerciseName={challenge.exercises[0].name}
        targetReps={challenge.exercises[0].targetReps}
        onValid={finalizeClaimXP}
        onInvalid={() => {
            setShowReviewModal(false);
            handleRestart();
        }}
      />
    );
  }

  if (showHonorValidation) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/90 flex flex-col items-center justify-center p-6 backdrop-blur-sm">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-[#050B1A] border border-[#14F1E1]/30 shadow-[0_0_30px_rgba(20,241,225,0.15)] rounded-3xl p-6 text-center max-w-sm w-full relative"
        >
          <Trophy className="w-16 h-16 text-[#14F1E1] mx-auto mb-4" />
          <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-4">🏆 Challenge Complete</h2>
          <p className="text-neutral-300 text-sm mb-6 leading-relaxed">
            {exercise.targetReps} {exercise.name} Completed?<br/><br/>
            Please confirm that you completed this challenge honestly.<br/>
            Fit Genie trust system par kaam karta hai.<br/><br/>
            <span className="text-[#14F1E1] font-bold">Real effort = Real progress. 💪</span>
          </p>
          
          <label className="flex items-center gap-3 p-4 bg-white/5 border border-white/10 rounded-xl cursor-pointer mb-6 text-left hover:bg-white/10 transition-colors">
            <input 
              type="checkbox" 
              checked={honorChecked}
              onChange={(e) => setHonorChecked(e.target.checked)}
              className="w-5 h-5 accent-[#14F1E1] rounded border-white/20 bg-white/10"
            />
            <span className="text-sm font-bold text-white leading-tight">Yes, I completed these reps honestly.</span>
          </label>

          <button 
            onClick={handleClaimXP}
            disabled={!honorChecked}
            className={`w-full py-4 font-black text-sm uppercase tracking-widest rounded-xl transition-all ${honorChecked ? 'bg-[#14F1E1] text-[#050B1A] shadow-[0_0_20px_rgba(20,241,225,0.4)]' : 'bg-white/10 text-neutral-500 cursor-not-allowed'}`}
          >
            🎁 Claim XP
          </button>
        </motion.div>
      </div>
    );
  }

  if (showFail) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }} 
        animate={{ opacity: 1, scale: 1 }} 
        className="fixed inset-0 z-50 bg-[#050B1A] flex flex-col items-center justify-center p-6"
      >
        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center space-y-6 max-w-sm w-full relative z-10"
        >
          <div className="w-32 h-32 mx-auto bg-red-500/20 rounded-full flex items-center justify-center relative">
            <XCircle className="w-16 h-16 text-red-500 relative z-10" />
          </div>
          
          <div>
            <h1 className="text-4xl font-black uppercase text-white tracking-tight">❌ Mission Failed</h1>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-4">
            <div className="text-sm font-medium text-neutral-300 leading-relaxed">
              Time khatam ho gaya.<br/>Kal phir try karna.
            </div>
            <div className="flex justify-center items-center mt-4">
              <span className="text-red-400 font-black text-xl">0 XP</span>
            </div>
          </div>

          <div className="pt-4 space-y-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleRestart}
              className="w-full py-4 bg-[#14F1E1] text-[#050B1A] font-black text-sm uppercase tracking-widest rounded-xl transition-all"
            >
              Try Again
            </motion.button>
            <button
              onClick={() => { playSound("click"); onBack(); }}
              className="w-full py-4 bg-transparent border border-white/20 text-white font-black text-sm uppercase tracking-widest rounded-xl hover:bg-white/5 mt-4"
            >
              Return To Challenges
            </button>
          </div>
        </motion.div>
      </motion.div>
    );
  }

  if (showCompletion || (isCompleted && !isStarted)) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }} 
        animate={{ opacity: 1, scale: 1 }} 
        className="fixed inset-0 z-50 bg-[#050B1A] flex flex-col items-center justify-center p-6"
      >
        {/* Simple Confetti */}
        {justClaimed && Array.from({ length: 30 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: Math.random() * window.innerWidth, 
              y: -20, 
              opacity: 1,
              rotate: 0 
            }}
            animate={{ 
              y: window.innerHeight + 20,
              rotate: 360,
              opacity: 0
            }}
            transition={{ 
              duration: 2 + Math.random() * 2, 
              ease: "linear", 
              repeat: Infinity 
            }}
            className="absolute w-2 h-4 rounded-sm"
            style={{ 
              backgroundColor: ['#14F1E1', '#B66DFF', '#F97316', '#FFFFFF'][Math.floor(Math.random() * 4)],
              left: `${Math.random() * 95}%`
            }}
          />
        ))}

        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center space-y-6 max-w-sm w-full relative z-10"
        >
          <div className="w-32 h-32 mx-auto bg-cyan-500/20 rounded-full flex items-center justify-center relative">
            <div className="absolute inset-0 bg-[#14F1E1] rounded-full blur-xl opacity-40 animate-pulse" />
            <Zap className="w-16 h-16 text-[#14F1E1] relative z-10" />
          </div>
          
          <div>
            <h1 className="text-4xl font-black uppercase text-white tracking-tight leading-tight">🏆 SPEED DEMON DEFEATED</h1>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-4">
            {justClaimed ? (
              <>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-[#14F1E1] font-black text-xl">+{challenge.xp} XP</span>
                  <span className="text-[#14F1E1] font-black text-xl">+1 Victory</span>
                </div>
                <div className="text-sm font-medium text-neutral-300 mt-4 leading-relaxed">
                  🔥 Amazing Work Warrior!<br/><br/>
                  Challenge completed successfully.<br/><br/>
                  Kal naye mission ke saath wapas aana.<br/>
                </div>
              </>
            ) : (
              <div className="text-center">
                <span className="text-neutral-400 font-bold uppercase tracking-widest text-xs leading-relaxed">
                  Challenge completed again.<br/>Reward already claimed for today.
                </span>
              </div>
            )}
          </div>

          <div className="pt-4 space-y-4">
            <button
              onClick={() => {
                playSound("click");
                onBack();
              }}
              className="w-full py-4 bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-sm uppercase tracking-widest rounded-xl transition-all shadow-[0_0_20px_rgba(20,241,225,0.4)]"
            >
              Return To Challenges
            </button>
          </div>
        </motion.div>
      </motion.div>
    );
  }

  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen relative">
      {/* TOP HEADER */}
      <div className="flex items-center justify-between mb-2">
        <button onClick={() => { playSound("click"); onBack(); }} className="flex items-center gap-2 text-[#14F1E1]">
          <ChevronLeft className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs">Back</span>
        </button>
        <div className="flex flex-col items-end">
          <span className="text-[#14F1E1] font-black tracking-widest uppercase text-xs flex items-center gap-1">
            <Zap className="w-3 h-3" /> SPEED CHALLENGE
          </span>
        </div>
      </div>

      {/* TIMER & PACING */}
      <div className="text-center flex flex-col items-center">
        <motion.div 
          animate={{ scale: timeLeft <= 30 && isStarted ? [1, 1.05, 1] : 1 }}
          transition={{ repeat: Infinity, duration: 0.5 }}
          className={`text-6xl font-mono font-black tracking-tight ${timeLeft <= 30 ? 'text-red-500' : 'text-white'}`}
        >
          {formatTime(timeLeft)}
        </motion.div>
      </div>

      {/* APEX CYBER BOSS SHIELD TELEMETRY */}
      <div className="bg-gradient-to-br from-[#0A1428] via-[#070E1E] to-[#050B1A] border border-[#14F1E1]/40 rounded-2xl p-4 relative overflow-hidden shadow-[0_0_25px_rgba(20,241,225,0.12)]">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-[#14F1E1]/15 border border-[#14F1E1]/40 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(20,241,225,0.25)]">
              <Zap className="w-6 h-6 text-[#14F1E1] animate-pulse" />
            </div>
            <div className="text-left">
              <span className="text-[9px] font-mono font-black uppercase tracking-[0.2em] text-[#14F1E1] block">
                OVERDRIVE BOSS • 3 MIN BLITZ
              </span>
              <h2 className="text-lg font-black uppercase tracking-tight text-white">
                SPEED DEMON CORE
              </h2>
            </div>
          </div>
          <div className="text-right font-mono">
            <span className="text-xs font-black text-[#14F1E1] block">{bossCurrentHP} / {bossMaxHP} HP</span>
            <span className="text-[9px] text-neutral-400 uppercase font-bold">{100 - progressPercent}% SHIELD</span>
          </div>
        </div>
        <div className="h-3 w-full bg-black/70 rounded-full overflow-hidden relative border border-[#14F1E1]/30 mt-3 p-0.5">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-[#14F1E1] via-[#38bdf8] to-[#B66DFF] shadow-[0_0_12px_rgba(20,241,225,0.6)]"
            initial={{ width: '100%' }}
            animate={{ width: `${(bossCurrentHP / bossMaxHP) * 100}%` }}
            transition={{ duration: 0.2 }}
          />
        </div>
      </div>

      {/* LIVE 3D HOLOGRAM ATHLETE & PACER */}
      <div className="rounded-2xl overflow-hidden border border-[#14F1E1]/25 bg-[#050B1A] shadow-[0_0_25px_rgba(20,241,225,0.08)]">
        <Exercise3DCharacterLoop
          exerciseName={exercise.name}
          targetMuscles={["Full Body", "Core", "Legs", "Shoulders"]}
          difficulty="advanced"
          heightClass="h-[220px]"
          showControls={true}
        />
      </div>

      {/* COMPACT REP PROGRESS & SPEED TELEMETRY */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="bg-[#0B1226] border border-[#14F1E1]/30 rounded-xl p-3 flex flex-col items-center justify-center">
          <span className="text-white font-black font-mono text-xl">{exercise.completedReps}<span className="text-xs text-neutral-400">/{exercise.targetReps}</span></span>
          <span className="text-[#14F1E1] text-[9px] font-bold uppercase tracking-widest mt-1">Reps Done</span>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex flex-col items-center justify-center">
          <span className="text-[#14F1E1] font-black font-mono text-xl">{bpm}</span>
          <span className="text-neutral-400 text-[9px] font-bold uppercase tracking-widest mt-1">Reps / Min</span>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex flex-col items-center justify-center">
          <span className="text-white font-mono font-bold text-xl">{estFinishSecs > 0 ? formatTime(estFinishSecs) : '--:--'}</span>
          <span className="text-neutral-400 text-[9px] font-bold uppercase tracking-widest mt-1">Est. Finish</span>
        </div>
      </div>

      {/* CONTROLS */}
      <div className="mt-4">
        {!isStarted ? (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleStart}
            className="w-full py-5 bg-[#14F1E1] text-[#050B1A] rounded-2xl font-black text-lg uppercase tracking-widest flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(20,241,225,0.4)]"
          >
            <Play className="w-6 h-6 fill-current" />
            START CHALLENGE
          </motion.button>
        ) : (
          <div className="relative w-full space-y-3">
            <div className="grid grid-cols-4 gap-2.5 w-full">
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(1)} disabled={isCompleted || timeLeft === 0} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-4 rounded-2xl relative overflow-hidden cursor-pointer">+1</motion.button>
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(5)} disabled={isCompleted || timeLeft === 0} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-4 rounded-2xl relative overflow-hidden cursor-pointer">+5</motion.button>
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(10)} disabled={isCompleted || timeLeft === 0} className="bg-[#14F1E1]/10 hover:bg-[#14F1E1]/20 border border-[#14F1E1]/30 text-[#14F1E1] font-black text-lg py-4 rounded-2xl relative overflow-hidden cursor-pointer">+10</motion.button>
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(15)} disabled={isCompleted || timeLeft === 0} className="bg-[#14F1E1]/10 hover:bg-[#14F1E1]/20 border border-[#14F1E1]/30 text-[#14F1E1] font-black text-lg py-4 rounded-2xl relative overflow-hidden cursor-pointer">+15</motion.button>
            </div>
            {(exercise.name.toLowerCase().includes('pushup') || exercise.name.toLowerCase().includes('push up') || exercise.name.toLowerCase().includes('squat')) && (
              <motion.button 
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowAiCounter(true)}
                disabled={isCompleted || timeLeft === 0}
                className="w-full py-3.5 rounded-xl bg-[#14F1E1] text-[#050B1A] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(20,241,225,0.4)] hover:bg-white transition-all disabled:opacity-50 disabled:shadow-none cursor-pointer"
              >
                <Camera className="w-5 h-5" /> AI CAMERA REP TRACKER
              </motion.button>
            )}

            {/* FLOATING TEXTS */}
            <AnimatePresence>
              {floatingTexts.map((ft) => (
                <motion.div
                  key={ft.id}
                  initial={{ opacity: 1, y: 0, x: ft.x, scale: 1 }}
                  animate={{ opacity: 0, y: -50, scale: 1.5 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                  className="absolute pointer-events-none left-1/2 -translate-x-1/2 -top-10 text-white font-black text-2xl z-20"
                >
                  {ft.text}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>


      {showAiCounter && (
        <AiRepCounter
          initialExercise={exercise.name.toLowerCase().includes('squat') ? "Squats" : "Pushups"}
          onClose={() => setShowAiCounter(false)}
          onComplete={(reps) => {
            if (reps > 0) {
              handleAddReps(reps, true);
            }
            setShowAiCounter(false);
          }}
        />
      )}
    </div>
  );
}
