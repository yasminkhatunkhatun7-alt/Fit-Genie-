import CompletionValidationModal from './CompletionValidationModal';
import { calculateExpectedMinimumTime } from '../utils/integrityEngine';
import { useGenieIntelligence } from '../hooks/useGenieIntelligence';
import GeniePenaltyModal from './GeniePenaltyModal';
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Trophy, Activity, Medal, Star, Target, CheckCircle2, ShieldAlert, Timer, Play, AlertTriangle } from "lucide-react";
import { playSound } from "../utils/audio";
import { useAuth } from "../context/AuthContext";
import { useGuardianContext } from "../context/GuardianContext";
import { getTodayDateString } from "../utils/dailyChallenge";
import { AiRepCounter } from "./AiRepCounter";
import { Camera } from "lucide-react";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";

export interface ActiveChallenge {
  id: string;
  title: string;
  xp: number;
  exercises: { name: string; targetReps: number; completedReps: number }[];
  desc?: string;
  startTime: number;
  difficulty?: string;
  time?: string;
  muscles?: string[];
  boss?: string;
}

interface DailyChallengeDetailScreenProps {
  challenge: ActiveChallenge;
  onUpdate: (updated: ActiveChallenge) => void;
  onBack: () => void;
  onComplete: (xpToAward: number) => Promise<boolean> | boolean | void;
}

export default function DailyChallengeDetailScreen({ challenge, onUpdate, onBack, onComplete }: DailyChallengeDetailScreenProps) {
  const { profile } = useAuth();
  const { triggerEvent } = useGuardianContext();
  const {
    cooldown,
    suspiciousPhase,
    lockEndTime,
    checkCheat,
    proceedFromAlert,
    proceedFromMotivation,
    submitApology,
    resetSessionTime
  } = useGenieIntelligence(challenge.id);

  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);

  const [showCompletion, setShowCompletion] = useState(false);
  const [showHonorValidation, setShowHonorValidation] = useState(false);
  const [honorChecked, setHonorChecked] = useState(false);
  const [justClaimed, setJustClaimed] = useState(false);
  
  const [floatingTexts, setFloatingTexts] = useState<{ id: number, text: string, x: number }[]>([]);
  const [textCounter, setTextCounter] = useState(0);
  
  const todayStr = getTodayDateString();
  const progressKey = `daily_challenge_progress_${profile?.uid}`;
  const claimedKey = `daily_challenge_claimed_${profile?.uid}`;
  const [hasClaimedToday, setHasClaimedToday] = useState(false);

  useEffect(() => {
    if (challenge.boss) {
      triggerEvent("boss_fight");
    } else {
      triggerEvent("challenge_active");
    }
  }, []);

  // Anti-cheat & Session State
  const [isStarted, setIsStarted] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [showManualInput, setShowManualInput] = useState(false);
  const [showAiCounter, setShowAiCounter] = useState(false);
  const [manualReps, setManualReps] = useState("");

  useEffect(() => {
    // Check if claimed today
    const claimedDate = localStorage.getItem(claimedKey);
    if (claimedDate === todayStr) {
      setHasClaimedToday(true);
    }
    // Load progress
    const saved = localStorage.getItem(progressKey);
    if (saved) {
      try {
        const { date, completedRepsArray, elapsed, started } = JSON.parse(saved);
        if (date === todayStr) {
          const updated = { ...challenge };
          let changed = false;
          let nextIdx = 0;
          if (completedRepsArray && Array.isArray(completedRepsArray)) {
            updated.exercises.forEach((ex, idx) => {
               if (completedRepsArray[idx] !== undefined && completedRepsArray[idx] > ex.completedReps) {
                 ex.completedReps = Math.min(ex.targetReps, completedRepsArray[idx]);
                 changed = true;
               }
               if (ex.completedReps >= ex.targetReps && idx === nextIdx) {
                 nextIdx = Math.min(updated.exercises.length - 1, idx + 1);
               }
            });
            setCurrentExerciseIndex(nextIdx);
          }
          
          if (changed) onUpdate(updated);
          if (elapsed) setElapsedTime(elapsed);
          if (started) setIsStarted(started);
        } else {
          // Reset progress for new day
          localStorage.removeItem(progressKey);
          const updated = { ...challenge };
          updated.exercises.forEach(ex => ex.completedReps = 0);
          onUpdate(updated);
        }
      } catch (e) {
        console.error(e);
      }
    }
  }, []); // Run once on mount

  const exercise = challenge.exercises[currentExerciseIndex] || challenge.exercises[0];
  
  const totalTarget = challenge.exercises.reduce((sum, ex) => sum + ex.targetReps, 0);
  const totalCompleted = challenge.exercises.reduce((sum, ex) => sum + ex.completedReps, 0);
  const overallProgressPercent = Math.min(100, Math.round((totalCompleted / totalTarget) * 100));
  
  const progressPercent = Math.min(100, Math.round((exercise.completedReps / exercise.targetReps) * 100));
  const isCompleted = challenge.exercises.every(ex => ex.completedReps >= ex.targetReps);

  // Boss Health (based on current exercise, or overall? Overall makes more sense for multi-stage)
  const bossMaxHP = totalTarget;
  const bossCurrentHP = Math.max(0, bossMaxHP - totalCompleted);

  // Earned XP
  const earnedXP = hasClaimedToday ? 0 : Math.floor((overallProgressPercent / 100) * challenge.xp);

  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  useEffect(() => {
    let cdTimer: NodeJS.Timeout;
    if (isStarted && !isCompleted && suspiciousPhase === "none") {
      cdTimer = setInterval(() => {
        setElapsedTime((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(cdTimer);
  }, [isStarted, isCompleted, suspiciousPhase]);

  useEffect(() => {
    if (isCompleted && !showCompletion && !showHonorValidation && suspiciousPhase === "none" && !hasClaimedToday) {
      const timer = setTimeout(() => setShowHonorValidation(true), 500);
      return () => clearTimeout(timer);
    }
  }, [isCompleted, showCompletion, showHonorValidation, suspiciousPhase, hasClaimedToday]);

  const saveProgress = (repsArray: number[], elapsed: number, started: boolean) => {
    localStorage.setItem(progressKey, JSON.stringify({
      date: todayStr,
      completedRepsArray: repsArray,
      elapsed: elapsed,
      started: started
    }));
  };

  const handleStart = () => {
    playSound("click");
    setIsStarted(true);
    saveProgress(challenge.exercises.map(ex => ex.completedReps), elapsedTime, true);
  };

  const handleAddReps = (amount: number, fromAI: boolean = false) => {
    if (isCompleted || hasClaimedToday || cooldown > 0) return;
    if (!fromAI && checkCheat(exercise.name, amount)) {
      const updated = { ...challenge };
      updated.exercises[currentExerciseIndex].completedReps = 0;
      onUpdate(updated);
      return;
    }
        
    const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);
    
    // XP logic
    const previousXP = Math.floor((overallProgressPercent / 100) * challenge.xp);
    
    const updated = { ...challenge };
    updated.exercises[currentExerciseIndex].completedReps = newCompleted;
    
    const newTotalCompleted = updated.exercises.reduce((sum, ex) => sum + ex.completedReps, 0);
    const newOverallProgress = Math.min(100, Math.round((newTotalCompleted / totalTarget) * 100));
    const newXP = Math.floor((newOverallProgress / 100) * challenge.xp);
    const xpDiff = newXP - previousXP;

    if (xpDiff > 0 && !hasClaimedToday) {
      const id = textCounter;
      setTextCounter(prev => prev + 1);
      setFloatingTexts(prev => [...prev, { id, text: `+${xpDiff} XP`, x: Math.random() * 40 - 20 }]);
      setTimeout(() => {
        setFloatingTexts(prev => prev.filter(t => t.id !== id));
      }, 1000);
    }

    if (newCompleted >= exercise.targetReps) {
       playSound("success");
       const nextIncomplete = updated.exercises.findIndex(e => e.completedReps < e.targetReps);
       if (nextIncomplete !== -1) {
          setCurrentExerciseIndex(nextIncomplete);
       }
    } else {
       playSound("click");
    }
    
    saveProgress(updated.exercises.map(ex => ex.completedReps), elapsedTime, isStarted);
    onUpdate(updated);
  };

  const handleFinish = () => {
    onBack();
  };

  const [showReviewModal, setShowReviewModal] = useState(false);

  const handleClaimXP = async () => {
    if (!honorChecked) return;
    setShowHonorValidation(false);
    await finalizeClaimXP();
  };

  const finalizeClaimXP = async () => {
    setShowReviewModal(false);
    playSound("success");
    if (!hasClaimedToday) {
      const result = await onComplete(challenge.xp);
      if (result === false) return; // Validation failed
      localStorage.setItem(claimedKey, todayStr);
      setHasClaimedToday(true);
      setJustClaimed(true);
    }
    setShowCompletion(true);
  };

  const submitManualReps = () => {
    const reps = parseInt(manualReps);
    if (!isNaN(reps) && reps > 0) {
      handleAddReps(reps);
    }
    setShowManualInput(false);
    setManualReps("");
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const badges = [
    { threshold: 25, label: "Started", hex: "#00F5D4", color: "text-[#00F5D4]" },
    { threshold: 50, label: "Halfway", hex: "#FB8500", color: "text-orange-400" },
    { threshold: 75, label: "Pushing", hex: "#38BDF8", color: "text-sky-400" },
    { threshold: 100, label: "Master", hex: "#FFB703", color: "text-amber-400" },
  ];

  const targetMuscles = challenge.muscles || ["Full Body"];

  if (showCompletion) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A] flex flex-col items-center justify-center p-6">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-center"
        >
          <Trophy className="w-24 h-24 text-yellow-500 mx-auto mb-6" />
          <h2 className="text-3xl font-black uppercase text-white mb-2">Challenge Conquered</h2>
          {justClaimed ? (
            <p className="text-[#14F1E1] font-bold mb-8 text-xl">+{challenge.xp} XP Earned!</p>
          ) : (
            <p className="text-[#14F1E1] font-bold mb-8 text-xl">Already Claimed Today</p>
          )}
          
          <button 
            onClick={handleFinish}
            className="w-full py-4 bg-white/10 hover:bg-white/20 text-white rounded-xl font-black uppercase tracking-widest transition-colors"
          >
            Return to Challenges
          </button>
        </motion.div>
      </div>
    );
  }

  if (suspiciousPhase === "alert") {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/95 flex flex-col items-center justify-center p-6 backdrop-blur-md">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-[#050B1A] border-2 border-red-500/50 p-6 rounded-3xl max-w-sm w-full text-center shadow-[0_0_50px_rgba(239,68,68,0.2)]"
        >
          <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-black uppercase text-red-500 mb-2">Unrealistic Speed</h2>
          <p className="text-white font-bold mb-4">Fit Genie AI detected impossible repetition speed.</p>
          <p className="text-neutral-400 text-sm mb-6">Slow down. Focus on form, not just numbers. Do you want to continue?</p>
          
          <button 
            onClick={proceedFromAlert}
            className="w-full py-4 bg-red-500 hover:bg-red-600 text-white rounded-xl font-black uppercase tracking-widest transition-colors"
          >
            I Understand
          </button>
        </motion.div>
      </div>
    );
  }

  if (suspiciousPhase === "motivation") {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/95 flex flex-col items-center justify-center p-6 backdrop-blur-md">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-[#050B1A] border-2 border-yellow-500/50 p-6 rounded-3xl max-w-sm w-full text-center shadow-[0_0_50px_rgba(234,179,8,0.2)]"
        >
          <Target className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-2xl font-black uppercase text-yellow-500 mb-2">Who are you cheating?</h2>
          <p className="text-white font-bold mb-4">You are only lying to yourself bro.</p>
          <p className="text-neutral-400 text-sm mb-6">The mirror doesn't care about fake numbers. Do the work.</p>
          
          <button 
            onClick={proceedFromMotivation}
            className="w-full py-4 bg-yellow-500 hover:bg-yellow-600 text-[#050B1A] rounded-xl font-black uppercase tracking-widest transition-colors"
          >
            Stay Hard
          </button>
        </motion.div>
      </div>
    );
  }

  if (suspiciousPhase === "locked" || suspiciousPhase === "apology") {
    return <GeniePenaltyModal suspiciousPhase={suspiciousPhase} lockEndTime={lockEndTime} onSubmitApology={submitApology} />;
  }

  if (showManualInput) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/90 flex flex-col items-center justify-center p-6 backdrop-blur-sm">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-[#0D1328] border border-[#14F1E1]/30 p-6 rounded-3xl max-w-xs w-full shadow-[0_0_40px_rgba(20,241,225,0.15)]"
        >
          <h3 className="text-white font-black uppercase tracking-widest mb-4 text-center text-sm">Add {exercise.name} Reps</h3>
          <input 
            type="number"
            value={manualReps}
            onChange={e => setManualReps(e.target.value)}
            className="w-full bg-white/5 border border-white/20 rounded-xl p-4 text-white text-center text-2xl font-black mb-6 focus:outline-none focus:border-[#14F1E1] transition-colors"
            placeholder="0"
            autoFocus
          />
          
          <div className="grid grid-cols-2 gap-3">
            <button 
              onClick={() => { setShowManualInput(false); setManualReps(""); }}
              className="py-3 bg-white/10 text-white font-bold rounded-xl text-xs uppercase tracking-widest border border-white/20"
            >
              Cancel
            </button>
            <button 
              onClick={submitManualReps}
              className="py-3 bg-[#14F1E1] text-[#050B1A] font-bold rounded-xl text-xs uppercase tracking-widest"
            >
              Add Reps
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  if (showReviewModal) {
    return (
      <CompletionValidationModal
        durationSeconds={elapsedTime}
        expectedSeconds={calculateExpectedMinimumTime(challenge.exercises)}
        exerciseName={challenge.title}
        targetReps={totalTarget}
        onValid={finalizeClaimXP}
        onInvalid={() => {
            setShowReviewModal(false);
            setElapsedTime(0);
            const updated = { ...challenge };
            updated.exercises.forEach(ex => ex.completedReps = 0);
            saveProgress(updated.exercises.map(e => 0), 0, false);
            setIsStarted(false);
            setCurrentExerciseIndex(0);
            onUpdate(updated);
        }}
      />
    );
  }

  if (showHonorValidation) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/90 flex flex-col items-center justify-center p-6 backdrop-blur-sm">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-[#050B1A] border border-[#14F1E1]/30 shadow-[0_0_30px_rgba(20,241,225,0.15)] rounded-3xl p-6 text-center max-w-sm w-full relative"
        >
          <Trophy className="w-16 h-16 text-[#14F1E1] mx-auto mb-4" />
          <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-4">🏆 Challenge Complete</h2>
          <p className="text-neutral-300 text-sm mb-6 leading-relaxed">
            {totalTarget} Reps Total Completed?<br/><br/>
            Please confirm that you completed this challenge honestly.<br/>
            Fit Genie trust system par kaam karta hai.<br/><br/>
            <span className="text-[#14F1E1] font-bold">Real effort = Real progress. 💪</span>
          </p>
          
          <label className="flex items-center gap-3 p-4 bg-white/5 border border-white/10 rounded-xl cursor-pointer mb-6 text-left hover:bg-white/10 transition-colors">
            <input 
              type="checkbox" 
              checked={honorChecked}
              onChange={(e) => { playSound("click"); setHonorChecked(e.target.checked); }}
              className="w-5 h-5 accent-[#14F1E1] rounded"
            />
            <span className="text-white text-sm font-bold">Main kasam khata hu ki maine cheat nahi kiya.</span>
          </label>
          
          <button 
            onClick={handleClaimXP}
            disabled={!honorChecked}
            className="w-full py-4 bg-[#14F1E1] text-[#050B1A] font-black uppercase tracking-widest rounded-xl transition-all disabled:opacity-50 disabled:grayscale shadow-[0_0_20px_rgba(20,241,225,0.3)]"
          >
            Claim Rewards
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen">
      <button onClick={() => { playSound("click"); onBack(); }} className="flex items-center gap-2 text-[#14F1E1] mb-4">
        <ChevronLeft className="w-5 h-5" />
        <span className="font-bold uppercase tracking-widest text-xs">Back to Hub</span>
      </button>

      {/* HEADER */}
      <div className="text-center space-y-2">
        <div className="inline-block px-3 py-1 bg-red-500/20 text-red-500 border border-red-500/50 rounded-full text-[10px] font-black uppercase tracking-widest animate-pulse">
          Extreme Difficulty
        </div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-white">
          {challenge.title}
        </h1>
        {challenge.boss && (
          <p className="text-[#14F1E1] text-sm font-black uppercase tracking-widest">
            VS {challenge.boss}
          </p>
        )}
      </div>

      {/* TIMER & XP ROW */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white/5 border border-white/10 p-4 rounded-2xl flex items-center gap-3">
          <Timer className="w-6 h-6 text-[#14F1E1]" />
          <div>
            <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">Elapsed Time</p>
            <p className="text-white font-black text-xl tabular-nums">{formatTime(elapsedTime)}</p>
          </div>
        </div>
        <div className="bg-white/5 border border-white/10 p-4 rounded-2xl flex items-center gap-3">
          <Target className="w-6 h-6 text-[#14F1E1]" />
          <div>
            <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">Target Time</p>
            <p className="text-white font-black text-xl">{challenge.time}</p>
          </div>
        </div>
      </div>

      {/* MULTI-STAGE TRACKER */}
      <div className="bg-[#050B1A] border border-[#14F1E1]/30 rounded-2xl p-4 space-y-3">
        <h3 className="text-white font-black uppercase text-xs tracking-widest text-center mb-3">Stages</h3>
        <div className="flex gap-2">
           {challenge.exercises.map((ex, idx) => {
             const isDone = ex.completedReps >= ex.targetReps;
             const isCurrent = idx === currentExerciseIndex;
             return (
               <div key={idx} onClick={() => setCurrentExerciseIndex(idx)} className={`flex-1 h-2 rounded-full cursor-pointer transition-all duration-300 ${isDone ? 'bg-[#14F1E1]' : isCurrent ? 'bg-orange-500 animate-pulse' : 'bg-white/10'}`} />
             )
           })}
        </div>
        <div className="text-center pt-2 space-y-3">
           <div>
             <p className="text-xs font-bold text-neutral-400 uppercase tracking-widest">Stage {currentExerciseIndex + 1} of {challenge.exercises.length}</p>
             <p className="text-lg font-black text-white">{exercise.name}</p>
           </div>
           <Exercise3DCharacterLoop
             name={exercise.name}
             muscles={challenge.muscles || ["chest"]}
             compact={false}
             interactive={true}
             onTempoRepCompleted={() => {
               if (isStarted) {
                 handleAddReps(1, true);
               }
             }}
           />
        </div>
      </div>

      {/* BOSS BATTLE / CYBER SHIELD TELEMETRY */}
      <div className="bg-gradient-to-b from-red-950/40 to-[#050B1A] border border-red-500/35 rounded-3xl p-5 relative overflow-hidden shadow-[0_0_35px_rgba(239,68,68,0.15)]">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent opacity-60" />

        <div className="flex flex-col gap-3">
           <div className="flex items-center justify-between">
             <div className="flex items-center gap-2.5">
               <div className="w-10 h-10 rounded-xl bg-red-500/15 border border-red-500/40 flex items-center justify-center">
                 <ShieldAlert className="w-5 h-5 text-red-400" />
               </div>
               <div>
                 <span className="text-[9px] font-mono font-black uppercase tracking-widest text-red-400 block">
                   APEX BOSS SHIELD
                 </span>
                 <h4 className="text-sm font-black uppercase text-white">
                   {challenge.boss || "CYBER TITAN OVERLORD"}
                 </h4>
               </div>
             </div>
             <div className="text-right font-mono">
               <span className="text-xs font-black text-red-400">HP: {bossCurrentHP}</span>
               <span className="text-[10px] text-neutral-400"> / {bossMaxHP}</span>
             </div>
           </div>

           <div className="h-3 w-full bg-red-950/80 rounded-full overflow-hidden relative border border-red-500/30">
             <motion.div 
               className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-red-600 via-orange-500 to-[#14F1E1]"
               initial={{ width: '100%' }}
               animate={{ width: `${(bossCurrentHP / bossMaxHP) * 100}%` }}
               transition={{ duration: 0.4 }}
             />
           </div>
        </div>
      </div>

      {/* CIRCULAR PROGRESS */}
      <div className="flex flex-col items-center justify-center my-8">
        <div className="relative flex items-center justify-center w-48 h-48">
          <svg className="transform -rotate-90 w-48 h-48">
            <circle
              cx="96" cy="96" r={radius}
              className="stroke-white/10"
              strokeWidth="12" fill="none"
            />
            <motion.circle
              cx="96" cy="96" r={radius}
              className="stroke-[#14F1E1]"
              strokeWidth="12" fill="none"
              strokeLinecap="round"
              strokeDasharray={circumference}
              animate={{ strokeDashoffset }}
              transition={{ duration: 0.5, ease: "easeOut" }}
            />
          </svg>
          <div className="absolute flex flex-col items-center justify-center">
            <span className="text-4xl font-black text-white">{progressPercent}%</span>
            <span className="text-neutral-400 text-xs uppercase font-bold tracking-widest mt-1">
              {exercise.completedReps} / {exercise.targetReps}
            </span>
          </div>
        </div>
      </div>

      {/* CONTROLS */}
      {!isStarted ? (
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleStart}
          className="w-full py-5 bg-[#14F1E1] text-[#050B1A] rounded-2xl font-black text-lg uppercase tracking-widest flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(20,241,225,0.4)]"
        >
          <Play className="w-6 h-6 fill-current" />
          START CHALLENGE
        </motion.button>
      ) : (
        <div className="grid grid-cols-1 gap-3 relative">
          <div className="grid grid-cols-4 gap-2.5 w-full">
            <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(1)} disabled={isCompleted || hasClaimedToday} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl cursor-pointer">+1</motion.button>
            <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(5)} disabled={isCompleted || hasClaimedToday} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl cursor-pointer">+5</motion.button>
            <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(10)} disabled={isCompleted || hasClaimedToday} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl cursor-pointer">+10</motion.button>
            <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(15)} disabled={isCompleted || hasClaimedToday} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl cursor-pointer">+15</motion.button>
          </div>
          {(exercise.name.toLowerCase().includes('pushup') || exercise.name.toLowerCase().includes('push up') || exercise.name.toLowerCase().includes('squat')) && (
             <motion.button 
               whileTap={{ scale: 0.95 }}
               onClick={() => setShowAiCounter(true)}
               disabled={isCompleted || hasClaimedToday}
               className="bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-sm py-3.5 rounded-2xl flex justify-center items-center gap-2 shadow-[0_0_20px_rgba(20,241,225,0.4)] transition-all disabled:opacity-50 cursor-pointer"
             >
               <Camera className="w-5 h-5" />
               AI CAMERA REP TRACKER
             </motion.button>
           )}
          
          {/* FLOATING TEXTS */}
          <AnimatePresence>
            {floatingTexts.map((ft) => (
              <motion.div
                key={ft.id}
                initial={{ opacity: 1, y: 0, x: ft.x, scale: 1 }}
                animate={{ opacity: 0, y: -50, scale: 1.5 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="absolute pointer-events-none left-1/2 -translate-x-1/2 -top-10 text-[#14F1E1] font-black text-xl z-20"
              >
                {ft.text}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* LIVE XP TRACKER */}
      <div className="bg-[#050B1A] border border-white/10 rounded-2xl p-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-yellow-500/20 p-2 rounded-xl">
            <Star className="w-5 h-5 text-yellow-500" />
          </div>
          <div>
            <h4 className="text-white font-black uppercase text-sm">Overall XP</h4>
            <p className="text-neutral-400 text-xs font-bold">Reward progression</p>
          </div>
        </div>
        <div className="text-[#14F1E1] font-black text-2xl">
          {earnedXP} <span className="text-sm text-neutral-500">/ {challenge.xp}</span>
        </div>
      </div>

      {/* 3D HOLOGRAPHIC MILESTONE CRYSTALS */}
      <div className="bg-[#060D20] border border-white/10 rounded-2xl p-5">
        <h4 className="text-white font-black uppercase text-sm mb-4">3D Milestone Crystals</h4>
        <div className="grid grid-cols-4 gap-2.5 text-center">
          {badges.map((badge, idx) => {
            const unlocked = overallProgressPercent >= badge.threshold;
            return (
              <div
                key={idx}
                className={`flex flex-col items-center p-2.5 rounded-2xl border transition-all ${
                  unlocked
                    ? "bg-white/[0.06] border-white/20 shadow-[0_0_16px_rgba(0,245,212,0.12)]"
                    : "bg-black/30 border-white/5 opacity-35"
                }`}
              >
                <motion.div
                  className="w-9 h-9 flex items-center justify-center mb-1"
                  animate={unlocked ? { y: [0, -3, 0], rotateZ: [0, 4, -4, 0] } : {}}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                >
                  <svg viewBox="0 0 40 40" className="w-8 h-8 overflow-visible">
                    <polygon
                      points="20,4 34,15 28,35 12,35 6,15"
                      fill={unlocked ? `${badge.hex}33` : "rgba(255,255,255,0.05)"}
                      stroke={unlocked ? badge.hex : "rgba(255,255,255,0.2)"}
                      strokeWidth="1.5"
                    />
                    <polygon
                      points="20,4 34,15 20,22 6,15"
                      fill={unlocked ? badge.hex : "rgba(255,255,255,0.1)"}
                      opacity="0.65"
                    />
                    <circle
                      cx="20"
                      cy="19"
                      r="3"
                      fill="#FFFFFF"
                      opacity={unlocked ? 0.9 : 0.2}
                    />
                  </svg>
                </motion.div>
                <span
                  className={`text-[9px] font-black uppercase tracking-widest mt-1 ${
                    unlocked ? badge.color : "text-neutral-500"
                  }`}
                >
                  {badge.label}
                </span>
                <span className="text-[8px] font-mono text-neutral-400">
                  {badge.threshold}%
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* TARGET MUSCLES */}
      <div className="space-y-3">
        <h4 className="text-white font-black uppercase text-sm">Target Muscles</h4>
        <div className="flex flex-wrap gap-2">
          {targetMuscles.map((muscle, idx) => (
            <span key={idx} className="bg-[#14F1E1]/10 border border-[#14F1E1]/20 text-[#14F1E1] px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-widest flex items-center gap-1.5">
              <Target className="w-3 h-3" /> {muscle}
            </span>
          ))}
        </div>
      </div>

      {showAiCounter && (
        <AiRepCounter
          initialExercise={exercise.name.toLowerCase().includes('squat') ? "Squats" : "Pushups"}
          onClose={() => setShowAiCounter(false)}
          onComplete={(reps) => {
            if (reps > 0) {
              handleAddReps(reps, true);
            }
            setShowAiCounter(false);
          }}
        />
      )}
    </div>
  );
}
