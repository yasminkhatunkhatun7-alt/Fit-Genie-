import { motion } from "motion/react";
import { Zap, Shield, Target, BookOpen, Heart } from "lucide-react";

export default function AboutPage() {
  const containerVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.4, staggerChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.3 } },
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="max-w-4xl mx-auto px-4 py-8 space-y-12"
      id="about-content"
    >
      {/* Brand Hero Shield */}
      <motion.div
        variants={itemVariants}
        className="relative bg-brand-surface border border-brand-border rounded-3xl p-8 md:p-12 text-center overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-accent/5 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-brand-accent/10 text-brand-accent mb-6 animate-pulse-slow">
          <Zap className="w-8 h-8 filter drop-shadow-[0_0_8px_rgba(201,243,29,0.5)]" />
        </div>

        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4 uppercase">
          FIT GENIE
        </h1>
        <p className="text-brand-accent font-semibold tracking-widest uppercase text-sm mb-6">
          "Train Smart. Train Hard."
        </p>
        <p className="max-w-xl mx-auto text-brand-muted text-sm md:text-base leading-relaxed">
          Fit Genie is a high-intensity, premium workout generator tailored to empower gym enthusiasts and home warriors alike. Born from the philosophy of pure functional mechanics and traditional Indian power athletics, our tool crafts customized regimes in seconds.
        </p>
      </motion.div>

      {/* Philosophy Row (Two Columns) */}
      <div className="grid md:grid-cols-2 gap-6">
        <motion.div
          variants={itemVariants}
          className="bg-brand-surface border border-brand-border rounded-2xl p-6 relative overflow-hidden"
        >
          <div className="flex items-center gap-3 mb-4">
            <Target className="w-5 h-5 text-brand-accent" />
            <span className="font-extrabold text-sm uppercase tracking-wider text-brand-text">
              Anatomical Precision
            </span>
          </div>
          <p className="text-brand-muted text-xs md:text-sm leading-relaxed">
            Our dual-sided interactive muscle schematic maps your body like a dynamic gym blueprint. By choosing exact zones (Chest, Back, Legs, Calves etc.), Fit Genie filters our expert library down to exercises matching only what you target and what tools you hold.
          </p>
        </motion.div>

        <motion.div
          variants={itemVariants}
          className="bg-brand-surface border border-brand-border rounded-2xl p-6 relative overflow-hidden"
        >
          <div className="flex items-center gap-3 mb-4">
            <Zap className="w-5 h-5 text-brand-accent" />
            <span className="font-extrabold text-sm uppercase tracking-wider text-brand-text">
              Pure Desi Virasat
            </span>
          </div>
          <p className="text-brand-muted text-xs md:text-sm leading-relaxed">
            We celebrate the legendary power of Indian Akharas. Fit Genie natively infuses time-tested physical culture into modern splits, curating traditional movements like <strong className="text-brand-accent">Surya Namaskar</strong>, <strong className="text-brand-accent">Dand</strong>, and <strong className="text-brand-accent">Baithaks</strong>.
          </p>
        </motion.div>
      </div>

      {/* Desi Workout Spotlight */}
      <motion.div
        variants={itemVariants}
        className="bg-brand-card border-l-4 border-brand-accent rounded-r-2xl p-6 space-y-4"
      >
        <h3 className="font-extrabold text-lg uppercase tracking-tight text-brand-text flex items-center gap-2">
          <span>🇮🇳</span> The Akhara Tradition (देसी व्यायाम)
        </h3>
        <p className="text-brand-muted text-xs md:text-sm leading-relaxed">
          Indian traditional athletics emphasize functional power weight-bearing moves. <strong>Dand</strong> (Hindu Push-ups) builds rotational shoulder stability and explosive chest drive, whereas <strong>Baithak</strong> constructs deep core stabilization and robust hip extension. We pay homage to these evergreen calisthenics routines right inside your generated splits.
        </p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2">
          <div className="p-3 bg-brand-surface rounded-lg border border-brand-border">
            <div className="text-brand-accent text-sm font-bold">सूर्य नमस्कार</div>
            <div className="text-brand-muted text-[10px] uppercase">Surya Namaskar</div>
          </div>
          <div className="p-3 bg-brand-surface rounded-lg border border-brand-border">
            <div className="text-brand-accent text-sm font-bold">दंड</div>
            <div className="text-brand-muted text-[10px] uppercase">Hindu Push-ups</div>
          </div>
          <div className="p-3 bg-brand-surface rounded-lg border border-brand-border">
            <div className="text-brand-accent text-sm font-bold">बैठक / उठक बैठक</div>
            <div className="text-brand-muted text-[10px] uppercase">Squat Athletics</div>
          </div>
          <div className="p-3 bg-brand-surface rounded-lg border border-brand-border">
            <div className="text-brand-accent text-sm font-bold">चौखट पुल-अप</div>
            <div className="text-brand-muted text-[10px] uppercase">Door pull-ups</div>
          </div>
        </div>
      </motion.div>

      {/* Core values bento style */}
      <div className="space-y-4">
        <h4 className="font-extrabold text-xs uppercase tracking-widest text-brand-accent">
          Core Capabilities
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-5 bg-brand-surface border border-brand-border rounded-xl">
            <div className="font-bold text-sm text-brand-text mb-1">100% Client-Side</div>
            <p className="text-brand-muted text-xs">
              State values are persistent inside your local browser storage. No login or backend queues required to begin training.
            </p>
          </div>
          <div className="p-5 bg-brand-surface border border-brand-border rounded-xl">
            <div className="font-bold text-sm text-brand-text mb-1">Adaptive Rest Counter</div>
            <p className="text-brand-muted text-xs">
              Maintain optimal cardiac windows with an integrated 60-second animated interval rest timer.
            </p>
          </div>
          <div className="p-5 bg-brand-surface border border-brand-border rounded-xl">
            <div className="font-bold text-sm text-brand-text mb-1">Instant PDF Companion</div>
            <p className="text-brand-muted text-xs">
              Save your generated sets into an elegant, high-contrast digital PDF file with Hindi translations.
            </p>
          </div>
        </div>
      </div>

      {/* Footer credits block */}
      <div className="text-center pt-8 border-t border-brand-border text-[11px] text-brand-muted flex flex-col items-center gap-2">
        <div className="flex items-center gap-1.5 justify-center">
          <span>Created with</span>
          <Heart className="w-3 h-3 text-brand-accent fill-brand-accent" />
          <span>incorporating premium Indian athletic values</span>
        </div>
        <div>Fit Genie © 2026 • Train Smart. Train Hard.</div>
      </div>
    </motion.div>
  );
}
