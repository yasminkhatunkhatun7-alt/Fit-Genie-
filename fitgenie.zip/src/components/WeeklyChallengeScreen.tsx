import { useGenieIntelligence } from '../hooks/useGenieIntelligence';
import GeniePenaltyModal from './GeniePenaltyModal';
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Trophy, Target, ShieldAlert, Timer, Play, AlertTriangle, Ghost, XCircle, Sword } from "lucide-react";
import { playSound } from "../utils/audio";
import { AiRepCounter } from "./AiRepCounter";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";
import { Camera } from "lucide-react";
import CompletionValidationModal from "./CompletionValidationModal";
import { calculateExpectedMinimumTime } from "../utils/integrityEngine";
import { useAuth } from "../context/AuthContext";
import { ActiveChallenge } from "./StrengthChallengeScreen";

interface WeeklyChallengeScreenProps {
  challenge: ActiveChallenge;
  onUpdate: (updated: ActiveChallenge) => void;
  onBack: () => void;
  onComplete: (xpToAward: number) => Promise<boolean> | boolean | void;
}

const getWeekId = () => {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay()||7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
  const weekNo = Math.ceil(( ( (d.getTime() - yearStart.getTime()) / 86400000) + 1)/7);
  return `${d.getUTCFullYear()}-W${weekNo}`;
};

const getDaysRemaining = () => {
  const d = new Date();
  const day = d.getDay(); 
  return day === 0 ? 0 : 7 - day; 
};

export default function WeeklyChallengeScreen({ challenge, onUpdate, onBack, onComplete }: WeeklyChallengeScreenProps) {
  const {
    cooldown,
    suspiciousPhase,
    lockEndTime,
    checkCheat,
    proceedFromAlert,
    proceedFromMotivation,
    submitApology,
    resetSessionTime
  } = useGenieIntelligence(challenge.id);
  const { profile } = useAuth();
  
  const [showCompletion, setShowCompletion] = useState(false);
  const [showHonorValidation, setShowHonorValidation] = useState(false);
  const [honorChecked, setHonorChecked] = useState(false);
  const [floatingTexts, setFloatingTexts] = useState<{ id: number, text: string, x: number }[]>([]);
  const [textCounter, setTextCounter] = useState(0);

  const weekId = getWeekId();
  const progressKey = `weekly_challenge_progress_${profile?.uid}_${weekId}`;
  const claimedKey = `weekly_challenge_claimed_${profile?.uid}_${weekId}`;

  const [hasClaimedThisWeek, setHasClaimedThisWeek] = useState(() => {
    return localStorage.getItem(claimedKey) === weekId;
  });
  const [justClaimed, setJustClaimed] = useState(false);
  const [showAiCounter, setShowAiCounter] = useState(false);

  // Anti-cheat & Session State
  const [cooldown1, setCooldown1] = useState(0);
  const [cooldown10, setCooldown10] = useState(0);
  const [pendingAmount, setPendingAmount] = useState(0);

  // Rate limiting check
  const [lastActionTime, setLastActionTime] = useState(0);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [isStarted, setIsStarted] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(progressKey);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.elapsed) setElapsedTime(parsed.elapsed);
        if (parsed.started) setIsStarted(parsed.started);
        if (parsed.reps > challenge.exercises[0].completedReps) {
          const updated = { ...challenge };
          updated.exercises[0].completedReps = Math.min(parsed.reps, challenge.exercises[0].targetReps);
          onUpdate(updated);
        }
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const exercise = challenge.exercises[0] || { name: "Squats", targetReps: 1500, completedReps: 0 };
  const progressPercent = Math.min(100, (exercise.completedReps / exercise.targetReps) * 100);
  const isCompleted = progressPercent >= 100;

  const bossMaxHP = exercise.targetReps;
  const bossCurrentHP = Math.max(0, bossMaxHP - exercise.completedReps);

  useEffect(() => {
    let timerId: NodeJS.Timeout;
    if (isStarted && !isCompleted && !hasClaimedThisWeek) {
      timerId = setInterval(() => {
        setElapsedTime(prev => {
          const next = prev + 1;
          saveProgress(exercise.completedReps, next, true);
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(timerId);
  }, [isStarted, isCompleted, hasClaimedThisWeek, exercise.completedReps]);

  useEffect(() => {
    let cdTimer: NodeJS.Timeout;
    if (cooldown1 > 0 || cooldown10 > 0) {
      cdTimer = setInterval(() => {
        setCooldown1(prev => Math.max(0, prev - 1));
        setCooldown10(prev => Math.max(0, prev - 1));
      }, 1000);
    }
    return () => clearInterval(cdTimer);
  }, [cooldown1, cooldown10]);

  useEffect(() => {
    if (isCompleted && !showCompletion && !showHonorValidation && !hasClaimedThisWeek) {
      const timer = setTimeout(() => setShowHonorValidation(true), 500);
      return () => clearTimeout(timer);
    }
  }, [isCompleted, showCompletion, showHonorValidation, hasClaimedThisWeek]);

  const saveProgress = (reps: number, elapsed: number, started: boolean) => {
    localStorage.setItem(progressKey, JSON.stringify({ reps, elapsed, started }));
  };

  const addRepsInternal = (amount: number) => {
    if (amount === 1) {
      setCooldown1(1); 
    } else if (amount === 10) {
      setCooldown10(10); 
    }

    playSound("timer_tick");
    
    const id = textCounter;
    setTextCounter(prev => prev + 1);
    setFloatingTexts(prev => [...prev, { id, text: `+${amount}`, x: Math.random() * 40 - 20 }]);
    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== id));
    }, 1000);

    const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);
    const updated = { ...challenge };
    updated.exercises[0].completedReps = newCompleted;
    onUpdate(updated);
    if (!isStarted) setIsStarted(true);
    saveProgress(newCompleted, elapsedTime, true);
    setLastActionTime(Date.now());
  };

  const handleAddReps = (amount: number, fromAI: boolean = false) => {
    if (isCompleted || hasClaimedThisWeek) return;
        
    if (amount === 1 && cooldown1 > 0) return;
    if (amount === 10 && cooldown10 > 0) return;

    if (!fromAI && checkCheat(exercise.name, amount)) {
      const updated = { ...challenge };
      updated.exercises[0].completedReps = 0;
      onUpdate(updated);
      return;
    }

    addRepsInternal(amount);
  };


  const handleFinish = () => {
    onBack();
  };

  const handleClaimXP = async () => {
    if (!honorChecked) return;
    setShowHonorValidation(false);
    await finalizeClaimXP();
  };

  const finalizeClaimXP = async () => {
    setShowReviewModal(false);
    playSound("success");
    if (!hasClaimedThisWeek) {
      const result = await onComplete(challenge.xp);
      if (result === false) return; // Validation failed
      localStorage.setItem(claimedKey, weekId);
      setHasClaimedThisWeek(true);
      setJustClaimed(true);
    }
    setShowCompletion(true);
  };

  if (suspiciousPhase !== 'none') {
    return (
      <GeniePenaltyModal 
        suspiciousPhase={suspiciousPhase as any}
        lockEndTime={lockEndTime}
        onProceedFromAlert={proceedFromAlert}
        onProceedFromMotivation={proceedFromMotivation}
        onSubmitApology={submitApology}
      />
    );
  }

  if (showReviewModal) {
    return (
      <CompletionValidationModal
        durationSeconds={elapsedTime}
        expectedSeconds={calculateExpectedMinimumTime(challenge.exercises)}
        exerciseName={challenge.exercises[0].name}
        targetReps={challenge.exercises[0].targetReps}
        onValid={finalizeClaimXP}
        onInvalid={() => {
            setShowReviewModal(false);
            setElapsedTime(0);
            const updated = { ...challenge };
            updated.exercises[0].completedReps = 0;
            saveProgress(0, 0, false);
            setIsStarted(false);
            onUpdate(updated);
        }}
      />
    );
  }

  if (showHonorValidation) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/95 flex flex-col items-center justify-center p-6 backdrop-blur-md">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-[#050B1A] border border-[#B66DFF]/30 shadow-[0_0_40px_rgba(182,109,255,0.2)] rounded-3xl p-6 text-center max-w-sm w-full relative"
        >
          <Trophy className="w-16 h-16 text-[#B66DFF] mx-auto mb-4" />
          <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-4">🏆 WEEKLY BOSS DEFEATED!</h2>
          <p className="text-neutral-300 text-sm mb-6 leading-relaxed">
            {exercise.targetReps} {exercise.name} Completed?<br/><br/>
            Please confirm that you completed this challenge honestly.<br/>
          </p>
          
          <label className="flex items-center gap-3 p-4 bg-white/5 border border-white/10 rounded-xl cursor-pointer mb-6 text-left hover:bg-white/10 transition-colors">
            <input 
              type="checkbox" 
              checked={honorChecked}
              onChange={(e) => setHonorChecked(e.target.checked)}
              className="w-5 h-5 accent-[#B66DFF] rounded border-white/20 bg-white/10"
            />
            <span className="text-sm font-bold text-white leading-tight">Yes, I completed them honestly.</span>
          </label>

          <button 
            onClick={handleClaimXP}
            disabled={!honorChecked}
            className={`w-full py-4 font-black text-sm uppercase tracking-widest rounded-xl transition-all ${honorChecked ? 'bg-[#B66DFF] hover:bg-[#a155ea] text-white shadow-[0_0_20px_rgba(182,109,255,0.4)]' : 'bg-white/10 text-neutral-500 cursor-not-allowed'}`}
          >
            🎁 CLAIM XP
          </button>
          
          <p className="text-neutral-500 text-[10px] uppercase tracking-widest font-bold mt-6">
            Fit Genie trust system par kaam karta hai.<br/>Real effort = Real progress.
          </p>
        </motion.div>
      </div>
    );
  }

  if (showCompletion || hasClaimedThisWeek) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }} 
        animate={{ opacity: 1, scale: 1 }} 
        className="fixed inset-0 z-50 bg-[#050B1A] flex flex-col items-center justify-center p-6"
      >
        {justClaimed && Array.from({ length: 40 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ x: Math.random() * window.innerWidth, y: -20, opacity: 1, rotate: 0 }}
            animate={{ y: window.innerHeight + 20, rotate: 360, opacity: 0 }}
            transition={{ duration: 2 + Math.random() * 2, ease: "linear", repeat: Infinity }}
            className="absolute w-2 h-4 rounded-sm"
            style={{ backgroundColor: ['#B66DFF', '#14F1E1', '#F97316', '#FFFFFF'][Math.floor(Math.random() * 4)], left: `${Math.random() * 95}%` }}
          />
        ))}

        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center space-y-6 max-w-sm w-full relative z-10"
        >
          <div className="w-32 h-32 mx-auto bg-[#B66DFF]/20 rounded-full flex items-center justify-center relative">
            <div className="absolute inset-0 bg-[#B66DFF] rounded-full blur-xl opacity-40 animate-pulse" />
            <Ghost className="w-16 h-16 text-[#B66DFF] relative z-10" />
          </div>
          
          <div>
            <h1 className="text-4xl font-black uppercase text-white tracking-tight leading-tight">🏆 WEEKLY BOSS DEFEATED!</h1>
            <p className="text-red-400 text-lg font-bold mt-2 uppercase tracking-widest">LEG DESTROYER has fallen.</p>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#B66DFF]/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
            {justClaimed ? (
              <>
                <div className="flex justify-between items-center mb-4 border-b border-white/10 pb-4">
                  <span className="text-neutral-400 font-bold uppercase tracking-widest text-xs">Reward Claimed</span>
                  <span className="text-[#B66DFF] font-black text-xl">+{challenge.xp} XP</span>
                </div>
                <div className="text-sm font-medium text-neutral-300 leading-relaxed text-left space-y-4">
                  <p>🔥 Amazing work warrior.</p>
                  <p>Tumne is week ka challenge complete kar diya.</p>
                  <p className="text-[#B66DFF] font-bold">Ab agle weekly challenge ka intezar karo aur daily missions complete karte raho.</p>
                </div>
              </>
            ) : (
              <div className="text-center space-y-4">
                 <div className="inline-block px-4 py-1.5 bg-[#B66DFF]/20 text-[#B66DFF] rounded-full text-xs font-black uppercase tracking-widest border border-[#B66DFF]/30">
                   Completed This Week
                 </div>
                <p className="text-neutral-400 font-bold uppercase tracking-widest text-xs leading-relaxed mt-4">
                  Weekly challenge complete ho gaya.<br/>
                  Agla weekly challenge next week reset par unlock ho.
                </p>
              </div>
            )}
          </div>

          <div className="pt-4 space-y-4">
            <button
              onClick={() => {
                playSound("click");
                onBack();
              }}
              className="w-full py-4 bg-[#B66DFF] hover:bg-[#a155ea] text-white font-black text-sm uppercase tracking-widest rounded-xl transition-all shadow-[0_0_20px_rgba(182,109,255,0.4)]"
            >
              Return To Challenges
            </button>
          </div>
        </motion.div>
      </motion.div>
    );
  }

  const daysRemaining = getDaysRemaining();
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen relative">
      {/* TOP HEADER */}
      <div className="flex items-center justify-between mb-2">
        <button onClick={() => { playSound("click"); onBack(); }} className="flex items-center gap-2 text-[#B66DFF] hover:text-white transition-colors">
          <ChevronLeft className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs">Back</span>
        </button>
        <div className="flex flex-col items-end">
          <span className="text-[#B66DFF] font-black tracking-widest uppercase text-xs flex items-center gap-1">
            <Target className="w-3 h-3" /> WEEKLY WARRIOR
          </span>
        </div>
      </div>

      {/* BOSS BATTLE BANNER */}
      <div className="bg-[#B66DFF]/10 border border-[#B66DFF]/30 rounded-2xl p-6 flex flex-col items-center text-center relative overflow-hidden shadow-[0_0_30px_rgba(182,109,255,0.1)]">
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/20 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-[#B66DFF]/20 rounded-full blur-3xl -ml-10 -mb-10 pointer-events-none" />
        
        <Sword className="w-10 h-10 text-red-500 mb-3 relative z-10" />
        <h2 className="text-2xl md:text-3xl font-black uppercase tracking-tight text-white relative z-10 drop-shadow-lg break-words">BOSS: LEG DESTROYER</h2>
        
        <div className="w-full mt-6 relative z-10">
           <div className="flex justify-between text-xs font-black uppercase tracking-widest mb-2">
             <span className="text-red-400">Boss HP</span>
             <span className="text-white">{bossCurrentHP} / {bossMaxHP}</span>
           </div>
           <div className="h-6 w-full bg-[#050B1A] rounded-full overflow-hidden relative border border-white/10 shadow-inner">
             <motion.div 
               className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-red-600 to-red-400" 
               initial={{ width: '100%' }}
               animate={{ width: `${(bossCurrentHP / bossMaxHP) * 100}%` }}
               transition={{ duration: 0.3 }}
             />
             <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iMTAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTAgMGwxMCAxME0xMCAwaC0xME0wIDEwaDEwIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4xKSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIi8+PC9zdmc+')] opacity-30" />
           </div>
        </div>
      </div>

      {/* LIVE 3D HOLOGRAM ATHLETE & PACER */}
      <div className="rounded-2xl overflow-hidden border border-[#14F1E1]/25 bg-[#050B1A] shadow-[0_0_25px_rgba(20,241,225,0.08)]">
        <Exercise3DCharacterLoop
          exerciseName={exercise.name}
          targetMuscles={["Legs", "Quads", "Glutes", "Core"]}
          difficulty="advanced"
          heightClass="h-[225px]"
          showControls={true}
        />
      </div>

      {/* PROGRESS STATS */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-white/5 border border-white/10 rounded-2xl p-3.5 flex flex-col items-center justify-center relative overflow-hidden">
          <span className="text-white font-black font-mono text-xl relative z-10">{exercise.completedReps}</span>
          <span className="text-neutral-400 text-[9px] font-bold uppercase tracking-widest mt-1 text-center relative z-10">Total {exercise.name}</span>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-2xl p-3.5 flex flex-col items-center justify-center relative overflow-hidden">
          <span className="text-[#B66DFF] font-black font-mono text-xl relative z-10">{Math.round(progressPercent)}%</span>
          <span className="text-neutral-400 text-[9px] font-bold uppercase tracking-widest mt-1 text-center relative z-10">Completion</span>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-2xl p-3.5 flex flex-col items-center justify-center relative overflow-hidden">
          <span className="text-[#14F1E1] font-black font-mono text-xl relative z-10">{daysRemaining}d</span>
          <span className="text-neutral-400 text-[9px] font-bold uppercase tracking-widest mt-1 text-center relative z-10">Remaining</span>
        </div>
      </div>

      {/* CONTROLS */}
      <div className="mt-6">
          <div className="grid grid-cols-1 gap-3 relative">
            <div className="grid grid-cols-4 gap-2.5 w-full">
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(1)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl cursor-pointer">+1</motion.button>
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(5)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl cursor-pointer">+5</motion.button>
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(10)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl cursor-pointer">+10</motion.button>
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(25)} disabled={isCompleted} className="bg-[#B66DFF]/20 hover:bg-[#B66DFF]/30 border border-[#B66DFF]/40 text-[#B66DFF] font-black text-lg py-3 rounded-xl cursor-pointer">+25</motion.button>
            </div>
            {(exercise.name.toLowerCase().includes('pushup') || exercise.name.toLowerCase().includes('push up') || exercise.name.toLowerCase().includes('squat')) && (
               <motion.button 
                 whileTap={{ scale: 0.95 }}
                 onClick={() => setShowAiCounter(true)}
                 disabled={isCompleted}
                 className="bg-[#B66DFF] hover:bg-[#a552f5] text-white font-black text-sm py-4 rounded-2xl flex justify-center items-center gap-2 shadow-[0_0_20px_rgba(182,109,255,0.4)] transition-all disabled:opacity-50 cursor-pointer"
               >
                 <Camera className="w-5 h-5" />
                 AI CAMERA REP TRACKER
               </motion.button>
             )}
            
            {/* FLOATING TEXTS */}
            <AnimatePresence>
              {floatingTexts.map((ft) => (
                <motion.div
                  key={ft.id}
                  initial={{ opacity: 1, y: 0, x: ft.x, scale: 1 }}
                  animate={{ opacity: 0, y: -60, scale: 1.5 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                  className="absolute pointer-events-none left-1/2 -translate-x-1/2 -top-10 text-white font-black text-3xl z-20 drop-shadow-md"
                >
                  {ft.text}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
      </div>


      {showAiCounter && (
        <AiRepCounter
          initialExercise={exercise.name.toLowerCase().includes('squat') ? "Squats" : "Pushups"}
          onClose={() => setShowAiCounter(false)}
          onComplete={(reps) => {
            if (reps > 0) {
              handleAddReps(reps, true);
            }
            setShowAiCounter(false);
          }}
        />
      )}
    </div>
  );
}
