import React from "react";

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }

  static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      error
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("FitGenie ErrorBoundary caught an unhandled error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="fixed inset-0 min-h-screen bg-[#070708] text-white flex flex-col justify-center items-center p-6 font-sans select-none z-[9999]">
          <div className="absolute top-10 left-1/4 w-80 h-80 bg-[#C9F31D]/5 rounded-full blur-[100px] pointer-events-none" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-500/5 rounded-full blur-[120px] pointer-events-none" />

          <div className="w-full max-w-md bg-[#0F0F11] border border-neutral-900 rounded-[2.5rem] p-8 text-center relative overflow-hidden shadow-2xl">
            <div className="w-16 h-16 bg-red-950/40 border border-red-500/30 rounded-2xl flex items-center justify-center mx-auto mb-6 text-red-400">
              <span className="text-2xl">⚠️</span>
            </div>

            <h1 className="text-2xl font-black uppercase tracking-tight mb-2">
              Bhai, Heavy Crash Hua! ⚡
            </h1>
            <p className="text-sm text-brand-muted mb-6">
              Aise kaise haar maan le bro! You hit an unexpected software muscle cramp. Let's reset the grip and jump back in.
            </p>

            <div className="bg-[#070708] border border-neutral-900 rounded-2xl p-4 text-left font-mono text-[11px] text-zinc-400 overflow-x-auto max-h-40 mb-6 space-y-1">
              <div className="text-red-400 font-bold uppercase select-none mb-1">Crash Diagnostics:</div>
              <div className="break-words font-semibold">{this.state.error?.name || "Exception"}: {this.state.error?.message || "Unknown error occurred"}</div>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => window.location.reload()}
                className="w-full py-3.5 bg-[#C9F31D] hover:bg-[#b0d616] text-[#0A0A0A] font-black text-xs uppercase tracking-widest rounded-xl transition-all shadow-[0_0_15px_#C9F31D] flex items-center justify-center gap-2 active:scale-98 cursor-pointer relative z-50"
              >
                <span>Reset Grip (Reload App)</span>
              </button>

              <button
                onClick={() => {
                  try {
                    localStorage.clear();
                    sessionStorage.clear();
                    window.location.href = "/";
                  } catch (e) {
                    window.location.reload();
                  }
                }}
                className="w-full py-3.5 bg-zinc-950 hover:bg-neutral-900 border border-neutral-900 text-zinc-400 hover:text-white font-black text-xs uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 active:scale-98 cursor-pointer relative z-50"
              >
                <span>Heavy Purge (Clear Cache)</span>
              </button>
            </div>
            
            <div className="text-[9px] text-zinc-700 font-mono tracking-widest uppercase mt-6 select-none">
              FIT GENIE SHIELD ACTIVE
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
