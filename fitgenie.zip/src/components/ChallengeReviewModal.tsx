import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, XCircle, ShieldAlert, Activity, BarChart2 } from 'lucide-react';
import { playSound } from '../utils/audio';

interface Props {
  progressValid: boolean;
  activityValid: boolean;
  consistencyValid: boolean;
  onProceed: () => void;
  onCancel: () => void;
}

export default function ChallengeReviewModal({ progressValid, activityValid, consistencyValid, onProceed, onCancel }: Props) {
  const isFlagged = !progressValid || !activityValid || !consistencyValid;

  return (
    <div className="fixed inset-0 z-50 bg-[#050B1A]/95 flex flex-col items-center justify-center p-6 backdrop-blur-md">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="bg-[#0A1020] border border-[#14F1E1]/20 shadow-[0_0_30px_rgba(20,241,225,0.1)] rounded-3xl p-6 max-w-sm w-full relative overflow-hidden"
      >
        <div className="text-center mb-6">
          <ShieldAlert className={`w-16 h-16 mx-auto mb-4 ${isFlagged ? 'text-red-500' : 'text-[#14F1E1]'}`} />
          <h2 className="text-2xl font-black uppercase tracking-tight text-white">Challenge Review</h2>
          <p className="text-neutral-400 text-sm mt-2 font-medium">Validating performance data...</p>
        </div>

        <div className="space-y-4 mb-8">
          <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
            <div className="flex items-center gap-3 text-white">
              <BarChart2 className="w-5 h-5 text-[#14F1E1]" />
              <span className="font-bold text-sm tracking-widest uppercase">Progress</span>
            </div>
            {progressValid ? <CheckCircle2 className="w-6 h-6 text-green-400" /> : <XCircle className="w-6 h-6 text-red-500" />}
          </div>
          
          <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
            <div className="flex items-center gap-3 text-white">
              <Activity className="w-5 h-5 text-[#14F1E1]" />
              <span className="font-bold text-sm tracking-widest uppercase">Activity</span>
            </div>
            {activityValid ? <CheckCircle2 className="w-6 h-6 text-green-400" /> : <XCircle className="w-6 h-6 text-red-500" />}
          </div>

          <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
            <div className="flex items-center gap-3 text-white">
              <ShieldAlert className="w-5 h-5 text-[#14F1E1]" />
              <span className="font-bold text-sm tracking-widest uppercase">Consistency</span>
            </div>
            {consistencyValid ? <CheckCircle2 className="w-6 h-6 text-green-400" /> : <XCircle className="w-6 h-6 text-red-500" />}
          </div>
        </div>

        {isFlagged && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-center">
            <p className="text-red-400 text-xs font-bold uppercase tracking-widest leading-relaxed">
              Integrity Check Failed<br/>
              <span className="text-neutral-400 mt-1 block">Inconsistent or unrealistic performance detected.</span>
            </p>
          </div>
        )}

        <div className="flex flex-col gap-3">
          <button 
            onClick={() => { playSound("click"); onProceed(); }}
            disabled={isFlagged}
            className={`py-4 w-full font-black uppercase tracking-widest rounded-xl transition-all ${
              isFlagged 
                ? 'bg-white/5 text-white/30 cursor-not-allowed border border-white/10' 
                : 'bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] shadow-[0_0_20px_rgba(20,241,225,0.4)]'
            }`}
          >
            Confirm & Claim
          </button>
          {isFlagged && (
            <button 
              onClick={() => { playSound("click"); onCancel(); }}
              className="py-4 w-full bg-white/5 hover:bg-white/10 text-white font-bold rounded-xl text-xs uppercase tracking-widest border border-white/10 transition-colors"
            >
              Back to Challenge
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
}
