import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Shield, Lock, AlertTriangle, MessageSquare, Send } from 'lucide-react';

interface Props {
  suspiciousPhase: "alert" | "locked" | "apology" | "motivation" | string;
  lockEndTime: number | null;
  onProceedFromAlert?: () => void;
  onProceedFromMotivation?: () => void;
  onSubmitApology?: (msg: string) => void;
}

export default function GeniePenaltyModal({ suspiciousPhase, lockEndTime, onProceedFromAlert, onProceedFromMotivation, onSubmitApology }: Props) {
  const [apology, setApology] = useState('');
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [error, setError] = useState(false);
  const [funnyMessage, setFunnyMessage] = useState("");

  useEffect(() => {
    const msgs = [
      "Bro... even superheroes need time.",
      "You're training buttons.",
      "Physics disagrees.",
      "Nice try 😏",
      "Genie is not convinced."
    ];
    setFunnyMessage(msgs[Math.floor(Math.random() * msgs.length)]);
  }, []);

  useEffect(() => {
    if (suspiciousPhase === 'locked' && lockEndTime) {
      const updateTime = () => {
        const remaining = Math.max(0, Math.ceil((lockEndTime - Date.now()) / 1000));
        setTimeLeft(remaining);
      };
      updateTime();
      const interval = setInterval(updateTime, 1000);
      return () => clearInterval(interval);
    }
  }, [suspiciousPhase, lockEndTime]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (apology.trim().toLowerCase() === "sorry") {
      onSubmitApology?.(apology);
      setError(false);
    } else {
      setError(true);
    }
  };

  return (
    <div className="fixed inset-0 z-[1000] bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center p-6 text-center">
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="max-w-sm w-full bg-[#050B1A] border border-red-500/30 rounded-3xl p-8 relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 right-0 h-1 bg-red-500 animate-pulse" />

        {(suspiciousPhase === 'alert' || suspiciousPhase === 'locked') && (
          <div className="space-y-6">
            <div className="flex justify-center mb-4">
              <div className="w-20 h-20 rounded-full relative flex items-center justify-center shadow-[0_0_20px_rgba(239,68,68,0.6),inset_0_0_20px_rgba(239,68,68,0.6)] bg-black">
                <div className="flex gap-2 z-20">
                  <div className="w-2.5 h-4 bg-white rounded-full shadow-[0_0_10px_white] transform rotate-12 scale-y-[0.4]" />
                  <div className="w-2.5 h-4 bg-white rounded-full shadow-[0_0_10px_white] transform -rotate-12 scale-y-[0.4]" />
                </div>
              </div>
            </div>
            <div>
              <h2 className="text-2xl font-black text-red-500 tracking-wider mb-2 uppercase">
                GENIE IS SUSPICIOUS
              </h2>
              <p className="text-neutral-300 font-medium text-lg leading-relaxed">
                {funnyMessage}
              </p>
            </div>

            {suspiciousPhase === 'locked' ? (
              <div className="bg-red-500/10 rounded-2xl p-6 border border-red-500/20">
                <Lock className="w-8 h-8 text-red-400 mx-auto mb-3" />
                <p className="text-red-400 font-bold mb-1">Cooldown Active</p>
                <p className="text-3xl font-black text-white font-mono">
                  {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
                </p>
              </div>
            ) : (
              <button
                onClick={onProceedFromAlert}
                className="w-full bg-red-500 hover:bg-red-600 text-white font-black py-4 rounded-xl uppercase tracking-widest active:scale-95 transition-all"
              >
                I Understand
              </button>
            )}
          </div>
        )}

        {suspiciousPhase === 'apology' && (
          <div className="space-y-6">
            <MessageSquare className="w-20 h-20 text-red-500 mx-auto" />
            <div>
              <h2 className="text-2xl font-black text-red-500 tracking-wider mb-2 uppercase">Prove Your Honor</h2>
              <p className="text-neutral-400 font-medium text-sm">
                Type <strong className="text-white">sorry</strong> below to unlock the challenge.
              </p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                value={apology}
                onChange={(e) => setApology(e.target.value)}
                placeholder="sorry"
                className={`w-full bg-black/50 border ${error ? 'border-red-500' : 'border-neutral-800'} rounded-xl px-5 py-4 text-center font-mono text-white uppercase outline-none focus:border-red-500 transition-colors`}
              />
              <button
                type="submit"
                className="w-full bg-red-500 hover:bg-red-600 text-white font-black py-4 rounded-xl flex items-center justify-center gap-2 uppercase tracking-widest active:scale-95 transition-all"
              >
                <span>Confirm</span>
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}

        {suspiciousPhase === 'motivation' && (
          <div className="space-y-6">
            <Shield className="w-20 h-20 text-brand-accent mx-auto" />
            <div>
              <h2 className="text-2xl font-black text-white tracking-wider mb-2 uppercase">Honor Restored</h2>
              <p className="text-brand-accent font-medium text-lg">
                Sorry accepted Boss. Next time cheat mat karna 💪
              </p>
            </div>
            <button
              onClick={onProceedFromMotivation}
              className="w-full bg-brand-accent text-black font-black py-4 rounded-xl uppercase tracking-widest active:scale-95 transition-all"
            >
              Start Training
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
