import { doc, getDoc, setDoc, onSnapshot, collection, increment } from '../lib/firestore';
import { db } from '../lib/firebase';
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Swords, Award, Play, CheckCircle2, Lock, Unlock, 
  Settings, Flame, ArrowRight, Video, Target, Sparkles, 
  BookOpen, Trophy, ShieldAlert, HelpCircle, 
  RotateCcw, Save, ShieldCheck, Heart
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useAuth } from "../context/AuthContext";
import { useGuardianContext } from "../context/GuardianContext";


import { playSound } from "../utils/audio";
import { useLocalStorageSync } from "../hooks/useLocalStorageSync";
import InteractiveBody from "./InteractiveBody";
import { GlobalCompletionCounter, incrementCompletionCount } from "./GlobalCompletionCounter";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";

// Types
export interface MartialLesson {
  id: string;
  category: "Karate" | "Taekwondo" | "Kung Fu" | "Muay Thai" | "Boxing" | "Kickboxing" | "Judo" | "Brazilian Jiu-Jitsu (BJJ)" | "Wrestling";
  level: "Beginner" | "Intermediate" | "Advanced";
  name: string;
  description: string;
  benefits: string;
  tips: string;
  xpReward: number;
}

interface UserProgress {
  completed: Record<string, boolean>;
  streak: number;
  lastCompletedDate: string; // YYYY-MM-DD
}

export const MARTIAL_LESSONS_MUSCLES: Record<string, string[]> = {
  // Karate
  karate_b_1: ["core", "shoulders", "legs", "triceps", "arms"],
  karate_i_1: ["legs", "core", "quadriceps", "calves"],
  karate_a_1: ["legs", "hips", "glutes", "core"],
  // Taekwondo
  tkd_b_1: ["legs", "quadriceps", "hips", "calves"],
  tkd_i_1: ["legs", "core", "abs", "obliques"],
  tkd_a_1: ["legs", "core", "calves", "glutes"],
  // Kung Fu
  kungfu_b_1: ["legs", "quadriceps", "core", "shoulders"],
  kungfu_i_1: ["full body", "shoulders", "legs", "core"],
  kungfu_a_1: ["core", "legs", "glutes", "back"],
  // Muay Thai
  muay_b_1: ["full body", "shoulders", "legs", "arms"],
  muay_i_1: ["shoulders", "neck", "core", "arms"],
  muay_a_1: ["legs", "shins", "core", "shoulders"],
  // Boxing
  box_b_1: ["shoulders", "core", "arms", "triceps"],
  box_i_1: ["legs", "quadriceps", "hamstrings", "core"],
  box_a_1: ["full body", "shoulders", "arms", "cardio"],
  // Kickboxing
  kick_b_1: ["legs", "shoulders", "arms", "quadriceps"],
  kick_i_1: ["legs", "shins", "core", "shoulders"],
  kick_a_1: ["core", "shoulders", "legs", "arms"],
  // Judo
  judo_b_1: ["core", "back", "shoulders", "legs"],
  judo_i_1: ["core", "back", "hips", "legs"],
  judo_a_1: ["full body", "back", "shoulders", "core"],
  // BJJ
  bjj_b_1: ["core", "hips", "shoulders", "legs"],
  bjj_i_1: ["core", "obliques", "hips", "back"],
  bjj_a_1: ["arms", "shoulders", "grip", "core"],
  // Wrestling
  wres_b_1: ["legs", "quadriceps", "glutes", "core", "neck"],
  wres_i_1: ["core", "hips", "back", "legs"],
  wres_a_1: ["shoulders", "core", "back", "legs"]
};

// Full Lesson Data
export const MARTIAL_LESSONS: MartialLesson[] = [
  // Karate
  {
    id: "karate_b_1",
    category: "Karate",
    level: "Beginner",
    name: "Choku Zuki & Maegeri Foundation",
    description: "Learn the absolute essentials of the karate straight punch (Choku Zuki) and basic front kick (Maegeri) from a classic Zenkutsu-dachi stance.",
    benefits: "Develops core rotation strength, leg alignment balance, and fast kinetic snapping reflexes.",
    tips: "Keep your heel firmly grounded on your supporting leg during the kick, and snap the fist flat at the final instant of the punch.",
    xpReward: 120
  },
  {
    id: "karate_i_1",
    category: "Karate",
    level: "Intermediate",
    name: "Heian Shodan Kata Movements",
    description: "Master the low blocks, stepping head punches, and body transitions of Heian Shodan, the first fundamental karate form.",
    benefits: "Builds spatial awareness, spatial patterns rhythm, low posture stamina, and rotational power.",
    tips: "Tension and relaxation must alternate. Breathe deeply into the lower dantian as you step.",
    xpReward: 200
  },
  {
    id: "karate_a_1",
    category: "Karate",
    level: "Advanced",
    name: "Mawashi Geri Roundhouse Combo",
    description: "Perfect the fast offensive Mawashi Geri (Roundhouse Kick) followed instantly by a reverse punch counter-attack.",
    benefits: "Increases dynamic flexibility, hip opening, balance recovery, and sparring transition speed.",
    tips: "Pivot your support foot 180 degrees backwards during the hip opening phase of the roundhouse kick to prevent knee strains.",
    xpReward: 280
  },

  // Taekwondo
  {
    id: "tkd_b_1",
    category: "Taekwondo",
    level: "Beginner",
    name: "Ap Chagi (Front Snap Kick)",
    description: "Formulate physical muscle memory for the primary Taekwondo front snap kick, executing knee chambering and ankle hyper-extension.",
    benefits: "Strengthens knee joints, quadriceps flexibility, and speeds up groin-level defensive kicking.",
    tips: "Pull your toes backward at the moment of strike to hit with the ball of the foot (Apkumchi).",
    xpReward: 120
  },
  {
    id: "tkd_i_1",
    category: "Taekwondo",
    level: "Intermediate",
    name: "Dollyo Chagi (Roundhouse Drill)",
    description: "Apply quick hip-turning action to execute Dollyo Chagi (Roundhouse Kick) aiming for the mid-section or the head area.",
    benefits: "Engages abdominal obliques, builds balance stamina, and optimizes high-reach hitting ability.",
    tips: "Do not rush. Lift the knee up front before turning your hips sideways into the kick trajectory.",
    xpReward: 200
  },
  {
    id: "tkd_a_1",
    category: "Taekwondo",
    level: "Advanced",
    name: "Tornado Kick & Spin Hooks",
    description: "Build coordination for the jump-spinning 360-degree roundhouse tornado kick (Narae Chagi) with stable balance landing.",
    benefits: "Generates massive rotational power, athletic elevation, and highly active leg speed.",
    tips: "Your gaze must rotate first. Look at your target before your kicking foot leaves the air.",
    xpReward: 280
  },

  // Kung Fu
  {
    id: "kungfu_b_1",
    category: "Kung Fu",
    level: "Beginner",
    name: "Ma Bu (Horse Stance) & Punching",
    description: "Master Ma Bu, the ultimate leg-strengthening Horse Stance, while executing symmetrical straight punches with perfect chest posture.",
    benefits: "Builds absolute leg durability, focus, grounding stability, and isometric hip power.",
    tips: "Keep your thighs parallel to the ground if possible, look straight ahead, and pull your resting elbow backward near your waist.",
    xpReward: 130
  },
  {
    id: "kungfu_i_1",
    category: "Kung Fu",
    level: "Intermediate",
    name: "Shaolin Five Animals Forms",
    description: "Introduction to Tiger, Crane, Leopard, Snake, and Dragon combat movements and breathing tactics.",
    benefits: "Improves fluid joint flexibility, multi-directional muscle coordination, and dynamic flow.",
    tips: "Imitate the spirit of the animal; Tiger is heavy and strong, while Crane is light, poised, and balanced.",
    xpReward: 210
  },
  {
    id: "kungfu_a_1",
    category: "Kung Fu",
    level: "Advanced",
    name: "Wushu Butterfly Kick Sequence",
    description: "Learn the high acrobatic butterfly kick (Xuan Feng Jiao) utilizing horizontal torso rotation and dual-leg weight transitions.",
    benefits: "Elite level core stability, jumping height, and dynamic kinetic control.",
    tips: "Lower your chest facing the ground during key windup, then kick upward with your back leg to create flight.",
    xpReward: 300
  },

  // Muay Thai
  {
    id: "muay_b_1",
    category: "Muay Thai",
    level: "Beginner",
    name: "The Basic Eight Limbs Strikes",
    description: "Understand basic boxing punches, leg roundhouse kicks, diagonal knees, and sharp elbow strikes from a Muay Thai stance.",
    benefits: "Comprehensive full body physical conditioning and simple self-defense readiness.",
    tips: "Keep your hands up high near your forehead to protect your temple and chin from head kicks.",
    xpReward: 140
  },
  {
    id: "muay_i_1",
    category: "Muay Thai",
    level: "Intermediate",
    name: "Clinch & Knee Sweep Mechanics",
    description: "Learn the plum (clinch collar tie) to control your opponent's head and deliver close-range diagonal knee strikes.",
    benefits: "Develops shoulder endurance, neck grip strength, and close contact balance control.",
    tips: "Never pull your opponent by their neck using only hand muscles; use your weight and core rotation instead.",
    xpReward: 220
  },
  {
    id: "muay_a_1",
    category: "Muay Thai",
    level: "Advanced",
    name: "Teep Kick & Roundhouse Countering",
    description: "Master defensive lead-foot Teep (push kicks) and perfect blocking and instantly countering an opponent's roundhouse.",
    benefits: "Develops elite range management, leg checks conditioning, and match-winning reflexes.",
    tips: "When checking a roundhouse kick, raise your shin at a 45-degree angle outward to maximize bone-structure resistance.",
    xpReward: 290
  },

  // Boxing
  {
    id: "box_b_1",
    category: "Boxing",
    level: "Beginner",
    name: "The Jab & Cross Foundation",
    description: "Establish defensive boxing stance, footwork steps (step-and-slide), and execute the Jab (1) and Cross (2).",
    benefits: "High cardio burning, core-rotational punch speed, and shoulder definition.",
    tips: "Keep your non-punching glove glued to your chin, and rotate your back foot fully during the cross punch.",
    xpReward: 120
  },
  {
    id: "box_i_1",
    category: "Boxing",
    level: "Intermediate",
    name: "Slipping, Rolling & Counters",
    description: "Learn defense mechanics: Slipping left/right, rolling underneath hooks, and counter-punching instantly from the slip.",
    benefits: "Superb head movement reflexes, hamstring/quadriceps agility, and precise counters.",
    tips: "Do not bend at your waist to slip punches; bend your knees slightly to move your head off the center-line.",
    xpReward: 190
  },
  {
    id: "box_a_1",
    category: "Boxing",
    level: "Advanced",
    name: "12-Punch Padwork Workout Flow",
    description: "Perform advanced combination flows: Jab-cross-hook-slip-cross-roll-uppercut-hook-cross with high speed.",
    benefits: "Extreme muscular endurance, focus, and realistic combat sparring rhythms.",
    tips: "Exhale sharply on every punch to sustain peak breathing endurance.",
    xpReward: 270
  },

  // Kickboxing
  {
    id: "kick_b_1",
    category: "Kickboxing",
    level: "Beginner",
    name: "Jab-Cross-Roundhouse Combo",
    description: "Combine standard boxing hands with Dutch style low/mid roundhouse kicks to create continuous offensive strings.",
    benefits: "Improves transition from hands to legs, builds leg flexibility and high-intensity stamina.",
    tips: "Step slightly outward on forty-five degrees with your lead foot to make space for your hips during the low roundhouse kick.",
    xpReward: 130
  },
  {
    id: "kick_i_1",
    category: "Kickboxing",
    level: "Intermediate",
    name: "Deflecting Kicking Counters",
    description: "Learn low-kick checking, catching body kicks, and sweeping the support leg as an instant response.",
    benefits: "Reduces strike impact damage, enhances counter speed, and improves stand-up confidence.",
    tips: "Always absorb body-kick impact by side-stepping slightly rather than standing completely static.",
    xpReward: 200
  },
  {
    id: "kick_a_1",
    category: "Kickboxing",
    level: "Advanced",
    name: "Spin Backfist & High Kick Combo",
    description: "Connect a heavy spinning backfist to high lead-leg switch kicking patterns to capture opponents off guard.",
    benefits: "Develops 360-degree rotational balance, visual tracking speed, and athletic agility.",
    tips: "When spinning, look over your shoulder at your target first to guide your backfist strike safely.",
    xpReward: 280
  },

  // Judo
  {
    id: "judo_b_1",
    category: "Judo",
    level: "Beginner",
    name: "Ukemi — Breakfalls & Forward Rolls",
    description: "Learn how to land safely on the tatami mat without hurting your joints using custom back and side breakfalls.",
    benefits: "Protects your brain, spine, and joints from impact damage. Essential foundation for throw-heavy martial arts.",
    tips: "Tuck your chin firmly into your chest during breakfalls so your head never contacts the ground.",
    xpReward: 120
  },
  {
    id: "judo_i_1",
    category: "Judo",
    level: "Intermediate",
    name: "O-Goshi — Major Hip Throw",
    description: "Understand Kuzushi (unbalancing your opponent), Tsukuri (fitting in your hip), and Kake (completing the throw).",
    benefits: "Builds leverage mechanics, core lifting strength, and throwing coordination.",
    tips: "Your hips must go slightly lower than your opponent's hips to serve as a solid pivot point for the throw.",
    xpReward: 200
  },
  {
    id: "judo_a_1",
    category: "Judo",
    level: "Advanced",
    name: "Ippon Seoi Nage & Pins",
    description: "Execute the classic deep one-arm shoulder throw (Ippon Seoi Nage) transitioning directly into a Kesa-Gatame scarf hold.",
    benefits: "Elite level kinetic leverage, full body fluid transitions, and pinning dominance.",
    tips: "Pull your opponent's sleeve tightly to your chest throughout the entry to prevent them from landing on your head.",
    xpReward: 280
  },

  // BJJ
  {
    id: "bjj_b_1",
    category: "Brazilian Jiu-Jitsu (BJJ)",
    level: "Beginner",
    name: "The Guard, Mount & Side Control",
    description: "Learn how to navigate and maintain the fundamental ground control positions and survive underneath on the mat.",
    benefits: "Engages full-body spatial wrestling intelligence and core isometric strength.",
    tips: "Keep your elbows close to your ribs to prevent opponents from easily searching for arm locks.",
    xpReward: 120
  },
  {
    id: "bjj_i_1",
    category: "Brazilian Jiu-Jitsu (BJJ)",
    level: "Intermediate",
    name: "Hip Escape & Guard Recovery",
    description: "Master 'shrimping' – the primary hip escapement technique used to recover guard when pinned under side control.",
    benefits: "Exceptional core endurance, hip agility, and defensive ground movement.",
    tips: "Frame your hands against your opponent's neck and hips to create structural space before moving your buttocks out.",
    xpReward: 200
  },
  {
    id: "bjj_a_1",
    category: "Brazilian Jiu-Jitsu (BJJ)",
    level: "Advanced",
    name: "Closed Guard Armbar & Kimura Lock",
    description: "Understand submission mechanics: Pulling armbars, isolating shoulder joints with the Kimura lock, and finishing safely.",
    benefits: "Teaches extreme focus, leverage of small muscles against large joints, and submission accuracy.",
    tips: "Pinch your knees together tightly on the armbar to stabilize their elbow joint before lifting your hips.",
    xpReward: 280
  },

  // Wrestling
  {
    id: "wres_b_1",
    category: "Wrestling",
    level: "Beginner",
    name: "Stance, Motion & Double Leg",
    description: "Acquire lower combat stance posture, level changes, and perform penetration steps for a double leg takedown.",
    benefits: "Excellent leg explosion drive, deep abdominal core strengthening, and take-down setups.",
    tips: "Never look down. Keep your neck upright and your chest glued to the opponent's thigh upon entry.",
    xpReward: 120
  },
  {
    id: "wres_i_1",
    category: "Wrestling",
    level: "Intermediate",
    name: "Sprawl Defense & Snapdown",
    description: "Perfect defensively throwing your legs backward (Sprawling) to stop double-leg shoots, converting into a snapdown control.",
    benefits: "Fast spinal expansion reflexes, core hip-down weight impact, and top control transition.",
    tips: "Drive your hips directly into the mat and lock their head with your chest weight to suffocate their shot.",
    xpReward: 200
  },
  {
    id: "wres_a_1",
    category: "Wrestling",
    level: "Advanced",
    name: "The Fireman's Carry Takedown",
    description: "Execute a beautiful overhead fireman's carry (Kata Guruma variant) leveraging their overhook directly onto your shoulders.",
    benefits: "Spectacular throwing leverage, timing coordination, and dynamic wrestling flair.",
    tips: "Pull their sleeve arm down tightly while punching your other arm deep between their legs to lift them weightlessly.",
    xpReward: 280
  }
];

export const DEFAULT_MARTIAL_VIDEO_URLS: Record<string, string> = {
  karate_b_1: "https://youtu.be/mC502f5JyXE",
  karate_i_1: "https://youtu.be/pJMewvBrGt0",
  karate_a_1: "https://youtu.be/DveiJQoHSeE",
  tkd_b_1: "https://youtu.be/xQsY0Ikjzao",
  tkd_i_1: "https://youtu.be/roOan4YVmBA",
  tkd_a_1: "https://youtu.be/NHnxJMn5jk0",
  kungfu_b_1: "https://youtu.be/MUNTBJJv-HE",
  kungfu_i_1: "https://youtu.be/XvexoOvsj9o",
  kungfu_a_1: "https://youtu.be/XSG-jiLxXmE",
  muay_b_1: "https://youtu.be/Vycn5rZQRpg",
  muay_i_1: "https://youtu.be/nq5zVFwolVI",
  muay_a_1: "https://youtu.be/3mnfzeo5ktw",
  box_b_1: "https://youtu.be/bpKppN8Y3t0",
  box_i_1: "https://youtu.be/RcYwobHGGUY",
  box_a_1: "https://youtu.be/9cf8FmoBmQU",
  kick_b_1: "https://youtu.be/2w3swSRu5ko",
  kick_i_1: "https://youtu.be/HpdF4OazPA8",
  kick_a_1: "https://youtu.be/NstNm_z5LP0",
  judo_b_1: "https://youtu.be/Y5PDXiXLj2g",
  judo_i_1: "https://youtu.be/5hjZ05NRKEQ",
  judo_a_1: "https://youtu.be/EG6hS00Qxqs",
  bjj_b_1: "https://youtu.be/yTdOuqJOhBo",
  bjj_i_1: "https://youtu.be/_IkDpa_ielg",
  bjj_a_1: "https://youtu.be/qHavQIk2PM8",
  wres_b_1: "https://youtu.be/6x5Bc834vOA",
  wres_i_1: "https://youtu.be/y-foHtIGYrw",
  wres_a_1: "https://youtu.be/woOAQ4BLWhY"
};

export default function MartialArts() {
  const { user, profile, updateProfileStats } = useAuth();
  const { reportSuspiciousActivity } = useGuardianContext();
  const lastLessonCompleteRef = useRef<number>(Date.now() - 8000);
  
  // States
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [selectedLevel, setSelectedLevel] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [expandedLessonId, setExpandedLessonId] = useState<string | null>(null);
  const [activeVideoLesson, setActiveVideoLesson] = useState<MartialLesson | null>(null);
  const [restTimerLeft, setRestTimerLeft] = useState<number | null>(null);
  const [practiceTimerLeft, setPracticeTimerLeft] = useState<number | null>(null);
  const [practiceDone, setPracticeDone] = useState<boolean>(false);

  useEffect(() => {
    setPracticeTimerLeft(null);
    setPracticeDone(false);
  }, [activeVideoLesson?.id]);

  useEffect(() => {
    if (practiceTimerLeft === null) return;
    if (practiceTimerLeft <= 0) {
      playSound("success");
      setPracticeTimerLeft(null);
      setPracticeDone(true);
      lastLessonCompleteRef.current = 0; // Unlock anti-cheat after genuine 30s practice
      return;
    }
    const tId = setInterval(() => {
      setPracticeTimerLeft(prev => (prev !== null && prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(tId);
  }, [practiceTimerLeft]);

  useEffect(() => {
    if (restTimerLeft === null) return;
    if (restTimerLeft <= 0) {
      playSound("rest_chime");
      setRestTimerLeft(null);
      return;
    }
    const timerId = setInterval(() => {
      setRestTimerLeft(prev => (prev ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timerId);
  }, [restTimerLeft]);
  
  // Real-time video URLs from Firestore Map
  const [videoUrls, setVideoUrls] = useState<Record<string, string>>({});
  
  // Admin-related states
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);
  const [adminLessonId, setAdminLessonId] = useState("");
  const [adminVideoUrl, setAdminVideoUrl] = useState("");
  const [adminStatus, setAdminStatus] = useState<string | null>(null);

  // User Martial Arts custom progress (synchronized and persisted in localStorage)
  const [progress, setProgress] = useLocalStorageSync<UserProgress>("fitgenie_martial_arts_progress", {
    completed: {},
    streak: 0,
    lastCompletedDate: ""
  });

  const [favorites, setFavorites] = useLocalStorageSync<string[]>("fitgenie_fav_videos", []);

  // Sync real-time Firestore database for exercise video mappings
  useEffect(() => {
    if (!user) return;
    const unsub = onSnapshot(collection(db, "martial_arts_videos"), (snapshot) => {
      const urlsMap: Record<string, string> = {};
      snapshot.forEach((d) => {
        urlsMap[d.id] = d.data().youtubeUrl || "";
      });
      setVideoUrls(urlsMap);
    }, (error) => {
      const errMsg = error instanceof Error ? error.message : String(error);
      if (!errMsg.includes("the client is offline")) {
        console.warn("Martial arts videos sync error:", error);
      }
    });
    return unsub;
  }, [user]);

  // Helper to save progress
  const saveProgress = (newProgress: UserProgress) => {
    setProgress(newProgress);
  };

  // Mark lesson complete handle (Protected by Orb Anti-Cheat)
  const handleMarkComplete = (lesson: MartialLesson) => {
    const now = Date.now();
    const elapsedSec = (now - lastLessonCompleteRef.current) / 1000;

    if (elapsedSec < 10) {
      reportSuspiciousActivity(
        `${lesson.name} (${lesson.category}) sirf ${Math.max(1, Math.round(elapsedSec))}s me complete? Bina drill practice kiye XP spam mat karo bro! 🛑`,
        "critical"
      );
      return;
    }

    lastLessonCompleteRef.current = now;
    playSound("success");
    incrementCompletionCount(lesson.name);
    
    const todayStr = new Date().toISOString().split("T")[0];
    const isAlreadyCompleted = progress.completed[lesson.id];
    
    // Calculate new streak
    let currentStreak = progress.streak;
    let lastDate = progress.lastCompletedDate;
    
    if (lastDate === "") {
      currentStreak = 1;
    } else {
      const last = new Date(lastDate);
      const today = new Date(todayStr);
      const diffTime = Math.abs(today.getTime() - last.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays === 1) {
        currentStreak += 1;
      } else if (diffDays > 1) {
        currentStreak = 1; // broken streak
      }
      // if diffDays === 0, keep streak unchanged
    }

    const updatedCompleted = {
      ...progress.completed,
      [lesson.id]: true
    };

    const newProgress = {
      completed: updatedCompleted,
      streak: currentStreak,
      lastCompletedDate: todayStr
    };

    saveProgress(newProgress);

    // Call Global Auth Context update stats to add XP and increase workout logs!
    if (profile) {
      updateProfileStats({
        xpGained: lesson.xpReward,
        workoutCompleted: true,
        completedWorkoutName: `Martial Arts: ${lesson.category} - ${lesson.name}`
      });
    }
  };

  // Reset lesson status
  const handleResetLesson = (lessonId: string) => {
    playSound("click");
    const updatedCompleted = { ...progress.completed };
    delete updatedCompleted[lessonId];
    saveProgress({
      ...progress,
      completed: updatedCompleted
    });
  };

  // Admin submit url handler
  const handleAdminSubmitUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminLessonId) {
      setAdminStatus("Please select a lesson first.");
      return;
    }
    if (!adminVideoUrl) {
      setAdminStatus("Please specify a YouTube URL.");
      return;
    }

    setAdminStatus("Uploading...");
    try {
      const newUrls = { ...videoUrls, [adminLessonId]: adminVideoUrl };
      setVideoUrls(newUrls);
      localStorage.setItem("fitgenie_martial_arts_videos", JSON.stringify(newUrls));
      playSound("success");
      setAdminStatus("Successfully linked!");
      setAdminVideoUrl("");
      setTimeout(() => setAdminStatus(null), 3000);
    } catch (err) {
      setAdminStatus("Error writing to database.");
      console.error(err);
    }
  };

  // Parse Youtube video ID securely
  function getYouTubeId(url: string | undefined): string | null {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2] && match[2].length === 11) ? match[2] : null;
  }

  // Filter lessons
  const filteredLessons = MARTIAL_LESSONS.filter((l) => {
    const matchesCat = selectedCategory === "All" || l.category === selectedCategory;
    const matchesLevel = selectedLevel === "All" || l.level === selectedLevel;
    
    // Retrieve custom muscle groups for this lesson
    const muscles = MARTIAL_LESSONS_MUSCLES[l.id] || [];
    const query = searchQuery.toLowerCase().trim();
    
    const matchesSearch = query === "" || 
      l.name.toLowerCase().includes(query) ||
      l.description.toLowerCase().includes(query) ||
      l.category.toLowerCase().includes(query) ||
      l.benefits.toLowerCase().includes(query) ||
      muscles.some(m => m.toLowerCase().includes(query));

    return matchesCat && matchesLevel && matchesSearch;
  });

  // Calculate stats
  const totalCount = MARTIAL_LESSONS.length;
  const completedCount = Object.keys(progress.completed).length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 105) : 0; // mapped beautiful visual scale
  const finalPercent = Math.min(100, Math.round((completedCount / totalCount) * 100));

  // Category counts
  const getCompletedCountForCat = (cat: string) => {
    return MARTIAL_LESSONS.filter(l => l.category === cat && progress.completed[l.id]).length;
  };
  const getTotalCountForCat = (cat: string) => {
    return MARTIAL_LESSONS.filter(l => l.category === cat).length;
  };

  // Achievements Definition & Progression Tracker
  const ACHIEVEMENTS = [
    {
      id: "white_belt",
      title: "White Belt Initiate",
      desc: "Complete your very first martial arts instruction lesson.",
      icon: "🥋",
      unlocked: completedCount >= 1,
      progress: Math.min(1, completedCount) * 100,
      text: "1/1 lessons"
    },
    {
      id: "striker",
      title: "Hard Striker",
      desc: "Complete 5 lessons across striking: Boxing, Kickboxing, Karate, Taekwondo, Kung Fu, Muay Thai.",
      icon: "🥊",
      unlocked: MARTIAL_LESSONS.filter(l => ["Boxing", "Kickboxing", "Karate", "Taekwondo", "Kung Fu", "Muay Thai"].includes(l.category) && progress.completed[l.id]).length >= 5,
      progress: Math.min(5, MARTIAL_LESSONS.filter(l => ["Boxing", "Kickboxing", "Karate", "Taekwondo", "Kung Fu", "Muay Thai"].includes(l.category) && progress.completed[l.id]).length) * 20,
      text: `${MARTIAL_LESSONS.filter(l => ["Boxing", "Kickboxing", "Karate", "Taekwondo", "Kung Fu", "Muay Thai"].includes(l.category) && progress.completed[l.id]).length}/5 striking complete`
    },
    {
      id: "grappler",
      title: "Tactical Grappler",
      desc: "Complete 3 grappling lessons across Wrestling, Judo, and Brazilian Jiu-Jitsu (BJJ).",
      icon: "🤼",
      unlocked: MARTIAL_LESSONS.filter(l => ["Wrestling", "Judo", "Brazilian Jiu-Jitsu (BJJ)"].includes(l.category) && progress.completed[l.id]).length >= 3,
      progress: Math.min(3, MARTIAL_LESSONS.filter(l => ["Wrestling", "Judo", "Brazilian Jiu-Jitsu (BJJ)"].includes(l.category) && progress.completed[l.id]).length) * 33.3,
      text: `${MARTIAL_LESSONS.filter(l => ["Wrestling", "Judo", "Brazilian Jiu-Jitsu (BJJ)"].includes(l.category) && progress.completed[l.id]).length}/3 grappling complete`
    },
    {
      id: "streak_3",
      title: "Daily Dojo Devotion",
      desc: "Sustain a 3-Day martial arts streak tracking daily workouts.",
      icon: "🔥",
      unlocked: progress.streak >= 3,
      progress: Math.min(3, progress.streak) * 33.3,
      text: `${progress.streak}/3 days`
    },
    {
      id: "grandmaster",
      title: "Fit Genie Grandmaster",
      desc: "Unlock lessons and complete all 27 techniques in the library definitions.",
      icon: "👑",
      unlocked: completedCount >= totalCount,
      progress: finalPercent,
      text: `${completedCount}/${totalCount} total`
    }
  ];

  const categoriesList = [
    "All", "Karate", "Taekwondo", "Kung Fu", "Muay Thai", "Boxing", "Kickboxing", "Judo", "Brazilian Jiu-Jitsu (BJJ)", "Wrestling"
  ];

  return (
    <div className="py-8 px-4 md:px-8 max-w-[1400px] mx-auto space-y-10 select-none text-white font-sans" id="martial-arts-module">
      
      {/* 1) HERO SECTION - Elite Dojo Banner */}
      <div className="relative rounded-3xl bg-gradient-to-br from-[#050B1A] to-[#0A1020] border border-[#14F1E1]/20 p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-8 overflow-hidden shadow-[0_0_40px_rgba(20,241,225,0.05)]">
        {/* Abstract Glow Effects */}
        <div className="absolute -top-20 -left-20 w-64 h-64 bg-[#14F1E1]/10 rounded-full blur-[80px] pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-[#B66DFF]/10 rounded-full blur-[80px] pointer-events-none" />

        <div className="space-y-5 text-center md:text-left relative z-10 flex-1">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#14F1E1]/10 border border-[#14F1E1]/30 rounded-full">
            <Swords className="w-4 h-4 text-[#14F1E1]" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#14F1E1]">Elite Training Ground</span>
          </div>
          
          <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter text-white leading-none drop-shadow-md">
            Martial <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#14F1E1] to-[#4DA8FF]">Arts</span>
          </h2>
          
          <p className="text-sm md:text-base text-neutral-400 font-medium leading-relaxed max-w-2xl">
            Welcome to the Fit Genie Dojo. Master traditional styles, standup sparring strikes, and heavy grappling leverage. Each lesson is stacked with safety tips and dynamic video coaching.
          </p>

          {/* Quick Stats Grid */}
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 pt-2">
            <div className="bg-white/5 border border-white/10 rounded-2xl px-5 py-3 backdrop-blur-sm shadow-inner flex items-center gap-4">
              <div className="p-2 bg-[#14F1E1]/20 rounded-xl">
                <Target className="w-5 h-5 text-[#14F1E1]" />
              </div>
              <div className="text-left">
                <span className="block text-[9px] font-bold text-neutral-500 uppercase tracking-widest">Completed</span>
                <span className="text-lg font-black text-white">{completedCount} / {totalCount}</span>
              </div>
            </div>
            
            <div className="bg-white/5 border border-white/10 rounded-2xl px-5 py-3 backdrop-blur-sm shadow-inner flex items-center gap-4">
              <div className="p-2 bg-orange-500/20 rounded-xl relative">
                <Flame className="w-5 h-5 text-orange-500 animate-pulse" />
              </div>
              <div className="text-left">
                <span className="block text-[9px] font-bold text-neutral-500 uppercase tracking-widest">Active Streak</span>
                <span className="text-lg font-black text-white">{progress.streak} Days</span>
              </div>
            </div>
          </div>
        </div>

        {/* Big Visual Progress Dial Gauge */}
        <div className="relative w-40 h-40 shrink-0 flex items-center justify-center bg-black/40 border border-white/10 rounded-full backdrop-blur-md shadow-[0_0_30px_rgba(20,241,225,0.15)] z-10" id="martial-arts-gauge">
          <div className="absolute inset-2.5 rounded-full border border-white/5 bg-[#050B1A] shadow-inner flex flex-col items-center justify-center">
            <span className="text-[9px] font-black text-neutral-500 uppercase tracking-widest">Dojo Path</span>
            <span className="text-3xl font-black text-white tracking-tighter mt-1">{finalPercent}%</span>
          </div>

          <svg className="absolute inset-0 w-full h-full transform -rotate-90 drop-shadow-[0_0_10px_rgba(20,241,225,0.5)]">
            <circle cx="80" cy="80" r="74" stroke="rgba(255,255,255,0.05)" strokeWidth="6" fill="transparent" />
            <circle
              cx="80" cy="80" r="74"
              stroke="#14F1E1" strokeWidth="6" fill="transparent"
              strokeDasharray={465}
              strokeDashoffset={465 - (465 * finalPercent) / 100}
              strokeLinecap="round"
              className="transition-all duration-1000 ease-out"
            />
          </svg>
        </div>
      </div>

      {/* Grid: Left - Lessons Library, Right - Stats and Badges */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* LEFT COLUMN: LESSONS LIBRARY (SPAN 2) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Glassmorphic Filters & Search Row */}
          <div className="bg-white/5 border border-white/10 rounded-3xl p-5 backdrop-blur-xl shadow-xl space-y-5">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-grow">
                <input
                  type="text"
                  placeholder="Search techniques, muscles or tips..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-2xl pl-11 pr-4 py-3.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-[#14F1E1]/50 transition-all focus:ring-1 focus:ring-[#14F1E1]/50 font-medium"
                />
                <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>

              <div className="flex gap-2 shrink-0 bg-black/40 p-1.5 border border-white/10 rounded-2xl">
                {["All", "Beginner", "Intermediate", "Advanced"].map((lv) => (
                  <button
                    key={lv}
                    onClick={() => { playSound("click"); setSelectedLevel(lv); }}
                    className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                      selectedLevel === lv
                        ? "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_15px_rgba(20,241,225,0.4)]"
                        : "text-neutral-400 hover:text-white hover:bg-white/5"
                    }`}
                  >
                    {lv}
                  </button>
                ))}
              </div>
            </div>

            {/* Premium Category Tabs */}
            <div className="space-y-2">
              <span className="block text-[9px] font-black text-neutral-500 uppercase tracking-[0.2em] ml-1">
                Combat Disciplines
              </span>
              <div className="flex gap-3 overflow-x-auto pb-3 scrollbar-none snap-x" id="combat-style-scroller">
                {categoriesList.map((cat) => {
                  const comp = getCompletedCountForCat(cat);
                  const tot = getTotalCountForCat(cat);
                  const isSelected = selectedCategory === cat;
                  
                  return (
                    <button
                      key={cat}
                      onClick={() => { playSound("click"); setSelectedCategory(cat); }}
                      className={`snap-start shrink-0 px-5 py-3 rounded-2xl border transition-all flex items-center gap-2 ${
                        isSelected
                          ? "bg-[#14F1E1]/10 border-[#14F1E1]/50 text-[#14F1E1] shadow-[0_0_20px_rgba(20,241,225,0.1)]"
                          : "bg-black/20 border-white/5 text-neutral-400 hover:bg-white/5 hover:text-white hover:border-white/10"
                      }`}
                    >
                      <Sparkles className={`w-3.5 h-3.5 ${isSelected ? 'text-[#14F1E1]' : 'opacity-50'}`} />
                      <span className="text-[11px] font-black uppercase tracking-widest">{cat}</span>
                      {cat !== "All" && (
                        <span className={`ml-2 text-[9px] px-2 py-0.5 rounded-lg font-bold ${isSelected ? 'bg-[#14F1E1]/20 text-[#14F1E1]' : 'bg-white/10 text-neutral-300'}`}>
                          {comp}/{tot}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Video Lesson Cards Stack */}
          <div className="flex flex-col gap-5">
            <h3 className="text-[11px] font-black uppercase text-neutral-400 tracking-[0.2em] flex items-center gap-2 ml-1">
              <BookOpen className="w-4 h-4 text-[#14F1E1]" /> Training Library <span className="text-neutral-600">({filteredLessons.length} Modules)</span>
            </h3>

            <AnimatePresence mode="popLayout">
              {filteredLessons.length === 0 ? (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-16 text-center border border-white/5 rounded-3xl bg-white/5 backdrop-blur-sm">
                  <Trophy className="w-12 h-12 text-neutral-600 mx-auto mb-4" />
                  <p className="text-sm text-neutral-300 font-bold mb-1">No techniques found</p>
                  <p className="text-xs text-neutral-500">Try adjusting your filters or search terms.</p>
                </motion.div>
              ) : (
                filteredLessons.map((lesson) => {
                  const isCompleted = progress.completed[lesson.id];
                  const customVideoUrl = videoUrls[lesson.id] || DEFAULT_MARTIAL_VIDEO_URLS[lesson.id] || "";
                  const finalVideoId = getYouTubeId(customVideoUrl);
                  const thumbnailUrl = finalVideoId ? `https://img.youtube.com/vi/${finalVideoId}/maxresdefault.jpg` : null;

                  return (
                    <motion.div
                      key={lesson.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.4, type: "spring", bounce: 0.3 }}
                      className={`relative overflow-hidden rounded-3xl cursor-pointer group transition-all duration-300 ${
                        isCompleted
                          ? "bg-gradient-to-r from-emerald-900/20 to-[#050B1A] border border-emerald-500/20 shadow-[0_0_20px_rgba(16,185,129,0.05)]"
                          : "bg-gradient-to-r from-[#0A1020] to-[#050B1A] border border-white/10 hover:border-[#14F1E1]/40 hover:shadow-[0_0_30px_rgba(20,241,225,0.1)]"
                      }`}
                      onClick={() => { playSound("click"); setActiveVideoLesson(lesson); }}
                    >
                      {/* Inner Layout */}
                      <div className="flex flex-col sm:flex-row p-4 gap-5 items-center">
                        
                        {/* 3D Combat Biomechanics Loop Preview */}
                        <div className="w-full sm:w-44 shrink-0">
                          <Exercise3DCharacterLoop
                            name={lesson.name}
                            muscles={MARTIAL_LESSONS_MUSCLES[lesson.id] || ["core"]}
                            category={lesson.category}
                            compact={true}
                            interactive={true}
                          />
                        </div>

                        {/* Content */}
                        <div className="flex-grow space-y-3 w-full">
                          {/* Tags */}
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-[9px] font-black uppercase tracking-widest text-neutral-300">
                              {lesson.category}
                            </span>
                            <span className={`px-2.5 py-1 rounded-lg border text-[9px] font-black uppercase tracking-widest flex items-center gap-1 ${
                              lesson.level === "Beginner" ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/20" :
                              lesson.level === "Intermediate" ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" :
                              "bg-red-500/10 text-red-400 border-red-500/20"
                            }`}>
                              {lesson.level === "Beginner" ? "🔰 Novice" : lesson.level === "Intermediate" ? "⚔️ Warrior" : "🔥 Elite"}
                            </span>
                            <span className="ml-auto text-[10px] font-black text-[#14F1E1] bg-[#14F1E1]/10 px-2.5 py-1 rounded-lg border border-[#14F1E1]/20">
                              +{lesson.xpReward} XP
                            </span>
                          </div>

                          {/* Titles */}
                          <div>
                            <h4 className="text-lg font-black text-white leading-tight group-hover:text-[#14F1E1] transition-colors">{lesson.name}</h4>
                            <p className="text-xs text-neutral-400 mt-1 line-clamp-2 leading-relaxed">{lesson.description}</p>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="hidden sm:flex shrink-0 px-2">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              playSound("click");
                              setFavorites(prev => prev.includes(lesson.id) ? prev.filter(id => id !== lesson.id) : [...prev, lesson.id]);
                            }}
                            className={`p-3 rounded-full border transition-all ${
                              favorites.includes(lesson.id) 
                                ? 'bg-rose-500/10 border-rose-500/30 text-rose-500' 
                                : 'bg-white/5 border-white/10 text-neutral-400 hover:text-white hover:bg-white/10'
                            }`}
                          >
                            <Heart className={`w-5 h-5 ${favorites.includes(lesson.id) ? 'fill-current' : ''}`} />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  );
                })
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* RIGHT COLUMN: STATS, BADGES, ADMIN */}
        <div className="space-y-6">
          
          {/* STATS MODULE */}
          <div className="bg-gradient-to-b from-white/5 to-transparent border border-white/10 rounded-3xl p-6 backdrop-blur-md">
            <h3 className="text-[11px] font-black uppercase text-white tracking-[0.2em] flex items-center gap-2 pb-4 border-b border-white/10 mb-5">
              <Trophy className="w-4 h-4 text-[#B66DFF]" /> Dojo Achievements
            </h3>

            <div className="space-y-4">
              {ACHIEVEMENTS.map((ach) => (
                <div 
                  key={ach.id}
                  className={`relative p-4 rounded-2xl border transition-all overflow-hidden ${
                    ach.unlocked 
                      ? "bg-[#B66DFF]/10 border-[#B66DFF]/30 shadow-[0_0_15px_rgba(182,109,255,0.05)]" 
                      : "bg-black/20 border-white/5 opacity-70"
                  }`}
                >
                  {ach.unlocked && <div className="absolute top-0 right-0 w-16 h-16 bg-[#B66DFF]/20 rounded-full blur-xl -mr-8 -mt-8" />}
                  
                  <div className="flex items-start gap-4 relative z-10">
                    <div className={`w-12 h-12 shrink-0 rounded-xl flex items-center justify-center text-2xl border ${
                      ach.unlocked ? "bg-[#B66DFF]/20 border-[#B66DFF]/40 text-[#B66DFF]" : "bg-white/5 border-white/10 text-neutral-600 grayscale"
                    }`}>
                      {ach.icon}
                    </div>

                    <div className="flex-1 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-black uppercase tracking-widest ${ach.unlocked ? 'text-white' : 'text-neutral-400'}`}>{ach.title}</span>
                      </div>
                      <p className="text-[10px] text-neutral-400 leading-snug">{ach.desc}</p>
                      
                      <div className="pt-2 space-y-1.5">
                        <div className="h-1.5 w-full bg-black/50 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all duration-1000 ${ach.unlocked ? 'bg-gradient-to-r from-[#B66DFF] to-[#14F1E1]' : 'bg-neutral-600'}`}
                            style={{ width: `${ach.progress}%` }}
                          />
                        </div>
                        <div className="flex justify-end">
                          <span className="text-[8px] font-black uppercase text-neutral-500 tracking-widest">{ach.text}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ADMIN CONFIG PANEL */}
          <div className="bg-gradient-to-b from-[#050B1A] to-transparent border border-white/10 rounded-3xl p-6 backdrop-blur-md">
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
              <h3 className="text-[11px] font-black uppercase text-white tracking-[0.2em] flex items-center gap-2">
                <Settings className="w-4 h-4 text-[#14F1E1] animate-spin-slow" /> Dojo Admin Panel
              </h3>
              <button
                onClick={() => { playSound("click"); setIsAdminPanelOpen(!isAdminPanelOpen); }}
                className="px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-[9px] font-black uppercase tracking-widest text-[#14F1E1] transition-all"
              >
                {isAdminPanelOpen ? "Close" : "Open"}
              </button>
            </div>

            <AnimatePresence>
              {isAdminPanelOpen && (
                <motion.form 
                  initial={{ opacity: 0, height: 0 }} 
                  animate={{ opacity: 1, height: 'auto' }} 
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-5 overflow-hidden"
                  onSubmit={handleAdminSubmitUrl}
                >
                  <div className="p-4 bg-[#14F1E1]/5 border border-[#14F1E1]/20 rounded-2xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-16 h-16 bg-amber-500/10 rounded-full blur-xl" />
                    <span className="text-[9px] font-black text-amber-400 uppercase tracking-[0.2em] flex items-center gap-1 mb-1">
                      <ShieldCheck className="w-3 h-3 text-[#14F1E1]" /> Cloud Sync Active
                    </span>
                    <p className="text-[10px] text-neutral-400 leading-relaxed font-medium">Link or replace video URLs in real-time. Changes go live instantly for all trainees.</p>
                  </div>

                  <div className="space-y-2 text-left">
                    <label className="text-[9px] font-black text-neutral-500 uppercase tracking-widest">Select Target Lesson</label>
                    <select
                      value={adminLessonId}
                      onChange={(e) => setAdminLessonId(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-[#14F1E1] font-medium"
                    >
                      <option value="">-- Choose Lesson --</option>
                      {MARTIAL_LESSONS.map((l) => (
                        <option key={l.id} value={l.id}>[{l.category}] - {l.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2 text-left">
                    <label className="text-[9px] font-black text-neutral-500 uppercase tracking-widest">YouTube Video URL</label>
                    <input
                      type="text"
                      placeholder="https://youtu.be/..."
                      value={adminVideoUrl}
                      onChange={(e) => setAdminVideoUrl(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#14F1E1] font-mono"
                    />
                  </div>

                  {adminStatus && (
                    <div className={`p-3 rounded-xl text-[10px] font-black uppercase tracking-widest text-center ${adminStatus.includes('Error') ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'}`}>
                      {adminStatus}
                    </div>
                  )}

                  <button type="submit" disabled={false} className="w-full py-3.5 bg-gradient-to-r from-[#14F1E1] to-[#4DA8FF] text-[#050B1A] rounded-xl text-[11px] font-black uppercase tracking-widest shadow-[0_0_15px_rgba(20,241,225,0.3)] hover:shadow-[0_0_25px_rgba(20,241,225,0.5)] transition-all flex items-center justify-center gap-2">
                    <Save className="w-4 h-4" /> {"Update Dojo Cloud"}
                  </button>
                </motion.form>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* THEATER MODE: Active Video Modal */}
      <AnimatePresence>
        {activeVideoLesson && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex flex-col items-center justify-center p-4 sm:p-6 md:p-8"
          >
            {/* Cinematic Background Blur */}
            <div className="absolute inset-0 bg-black/80 backdrop-blur-2xl" onClick={() => setActiveVideoLesson(null)} />
            
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="relative w-full max-w-6xl bg-[#050B1A] border border-[#14F1E1]/20 rounded-[2rem] shadow-[0_0_80px_rgba(20,241,225,0.15)] overflow-hidden flex flex-col max-h-[95vh]"
            >
              {/* Modal Header */}
              <div className="flex items-center justify-between p-6 border-b border-white/10 bg-white/5 relative z-10">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-[#14F1E1]/10 rounded-2xl border border-[#14F1E1]/20 hidden sm:block">
                    <Swords className="w-6 h-6 text-[#14F1E1]" />
                  </div>
                  <div>
                    <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-tight">{activeVideoLesson.name}</h2>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] bg-white/10 text-neutral-300 px-2 py-0.5 rounded uppercase tracking-widest font-black">{activeVideoLesson.category}</span>
                      <span className="text-[10px] text-[#14F1E1] uppercase tracking-widest font-bold">Level: {activeVideoLesson.level}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      playSound("click");
                      setFavorites(prev => favorites.includes(activeVideoLesson.id) ? prev.filter(id => id !== activeVideoLesson.id) : [...prev, activeVideoLesson.id]);
                    }}
                    className={`p-3 rounded-full border transition-all ${
                      favorites.includes(activeVideoLesson.id) 
                        ? 'bg-rose-500/20 border-rose-500/50 text-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.3)]' 
                        : 'bg-black/40 border-white/10 text-neutral-400 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <Heart className={`w-5 h-5 ${favorites.includes(activeVideoLesson.id) ? 'fill-current' : ''}`} />
                  </button>
                  <button
                    onClick={() => { playSound("click"); setActiveVideoLesson(null); }}
                    className="p-3 bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-400 hover:text-white rounded-full transition-all"
                  >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Modal Body */}
              <div className="flex-1 overflow-y-auto overflow-x-hidden p-6 md:p-8 scrollbar-none relative">
                <div className="absolute top-0 right-0 w-96 h-96 bg-[#14F1E1]/5 rounded-full blur-[100px] pointer-events-none" />
                
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  {/* Left Column: Video & Info */}
                  <div className="lg:col-span-8 space-y-8">
                    
                    {/* The Video Player */}
                    <div className="relative aspect-video rounded-3xl overflow-hidden border border-white/10 bg-black shadow-2xl group ring-1 ring-white/5">
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none z-10" />
                      {(() => {
                        const finalUrl = videoUrls[activeVideoLesson.id] || DEFAULT_MARTIAL_VIDEO_URLS[activeVideoLesson.id] || "";
                        const youtubeId = getYouTubeId(finalUrl);
                        if (youtubeId) {
                          return (
                            <iframe
                              src={`https://www.youtube.com/embed/${youtubeId}?autoplay=1&rel=0&modestbranding=1`}
                              title={activeVideoLesson.name}
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                              allowFullScreen
                              className="absolute inset-0 w-full h-full border-0 relative z-0"
                            />
                          );
                        } else {
                          return (
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-neutral-900 z-0">
                              <Video className="w-16 h-16 text-[#14F1E1] animate-pulse mb-4" />
                              <h4 className="text-xl font-black uppercase tracking-widest text-white mb-2">Video Coming Soon</h4>
                              <p className="text-sm text-neutral-400 font-medium max-w-sm">Admins are uploading the masterclass materials.</p>
                            </div>
                          );
                        }
                      })()}
                    </div>

                    {/* Lesson Details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <span className="text-[10px] font-black text-[#14F1E1] uppercase tracking-[0.2em] flex items-center gap-2">
                            <BookOpen className="w-3 h-3" /> Synopsis
                          </span>
                          <p className="text-sm text-neutral-300 leading-relaxed">{activeVideoLesson.description}</p>
                        </div>
                        <div className="space-y-2">
                          <span className="text-[10px] font-black text-[#14F1E1] uppercase tracking-[0.2em] flex items-center gap-2">
                            <Target className="w-3 h-3" /> Core Values
                          </span>
                          <p className="text-sm text-neutral-300 leading-relaxed">{activeVideoLesson.benefits}</p>
                        </div>
                      </div>

                      <div className="p-5 bg-[#14F1E1]/5 border border-[#14F1E1]/20 rounded-3xl space-y-4">
                        <span className="text-[10px] font-black text-[#14F1E1] uppercase tracking-[0.2em] flex items-center gap-2">
                          <Sparkles className="w-4 h-4" /> Sensei Coaching Tips
                        </span>
                        <p className="text-[13px] text-white font-medium leading-relaxed italic border-l-2 border-[#14F1E1] pl-4 py-1">
                          "{activeVideoLesson.tips}"
                        </p>
                        
                        {/* Muscle Tags */}
                        <div className="pt-4 border-t border-[#14F1E1]/20">
                          <span className="block text-[9px] font-bold text-neutral-400 uppercase tracking-widest mb-2">Target Recruits</span>
                          <div className="flex flex-wrap gap-2">
                            {(MARTIAL_LESSONS_MUSCLES[activeVideoLesson.id] || []).map((muscle) => (
                              <span key={muscle} className="text-[9px] font-black uppercase bg-[#14F1E1]/10 border border-[#14F1E1]/30 text-[#14F1E1] px-2.5 py-1 rounded-lg">
                                {muscle}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Interactive Anatomy & Actions */}
                  <div className="lg:col-span-4 flex flex-col gap-6">
                    {/* Anatomy Scanner */}
                    <div className="bg-black/40 border border-white/10 rounded-3xl p-6 backdrop-blur-md flex-1 flex flex-col relative z-10">
                      <div className="mb-4">
                        <span className="text-[10px] font-black text-neutral-400 uppercase tracking-[0.2em] block mb-1">Live Telemetry</span>
                        <h4 className="text-sm font-bold text-white">Anatomical Recruits</h4>
                      </div>
                      
                      <div className="mb-4">
                        <Exercise3DCharacterLoop
                          name={activeVideoLesson.name}
                          muscles={MARTIAL_LESSONS_MUSCLES[activeVideoLesson.id] || ["core"]}
                          category={activeVideoLesson.category}
                          compact={false}
                          interactive={true}
                        />
                      </div>

                      {/* Combat Kinetic Chain & Strike Telemetry HUD */}
                      <div className="flex-1 bg-black/50 border border-[#14F1E1]/20 rounded-2xl p-4 flex flex-col justify-between gap-3 relative overflow-hidden">
                        <div className="flex items-center justify-between border-b border-white/10 pb-2">
                          <span className="text-[9px] font-mono font-black uppercase tracking-widest text-[#14F1E1]">
                            KINETIC CHAIN TELEMETRY
                          </span>
                          <span className="text-[9px] font-mono font-bold text-[#B66DFF]">
                            {activeVideoLesson.category.toUpperCase()}
                          </span>
                        </div>

                        <div className="space-y-2.5">
                          {(MARTIAL_LESSONS_MUSCLES[activeVideoLesson.id] || ["core", "legs", "shoulders"]).map(
                            (muscle, idx) => {
                              const pct = Math.max(68, 96 - idx * 8);
                              return (
                                <div key={muscle} className="space-y-1">
                                  <div className="flex justify-between text-[10px] font-mono font-bold uppercase">
                                    <span className="text-white">{muscle} Recruitment</span>
                                    <span className="text-[#14F1E1]">{pct}%</span>
                                  </div>
                                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                                    <div
                                      className="h-full bg-gradient-to-r from-[#14F1E1] to-[#B66DFF]"
                                      style={{ width: `${pct}%` }}
                                    />
                                  </div>
                                </div>
                              );
                            }
                          )}
                        </div>
                      </div>
                      
                      {/* Specs */}
                      <div className="grid grid-cols-2 gap-3 mt-4">
                        <div className="bg-white/5 border border-white/10 p-3 rounded-xl text-center">
                          <span className="text-neutral-500 block text-[9px] font-black uppercase tracking-widest mb-1">Reps</span>
                          <span className="text-white font-black text-sm">10-12</span>
                        </div>
                        <button 
                          onClick={() => {
                            if (restTimerLeft !== null) {
                              playSound("timer_pause"); setRestTimerLeft(null);
                            } else {
                              playSound("timer_start"); setRestTimerLeft(45);
                            }
                          }}
                          className={`p-3 rounded-xl text-center border transition-all ${restTimerLeft !== null ? 'bg-[#14F1E1]/20 border-[#14F1E1]/50 text-[#14F1E1]' : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'}`}
                        >
                          <span className="text-neutral-500 flex justify-center items-center gap-1 text-[9px] font-black uppercase tracking-widest mb-1">
                            Rest {restTimerLeft === null && <Play className="w-2.5 h-2.5" />}
                          </span>
                          <span className={`font-black text-sm ${restTimerLeft !== null ? 'text-[#14F1E1]' : 'text-white'}`}>
                            {restTimerLeft !== null ? `${restTimerLeft}s` : '45s'}
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* Completion Card + 3D 30s Guided Combat Practice Ring Timer */}
                    <div className="bg-gradient-to-br from-[#14F1E1]/10 via-[#050B1A]/90 to-[#B66DFF]/10 border border-[#14F1E1]/30 rounded-3xl p-5 relative z-10 text-center flex flex-col justify-center gap-4 shadow-[0_12px_30px_rgba(0,0,0,0.6),inset_0_1px_1px_rgba(255,255,255,0.12)]">
                      {/* 3D Guided Practice Ring */}
                      <div className="flex items-center justify-between gap-3 bg-black/50 border border-white/10 rounded-2xl p-3">
                        <div className="relative w-14 h-14 shrink-0 flex items-center justify-center">
                          <svg viewBox="0 0 60 60" className="w-full h-full -rotate-90">
                            <circle cx="30" cy="30" r="24" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="4.5" />
                            <motion.circle
                              cx="30"
                              cy="30"
                              r="24"
                              fill="none"
                              stroke={practiceDone ? "#10B981" : "#14F1E1"}
                              strokeWidth="4.5"
                              strokeLinecap="round"
                              strokeDasharray={150.8}
                              animate={{
                                strokeDashoffset:
                                  practiceTimerLeft !== null
                                    ? 150.8 * (practiceTimerLeft / 30)
                                    : practiceDone
                                    ? 0
                                    : 150.8
                              }}
                              transition={{ duration: 0.4 }}
                              style={{ filter: "drop-shadow(0 0 6px rgba(20,241,225,0.7))" }}
                            />
                          </svg>
                          <div className="absolute inset-0 flex flex-col items-center justify-center">
                            <span className="text-[11px] font-black font-mono text-white leading-none">
                              {practiceTimerLeft !== null ? `${practiceTimerLeft}s` : practiceDone ? "DONE" : "30s"}
                            </span>
                            <span className="text-[7px] font-bold uppercase tracking-widest text-[#14F1E1]">DRILL</span>
                          </div>
                        </div>

                        <div className="flex-1 text-left">
                          <div className="text-[9px] font-black uppercase tracking-widest text-[#14F1E1] flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#14F1E1] animate-ping" />
                            Guided Drill Timer
                          </div>
                          <p className="text-[10px] text-neutral-400 font-medium leading-tight mt-0.5">
                            {practiceTimerLeft !== null
                              ? "Follow the movement form & pace..."
                              : practiceDone
                              ? "30s Drill Completed!"
                              : "Run 30s guided drill before completing"}
                          </p>
                          <button
                            type="button"
                            onClick={() => {
                              if (practiceTimerLeft !== null) {
                                playSound("timer_pause");
                                setPracticeTimerLeft(null);
                              } else {
                                playSound("timer_start");
                                setPracticeDone(false);
                                setPracticeTimerLeft(30);
                              }
                            }}
                            className={`mt-1.5 px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all ${
                              practiceTimerLeft !== null
                                ? "bg-amber-500/20 border-amber-400/50 text-amber-300"
                                : "bg-[#14F1E1]/15 border-[#14F1E1]/40 text-[#14F1E1] hover:bg-[#14F1E1]/25"
                            }`}
                          >
                            {practiceTimerLeft !== null ? "Pause Drill" : practiceDone ? "Restart 30s Drill" : "⚡ Start 30s Guided Drill"}
                          </button>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <span className="text-[10px] font-black text-neutral-400 uppercase tracking-widest">Completion Reward</span>
                        <h3 className="text-3xl font-black text-[#14F1E1] tracking-tighter">+{activeVideoLesson.xpReward} XP</h3>
                      </div>
                      
                      {progress.completed[activeVideoLesson.id] ? (
                        <div className="space-y-3">
                          <div className="w-full py-3.5 bg-[#14F1E1]/20 border border-[#14F1E1] text-[#14F1E1] rounded-xl text-[11px] font-black uppercase tracking-widest flex items-center justify-center gap-2">
                            <CheckCircle2 className="w-5 h-5" /> Mastered
                          </div>
                          <button
                            onClick={() => {
                              playSound("click");
                              const updated = { ...progress.completed };
                              delete updated[activeVideoLesson.id];
                              setProgress({ ...progress, completed: updated });
                            }}
                            className="text-[9px] font-black uppercase text-neutral-500 hover:text-white transition-colors underline underline-offset-4"
                          >
                            Reset Progress
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleMarkComplete(activeVideoLesson)}
                          className="w-full py-4 bg-[#14F1E1] hover:bg-[#1DE9B6] text-[#050B1A] rounded-xl text-xs font-black uppercase tracking-widest transition-all hover:scale-[1.02] active:scale-95 shadow-[0_0_20px_rgba(20,241,225,0.4)] hover:shadow-[0_0_30px_rgba(20,241,225,0.6)] flex items-center justify-center gap-2"
                        >
                          <CheckCircle2 className="w-5 h-5" /> Complete Lesson
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );

}
