import { useState, useMemo } from "react";
import SafeResponsiveContainer from "./SafeResponsiveContainer";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Cell,
  LineChart,
  Line,
  Legend,
  PieChart,
  Pie
} from "recharts";
import { CompletedSession } from "../types";
import { motion } from "motion/react";
import { 
  Sparkles, 
  Flame, 
  TrendingUp, 
  Calendar, 
  Activity, 
  Clock, 
  Target, 
  Dumbbell, 
  ArrowRight 
} from "lucide-react";

interface StatsViewProps {
  history: CompletedSession[];
  onSeedMockData: () => void;
  onNavigateToExercises: () => void;
}

export default function StatsView({ 
  history, 
  onSeedMockData, 
  onNavigateToExercises 
}: StatsViewProps) {
  const [activeMetric, setActiveMetric] = useState<"count" | "duration" | "calories">("count");

  // 1. Process Past 30 Days of Workout Data
  const statsData = useMemo(() => {
    const data = [];
    const today = new Date();
    
    for (let i = 29; i >= 0; i--) {
      const d = new Date();
      d.setDate(today.getDate() - i);
      const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
      
      // Filter sessions logged on this concrete day
      const sessionsOnDay = history.filter((s) => {
        const sDate = new Date(s.date);
        const sDateStr = `${sDate.getFullYear()}-${String(sDate.getMonth() + 1).padStart(2, "0")}-${String(sDate.getDate()).padStart(2, "0")}`;
        return sDateStr === dateStr;
      });
      
      const shortLabel = d.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      });
      
      const dailyDuration = sessionsOnDay.reduce((sum, s) => sum + s.totalDurationMin, 0);
            
            // Calculate daily volume (sets * reps * weight) and max weight
            let dailyVolume = 0;
            let dailyMaxWeight = 0;
            sessionsOnDay.forEach(s => {
                s.exercises.forEach(ex => {
                    const weight = ex.weight || 20; // default to 20 to show bodyweight equivalent volume
                    dailyVolume += (ex.sets * ex.reps * weight);
                    if (weight > dailyMaxWeight) dailyMaxWeight = weight;
                });
            });

            data.push({
                date: dateStr,
                label: shortLabel,
                count: sessionsOnDay.length,
                duration: dailyDuration,
                calories: Math.round(dailyDuration * 8.5),
                exercises: sessionsOnDay.reduce((sum, s) => sum + s.exercisesCount, 0),
                volume: dailyVolume,
                maxWeight: dailyMaxWeight,
            });
    }
    return data;
  }, [history]);

  // 2. High level metrics calculation for the last 30 days
  const metrics = useMemo(() => {
    const filtered30Days = history.filter((s) => {
      const sDate = new Date(s.date);
      const diffTime = Math.abs(new Date().getTime() - sDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 30;
    });

    const activeDaysCount = statsData.filter((d) => d.count > 0).length;
    const consistencyPercentage = Math.round((activeDaysCount / 30) * 100);
    const totalMinutes = filtered30Days.reduce((sum, s) => sum + s.totalDurationMin, 0);
    const totalCaloriesBurned = Math.round(totalMinutes * 8.5);
    const avgDuration = filtered30Days.length > 0
      ? Math.round(totalMinutes / filtered30Days.length)
      : 0;

    // Muscle Group breakdown count
    const muscleCounts: Record<string, number> = {};
    let beginnerCount = 0;
    let intermediateCount = 0;
    let advancedCount = 0;

    filtered30Days.forEach((s) => {
      s.muscles.forEach((muscle) => {
        const normalized = muscle.trim();
        muscleCounts[normalized] = (muscleCounts[normalized] || 0) + 1;
      });
      
      s.exercises.forEach((ex) => {
        if (ex.difficulty === "beginner") beginnerCount++;
        else if (ex.difficulty === "intermediate") intermediateCount++;
        else if (ex.difficulty === "advanced") advancedCount++;
      });
    });

    const intensityData = [
      { name: "Beginner", count: beginnerCount, color: "#10B981" },
      { name: "Intermediate", count: intermediateCount, color: "#F59E0B" },
      { name: "Advanced", count: advancedCount, color: "#EF4444" }
    ].filter(d => d.count > 0);

    const muscleData = Object.entries(muscleCounts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);

    const favoriteMuscle = muscleData.length > 0 ? muscleData[0].name : "None yet";

    return {
      activeDaysCount,
      consistencyPercentage,
      totalMinutes,
      totalCaloriesBurned,
      avgDuration,
      muscleData,
      favoriteMuscle,
      intensityData,
      workoutsCount30Days: filtered30Days.length,
    };
  }, [history, statsData]);

  // Visual Palette for the custom chart
  const COLORS = ["#C9F31D", "#3B82F6", "#EC4899", "#10B981", "#F59E0B", "#8B5CF6"];

  if (history.length === 0) {
    return (
      <div className="text-center py-16 bg-brand-surface border border-brand-border rounded-3xl p-8 space-y-8 max-w-2xl mx-auto my-4" id="stats-empty-state">
        <div className="relative inline-flex items-center justify-center">
          <div className="w-20 h-20 bg-[#1A1A1A] border border-brand-border rounded-full flex items-center justify-center text-brand-accent animate-pulse">
            <Activity className="w-10 h-10 text-brand-accent/70" />
          </div>
          <div className="absolute -top-1 -right-1 w-6 h-6 bg-brand-accent text-brand-bg rounded-full flex items-center justify-center font-black text-xs">
            0
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-xl font-black uppercase text-white tracking-widest">No Analytics Data Yet</h3>
          <p className="text-xs text-brand-muted max-w-md mx-auto leading-relaxed uppercase">
            Complete and log your first workout session to unlock deep interactive 30-day frequency charts and fitness consistency metrics!
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-2">
          <button
            onClick={onNavigateToExercises}
            className="px-8 py-4 bg-brand-accent text-brand-bg hover:bg-brand-accent-hover font-extrabold text-xs uppercase tracking-widest rounded-xl transition-all duration-300 shadow-[0_0_20px_rgba(201,243,29,0.3)] hover:scale-[1.03] flex items-center justify-center gap-2 cursor-pointer"
            id="stats-btn-empty-goto-gen"
          >
            <span>View Exercises</span>
            <ArrowRight className="w-4 h-4 text-brand-bg" />
          </button>

          <button
            onClick={onSeedMockData}
            className="px-6 py-4 bg-brand-card hover:bg-[#1f1f1f] text-brand-accent border border-brand-accent/20 rounded-xl text-xs uppercase font-extrabold tracking-widest transition-all duration-300 hover:border-brand-accent flex items-center justify-center gap-2 cursor-pointer"
            id="stats-btn-seed-sample-history"
          >
            <Sparkles className="w-4 h-4" />
            <span>Seed Sample Sessions</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 py-2" id="stats-recharts-dashboard">
      
      {/* 4 Cards Bento Grid of 30-Day Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="stats-bento-grid-30d">
        
        {/* Active Days */}
        <div className="bg-brand-surface border border-brand-border p-5 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-brand-accent/30 transition-all">
          <div className="absolute top-0 right-0 w-16 h-16 bg-brand-accent/3 rounded-full blur-xl"></div>
          <div className="flex items-center justify-between text-brand-muted">
            <span className="text-[9px] uppercase font-bold tracking-widest">Active Days</span>
            <Calendar className="w-4 h-4 text-brand-accent" />
          </div>
          <div className="mt-4">
            <div className="text-3xl font-black text-white">{metrics.activeDaysCount} Days</div>
            <div className="text-[10px] text-brand-muted uppercase tracking-widest font-black mt-1">out of last 30 days</div>
          </div>
        </div>

        {/* Consistency */}
        <div className="bg-brand-surface border border-brand-border p-5 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-brand-accent/30 transition-all">
          <div className="absolute top-0 right-0 w-16 h-16 bg-[#3B82F6]/5 rounded-full blur-xl"></div>
          <div className="flex items-center justify-between text-brand-muted">
            <span className="text-[9px] uppercase font-bold tracking-widest">Consistency</span>
            <Flame className="w-4 h-4 text-blue-400" />
          </div>
          <div className="mt-4">
            <div className="text-3xl font-black text-white">{metrics.consistencyPercentage}%</div>
            <div className="text-[10px] text-brand-muted uppercase tracking-widest font-black mt-1">Active ratio</div>
          </div>
        </div>

        {/* Training minutes volume */}
        <div className="bg-brand-surface border border-brand-border p-5 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-brand-accent/30 transition-all">
          <div className="absolute top-0 right-0 w-16 h-16 bg-pink-500/2 rounded-full blur-xl"></div>
          <div className="flex items-center justify-between text-brand-muted">
            <span className="text-[9px] uppercase font-bold tracking-widest">30d Training Time</span>
            <Clock className="w-4 h-4 text-pink-400" />
          </div>
          <div className="mt-4">
            <div className="text-3xl font-black text-white">~{metrics.totalMinutes} m</div>
            <div className="text-[10px] text-brand-muted uppercase tracking-widest font-black mt-1">Average {metrics.avgDuration} min/set</div>
          </div>
        </div>

        {/* Favorite Target */}
        <div className="bg-brand-surface border border-brand-border p-5 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-brand-accent/30 transition-all">
          <div className="absolute top-0 right-0 w-16 h-16 bg-green-500/2 rounded-full blur-xl"></div>
          <div className="flex items-center justify-between text-brand-muted">
            <span className="text-[9px] uppercase font-bold tracking-widest">Favorite Target</span>
            <Target className="w-4 h-4 text-green-400" />
          </div>
          <div className="mt-4">
            <div className="text-xl md:text-2xl font-black text-brand-accent capitalize truncate">{metrics.favoriteMuscle}</div>
            <div className="text-[10px] text-brand-muted uppercase tracking-widest font-black mt-1">Most hit in 30 days</div>
          </div>
        </div>

      </div>

      {/* Main Recharts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="charts-visualization-grid">
        
        {/* Left/Middle Column: 30-Day Workout Frequency Area Chart */}
        <div className="lg:col-span-2 bg-brand-surface border border-brand-border p-5 md:p-6 rounded-2xl space-y-4 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-brand-border/40 pb-4">
            <div>
              <h3 className="text-xs uppercase font-extrabold tracking-widest text-white flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-brand-accent" />
                <span>30-Day Workout Frequency</span>
              </h3>
              <p className="text-[10px] text-brand-muted uppercase mt-0.5">
                Daily frequency and performance peaks over the past month
              </p>
            </div>

            {/* Metric Toggle Button Segment */}
            <div className="flex bg-[#111] p-1 rounded-lg border border-brand-border self-start sm:self-center">
              <button
                onClick={() => setActiveMetric("count")}
                className={`px-3 py-1 text-[10px] font-black uppercase tracking-wider rounded transition-all cursor-pointer ${
                  activeMetric === "count"
                    ? "bg-brand-accent text-brand-bg font-black"
                    : "text-brand-muted hover:text-white"
                }`}
                id="btn-toggle-frequency-count"
              >
                Workouts Count
              </button>
              <button
                onClick={() => setActiveMetric("duration")}
                className={`px-3 py-1 text-[10px] font-black uppercase tracking-wider rounded transition-all cursor-pointer ${
                  activeMetric === "duration"
                    ? "bg-brand-accent text-brand-bg font-black"
                    : "text-brand-muted hover:text-white"
                }`}
                id="btn-toggle-frequency-duration"
              >
                Duration (Min)
              </button>
              <button
                onClick={() => setActiveMetric("calories")}
                className={`px-3 py-1 text-[10px] font-black uppercase tracking-wider rounded transition-all cursor-pointer ${
                  activeMetric === "calories"
                    ? "bg-brand-accent text-brand-bg font-black"
                    : "text-brand-muted hover:text-white"
                }`}
                id="btn-toggle-frequency-calories"
              >
                Calories (Kcal)
              </button>
            </div>
          </div>

          {/* Core Responsive Chart Container */}
          <div className="h-64 sm:h-72 w-full pt-4" id="main-recharts-frequency-wrapper">
            <SafeResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={statsData}
                margin={{ top: 10, right: 10, left: -25, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="colorFreq" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#C9F31D" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#C9F31D" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorDur" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorCal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#F59E0B" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                <XAxis 
                  dataKey="label" 
                  stroke="#555555" 
                  fontSize={9} 
                  tickLine={false}
                  dy={10} 
                  fontFamily="monospace"
                />
                <YAxis 
                  stroke="#555555" 
                  fontSize={10} 
                  allowDecimals={false} 
                  tickLine={false}
                  dx={-5}
                  fontFamily="monospace"
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "#0F0F0F", 
                    borderColor: "#222222", 
                    borderRadius: "12px", 
                    color: "#FFFFFF",
                    fontFamily: "sans-serif",
                    fontSize: "12px"
                  }} 
                  labelClassName="text-brand-muted uppercase font-black tracking-widest text-[9px] mb-1"
                />
                {activeMetric === "count" ? (
                  <Area 
                    type="monotone" 
                    dataKey="count" 
                    name="Workouts Completed"
                    stroke="#C9F31D" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorFreq)" 
                  />
                ) : activeMetric === "duration" ? (
                  <Area 
                    type="monotone" 
                    dataKey="duration" 
                    name="Minutes Trained"
                    stroke="#3B82F6" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorDur)" 
                  />
                ) : (
                  <Area 
                    type="monotone" 
                    dataKey="calories" 
                    name="Calories Burned (Kcal)"
                    stroke="#F59E0B" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorCal)" 
                  />
                )}
              </AreaChart>
            </SafeResponsiveContainer>
          </div>

          <div className="flex justify-between items-center text-[10px] text-brand-muted uppercase font-bold font-mono pt-1">
            <span>📅 30 Days Ago</span>
            <span className="flex items-center gap-1">
              <span className={`w-2 h-2 rounded ${activeMetric === "count" ? "bg-brand-accent" : activeMetric === "duration" ? "bg-blue-500" : "bg-amber-500"}`} />
              {activeMetric === "count" ? "Daily Sessions count" : activeMetric === "duration" ? "Daily exercise duration" : "Estimated daily calories burned"}
            </span>
            <span>Today (Now) 🏁</span>
          </div>

        </div>

        {/* Right Column: Muscle Target Distribution Bar Chart */}
        <div className="bg-brand-surface border border-brand-border p-5 md:p-6 rounded-2xl flex flex-col justify-between space-y-4 shadow-xl">
          <div>
            <h3 className="text-xs uppercase font-extrabold tracking-widest text-white flex items-center gap-1.5">
              <Dumbbell className="w-4 h-4 text-brand-accent" />
              <span>Target Breakdown</span>
            </h3>
            <p className="text-[10px] text-brand-muted uppercase mt-0.5">
              Muscle group focus in your last 30 days
            </p>
          </div>

          {metrics.muscleData.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-xs text-brand-muted uppercase">
              No specific muscle targets logged in 30 days. Customize your routine to build up data!
            </div>
          ) : (
            <div className="flex-1 space-y-4 pt-2">
              {/* Custom Mini Horizonal Bar Chart Representation using Recharts for flawless presentation */}
              <div className="h-44 w-full">
                <SafeResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={metrics.muscleData.slice(0, 5)}
                    layout="vertical"
                    margin={{ top: 0, right: 10, left: 15, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#222222" horizontal={false} />
                    <XAxis type="number" stroke="#555555" fontSize={9} allowDecimals={false} tickLine={false} />
                    <YAxis 
                      type="category" 
                      dataKey="name" 
                      stroke="#FFFFFF" 
                      fontSize={10} 
                      tickLine={false} 
                      width={45}
                      fontFamily="monospace"
                      textAnchor="end"
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: "#0F0F0F", 
                        borderColor: "#222222", 
                        borderRadius: "12px", 
                        color: "#FFFFFF",
                        fontSize: "11.5px"
                      }}
                    />
                    <Bar dataKey="count" name="Times Targeted" radius={[0, 4, 4, 0]}>
                      {metrics.muscleData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </SafeResponsiveContainer>
              </div>

              {/* Progress-styled legend */}
              <div className="space-y-2 max-h-32 overflow-y-auto pr-1">
                {metrics.muscleData.map((item, idx) => (
                  <div key={item.name} className="flex items-center justify-between text-[11px] font-bold">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                      <span className="capitalize text-white">{item.name}</span>
                    </div>
                    <span className="text-brand-muted uppercase">{item.count} times logged</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Seed/coaching info disclaimer */}
          <div className="text-[10px] text-[#555] uppercase leading-relaxed font-mono pt-2 border-t border-brand-border/40">
            Coach Advice: balance anterior & posterior targets.
          </div>

        </div>

      </div>

      
      {/* Volume & Weight Progression Line Chart */}
      <div className="bg-brand-surface border border-brand-border p-5 md:p-6 rounded-3xl space-y-5 shadow-2xl relative overflow-hidden" id="stats-volume-progression-card">
        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-brand-border/40 pb-4">
          <div className="space-y-0.5 text-left">
            <h3 className="text-xs uppercase font-extrabold tracking-widest text-[#4DA8FF] flex items-center gap-1.5 font-sans">
              <TrendingUp className="w-4 h-4 text-[#4DA8FF]" />
              <span>Progress & Volume Over Time</span>
            </h3>
            <p className="text-[10px] text-brand-muted uppercase mt-0.5">
              Total volume (Sets × Reps × Weight) and max weight lifted
            </p>
          </div>
        </div>

        <div className="h-64 w-full relative z-10 pt-4">
          <SafeResponsiveContainer width="100%" height="100%">
            <LineChart data={statsData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
              <XAxis 
                dataKey="label" 
                stroke="#666" 
                fontSize={10} 
                tickLine={false}
                axisLine={false}
                tickMargin={10}
              />
              <YAxis 
                yAxisId="left"
                stroke="#666" 
                fontSize={10} 
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => val >= 1000 ? `${(val/1000).toFixed(1)}k` : val}
              />
              <YAxis 
                yAxisId="right"
                orientation="right"
                stroke="#666" 
                fontSize={10} 
                tickLine={false}
                axisLine={false}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: "#0F0F0F", 
                  borderColor: "#222222", 
                  borderRadius: "12px", 
                  color: "#FFFFFF",
                  fontFamily: "sans-serif",
                  fontSize: "12px"
                }} 
                labelClassName="text-brand-muted uppercase font-black tracking-widest text-[9px] mb-1"
              />
              <Legend wrapperStyle={{ fontSize: '10px', textTransform: 'uppercase', fontWeight: 900, letterSpacing: '1px' }} />
              <Line 
                yAxisId="left"
                type="monotone" 
                dataKey="volume" 
                name="Total Volume (kg)"
                stroke="#4DA8FF" 
                strokeWidth={3}
                dot={{ r: 2, fill: "#4DA8FF", strokeWidth: 0 }}
                activeDot={{ r: 5, strokeWidth: 0 }}
              />
              <Line 
                yAxisId="right"
                type="monotone" 
                dataKey="maxWeight" 
                name="Max Weight (kg)"
                stroke="#B66DFF" 
                strokeWidth={3}
                dot={{ r: 2, fill: "#B66DFF", strokeWidth: 0 }}
                activeDot={{ r: 5, strokeWidth: 0 }}
              />
            </LineChart>
          </SafeResponsiveContainer>
        </div>
      </div>

      {/* INTENSITY DISTRIBUTION PIE CHART */}
      <div className="bg-brand-surface border border-brand-border p-5 md:p-6 rounded-3xl space-y-5 shadow-2xl relative overflow-hidden" id="stats-intensity-distribution-card">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-brand-border/40 pb-4">
          <div className="space-y-0.5 text-left">
            <h3 className="text-xs uppercase font-extrabold tracking-widest text-[#B66DFF] flex items-center gap-1.5 font-sans">
              <span className="text-sm">🔥</span>
              <span>Intensity Distribution</span>
            </h3>
            <p className="text-[10px] text-brand-muted uppercase mt-0.5">
              Breakdown of exercise difficulty levels over the last 30 days
            </p>
          </div>
        </div>

        <div className="h-56 sm:h-64 w-full flex items-center justify-center">
          {metrics.intensityData.length === 0 ? (
            <div className="text-xs text-brand-muted uppercase">No intensity data logged yet.</div>
          ) : (
            <SafeResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={metrics.intensityData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="count"
                >
                  {metrics.intensityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "#0F0F0F", 
                    borderColor: "#222222", 
                    borderRadius: "12px", 
                    color: "#FFFFFF",
                    fontSize: "11.5px",
                    fontFamily: "sans-serif"
                  }}
                  itemStyle={{ color: '#fff' }}
                  formatter={(value: any, name: any) => [`${value} exercises`, name]}
                />
                <Legend 
                  verticalAlign="bottom" 
                  height={36} 
                  content={({ payload }) => (
                    <div className="flex justify-center gap-6 mt-4 text-[10px] font-bold uppercase tracking-wider font-mono">
                      {payload?.map((entry: any, index) => (
                        <span key={`item-${index}`} className="flex items-center gap-1.5" style={{ color: entry.color }}>
                          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: entry.color }} />
                          {entry.value}
                        </span>
                      ))}
                    </div>
                  )}
                />
              </PieChart>
            </SafeResponsiveContainer>
          )}
        </div>
      </div>

      {/* PERFORMANCE OVER TIME LINE CHART */}
      <div className="bg-brand-surface border border-brand-border p-5 md:p-6 rounded-3xl space-y-5 shadow-2xl relative overflow-hidden" id="stats-performance-over-time-card">
        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-brand-border/40 pb-4">
          <div className="space-y-0.5 text-left">
            <h3 className="text-xs uppercase font-extrabold tracking-widest text-[#22D3EE] flex items-center gap-1.5 font-sans">
              <span className="text-sm">📈</span>
              <span>Performance Over Time</span>
            </h3>
            <p className="text-[10px] text-brand-muted uppercase">
              Simultaneous tracking of workout duration and total exercises completed over the last 30 days
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-[#111] px-2.5 py-1 rounded-lg border border-brand-border text-[9px] uppercase font-bold text-zinc-400">
              <span className="w-2 h-2 rounded bg-[#22D3EE]" />
              <span>Duration</span>
            </div>
            <div className="flex items-center gap-1.5 bg-[#111] px-2.5 py-1 rounded-lg border border-brand-border text-[9px] uppercase font-bold text-zinc-400">
              <span className="w-2 h-2 rounded bg-[#EC4899]" />
              <span>Exercises</span>
            </div>
          </div>
        </div>

        {/* Recharts LineChart for dual-axis duration and exercise tracking */}
        <div className="h-64 sm:h-72 w-full" id="performance-linechart-container">
          <SafeResponsiveContainer width="100%" height="100%">
            <LineChart
              data={statsData}
              margin={{ top: 10, right: -5, left: -25, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
              <XAxis 
                dataKey="label" 
                stroke="#555555" 
                fontSize={9} 
                tickLine={false}
                fontFamily="monospace"
                dy={8}
              />
              <YAxis 
                yAxisId="left"
                stroke="#22D3EE" 
                fontSize={10} 
                tickLine={false}
                fontFamily="monospace"
                dx={-5}
                allowDecimals={false}
              />
              <YAxis 
                yAxisId="right"
                orientation="right"
                stroke="#EC4899" 
                fontSize={10} 
                tickLine={false}
                fontFamily="monospace"
                dx={5}
                allowDecimals={false}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: "#0F0F0F", 
                  borderColor: "#222222", 
                  borderRadius: "12px", 
                  color: "#FFFFFF",
                  fontFamily: "sans-serif",
                  fontSize: "12px"
                }} 
                labelClassName="text-brand-muted uppercase font-black tracking-widest text-[9px] mb-1"
              />
              <Legend 
                content={({ payload }) => (
                  <div className="flex justify-center gap-6 mt-4 text-[10px] font-bold uppercase tracking-wider font-mono text-zinc-500">
                    {payload?.map((entry: any, index) => (
                      <span key={`item-${index}`} className="flex items-center gap-1.5" style={{ color: entry.color }}>
                        <span className="w-2.5 h-0.5" style={{ backgroundColor: entry.color }} />
                        {entry.value}
                      </span>
                    ))}
                  </div>
                )}
              />
              <Line 
                yAxisId="left"
                type="monotone" 
                dataKey="duration" 
                name="Duration (Min)"
                stroke="#22D3EE" 
                strokeWidth={3}
                dot={{ r: 2, stroke: '#22D3EE', strokeWidth: 1 }}
                activeDot={{ r: 5, stroke: '#22D3EE', strokeWidth: 1 }}
              />
              <Line 
                yAxisId="right"
                type="monotone" 
                dataKey="exercises" 
                name="Exercise Count"
                stroke="#EC4899" 
                strokeWidth={3}
                dot={{ r: 2, stroke: '#EC4899', strokeWidth: 1 }}
                activeDot={{ r: 5, stroke: '#EC4899', strokeWidth: 1 }}
              />
            </LineChart>
          </SafeResponsiveContainer>
        </div>

        {/* Summary analysis card footer help block */}
        <div className="bg-[#111] p-3 rounded-2xl flex items-start gap-2.5 text-[10px] text-neutral-400 font-mono uppercase leading-relaxed border border-brand-border/40 text-left">
          <span className="text-base text-cyan-400 animate-pulse">💡</span>
          <p>
            This dual-axis line graph tracks both mechanical output parameters. Look for areas of overlap: a rising <span className="text-cyan-400">Duration curve</span> paired with a flattening <span className="text-pink-400">Exercise curve</span> indicates increased workout density or longer pacing times per set.
          </p>
        </div>
      </div>

      {/* SECTION 3 — DEDICATED ESTIMATED CALORIES BURNED TREND */}
      <div className="bg-brand-surface border border-brand-border p-5 md:p-6 rounded-3xl space-y-5 shadow-2xl relative overflow-hidden" id="stats-calories-burned-trend-card">
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-brand-border/40 pb-4">
          <div className="space-y-0.5">
            <h3 className="text-xs uppercase font-extrabold tracking-widest text-[#F59E0B] flex items-center gap-1.5 font-sans">
              <span className="text-sm">🔥</span>
              <span>Daily Calories Burned Trend</span>
            </h3>
            <p className="text-[10px] text-brand-muted uppercase">
              Accumulative energy output mapped over past 30 days window (8.5 Kcal/min)
            </p>
          </div>
          
          <div className="bg-[#111] px-3 py-1.5 rounded-xl border border-brand-border text-[10px] text-white uppercase font-extrabold font-mono flex items-center gap-2">
            <span>Total Burned:</span>
            <span className="text-[#F59E0B] font-black">{metrics.totalCaloriesBurned} kcal</span>
          </div>
        </div>

        {/* Recharts BarChart representing daily burn volume */}
        <div className="h-56 sm:h-64 w-full" id="calories-burned-barchart-container">
          <SafeResponsiveContainer width="100%" height="100%">
            <BarChart
              data={statsData}
              margin={{ top: 10, right: 10, left: -25, bottom: 0 }}
            >
              <defs>
                <linearGradient id="colorBarCal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#EF4444" stopOpacity={0.2}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#222222" vertical={false} />
              <XAxis 
                dataKey="label" 
                stroke="#555555" 
                fontSize={9} 
                tickLine={false}
                fontFamily="monospace"
                dy={8}
              />
              <YAxis 
                stroke="#555555" 
                fontSize={10} 
                allowDecimals={false} 
                tickLine={false}
                fontFamily="monospace"
                dx={-5}
              />
              <Tooltip 
                cursor={{ fill: "rgba(245,158,11,0.03)" }}
                contentStyle={{ 
                  backgroundColor: "#0F0F0F", 
                  borderColor: "#222222", 
                  borderRadius: "12px", 
                  color: "#FFFFFF",
                  fontFamily: "sans-serif",
                  fontSize: "12px"
                }} 
                labelClassName="text-brand-muted uppercase font-black tracking-widest text-[9px] mb-1"
                formatter={(value: any) => [`${value} kcal`, "Burned Energy"]}
              />
              <Bar 
                dataKey="calories" 
                name="Calories Burned" 
                fill="url(#colorBarCal)" 
                radius={[4, 4, 0, 0]}
              >
                {statsData.map((entry, index) => {
                  return (
                    <Cell 
                      key={`cell-cal-${index}`} 
                      fill={entry.calories > 300 ? "#F59E0B" : "url(#colorBarCal)"}
                    />
                  );
                })}
              </Bar>
            </BarChart>
          </SafeResponsiveContainer>
        </div>

        {/* Informative Coach Advice */}
        <div className="bg-[#111] p-3 rounded-2xl flex items-start gap-2.5 text-[10px] text-neutral-400 font-mono uppercase leading-relaxed border border-brand-border/40">
          <span className="text-base text-amber-500 animate-pulse">⚡</span>
          <p>
            Daily output is calculated at a metabolic training rate of 8.5 Kcal per minute. Keep pushing over <strong className="text-white">300 Kcal (Solid Amber Bars)</strong> per workout session to optimize physiological recovery indices and fast-track cardiovascular hypertrophy!
          </p>
        </div>
      </div>

      {/* Bonus Desi Genie Intelligent Coach Insights */}
      <div className="bg-gradient-to-r from-brand-surface to-[#111] border border-brand-border p-5 rounded-3xl flex flex-col md:flex-row items-center gap-4 justify-between" id="recharts-coaching-insights-strip">
        <div className="flex items-center gap-3 text-center md:text-left flex-col md:flex-row">
          <div className="w-12 h-12 rounded-full bg-brand-accent/15 border border-brand-accent/30 flex items-center justify-center text-2xl select-none">
            🧬
          </div>
          <div>
            <h4 className="text-xs uppercase font-black text-brand-accent tracking-widest">Genie Bio-Feedback Analytica</h4>
            <p className="text-[11px] text-brand-muted leading-relaxed uppercase mt-0.5 max-w-xl">
              You ran <strong className="text-white">{metrics.workoutsCount30Days} workouts</strong>, hitting <strong className="text-white">{metrics.favoriteMuscle}</strong> active profiles. Complete 2 more routines to balance your total strength index!
            </p>
          </div>
        </div>
        
        {/* Short encouragement message */}
        <div className="bg-brand-accent/10 border border-brand-accent/20 px-4 py-2 rounded-xl text-[10px] font-black uppercase text-brand-accent tracking-widest animate-pulse-slow">
          🔥 Consistency Score: {metrics.consistencyPercentage}%
        </div>
      </div>

    </div>
  );
}
