import { useEffect } from "react";
import { useLocalStorageSync } from "../hooks/useLocalStorageSync";

declare global {
  interface Window {
    AndroidStepCounter?: {
      getSteps: () => number;
    };
    onAndroidStepsUpdated?: (steps: number) => void;
  }
}

export function BackgroundStepTracker() {
  const [hasGrantedPermission] = useLocalStorageSync<boolean>("fitgenie_motion_permission", false);
  const [, setStepLogs] = useLocalStorageSync<{dateStr: string; steps: number}[]>("fitgenie_steps_history", []);

  const getLocalDateString = (date = new Date()) => {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const dd = String(date.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  useEffect(() => {
    if (!hasGrantedPermission) return;

    // 1. PRIMARY SOURCE: Android TYPE_STEP_COUNTER via WebView Bridge
    if (window.AndroidStepCounter) {
      // Setup global callback for Android to push step updates
      window.onAndroidStepsUpdated = (newSteps: number) => {
        setStepLogs((prev: any) => {
          const today = getLocalDateString();
          const todayLogIndex = prev.findIndex((l: any) => l.dateStr === today);
          if (todayLogIndex >= 0) {
            const newLogs = [...prev];
            // Android TYPE_STEP_COUNTER usually gives total steps since boot,
            // but assuming the bridge sends the delta or daily total for simplicity,
            // we will treat `newSteps` as an absolute daily value if it's large,
            // or we'll just implement a simple additive logic if it sends individual steps.
            // Let's assume the bridge sends 1 for each step detected for compatibility.
            newLogs[todayLogIndex] = { ...newLogs[todayLogIndex], steps: newLogs[todayLogIndex].steps + 1 };
            return newLogs;
          } else {
            return [...prev, { dateStr: today, steps: 1 }];
          }
        });
      };
      
      // We rely on Android calling `window.onAndroidStepsUpdated(1)` 
      // or we can poll if getSteps() is provided.
      const pollInterval = setInterval(() => {
        if (window.AndroidStepCounter?.getSteps) {
           const steps = window.AndroidStepCounter.getSteps();
           if (steps > 0) {
             // Handle absolute steps if needed, but for now just rely on events.
           }
        }
      }, 5000);
      
      return () => {
        clearInterval(pollInterval);
        delete window.onAndroidStepsUpdated;
      };
    }

    // 2. FALLBACK: Accelerometer (DeviceMotionEvent)
    let lastVector = 0;
    let lastTime = 0;
    const threshold = 1.5; // Acceleration threshold difference
    
    const handleMotion = (e: DeviceMotionEvent) => {
      const x = e.accelerationIncludingGravity?.x || 0;
      const y = e.accelerationIncludingGravity?.y || 0;
      const z = e.accelerationIncludingGravity?.z || 0;
      
      // Use total acceleration vector magnitude
      const vector = Math.sqrt(x * x + y * y + z * z);
      
      if (lastVector === 0) {
        lastVector = vector;
        return;
      }
      
      const currentTime = new Date().getTime();
      const timeDifference = currentTime - lastTime;
      
      // Typical step frequency is ~100-160 steps per minute (approx >300ms per step)
      if (Math.abs(vector - lastVector) > threshold && timeDifference > 300) {
        // Step detected
        setStepLogs((prev: any) => {
          const today = getLocalDateString();
          const todayLogIndex = prev.findIndex((l: any) => l.dateStr === today);
          if (todayLogIndex >= 0) {
            const newLogs = [...prev];
            newLogs[todayLogIndex] = { ...newLogs[todayLogIndex], steps: newLogs[todayLogIndex].steps + 1 };
            return newLogs;
          } else {
            return [...prev, { dateStr: today, steps: 1 }];
          }
        });
        lastTime = currentTime;
      }
      lastVector = vector;
    };

    window.addEventListener('devicemotion', handleMotion);
      
    return () => {
      window.removeEventListener('devicemotion', handleMotion);
    };
  }, [hasGrantedPermission, setStepLogs]);

  return null;
}
