import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Play, Square, Pause, Save, CheckCircle, AlertTriangle, MessageSquare } from "lucide-react";
import { Exercise, CompletedSession } from "../types";
import { playSound } from "../utils/audio";
import { useAuth } from "../context/AuthContext";
import { useGenieTracker } from "../context/GenieTrackerContext";
import { useGuardianContext } from "../context/GuardianContext";
import { AiRepCounter } from "./AiRepCounter";
import { Camera, TrendingUp } from "lucide-react";
import { LineChart, Line, ResponsiveContainer, YAxis, Tooltip, XAxis } from "recharts";
import { speakGenie, getWorkoutStartLine, getWorkoutCompleteLine } from "../utils/voiceCoach";

interface SmartWorkoutTrackerProps {
  exercise: Exercise;
  onClose: () => void;
  onSave: (session: CompletedSession) => void;
}

type TrackerState = "goal_selection" | "active" | "completion";

export function SmartWorkoutTracker({ exercise, onClose, onSave }: SmartWorkoutTrackerProps) {
  const { startExercise, completeExercise } = useGenieTracker();
  const { evaluateRealism, reportSuspiciousActivity } = useGuardianContext();
  const { profile, updateUserProfileFields } = useAuth();
  const [state, setState] = useState<TrackerState>("goal_selection");
  
  // Goal Selection
  const [targetReps, setTargetReps] = useState<number | "custom">(10);
  const [customReps, setCustomReps] = useState<string>("");

  // Timer
  const [timeActiveMs, setTimeActiveMs] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [restTimeLeft, setRestTimeLeft] = useState<number | null>(null);

  useEffect(() => {
    if (restTimeLeft === null) return;
    if (restTimeLeft <= 0) {
      playSound("rest_chime");
      setRestTimeLeft(null);
      return;
    }
    const tid = setInterval(() => setRestTimeLeft(p => p ? p - 1 : 0), 1000);
    return () => clearInterval(tid);
  }, [restTimeLeft]);
  const intervalRef = useRef<number | null>(null);

  // Completion
  const [completedRepsInput, setCompletedRepsInput] = useState<string>("");
  const [repHistory, setRepHistory] = useState<{ date: string; reps: number }[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem(`fitgenie_reps_${exercise.id}`);
    if (stored) {
      try {
        setRepHistory(JSON.parse(stored));
      } catch(e){}
    }
  }, [exercise.id]);
  const [showAiTracker, setShowAiTracker] = useState(false);
  const [notes, setNotes] = useState<string>("");
  
  // Validation
  const [unusualWarning, setUnusualWarning] = useState(false);

  useEffect(() => {
    if (state === "active" && !isPaused) {
      intervalRef.current = window.setInterval(() => {
        setTimeActiveMs(prev => prev + 100);
      }, 100);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [state, isPaused]);

  const handleStart = () => {
    let finalTarget = 10;
    if (targetReps === "custom") {
      finalTarget = parseInt(customReps, 10);
      if (isNaN(finalTarget) || finalTarget <= 0) {
        finalTarget = 12;
        setCustomReps("12");
      }
    } else {
      finalTarget = targetReps;
    }
    playSound("click");
    speakGenie(getWorkoutStartLine());
    startExercise(exercise.id.toString(), exercise.name_en);
    setState("active");
  };

  const handleFinishWorkout = () => {
    playSound("success");
    speakGenie(getWorkoutCompleteLine());
    setIsPaused(true);
    setState("completion");
  };

  const handleSave = () => {
    const finalTarget = targetReps === "custom" ? (parseInt(customReps, 10) || 12) : targetReps;
    const parsedCompleted = parseInt(completedRepsInput, 10);
    const finalCompleted = isNaN(parsedCompleted) || parsedCompleted < 0 ? finalTarget : parsedCompleted;
    const workoutTimeSec = Math.floor(timeActiveMs / 1000);

    // Anti-cheat Biomechanical Validation via Guardian Orb
    let isUnusual = false;
    const nameLower = exercise.name_en.toLowerCase();
    const realismScore = evaluateRealism(exercise.name_en, finalCompleted, workoutTimeSec);

    if (finalCompleted >= 5 && realismScore < 45) {
      isUnusual = true;
    }

    if (nameLower.includes("pushup") || nameLower.includes("push-up") || nameLower.includes("push up")) {
      if (finalCompleted > 300) isUnusual = true;
    } else if (nameLower.includes("squat")) {
      if (finalCompleted > 300) isUnusual = true;
    } else if (nameLower.includes("pullup") || nameLower.includes("pull-up")) {
      if (finalCompleted > 80) isUnusual = true;
    } else if (finalCompleted > 500) {
      isUnusual = true;
    }

    if (isUnusual && !unusualWarning) {
      setUnusualWarning(true);
      reportSuspiciousActivity(
        `${finalCompleted} ${exercise.name_en} sirf ${workoutTimeSec}s me? Orb Anti-Cheat ne impossible workout speed pakad li hai! 🛑`,
        "critical"
      );
      return; // Stop and wait for user to verify or fix reps
    }

    completeExercise(exercise.id.toString(), exercise.name_en, finalCompleted);

    // Leaderboard Stats Update (only if verified & realistic!)
    if (!isUnusual && profile && updateUserProfileFields) {
      const exerciseName = exercise.name_en.toLowerCase();
      const currentStats = profile.stats || {};
      let statsPatch: any = {};
      let shouldUpdate = false;
      
      if (exerciseName.includes('squat')) {
         if (finalCompleted > (currentStats.squats_all || 0)) {
            statsPatch.squats_all = finalCompleted;
            shouldUpdate = true;
         }
      } else if (exerciseName.includes('push')) {
         if (finalCompleted > (currentStats.pushups_all || 0)) {
            statsPatch.pushups_all = finalCompleted;
            shouldUpdate = true;
         }
      }
      
      if (shouldUpdate) {
         updateUserProfileFields({ stats: statsPatch }).catch(console.error);
      }
    }

    playSound("success");

    const progressPercentage = Math.round((finalCompleted / finalTarget) * 100);

    const session: CompletedSession = {
      id: `smart_${Date.now()}`,
      date: new Date().toISOString(),
      muscles: exercise.muscles,
      equipment: exercise.equipment,
      exercisesCount: 1,
      totalDurationMin: Math.max(1, Math.ceil(workoutTimeSec / 60)),
      exercises: [
        {
          id: exercise.id,
          name_en: exercise.name_en,
          name_hi: exercise.name_hi,
          sets: 1,
          reps: finalCompleted,
          difficulty: exercise.difficulty
        }
      ],
      notes: notes.trim(),
      // Smart Validation additions
      isSmartValidation: true,
      targetReps: finalTarget,
      completedReps: finalCompleted,
      progressPercentage,
      unverified: isUnusual,
      workoutTimeSec,
    };

    onSave(session);
    onClose();
  };

  const formatTime = (ms: number) => {
    const totalSec = Math.floor(ms / 1000);
    const m = Math.floor(totalSec / 60).toString().padStart(2, "0");
    const s = (totalSec % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  // Render Goal Selection
  const renderGoalSelection = () => (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col h-full justify-between flex-1 p-6">
      <div>
        <h2 className="text-2xl font-black uppercase text-white mb-2">Target Goal</h2>
        <p className="text-neutral-400 text-sm mb-8">How many reps do you want to complete?</p>
        
        <div className="grid grid-cols-3 gap-3 mb-6">
          {[10, 15, 20, 25, 30].map(val => (
            <button
              key={val}
              onClick={() => { playSound("click"); setTargetReps(val); }}
              className={`py-4 rounded-2xl border transition-all text-xl font-black cursor-pointer ${
                targetReps === val 
                  ? "bg-brand-accent text-brand-bg border-brand-accent shadow-[0_0_15px_rgba(201,243,29,0.3)]" 
                  : "bg-neutral-900 text-white border-brand-border/40 hover:border-brand-accent/50"
              }`}
            >
              {val}
            </button>
          ))}
          <button
            onClick={() => { playSound("click"); setTargetReps("custom"); }}
            className={`py-4 rounded-2xl border transition-all text-sm font-black uppercase cursor-pointer ${
              targetReps === "custom" 
                ? "bg-brand-accent text-brand-bg border-brand-accent shadow-[0_0_15px_rgba(201,243,29,0.3)]" 
                : "bg-neutral-900 text-white border-brand-border/40 hover:border-brand-accent/50"
            }`}
          >
            Custom
          </button>
        </div>

        {targetReps === "custom" && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} className="overflow-hidden">
            <input
              type="number"
              min="1"
              value={customReps}
              onChange={(e) => setCustomReps(e.target.value)}
              placeholder="Enter custom reps..."
              className="w-full bg-neutral-900 border border-brand-border rounded-xl p-4 text-white text-center text-xl font-bold focus:outline-none focus:border-brand-accent"
            />
          </motion.div>
        )}
      </div>

      <button
        onClick={handleStart}
        className="w-full py-4 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg font-black text-lg uppercase tracking-widest rounded-xl transition-all shadow-[0_0_20px_rgba(201,243,29,0.2)] hover:scale-[1.02] cursor-pointer"
      >
        Start Workout
      </button>
    </motion.div>
  );

  // Render Active Timer
  const renderActive = () => (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col h-full items-center justify-center p-6 flex-1 text-center">
      <div className="absolute top-6 left-6 right-6 flex justify-between items-center">
        <span className="text-xs uppercase font-extrabold tracking-widest text-brand-accent px-3 py-1 bg-brand-surface border border-brand-border rounded-full flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${isPaused ? "bg-orange-500" : "bg-green-500 animate-pulse"}`}></span>
          {isPaused ? "Paused" : "Active"}
        </span>
      </div>

      <div className="w-full flex-1 flex flex-col items-center justify-center">
        {!isPaused && (
          <button 
            onClick={() => { playSound("click"); setShowAiTracker(true); }}
            className="mb-8 px-5 py-3 bg-[#14F1E1]/10 text-[#14F1E1] border border-[#14F1E1]/30 rounded-2xl flex items-center justify-center gap-2 font-black uppercase tracking-widest hover:bg-[#14F1E1]/20 transition-all hover:scale-105 shadow-[0_0_15px_rgba(20,241,225,0.15)]"
          >
            <Camera className="w-5 h-5" />
            AI Auto-Track Reps
          </button>
        )}
        {!isPaused ? (
          <>
            <div className="text-[5rem] font-black font-mono text-white tabular-nums tracking-tighter leading-none mb-2">
              {formatTime(timeActiveMs)}
            </div>
            <p className="text-neutral-500 font-mono text-sm uppercase tracking-widest">Active Workout Time</p>
          </>
        ) : (
          <>
            <div className="text-[5rem] font-black font-mono text-brand-accent tabular-nums tracking-tighter leading-none mb-2 relative">
              {restTimeLeft !== null ? `${Math.floor(restTimeLeft / 60).toString().padStart(2, '0')}:${(restTimeLeft % 60).toString().padStart(2, '0')}` : formatTime(timeActiveMs)}
            </div>
            <p className="text-brand-accent font-mono text-sm uppercase tracking-widest">Resting Timer</p>
            {restTimeLeft !== null && (
              <div className="flex gap-4 mt-6">
                 <button onClick={() => setRestTimeLeft(p => (p || 0) + 30)} className="px-4 py-2 bg-neutral-800 text-white rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-neutral-700 active:scale-95 transition-all">+30s</button>
                 <button onClick={() => setRestTimeLeft(60)} className="px-4 py-2 bg-neutral-800 text-white rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-neutral-700 active:scale-95 transition-all">Reset</button>
              </div>
            )}
          </>
        )}
      </div>

      <div className="w-full flex gap-4 mt-8">
        <button
          onClick={() => { playSound("click"); if (!isPaused) { setRestTimeLeft(60); } else { setRestTimeLeft(null); } setIsPaused(!isPaused); }}
          className="flex-1 py-4 bg-neutral-900 hover:bg-neutral-800 text-white border border-brand-border rounded-2xl flex items-center justify-center gap-2 font-bold uppercase cursor-pointer"
        >
          {isPaused ? <Play className="w-5 h-5 text-brand-accent" /> : <Pause className="w-5 h-5 text-brand-accent" />}
          {isPaused ? "Resume" : "Pause"}
        </button>
        <button
          onClick={handleFinishWorkout}
          className="flex-1 py-4 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg rounded-2xl flex items-center justify-center gap-2 font-black uppercase shadow-[0_0_15px_rgba(201,243,29,0.2)] cursor-pointer"
        >
          <Square className="w-5 h-5 fill-current" />
          Finish
        </button>
      </div>
    </motion.div>
  );

  // Render Completion
  const renderCompletion = () => {
    const finalTarget = targetReps === "custom" ? parseInt(customReps, 10) : targetReps;
    const finalCompleted = parseInt(completedRepsInput, 10);
    const progress = (!isNaN(finalCompleted) && finalTarget > 0) ? Math.round((finalCompleted / finalTarget) * 100) : 0;
    
    let coachingMsg = "Ready to log?";
    let coachingIcon = <CheckCircle className="w-5 h-5 text-neutral-400" />;
    
    if (!isNaN(finalCompleted)) {
      if (progress < 50) {
        coachingMsg = "🚀 Progress is progress. Keep pushing bro.";
        coachingIcon = <CheckCircle className="w-5 h-5 text-brand-accent" />;
      } else if (progress < 100) {
        coachingMsg = "💪 Nice work. Solid effort!";
        coachingIcon = <CheckCircle className="w-5 h-5 text-brand-accent" />;
      } else if (progress === 100) {
        coachingMsg = "🔥 Great effort bro. Target smashed!";
        coachingIcon = <CheckCircle className="w-5 h-5 text-orange-500" />;
      } else {
        coachingMsg = "👑 New Personal Record. You destroyed that target!";
        coachingIcon = <CheckCircle className="w-5 h-5 text-yellow-500" />;
      }
    }

    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col h-full flex-1 p-6 overflow-y-auto">
        <h2 className="text-2xl font-black uppercase text-white mb-2">Session Complete</h2>
        <p className="text-neutral-400 text-sm mb-6">Bro, how many reps did you actually complete?</p>
        
        <div className="bg-neutral-900 border border-brand-border/40 p-5 rounded-2xl mb-6">
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm text-neutral-400 uppercase font-bold tracking-widest">Target</span>
            <span className="text-lg font-mono font-black text-white">{finalTarget}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-brand-accent uppercase font-black tracking-widest">Completed</span>
            <input
              type="number"
              min="0"
              value={completedRepsInput}
              onChange={(e) => {
                setCompletedRepsInput(e.target.value);
                setUnusualWarning(false); // reset warning on change
              }}
              placeholder="0"
              className="w-24 bg-[#111] border-b-2 border-brand-accent text-white text-right text-2xl font-black font-mono focus:outline-none p-1"
            />
          </div>
        </div>

        <div className="bg-brand-primary/20 border border-brand-border p-4 rounded-xl flex items-start gap-3 mb-6">
          {coachingIcon}
          <div className="flex-1">
             <p className="text-white font-bold text-sm leading-tight">{coachingMsg}</p>
             {!isNaN(finalCompleted) && (
                <p className="text-xs text-neutral-500 mt-1 font-mono">Progress: {progress}%</p>
             )}
          </div>
        </div>

        {unusualWarning && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="bg-red-500/10 border border-red-500/30 p-4 rounded-xl flex items-start gap-3 mb-6 text-red-400">
             <AlertTriangle className="w-5 h-5 shrink-0" />
             <div className="text-xs font-bold leading-relaxed">
               🤨 Bro, this result seems unusual. Please verify your workout. Saving this will mark it as unverified and exclude it from Personal Records. Click Save again to force save.
             </div>
          </motion.div>
        )}

                {/* TREND CHART */}
        <div className="bg-neutral-900 border border-brand-border/40 p-4 rounded-2xl mb-6">
           <div className="flex items-center gap-2 mb-3 text-neutral-400">
             <TrendingUp className="w-4 h-4 text-[#B66DFF]" />
             <span className="text-xs font-bold uppercase tracking-widest text-[#B66DFF]">Historical Trend</span>
           </div>
           <div className="h-28 w-full">
             <ResponsiveContainer width="100%" height="100%">
               <LineChart data={[...repHistory.map((h, i) => ({ name: `S${i+1}`, reps: h.reps })), { name: "Now", reps: isNaN(finalCompleted) ? 0 : finalCompleted }]}>
                 <Tooltip 
                   contentStyle={{ backgroundColor: '#111', border: '1px solid #333', borderRadius: '8px' }}
                   itemStyle={{ color: '#14F1E1', fontWeight: 'bold' }}
                   labelStyle={{ display: 'none' }}
                   formatter={(value: number) => [`${value} reps`, ""]}
                 />
                 <Line 
                   type="monotone" 
                   dataKey="reps" 
                   stroke="#14F1E1" 
                   strokeWidth={3} 
                   dot={{ fill: '#B66DFF', r: 4, strokeWidth: 0 }} 
                   activeDot={{ r: 6, fill: '#14F1E1' }} 
                   isAnimationActive={true}
                 />
               </LineChart>
             </ResponsiveContainer>
           </div>
           {repHistory.length === 0 && (
             <p className="text-center text-[10px] text-neutral-500 uppercase font-bold mt-2">First time tracking this exercise.</p>
           )}
        </div>

        <div className="space-y-2 mb-6">
           <label className="text-xs uppercase font-bold text-neutral-500 flex items-center gap-1.5"><MessageSquare className="w-3.5 h-3.5" /> Notes (Optional)</label>
           <textarea
             value={notes}
             onChange={(e) => setNotes(e.target.value)}
             placeholder="e.g. Last 10 reps were difficult, Great shoulder pump..."
             className="w-full bg-neutral-900 border border-brand-border rounded-xl p-3 text-sm text-white focus:outline-none focus:border-brand-accent min-h-[80px]"
           />
        </div>

        <div className="mt-auto pt-4">
          <button
            onClick={handleSave}
            className={`w-full py-4 rounded-xl font-black text-lg uppercase tracking-widest transition-all cursor-pointer ${unusualWarning ? 'bg-red-500 text-white hover:bg-red-600 shadow-[0_0_20px_rgba(239,68,68,0.3)]' : 'bg-brand-accent hover:bg-brand-accent-hover text-brand-bg shadow-[0_0_20px_rgba(201,243,29,0.2)] hover:scale-[1.02]'}`}
          >
            {unusualWarning ? 'Force Save Anyway' : 'Save Workout'}
          </button>
        </div>
      </motion.div>
    );
  };

  return (
    <>
    {showAiTracker && (
      <AiRepCounter
        initialExercise={exercise.name_en.toLowerCase().includes("squat") ? "Squats" : "Pushups"}
        onClose={() => setShowAiTracker(false)}
        onComplete={(reps) => {
          setShowAiTracker(false);
          setCompletedRepsInput(reps.toString());
          setState("completion");
          playSound("success");
        }}
      />
    )}
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md">
      <div className="bg-brand-surface border border-brand-border rounded-3xl max-w-md w-full overflow-hidden shadow-[0_0_50px_rgba(201,243,29,0.18)] flex flex-col relative h-[650px] max-h-full">
        {state !== "active" && (
          <button onClick={onClose} className="absolute top-4 right-4 text-neutral-400 hover:text-white z-10 bg-black/50 p-2 rounded-full cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        )}
        
        {/* Header */}
        <div className="bg-[#111] p-4 border-b border-brand-border/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-lg bg-neutral-900 border border-brand-border flex items-center justify-center overflow-hidden">
               {exercise.gif_url ? (
                 <img src={exercise.gif_url} alt="exercise" className="w-full h-full object-cover" />
               ) : (
                 <Play className="w-4 h-4 text-brand-accent" />
               )}
             </div>
             <div>
               <h3 className="text-white font-black uppercase text-sm">{exercise.name_en}</h3>
               <p className="text-brand-accent text-[10px] font-mono font-bold">{exercise.name_hi}</p>
             </div>
          </div>
        </div>

        {/* Content Area */}
        {state === "goal_selection" && renderGoalSelection()}
        {state === "active" && renderActive()}
        {state === "completion" && renderCompletion()}
      </div>
    </div>
    </>
  );
}
