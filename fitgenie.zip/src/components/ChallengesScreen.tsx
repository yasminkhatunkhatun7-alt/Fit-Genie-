import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AppView } from "../types";
import { playSound } from "../utils/audio";
import {
  Zap,
  Trophy,
  Target as TargetIcon,
  Play,
  ChevronLeft,
  Activity,
  CheckCircle2,
  ShieldAlert,
  Eye,
  EyeOff,
  Sparkles,
  Crown,
} from "lucide-react";
import { useLocalStorageSync } from "../hooks/useLocalStorageSync";
import { useAuth } from "../context/AuthContext";
import { useGuardianContext } from "../context/GuardianContext";
import { useGenieTracker } from "../context/GenieTrackerContext";
import MuscleSelector from "./MuscleSelector";

import DailyChallengeDetailScreen from "./DailyChallengeDetailScreen";
import SpeedChallengeScreen from "./SpeedChallengeScreen";
import StrengthChallengeScreen from "./StrengthChallengeScreen";
import WeeklyChallengeScreen from "./WeeklyChallengeScreen";
import CustomChallengeDetailScreen from "./CustomChallengeDetailScreen";
import OneMonthChallengeScreen from "./OneMonthChallengeScreen";

import { getTodayChallenge } from "../utils/dailyChallenge";
import { AiRepCounter } from "./AiRepCounter";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";

interface ChallengesScreenProps {
  onNavigateToView?: (view: AppView) => void;
}

export interface ActiveChallenge {
  id: string;
  title: string;
  xp: number;
  exercises: { name: string; targetReps: number; completedReps: number }[];
  desc?: string;
  startTime: number;
  difficulty?: string;
  time?: string;
  muscles?: string[];
  boss?: string;
}

/**
 * Custom 3D Volumetric Holographic Emblem for each Challenge Archetype
 * (Replaces flat 2D icons with multi-layered 3D shaded SVG cores & rotating gimbals)
 */
const Challenge3DEmblem = ({
  id,
  primaryHex,
  secondaryHex,
}: {
  id: string;
  primaryHex: string;
  secondaryHex: string;
}) => {
  const uid = `ch_emb_${id}`;
  return (
    <div className="w-14 h-14 relative flex items-center justify-center shrink-0 select-none pointer-events-none">
      {/* Volumetric Backlight Glow */}
      <div
        className="absolute inset-0 rounded-2xl opacity-60 blur-md"
        style={{
          background: `radial-gradient(circle, ${primaryHex}55 0%, ${secondaryHex}22 65%, transparent 100%)`,
        }}
      />
      {/* 3D Glass Beveled Pedestal Frame */}
      <div
        className="w-14 h-14 rounded-2xl bg-[#04091A]/90 border relative flex items-center justify-center overflow-hidden"
        style={{
          borderColor: `${primaryHex}55`,
          boxShadow: `inset 0 2px 6px rgba(255,255,255,0.16), inset 0 -3px 8px rgba(0,0,0,0.9), 0 6px 18px ${primaryHex}26`,
        }}
      >
        <svg viewBox="0 0 64 64" className="w-12 h-12 overflow-visible">
          <defs>
            <radialGradient id={`${uid}_core`} cx="35%" cy="30%" r="65%">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.95" />
              <stop offset="35%" stopColor={primaryHex} stopOpacity="0.9" />
              <stop offset="80%" stopColor={secondaryHex} stopOpacity="0.85" />
              <stop offset="100%" stopColor="#030712" stopOpacity="0.95" />
            </radialGradient>
            <linearGradient id={`${uid}_metal`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.9" />
              <stop offset="50%" stopColor={primaryHex} stopOpacity="0.8" />
              <stop offset="100%" stopColor={secondaryHex} stopOpacity="0.9" />
            </linearGradient>
          </defs>

          {/* Outer Rotating 3D Gimbal Ring */}
          <motion.g
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            style={{ transformOrigin: "32px 32px" }}
          >
            <ellipse
              cx="32"
              cy="32"
              rx="26"
              ry="10"
              fill="none"
              stroke={`url(#${uid}_metal)`}
              strokeWidth="1.5"
              strokeDasharray="14 5"
              opacity="0.85"
            />
            <circle cx="58" cy="32" r="2" fill="#FFFFFF" />
          </motion.g>

          {/* Counter-Rotating 3D Meridian Ring */}
          <motion.g
            animate={{ rotate: -360 }}
            transition={{ duration: 13, repeat: Infinity, ease: "linear" }}
            style={{ transformOrigin: "32px 32px" }}
          >
            <ellipse
              cx="32"
              cy="32"
              rx="10"
              ry="25"
              fill="none"
              stroke={secondaryHex}
              strokeWidth="1.2"
              strokeDasharray="10 6"
              opacity="0.7"
            />
          </motion.g>

          {/* Archetype-Specific 3D Geometric Centerpiece */}
          {id === "daily" && (
            <g>
              {/* 3D Octahedron Solar Core */}
              <polygon
                points="32,12 48,32 32,52 16,32"
                fill={`url(#${uid}_core)`}
                stroke="#FFFFFF"
                strokeWidth="0.8"
              />
              <polygon
                points="32,12 48,32 32,36"
                fill="#FFFFFF"
                opacity="0.35"
              />
              <line x1="32" y1="12" x2="32" y2="52" stroke="#FFFFFF" strokeWidth="0.9" opacity="0.75" />
            </g>
          )}

          {id === "1month" && (
            <g>
              {/* 3D Titan Shield & Crown Prism */}
              <polygon
                points="32,11 49,19 45,42 32,53 19,42 15,19"
                fill={`url(#${uid}_core)`}
                stroke={`url(#${uid}_metal)`}
                strokeWidth="1.2"
              />
              <polygon
                points="32,16 43,22 40,39 32,47 24,39 21,22"
                fill="none"
                stroke="#FFFFFF"
                strokeWidth="0.8"
                opacity="0.65"
              />
              <circle cx="32" cy="31" r="5" fill="#FFFFFF" opacity="0.85" />
            </g>
          )}

          {(id === "strength" || id === "pushup") && (
            <g>
              {/* 3D Hexagonal Power Reactor */}
              <polygon
                points="32,13 48,22 48,42 32,51 16,42 16,22"
                fill={`url(#${uid}_core)`}
                stroke="#FFFFFF"
                strokeWidth="1"
              />
              <polygon
                points="32,19 42,25 42,39 32,45 22,39 22,25"
                fill="none"
                stroke="#FFFFFF"
                strokeWidth="0.9"
                opacity="0.7"
              />
              <circle cx="32" cy="32" r="5.5" fill="#FFFFFF" opacity="0.9" />
            </g>
          )}

          {id === "speed" && (
            <g>
              {/* 3D Hyper-Velocity Lightning Prism */}
              <circle cx="32" cy="32" r="15" fill={`url(#${uid}_core)`} />
              <polygon
                points="35,14 21,34 31,34 28,50 43,29 33,29"
                fill="#FFFFFF"
                stroke={primaryHex}
                strokeWidth="0.8"
              />
            </g>
          )}

          {id === "weekly" && (
            <g>
              {/* 3D Celestial Trophy Star Polyhedron */}
              <polygon
                points="32,11 38,24 52,26 41,36 44,50 32,43 20,50 23,36 12,26 26,24"
                fill={`url(#${uid}_core)`}
                stroke="#FFFFFF"
                strokeWidth="0.9"
              />
              <circle cx="32" cy="32" r="6" fill="#FFFFFF" opacity="0.75" />
            </g>
          )}

          {id === "custom" && (
            <g>
              {/* 3D Anatomical Cyber Target Sphere */}
              <circle cx="32" cy="32" r="15" fill={`url(#${uid}_core)`} />
              <circle
                cx="32"
                cy="32"
                r="19"
                fill="none"
                stroke="#FFFFFF"
                strokeWidth="1"
                strokeDasharray="4 4"
              />
              <line x1="32" y1="9" x2="32" y2="21" stroke="#FFFFFF" strokeWidth="1.4" />
              <line x1="32" y1="43" x2="32" y2="55" stroke="#FFFFFF" strokeWidth="1.4" />
              <line x1="9" y1="32" x2="21" y2="32" stroke="#FFFFFF" strokeWidth="1.4" />
              <line x1="43" y1="32" x2="55" y2="32" stroke="#FFFFFF" strokeWidth="1.4" />
            </g>
          )}

          {/* Top-Left Specular Glass Reflection */}
          <ellipse
            cx="25"
            cy="22"
            rx="7"
            ry="3.5"
            transform="rotate(-25 25 22)"
            fill="#FFFFFF"
            opacity="0.45"
          />
        </svg>
      </div>
    </div>
  );
};

export default function ChallengesScreen({ onNavigateToView }: ChallengesScreenProps) {
  const { updateProfileStats, profile, updateUserProfileFields } = useAuth();
  const { logEvent } = useGenieTracker();
  const { triggerEvent } = useGuardianContext();
  const [activeChallenge, setActiveChallenge] = useLocalStorageSync<ActiveChallenge | null>(
    "fitgenie_active_challenge",
    null
  );

  // 'list' | 'builder' | 'active' | 'validation_failed'
  const [view, setView] = useState<"list" | "builder" | "active" | "validation_failed">("list");
  const [showAiCounter, setShowAiCounter] = useState(false);
  const [aiExerciseIndex, setAiExerciseIndex] = useState<number>(0);

  // Interactive 3D Hologram Preview Deck on the Main Challenges Hub
  const [show3DPreviewDeck, setShow3DPreviewDeck] = useState(true);
  const [previewChallengeId, setPreviewChallengeId] = useState<string>("daily");

  const [selectedMuscles, setSelectedMuscles] = useState<string[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const lastTapTimes = useRef<Record<string, number>>({});

  useEffect(() => {
    if (view === "active" && activeChallenge) {
      const now = Date.now();
      const initial: Record<string, number> = {};
      activeChallenge.exercises.forEach((ex) => {
        initial[ex.name.toLowerCase()] = now;
      });
      lastTapTimes.current = initial;
    }
  }, [view, activeChallenge]);

  useEffect(() => {
    if (activeChallenge && activeChallenge.id === "daily") {
      const today = new Date();
      const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(
        today.getDate()
      ).padStart(2, "0")}`;
      const start = new Date(activeChallenge.startTime);
      const startStr = `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, "0")}-${String(
        start.getDate()
      ).padStart(2, "0")}`;
      if (todayStr !== startStr) {
        setActiveChallenge(null);
        if (view === "active") setView("list");
      }
    }
  }, [activeChallenge, view, setActiveChallenge]);

  useEffect(() => {
    const handleFocus = () => {
      if (activeChallenge && activeChallenge.id === "daily") {
        const today = new Date();
        const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(
          today.getDate()
        ).padStart(2, "0")}`;
        const start = new Date(activeChallenge.startTime);
        const startStr = `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, "0")}-${String(
          start.getDate()
        ).padStart(2, "0")}`;
        if (todayStr !== startStr) {
          setActiveChallenge(null);
          if (view === "active") setView("list");
        }
      }
    };

    window.addEventListener("focus", handleFocus);
    window.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") handleFocus();
    });

    const interval = setInterval(handleFocus, 60000);
    return () => {
      window.removeEventListener("focus", handleFocus);
      window.removeEventListener("visibilitychange", handleFocus);
      clearInterval(interval);
    };
  }, [activeChallenge, view, setActiveChallenge]);

  const todayChallenge = getTodayChallenge();

  const challenges = [
    {
      id: "daily",
      title: "Daily Challenge",
      bossName: todayChallenge.boss || "Cyber Titan Overlord",
      desc: todayChallenge.desc,
      xp: todayChallenge.xp,
      difficulty: todayChallenge.difficulty || "Extreme",
      primaryHex: "#FF6B35",
      secondaryHex: "#FFB703",
      previewExercise: todayChallenge.exercises[0]?.name || "Pushups",
      previewMuscles: todayChallenge.muscles || ["Chest", "Core", "Legs"],
      exercises: todayChallenge.exercises,
      time: todayChallenge.time,
      muscles: todayChallenge.muscles,
      boss: todayChallenge.boss,
    },
    {
      id: "1month",
      title: "1 Month Challenge",
      bossName: "Titan Of Discipline",
      desc: "30-Day RPG consistency campaign with Normal & Legendary boss tiers.",
      xp: 500,
      difficulty: "Hard",
      primaryHex: "#38BDF8",
      secondaryHex: "#6366F1",
      previewExercise: "Pushups",
      previewMuscles: ["Chest", "Legs", "Core", "Full Body"],
      exercises: [],
    },
    {
      id: "strength",
      title: "Strength Challenge",
      bossName: "Squat Destroyer",
      desc: "Max Out 150 Squats in 5 minutes to shatter Titan Armor.",
      xp: 150,
      difficulty: "Hard",
      primaryHex: "#B66DFF",
      secondaryHex: "#7209B7",
      previewExercise: "Squats",
      previewMuscles: ["Quads", "Glutes", "Hamstrings"],
      exercises: [{ name: "Squats", targetReps: 150, completedReps: 0 }],
    },
    {
      id: "pushup",
      title: "Pushup Challenge",
      bossName: "Iron Chest Colossus",
      desc: "Complete 100 Pushups as fast as possible with clean form.",
      xp: 200,
      difficulty: "Hard",
      primaryHex: "#FF2A5F",
      secondaryHex: "#FB5607",
      previewExercise: "Pushups",
      previewMuscles: ["Chest", "Triceps", "Shoulders"],
      exercises: [{ name: "Pushups", targetReps: 100, completedReps: 0 }],
    },
    {
      id: "speed",
      title: "Speed Challenge",
      bossName: "Speed Demon Core",
      desc: "50 Burpees under 3 minutes in high-voltage blitz mode.",
      xp: 100,
      difficulty: "Extreme",
      primaryHex: "#00F5D4",
      secondaryHex: "#00BBF9",
      previewExercise: "Burpees",
      previewMuscles: ["Full Body", "Core", "Legs"],
      exercises: [{ name: "Burpees", targetReps: 50, completedReps: 0 }],
    },
    {
      id: "weekly",
      title: "Weekly Warrior",
      bossName: "Leg Destroyer",
      desc: "Accumulate 1,500 Squats across 7 days to claim the Weekly Crown.",
      xp: 500,
      difficulty: "Hard",
      primaryHex: "#C084FC",
      secondaryHex: "#00F5D4",
      previewExercise: "Squats",
      previewMuscles: ["Quads", "Glutes", "Calves"],
      exercises: [{ name: "Squats", targetReps: 1500, completedReps: 0 }],
    },
    {
      id: "custom",
      title: "Custom Challenge",
      bossName: "Custom Anatomical Boss",
      desc: "Select target muscles on the 3D anatomy rig & forge your own mission.",
      xp: 250,
      difficulty: "Custom",
      primaryHex: "#4DA8FF",
      secondaryHex: "#00F5D4",
      previewExercise: "Barbell Bench Press",
      previewMuscles: ["Chest", "Back", "Shoulders", "Arms"],
      exercises: [],
    },
  ];

  const handleStartChallenge = (ch: any) => {
    playSound("click");
    if (ch.id === "custom") {
      setView("builder");
    } else {
      const newActive: ActiveChallenge = {
        id: ch.id,
        title: ch.title,
        xp: ch.xp,
        desc: ch.desc,
        exercises: ch.exercises.map((e: any) => ({ ...e })),
        startTime: Date.now(),
        difficulty: ch.difficulty,
        time: ch.time,
        muscles: ch.muscles,
        boss: ch.boss,
      };
      setActiveChallenge(newActive);
      setView("active");
    }
  };

  const toggleMuscle = (m: string) => {
    playSound("toggle");
    setSelectedMuscles((prev) =>
      prev.includes(m) ? prev.filter((x) => x !== m) : [...prev, m]
    );
  };

  const generateAndStartCustom = () => {
    if (selectedMuscles.length === 0) return;
    playSound("success");

    const userPath =
      profile?.trainingPath ||
      localStorage.getItem("fitgenie_training_path") ||
      "home";

    const isGym = userPath === "gym";

    const MUSCLE_EXERCISES: Record<string, { name: string; targetReps: number }[]> = {
      Chest: isGym
        ? [
            { name: "Barbell Bench Press", targetReps: 36 },
            { name: "Incline Dumbbell Press", targetReps: 36 },
            { name: "Push Ups", targetReps: 45 },
          ]
        : [
            { name: "Push Ups", targetReps: 50 },
            { name: "Wide Push Ups", targetReps: 40 },
            { name: "Diamond Push Ups", targetReps: 30 },
          ],
      Back: isGym
        ? [
            { name: "Lat Pulldowns", targetReps: 40 },
            { name: "Barbell Bent-Over Rows", targetReps: 36 },
            { name: "Pull Ups", targetReps: 25 },
          ]
        : [
            { name: "Pull Ups / Doorway Rows", targetReps: 30 },
            { name: "Superman Hold (Secs)", targetReps: 60 },
            { name: "Reverse Snow Angels", targetReps: 35 },
          ],
      Shoulders: isGym
        ? [
            { name: "Overhead Shoulder Press", targetReps: 36 },
            { name: "Dumbbell Lateral Raises", targetReps: 45 },
            { name: "Pike Push Ups", targetReps: 30 },
          ]
        : [
            { name: "Pike Push Ups", targetReps: 30 },
            { name: "Shoulder Taps", targetReps: 50 },
            { name: "Arm Circles (Secs)", targetReps: 60 },
          ],
      Biceps: isGym
        ? [
            { name: "Barbell Bicep Curls", targetReps: 36 },
            { name: "Hammer Curls", targetReps: 40 },
            { name: "Chin Ups", targetReps: 25 },
          ]
        : [
            { name: "Chin Ups / Towel Curls", targetReps: 35 },
            { name: "Backpack Curls", targetReps: 35 },
            { name: "Isometric Bicep Hold (Secs)", targetReps: 60 },
          ],
      Triceps: isGym
        ? [
            { name: "Cable Tricep Pushdowns", targetReps: 45 },
            { name: "Overhead Tricep Extension", targetReps: 36 },
            { name: "Bench Dips", targetReps: 40 },
          ]
        : [
            { name: "Bench Dips", targetReps: 40 },
            { name: "Diamond Push Ups", targetReps: 30 },
            { name: "Bodyweight Skullcrushers", targetReps: 30 },
          ],
      Forearms: [
        { name: "Wrist Curls", targetReps: 50 },
        { name: "Reverse Wrist Curls", targetReps: 45 },
        { name: "Farmer / Dead Hang (Secs)", targetReps: 60 },
      ],
      Abs: [
        { name: "Crunches", targetReps: 50 },
        { name: "Hanging / Lying Leg Raises", targetReps: 35 },
        { name: "Plank (Secs)", targetReps: 60 },
      ],
      Obliques: [
        { name: "Russian Twists", targetReps: 50 },
        { name: "Side Plank (Secs)", targetReps: 45 },
        { name: "Bicycle Crunches", targetReps: 40 },
      ],
      Quads: isGym
        ? [
            { name: "Barbell / Goblet Squats", targetReps: 40 },
            { name: "Bulgarian Split Squats", targetReps: 30 },
            { name: "Wall Sit (Secs)", targetReps: 60 },
          ]
        : [
            { name: "Squats", targetReps: 50 },
            { name: "Jump Squats", targetReps: 30 },
            { name: "Wall Sit (Secs)", targetReps: 60 },
          ],
      Hamstrings: isGym
        ? [
            { name: "Romanian Deadlifts (RDL)", targetReps: 36 },
            { name: "Lying Hamstring Curls", targetReps: 40 },
            { name: "Single Leg Glute Bridge", targetReps: 30 },
          ]
        : [
            { name: "Single Leg Bridge", targetReps: 35 },
            { name: "Nordic Curl Progression", targetReps: 20 },
            { name: "Glute Bridge Walkouts", targetReps: 35 },
          ],
      Glutes: [
        { name: "Hip Thrusts", targetReps: 45 },
        { name: "Glute Bridges", targetReps: 45 },
        { name: "Jump Lunges", targetReps: 35 },
      ],
      Calves: [
        { name: "Standing Calf Raises", targetReps: 60 },
        { name: "Single Leg Calf Raises", targetReps: 35 },
        { name: "Explosive Calf Hops", targetReps: 50 },
      ],
      Neck: [
        { name: "Neck Flexion", targetReps: 30 },
        { name: "Neck Extension", targetReps: 30 },
        { name: "Neck Isometric Hold (Secs)", targetReps: 45 },
      ],
      Traps: [
        { name: "Shoulder Shrugs", targetReps: 50 },
        { name: "Weighted / Backpack Shrugs", targetReps: 40 },
        { name: "Isometric Trap Hold (Secs)", targetReps: 45 },
      ],
    };

    const uniqueExercises: { name: string; targetReps: number; completedReps: number }[] = [];
    const seenNames = new Set<string>();

    const perMuscleCount =
      selectedMuscles.length === 1 ? 3 : selectedMuscles.length === 2 ? 2 : 1;

    selectedMuscles.forEach((m) => {
      const pool = MUSCLE_EXERCISES[m] || [];
      let addedForMuscle = 0;
      for (const item of pool) {
        if (!seenNames.has(item.name) && addedForMuscle < perMuscleCount) {
          seenNames.add(item.name);
          uniqueExercises.push({
            name: item.name,
            targetReps: item.targetReps,
            completedReps: 0,
          });
          addedForMuscle += 1;
        }
      }
    });

    if (uniqueExercises.length === 0) {
      uniqueExercises.push(
        { name: "Push Ups", targetReps: 40, completedReps: 0 },
        { name: "Squats", targetReps: 50, completedReps: 0 },
        { name: "Plank (Secs)", targetReps: 60, completedReps: 0 }
      );
    }

    const calculatedXp = Math.max(150, uniqueExercises.length * 75);

    const newActive: ActiveChallenge = {
      id: "custom_" + Date.now(),
      title:
        "Target: " +
        selectedMuscles.slice(0, 2).join(", ") +
        (selectedMuscles.length > 2 ? ` +${selectedMuscles.length - 2}` : ""),
      xp: calculatedXp,
      exercises: uniqueExercises,
      muscles: selectedMuscles,
      startTime: Date.now(),
      difficulty:
        uniqueExercises.length >= 5
          ? "Elite"
          : uniqueExercises.length >= 3
          ? "Advanced"
          : "Intermediate",
    };

    setActiveChallenge(newActive);
    setView("active");
  };

  const updateProgress = (exIndex: number, amount: number) => {
    if (!activeChallenge) return;
    playSound("timer_tick");

    const exercise = activeChallenge.exercises[exIndex];
    const exName = exercise.name.toLowerCase();

    let minTimePerRep = 1500;
    if (exName.includes("burpee")) {
      minTimePerRep = 4000;
    } else if (exName.includes("push")) {
      minTimePerRep = 1500;
    } else if (exName.includes("sec") || exName.includes("min")) {
      minTimePerRep = 1000;
    }

    const now = Date.now();

    if (lastTapTimes.current[exName]) {
      const elapsed = now - lastTapTimes.current[exName];
      const requiredTime = amount * minTimePerRep;

      if (elapsed < requiredTime) {
        setToastMessage(
          `Bhai itni jaldi ${amount} ${exercise.name}?? Khud ko dhoka de raha hai kya? Number badhane se body nahi banegi, real mein maar bhai!`
        );
        setTimeout(() => setToastMessage(null), 4000);
        return;
      }
    }

    lastTapTimes.current[exName] = now;

    const updated = { ...activeChallenge };
    updated.exercises[exIndex].completedReps = Math.min(
      updated.exercises[exIndex].targetReps,
      updated.exercises[exIndex].completedReps + amount
    );
    setActiveChallenge(updated);
  };

  const completeChallenge = async (customXp?: number) => {
    if (!activeChallenge) return false;

    playSound("success");
    const xpToAward = customXp !== undefined ? customXp : activeChallenge.xp;
    logEvent("CHALLENGE_COMPLETE", {
      id: activeChallenge.id,
      title: activeChallenge.title,
      xp: xpToAward,
    });
    triggerEvent("challenge_complete");

    if (updateProfileStats && xpToAward > 0) {
      await updateProfileStats({
        xpGained: xpToAward,
        challengeWon: true,
        workoutCompleted: true,
      });
    }

    // Record completed Dojo Challenge into fitgenie_history so 7-day calendar & Workout History stay synced
    try {
      const existingRaw = localStorage.getItem("fitgenie_history");
      const existingHistory = existingRaw ? JSON.parse(existingRaw) : [];
      const inferredMuscles =
        activeChallenge.muscles && activeChallenge.muscles.length > 0
          ? activeChallenge.muscles
          : activeChallenge.id === "pushup"
          ? ["Chest", "Triceps", "Shoulders"]
          : activeChallenge.id === "strength" || activeChallenge.id === "weekly"
          ? ["Quads", "Legs", "Glutes"]
          : ["Full Body", "Core"];

      const newSession = {
        id: `dojo_${activeChallenge.id}_${Date.now()}`,
        date: new Date().toISOString(),
        muscles: inferredMuscles,
        equipment: ["Bodyweight"],
        exercisesCount: activeChallenge.exercises.length || 1,
        totalDurationMin: Math.max(
          5,
          Math.round((Date.now() - (activeChallenge.startTime || Date.now())) / 60000) || 12
        ),
        exercises: activeChallenge.exercises.map((ex, idx) => ({
          id: idx + 1,
          name_en: ex.name,
          name_hi: ex.name,
          sets: 1,
          reps: String(ex.completedReps || ex.targetReps),
          difficulty: (activeChallenge.difficulty?.toLowerCase() as any) || "intermediate",
        })),
        notes: `Dojo Mission Completed: ${activeChallenge.title} (+${xpToAward} XP)`,
        rating: 5,
        isSmartValidation: true,
      };
      localStorage.setItem(
        "fitgenie_history",
        JSON.stringify([newSession, ...existingHistory])
      );
      window.dispatchEvent(new Event("storage"));
    } catch (err) {
      console.warn("Could not sync Dojo challenge to history", err);
    }

    // Leaderboard Stats Update
    if (profile && updateUserProfileFields) {
      const currentStats = profile.stats || {};
      const statsPatch: any = {};
      let shouldUpdate = false;

      activeChallenge.exercises.forEach((ex) => {
        const exerciseName = ex.name.toLowerCase();
        const completedReps = ex.completedReps || 0;

        if (exerciseName.includes("squat")) {
          if (completedReps > (currentStats.squats_all || 0)) {
            statsPatch.squats_all = completedReps;
            shouldUpdate = true;
          }
          if (
            activeChallenge.id === "speed" &&
            completedReps > (currentStats.squats_1min || 0)
          ) {
            statsPatch.squats_1min = completedReps;
            shouldUpdate = true;
          }
        } else if (
          exerciseName.includes("pushup") ||
          exerciseName.includes("push-up") ||
          exerciseName.includes("push up")
        ) {
          if (completedReps > (currentStats.pushups_all || 0)) {
            statsPatch.pushups_all = completedReps;
            shouldUpdate = true;
          }
          if (
            activeChallenge.id === "speed" &&
            completedReps > (currentStats.pushups_1min || 0)
          ) {
            statsPatch.pushups_1min = completedReps;
            shouldUpdate = true;
          }
        }
      });

      if (shouldUpdate) {
        try {
          await updateUserProfileFields({ stats: statsPatch });
        } catch (e) {
          console.error("Failed to update leaderboard stats:", e);
        }
      }
    }

    setActiveChallenge(null);
    setView("list");
    return true;
  };

  if (view === "validation_failed") {
    return (
      <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen flex flex-col items-center justify-center text-center">
        <ShieldAlert className="w-20 h-20 text-red-500 mb-4" />
        <h2 className="text-2xl font-black uppercase text-red-500 tracking-tight">
          Validation Failed
        </h2>
        <p className="text-white font-bold mt-4">
          This challenge was completed faster than humanly possible.
        </p>
        <p className="text-neutral-400 text-sm mt-2">
          Fit Genie rewards real effort. Please complete the challenge honestly.
        </p>
        <p className="text-neutral-500 text-xs font-black uppercase tracking-widest mt-6">
          XP not awarded.
        </p>

        <button
          onClick={() => {
            setView("list");
          }}
          className="mt-10 w-full py-4 bg-neutral-800 hover:bg-neutral-700 text-white font-black uppercase tracking-widest rounded-xl transition cursor-pointer"
        >
          Return to Challenges
        </button>
      </div>
    );
  }

  if (view === "builder") {
    return (
      <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen">
        <button
          onClick={() => {
            playSound("click");
            setView("list");
          }}
          className="flex items-center gap-2 text-[#00F5D4] bg-white/5 border border-white/10 px-3.5 py-2 rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs">
            Back to Missions
          </span>
        </button>

        <div className="text-center space-y-2">
          <h2 className="text-2xl font-black uppercase tracking-tight text-white">
            3D Anatomical Target Builder
          </h2>
          <p className="text-neutral-400 text-xs font-bold uppercase tracking-widest">
            Select target muscle groups to synthesize a custom Boss Mission
          </p>
        </div>

        <div className="relative">
          <MuscleSelector
            selectedMuscles={selectedMuscles}
            toggleMuscle={toggleMuscle}
          />
        </div>

        <motion.button
          onClick={generateAndStartCustom}
          disabled={selectedMuscles.length === 0}
          className={`w-full py-4 font-black text-sm uppercase tracking-widest rounded-2xl transition-all flex items-center justify-center gap-2 ${
            selectedMuscles.length > 0
              ? "bg-gradient-to-r from-[#00F5D4] via-[#38BDF8] to-[#B66DFF] text-[#030712] shadow-[0_0_25px_rgba(0,245,212,0.45)] cursor-pointer"
              : "bg-white/10 text-white/30 cursor-not-allowed"
          }`}
        >
          <Zap className="w-5 h-5" />
          Generate Custom Challenge
        </motion.button>
      </div>
    );
  }

  if (view === "active" && activeChallenge) {
    if (activeChallenge.id === "daily") {
      return (
        <>
          <DailyChallengeDetailScreen
            challenge={activeChallenge}
            onUpdate={setActiveChallenge}
            onBack={() => setView("list")}
            onComplete={completeChallenge}
          />
          {showAiCounter && (
            <AiRepCounter
              initialExercise={
                activeChallenge.exercises[aiExerciseIndex]?.name
                  .toLowerCase()
                  .includes("squat")
                  ? "Squats"
                  : "Pushups"
              }
              onClose={() => setShowAiCounter(false)}
              onComplete={(reps) => {
                const updated = { ...activeChallenge };
                if (updated.exercises[aiExerciseIndex]) {
                  updated.exercises[aiExerciseIndex].completedReps += reps;
                  setActiveChallenge(updated);
                }
                setShowAiCounter(false);
              }}
            />
          )}
        </>
      );
    }
    if (activeChallenge.id === "speed") {
      return (
        <>
          <SpeedChallengeScreen
            challenge={activeChallenge as any}
            onUpdate={setActiveChallenge as any}
            onBack={() => setView("list")}
            onComplete={completeChallenge}
          />
          {showAiCounter && (
            <AiRepCounter
              initialExercise={
                activeChallenge.exercises[aiExerciseIndex]?.name
                  .toLowerCase()
                  .includes("squat")
                  ? "Squats"
                  : "Pushups"
              }
              onClose={() => setShowAiCounter(false)}
              onComplete={(reps) => {
                const updated = { ...activeChallenge };
                if (updated.exercises[aiExerciseIndex]) {
                  updated.exercises[aiExerciseIndex].completedReps += reps;
                  setActiveChallenge(updated);
                }
                setShowAiCounter(false);
              }}
            />
          )}
        </>
      );
    }
    if (activeChallenge.id === "weekly") {
      return (
        <>
          <WeeklyChallengeScreen
            challenge={activeChallenge as any}
            onUpdate={setActiveChallenge as any}
            onBack={() => setView("list")}
            onComplete={completeChallenge}
          />
          {showAiCounter && (
            <AiRepCounter
              initialExercise={
                activeChallenge.exercises[aiExerciseIndex]?.name
                  .toLowerCase()
                  .includes("squat")
                  ? "Squats"
                  : "Pushups"
              }
              onClose={() => setShowAiCounter(false)}
              onComplete={(reps) => {
                const updated = { ...activeChallenge };
                if (updated.exercises[aiExerciseIndex]) {
                  updated.exercises[aiExerciseIndex].completedReps += reps;
                  setActiveChallenge(updated);
                }
                setShowAiCounter(false);
              }}
            />
          )}
        </>
      );
    }

    if (activeChallenge.id === "1month") {
      return (
        <OneMonthChallengeScreen
          challenge={activeChallenge as any}
          onUpdate={setActiveChallenge as any}
          onBack={() => setView("list")}
          onComplete={completeChallenge}
        />
      );
    }
    if (activeChallenge.id === "strength" || activeChallenge.id === "pushup") {
      return (
        <>
          <StrengthChallengeScreen
            challenge={activeChallenge as any}
            onUpdate={setActiveChallenge as any}
            onBack={() => setView("list")}
            onComplete={completeChallenge}
          />
          {showAiCounter && (
            <AiRepCounter
              initialExercise={
                activeChallenge.exercises[aiExerciseIndex]?.name
                  .toLowerCase()
                  .includes("squat")
                  ? "Squats"
                  : "Pushups"
              }
              onClose={() => setShowAiCounter(false)}
              onComplete={(reps) => {
                const updated = { ...activeChallenge };
                if (updated.exercises[aiExerciseIndex]) {
                  updated.exercises[aiExerciseIndex].completedReps += reps;
                  setActiveChallenge(updated);
                }
                setShowAiCounter(false);
              }}
            />
          )}
        </>
      );
    }

    if (activeChallenge.id.startsWith("custom")) {
      return (
        <>
          <CustomChallengeDetailScreen
            challenge={activeChallenge}
            onUpdate={setActiveChallenge}
            onBack={() => setView("list")}
            onComplete={completeChallenge}
            onDelete={() => {
              setActiveChallenge(null);
              setView("list");
            }}
            onEditMuscles={() => {
              setSelectedMuscles(activeChallenge.muscles || []);
              setView("builder");
            }}
          />
          {showAiCounter && (
            <AiRepCounter
              initialExercise={
                activeChallenge.exercises[aiExerciseIndex]?.name
                  .toLowerCase()
                  .includes("squat")
                  ? "Squats"
                  : "Pushups"
              }
              onClose={() => setShowAiCounter(false)}
              onComplete={(reps) => {
                const updated = { ...activeChallenge };
                if (updated.exercises[aiExerciseIndex]) {
                  updated.exercises[aiExerciseIndex].completedReps += reps;
                  setActiveChallenge(updated);
                }
                setShowAiCounter(false);
              }}
            />
          )}
        </>
      );
    }

    const allDone = activeChallenge.exercises.every(
      (ex) => ex.completedReps >= ex.targetReps
    );

    return (
      <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen">
        <button
          onClick={() => {
            playSound("click");
            setView("list");
          }}
          className="flex items-center gap-2 text-[#00F5D4] mb-4 cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs">
            Back to List
          </span>
        </button>

        <div className="text-center space-y-2">
          <h2 className="text-2xl font-black uppercase tracking-tight text-white">
            {activeChallenge.title}
          </h2>
          <div className="flex items-center justify-center gap-2 mt-2 text-xs text-neutral-300 font-bold">
            {!activeChallenge.id.startsWith("custom") && (
              <>
                <span className="text-[#00F5D4]">+{activeChallenge.xp} XP Reward</span>
                <span aria-hidden="true">·</span>
              </>
            )}
            <span className="text-orange-400">In Progress</span>
          </div>
        </div>

        <div className="space-y-4 mt-8">
          {activeChallenge.exercises.map((ex, i) => {
            const isDone = ex.completedReps >= ex.targetReps;
            const progress = Math.min(
              100,
              (ex.completedReps / ex.targetReps) * 100
            );

            return (
              <div
                key={i}
                className="bg-[#050B1A] border border-white/10 rounded-2xl p-5 relative overflow-hidden"
              >
                <div
                  className="absolute left-0 top-0 bottom-0 bg-[#00F5D4]/10 transition-all duration-500 ease-out"
                  style={{ width: `${progress}%` }}
                />

                <div className="relative z-10 flex items-center justify-between">
                  <div>
                    <h4
                      className={`font-black text-lg uppercase tracking-tight ${
                        isDone ? "text-[#00F5D4]" : "text-white"
                      }`}
                    >
                      {ex.name}
                    </h4>
                    <p className="text-neutral-400 text-xs font-bold tracking-wider mt-1 tabular-nums">
                      {ex.completedReps} / {ex.targetReps}{" "}
                      {ex.name.includes("Sec") || ex.name.includes("Min")
                        ? "Time"
                        : "Reps"}
                    </p>
                  </div>

                  {!isDone ? (
                    <div className="flex flex-col gap-2">
                      <button
                        onClick={() => updateProgress(i, 10)}
                        className="bg-white/10 hover:bg-white/20 text-white text-[10px] font-black px-3 py-2 rounded-lg cursor-pointer"
                      >
                        +10
                      </button>
                      <button
                        onClick={() => updateProgress(i, 1)}
                        className="bg-white/5 hover:bg-white/10 text-white text-[10px] font-black px-3 py-2 rounded-lg cursor-pointer"
                      >
                        +1
                      </button>
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-[#00F5D4]/20 flex items-center justify-center text-[#00F5D4]">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {allDone && (
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => completeChallenge()}
            className="w-full py-4 bg-[#00F5D4] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-sm uppercase tracking-widest rounded-xl transition-all shadow-[0_0_20px_rgba(0,245,212,0.4)] flex items-center justify-center gap-2 mt-8 cursor-pointer"
          >
            <Trophy className="w-5 h-5" />
            Claim Reward
          </motion.button>
        )}

        <AnimatePresence>
          {toastMessage && (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className="fixed bottom-24 left-4 right-4 bg-[#050B1A] border border-orange-500/50 shadow-[0_0_15px_rgba(249,115,22,0.3)] rounded-2xl p-4 z-50 flex gap-3 items-start"
            >
              <div className="bg-orange-500/20 text-orange-500 p-2 rounded-full shrink-0">
                <Activity className="w-5 h-5" />
              </div>
              <p className="text-white text-sm font-bold leading-tight">
                {toastMessage}
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  const previewTarget =
    challenges.find((c) => c.id === previewChallengeId) || challenges[0];

  return (
    <div className="max-w-md lg:max-w-5xl mx-auto p-4 space-y-6 pb-28">
      {/* 3D CYBER-TACTICAL COMMAND DECK HEADER */}
      <div className="rounded-3xl bg-gradient-to-br from-[#0A132C] via-[#060C1E] to-[#030712] border border-[#00F5D4]/30 p-5 relative overflow-hidden shadow-[0_12px_40px_rgba(0,0,0,0.65),inset_0_1px_1px_rgba(255,255,255,0.15)]">
        {/* Top Specular Rim Highlight */}
        <div className="absolute top-0 left-8 right-8 h-[1.5px] bg-gradient-to-r from-transparent via-[#00F5D4] to-transparent opacity-80" />
        <div className="absolute -top-16 -right-16 w-44 h-44 rounded-full bg-[#00F5D4]/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-44 h-44 rounded-full bg-[#B66DFF]/10 blur-3xl pointer-events-none" />

        <div className="flex items-start justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-bold text-[#00F5D4] tracking-wider uppercase">
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>3D Boss Arena & Tactical Missions</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-tight mt-1">
              Challenges Arena
            </h1>
            <p className="text-neutral-400 text-xs font-medium mt-1">
              Defeat 3D Boss Shields, track reps with AI Camera, and earn Rank XP.
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              playSound("toggle");
              setShow3DPreviewDeck((prev) => !prev);
            }}
            className="shrink-0 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-[#00F5D4]/35 text-[#00F5D4] text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap"
          >
            {show3DPreviewDeck ? (
              <>
                <EyeOff className="w-3.5 h-3.5" /> Hide 3D Stage
              </>
            ) : (
              <>
                <Eye className="w-3.5 h-3.5" /> 3D Stage
              </>
            )}
          </button>
        </div>

        {/* Live Warrior Combat Telemetry Strip */}
        <div className="grid grid-cols-3 gap-2.5 mt-4 pt-4 border-t border-white/10 relative z-10">
          <div className="bg-[#030712]/70 border border-white/10 rounded-2xl p-3">
            <span className="text-[10px] text-neutral-400 font-bold block">
              Warrior Rank
            </span>
            <span className="text-sm sm:text-base font-black text-white uppercase tracking-tight mt-0.5 block truncate">
              {profile?.rank || "Rookie"}
            </span>
          </div>
          <div className="bg-[#030712]/70 border border-white/10 rounded-2xl p-3">
            <span className="text-[10px] text-neutral-400 font-bold block">
              Total Power XP
            </span>
            <span className="text-sm sm:text-base font-black text-[#00F5D4] font-mono tabular-nums mt-0.5 block">
              {(profile?.xp || 0).toLocaleString()} XP
            </span>
          </div>
          <div className="bg-[#030712]/70 border border-white/10 rounded-2xl p-3">
            <span className="text-[10px] text-neutral-400 font-bold block">
              Active Mission
            </span>
            <span className="text-sm sm:text-base font-black text-amber-400 mt-0.5 block truncate">
              {activeChallenge ? activeChallenge.title : "Ready"}
            </span>
          </div>
        </div>

        {/* INTERACTIVE 3D HOLOGRAM BOSS & FORM SIMULATOR STAGE */}
        <AnimatePresence>
          {show3DPreviewDeck && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 pt-4 border-t border-white/10 space-y-3 overflow-hidden"
            >
              <div className="flex items-center justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono font-bold text-[#00F5D4] uppercase tracking-wider block">
                    Live 3D Hologram Mission Preview
                  </span>
                  <h3 className="text-sm font-black text-white uppercase">
                    {previewTarget.title} · {previewTarget.bossName}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => handleStartChallenge(previewTarget)}
                  className="px-3.5 py-2 rounded-xl bg-[#00F5D4] hover:bg-[#0fd1c3] text-[#030712] font-black text-[11px] uppercase tracking-wider flex items-center gap-1.5 shadow-[0_0_15px_rgba(0,245,212,0.4)] cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Play className="w-3.5 h-3.5 fill-current" /> Launch Mission
                </button>
              </div>

              {/* Mission Selector Tabs for 3D Stage */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {challenges.map((ch) => {
                  const selected = previewChallengeId === ch.id;
                  return (
                    <button
                      key={ch.id}
                      type="button"
                      onClick={() => {
                        playSound("toggle");
                        setPreviewChallengeId(ch.id);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-[11px] font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
                        selected
                          ? "bg-[#00F5D4] text-[#030712] shadow-[0_0_12px_rgba(0,245,212,0.35)]"
                          : "bg-white/5 text-neutral-300 hover:bg-white/10"
                      }`}
                    >
                      {ch.title}
                    </button>
                  );
                })}
              </div>

              <div className="rounded-2xl overflow-hidden border border-[#00F5D4]/30 bg-[#030712]">
                <Exercise3DCharacterLoop
                  exerciseName={previewTarget.previewExercise}
                  targetMuscles={previewTarget.previewMuscles}
                  difficulty="advanced"
                  heightClass="h-[215px]"
                  showControls={true}
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 3D SPATIAL CHALLENGE CARDS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {challenges.map((challenge, index) => {
          const isActive =
            activeChallenge?.id === challenge.id ||
            (challenge.id === "custom" &&
              Boolean(activeChallenge?.id.startsWith("custom_")));

          const activeRepsDone =
            isActive && activeChallenge?.exercises?.length
              ? activeChallenge.exercises.reduce(
                  (sum, e) => sum + (e.completedReps || 0),
                  0
                )
              : 0;
          const activeRepsTarget =
            isActive && activeChallenge?.exercises?.length
              ? activeChallenge.exercises.reduce(
                  (sum, e) => sum + (e.targetReps || 0),
                  0
                )
              : 0;
          const activePct =
            activeRepsTarget > 0
              ? Math.min(100, Math.round((activeRepsDone / activeRepsTarget) * 100))
              : 0;

          return (
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.06 }}
              key={challenge.id}
              onClick={() => {
                setPreviewChallengeId(challenge.id);
              }}
              style={{
                borderColor: isActive
                  ? "#00F5D4"
                  : `${challenge.primaryHex}40`,
                boxShadow: isActive
                  ? "0 14px 35px rgba(0,245,212,0.18), inset 0 1px 1px rgba(255,255,255,0.2)"
                  : `0 10px 28px rgba(0,0,0,0.55), inset 0 1px 1px rgba(255,255,255,0.1)`,
              }}
              className="rounded-3xl bg-gradient-to-br from-[#0B1530]/95 via-[#070E22]/95 to-[#040814] border p-5 relative overflow-hidden flex flex-col justify-between transition-transform duration-200 hover:-translate-y-0.5"
            >
              {/* Top 3D Specular Rim Line */}
              <div
                className="absolute top-0 left-6 right-6 h-[1.5px] opacity-75 pointer-events-none"
                style={{
                  background: `linear-gradient(90deg, transparent, ${challenge.primaryHex}, transparent)`,
                }}
              />

              {/* Ambient 3D Corner Glow */}
              <div
                className="absolute -top-12 -right-12 w-36 h-36 rounded-full blur-3xl pointer-events-none opacity-25"
                style={{ backgroundColor: challenge.primaryHex }}
              />

              <div>
                <div className="flex items-start gap-4 relative z-10">
                  {/* Custom 3D Volumetric Holographic Emblem */}
                  <Challenge3DEmblem
                    id={challenge.id}
                    primaryHex={challenge.primaryHex}
                    secondaryHex={challenge.secondaryHex}
                  />

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className="text-[10px] font-mono font-bold uppercase tracking-wider truncate"
                        style={{ color: challenge.primaryHex }}
                      >
                        Boss · {challenge.bossName}
                      </span>
                      {isActive && (
                        <span className="text-[10px] font-black uppercase tracking-wider text-[#00F5D4] shrink-0">
                          Active Mission
                        </span>
                      )}
                    </div>

                    <h3 className="text-white font-black text-lg uppercase tracking-tight mt-0.5 truncate">
                      {isActive && challenge.id === "custom"
                        ? activeChallenge?.title
                        : challenge.title}
                    </h3>

                    <p className="text-neutral-300 text-xs leading-relaxed mt-1">
                      {challenge.desc}
                    </p>

                    {/* Clean Unboxed Metadata with Typographic Separators */}
                    <div className="flex flex-wrap items-center gap-2 mt-3 text-xs font-bold text-neutral-400 tabular-nums">
                      <span style={{ color: challenge.primaryHex }}>
                        +
                        {isActive && challenge.id === "custom"
                          ? activeChallenge?.xp
                          : challenge.xp}{" "}
                        XP
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="text-neutral-300">
                        {challenge.difficulty} Difficulty
                      </span>
                      {challenge.exercises.length > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-neutral-400">
                            {challenge.exercises.reduce(
                              (s, e) => s + e.targetReps,
                              0
                            )}{" "}
                            Total Reps
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Live Progress Bar when Active */}
                {isActive && activeRepsTarget > 0 && (
                  <div className="mt-4 pt-3 border-t border-white/10 space-y-1.5 relative z-10">
                    <div className="flex justify-between text-[11px] font-mono font-bold">
                      <span className="text-neutral-300">Mission Progress</span>
                      <span className="text-[#00F5D4] tabular-nums">
                        {activeRepsDone} / {activeRepsTarget} ({activePct}%)
                      </span>
                    </div>
                    <div className="h-2 bg-black/60 rounded-full overflow-hidden p-0.5 border border-white/10">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-[#00F5D4] to-[#B66DFF] transition-all duration-300"
                        style={{ width: `${activePct}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* 3D Tactile Action Row */}
              <div className="mt-5 flex items-center gap-2.5 relative z-10">
                {isActive ? (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      playSound("click");
                      setView("active");
                    }}
                    className="flex-1 py-3.5 px-4 bg-gradient-to-r from-[#00F5D4]/20 to-[#B66DFF]/20 hover:from-[#00F5D4]/30 hover:to-[#B66DFF]/30 border border-[#00F5D4]/60 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition duration-150 cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap shadow-[0_0_20px_rgba(0,245,212,0.2)]"
                  >
                    <Activity className="w-4 h-4 text-[#00F5D4]" />
                    Continue Mission
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleStartChallenge(challenge);
                    }}
                    style={{
                      background: `linear-gradient(135deg, ${challenge.primaryHex} 0%, ${challenge.secondaryHex} 100%)`,
                      boxShadow: `0 6px 20px ${challenge.primaryHex}40, inset 0 1px 1px rgba(255,255,255,0.4)`,
                    }}
                    className="flex-1 py-3.5 px-4 text-[#030712] font-black text-xs uppercase tracking-widest rounded-2xl transition duration-150 cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap active:scale-[0.98]"
                  >
                    {challenge.id === "custom" ? (
                      <TargetIcon className="w-4 h-4" />
                    ) : (
                      <Play className="w-4 h-4 fill-current" />
                    )}
                    {challenge.id === "custom"
                      ? "Create Custom Challenge"
                      : "Start Challenge"}
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
