import React, { useState, useEffect, useRef } from "react";
import { ResponsiveContainer } from "recharts";

interface SafeResponsiveContainerProps {
  children: React.ReactElement;
  height?: number | string;
  width?: number | string;
  minHeight?: number;
}

export default function SafeResponsiveContainer({
  children,
  height = "100%",
  width = "100%",
  minHeight,
}: SafeResponsiveContainerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState<{ width: number; height: number } | null>(null);

  useEffect(() => {
    let active = true;
    if (!containerRef.current) return;

    const observeTarget = containerRef.current;
    const resizeObserver = new ResizeObserver((entries) => {
      if (!active || !entries || entries.length === 0) return;
      const { width, height } = entries[0].contentRect;
      
      if (width > 0 && height > 0) {
        setDimensions({ width, height });
      }
    });

    resizeObserver.observe(observeTarget);

    // Initial check
    const rect = observeTarget.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) {
      setDimensions({ width: rect.width, height: rect.height });
    }

    return () => {
      active = false;
      resizeObserver.unobserve(observeTarget);
      resizeObserver.disconnect();
    };
  }, []);

  // Compute inline styles safely
  const style: React.CSSProperties = {
    width: "100%",
    height: typeof height === "number" ? `${height}px` : height,
  };
  
  if (minHeight) {
    style.minHeight = `${minHeight}px`;
  }

  return (
    <div 
      ref={containerRef} 
      style={style}
      className="w-full h-full relative overflow-hidden"
    >
      {dimensions ? (
        <ResponsiveContainer width={dimensions.width} height={dimensions.height}>
          {children}
        </ResponsiveContainer>
      ) : (
        <div className="absolute inset-0 flex items-center justify-center text-[10px] text-[#444] font-mono uppercase tracking-widest">
          Loading graph...
        </div>
      )}
    </div>
  );
}
