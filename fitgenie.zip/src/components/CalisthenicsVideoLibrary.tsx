import React, { useState, useMemo } from "react";
import { motion } from "motion/react";
import { Video, Play, Search, Box, Sparkles } from "lucide-react";
import videosData from "../data/calisthenics_videos.json";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";
import { playSound } from "../utils/audio";

export default function CalisthenicsVideoLibrary() {
  const [failedVideos, setFailedVideos] = useState<Set<string>>(new Set());
  const [playingVideoId, setPlayingVideoId] = useState<string | null>(null);
  const [active3DIds, setActive3DIds] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<
    "all" | "push" | "pull" | "core" | "skills"
  >("all");

  const handleImageError = (id: string) => {
    setFailedVideos((prev) => new Set(prev).add(id));
  };

  const inferMusclesAndCategory = (title: string) => {
    const lower = title.toLowerCase();
    if (
      lower.includes("planche") ||
      lower.includes("handstand") ||
      lower.includes("lever") ||
      lower.includes("flag") ||
      lower.includes("muscle up")
    ) {
      return {
        category: "skills" as const,
        muscles: ["Full Body", "Shoulders", "Core"],
      };
    }
    if (
      lower.includes("pull") ||
      lower.includes("chin") ||
      lower.includes("back") ||
      lower.includes("row")
    ) {
      return {
        category: "pull" as const,
        muscles: ["Back", "Biceps", "Forearms"],
      };
    }
    if (
      lower.includes("abs") ||
      lower.includes("core") ||
      lower.includes("l-sit") ||
      lower.includes("plank")
    ) {
      return {
        category: "core" as const,
        muscles: ["Abs", "Core", "Obliques"],
      };
    }
    return {
      category: "push" as const,
      muscles: ["Chest", "Triceps", "Shoulders"],
    };
  };

  const filteredVideos = useMemo(() => {
    return videosData.filter((v) => {
      const meta = inferMusclesAndCategory(v.title);
      if (categoryFilter !== "all" && meta.category !== categoryFilter) {
        return false;
      }
      if (!searchQuery.trim()) return true;
      return v.title.toLowerCase().includes(searchQuery.toLowerCase());
    });
  }, [searchQuery, categoryFilter]);

  const toggle3DMode = (id: string) => {
    playSound("click");
    setActive3DIds((prev) => ({
      ...prev,
      [id]: prev[id] === undefined ? false : !prev[id],
    }));
  };

  return (
    <div className="max-w-3xl mx-auto p-4 space-y-6 pb-24 relative min-h-screen bg-[#050B1A]">
      {/* HEADER */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-[#0D1630] via-[#091024] to-[#050B1A] border border-[#14F1E1]/25 shadow-[0_0_30px_rgba(20,241,225,0.08)] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#14F1E1]/10 border border-[#14F1E1]/30 text-[#14F1E1] text-[9px] font-mono font-black uppercase tracking-widest mb-2">
            <Sparkles className="w-3 h-3" /> Video Masterclass
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight flex items-center gap-2.5">
            <Video className="w-7 h-7 text-[#14F1E1]" />
            CALISTHENICS LIBRARY
          </h2>
          <p className="text-xs text-neutral-400 font-medium mt-1">
            Interactive form guide & step-by-step tutorials ({filteredVideos.length} drills)
          </p>
        </div>
      </div>

      {/* SEARCH & CATEGORY PILLS */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-neutral-500 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search planche, pull ups, pushups, handstand..."
            className="w-full bg-[#0A1128] border border-[#14F1E1]/25 rounded-2xl pl-11 pr-4 py-3 text-xs sm:text-sm text-white placeholder-neutral-500 font-bold focus:outline-none focus:border-[#14F1E1]"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {[
            { id: "all", label: "All Masterclasses" },
            { id: "skills", label: "Static & Pro Skills" },
            { id: "push", label: "Push Power" },
            { id: "pull", label: "Pull & Back" },
            { id: "core", label: "Core & Compression" },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                playSound("click");
                setCategoryFilter(cat.id as any);
              }}
              className={`shrink-0 px-3.5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all cursor-pointer ${
                categoryFilter === cat.id
                  ? "bg-[#14F1E1] text-[#050B1A] border-[#14F1E1] shadow-[0_0_12px_rgba(20,241,225,0.4)]"
                  : "bg-[#0A1128] border-white/10 text-neutral-400 hover:text-white"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredVideos.map((video, index) => {
          const meta = inferMusclesAndCategory(video.title);
          const isVideoBroken = failedVideos.has(video.id);
          const show3D =
            active3DIds[video.id] !== undefined
              ? active3DIds[video.id]
              : isVideoBroken || index < 2;

          return (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(index * 0.04, 0.4) }}
              className="bg-[#0A1128] border border-[#14F1E1]/20 hover:border-[#14F1E1]/50 rounded-2xl overflow-hidden transition-all flex flex-col justify-between shadow-lg"
            >
              <div className="relative w-full bg-[#050B1A]">
                {show3D ? (
                  <Exercise3DCharacterLoop
                    exerciseName={video.title}
                    targetMuscles={meta.muscles}
                    difficulty="advanced"
                    heightClass="h-[220px]"
                    showControls={true}
                  />
                ) : playingVideoId === video.id ? (
                  <div className="relative aspect-video w-full bg-black">
                    <iframe
                      width="100%"
                      height="100%"
                      src={`https://www.youtube.com/embed/${video.id}?autoplay=1`}
                      title={video.title}
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      allowFullScreen
                      className="absolute top-0 left-0 w-full h-full"
                    />
                  </div>
                ) : (
                  <div className="relative aspect-video w-full bg-black">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      onError={() => handleImageError(video.id)}
                      className="w-full h-full object-cover opacity-85 hover:opacity-100 transition-opacity cursor-pointer"
                      loading="lazy"
                      onClick={() => setPlayingVideoId(video.id)}
                    />
                    <div
                      className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/15 transition-colors cursor-pointer"
                      onClick={() => setPlayingVideoId(video.id)}
                    >
                      <div className="w-12 h-12 rounded-full bg-[#14F1E1] flex items-center justify-center shadow-[0_0_20px_rgba(20,241,225,0.5)]">
                        <Play className="w-5 h-5 text-[#050B1A] ml-0.5 fill-current" />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-4 flex items-center justify-between gap-3 bg-[#080E20] border-t border-white/5">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 mb-1">
                    {meta.muscles.map((m) => (
                      <span
                        key={m}
                        className="text-[8px] font-mono font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-[#14F1E1]/10 text-[#14F1E1]"
                      >
                        {m}
                      </span>
                    ))}
                  </div>
                  <h3 className="text-white font-black text-xs sm:text-sm leading-snug truncate">
                    {video.title}
                  </h3>
                </div>

                {!isVideoBroken && (
                  <button
                    type="button"
                    onClick={() => toggle3DMode(video.id)}
                    className={`shrink-0 px-2.5 py-1.5 rounded-xl text-[9px] font-mono font-black uppercase tracking-wider border flex items-center gap-1 cursor-pointer transition-all ${
                      show3D
                        ? "bg-[#14F1E1] text-[#050B1A] border-[#14F1E1]"
                        : "bg-white/5 text-[#14F1E1] border-[#14F1E1]/30 hover:bg-[#14F1E1]/15"
                    }`}
                  >
                    <Box className="w-3 h-3" />
                    {show3D ? "Video" : "Form Guide"}
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}

        {filteredVideos.length === 0 && (
          <div className="col-span-full text-center text-neutral-400 py-12 font-bold text-xs uppercase tracking-widest border border-dashed border-[#14F1E1]/20 rounded-2xl">
            No matching calisthenics drills found
          </div>
        )}
      </div>
    </div>
  );
}
