import { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import SafeResponsiveContainer from "./SafeResponsiveContainer";
import { 
  AreaChart, Area, CartesianGrid, XAxis, YAxis, Tooltip
} from "recharts";
import { 
  Flame, Bell, Zap, Trophy, ChevronRight, LogOut, RefreshCw, MessageSquare, Play, Square, Activity, Footprints, Target, Share2
} from "lucide-react";
import { CompletedSession } from "../types";
import { playSound } from "../utils/audio";
import { useLocalStorageSync } from "../hooks/useLocalStorageSync";
import { useAuth, getRankDetails } from "../context/AuthContext";
import { useGuardianContext } from "../context/GuardianContext";
import MuscleRecoveryMap from "./MuscleRecoveryMap";
import FlexCardModal from "./FlexCardModal";
import WarriorSuiteHub from "./WarriorSuiteHub";
import PersonalizationHub from "./PersonalizationHub";
import ApexBioLab from "./ApexBioLab";
import GlowUpAndRecoveryHub from "./GlowUpAndRecoveryHub";
import CyberEvolutionAndDuelHub from "./CyberEvolutionAndDuelHub";
import { useAppLanguage } from "../utils/language";
import { speakGenie } from "../utils/voiceCoach";

interface HomeDashboardProps {
  onNavigateToCoach: () => void;
  onNavigateToLeaderboard?: () => void;
  onNavigateToExercises?: (query: string) => void;
  onOpenRecalibrate?: () => void;
  onSaveSmartSession?: (session: CompletedSession) => void;
  streakCount: number;
  history: CompletedSession[];
}

export default function HomeDashboard({
  onNavigateToCoach,
  onNavigateToLeaderboard,
  onNavigateToExercises,
  onOpenRecalibrate,
  onSaveSmartSession,
  streakCount,
  history,
}: HomeDashboardProps) {
  const { triggerEvent } = useGuardianContext();
  const { profile, signOutUser } = useAuth();
  const { lang: appLang, setLang: setAppLang, t } = useAppLanguage();
  
  useEffect(() => {
    let daysInactive = 0;
    if (profile?.last_workout_date) {
      const lastWorkout = new Date(profile.last_workout_date);
      const today = new Date();
      // Compare by date only
      lastWorkout.setHours(0, 0, 0, 0);
      today.setHours(0, 0, 0, 0);
      daysInactive = Math.floor((today.getTime() - lastWorkout.getTime()) / (1000 * 60 * 60 * 24));
    }
    
    if (daysInactive >= 7) {
      triggerEvent("inactive_7");
    } else if (daysInactive >= 3) {
      triggerEvent("inactive_3");
    } else if (daysInactive >= 1) {
      triggerEvent("inactive_1");
    } else {
      if (streakCount === 90) triggerEvent("streak_90");
      else if (streakCount === 30) triggerEvent("streak_30");
      else if (streakCount === 7) triggerEvent("streak_7");
      else triggerEvent("home_greet");
    }
  }, [profile?.last_workout_date, streakCount]);
  const [notification, setNotification] = useState<string | null>(null);

  // Stats derived
  const userXP = Number(profile?.xp || 0);

  const [prevXP, setPrevXP] = useState(userXP);
  const [isLevelingUp, setIsLevelingUp] = useState(false);
  const [showSystemPortal, setShowSystemPortal] = useState(false);
  const [streakBurstActive, setStreakBurstActive] = useState(false);
  const [celebratedMilestoneValue, setCelebratedMilestoneValue] = useState<number>(streakCount || 1);
  const [cardTilt, setCardTilt] = useState<{ rx: number; ry: number; gx: number; gy: number }>({
    rx: 0,
    ry: 0,
    gx: 50,
    gy: 50,
  });
  const [hasGrantedPermission, setHasGrantedPermission] = useLocalStorageSync<boolean>("fitgenie_motion_permission", false);
  const [showPermissionPopup, setShowPermissionPopup] = useState(false);
  const [showFlexCard, setShowFlexCard] = useState(false);
  const [homeDeckTab, setHomeDeckTab] = useState<"overview" | "labs" | "arena">("overview");

  // 36 High-Fidelity 3D Particle Vectors for Streak Milestone Explosion
  const streakParticles = useMemo(() => {
    const palette = ["#14F1E1", "#FFB703", "#B66DFF", "#FF5E3A", "#38BDF8"];
    const shapes: Array<"diamond" | "orb" | "spark"> = ["diamond", "orb", "spark"];
    return Array.from({ length: 36 }, (_, i) => {
      const angle = (i / 36) * Math.PI * 2 + (i % 3) * 0.08;
      const velocity = 95 + (i % 5) * 42;
      return {
        id: i,
        tx: Math.cos(angle) * velocity,
        ty: Math.sin(angle) * velocity - 18,
        rot: (i % 2 === 0 ? 1 : -1) * (180 + (i * 25) % 360),
        scale: 0.75 + (i % 4) * 0.32,
        delay: (i % 6) * 0.025,
        color: palette[i % palette.length],
        shape: shapes[i % shapes.length],
      };
    });
  }, []);

  const triggerStreakMilestoneBurst = (milestoneVal: number) => {
    setCelebratedMilestoneValue(milestoneVal);
    setStreakBurstActive(true);
    playSound("success");
    setTimeout(() => {
      setStreakBurstActive(false);
    }, 3400);
  };

  // Detect new streak milestones automatically + listen for global header streak pill trigger
  useEffect(() => {
    const milestones = [1, 3, 5, 7, 10, 14, 21, 30, 45, 50, 60, 75, 90, 100];
    const isMilestone =
      streakCount > 0 && (milestones.includes(streakCount) || streakCount % 7 === 0);

    if (isMilestone) {
      const lastCelebrated = Number(
        localStorage.getItem("fitgenie_last_streak_milestone") || "0"
      );
      if (streakCount > lastCelebrated) {
        localStorage.setItem("fitgenie_last_streak_milestone", String(streakCount));
        triggerStreakMilestoneBurst(streakCount);
      }
    }
  }, [streakCount]);

  useEffect(() => {
    const handleGlobalStreakBurst = () => {
      triggerStreakMilestoneBurst(Math.max(1, streakCount));
    };
    window.addEventListener("trigger_streak_explosion", handleGlobalStreakBurst);
    return () => window.removeEventListener("trigger_streak_explosion", handleGlobalStreakBurst);
  }, [streakCount]);

  useEffect(() => {
    if (userXP > prevXP) {
      setIsLevelingUp(true);
      setShowSystemPortal(true);
      const timer = setTimeout(() => setIsLevelingUp(false), 2500);
      setPrevXP(userXP);
      return () => clearTimeout(timer);
    }
  }, [userXP, prevXP]);
  
  

  const rank = getRankDetails(userXP);
  const progressPercent = Math.min(100, Math.max(0, ((userXP - rank.base) / (rank.nextXP - rank.base)) * 100));

  // Local date helper
  const getLocalDateString = (date = new Date()) => {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const dd = String(date.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  const todayStr = getLocalDateString();

  const [voicePlayed, setVoicePlayed] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState<string | null>(null);
  const [dailyInsight, setDailyInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);

  useEffect(() => {
    const fetchInsight = async () => {
      const lastFetchDate = localStorage.getItem("daily_insight_date");
      const savedInsight = localStorage.getItem("daily_insight_text");
      
      if (lastFetchDate === todayStr && savedInsight) {
        setDailyInsight(savedInsight);
        return;
      }

      setLoadingInsight(true);
      try {
        const res = await fetch("/api/fitness-insight", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ goal: profile?.mainGoal || "general fitness" })
        });
        const data = await res.json();
        if (data.insight) {
          setDailyInsight(data.insight);
          localStorage.setItem("daily_insight_date", todayStr);
          localStorage.setItem("daily_insight_text", data.insight);
        }
      } catch (e) {
        console.error("Failed to fetch insight", e);
      } finally {
        setLoadingInsight(false);
      }
    };
    fetchInsight();
  }, [profile?.mainGoal, todayStr]);

  // Daily Random Bro Coach Welcome Voice System
  useEffect(() => {
    const lastPlayedDate = localStorage.getItem("bro_coach_welcome_date");
    let currentSelectedVoice = localStorage.getItem("bro_coach_welcome_voice");
    
    if (lastPlayedDate !== todayStr) {
      const voices = [
        "welcome_1.mp3",
        "welcome_2.mp3",
        "welcome_3.mp3",
        "welcome_4.mp3",
        "welcome_5.mp3"
      ];
      
      const availableVoices = voices.filter(v => v !== currentSelectedVoice);
      currentSelectedVoice = availableVoices[Math.floor(Math.random() * availableVoices.length)];
      
      localStorage.setItem("bro_coach_welcome_date", todayStr);
      localStorage.setItem("bro_coach_welcome_voice", currentSelectedVoice);
      localStorage.removeItem("bro_coach_welcome_played_date");
    }
    
    setSelectedVoice(currentSelectedVoice);
    if (localStorage.getItem("bro_coach_welcome_played_date") === todayStr) {
      setVoicePlayed(true);
    }
  }, [todayStr]);

  const handlePlayVoice = () => {
    const message = t(
      "Uth ja bhai! Aaj ka workout aur diet target pura karna hai. Tera 90-day glow up rukna nahi chahiye!",
      "Let's go warrior! Time to crush today's workout and hit your protein target. Stay locked in on your 90-day glow up!"
    );
    speakGenie(message);
    setVoicePlayed(true);
    localStorage.setItem("bro_coach_welcome_played_date", todayStr);
  };

  const [stepLogs, setStepLogs] = useLocalStorageSync<{dateStr: string; steps: number}[]>("fitgenie_steps_history", []);
  const todaySteps = stepLogs.find((l) => l.dateStr === todayStr)?.steps || 0;

  // Trigger permission popup on mount if permission is not granted
  useEffect(() => {
    if (!hasGrantedPermission) {
      if (typeof (DeviceMotionEvent as any)?.requestPermission === 'function') {
        setShowPermissionPopup(true);
      } else {
        setHasGrantedPermission(true);
      }
    }
  }, [hasGrantedPermission, setHasGrantedPermission]);

  const requestMotionPermission = async () => {
    playSound("click");
    if (typeof (DeviceMotionEvent as any)?.requestPermission === 'function') {
      try {
        const permission = await (DeviceMotionEvent as any).requestPermission();
        if (permission === 'granted') {
          setHasGrantedPermission(true);
          setShowPermissionPopup(false);
        } else {
          console.warn('Permission denied. Step tracking is unavailable.');
          setShowPermissionPopup(false);
        }
      } catch (error) {
        console.error(error);
        setHasGrantedPermission(true);
        setShowPermissionPopup(false);
      }
    } else {
      setHasGrantedPermission(true);
      setShowPermissionPopup(false);
    }
  };

  // Calculate dynamic weekly calendar checkboxes mapping the last 7 days ending today
  const weeklyChartData = useMemo(() => {
    const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const result = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const targetDateStr = getLocalDateString(d);
      const sessionsOnDay = history.filter((s) => s.date.startsWith(targetDateStr));
      const totalDuration = sessionsOnDay.reduce((sum, s) => sum + s.totalDurationMin, 0);
      result.push({
        name: daysOfWeek[d.getDay()],
        duration: totalDuration,
      });
    }
    return result;
  }, [history]);

  // Smart Routine Recommender logic
  const recommendedWorkout = useMemo(() => {
    const priorities = ["legs", "back", "chest", "shoulders", "core", "biceps", "triceps"];
    const today = new Date();
    
    const last7DaysHistory = history.filter(s => {
      const sDate = new Date(s.date);
      const diffTime = Math.abs(today.getTime() - sDate.getTime());
      const diffDays = diffTime / (1000 * 60 * 60 * 24);
      return diffDays <= 7;
    });

    const trainedMuscles = new Set<string>();
    last7DaysHistory.forEach(s => {
      if (s.muscles) {
        s.muscles.forEach(m => trainedMuscles.add(m.toLowerCase()));
      }
    });

    let missedMuscle = priorities.find(m => !trainedMuscles.has(m));
    
    if (!missedMuscle) {
       missedMuscle = "core"; 
    }

    const activePath =
      profile?.trainingPath ||
      (localStorage.getItem("fitgenie_training_path") as any) ||
      "calisthenics";

    const pathTitleMap: Record<string, Record<string, string>> = {
      calisthenics: {
        chest: "Explosive Pushup & Dip Mastery",
        back: "Pull-Up Bar & Front Lever Pull",
        shoulders: "Pike Pushup & Handstand Prep",
        legs: "Pistol Squat & Jump Power",
        core: "Hollow Body & L-Sit Shredder",
        biceps: "Chin-Up & Isometric Bar Curl",
        triceps: "Diamond Pushup & Bar Dip Burn",
      },
      home_jugaad: {
        chest: "Hostel Backpack Weighted Pushups",
        back: "Towel Door-Frame Row & Pull",
        shoulders: "Bed-Edge Pike & Bucket Delt Raises",
        legs: "Desi Baithak & Backpack Squats",
        core: "Floor Abs & Plank Burnout",
        biceps: "Loaded Backpack Curls (Jugaad)",
        triceps: "Chair Dips & Close-Grip Pushups",
      },
      gym: {
        chest: "Heavy Barbell & Incline Dumbbell Press",
        back: "Lat Pulldown & Barbell Row Thickness",
        shoulders: "Overhead Press & Lateral Raise Pump",
        legs: "Barbell Squat & Leg Press Destruction",
        core: "Cable Crunch & Hanging Leg Raise",
        biceps: "EZ-Bar Curl & Hammer Pump",
        triceps: "Rope Pushdown & Skullcrushers",
      },
      aesthetics: {
        chest: "Upper Chest Clavicular Shelf Builder",
        back: "1.618 Golden Ratio V-Taper Lat Width",
        shoulders: "Side Delt & Posture Rear-Delt Sculpt",
        legs: "Athletic Quad Sweep & Calf Proportion",
        core: "Vacuum Waist Tightener & Abs Etching",
        biceps: "Long-Head Peak & Forearm Vascularity",
        triceps: "Lateral Head Aesthetic Sweep",
      },
    };

    const selectedMap = pathTitleMap[activePath] || pathTitleMap.calisthenics;

    return {
      muscle: missedMuscle,
      title: selectedMap[missedMuscle] || `${missedMuscle.charAt(0).toUpperCase() + missedMuscle.slice(1)} Protocol`,
      description: `Tailored for your ${activePath.replace("_", " ").toUpperCase()} path — hit ${missedMuscle} today for +120 XP!`
    };
  }, [history, profile?.trainingPath]);

  // Calculate dynamic weekly step data
  const weeklyStepsData = useMemo(() => {
    const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const result = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const targetDateStr = getLocalDateString(d);
      const log = stepLogs.find((l) => l.dateStr === targetDateStr);
      result.push({
        name: daysOfWeek[d.getDay()],
        steps: log ? log.steps : 0,
      });
    }
    return result;
  }, [stepLogs]);

  const dailyCalories = useMemo(() => {
    const sessionsToday = history.filter((s) => s.date.startsWith(todayStr));
    const totalMinutes = sessionsToday.reduce((sum, s) => sum + s.totalDurationMin, 0);
    return Math.round(totalMinutes * 8.5);
  }, [history, todayStr]);
  const dailyCalorieTarget = profile?.dailyCalorieTarget || 500;
  const caloriePercent = Math.min(100, Math.max(0, (dailyCalories / dailyCalorieTarget) * 100));

  const dailyXP = Number(profile?.dailyXP || 0);
  const dailyXPTarget = 200;
  const xpPercent = Math.min(100, Math.max(0, (dailyXP / dailyXPTarget) * 100));

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 pb-24">
      {/* 3D HERO COMMAND COCKPIT HEADER */}
      <div className="relative rounded-3xl bg-gradient-to-br from-[#0B152E]/95 via-[#070E20]/95 to-[#050A18]/95 border border-[#14F1E1]/30 p-4 shadow-[0_16px_38px_rgba(0,0,0,0.8),0_0_24px_rgba(20,241,225,0.12),inset_0_1px_1px_rgba(255,255,255,0.18)] overflow-hidden">
        {/* Top Specular Bevel */}
        <div className="absolute top-0 left-6 right-6 h-[1px] bg-gradient-to-r from-transparent via-[#14F1E1]/70 to-transparent pointer-events-none" />

        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3.5">
            <div className="relative w-16 h-16 flex items-center justify-center shrink-0">
              {/* Outer Rotating Cyber Gyroscope */}
              <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 64 64">
                <circle cx="32" cy="32" r="26" stroke="#F59E0B" strokeWidth="2.5" fill="none" opacity="0.18" />
                <motion.circle
                  cx="32"
                  cy="32"
                  r="26"
                  stroke="#F59E0B"
                  strokeWidth="2.5"
                  fill="none"
                  strokeDasharray="163.36"
                  strokeDashoffset={163.36 - (163.36 * caloriePercent) / 100}
                  strokeLinecap="round"
                  initial={{ strokeDashoffset: 163.36 }}
                  animate={{ strokeDashoffset: 163.36 - (163.36 * caloriePercent) / 100 }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                />
                <circle cx="32" cy="32" r="30.5" stroke="#14F1E1" strokeWidth="2.5" fill="none" opacity="0.18" />
                <motion.circle
                  cx="32"
                  cy="32"
                  r="30.5"
                  stroke="#14F1E1"
                  strokeWidth="2.5"
                  fill="none"
                  strokeDasharray="191.6"
                  strokeDashoffset={191.6 - (191.6 * xpPercent) / 100}
                  strokeLinecap="round"
                  initial={{ strokeDashoffset: 191.6 }}
                  animate={{ strokeDashoffset: 191.6 - (191.6 * xpPercent) / 100 }}
                  transition={{ duration: 1.5, ease: "easeOut", delay: 0.2 }}
                />
              </svg>

              {/* 3D Holographic Warrior Visor Core Avatar */}
              <div className="w-11 h-11 rounded-full bg-gradient-to-b from-[#132247] to-[#080F24] border border-[#14F1E1]/50 flex items-center justify-center z-10 relative overflow-hidden shadow-[0_0_15px_rgba(20,241,225,0.35)]">
                {profile?.photoURL && profile.photoURL.startsWith("http") ? (
                  <img src={profile.photoURL} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <svg viewBox="0 0 40 40" className="w-8 h-8">
                    <defs>
                      <linearGradient id="visorGrad" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="#14F1E1" />
                        <stop offset="100%" stopColor="#B66DFF" />
                      </linearGradient>
                    </defs>
                    {/* 3D Cyber Helmet Silhouette */}
                    <polygon
                      points="20,4 33,11 31,28 20,36 9,28 7,11"
                      fill="rgba(20,241,225,0.12)"
                      stroke="url(#visorGrad)"
                      strokeWidth="1.6"
                    />
                    {/* Glowing Cyber Visor Slit */}
                    <polygon
                      points="11,17 20,20 29,17 27,22 20,24 13,22"
                      fill="#14F1E1"
                      style={{ filter: "drop-shadow(0 0 4px #14F1E1)" }}
                    />
                    {/* Center Crest Line */}
                    <line x1="20" y1="5" x2="20" y2="15" stroke="#B66DFF" strokeWidth="1.5" />
                  </svg>
                )}
              </div>

              {/* Tooltip on hover/tap */}
              <div className="absolute inset-0 z-20 group cursor-pointer">
                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-max bg-black/95 border border-[#14F1E1]/30 rounded-xl p-2 text-[10px] uppercase font-bold tracking-widest text-white opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none flex flex-col gap-1 shadow-2xl">
                  <span className="text-[#14F1E1] flex items-center gap-1"><Zap className="w-3 h-3" /> {dailyXP} / {dailyXPTarget} XP</span>
                  <span className="text-[#F59E0B] flex items-center gap-1"><Flame className="w-3 h-3" /> {dailyCalories} / {dailyCalorieTarget} KCAL</span>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#14F1E1] animate-ping" />
                <p className="text-[#14F1E1] text-[9.5px] font-black uppercase tracking-[0.2em] font-mono">
                  WELCOME BACK
                </p>
              </div>
              <h1 className="text-white text-xl font-black tracking-tight uppercase drop-shadow-[0_2px_10px_rgba(20,241,225,0.25)]">
                {profile?.username || "Player One"}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Rank Overview Trigger Button */}
            <button
              onClick={() => {
                playSound("click");
                setShowSystemPortal(true);
              }}
              className="px-2.5 py-2 rounded-xl bg-gradient-to-br from-[#14F1E1]/20 to-[#B66DFF]/20 border border-[#14F1E1]/45 text-[#14F1E1] hover:border-[#14F1E1] transition-all cursor-pointer active:scale-95 flex items-center gap-1 shadow-[0_0_15px_rgba(20,241,225,0.2)]"
              title="Open Rank & Stats Overview"
            >
              <Zap className="w-4 h-4 text-[#14F1E1]" />
              <span className="text-[9px] font-black uppercase tracking-widest hidden sm:inline">STATS</span>
            </button>

            <button
              onClick={() => {
                playSound("click");
                setNotification((prev) =>
                  prev
                    ? null
                    : t(
                        `🔥 ${streakCount} Day Streak Active! Aaj ka recommended target: ${recommendedWorkout.title}`,
                        `🔥 ${streakCount} Day Streak Active! Today's target: ${recommendedWorkout.title}`
                      )
                );
              }}
              className="w-10 h-10 rounded-xl bg-[#0D1630] border border-[#14F1E1]/30 flex items-center justify-center hover:bg-[#14F1E1]/15 text-white transition-all cursor-pointer relative shadow-[inset_0_1px_1px_rgba(255,255,255,0.15)]"
              title="Daily Status Alert"
            >
              <Bell className="w-4 h-4 text-[#14F1E1]" />
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#14F1E1] animate-ping" />
            </button>
          </div>
        </div>

        {/* Daily Fitness Status Bar */}
        <div className="grid grid-cols-3 gap-2 mt-3.5 pt-3 border-t border-white/10">
          <div className="bg-black/35 border border-white/10 rounded-xl px-2.5 py-1.5 flex flex-col">
            <span className="text-[8px] font-mono font-bold uppercase tracking-widest text-neutral-400">RECOVERY</span>
            <span className="text-[10px] font-black text-emerald-400 flex items-center gap-1 mt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              READY
            </span>
          </div>
          <div className="bg-black/35 border border-white/10 rounded-xl px-2.5 py-1.5 flex flex-col">
            <span className="text-[8px] font-mono font-bold uppercase tracking-widest text-neutral-400">DAILY BURN</span>
            <span className="text-[10px] font-black text-amber-400 font-mono mt-0.5">
              {dailyCalories} / {dailyCalorieTarget} KCAL
            </span>
          </div>
          <button
            type="button"
            onClick={() => {
              playSound("click");
              window.dispatchEvent(new CustomEvent("open_streak_modal"));
            }}
            className="bg-black/35 hover:bg-[#14F1E1]/15 border border-white/10 hover:border-[#14F1E1]/50 rounded-xl px-2.5 py-1.5 flex flex-col text-left transition-all active:scale-95 cursor-pointer relative overflow-hidden group"
            title="Tap to open Streak & Consistency Calendar"
          >
            <span className="text-[8px] font-mono font-bold uppercase tracking-widest text-neutral-400 group-hover:text-[#14F1E1] transition-colors">
              STREAK
            </span>
            <span className="text-[10px] font-black text-[#14F1E1] font-mono mt-0.5 flex items-center gap-1">
              {streakCount} {streakCount === 1 ? "DAY" : "DAYS"} 🔥
            </span>
          </button>
        </div>
      </div>

      {notification && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#0D1328] border border-[#14F1E1]/40 rounded-2xl p-3.5 flex items-center justify-between gap-3 text-xs text-white font-bold shadow-[0_0_20px_rgba(20,241,225,0.15)]"
        >
          <span>{notification}</span>
          <button
            onClick={() => setNotification(null)}
            className="text-neutral-400 hover:text-white px-2 py-0.5 rounded bg-white/5 cursor-pointer"
          >
            ✕
          </button>
        </motion.div>
      )}

      {/* 3D PERSPECTIVE TILT RANK & PLASMA XP REACTOR CARD */}
      <motion.div
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const x = e.clientX - rect.left;
          const y = e.clientY - rect.top;
          const rx = ((y / rect.height) - 0.5) * -10;
          const ry = ((x / rect.width) - 0.5) * 10;
          setCardTilt({
            rx,
            ry,
            gx: Math.round((x / rect.width) * 100),
            gy: Math.round((y / rect.height) * 100),
          });
        }}
        onMouseLeave={() => setCardTilt({ rx: 0, ry: 0, gx: 50, gy: 50 })}
        style={{
          transform: `perspective(900px) rotateX(${cardTilt.rx}deg) rotateY(${cardTilt.ry}deg)`,
          transition: "transform 0.18s ease-out",
        }}
        className={`rounded-3xl p-5 space-y-4 relative overflow-hidden bg-gradient-to-br from-[#0E1938]/95 via-[#081024]/95 to-[#120B29]/95 border ${
          isLevelingUp
            ? "border-[#14F1E1] shadow-[0_0_40px_rgba(20,241,225,0.45)] scale-[1.02]"
            : "border-[#14F1E1]/35 shadow-[0_18px_40px_rgba(0,0,0,0.85),inset_0_1px_1px_rgba(255,255,255,0.2)]"
        }`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {/* Dynamic Holographic Foil Glare */}
        <div
          className="absolute inset-0 pointer-events-none opacity-25 transition-opacity duration-300"
          style={{
            background: `radial-gradient(circle at ${cardTilt.gx}% ${cardTilt.gy}%, rgba(20,241,225,0.45), rgba(182,109,255,0.18) 45%, transparent 75%)`,
          }}
        />

        <div className="flex justify-between items-center relative z-10">
          <div className="flex items-center gap-3.5">
            {/* Live 3D Rotating Rank Crystal Emblem */}
            <motion.div
              animate={{ rotateY: [0, 180, 360], y: [0, -3, 0] }}
              transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
              onClick={() => {
                playSound("click");
                setShowSystemPortal(true);
              }}
              className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#14F1E1]/20 via-[#070E22] to-[#B66DFF]/25 border border-[#14F1E1]/50 flex items-center justify-center relative cursor-pointer shadow-[0_0_20px_rgba(20,241,225,0.3)] shrink-0"
              title="Tap to view Rank & Stats Overview"
            >
              <svg viewBox="0 0 56 56" className="w-11 h-11">
                <polygon
                  points="28,4 48,16 48,40 28,52 8,40 8,16"
                  fill="rgba(20,241,225,0.14)"
                  stroke="#14F1E1"
                  strokeWidth="2"
                />
                <polygon
                  points="28,10 42,20 28,46 14,20"
                  fill="rgba(182,109,255,0.28)"
                  stroke="#B66DFF"
                  strokeWidth="1.5"
                />
                <circle cx="28" cy="24" r="5" fill="#14F1E1" />
              </svg>
            </motion.div>

            <div className="space-y-0.5">
              <span className="text-[#14F1E1] text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-1.5 font-mono">
                RANK: {rank.title}
              </span>
              <motion.h2
                animate={isLevelingUp ? { scale: [1, 1.2, 1], color: ["#FFF", "#14F1E1", "#FFF"] } : {}}
                transition={{ duration: 0.5 }}
                className="text-white text-3xl font-black font-mono origin-left tracking-tight drop-shadow-[0_0_12px_rgba(20,241,225,0.35)]"
              >
                {userXP} <span className="text-xs text-[#14F1E1]">XP</span>
              </motion.h2>
            </div>
          </div>

          <div className="text-right bg-black/40 border border-white/10 rounded-2xl px-3 py-2">
            <span className="text-[#9CA3AF] text-[9px] uppercase font-black tracking-widest block">Next Rank</span>
            <span className="text-[#B66DFF] text-xs font-black uppercase">{rank.next}</span>
          </div>
        </div>

        {/* XP Progress Bar */}
        <div className="space-y-1.5 relative z-10">
          <div className="flex justify-between text-[10px] text-[#9CA3AF] font-mono font-bold">
            <span className="text-white/80 uppercase tracking-wider">Rank Progress</span>
            <span className="text-[#14F1E1]">{Math.round(progressPercent)}% ({userXP} / {rank.nextXP} XP)</span>
          </div>
          <div
            className={`h-4 w-full bg-[#040814] rounded-full overflow-hidden border p-0.5 transition-colors duration-500 relative shadow-[inset_0_2px_6px_rgba(0,0,0,0.9)] ${
              isLevelingUp ? "border-[#14F1E1] shadow-[0_0_20px_#14F1E1]" : "border-[#14F1E1]/35"
            }`}
          >
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progressPercent}%` }}
              transition={{ type: "spring", stiffness: 50, damping: 12 }}
              className="h-full rounded-full relative overflow-hidden bg-gradient-to-r from-[#14F1E1] via-[#38BDF8] to-[#B66DFF] shadow-[0_0_14px_#14F1E1]"
            >
              {/* Top Specular Highlight */}
              <div className="absolute top-0 left-0 right-0 h-[40%] bg-white/35 rounded-full" />
              {/* Animated Shimmer */}
              <motion.div
                animate={{ x: ["-100%", "200%"] }}
                transition={{ duration: 2.2, repeat: Infinity, ease: "linear" }}
                className="absolute inset-y-0 w-1/2 bg-gradient-to-r from-transparent via-white/60 to-transparent"
              />
            </motion.div>
          </div>
        </div>

        {/* Action Buttons Row */}
        <div className="grid grid-cols-2 gap-2.5 relative z-10">
          <button
            onClick={() => {
              playSound("click");
              setShowFlexCard(true);
            }}
            className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#14F1E1]/15 via-[#B66DFF]/15 to-[#14F1E1]/15 hover:from-[#14F1E1]/25 hover:to-[#B66DFF]/25 border border-[#14F1E1]/40 text-white font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer shadow-[0_4px_15px_rgba(0,0,0,0.4)]"
          >
            <Share2 className="w-3.5 h-3.5 text-[#14F1E1]" />
            <span>Share Flex Card</span>
          </button>

          <button
            onClick={() => {
              playSound("success");
              setShowSystemPortal(true);
            }}
            className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#B66DFF]/20 to-[#14F1E1]/20 hover:from-[#B66DFF]/30 hover:to-[#14F1E1]/30 border border-[#B66DFF]/50 text-white font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer shadow-[0_4px_15px_rgba(182,109,255,0.2)]"
          >
            <Trophy className="w-3.5 h-3.5 text-[#B66DFF]" />
            <span>Rank Overview</span>
          </button>
        </div>
      </motion.div>

      {/* 90-DAY GLOW-UP BLUEPRINT & ACTIVE WARRIOR PATH CARD (IDEAS #1, #2, #5, #6, #8) */}
      {(() => {
        const activePath =
          profile?.trainingPath ||
          localStorage.getItem("fitgenie_training_path") ||
          "calisthenics";
        const activeDiet =
          profile?.dietPreference ||
          localStorage.getItem("fitgenie_diet_pref") ||
          "veg";
        const warriorClass =
          profile?.warriorClass ||
          localStorage.getItem("fitgenie_warrior_class") ||
          "Street Calisthenics Assassin";
        const baselineScore = profile?.aiBaselineScore || 78;

        const pathMeta: Record<string, { label: string; badge: string; desc: string }> = {
          calisthenics: {
            label: "🤸 Street Calisthenics Ninja",
            badge: "BODYWEIGHT & BAR ONLY",
            desc: "Gym machine clutter hidden. Showing Calisthenics & Bodyweight skills.",
          },
          gym: {
            label: "🏋️ Iron Gym Titan",
            badge: "BARBELL & DUMBBELL HYPERTROPHY",
            desc: "Calibrated for heavy compound lifts, cables & gym hypertrophy.",
          },
          home_jugaad: {
            label: "🎒 Hostel / Home Spartan",
            badge: "ZERO-EQUIPMENT & DESI JUGAAD",
            desc: "Showing Backpack, Towel & Floor drills. Zero gym needed.",
          },
          aesthetics: {
            label: "🗿 Aesthetic & Mogging Glow-Up",
            badge: "1.618 V-TAPER & JAWLINE",
            desc: "Focused on shoulder-to-waist ratio, posture & facial debloat.",
          },
        };

        const currentMeta = pathMeta[activePath] || pathMeta.calisthenics;
        const dietBadge =
          activeDiet === "veg"
            ? "🌱 Pure Veg Mode"
            : activeDiet === "egg"
            ? "🥚 Eggetarian Mode"
            : "🍗 Non-Veg Mode";

        return (
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card rounded-3xl p-5 border border-[#14F1E1]/30 bg-gradient-to-br from-[#0D1328] via-[#091124] to-[#050B1A] relative overflow-hidden space-y-4"
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="inline-flex items-center gap-1.5 text-[9px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-[#14F1E1]/15 text-[#14F1E1] border border-[#14F1E1]/30">
                  ⚡ 90-DAY GLOW-UP PROTOCOL ACTIVE
                </span>
                <h3 className="text-white text-base font-black uppercase tracking-wide mt-1.5">
                  {currentMeta.label}
                </h3>
                <p className="text-[11px] text-[#9CA3AF] mt-0.5 leading-snug">
                  {currentMeta.desc}
                </p>
              </div>
              <div className="text-right shrink-0 bg-black/40 border border-white/10 rounded-2xl px-3 py-1.5">
                <span className="text-[8px] font-mono uppercase text-neutral-400 block">Day 90 Target</span>
                <span className="text-sm font-black font-mono text-[#14F1E1]">94% AESTHETIC</span>
              </div>
            </div>

            {/* Active Filters Pills */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[9px] font-black uppercase tracking-wider px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-white">
                {currentMeta.badge}
              </span>
              <span className="text-[9px] font-black uppercase tracking-wider px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300">
                {dietBadge}
              </span>
              <span className="text-[9px] font-black uppercase tracking-wider px-2.5 py-1 rounded-lg bg-[#B66DFF]/15 border border-[#B66DFF]/30 text-[#B66DFF]">
                Scan Score: {baselineScore}/100
              </span>
            </div>

            {/* Day 1 -> Day 90 Mini Progress Bar */}
            <div className="bg-black/40 border border-white/10 rounded-2xl p-3 space-y-1.5">
              <div className="flex items-center justify-between text-[10px] font-mono font-bold">
                <span className="text-neutral-400">CLASS: {warriorClass.toUpperCase()}</span>
                <span className="text-[#14F1E1]">DAY {Math.min(90, Math.max(1, streakCount || 1))} / 90</span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#14F1E1] via-[#4DA8FF] to-[#B66DFF]"
                  style={{ width: `${Math.min(100, Math.max(8, Math.round(((streakCount || 1) / 90) * 100)))}%` }}
                />
              </div>
            </div>

            {/* Recalibrate Glow-Up Button (#8) + Quick Language Toggle */}
            <div className="flex flex-col sm:flex-row gap-2">
              {onOpenRecalibrate && (
                <button
                  onClick={() => {
                    playSound("click");
                    onOpenRecalibrate();
                  }}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-white/5 hover:bg-[#14F1E1]/15 border border-white/15 hover:border-[#14F1E1]/50 text-xs font-black uppercase tracking-widest text-[#14F1E1] flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>
                    {t(
                      "Onboarding / Path & Diet Badlo",
                      "Recalibrate Glow-Up Path / Diet"
                    )}
                  </span>
                </button>
              )}
              <button
                onClick={() => {
                  playSound("click");
                  setAppLang(appLang === "hinglish" ? "english" : "hinglish");
                }}
                className="py-2.5 px-4 rounded-xl bg-[#B66DFF]/15 hover:bg-[#B66DFF]/25 border border-[#B66DFF]/40 text-xs font-black uppercase tracking-widest text-[#B66DFF] flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
              >
                <span>
                  {appLang === "hinglish"
                    ? "🇮🇳 Mode: Hinglish (Switch to EN)"
                    : "🌐 Mode: English (Switch to Hinglish)"}
                </span>
              </button>
            </div>
          </motion.div>
        );
      })()}

      {/* 3-TAB DASHBOARD SWITCHER */}
      <div className="grid grid-cols-3 gap-2 p-1.5 rounded-2xl bg-[#0D1328]/90 border border-[#14F1E1]/30 shadow-[0_0_25px_rgba(20,241,225,0.1)] sticky top-2 z-30 backdrop-blur-md">
        {[
          { id: "overview", label: t("⚡ Overview", "⚡ Overview") },
          { id: "arena", label: t("⚔️ Arena & Duels", "⚔️ Arena & Duels") },
          { id: "labs", label: t("🧬 Bio-Labs", "🧬 Bio-Labs") },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => {
              playSound("click");
              setHomeDeckTab(tab.id as any);
            }}
            className={`py-2.5 px-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all cursor-pointer ${
              homeDeckTab === tab.id
                ? "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_15px_rgba(20,241,225,0.55)]"
                : "text-neutral-300 hover:text-white bg-white/5"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* ================================================================== */}
      {/* TAB 1: OVERVIEW (CORE TELEMETRY, RECOVERY MAP, STEPS & ROUTINE)    */}
      {/* ================================================================== */}
      {homeDeckTab === "overview" && (
        <div className="space-y-6">
          {/* SMART ROUTINE RECOMMENDER */}
          <motion.div
            className="glass-card rounded-3xl p-5 relative overflow-hidden group cursor-pointer border border-[#FF4D4D]/30 glow-red"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => {
              playSound("click");
              if (onNavigateToExercises) onNavigateToExercises(recommendedWorkout.muscle);
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#FF4D4D]/10 to-[#B66DFF]/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="flex items-center gap-4 relative z-10">
              <div className="w-14 h-14 rounded-2xl bg-[#FF4D4D]/20 flex items-center justify-center border border-[#FF4D4D]/40 shrink-0">
                <Target className="w-7 h-7 text-[#FF4D4D]" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-white text-sm font-bold uppercase tracking-wider mb-0.5">
                  Recommended Routine
                </h3>
                <p className="text-[#FF4D4D] font-black text-lg truncate">
                  {recommendedWorkout.title}
                </p>
                <p className="text-[#9CA3AF] text-[10px] uppercase font-bold tracking-widest mt-1 truncate">
                  {recommendedWorkout.description}
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-neutral-500 group-hover:text-white transition-colors shrink-0" />
            </div>
          </motion.div>

          {/* INTERACTIVE BIOMETRIC MUSCLE RECOVERY COOLDOWN MAP */}
          <MuscleRecoveryMap
            history={history}
            onSelectMuscleToTrain={(muscle) => {
              if (onNavigateToExercises) onNavigateToExercises(muscle);
            }}
          />

          {/* STREAK & WORKOUTS GRID */}
          <div className="grid grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => {
                playSound("click");
                window.dispatchEvent(new CustomEvent("open_streak_modal"));
              }}
              className="glass-card rounded-3xl p-5 flex flex-col items-center justify-center gap-2 glow-purple hover:border-[#B66DFF]/60 transition-all active:scale-95 cursor-pointer"
            >
              <div className="w-12 h-12 rounded-full bg-[#B66DFF]/10 flex items-center justify-center">
                <Flame className="w-6 h-6 text-[#B66DFF] fill-[#B66DFF]" />
              </div>
              <div className="text-center">
                <h3 className="text-white text-2xl font-black font-mono">{streakCount}</h3>
                <span className="text-[#9CA3AF] text-[10px] uppercase font-bold tracking-widest block">
                  Day Streak
                </span>
                <span className="text-[#14F1E1] text-[8.5px] font-bold uppercase tracking-wider block mt-0.5">
                  View Calendar →
                </span>
              </div>
            </button>

            <div className="glass-card rounded-3xl p-5 flex flex-col items-center justify-center gap-2 glow-green">
              <div className="w-12 h-12 rounded-full bg-[#10B981]/10 flex items-center justify-center">
                <Trophy className="w-6 h-6 text-[#10B981] fill-[#10B981]" />
              </div>
              <div className="text-center">
                <h3 className="text-white text-2xl font-black font-mono">{history.length}</h3>
                <span className="text-[#9CA3AF] text-[10px] uppercase font-bold tracking-widest">
                  Workouts
                </span>
              </div>
            </div>
          </div>

          {/* REAL-TIME STEP TRACKER */}
          <div className="glass-card rounded-3xl p-6 relative overflow-hidden group border border-[#14F1E1]/30 glow-blue">
            <div className="absolute inset-0 bg-gradient-to-br from-[#0D1328]/80 to-[#14F1E1]/10 opacity-100 transition-opacity" />
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-full flex justify-between items-center mb-6">
                <h3 className="text-white text-sm font-bold tracking-widest uppercase flex items-center gap-2">
                  <Footprints className="w-4 h-4 text-[#14F1E1]" /> Daily Steps
                </h3>
                <span className="text-[#14F1E1] text-[10px] uppercase font-bold tracking-widest flex items-center gap-1 bg-[#14F1E1]/10 px-2 py-1 rounded-full border border-[#14F1E1]/20">
                  Live Sensor
                </span>
              </div>

              <div className="relative flex items-center justify-center mb-6">
                <svg className="w-40 h-40 transform -rotate-90">
                  <circle
                    cx="80"
                    cy="80"
                    r="70"
                    fill="transparent"
                    stroke="rgba(255,255,255,0.05)"
                    strokeWidth="12"
                  />
                  <motion.circle
                    cx="80"
                    cy="80"
                    r="70"
                    fill="transparent"
                    stroke="url(#stepGradient)"
                    strokeWidth="12"
                    strokeLinecap="round"
                    strokeDasharray="439.8"
                    initial={{ strokeDashoffset: 439.8 }}
                    animate={{
                      strokeDashoffset: 439.8 - 439.8 * Math.min(todaySteps / 10000, 1),
                    }}
                    transition={{ duration: 1, ease: "easeOut" }}
                  />
                  <defs>
                    <linearGradient id="stepGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#4DA8FF" />
                      <stop offset="100%" stopColor="#14F1E1" />
                    </linearGradient>
                  </defs>
                </svg>

                <div className="absolute flex flex-col items-center justify-center">
                  <h2 className="text-white text-4xl font-black font-mono tracking-tight">
                    {todaySteps.toLocaleString()}
                  </h2>
                  <span className="text-[#9CA3AF] text-xs font-bold uppercase tracking-widest mt-1">
                    / 10,000
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 w-full mb-4">
                <div className="bg-black/30 rounded-2xl p-3 border border-white/5 flex flex-col items-center justify-center gap-1">
                  <Flame className="w-4 h-4 text-[#FF4D4D]" />
                  <span className="text-white font-mono font-bold text-lg">
                    {(todaySteps * 0.04).toFixed(0)}
                  </span>
                  <span className="text-[#9CA3AF] text-[9px] uppercase tracking-wider font-bold">
                    Kcal
                  </span>
                </div>
                <div className="bg-black/30 rounded-2xl p-3 border border-white/5 flex flex-col items-center justify-center gap-1">
                  <Activity className="w-4 h-4 text-[#B66DFF]" />
                  <span className="text-white font-mono font-bold text-lg">
                    {(todaySteps * 0.0008).toFixed(2)}
                  </span>
                  <span className="text-[#9CA3AF] text-[9px] uppercase tracking-wider font-bold">
                    Km
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* MOGGED HUB DIRECT PORTAL CARD */}
          <div
            onClick={() => {
              playSound("click");
              onNavigateToCoach();
            }}
            className="glass-card rounded-3xl p-5 relative overflow-hidden group cursor-pointer border border-[#B66DFF]/30 glow-purple"
          >
            <div className="flex items-center justify-between gap-4 relative z-10">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-[#B66DFF]/20 flex items-center justify-center border border-[#B66DFF]/40 shrink-0">
                  <MessageSquare className="w-7 h-7 text-[#B66DFF]" />
                </div>
                <div>
                  <h3 className="text-white text-lg font-bold tracking-wide">
                    {t("Mogged Station & Posture Lab", "Mogged Station & Posture Lab")}
                  </h3>
                  <p className="text-[#9CA3AF] text-xs mt-1 leading-snug">
                    {t(
                      "Jawline conditioning, posture alignment & facial aesthetics routines.",
                      "Jawline conditioning, posture alignment & facial aesthetics routines."
                    )}
                  </p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-[#B66DFF] group-hover:translate-x-1 transition-transform shrink-0" />
            </div>
          </div>

          {/* WEEKLY PROGRESS CHART */}
          <div className="glass-card rounded-3xl p-5 space-y-4">
            <h3 className="text-white text-sm font-bold uppercase tracking-wider mb-2">
              Weekly Activity
            </h3>
            <div className="h-48 w-full">
              <SafeResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={weeklyChartData}
                  margin={{ top: 5, right: 0, left: -25, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#14F1E1" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#14F1E1" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(255,255,255,0.05)"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="name"
                    stroke="#9CA3AF"
                    fontSize={10}
                    tickLine={false}
                    axisLine={false}
                    dy={10}
                  />
                  <YAxis
                    stroke="#9CA3AF"
                    fontSize={10}
                    tickLine={false}
                    axisLine={false}
                    dx={-10}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#0D1328",
                      borderColor: "rgba(20,241,225,0.15)",
                      borderRadius: "12px",
                      color: "#FFF",
                    }}
                    itemStyle={{ color: "#14F1E1" }}
                  />
                  <Area
                    type="monotone"
                    dataKey="duration"
                    stroke="#14F1E1"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorVolume)"
                  />
                </AreaChart>
              </SafeResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* ================================================================== */}
      {/* TAB 2: 3D HOLO-EVOLUTION, 1v1 GHOST DUEL, BEATS & TIME-LAPSE VAULT */}
      {/* ================================================================== */}
      {homeDeckTab === "arena" && (
        <div className="space-y-6">
          <CyberEvolutionAndDuelHub />
          <GlowUpAndRecoveryHub onSaveSmartSession={onSaveSmartSession} />
        </div>
      )}

      {/* ================================================================== */}
      {/* TAB 3: BIO-LABS, PERSONALIZATION & WARRIOR SUITE                   */}
      {/* ================================================================== */}
      {homeDeckTab === "labs" && (
        <div className="space-y-6">
          <PersonalizationHub
            onSaveSmartSession={onSaveSmartSession}
            onNavigateToExercises={onNavigateToExercises}
          />
          <ApexBioLab history={history} streakCount={streakCount} />
          <WarriorSuiteHub history={history} streakCount={streakCount} />
        </div>
      )}

      {/* PERMISSION POPUP */}
      {showPermissionPopup && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-6 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-[#0D1328] border border-[#4DA8FF]/30 rounded-3xl p-6 w-full max-w-sm text-center shadow-[0_0_40px_rgba(77,168,255,0.2)]"
          >
            <div className="w-16 h-16 rounded-full bg-[#4DA8FF]/20 flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-[#4DA8FF] animate-pulse" />
            </div>
            <h3 className="text-white text-xl font-black tracking-wide mb-2">Enable Step Tracker</h3>
            <p className="text-[#9CA3AF] text-sm mb-6 leading-relaxed">
              We need access to your device's motion sensor to track your steps in the background. It runs efficiently and saves battery.
            </p>
            <div className="flex gap-3">
               <button 
                  onClick={() => setShowPermissionPopup(false)}
                  className="flex-1 py-3 rounded-xl border border-white/10 text-white font-bold uppercase text-xs tracking-wider hover:bg-white/5"
               >
                 Maybe Later
               </button>
               <button 
                  onClick={requestMotionPermission}
                  className="flex-1 py-3 rounded-xl bg-[#4DA8FF] text-[#050B1A] font-black uppercase text-xs tracking-wider shadow-[0_0_15px_#4DA8FF] hover:scale-105 transition-all"
               >
                 Allow Access
               </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* IDEA 6: CYBERPUNK FIGHTER FLEX CARD MODAL */}
      {showFlexCard && (
        <FlexCardModal
          onClose={() => setShowFlexCard(false)}
        />
      )}

      {/* 3D SOLO-LEVELING "[SYSTEM NOTIFICATION: RANK ASCENSION]" PORTAL MODAL */}
      <AnimatePresence>
        {showSystemPortal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowSystemPortal(false)}
            className="fixed inset-0 z-[120] bg-black/85 backdrop-blur-xl flex items-center justify-center p-4 select-none"
          >
            <motion.div
              initial={{ scale: 0.8, rotateX: 25, opacity: 0 }}
              animate={{ scale: 1, rotateX: 0, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              transition={{ type: "spring", stiffness: 260, damping: 22 }}
              onClick={(e) => e.stopPropagation()}
              style={{ transformStyle: "preserve-3d" }}
              className="relative w-full max-w-sm rounded-3xl bg-gradient-to-b from-[#07142B]/95 via-[#050B1A]/98 to-[#0B0726]/95 border-2 border-[#14F1E1] p-6 text-center shadow-[0_0_70px_rgba(20,241,225,0.45),inset_0_0_30px_rgba(20,241,225,0.18)] overflow-hidden"
            >
              {/* Top & Bottom System Warning Strips */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-transparent via-[#14F1E1] to-transparent animate-pulse" />
              <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-gradient-to-r from-transparent via-[#B66DFF] to-transparent animate-pulse" />

              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#14F1E1]/15 border border-[#14F1E1]/50 text-[#14F1E1] text-[10px] font-mono font-black uppercase tracking-[0.25em] mb-4">
                <span className="w-2 h-2 rounded-full bg-[#14F1E1] animate-ping" />
                [SYSTEM NOTIFICATION]
              </div>

              {/* 3D Floating Hexagonal Rank Sovereign Crystal */}
              <div className="relative w-28 h-28 mx-auto my-2 flex items-center justify-center">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 14, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 rounded-full border border-dashed border-[#14F1E1]/50"
                />
                <motion.div
                  animate={{ rotate: -360 }}
                  transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-2 rounded-full border border-[#B66DFF]/40"
                />
                <motion.svg
                  viewBox="0 0 80 80"
                  className="w-20 h-20 relative z-10"
                  animate={{ y: [0, -6, 0], scale: [1, 1.06, 1] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                >
                  <polygon
                    points="40,6 70,22 70,58 40,74 10,58 10,22"
                    fill="rgba(20,241,225,0.18)"
                    stroke="#14F1E1"
                    strokeWidth="2.5"
                  />
                  <polygon
                    points="40,14 60,28 40,66 20,28"
                    fill="rgba(182,109,255,0.35)"
                    stroke="#B66DFF"
                    strokeWidth="1.8"
                  />
                  <circle cx="40" cy="34" r="7" fill="#FFFFFF" />
                </motion.svg>
              </div>

              <h3 className="text-2xl font-black uppercase tracking-tight text-white drop-shadow-[0_0_15px_rgba(20,241,225,0.6)]">
                {rank.title}
              </h3>
              <p className="text-[11px] font-mono text-[#14F1E1] uppercase tracking-widest mt-1">
                PLAYER POWER: {userXP} XP // STREAK: {streakCount}D
              </p>

              {/* Hunter Stat Matrix */}
              <div className="grid grid-cols-2 gap-2.5 my-5 text-left">
                <div className="bg-black/50 border border-[#14F1E1]/30 rounded-xl p-2.5">
                  <span className="text-[8.5px] font-mono uppercase text-neutral-400 block">STRENGTH INDEX</span>
                  <span className="text-sm font-black font-mono text-white">
                    LVL {Math.max(1, Math.floor(userXP / 150) + 1)} <strong className="text-[#14F1E1] text-[10px]">+BUFF</strong>
                  </span>
                </div>
                <div className="bg-black/50 border border-[#B66DFF]/30 rounded-xl p-2.5">
                  <span className="text-[8.5px] font-mono uppercase text-neutral-400 block">STAMINA & RECOVERY</span>
                  <span className="text-sm font-black font-mono text-white">
                    {Math.min(100, 70 + streakCount * 3)}% <strong className="text-[#B66DFF] text-[10px]">PEAK</strong>
                  </span>
                </div>
                <div className="bg-black/50 border border-amber-400/30 rounded-xl p-2.5">
                  <span className="text-[8.5px] font-mono uppercase text-neutral-400 block">METABOLIC OUTPUT</span>
                  <span className="text-sm font-black font-mono text-amber-400">{dailyCalories} KCAL</span>
                </div>
                <div className="bg-black/50 border border-emerald-400/30 rounded-xl p-2.5">
                  <span className="text-[8.5px] font-mono uppercase text-neutral-400 block">NEXT ASCENSION</span>
                  <span className="text-xs font-black font-mono text-emerald-400 truncate block">{rank.next}</span>
                </div>
              </div>

              <button
                onClick={() => {
                  playSound("click");
                  setShowSystemPortal(false);
                }}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#14F1E1] to-[#B66DFF] text-[#050B1A] font-black text-xs uppercase tracking-[0.2em] shadow-[0_0_25px_rgba(20,241,225,0.5)] hover:scale-[1.02] active:scale-95 transition-all cursor-pointer"
              >
                ACKNOWLEDGE SYSTEM
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FRAMER MOTION 3D STREAK MILESTONE PARTICLE EXPLOSION OVERLAY */}
      <AnimatePresence>
        {streakBurstActive && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setStreakBurstActive(false)}
            className="fixed inset-0 z-[130] flex items-center justify-center pointer-events-auto bg-black/55 backdrop-blur-sm select-none overflow-hidden"
          >
            {/* Dual Expanding 3D Shockwave Rings */}
            <motion.div
              initial={{ scale: 0.15, opacity: 0.95 }}
              animate={{ scale: 3.1, opacity: 0 }}
              transition={{ duration: 1.4, ease: "easeOut" }}
              className="absolute w-44 h-44 rounded-full border-2 border-[#14F1E1] shadow-[0_0_40px_#14F1E1] pointer-events-none"
            />
            <motion.div
              initial={{ scale: 0.1, opacity: 0.9 }}
              animate={{ scale: 2.5, opacity: 0 }}
              transition={{ duration: 1.6, delay: 0.12, ease: "easeOut" }}
              className="absolute w-44 h-44 rounded-full border-2 border-[#FFB703] shadow-[0_0_35px_#FFB703] pointer-events-none"
            />

            {/* 36 Radial 3D Holographic Shards, Sparks & Plasma Orbs */}
            <div className="relative flex items-center justify-center">
              {streakParticles.map((p) => (
                <motion.div
                  key={p.id}
                  initial={{ x: 0, y: 0, scale: 0, rotate: 0, opacity: 1 }}
                  animate={{
                    x: [0, p.tx * 0.75, p.tx],
                    y: [0, p.ty * 0.75, p.ty + 28],
                    scale: [0, p.scale, 0],
                    rotate: [0, p.rot],
                    opacity: [1, 1, 0],
                  }}
                  transition={{
                    duration: 1.65,
                    delay: p.delay,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  style={{
                    backgroundColor: p.shape !== "spark" ? p.color : "transparent",
                    boxShadow: `0 0 14px ${p.color}`,
                    borderColor: p.color,
                  }}
                  className={`absolute pointer-events-none ${
                    p.shape === "diamond"
                      ? "w-3.5 h-3.5 rotate-45 rounded-[2px] border border-white/60"
                      : p.shape === "orb"
                      ? "w-3 h-3 rounded-full"
                      : "w-1.5 h-6 rounded-full bg-gradient-to-b from-white via-[#14F1E1] to-transparent"
                  }`}
                />
              ))}

              {/* Central 3D Streak Milestone Trophy Card */}
              <motion.div
                initial={{ scale: 0.4, rotateX: 35, y: 30, opacity: 0 }}
                animate={{ scale: [0.4, 1.08, 1], rotateX: 0, y: 0, opacity: 1 }}
                exit={{ scale: 0.75, opacity: 0 }}
                transition={{ duration: 0.55, ease: "backOut" }}
                className="relative z-10 px-7 py-6 rounded-3xl bg-gradient-to-b from-[#0C1938]/95 via-[#070E22]/98 to-[#170B2C]/95 border-2 border-[#FFB703] shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_50px_rgba(255,183,3,0.45),inset_0_1px_2px_rgba(255,255,255,0.3)] text-center max-w-xs"
              >
                <motion.div
                  animate={{ scale: [1, 1.15, 1], rotate: [0, -6, 6, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                  className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-br from-[#FFB703]/30 via-[#FF5E3A]/25 to-[#14F1E1]/20 border border-[#FFB703] flex items-center justify-center shadow-[0_0_25px_rgba(255,183,3,0.5)]"
                >
                  <Flame className="w-9 h-9 text-[#FFB703] fill-[#FFB703] drop-shadow-[0_0_12px_#FFB703]" />
                </motion.div>

                <span className="inline-block px-3 py-0.5 rounded-full bg-[#FFB703]/20 border border-[#FFB703]/50 text-[#FFB703] text-[9px] font-mono font-black uppercase tracking-[0.22em]">
                  MILESTONE IGNITED
                </span>

                <h3 className="text-3xl font-black text-white font-mono tracking-tight mt-2 drop-shadow-[0_0_16px_rgba(255,183,3,0.6)]">
                  {celebratedMilestoneValue} DAY STREAK!
                </h3>

                <p className="text-[11px] text-neutral-300 font-medium mt-1">
                  Unstoppable consistency! Guardian Orb has supercharged your Anabolic Core.
                </p>

                <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-center gap-2 text-[10px] font-mono font-black text-[#14F1E1]">
                  <Zap className="w-3.5 h-3.5 text-[#14F1E1]" />
                  <span>+STREAK MOMENTUM SHIELD ACTIVE</span>
                </div>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
