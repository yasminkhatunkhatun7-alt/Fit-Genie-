import React, { useState, useEffect } from "react";
import { useAuth, getRankDetails } from "../context/AuthContext";
import { motion, AnimatePresence } from "motion/react";
import { 
  User, Award, Flame, Shield, Edit3, CheckCircle, Flag, Activity, 
  ChevronLeft, Users, Trophy, Target, Settings, X, Loader2, Dumbbell, Clock, Save
} from "lucide-react";
import { db, auth } from "../lib/firebase";
import { collection, query, where, getDocs, doc, getDoc, setDoc, deleteDoc, updateDoc, orderBy, limit, startAfter } from "firebase/firestore";
import { playSound } from "../utils/audio";
import { getIntegrityRank } from '../utils/integrityEngine';
import { CompletedSession } from "../types";
import Leaderboards from "./Leaderboards";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";

interface ProfileViewProps {
  history: CompletedSession[];
  streakCount: number;
  onNavigateToView?: (view: any, params?: any) => void;
  targetUserId?: string;
}

export default function ProfileView({ history = [], streakCount = 0, onNavigateToView, targetUserId }: ProfileViewProps) {
  const { user, profile, refreshProfile } = useAuth();
  
  // Identify if viewing own profile
  const isOwnProfile = !targetUserId || targetUserId === profile?.uid;
  const viewUserId = isOwnProfile ? profile?.uid : targetUserId;
  
  const [viewProfile, setViewProfile] = useState<any>(isOwnProfile ? profile : null);
  const [loadingProfile, setLoadingProfile] = useState(!isOwnProfile);
  
  const [followersCount, setFollowersCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [isFollowing, setIsFollowing] = useState(false);
  const [toggleFollowLoading, setToggleFollowLoading] = useState(false);
  const [showLeaderboards, setShowLeaderboards] = useState(false);
  
  const [activeList, setActiveList] = useState<"followers" | "following" | null>(null);
  const [listUsers, setListUsers] = useState<any[]>([]);
  const [loadingList, setLoadingList] = useState(false);
  
  const [isEditingBio, setIsEditingBio] = useState(false);
  const [bioText, setBioText] = useState("");
  const [savingBio, setSavingBio] = useState(false);
  const [error, setError] = useState("");
  
  const [workouts, setWorkouts] = useState<any[]>([]);
  const [loadingWorkouts, setLoadingWorkouts] = useState(false);
  const [lastWorkoutDoc, setLastWorkoutDoc] = useState<any>(null);
  const [hasMoreWorkouts, setHasMoreWorkouts] = useState(false);
  
  const [currentUserFollowingMap, setCurrentUserFollowingMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    console.log("[ProfileView] Dependency effect triggered. IsOwnProfile:", isOwnProfile, "Context XP:", profile?.xp);
    if (!viewUserId && !isOwnProfile) return;
    loadProfileData();
  }, [viewUserId, isOwnProfile, profile]);

  const loadProfileData = async () => {
    try {
      if (!isOwnProfile && viewUserId) {
        setLoadingProfile(true);
        if (auth.currentUser && viewUserId !== 'local_user') {
          const userDoc = await getDoc(doc(db, "users", viewUserId));
          if (userDoc.exists()) {
            setViewProfile({ uid: userDoc.id, ...userDoc.data() });
            setBioText(userDoc.data().bio || "");
          }
        }
        setLoadingProfile(false);
      } else {
        setViewProfile(profile || {
          uid: 'local_user',
          username: 'Warrior',
          xp: 0,
          rank: 'Beginner',
          streak: streakCount,
          joinDate: 'Today'
        });
        setBioText(profile?.bio || "");
      }

      // If user is local/guest or unauthenticated, skip remote social follow queries
      if (!auth.currentUser || !viewUserId || viewUserId === 'local_user') {
        setFollowersCount(0);
        setFollowingCount(0);
        setIsFollowing(false);
        if (isOwnProfile) {
          setWorkouts(history.slice(0, 30));
          setHasMoreWorkouts(history.length > 30);
        }
        setLoadingProfile(false);
        return;
      }
      
      try {
        const followersQ = query(collection(db, "follows"), where("followingId", "==", viewUserId));
        const followingQ = query(collection(db, "follows"), where("followerId", "==", viewUserId));
        
        const [followersSnap, followingSnap] = await Promise.all([
          getDocs(followersQ),
          getDocs(followingQ)
        ]);
        
        setFollowersCount(followersSnap.size);
        setFollowingCount(followingSnap.size);
        
        if (!isOwnProfile && profile?.uid) {
          const checkFollowQ = query(
            collection(db, "follows"), 
            where("followerId", "==", profile.uid),
            where("followingId", "==", viewUserId)
          );
          const checkFollowSnap = await getDocs(checkFollowQ);
          setIsFollowing(!checkFollowSnap.empty);
        }
      } catch (socialErr) {
        console.warn("Could not load social follower connections:", socialErr);
      }

      if (!isOwnProfile) {
        fetchWorkouts(true);
      } else {
        setWorkouts(history.slice(0, 30));
        setHasMoreWorkouts(history.length > 30);
      }
      
    } catch (err) {
      console.error("Error loading profile data:", err);
      setError("Something went wrong");
      setLoadingProfile(false);
    }
  };

  const fetchWorkouts = async (isInitial = false) => {
    if (!viewUserId || isOwnProfile || !auth.currentUser || viewUserId === 'local_user') return;
    setLoadingWorkouts(true);
    try {
      let workoutsQ = query(
        collection(db, "users", viewUserId, "workouts"),
        orderBy("timestamp", "desc"),
        limit(30)
      );
      
      if (!isInitial && lastWorkoutDoc) {
        workoutsQ = query(
          collection(db, "users", viewUserId, "workouts"),
          orderBy("timestamp", "desc"),
          startAfter(lastWorkoutDoc),
          limit(30)
        );
      }

      const snapshot = await getDocs(workoutsQ);
      const fetched = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      
      if (isInitial) {
        setWorkouts(fetched);
      } else {
        setWorkouts(prev => [...prev, ...fetched]);
      }
      
      setLastWorkoutDoc(snapshot.docs[snapshot.docs.length - 1]);
      setHasMoreWorkouts(snapshot.docs.length === 30);
    } catch (err) {
      console.error("Error fetching workouts:", err);
    }
    setLoadingWorkouts(false);
  };

  const loadFollowList = async (type: "followers" | "following") => {
    setActiveList(type);
    setLoadingList(true);
    setListUsers([]);
    if (!auth.currentUser || !viewUserId || viewUserId === 'local_user') {
      setLoadingList(false);
      return;
    }
    try {
      const q = type === "followers" 
        ? query(collection(db, "follows"), where("followingId", "==", viewUserId))
        : query(collection(db, "follows"), where("followerId", "==", viewUserId));
        
      const snap = await getDocs(q);
      const relationIds = snap.docs.map(d => type === "followers" ? d.data().followerId : d.data().followingId);
      
      if (relationIds.length === 0) {
        setLoadingList(false);
        return;
      }
      
      // Batch fetch user details (max 10 for simplicity, in a real app we would chunk 'in' queries)
      const userDocs = [];
      // To stay within free quota and avoid large 'in' queries which can fail over 10:
      // We will do individual fetches since lists might be small, or chunk them
      for (const id of relationIds) {
        const uDoc = await getDoc(doc(db, "users", id));
        if (uDoc.exists()) {
          userDocs.push({ uid: uDoc.id, ...uDoc.data() });
        }
      }
      setListUsers(userDocs);
      
      // Load current user's follow status towards these users
      if (profile?.uid) {
        const myFollowingMap: Record<string, boolean> = {};
        for (const u of userDocs) {
          if (u.uid === profile.uid) continue;
          const checkQ = query(
            collection(db, "follows"),
            where("followerId", "==", profile.uid),
            where("followingId", "==", u.uid)
          );
          const chkSnap = await getDocs(checkQ);
          myFollowingMap[u.uid] = !chkSnap.empty;
        }
        setCurrentUserFollowingMap(myFollowingMap);
      }
      
    } catch (err) {
      console.error("Error loading list:", err);
    }
    setLoadingList(false);
  };

  const handleToggleFollow = async (targetId: string, currentStatus: boolean, isMainProfileBtn = false) => {
    if (!profile?.uid || !auth.currentUser || profile.uid === 'local_user' || toggleFollowLoading) return;
    
    // We cannot follow ourselves
    if (profile.uid === targetId) return;
    
    setToggleFollowLoading(true);
    playSound("click");
    
    try {
      const followId = `${profile.uid}_${targetId}`;
      const followRef = doc(db, "follows", followId);
      
      if (currentStatus) {
        await deleteDoc(followRef);
        if (isMainProfileBtn) {
          setIsFollowing(false);
          setFollowersCount(prev => Math.max(0, prev - 1));
        } else {
          setCurrentUserFollowingMap(prev => ({...prev, [targetId]: false}));
        }
      } else {
        await setDoc(followRef, {
          followerId: profile.uid,
          followingId: targetId,
          timestamp: Date.now()
        });
        if (isMainProfileBtn) {
          setIsFollowing(true);
          setFollowersCount(prev => prev + 1);
        } else {
          setCurrentUserFollowingMap(prev => ({...prev, [targetId]: true}));
        }
      }
    } catch (err) {
      console.error("Error toggling follow:", err);
    }
    setToggleFollowLoading(false);
  };

  const handleSaveBio = async () => {
    if (!profile?.uid) return;
    setSavingBio(true);
    try {
      await updateDoc(doc(db, "users", profile.uid), { bio: bioText });
      setIsEditingBio(false);
      refreshProfile(); // Assuming this is available to update context
      playSound("success");
    } catch (err) {
      console.error("Error saving bio:", err);
    }
    setSavingBio(false);
  };

  if (loadingProfile) {
    return (
      <div className="flex-1 flex items-center justify-center h-full">
        <Loader2 className="w-8 h-8 text-brand-accent animate-spin" />
      </div>
    );
  }

  if (!viewProfile) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center h-full p-6 text-center">
        <User className="w-16 h-16 text-brand-muted opacity-50 mb-4" />
        <h2 className="text-xl font-black text-white uppercase tracking-widest">Profile Not Found</h2>
        <button 
          onClick={() => onNavigateToView?.("home")}
          className="mt-6 px-6 py-3 bg-brand-surface border border-brand-border rounded-xl text-xs font-black uppercase tracking-widest"
        >
          Go Back
        </button>
      </div>
    );
  }

  const rankDetails = getRankDetails(viewProfile.xp || 0);
  const totalWorkouts = isOwnProfile ? history.length : (viewProfile.totalWorkouts || workouts.length || 0);
  const displayStreak = isOwnProfile ? streakCount : (viewProfile.streak || 0);
  const integrity = getIntegrityRank(viewProfile.integrityScore || 100);

  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#B66DFF]/30">
      {/* HEADER */}
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
        <div className="flex items-center gap-3">
          {!isOwnProfile && (
            <button onClick={() => onNavigateToView?.("world")} className="p-2 -ml-2 rounded-lg hover:bg-white/5 text-white">
              <ChevronLeft className="w-6 h-6" />
            </button>
          )}
          <div className="flex flex-col">
            <h1 className="text-xl leading-none font-black text-white uppercase tracking-widest">{viewProfile.username || "Fighter"}</h1>
            {viewProfile.fighterId && (
              <span className="text-[10px] font-black uppercase tracking-widest text-brand-muted mt-0.5">
                {viewProfile.fighterId}
              </span>
            )}
          </div>
        </div>
        {isOwnProfile && (
          <button onClick={() => onNavigateToView?.("settings")} className="p-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 hover:border-[#B66DFF]/30 transition-all group">
            <Settings className="w-5 h-5 text-neutral-400 group-hover:text-[#B66DFF]" />
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#B66DFF]/5 rounded-full blur-[100px] pointer-events-none" />
        <div className="max-w-4xl mx-auto space-y-8 relative z-10 pb-24">
        {/* UPGRADED: 3D HOLOGRAPHIC FIGHTER SHOWCASE & TELEMETRY BANNER */}
        <div className="bg-gradient-to-br from-[#0A1328] via-[#070D1E] to-[#050B1A] border border-[#14F1E1]/30 rounded-3xl p-5 shadow-[0_0_40px_rgba(20,241,225,0.1)]">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
            <div className="md:col-span-5">
              <Exercise3DCharacterLoop
                name="Barbell Squat"
                muscles={["chest", "shoulders", "quads", "abs"]}
                compact={false}
                interactive={true}
              />
            </div>
            <div className="md:col-span-7 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono font-black uppercase tracking-widest text-[#14F1E1] block">
                    HOLO-BIOMETRIC ATHLETE ID
                  </span>
                  <h2 className="text-2xl font-black text-white uppercase tracking-tight">
                    {viewProfile.username || "Warrior"}
                  </h2>
                </div>
                <div className="px-3 py-1.5 rounded-xl bg-[#14F1E1]/15 border border-[#14F1E1]/40 text-right">
                  <span className="text-[9px] font-mono uppercase text-neutral-300 block">
                    ACTIVE RANK
                  </span>
                  <span className="text-xs font-black uppercase text-[#14F1E1]">
                    {rankDetails.emoji} {rankDetails.title}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                <div className="bg-black/50 border border-white/10 rounded-2xl p-3 text-center">
                  <span className="text-[9px] font-mono uppercase text-neutral-400 block">
                    TOTAL XP
                  </span>
                  <span className="text-lg font-mono font-black text-[#14F1E1]">
                    {viewProfile.xp || 0}
                  </span>
                </div>
                <div className="bg-black/50 border border-white/10 rounded-2xl p-3 text-center">
                  <span className="text-[9px] font-mono uppercase text-neutral-400 block">
                    STREAK
                  </span>
                  <span className="text-lg font-mono font-black text-[#B66DFF]">
                    {displayStreak}D 🔥
                  </span>
                </div>
                <div className="bg-black/50 border border-emerald-500/30 rounded-2xl p-3 text-center">
                  <span className="text-[9px] font-mono uppercase text-neutral-400 block">
                    TRUST SCORE
                  </span>
                  <span className="text-lg font-mono font-black text-emerald-400">
                    {viewProfile.integrityScore || 100}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* PROFILE SOCIAL METRICS */}
        <div className="px-4 pt-2 pb-4">
          <div className="flex items-center gap-3 md:gap-6">

            <div className="flex-1 flex justify-between ml-1 md:ml-2">
              <div className="flex flex-col items-center justify-center">
                <span className="text-lg md:text-xl font-black text-white">{totalWorkouts}</span>
                <span className="text-[8px] md:text-[10px] uppercase font-bold text-brand-muted tracking-widest">Workouts</span>
              </div>
              <button onClick={() => loadFollowList("followers")} className="flex flex-col items-center justify-center hover:opacity-80 active:scale-95 transition-all">
                <span className="text-lg md:text-xl font-black text-white">{followersCount}</span>
                <span className="text-[8px] md:text-[10px] uppercase font-bold text-brand-muted tracking-widest">Followers</span>
              </button>
              <button onClick={() => loadFollowList("following")} className="flex flex-col items-center justify-center hover:opacity-80 active:scale-95 transition-all">
                <span className="text-lg md:text-xl font-black text-white">{followingCount}</span>
                <span className="text-[8px] md:text-[10px] uppercase font-bold text-brand-muted tracking-widest">Following</span>
              </button>
            </div>
          </div>

          <div className="mt-6 mb-2">
            <div className="flex justify-between text-[10px] text-brand-muted font-mono font-bold mb-1.5">
              <span>{rankDetails.title} Progress</span>
              <span>{viewProfile.xp || 0} / {rankDetails.nextXP} XP</span>
            </div>
            <div className="h-2.5 w-full bg-[#050B1A] rounded-full overflow-hidden border border-brand-accent/20">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, Math.max(0, (((viewProfile.xp || 0) - rankDetails.base) / (rankDetails.nextXP - rankDetails.base)) * 100))}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="h-full gradient-main shadow-[0_0_10px_#14F1E1]"
              />
            </div>
          </div>

          <div className="mt-5">
            {isEditingBio ? (
              <div className="flex items-center gap-2">
                <input 
                  type="text" 
                  maxLength={60}
                  value={bioText}
                  onChange={e => setBioText(e.target.value)}
                  className="flex-1 bg-brand-surface border border-brand-accent/50 rounded-lg px-3 py-2 text-sm text-white focus:outline-none"
                  placeholder="Add a bio... (max 60 chars)"
                />
                <button onClick={handleSaveBio} disabled={savingBio} className="p-2 bg-brand-accent text-black rounded-lg">
                  {savingBio ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                </button>
              </div>
            ) : (
              <p className="text-sm text-white/90 font-medium">
                {bioText || (isOwnProfile ? <span className="text-brand-muted text-xs italic">No bio yet</span> : null)}
              </p>
            )}
          </div>

          <div className="mt-4 flex gap-2">
            {isOwnProfile ? (
              <button 
                onClick={() => setIsEditingBio(!isEditingBio)}
                className="flex-1 py-2 bg-brand-surface border border-brand-border rounded-xl text-xs font-black uppercase tracking-widest text-white hover:bg-neutral-800 transition-colors"
              >
                {isEditingBio ? "Cancel" : "Edit Profile"}
              </button>
            ) : (
              <>
                <button 
                  onClick={() => handleToggleFollow(viewUserId!, isFollowing, true)}
                  disabled={toggleFollowLoading}
                  className={`flex-1 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-colors ${
                    isFollowing 
                      ? 'bg-brand-surface border border-brand-border text-white hover:bg-neutral-800' 
                      : 'bg-[#4DA8FF] text-black hover:bg-[#4DA8FF]/90'
                  }`}
                >
                  {toggleFollowLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : (isFollowing ? "Following" : "Follow")}
                </button>
                <button 
                  onClick={() => onNavigateToView?.("dojo")}
                  className="flex-1 py-2 bg-[#B66DFF] text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-[#B66DFF]/90 transition-colors"
                >
                  Challenge
                </button>
              </>
            )}
          </div>
        </div>

        {/* STATS CARDS */}
        <div className="px-4 py-2 flex gap-3 overflow-x-auto custom-scrollbar">
          <div className="shrink-0 w-28 bg-brand-surface/50 border border-brand-border rounded-xl p-3 flex flex-col items-center justify-center">
            <Award className="w-5 h-5 text-brand-accent mb-1" />
            <span className="text-xs font-black text-white">{viewProfile.xp || 0}</span>
            <span className="text-[8px] uppercase tracking-widest text-brand-muted">Total XP</span>
          </div>
          <div className="shrink-0 w-28 bg-brand-surface/50 border border-brand-border rounded-xl p-3 flex flex-col items-center justify-center">
            <Flame className="w-5 h-5 text-orange-500 mb-1" />
            <span className="text-xs font-black text-white">{displayStreak} Days</span>
            <span className="text-[8px] uppercase tracking-widest text-brand-muted">Streak</span>
          </div>
          <div className="shrink-0 w-28 bg-brand-surface/50 border border-brand-border rounded-xl p-3 flex flex-col items-center justify-center">
            <Shield className={`w-5 h-5 mb-1 ${integrity.color}`} />
            <span className="text-xs font-black text-white">{viewProfile.integrityScore || 100}%</span>
            <span className="text-[8px] uppercase tracking-widest text-brand-muted">Trust Score</span>
          </div>
        </div>

                {/* LEADERBOARDS BUTTON */}
        <div className="px-4 mt-4">
          <button 
            onClick={() => setShowLeaderboards(true)}
            className="w-full bg-[#1A2642] border border-[#B66DFF]/30 hover:border-[#B66DFF] rounded-xl p-4 flex items-center justify-between transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#B66DFF]/20 flex items-center justify-center">
                <Trophy className="w-5 h-5 text-[#B66DFF]" />
              </div>
              <div className="text-left">
                <h3 className="text-sm font-black uppercase text-white group-hover:text-[#B66DFF] transition-colors">Global Leaderboards</h3>
                <p className="text-[10px] font-bold uppercase tracking-widest text-brand-muted">See where you rank worldwide</p>
              </div>
            </div>
            <ChevronLeft className="w-5 h-5 text-brand-muted rotate-180 group-hover:text-[#B66DFF] group-hover:translate-x-1 transition-all" />
          </button>
        </div>

        {/* HISTORY LIST */}
        <div className="px-4 mt-6">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-5 h-5 text-brand-muted" />
            <h3 className="text-xs font-black uppercase tracking-widest text-neutral-400">Workout History</h3>
          </div>

          <div className="space-y-3">
            {loadingWorkouts && workouts.length === 0 ? (
              <div className="py-10 flex justify-center">
                <Loader2 className="w-8 h-8 text-brand-accent animate-spin" />
              </div>
            ) : workouts.length === 0 ? (
              <div className="py-10 flex flex-col items-center justify-center text-center opacity-50 border border-dashed border-brand-border rounded-xl">
                <Dumbbell className="w-10 h-10 text-brand-muted mb-2" />
                <p className="text-xs font-bold uppercase tracking-widest text-brand-muted">No workouts logged yet — start your first session!</p>
              </div>
            ) : (
              workouts.map((session, i) => {
                // Determine icon
                const isSquat = session.exercises?.some((e: any) => e.name_en.toLowerCase().includes('squat'));
                const isPushup = session.exercises?.some((e: any) => e.name_en.toLowerCase().includes('pushup') || e.name_en.toLowerCase().includes('push-up'));
                const icon = isSquat ? "🦵" : isPushup ? "💪" : "🏋️";
                
                const dateStr = new Date(session.date || session.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
                const reps = session.exercises?.reduce((acc: number, e: any) => acc + (e.reps * e.sets || 0), 0) || 0;
                
                return (
                  <div key={session.id || i} className="bg-brand-surface border border-brand-border rounded-xl p-3 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-neutral-900 border border-brand-border flex flex-col items-center justify-center shrink-0">
                      <span className="text-xl">{icon}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-white truncate">
                          {session.muscles?.join(", ") || "General Workout"}
                        </h4>
                        {session.isSmartValidation && !session.unverified && (
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        )}
                        {session.unverified && (
                          <Flag className="w-3.5 h-3.5 text-red-500 shrink-0" />
                        )}
                      </div>
                      <p className="text-[10px] uppercase tracking-wider text-brand-muted mt-0.5 truncate">
                        {reps > 0 ? `${reps} Total Reps • ` : ''}{session.totalDurationMin || 15} Min
                      </p>
                    </div>
                    <div className="shrink-0 flex items-center gap-1 text-[10px] font-black uppercase text-brand-muted">
                      <Clock className="w-3 h-3" />
                      {dateStr}
                    </div>
                  </div>
                );
              })
            )}

            {hasMoreWorkouts && (
              <button 
                onClick={() => fetchWorkouts(false)}
                disabled={loadingWorkouts}
                className="w-full py-3 mt-2 bg-brand-surface/50 border border-brand-border rounded-xl text-xs font-black uppercase tracking-widest text-brand-muted hover:text-white transition-colors flex items-center justify-center"
              >
                {loadingWorkouts ? <Loader2 className="w-4 h-4 animate-spin" /> : "Load More"}
              </button>
            )}
          </div>
        </div>
      </div>
      </div>


      {/* FOLLOWERS / FOLLOWING MODAL */}
      <AnimatePresence>
        {activeList && (
          <motion.div 
            initial={{ opacity: 0, y: "100%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="absolute inset-0 z-50 bg-[#050B1A] flex flex-col"
          >
            <div className="p-4 flex items-center justify-between border-b border-brand-border bg-[#050B1A]">
              <h2 className="text-lg font-black text-white uppercase tracking-widest">
                {activeList === "followers" ? "Followers" : "Following"}
              </h2>
              <button onClick={() => setActiveList(null)} className="p-2 bg-brand-surface rounded-full text-white hover:bg-neutral-800">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
              {loadingList ? (
                <div className="py-10 flex justify-center">
                  <Loader2 className="w-8 h-8 text-brand-accent animate-spin" />
                </div>
              ) : listUsers.length === 0 ? (
                <div className="py-10 flex flex-col items-center text-center opacity-50">
                  <Users className="w-12 h-12 text-brand-muted mb-3" />
                  <p className="text-xs font-bold uppercase tracking-widest text-brand-muted">{activeList === "followers" ? "No followers yet — invite friends to join your journey!" : "You're not following anyone yet — find athletes to follow!"}</p>
                </div>
              ) : (
                listUsers.map(u => {
                  const amFollowing = currentUserFollowingMap[u.uid];
                  const isMe = u.uid === profile?.uid;
                  
                  return (
                    <div key={u.uid} className="flex items-center justify-between bg-brand-surface border border-brand-border p-3 rounded-xl">
                      <div 
                        className="flex items-center gap-3 cursor-pointer flex-1"
                        onClick={() => {
                          setActiveList(null);
                          if (onNavigateToView) onNavigateToView("profile", { userId: u.uid });
                        }}
                      >
                        {u.photoURL && u.photoURL.startsWith('http') ? (
                          <img src={u.photoURL} alt="" className="w-10 h-10 rounded-full border border-brand-border object-cover" />
                        ) : (
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg border ${u.avatarBg || 'bg-brand-surface border-brand-border'}`}>
                            {u.photoURL || "🥷"}
                          </div>
                        )}
                        <div>
                          <p className="text-sm font-bold text-white leading-tight">{u.username || "User"}</p>
                          <p className="text-[10px] text-brand-muted uppercase tracking-widest mt-0.5">{getRankDetails(u.xp || 0).title}</p>
                        </div>
                      </div>
                      
                      {!isMe && profile?.uid && (
                        <button 
                          onClick={() => handleToggleFollow(u.uid, amFollowing)}
                          className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-colors ${
                            amFollowing 
                              ? 'bg-neutral-800 text-white border border-neutral-700' 
                              : 'bg-[#4DA8FF] text-black'
                          }`}
                        >
                          {amFollowing ? "Following" : "Follow"}
                        </button>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* LEADERBOARDS MODAL */}
      <AnimatePresence>
        {showLeaderboards && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="absolute inset-0 z-50 bg-[#050B1A] flex flex-col"
          >
             <Leaderboards onClose={() => setShowLeaderboards(false)} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
