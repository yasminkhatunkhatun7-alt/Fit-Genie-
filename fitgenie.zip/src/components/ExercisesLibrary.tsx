import React, { useState, useEffect, useMemo } from "react";
import { Search, Filter, Play, CheckCircle, Info, X, ChevronRight, ChevronDown, ChevronUp, Video, Award, Trophy, Dumbbell, Star, Lock, Swords, Flame, Sparkles, BookOpen, CheckCircle2, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { EXERCISES_DATA } from "../data/exercises";
import { Exercise } from "../types";
import { useAuth } from "../context/AuthContext";
import { playSound } from "../utils/audio";
import { ConfirmModal } from "./ConfirmModal";
import HostelJugaadArena from "./HostelJugaadArena";
import StrengthAndTimerDeck from "./StrengthAndTimerDeck";
import { useAppLanguage } from "../utils/language";
import { ExerciseLoopPreview } from "./ExerciseLoopPreview";
import { Exercise3DCharacterLoop } from "./Exercise3DCharacterLoop";
import { SmartWorkoutTracker } from "./SmartWorkoutTracker";

export interface CalisthenicsExercise {
  id: string;
  name: string;
  reps: string;
  xpReward: number;
}

export interface CaliLesson {
  id: string;
  name: string;
  description: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced" | "Elite";
  targetMuscles: string[];
  duration: string;
  videoUrl: string;
  exercises: CalisthenicsExercise[];
}

export const CALISTHENICS_LESSONS: CaliLesson[] = [
  {
    id: "lesson_1",
    name: "LEVEL 1 - STARTER",
    description: "The beginning of your calisthenics journey. Build basic strength and core stability.",
    difficulty: "Beginner",
    targetMuscles: ["Full Body", "Core"],
    duration: "15 Mins",
    videoUrl: "", 
    exercises: [
      { id: "cali_1", name: "Wall Push Up", reps: "3 sets x 15 reps", xpReward: 50 },
      { id: "cali_2", name: "Knee Push Up", reps: "3 sets x 10 reps", xpReward: 60 },
      { id: "cali_3", name: "Assisted Squat", reps: "3 sets x 15 reps", xpReward: 50 },
      { id: "cali_4", name: "Dead Bug", reps: "3 sets x 20 reps", xpReward: 50 },
      { id: "cali_5", name: "Glute Bridge", reps: "3 sets x 15 reps", xpReward: 50 },
      { id: "cali_6", name: "Incline Push Up", reps: "3 sets x 12 reps", xpReward: 60 },
      { id: "cali_7", name: "Plank Hold", reps: "3 sets x 30s", xpReward: 80 },
      { id: "cali_8", name: "Bodyweight Squat", reps: "4 sets x 15 reps", xpReward: 100 },
      { id: "cali_9", name: "Hollow Body Hold", reps: "3 sets x 30s", xpReward: 130 },
      { id: "cali_10", name: "Surya Namaskar", reps: "3 sets x 6 reps", xpReward: 100 },
    ]
  },
  {
    id: "lesson_2",
    name: "LEVEL 2 - BEGINNER",
    description: "Move past the basics. Develop true push and pull strength.",
    difficulty: "Beginner",
    targetMuscles: ["Chest", "Back", "Legs"],
    duration: "20 Mins",
    videoUrl: "",
    exercises: [
      { id: "cali_11", name: "Negative Pull Up", reps: "3 sets x 5 reps", xpReward: 100 },
      { id: "cali_12", name: "Full Push Up", reps: "3 sets x 12 reps", xpReward: 100 },
      { id: "cali_13", name: "Dead Hang", reps: "3 sets x 30s", xpReward: 80 },
      { id: "cali_14", name: "Jump Squat", reps: "3 sets x 15 reps", xpReward: 100 },
      { id: "cali_15", name: "Parallel Bar Dips", reps: "3 sets x 10 reps", xpReward: 120 },
      { id: "cali_16", name: "L-Sit Hold", reps: "3 sets x 15s", xpReward: 150 },
    ]
  },
  {
    id: "lesson_3",
    name: "LEVEL 3 - INTERMEDIATE",
    description: "Take your bodyweight strength to the next level with advanced variations.",
    difficulty: "Intermediate",
    targetMuscles: ["Chest", "Back", "Core"],
    duration: "25 Mins",
    videoUrl: "",
    exercises: [
      { id: "cali_17", name: "Full Pull Up", reps: "3 sets x 8 reps", xpReward: 150 },
      { id: "cali_18", name: "Diamond Push Up", reps: "3 sets x 12 reps", xpReward: 150 },
      { id: "cali_19", name: "Pike Push Up", reps: "3 sets x 8 reps", xpReward: 150 },
      { id: "cali_20", name: "Assisted Pistol Squat", reps: "3 sets x 8 reps/leg", xpReward: 150 },
      { id: "cali_21", name: "Chest To Bar Pull Up", reps: "3 sets x 5 reps", xpReward: 200 },
      { id: "cali_22", name: "Dragon Flag Negative", reps: "3 sets x 5 reps", xpReward: 200 },
    ]
  },
  {
    id: "lesson_4",
    name: "LEVEL 4 - ADVANCED",
    description: "Master complex unilateral movements and elite gymnastic strength.",
    difficulty: "Advanced",
    targetMuscles: ["Full Body", "Shoulders"],
    duration: "30 Mins",
    videoUrl: "",
    exercises: [
      { id: "cali_23", name: "Full Pistol Squat", reps: "3 sets x 5 reps/leg", xpReward: 250 },
      { id: "cali_24", name: "One Arm Pull Up", reps: "3 sets x 1 rep/arm", xpReward: 500 },
      { id: "cali_25", name: "Wall Handstand Push Up", reps: "3 sets x 5 reps", xpReward: 250 },
      { id: "cali_26", name: "Tuck Back Lever", reps: "3 sets x 10s", xpReward: 250 },
      { id: "cali_27", name: "Muscle Up", reps: "3 sets x 5 reps", xpReward: 300 },
    ]
  },
  {
    id: "lesson_5",
    name: "LEVEL 5 - ELITE",
    description: "The pinnacle of bodyweight mastery. Defy gravity.",
    difficulty: "Elite",
    targetMuscles: ["Full Body", "Core", "Shoulders"],
    duration: "35 Mins",
    videoUrl: "",
    exercises: [
      { id: "cali_28", name: "Free Handstand Push Up", reps: "3 sets x 5 reps", xpReward: 400 },
      { id: "cali_29", name: "Tuck Planche", reps: "3 sets x 10s", xpReward: 400 },
      { id: "cali_30", name: "Human Flag", reps: "3 sets x 10s/side", xpReward: 500 },
      { id: "cali_31", name: "Full Front Lever", reps: "3 sets x 10s", xpReward: 500 },
      { id: "cali_32", name: "One Arm Push Up", reps: "3 sets x 5 reps/arm", xpReward: 350 },
      { id: "cali_33", name: "Full Planche", reps: "3 sets x 5s", xpReward: 800 },
      { id: "cali_34", name: "Iron Cross", reps: "3 sets x 5s", xpReward: 1000 },
      { id: "cali_35", name: "Manna Hold", reps: "3 sets x 5s", xpReward: 1000 },
    ]
  }
];

interface ExercisesLibraryProps {
  forceMode?: "workouts" | "calisthenics";
  initialSearchQuery?: string;
  onSaveSmartSession?: any;
}

export default function ExercisesLibrary({ forceMode, initialSearchQuery, onSaveSmartSession }: ExercisesLibraryProps = {}) {
  const { user, profile, updateUserProfileFields, updateProfileStats } = useAuth();
  const { lang: appLang, t } = useAppLanguage();
  const [viewingCalisthenics, setViewingCalisthenics] = useState(forceMode === "calisthenics");
  const [localAchieved, setLocalAchieved] = useState<string[]>([]);
  const [confirmAchieveState, setConfirmAchieveState] = useState<{isOpen: boolean, exId: string, xpReward: number} | null>(null);
  const [selectedLessonExerciseName, setSelectedLessonExerciseName] = useState<string | null>(null);
  
  // States for Academy & Expandable Exercise Cards
  const [activeLesson, setActiveLesson] = useState<CaliLesson | null>(null);
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery || "");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("All");
  const [expandedExerciseId, setExpandedExerciseId] = useState<number | null>(null);
  const [activeSmartExercise, setActiveSmartExercise] = useState<Exercise | null>(null);

  // Calisthenics Logic — sync both achievedCalisthenics & calisthenicsUnlocked
  useEffect(() => {
    const fromProfile =
      profile?.achievedCalisthenics ||
      (profile as any)?.calisthenicsUnlocked;
    if (Array.isArray(fromProfile) && fromProfile.length > 0) {
      setLocalAchieved(fromProfile);
      localStorage.setItem("fit_genie_calisthenics", JSON.stringify(fromProfile));
    } else {
      const stored = localStorage.getItem("fit_genie_calisthenics");
      if (stored) {
        try {
          setLocalAchieved(JSON.parse(stored));
        } catch {}
      }
    }
  }, [profile?.achievedCalisthenics, (profile as any)?.calisthenicsUnlocked]);

  const requestAchieveExercise = async (exId: string, xpReward: number) => {
    if (localAchieved.includes(exId)) return;
    setConfirmAchieveState({ isOpen: true, exId, xpReward });
  };

  const confirmAchieve = async () => {
    if (!confirmAchieveState) return;
    playSound("success");
    const newAchieved = Array.from(new Set([...localAchieved, confirmAchieveState.exId]));
    setLocalAchieved(newAchieved);
    localStorage.setItem("fit_genie_calisthenics", JSON.stringify(newAchieved));

    if (updateProfileStats && confirmAchieveState.xpReward > 0) {
      try {
        await updateProfileStats({
          xpGained: confirmAchieveState.xpReward,
          workoutCompleted: true,
        });
      } catch (err) {
        console.error("Failed to award Calisthenics XP:", err);
      }
    }

    if (user && updateUserProfileFields) {
      try {
        await updateUserProfileFields({ 
          achievedCalisthenics: newAchieved,
          calisthenicsUnlocked: newAchieved 
        } as any);
      } catch (err) {
        console.error("Failed to save calisthenics achievement:", err);
      }
    }
    setConfirmAchieveState(null);
  };

  // Calculations for Academy
  const validCompletedExercises = useMemo(() => {
    const allValidIds = CALISTHENICS_LESSONS.flatMap(l => l.exercises.map(ex => ex.id));
    return localAchieved.filter(id => allValidIds.includes(id));
  }, [localAchieved]);

  const totalCaliExercises = CALISTHENICS_LESSONS.reduce((acc, lesson) => acc + lesson.exercises.length, 0);
  const caliProgress = totalCaliExercises === 0 ? 0 : Math.min(100, Math.round((validCompletedExercises.length / totalCaliExercises) * 100));
  const completedLessonsCount = CALISTHENICS_LESSONS.filter(l => l.exercises.length > 0 && l.exercises.every(ex => validCompletedExercises.includes(ex.id))).length;
  
  const totalEarnedXp = validCompletedExercises.reduce((total, exId) => {
    for (const lesson of CALISTHENICS_LESSONS) {
      const ex = lesson.exercises.find(e => e.id === exId);
      if (ex) return total + ex.xpReward;
    }
    return total;
  }, 0);
  
  // Determine Rank
  let currentRank = "STARTER";
  if (caliProgress >= 20) currentRank = "BEGINNER";
  if (caliProgress >= 40) currentRank = "INTERMEDIATE";
  if (caliProgress >= 60) currentRank = "ADVANCED";
  if (caliProgress >= 80) currentRank = "ELITE";
  if (caliProgress === 100) currentRank = "LEGEND";

  // Filter Lessons
  const filteredLessons = useMemo(() => {
    return CALISTHENICS_LESSONS.filter((lesson) => {
      const matchDiff = selectedDifficulty === "All" || lesson.difficulty === selectedDifficulty;
      const query = searchQuery.toLowerCase();
      const matchSearch = query === "" || 
        lesson.name.toLowerCase().includes(query) ||
        lesson.description.toLowerCase().includes(query) ||
        lesson.targetMuscles.some(m => m.toLowerCase().includes(query));
      return matchDiff && matchSearch;
    });
  }, [searchQuery, selectedDifficulty]);

  // Smart Training Path Filter (Feature #5: Auto-morphs Exercises based on user's Onboarding Archetype)
  const userSavedPath =
    profile?.trainingPath ||
    (localStorage.getItem("fitgenie_training_path") as
      | "calisthenics"
      | "gym"
      | "home_jugaad"
      | "aesthetics"
      | null) ||
    "all";

  const [pathFilter, setPathFilter] = useState<
    "all" | "calisthenics" | "gym" | "home_jugaad" | "aesthetics"
  >(userSavedPath);

  // IDEA #2: Injury / Joint Pain Safe-Mode Filter
  const [injuryMode, setInjuryMode] = useState<
    "all_good" | "wrist" | "knee" | "lower_back" | "shoulder"
  >(() => {
    return (
      (localStorage.getItem("fitgenie_injury_mode") as any) || "all_good"
    );
  });

  useEffect(() => {
    const syncInjury = () => {
      const saved = localStorage.getItem("fitgenie_injury_mode") as any;
      if (saved) setInjuryMode(saved);
    };
    window.addEventListener("fitgenie_personalization_updated", syncInjury);
    return () =>
      window.removeEventListener("fitgenie_personalization_updated", syncInjury);
  }, []);

  const handleSelectInjuryMode = (
    mode: "all_good" | "wrist" | "knee" | "lower_back" | "shoulder"
  ) => {
    playSound("click");
    setInjuryMode(mode);
    try {
      localStorage.setItem("fitgenie_injury_mode", mode);
    } catch {}
  };

  // Joint-safe modification engine (#2)
  const getInjuryModification = (ex: Exercise): string | null => {
    const nameL = ex.name_en.toLowerCase();
    const musclesL = ex.muscles.map((m) => m.toLowerCase());
    if (injuryMode === "wrist") {
      if (
        nameL.includes("push") ||
        nameL.includes("plank") ||
        nameL.includes("dip") ||
        nameL.includes("press") ||
        nameL.includes("curl")
      ) {
        return "🩹 Wrist-Safe Mod: Perform on closed knuckles/push-up bars or switch to forearm support to keep wrists 100% neutral.";
      }
    }
    if (injuryMode === "knee") {
      if (
        musclesL.includes("legs") ||
        musclesL.includes("quads") ||
        nameL.includes("squat") ||
        nameL.includes("lunge") ||
        nameL.includes("jump")
      ) {
        return "🩹 Knee-Safe Mod: Use High-Box Squat (90° max depth) or Glute Bridges — zero forward knee shear.";
      }
    }
    if (injuryMode === "lower_back") {
      if (
        musclesL.includes("back") ||
        musclesL.includes("core") ||
        nameL.includes("deadlift") ||
        nameL.includes("row") ||
        nameL.includes("sit")
      ) {
        return "🩹 Spine-Safe Mod: Chest-supported variation or McGill Dead-Bug / Bird-Dog with braced core.";
      }
    }
    if (injuryMode === "shoulder") {
      if (
        musclesL.includes("shoulders") ||
        musclesL.includes("chest") ||
        nameL.includes("press") ||
        nameL.includes("push") ||
        nameL.includes("dip")
      ) {
        return "🩹 Shoulder-Safe Mod: Use 45° tucked elbows (scapular plane) and stop 2 inches above bottom stretch.";
      }
    }
    return null;
  };

  const userDisplayName = profile?.name || profile?.username || "Warrior";

  useEffect(() => {
    if (profile?.trainingPath) {
      setPathFilter(profile.trainingPath);
    }
  }, [profile?.trainingPath]);

  const handleSelectPathFilter = (
    nextPath: "all" | "calisthenics" | "gym" | "home_jugaad" | "aesthetics"
  ) => {
    playSound("click");
    setPathFilter(nextPath);
    if (nextPath !== "all") {
      try {
        localStorage.setItem("fitgenie_training_path", nextPath);
      } catch {}
    }
  };

  // Workout Library Logic (Smart Path Filtered + Search Query)
  const filteredExercises = useMemo(() => {
    return EXERCISES_DATA.filter((ex) => {
      // 1. Check Path Filter
      if (pathFilter === "calisthenics") {
        // Only bodyweight ('none') or pullup bar ('pullup') exercises — NO gym barbells/cables/dumbbells!
        const isCali = ex.equipment.every(
          (eq) => eq === "none" || eq === "pullup"
        );
        if (!isCali) return false;
      } else if (pathFilter === "home_jugaad") {
        // Zero equipment bodyweight drills suitable for Hostel/PG room
        const isHome = ex.equipment.includes("none");
        if (!isHome) return false;
      } else if (pathFilter === "gym") {
        // Iron Titan: prioritize dumbbells, barbell, cables, bench
        const isGym = ex.equipment.some((eq) =>
          ["dumbbells", "barbell", "cables", "bench", "pullup"].includes(eq)
        );
        if (!isGym) return false;
      } else if (pathFilter === "aesthetics") {
        // Aesthetic V-Taper: Shoulders, Upper Chest, Lats/Back, Core/Abs
        const isAesthetic = ex.muscles.some((m) =>
          ["shoulders", "back", "chest", "core", "biceps"].includes(
            m.toLowerCase()
          )
        );
        if (!isAesthetic) return false;
      }

      // 2. Check Search Query
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        ex.name_en.toLowerCase().includes(q) ||
        ex.name_hi.toLowerCase().includes(q) ||
        ex.muscles.some((m) => m.toLowerCase().includes(q))
      );
    });
  }, [searchQuery, pathFilter]);

  return (
    <div className={`mx-auto p-4 space-y-6 pb-24 ${viewingCalisthenics ? "max-w-7xl" : "max-w-4xl"}`}>
      {viewingCalisthenics ? (
        // PREMIUM CALISTHENICS ACADEMY VIEW
        <div className="space-y-8 select-none">
          {/* Title & Introduction Hero Banner */}
          <div className="relative rounded-3xl bg-[radial-gradient(ellipse_at_top_right,rgba(20,241,225,0.15),transparent_65%)] bg-[#0C0C0C] border border-[#1E1E1E] p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6 overflow-hidden">
            <div className="absolute top-0 left-0 w-32 h-32 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />
            
            <div className="space-y-4 text-left relative z-10 max-w-xl">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-brand-accent/10 border border-brand-accent/25 text-brand-accent rounded-full text-[10px] font-black uppercase tracking-widest font-mono">
                <Award className="w-3.5 h-3.5" /> Calisthenics Academy
              </span>
              <h2 className="text-3xl md:text-4xl font-extrabold uppercase tracking-tight text-white leading-none">
                MASTER YOUR <span className="text-brand-accent">BODYWEIGHT</span>
              </h2>
              <p className="text-sm text-zinc-300 font-medium leading-relaxed">
                Welcome to the Calisthenics Academy. Master true physical freedom through progressive bodyweight strength training. From foundational pushups to the elite human flag.
              </p>

              {/* Quick Stats Pill Panel */}
              <div className="flex flex-wrap gap-3 pt-2">
                <div className="bg-[#141414] border border-[#222] rounded-xl px-3 py-2 text-center mini-card">
                  <span className="block text-[8px] font-mono text-zinc-500 uppercase font-bold">Current Rank</span>
                  <span className="text-sm font-black text-brand-accent">{currentRank}</span>
                </div>
                <div className="bg-[#141414] border border-[#222] rounded-xl px-3 py-2 text-center mini-card flex items-center gap-2">
                  <div className="text-left">
                    <span className="block text-[8px] font-mono text-zinc-500 uppercase font-bold">Lessons Completed</span>
                    <span className="text-sm font-black text-white font-mono">{completedLessonsCount} / {CALISTHENICS_LESSONS.length}</span>
                  </div>
                  <Award className="w-4 h-4 text-yellow-500" />
                </div>
                <div className="bg-[#141414] border border-[#222] rounded-xl px-3 py-2 text-center mini-card flex items-center gap-2">
                  <div className="text-left">
                    <span className="block text-[8px] font-mono text-zinc-500 uppercase font-bold">Total XP</span>
                    <span className="text-sm font-black text-brand-accent font-mono">{totalEarnedXp}</span>
                  </div>
                  <Flame className="w-4 h-4 text-orange-500" />
                </div>
              </div>
            </div>

            {/* Visual Progress Dial Gauge */}
            <div className="relative w-36 h-36 shrink-0 flex items-center justify-center bg-brand-surface border border-neutral-850 rounded-full select-none">
              <div className="absolute inset-2 rounded-full border border-neutral-900 bg-[#070707] flex flex-col items-center justify-center">
                <span className="text-xs font-mono font-bold text-zinc-500 uppercase">MASTERY</span>
                <span className="text-3xl font-extrabold text-white font-mono">{caliProgress}%</span>
                <span className="text-[8px] font-black uppercase text-brand-accent tracking-widest mt-0.5">completed</span>
              </div>

              {/* Custom SVG ring progress */}
              <svg className="absolute inset-0 w-full h-full transform -rotate-90">
                <circle cx="72" cy="72" r="66" stroke="#131313" strokeWidth="5" fill="transparent" />
                <circle
                  cx="72"
                  cy="72"
                  r="66"
                  stroke="var(--brand-accent)"
                  strokeWidth="6"
                  fill="transparent"
                  strokeDasharray={414}
                  strokeDashoffset={414 - (414 * caliProgress) / 100}
                  strokeLinecap="round"
                  className="transition-all duration-1000 ease-out"
                />
              </svg>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* LEFT COLUMN: LESSONS LIBRARY */}
            <div className="lg:col-span-2 space-y-6 text-left">
              {/* Filters & Search Row */}
              <div className="bg-[#0C0C0C] border border-[#1E1E1E] rounded-2xl p-4 space-y-3">
                <div className="flex flex-col md:flex-row gap-3">
                  {/* Search */}
                  <input
                    type="text"
                    placeholder="Search exercises, skills, or muscles..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-grow bg-[#141414] border border-[#262626] rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-brand-accent transition-all uppercase font-medium font-mono"
                  />

                  {/* Training Level Filter */}
                  <div className="flex gap-1.5 shrink-0 bg-[#141414] p-1 border border-[#262626] rounded-xl font-mono text-[10px] overflow-x-auto scrollbar-none">
                    {["All", "Beginner", "Intermediate", "Advanced", "Elite"].map((lv) => (
                      <button
                        key={lv}
                        onClick={() => { playSound("click"); setSelectedDifficulty(lv); }}
                        className={`px-3 py-1.5 rounded-lg font-black uppercase tracking-wider transition-all cursor-pointer shrink-0 ${
                          selectedDifficulty === lv
                            ? "bg-brand-accent text-brand-bg font-black"
                            : "text-zinc-400 hover:text-white"
                        }`}
                      >
                        {lv}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Lessons Stack */}
              <div className="flex flex-col gap-4">
                <h3 className="text-xs font-black uppercase text-zinc-400 tracking-widest font-mono flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-brand-accent" /> Academy Catalog ({filteredLessons.length})
                </h3>

                <div className="flex flex-col gap-4">
                  <AnimatePresence mode="popLayout">
                    {filteredLessons.length === 0 ? (
                      <motion.div
                        key="no-lessons"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="bg-[#0C0C0C] border border-[#1C1C1C] rounded-2xl py-12 text-center p-6 space-y-2"
                      >
                        <p className="text-sm font-black text-zinc-400 uppercase tracking-wider">No lessons match your filter</p>
                      </motion.div>
                    ) : (
                      filteredLessons.map((lesson) => {
                        const lessonTotalExercises = lesson.exercises.length;
                        const lessonCompletedExercises = lesson.exercises.filter(ex => localAchieved.includes(ex.id)).length;
                        const isLessonCompleted = lessonCompletedExercises === lessonTotalExercises;
                        const lessonXp = lesson.exercises.reduce((sum, ex) => sum + ex.xpReward, 0);

                        return (
                          <motion.div
                            key={lesson.id}
                            layout
                            initial={{ opacity: 0, y: 15 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -15 }}
                            className={`border transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98] rounded-2xl overflow-hidden cursor-pointer select-none group shadow-lg hover:shadow-xl ${
                              isLessonCompleted 
                                ? "border-emerald-500/30 bg-[#0C120C]/35 hover:border-emerald-500/50" 
                                : "border-[#1E1E1E] hover:border-brand-accent/40 bg-[#0C0C0C]"
                            }`}
                            onClick={() => {
                              playSound("click");
                              setActiveLesson(lesson);
                            }}
                          >
                            <div className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                              <div className="flex items-center gap-4 flex-grow min-w-0">
                                <div className="relative w-28 h-20 shrink-0 rounded-xl overflow-hidden border border-[#14F1E1]/30 bg-[#050B1A] shadow-inner flex items-center justify-center">
                                  <Exercise3DCharacterLoop
                                    exerciseName={lesson.exercises[0]?.name || lesson.name}
                                    targetMuscles={lesson.targetMuscles}
                                    difficulty={lesson.difficulty.toLowerCase() as any}
                                    compact={true}
                                    showControls={false}
                                  />
                                </div>

                                <div className="text-left space-y-1 min-w-0 flex-grow">
                                  <div className="flex flex-wrap items-center gap-1.5">
                                    {/* Difficulty Badge */}
                                    <span className={`inline-flex items-center gap-1 text-[8.5px] font-mono uppercase px-2 py-0.5 rounded-md font-black border ${
                                      lesson.difficulty === "Beginner" 
                                        ? "bg-cyan-950/40 text-cyan-400 border-cyan-500/20" 
                                        : lesson.difficulty === "Intermediate" 
                                          ? "bg-yellow-950/40 text-yellow-400 border-yellow-500/20" 
                                          : lesson.difficulty === "Advanced"
                                            ? "bg-orange-950/40 text-orange-400 border-orange-500/20"
                                            : "bg-red-950/40 text-red-400 border-red-500/20"
                                    }`}>
                                      <span>{lesson.difficulty}</span>
                                    </span>
                                    
                                    {isLessonCompleted && (
                                      <span className="inline-flex items-center gap-1 bg-emerald-500/10 text-emerald-400 text-[8px] border border-emerald-500/25 px-1.5 py-0.5 rounded font-black font-mono">
                                        <CheckCircle2 className="w-2.5 h-2.5" /> MASTERY
                                      </span>
                                    )}
                                  </div>

                                  <h4 className="text-xs font-black uppercase text-white tracking-wide group-hover:text-brand-accent transition-colors truncate">
                                    {lesson.name}
                                  </h4>
                                  
                                  <p className="text-[10px] text-zinc-400 line-clamp-1 font-medium leading-relaxed">
                                    {lesson.description}
                                  </p>

                                  <div className="flex flex-wrap items-center gap-y-1 gap-x-3 pt-1.5 border-t border-neutral-900 mt-1.5 text-[9px] uppercase font-mono tracking-wider">
                                    <span className="text-zinc-500 flex items-center gap-1">
                                      <span className="text-[10px]">🎯</span>
                                      <span className="text-brand-accent/90">{lesson.targetMuscles.slice(0, 3).join(", ")}</span>
                                    </span>
                                    <span className="text-zinc-500 flex items-center gap-1">
                                      <span className="text-[10px]">⏱️</span>
                                      <span className="text-neutral-300">{lesson.duration}</span>
                                    </span>
                                  </div>
                                </div>
                              </div>

                              <div className="flex flex-wrap sm:flex-nowrap items-center gap-2.5 shrink-0 self-end sm:self-auto mt-2 sm:mt-0">
                                <span className="text-[10px] font-mono text-brand-muted font-bold block bg-[#131313] px-2.5 py-1 rounded-lg border border-[#232323]">
                                  +{lessonXp} XP
                                </span>
                                <button className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-brand-accent hover:text-brand-bg text-white border border-white/10 hover:border-brand-accent transition-all text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5">
                                  Start <ArrowRight className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                            
                            {/* Inner Progress Bar */}
                            <div className="h-1 w-full bg-neutral-900">
                              <div 
                                className="h-full bg-brand-accent transition-all duration-500" 
                                style={{ width: `${(lessonCompletedExercises / lessonTotalExercises) * 100}%` }}
                              />
                            </div>
                          </motion.div>
                        );
                      })
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>

            {/* RIGHT COLUMN: STATS AND INFO */}
            <div className="space-y-6">
              <div className="bg-[#0C0C0C] border border-[#1E1E1E] rounded-2xl p-5 space-y-4">
                <h3 className="text-xs font-black uppercase text-zinc-400 tracking-widest font-mono flex items-center gap-2">
                  <Flame className="w-4 h-4 text-orange-500" /> Progression Status
                </h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-xl bg-[#141414] border border-[#262626]">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-brand-accent/10 flex items-center justify-center">
                        <Dumbbell className="w-4 h-4 text-brand-accent" />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Exercises Mastered</p>
                        <p className="text-sm font-black text-white">{validCompletedExercises.length} / {totalCaliExercises}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-xl bg-[#141414] border border-[#262626]">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                        <Award className="w-4 h-4 text-yellow-500" />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Lessons Conquered</p>
                        <p className="text-sm font-black text-white">{completedLessonsCount} / {CALISTHENICS_LESSONS.length}</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-[#1E1E1E]">
                  <p className="text-[10px] text-zinc-500 font-mono leading-relaxed">
                    "Calisthenics is the ultimate pursuit of physical mastery. No equipment required. Just your body, gravity, and unwavering discipline."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        // WORKOUTS VIEW
        <div className="space-y-4">
          <div className="flex flex-col items-center justify-center pt-4 pb-2">
            <h1 className="text-3xl font-black uppercase text-white tracking-tight flex items-center gap-3">
              <Dumbbell className="w-8 h-8 text-[#14F1E1]" /> EXERCISES
            </h1>
            <p className="text-[#9CA3AF] text-xs font-bold uppercase tracking-widest mt-1 text-center">
              Auto-Filtered for Your Glow-Up Archetype ({filteredExercises.length} Drills)
            </p>
          </div>

          {/* SMART ARCHETYPE FILTER BAR (FEATURE #5) */}
          <div className="bg-[#0D1328] border border-[#14F1E1]/30 rounded-2xl p-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-widest text-[#14F1E1] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> Active Training Filter
              </span>
              <button
                onClick={() =>
                  handleSelectPathFilter(
                    pathFilter === "all"
                      ? (userSavedPath === "all" ? "calisthenics" : userSavedPath)
                      : "all"
                  )
                }
                className="text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 cursor-pointer"
              >
                {pathFilter === "all" ? "Lock My Path Only" : "Show All Equipment"}
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
              {[
                { id: "calisthenics", label: "🤸 Calisthenics" },
                { id: "gym", label: "🏋️ Gym Iron" },
                { id: "home_jugaad", label: "🎒 Hostel Jugaad" },
                { id: "aesthetics", label: "🗿 V-Taper" },
                { id: "all", label: "🌐 All Drills" },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => handleSelectPathFilter(tab.id as any)}
                  className={`py-2 px-2 rounded-xl text-[10px] font-black uppercase tracking-wider border transition-all cursor-pointer ${
                    pathFilter === tab.id
                      ? "bg-[#14F1E1] text-black border-[#14F1E1] shadow-[0_0_12px_rgba(20,241,225,0.35)]"
                      : "bg-black/40 border-white/10 text-neutral-400 hover:text-white"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {pathFilter === "calisthenics" && (
              <div className="flex items-center justify-between bg-[#14F1E1]/10 border border-[#14F1E1]/30 rounded-xl px-3 py-2">
                <span className="text-[10px] font-bold text-white">
                  🤸 Gym barbell/machine clutter hidden! Want progressive 5-Level Skills?
                </span>
                <button
                  onClick={() => {
                    playSound("click");
                    setViewingCalisthenics(true);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-[#14F1E1] text-black text-[9px] font-black uppercase tracking-wider shrink-0 ml-2 cursor-pointer"
                >
                  Open Academy
                </button>
              </div>
            )}

            {/* IDEA #2: JOINT & INJURY SAFE-MODE INLINE BAR */}
            <div className="pt-2 border-t border-white/10 space-y-1.5">
              <span className="text-[9px] font-mono uppercase tracking-widest text-emerald-400 block">
                🩹 Joint / Pain Safe-Mode (Auto-Modifies Risky Drills for {userDisplayName}):
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { id: "all_good", label: "✅ All Good" },
                  { id: "wrist", label: "🤚 Wrist Safe" },
                  { id: "knee", label: "🦵 Knee Safe" },
                  { id: "lower_back", label: "🦴 Back Safe" },
                  { id: "shoulder", label: "💪 Shoulder Safe" },
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() => handleSelectInjuryMode(m.id as any)}
                    className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider border transition-all cursor-pointer ${
                      injuryMode === m.id
                        ? "bg-emerald-400 text-black border-emerald-400"
                        : "bg-black/40 border-white/10 text-neutral-400 hover:text-white"
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* IDEA #5, #7, #8: 1RM & CALISTHENICS SKILL CALCULATOR + AKHADA VOICE TIMER + PLATEAU BUSTER */}
          <StrengthAndTimerDeck />

          {/* IDEA #13: HOSTEL / PG ROOM "DESI JUGAAD" ZERO-EQUIPMENT WORKOUT GENERATOR (Shown for Hostel/Cali/All, hidden in pure Gym mode to prevent clutter) */}
          {pathFilter !== "gym" && (
            <HostelJugaadArena onSaveSmartSession={onSaveSmartSession} />
          )}

          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-500" />
            <input
              type="text"
              placeholder="Search exercises, muscles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#050B1A] border border-[#4DA8FF]/20 rounded-2xl py-4 pl-12 pr-4 text-white placeholder-neutral-500 font-bold focus:outline-none focus:border-[#4DA8FF]/50 transition-colors"
            />
          </div>
          
          <div className="space-y-3.5">
            {filteredExercises.map((ex) => {
              const injuryMod = getInjuryModification(ex);
              const isExpanded = expandedExerciseId === ex.id;
              const primaryM = (ex.muscles[0] || "full body").toLowerCase();
              const isChest = primaryM.includes("chest") || primaryM.includes("pec");
              const isBack = primaryM.includes("back") || primaryM.includes("lat") || primaryM.includes("trap");
              const isLegs = primaryM.includes("leg") || primaryM.includes("quad") || primaryM.includes("glute") || primaryM.includes("calf") || primaryM.includes("hamstring");
              const isShoulders = primaryM.includes("shoulder") || primaryM.includes("delt");
              const isArms = primaryM.includes("bicep") || primaryM.includes("tricep") || primaryM.includes("forearm") || primaryM.includes("arm");
              const isCore = primaryM.includes("core") || primaryM.includes("ab") || primaryM.includes("oblique");
              const accentHex = isChest
                ? "#00F5D4"
                : isBack
                ? "#B66DFF"
                : isLegs
                ? "#FF006E"
                : isShoulders
                ? "#FFB703"
                : isArms
                ? "#00BBF9"
                : isCore
                ? "#10B981"
                : "#14F1E1";

              return (
                <div
                  key={ex.id}
                  onClick={() => {
                    playSound("click");
                    setExpandedExerciseId(isExpanded ? null : ex.id);
                  }}
                  style={{
                    boxShadow: isExpanded
                      ? `0 18px 40px -12px rgba(0,0,0,0.85), 0 0 28px ${accentHex}28, inset 0 1px 0 rgba(255,255,255,0.18)`
                      : `0 12px 28px -10px rgba(0,0,0,0.75), inset 0 1px 0 rgba(255,255,255,0.08)`,
                  }}
                  className={`bg-gradient-to-br from-[#0B132B]/95 via-[#070D1F]/95 to-[#040814] border rounded-2xl p-4 flex flex-col gap-3 transition-all duration-300 cursor-pointer relative overflow-hidden group ${
                    isExpanded
                      ? "border-[#14F1E1]/60"
                      : "border-white/10 hover:border-[#14F1E1]/45 hover:-translate-y-0.5"
                  }`}
                >
                  {/* 3D Top Specular Rim Highlight */}
                  <div
                    className="absolute top-0 left-6 right-6 h-[1.5px] opacity-75 pointer-events-none"
                    style={{
                      background: `linear-gradient(90deg, transparent, ${accentHex}, transparent)`,
                    }}
                  />

                  {/* Main Responsive Grid: Details Left + Dedicated Looping GIF/Video Column Right (Desktop) */}
                  <div className="grid grid-cols-1 md:grid-cols-[1fr_195px] gap-4 items-center">
                    <div className="flex items-start gap-3.5 min-w-0">
                      {/* 3D Holographic Anatomical Target Pod */}
                      <div
                        className="w-14 h-16 rounded-2xl bg-[#050914] border flex flex-col items-center justify-center shrink-0 mt-0.5 relative overflow-hidden"
                        style={{
                          borderColor: `${accentHex}55`,
                          boxShadow: `inset 0 0 16px ${accentHex}25, 0 0 15px ${accentHex}18`,
                        }}
                      >
                        <svg viewBox="0 0 60 72" className="w-12 h-14 overflow-visible">
                          {/* 3D Floor Pedestal Ring */}
                          <ellipse
                            cx="30"
                            cy="64"
                            rx="18"
                            ry="4.5"
                            fill="none"
                            stroke={accentHex}
                            strokeWidth="1.2"
                            strokeDasharray="3 2"
                            opacity="0.65"
                          />
                          {/* Wireframe Cyber-Athlete Silhouette */}
                          <circle cx="30" cy="12" r="5" fill="none" stroke="#64748B" strokeWidth="1.3" />
                          {/* Torso */}
                          <polygon
                            points="20,20 40,20 36,42 24,42"
                            fill={isChest || isBack ? `${accentHex}35` : "rgba(255,255,255,0.03)"}
                            stroke={isChest || isBack ? accentHex : "#475569"}
                            strokeWidth="1.4"
                          />
                          {/* Shoulders */}
                          <circle
                            cx="17"
                            cy="22"
                            r="3.2"
                            fill={isShoulders ? accentHex : "#1E293B"}
                            stroke={isShoulders ? "#FFF" : "#475569"}
                            strokeWidth="1"
                          />
                          <circle
                            cx="43"
                            cy="22"
                            r="3.2"
                            fill={isShoulders ? accentHex : "#1E293B"}
                            stroke={isShoulders ? "#FFF" : "#475569"}
                            strokeWidth="1"
                          />
                          {/* Arms */}
                          <line
                            x1="16"
                            y1="25"
                            x2="13"
                            y2="39"
                            stroke={isArms ? accentHex : "#475569"}
                            strokeWidth={isArms ? "3.2" : "1.8"}
                            strokeLinecap="round"
                          />
                          <line
                            x1="44"
                            y1="25"
                            x2="47"
                            y2="39"
                            stroke={isArms ? accentHex : "#475569"}
                            strokeWidth={isArms ? "3.2" : "1.8"}
                            strokeLinecap="round"
                          />
                          {/* Core / Abs */}
                          <rect
                            x="25.5"
                            y="29"
                            width="9"
                            height="11"
                            rx="1.5"
                            fill={isCore ? accentHex : "transparent"}
                            stroke={isCore ? "#FFF" : "transparent"}
                            strokeWidth="0.8"
                            opacity={isCore ? "0.9" : "0"}
                          />
                          {/* Chest Pecs Highlight */}
                          {isChest && (
                            <>
                              <polygon points="21,21 29.5,21 29.5,28 22,28" fill={accentHex} opacity="0.85" />
                              <polygon points="30.5,21 39,21 38,28 30.5,28" fill={accentHex} opacity="0.85" />
                            </>
                          )}
                          {/* Back V-Taper Highlight */}
                          {isBack && (
                            <polygon points="21,21 39,21 35,36 25,36" fill={accentHex} opacity="0.75" />
                          )}
                          {/* Legs */}
                          <line
                            x1="26"
                            y1="42"
                            x2="23"
                            y2="60"
                            stroke={isLegs ? accentHex : "#475569"}
                            strokeWidth={isLegs ? "3.5" : "2"}
                            strokeLinecap="round"
                          />
                          <line
                            x1="34"
                            y1="42"
                            x2="37"
                            y2="60"
                            stroke={isLegs ? accentHex : "#475569"}
                            strokeWidth={isLegs ? "3.5" : "2"}
                            strokeLinecap="round"
                          />
                        </svg>
                        <span
                          className="text-[7px] font-mono font-black uppercase tracking-widest px-1 rounded bg-black/70 border border-white/10 -mt-1"
                          style={{ color: accentHex }}
                        >
                          TARGET
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                          <span className="text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-[#14F1E1]/15 text-[#14F1E1] border border-[#14F1E1]/30">
                            ✨ {t("Tere Liye:", "Matched for")} {userDisplayName} • {pathFilter === "all" ? "All-Rounder" : pathFilter.replace("_", " ")}
                          </span>
                          {injuryMod && (
                            <span className="text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                              🩹 {injuryMode.toUpperCase()}-MODIFIED
                            </span>
                          )}
                        </div>

                        <div className="flex items-center justify-between gap-2">
                          <h3 className="text-white font-black uppercase tracking-wider text-sm sm:text-base truncate">
                            {appLang === "hinglish" ? `${ex.name_en} (${ex.name_hi})` : ex.name_en}
                          </h3>
                          {/* Mobile Expand / Preview Toggle Indicator */}
                          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-white/5 border border-white/10 text-[9px] font-mono font-bold text-[#14F1E1] shrink-0">
                            <Video className="w-3 h-3" />
                            <span className="md:hidden">{isExpanded ? "Hide Form" : "Form Guide"}</span>
                            <span className="hidden md:inline">{isExpanded ? "Less" : "Details"}</span>
                            {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                          </span>
                        </div>

                        <p className="text-neutral-400 text-xs font-bold mt-0.5">
                          {appLang === "hinglish"
                            ? `${ex.name_hi} • ${ex.sets} Sets × ${ex.reps} Reps`
                            : `Target: ${ex.muscles.join(", ").toUpperCase()} • ${ex.sets} Sets × ${ex.reps} Reps`}
                        </p>

                        <div className="flex items-center gap-2 mt-2 flex-wrap">
                          {ex.muscles.map((m) => (
                            <span key={m} className="text-[9px] bg-neutral-900 border border-neutral-800 text-neutral-300 px-1.5 py-0.5 rounded uppercase tracking-widest font-bold">
                              {m}
                            </span>
                          ))}
                          <span
                            className="text-[9px] px-1.5 py-0.5 rounded uppercase tracking-widest font-mono font-bold border"
                            style={{
                              backgroundColor: `${accentHex}15`,
                              borderColor: `${accentHex}40`,
                              color: accentHex,
                            }}
                          >
                            {ex.sets}s × {ex.reps}r • ~{ex.duration_minutes}m
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Desktop Dedicated Looping GIF / Video Preview Column */}
                    <div className="hidden md:block">
                      <ExerciseLoopPreview
                        name={ex.name_en}
                        muscles={ex.muscles}
                        equipment={ex.equipment}
                        gifUrl={ex.gif_url}
                        compact
                      />
                    </div>
                  </div>

                  {injuryMod && (
                    <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-[11px] text-emerald-200 font-semibold leading-snug">
                      {injuryMod}
                    </div>
                  )}

                  {/* Expandable Exercise Details & Mobile Looping GIF/Video Preview */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="pt-3 border-t border-white/10 space-y-3 overflow-hidden"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {/* Mobile Looping GIF / Video Preview (Shown inside expanded panel so mobile layout stays clean) */}
                        <div className="md:hidden">
                          <ExerciseLoopPreview
                            name={ex.name_en}
                            muscles={ex.muscles}
                            equipment={ex.equipment}
                            gifUrl={ex.gif_url}
                          />
                        </div>

                        <div className="p-3 rounded-xl bg-black/50 border border-white/10 space-y-1.5">
                          <p className="text-[10px] font-mono uppercase tracking-widest text-[#14F1E1] font-bold">
                            {t("Form & Technique Guide:", "Form & Technique Guide:")}
                          </p>
                          <p className="text-xs text-neutral-200 leading-relaxed font-medium">
                            {appLang === "hinglish" ? ex.instruction_hi || ex.instruction_en : ex.instruction_en}
                          </p>
                          {appLang === "hinglish" && ex.instruction_en && (
                            <p className="text-[11px] text-neutral-400 leading-relaxed">
                              {ex.instruction_en}
                            </p>
                          )}
                        </div>

                        <div className="flex items-center justify-between gap-3">
                          <div className="text-[10px] font-mono text-neutral-400 uppercase">
                            Difficulty: <strong className="text-white">{ex.difficulty}</strong> • Equipment: <strong className="text-white">{ex.equipment.join(", ")}</strong>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              playSound("click");
                              setActiveSmartExercise(ex);
                            }}
                            className="px-4 py-2 rounded-xl bg-[#14F1E1] text-[#050B1A] font-black text-xs uppercase tracking-wider flex items-center gap-1.5 hover:bg-white transition-colors cursor-pointer shrink-0"
                          >
                            <Play className="w-3.5 h-3.5 fill-current" /> Start Smart Set
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
            {filteredExercises.length === 0 && (
              <div className="text-center py-10">
                <p className="text-neutral-500 font-bold uppercase tracking-widest">No exercises found.</p>
              </div>
            )}
          </div>

          {activeSmartExercise && (
            <SmartWorkoutTracker
              exercise={activeSmartExercise}
              onClose={() => setActiveSmartExercise(null)}
              onSave={(session) => {
                if (onSaveSmartSession) onSaveSmartSession(session);
                setActiveSmartExercise(null);
              }}
            />
          )}
        </div>
      )}

      {/* ACTIVE LESSON MODAL */}
      <AnimatePresence>
        {activeLesson && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            className="fixed inset-0 z-50 flex items-end justify-center sm:items-center p-4 bg-black/80 backdrop-blur-sm"
          >
            <div className="bg-[#0C0C0C] border border-[#222] rounded-t-3xl sm:rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
              <div className="p-4 border-b border-neutral-900 flex justify-between items-center bg-[#111]">
                <div>
                  <h3 className="font-black uppercase tracking-widest text-white text-lg">{activeLesson.name}</h3>
                  <p className="text-brand-muted text-[10px] uppercase font-bold tracking-widest mt-1">Academy Lesson Details</p>
                </div>
                <button onClick={() => { playSound("click"); setActiveLesson(null); }} className="p-2 rounded-full bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-0">
                <div className="relative w-full bg-[#050B1A] border-b border-[#14F1E1]/20">
                  <Exercise3DCharacterLoop
                    exerciseName={
                      selectedLessonExerciseName ||
                      activeLesson.exercises[0]?.name ||
                      activeLesson.name
                    }
                    targetMuscles={activeLesson.targetMuscles}
                    difficulty={activeLesson.difficulty.toLowerCase() as any}
                    heightClass="h-[260px]"
                    showControls={true}
                  />
                </div>
                <div className="p-6 space-y-6">
                  <div className="flex items-center gap-3 bg-[#14F1E1]/10 p-3 rounded-xl border border-[#14F1E1]/25">
                    <Info className="w-5 h-5 text-[#14F1E1] shrink-0" />
                    <p className="text-xs font-bold text-neutral-200">
                      Tap any exercise below to preview its live form guide above, or click "MARK DONE" to claim your XP reward!
                    </p>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-xs font-black uppercase text-zinc-400 tracking-widest font-mono flex items-center gap-2">
                      <Dumbbell className="w-4 h-4 text-zinc-500" /> Lesson Exercises
                    </h4>
                    
                    <div className="space-y-3">
                      {activeLesson.exercises.map((ex) => {
                        const achieved = localAchieved.includes(ex.id);
                        return (
                          <div
                            key={ex.id}
                            onClick={() => {
                              playSound("click");
                              setSelectedLessonExerciseName(ex.name);
                            }}
                            className={`p-4 rounded-xl border flex items-center justify-between transition-all duration-300 transform hover:scale-[1.01] ${
                              achieved
                                ? "bg-emerald-500/10 border-emerald-500/30 cursor-pointer"
                                : selectedLessonExerciseName === ex.name
                                ? "bg-[#14F1E1]/10 border-[#14F1E1]/60 cursor-pointer"
                                : "bg-[#141414] border-[#262626] hover:border-brand-accent/40 cursor-pointer shadow-lg"
                            }`}
                          >
                            <div className="flex items-center gap-4">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${achieved ? "bg-emerald-500/20 text-emerald-400" : "bg-neutral-800 text-[#14F1E1]"}`}>
                                {achieved ? <CheckCircle className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                              </div>
                              <div>
                                <p className="text-sm font-bold text-white uppercase tracking-wider">{ex.name}</p>
                                <div className="flex items-center gap-2 mt-1">
                                  <span className="text-[10px] text-brand-muted uppercase tracking-widest font-mono bg-black px-1.5 py-0.5 rounded border border-[#222]">
                                    {ex.reps}
                                  </span>
                                  <span className="text-[10px] text-brand-accent uppercase tracking-widest font-mono font-bold">
                                    +{ex.xpReward} XP
                                  </span>
                                </div>
                              </div>
                            </div>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                requestAchieveExercise(ex.id, ex.xpReward);
                              }}
                              disabled={achieved}
                              className={`px-4 py-2 shrink-0 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                                achieved 
                                  ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/30 cursor-default" 
                                  : "bg-brand-accent text-brand-bg hover:bg-white cursor-pointer shadow-[0_0_10px_rgba(20,241,225,0.2)]"
                              }`}
                            >
                              {achieved ? "MASTERED" : "MARK DONE"}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {confirmAchieveState?.isOpen && (
          <ConfirmModal
            isOpen={confirmAchieveState.isOpen}
            message={`Are you sure you have fully mastered this exercise? You will earn +${confirmAchieveState.xpReward} XP!`}
            onConfirm={confirmAchieve}
            onCancel={() => setConfirmAchieveState(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
