import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { Crown, Sparkles, CheckCircle2, ShieldCheck, Zap, Lock, ArrowRight, Loader2 } from "lucide-react";

// Backward-compatible billing helpers
export async function initBilling(): Promise<void> {
  return;
}

export async function verifyCoupon(code: string, uid: string): Promise<boolean> {
  return code.trim().toUpperCase() === "GENIEPRO" || code.trim().toUpperCase() === "VIP";
}

export async function handleSubscription(uid: string, callback?: (success: boolean) => void): Promise<void> {
  if (callback) {
    callback(true);
  }
}

export function GooglePlayBillingSimulator() {
  return null;
}

interface PremiumGuardProps {
  children: React.ReactNode;
  title?: string;
  description?: string;
}

export function PremiumGuard({ 
  children, 
  title = "Exclusive Pro Athlete Access",
  description = "Unlock the complete cyber-fitness arsenal powered by AI biomechanics."
}: PremiumGuardProps) {
  const { profile, updateUserProfileFields } = useAuth();
  const [isProcessing, setIsProcessing] = useState(false);
  const [promoCode, setPromoCode] = useState("");
  const [promoMessage, setPromoMessage] = useState<string | null>(null);

  // Check if user has active Pro status
  const isPro = Boolean(profile?.isPro || profile?.isPremium);

  if (isPro) {
    return <>{children}</>;
  }

  // Simulated Pro upgrade handler
  const handleUpgradeToPro = async () => {
    setIsProcessing(true);
    try {
      if (updateUserProfileFields) {
        await updateUserProfileFields({
          isPro: true,
          isPremium: true,
          subscriptionStatus: "active_pro_simulation",
          expiry_date: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
        });
      }
    } catch (err) {
      console.error("Error activating Pro tier:", err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleApplyPromo = async () => {
    if (!promoCode.trim()) return;
    setIsProcessing(true);
    if (promoCode.trim().toUpperCase() === "GENIEPRO" || promoCode.trim().toUpperCase() === "VIP") {
      setPromoMessage("Coupon verified! Unlocking Pro Athlete status...");
      await handleUpgradeToPro();
    } else {
      setPromoMessage("Invalid promo code. Try 'GENIEPRO' for instant dev testing.");
      setIsProcessing(false);
    }
  };

  return (
    <div className="relative min-h-[500px] w-full flex items-center justify-center p-4">
      {/* Background glow effects */}
      <div className="absolute inset-0 bg-[#080706] rounded-3xl border border-[#3D3728] overflow-hidden">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-[#C68A3E]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-[#FFC066]/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Main Paywall Card */}
      <div className="relative z-10 max-w-md w-full bg-[#0F0E0B]/90 backdrop-blur-xl border border-[#524A38] rounded-2xl p-6 sm:p-8 shadow-2xl text-left">
        {/* Pro Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C68A3E]/20 border border-[#C68A3E]/40 text-[#FFC066] text-xs font-bold uppercase tracking-wider mb-4">
          <Crown className="w-3.5 h-3.5 text-[#FFC066]" />
          <span>PRO ATHLETE TIER</span>
        </div>

        <h3 className="text-2xl font-black tracking-tight text-[#E8E2D4] mb-2 flex items-center gap-2">
          {title}
        </h3>
        <p className="text-sm text-[#A89F8C] mb-6 leading-relaxed">
          {description}
        </p>

        {/* Pro Feature Highlights */}
        <div className="space-y-3 mb-6">
          <div className="flex items-start gap-3">
            <div className="p-1 rounded-md bg-[#C68A3E]/20 text-[#E8A54B] mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <p className="text-sm font-semibold text-[#E8E2D4]">4K Exercise Video Masterclasses</p>
              <p className="text-xs text-[#A89F8C]">Step-by-step calisthenics form guides & progression drills.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-1 rounded-md bg-[#C68A3E]/20 text-[#E8A54B] mt-0.5">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <p className="text-sm font-semibold text-[#E8E2D4]">Server-Verified Anti-Cheat Badges</p>
              <p className="text-xs text-[#A89F8C]">Official athlete badge on global leaderboards & 1-min tests.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-1 rounded-md bg-[#C68A3E]/20 text-[#E8A54B] mt-0.5">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <p className="text-sm font-semibold text-[#E8E2D4]">Uncapped AI Nutrition & Diet Generator</p>
              <p className="text-xs text-[#A89F8C]">Bespoke macro breakdowns generated by Gemini AI.</p>
            </div>
          </div>
        </div>

        {/* Pricing & CTA */}
        <div className="p-4 rounded-xl bg-[#17150F] border border-[#3D3728] mb-6">
          <div className="flex items-baseline justify-between mb-1">
            <span className="text-xs uppercase font-bold tracking-wider text-[#A89F8C]">All-Inclusive Pass</span>
            <span className="text-xs text-[#E8A54B] font-semibold">Test Mode Active</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-[#E8E2D4]">₹0</span>
            <span className="text-sm text-[#6E675A] line-through">₹499/mo</span>
            <span className="text-xs text-[#FFC066] font-bold ml-auto bg-[#C68A3E]/30 px-2 py-0.5 rounded">FREE TRIAL</span>
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={handleUpgradeToPro}
          disabled={isProcessing}
          className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#C68A3E] via-[#E8A54B] to-[#FFC066] text-[#080706] font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-[#C68A3E]/20 hover:brightness-110 active:scale-[0.99] transition-all disabled:opacity-50 cursor-pointer"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-[#080706]" />
              <span>Activating Pro Pass...</span>
            </>
          ) : (
            <>
              <span>Upgrade to Pro (Test Mode)</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>

        {/* Promo code redemption */}
        <div className="mt-4 pt-4 border-t border-[#3D3728]/60">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Promo code (e.g. GENIEPRO)"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
              className="flex-1 bg-[#17150F] border border-[#3D3728] rounded-lg px-3 py-1.5 text-xs text-[#E8E2D4] placeholder-[#6E675A] focus:outline-none focus:border-[#C68A3E]"
            />
            <button
              onClick={handleApplyPromo}
              disabled={isProcessing || !promoCode}
              className="px-3 py-1.5 bg-[#3D3728] hover:bg-[#524A38] text-[#E8E2D4] text-xs font-semibold rounded-lg transition-colors disabled:opacity-40"
            >
              Apply
            </button>
          </div>
          {promoMessage && (
            <p className="text-[11px] text-[#FFC066] mt-2 font-medium">{promoMessage}</p>
          )}
        </div>

        <p className="text-[10px] text-center text-[#6E675A] mt-4">
          Simulation mode for testing. Real payment gateway can be integrated via Google Play Billing.
        </p>
      </div>
    </div>
  );
}
