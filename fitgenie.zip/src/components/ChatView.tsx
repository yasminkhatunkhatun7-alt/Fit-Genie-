import React, { useState, useEffect, useRef } from "react";
import { useAuth } from "../context/AuthContext";
import { motion, AnimatePresence } from "motion/react";
import { 
  MessageCircle, 
  Search, 
  User, 
  Send, 
  RefreshCw, 
  ChevronLeft, 
  ShieldAlert, 
  Ban, 
  MoreVertical, 
  X, 
  Loader2, 
  Sparkles, 
  Shield, 
  Target, 
  Flame, 
  Dumbbell, 
  Apple, 
  RotateCcw,
  Zap,
  CheckCircle2,
  Compass,
  Bell,
  UserPlus
} from "lucide-react";
import { db } from "../lib/firebase";
import { collection, query, where, getDocs, doc, getDoc, setDoc, addDoc, orderBy, limit, deleteDoc } from "firebase/firestore";
import { playSound } from "../utils/audio";
import { EXERCISES_DATA } from "../data/exercises";
import Exercise3DCharacterLoop from "./Exercise3DCharacterLoop";

const CHAT_EXERCISE_KEYWORDS = [
  { key: "pushup", name: "Pushups", muscles: ["Chest", "Triceps", "Shoulders"] },
  { key: "push-up", name: "Pushups", muscles: ["Chest", "Triceps", "Shoulders"] },
  { key: "squat", name: "Squats", muscles: ["Quads", "Glutes", "Core"] },
  { key: "pullup", name: "Pull-Ups", muscles: ["Back", "Biceps", "Forearms"] },
  { key: "pull-up", name: "Pull-Ups", muscles: ["Back", "Biceps", "Forearms"] },
  { key: "plank", name: "Plank Hold", muscles: ["Core", "Shoulders"] },
  { key: "burpee", name: "Burpees", muscles: ["Full Body", "Quads", "Chest"] },
  { key: "crunch", name: "Crunches", muscles: ["Core", "Abs"] },
  { key: "lunge", name: "Walking Lunges", muscles: ["Quads", "Glutes", "Hamstrings"] },
  { key: "dip", name: "Parallel Bar Dips", muscles: ["Chest", "Triceps", "Shoulders"] },
  { key: "dead hang", name: "Dead Hang", muscles: ["Back", "Forearms", "Spine"] },
  { key: "hang", name: "Dead Hang", muscles: ["Back", "Forearms", "Spine"] },
  { key: "cobra", name: "Cobra Stretch", muscles: ["Core", "Lower Back"] },
  { key: "pike", name: "Pike Pushups", muscles: ["Shoulders", "Triceps"] },
];

function detectExerciseInText(text: string): { name: string; muscles: string[] } | null {
  const lower = text.toLowerCase();
  for (const item of CHAT_EXERCISE_KEYWORDS) {
    if (lower.includes(item.key)) {
      return { name: item.name, muscles: item.muscles };
    }
  }
  return null;
}

interface Friend {
  uid: string;
  userName: string;
  avatarBg: string;
  isAi?: boolean;
  tagline?: string;
}

interface ChatMessage {
  id: string;
  senderId: string;
  text: string;
  timestamp: number;
  isOffTopicFallback?: boolean;
}

const FITGENIE_BOT_ID = "fitgenie_ai_coach";

const FITGENIE_FRIEND: Friend = {
  uid: FITGENIE_BOT_ID,
  userName: "FitGenie AI Coach",
  avatarBg: "bg-gradient-to-tr from-[#14F1E1] to-[#B66DFF]",
  isAi: true,
  tagline: "24/7 Dedicated Fitness & Training Mentor"
};

// Off-topic keywords categories
const OFF_TOPIC_TRIGGERS = [
  // Politics & Government
  "modi", "rahul", "election", "bjp", "congress", "politics", "vote", "government", "parliament", "minister", "president", "bjp", "aap", "pm", "law",
  // Movies, Series & Entertainment
  "movie", "film", "cinema", "actor", "actress", "song", "gaana", "netflix", "trailer", "hero", "bollywood", "hollywood", "series", "season", "episode", "director", "cinema", "music", "singer", "album",
  // Sports & Non-fitness games
  "cricket", "ipl", "match", "score", "football", "messi", "ronaldo", "fifa", "world cup", "tennis",
  // Gaming
  "pubg", "free fire", "bgmi", "gta", "playstation", "xbox", "pc game", "minecraft", "valorant", "fortnite", "roblox",
  // Romance & Dating
  "girlfriend", "gf", "boyfriend", "bf", "love", "shadi", "pyaar", "ishq", "breakup", "date", "flirt", "propose", "crush", "dating", "kiss", "marry",
  // Tech & General Coding
  "code", "coding", "javascript", "python", "software", "react", "css", "html", "php", "java", "sql", "bug", "compiler", "github",
  // Finance & Money
  "crypto", "bitcoin", "stock", "share market", "paisa", "money", "loan", "salary", "investment", "trading", "forex", "mutual fund",
  // General Trivia & Random
  "weather", "mausam", "rain", "barish", "joke", "kahani", "story", "shayari", "alien", "space", "planet", "homework", "essay"
];

// Fitness-specific triggers
const FITNESS_TOPICS = [
  {
    id: "diet",
    keys: ["diet", "food", "khana", "meal", "nutrition", "calories", "eating", "junk", "fat loss", "cutting", "bulk"],
    en: "Eat clean, cut sugar, and stay in calorie deficit for fat loss! 💪",
    hi: "Ghar ka saaf khana khao aur sugar band karo fat loss ke liye! 🔥"
  },
  {
    id: "protein",
    keys: ["protein", "whey", "soya", "paneer", "eggs", "chicken", "dal", "protein powder"],
    en: "Take 1.5g protein per kg. Eat paneer, eggs, chicken, and soya daily! 🍗",
    hi: "Roz 1.5g protein per kg target karo! Paneer, ande, aur soya khao. 🥚"
  },
  {
    id: "workout",
    keys: ["pushup", "squat", "pullup", "dip", "workout", "exercise", "calisthenics", "training", "reps", "sets", "gym"],
    en: "Do 3-4 sets near failure! Strict form and full range of motion matter! 🏋️",
    hi: "Har exercise ke 3-4 sets failure tak lagao. Form ekdum strict rakho! 💯"
  },
  {
    id: "recovery",
    keys: ["sleep", "rest", "sore", "soreness", "dard", "pain", "recovery", "neend", "doms"],
    en: "Sleep 7-8 hours deeply! Hydrate well and rest sore muscles for 48 hours. 😴",
    hi: "7-8 ghante so jao! Dard wali muscle ko agle 48 ghante rest do. 🛌"
  },
  {
    id: "water",
    keys: ["water", "pani", "paani", "hydrate", "hydration"],
    en: "Drink 3-4 liters of water daily to boost stamina and stop cramps! 💧",
    hi: "Roz 3-4 litre paani piyo! Stamina badhega aur cramps nahi aayenge! 🚰"
  },
  {
    id: "height",
    keys: ["height", "lambai", "taller", "posture", "hang", "spine"],
    en: "Do dead hangs and cobra stretches daily to fix posture and look taller! 📏",
    hi: "Daily dead hang aur cobra stretch karo! Posture theek hoga aur height dikhegi! 🧍‍♂️"
  },
  {
    id: "motivation",
    keys: ["motivate", "motivation", "tired", "lazy", "give up", "aalsi", "himmat", "thak"],
    en: "Discipline beats motivation! Even 10 minutes of pushups keeps your streak alive! ⚡",
    hi: "Aalas chhodo! Aaj sirf 10 minute pushups marke bhi streak bacha sakte ho! 🔥"
  }
];

const POLITE_BRANDED_FALLBACKS = {
  en: [
    "Drop distractions {title}! 🛑 Focus on gains. Ask about workouts or diet! 💪",
    "Focus on the grind {title}! ⚡ Let's get back to your workout goals! 🔥",
    "No off-topic talk {title}! 🛡️ Ask me about pushups, squats, or diet! 🎯"
  ],
  hi: [
    "Faltu baatein chhod {title}! 🛑 Sirf workout, diet aur gains pe focus kar! 💪",
    "Aalas chhod {title}, grind pe dhyan de! ⚡ Fitness tips ke baare me puch! 🔥",
    "Idhar-udhar ki baat band {title}! 🛡️ Aaj ka workout pura kiya ya nahi? 🎯"
  ]
};

const SUGGESTED_FITNESS_ACTIONS = [
  { label: "💪 Pushup Form", query: "How to do perfect pushups?" },
  { label: "🥗 Diet & Protein", query: "What should be my daily protein intake?" },
  { label: "🔥 Fat Loss Tips", query: "How to lose belly fat effectively?" },
  { label: "😴 Muscle Recovery", query: "How to recover from muscle soreness?" },
  { label: "💧 Hydration Rule", query: "How much water should I drink daily?" },
  { label: "📏 Height & Posture", query: "Tips for height increase and posture" }
];

export default function ChatView() {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState<"all" | "ai" | "athletes">("all");
  const [activeScreen, setActiveScreen] = useState<"list" | "chat">("list");
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [loadingFriends, setLoadingFriends] = useState(true);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loadingNotifications, setLoadingNotifications] = useState(false);
  const [followingMap, setFollowingMap] = useState<Record<string, boolean>>({});
  
  const [activeFriend, setActiveFriend] = useState<Friend | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [inputText, setInputText] = useState("");
  const [sending, setSending] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [toastNotice, setToastNotice] = useState<string | null>(null);
  const [confirmBlockOpen, setConfirmBlockOpen] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const triggerToast = (msg: string) => {
    setToastNotice(msg);
    setTimeout(() => setToastNotice(null), 3500);
  };
  
  const currentUserId = profile?.uid;

  // Scroll to bottom helper
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, activeScreen]);

  // Load mutual friends & notifications
  useEffect(() => {
    if (!currentUserId || activeScreen !== "list") return;
    loadMutualFriends();
    loadNotifications();
  }, [currentUserId, activeScreen]);

  const searchUsers = async (qText: string) => {
    setSearchQuery(qText);
    if (qText.trim().length < 3) {
      setSearchResults([]);
      return;
    }
    setSearching(true);
    try {
      const lowerQ = qText.toLowerCase().trim();
      const isFighterIdSearch = /^\d{4}$/.test(lowerQ) || /^#\d{4}$/.test(lowerQ);
      let formattedFighterId = lowerQ;
      if (/^\d{4}$/.test(lowerQ)) formattedFighterId = "#" + lowerQ;
      
      let snap;
      if (isFighterIdSearch) {
        const q = query(
          collection(db, "users"),
          where("fighterId", "==", formattedFighterId),
          limit(20)
        );
        snap = await getDocs(q);
      } else {
        const q = query(
          collection(db, "users"),
          where("username", ">=", lowerQ),
          where("username", "<=", lowerQ + "\uf8ff"),
          limit(20)
        );
        snap = await getDocs(q);
      }

      const results: any[] = [];
      snap.forEach(d => {
        const data = d.data();
        const uName = data.username || data.userName;
        if (d.id !== currentUserId) {
          results.push({ id: d.id, userName: uName, avatarBg: data.avatarBg, fighterId: data.fighterId });
        }
      });
      setSearchResults(results);
    } catch (e) {
      console.error(e);
    } finally {
      setSearching(false);
    }
  };

  const followUser = async (userId: string) => {
    if (!currentUserId) return;
    try {
      const followId = currentUserId + "_" + userId;
      await setDoc(doc(db, "follows", followId), {
        followerId: currentUserId,
        followingId: userId,
        timestamp: Date.now()
      });
      triggerToast("⚡ Follow request sent! You are now following this athlete.");
      setShowSearch(false);
      setShowNotifications(false);
      setSearchQuery("");
      setSearchResults([]);
      loadNotifications();
      loadMutualFriends();
    } catch (e) {
      console.error(e);
    }
  };

  const loadNotifications = async () => {
    if (!currentUserId) return;
    setLoadingNotifications(true);
    try {
      const myFollowersQuery = query(collection(db, "follows"), where("followingId", "==", currentUserId));
      const myFollowersSnap = await getDocs(myFollowersQuery);
      const followerIds = myFollowersSnap.docs.map(d => d.data().followerId);
      
      const myFollowingQuery = query(collection(db, "follows"), where("followerId", "==", currentUserId));
      const myFollowingSnap = await getDocs(myFollowingQuery);
      const followingIds = new Set(myFollowingSnap.docs.map(d => d.data().followingId));
      
      const fMap: Record<string, boolean> = {};
      followingIds.forEach(id => { fMap[id] = true; });
      setFollowingMap(fMap);

      const followerDetails = [];
      for (const fId of followerIds) {
        const docSnap = await getDoc(doc(db, "users", fId));
        if (docSnap.exists()) {
          followerDetails.push({ id: docSnap.id, ...docSnap.data() });
        }
      }
      setNotifications(followerDetails);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingNotifications(false);
    }
  };

  const loadMutualFriends = async () => {
    setLoadingFriends(true);
    try {
      const followingQuery = query(collection(db, "follows"), where("followerId", "==", currentUserId));
      const followingSnap = await getDocs(followingQuery);
      const followingIds = new Set(followingSnap.docs.map(d => d.data().followingId));

      if (followingIds.size === 0) {
        setFriends([]);
        setLoadingFriends(false);
        return;
      }

      const followerQuery = query(collection(db, "follows"), where("followingId", "==", currentUserId));
      const followerSnap = await getDocs(followerQuery);
      
      const mutualIds = followerSnap.docs
        .map(d => d.data().followerId)
        .filter(id => followingIds.has(id));

      if (mutualIds.length === 0) {
        setFriends([]);
        setLoadingFriends(false);
        return;
      }

      const blockedStr = localStorage.getItem("fitgenie_blocked_users");
      const blockedIds = blockedStr ? JSON.parse(blockedStr) : [];
      
      const validMutuals = mutualIds.filter(id => !blockedIds.includes(id));
      
      if (validMutuals.length === 0) {
        setFriends([]);
        setLoadingFriends(false);
        return;
      }

      const friendProfiles: Friend[] = [];
      for (const id of validMutuals) {
        const uDoc = await getDoc(doc(db, "users", id));
        if (uDoc.exists()) {
          const data = uDoc.data();
          friendProfiles.push({
            uid: id,
            userName: data.userName || "Athlete",
            avatarBg: data.avatarBg || "bg-gradient-to-br from-zinc-700 to-zinc-900",
            tagline: "Fellow Athlete"
          });
        }
      }
      setFriends(friendProfiles);
    } catch (e) {
      console.error("Failed to load friends", e);
    } finally {
      setLoadingFriends(false);
    }
  };

  const getChatId = (uid1: string, uid2: string) => {
    return [uid1, uid2].sort().join("_");
  };

  const openChat = (friend: Friend) => {
    setActiveFriend(friend);
    setActiveScreen("chat");
    loadMessages(friend.uid);
  };

  const loadMessages = async (friendId: string) => {
    if (!currentUserId) return;
    setLoadingMessages(true);
    try {
      const chatId = getChatId(currentUserId, friendId);

      // Ensure the parent chat document exists with participants so Firestore security rules can verify membership
      const chatDocRef = doc(db, "chats", chatId);
      try {
        await setDoc(chatDocRef, {
          participants: [currentUserId, friendId],
          updatedAt: Date.now()
        }, { merge: true });
      } catch (err) {
        console.warn("Notice updating chat parent document:", err);
      }

      const q = query(
        collection(db, "chats", chatId, "messages"),
        orderBy("timestamp", "desc"),
        limit(50)
      );
      const snap = await getDocs(q);
      const fetched: ChatMessage[] = snap.docs.map(d => ({
        id: d.id,
        senderId: d.data().senderId,
        text: d.data().text,
        timestamp: d.data().timestamp
      }));
      setMessages(fetched.reverse());
    } catch (e) {
      console.error("Failed to load messages:", e);
      setMessages([]);
    } finally {
      setLoadingMessages(false);
    }
  };

  // Helper to detect language
  const detectLanguage = (text: string): "en" | "hi" => {
    const hinglishWords = ["kya", "kaise", "hai", "mera", "bata", "karna", "nahi", "haan", "bhai", "karo", "dard", "neend", "khana"];
    const lower = text.toLowerCase();
    const isHinglish = hinglishWords.some(w => lower.includes(w));
    return isHinglish ? "hi" : "en";
  };

  // Helper to process AI message with refined fallback
  const generateAiReply = (userText: string): { reply: string; isOffTopic: boolean } => {
    const lower = userText.toLowerCase().trim();
    const lang = detectLanguage(lower);

    // 1. Check for specific exercise tips in exercise database
    for (const ex of EXERCISES_DATA) {
      if (lower.includes(ex.name_en.toLowerCase()) || (ex.name_hi && lower.includes(ex.name_hi))) {
        const instr = lang === "hi" && ex.instruction_hi ? ex.instruction_hi : ex.instruction_en;
        return {
          reply: `🔥 ${ex.name_en} (${ex.difficulty.toUpperCase()}):\n\n${instr}\n\n🎯 Recommended: ${ex.sets} sets × ${ex.reps} reps. Focus on full range of motion and core stability!`,
          isOffTopic: false
        };
      }
    }

    // 2. Check for Fitness Topics
    for (const topic of FITNESS_TOPICS) {
      if (topic.keys.some(k => lower.includes(k))) {
        const text = lang === "hi" ? topic.hi : topic.en;
        return { reply: text, isOffTopic: false };
      }
    }

    // 3. Check for Non-Fitness / Off-Topic Triggers -> TRIGGER POLITE BRANDED FALLBACK
    const isOffTopic = OFF_TOPIC_TRIGGERS.some(trigger => {
      // check whole word or substring boundary
      const regex = new RegExp(`\\b${trigger}\\b`, "i");
      return regex.test(lower) || lower.includes(trigger);
    });

    if (isOffTopic) {
      const fallbackList = POLITE_BRANDED_FALLBACKS[lang];
      let randomFallback = fallbackList[Math.floor(Math.random() * fallbackList.length)];
      const athleteName = profile?.username || profile?.name || "Athlete";
      randomFallback = randomFallback.replace(/\{title\}/g, athleteName);
      return { reply: randomFallback, isOffTopic: true };
    }

    // 4. Greetings or Small Talk
    if (/^(hi|hello|hey|yo|namaste|sup|greetings)\b/i.test(lower)) {
      const athleteName = profile?.username || profile?.name || "Athlete";
      return {
        reply: lang === "hi" 
          ? "Namaste " + athleteName + "! ⚡ Aaj kaunsa workout target karne ka plan hai?"
          : "Hey " + athleteName + "! ⚡ Ready to crush today's reps? Tell me what muscle group we're training!",
        isOffTopic: false
      };
    }

    // 5. Default Fallback - Politeness with Goal Redirection
    const athleteName = profile?.username || profile?.name || "Athlete";
    const defaultTextList = lang === "hi"
      ? [
          "Workout, diet, ya form pe doubt puch {title}! ⚡ Baki topic apne scope ke bahar hai boss. 🛡️",
          "Samjha nahi {title}, thoda clear bol! 🎯 Try kar 'diet plan', 'protein guide' ya 'pushup tips'.",
          "Fitness ki baat kar bhai {title}! 💪 Bata aaj kaunse muscle ki training karni hai?"
        ]
      : [
          "Ask me about workouts, diet, protein, or form tips {title}! ⚡ I strictly focus on your fitness goals. 🛡️",
          "I didn't catch that {title}. 🎯 Try asking about a 'diet plan', 'fat loss tips', or 'squat tips'.",
          "Let's talk fitness {title}! 💪 Tell me how I can help with your exercises or nutrition today?"
        ];
    
    let defaultText = defaultTextList[Math.floor(Math.random() * defaultTextList.length)];
    defaultText = defaultText.replace(/\{title\}/g, athleteName);

    return { reply: defaultText, isOffTopic: true };
  };

  const sendMessage = async (customQuery?: string) => {
    const text = (customQuery || inputText).trim();
    if (!text || !currentUserId || !activeFriend || sending) return;
    if (text.length > 500) return;

    setSending(true);
    setInputText("");

    // --- Handle Peer-to-Peer Firestore Chat ---
    try {
      const chatId = getChatId(currentUserId, activeFriend.uid);
      const now = Date.now();

      // Ensure the parent chat document exists and tracks latest activity
      const chatDocRef = doc(db, "chats", chatId);
      try {
        await setDoc(chatDocRef, {
          participants: [currentUserId, activeFriend.uid],
          lastMessage: text,
          updatedAt: now
        }, { merge: true });
      } catch (err) {
        console.warn("Notice updating chat parent document:", err);
      }

      const messagesRef = collection(db, "chats", chatId, "messages");
      
      const newMessage = {
        senderId: currentUserId,
        text,
        timestamp: now
      };
      
      const docRef = await addDoc(messagesRef, newMessage);
      setMessages(prev => [...prev, { id: docRef.id, ...newMessage }]);
      playSound("click");

      // If chatting with AI Coach, trigger the dedicated fitness bot response
      if (activeFriend.isAi) {
        const aiReplyData = generateAiReply(text);
        const aiMessage = {
          senderId: FITGENIE_BOT_ID,
          text: aiReplyData.reply,
          timestamp: Date.now() + 50,
          isOffTopicFallback: aiReplyData.isOffTopic
        };

        const aiDocRef = await addDoc(messagesRef, aiMessage);
        setMessages(prev => [...prev, { id: aiDocRef.id, ...aiMessage }]);
      }

      const countQuery = query(messagesRef, orderBy("timestamp", "asc"), limit(51));
      const countSnap = await getDocs(countQuery);
      if (countSnap.docs.length > 50) {
        await deleteDoc(doc(db, "chats", chatId, "messages", countSnap.docs[0].id));
      }
    } catch (e) {
      console.error("Failed to send message", e);
    } finally {
      setSending(false);
    }
  };

  const blockUser = () => {
    if (!activeFriend || activeFriend.isAi) return;
    setConfirmBlockOpen(true);
  };

  const confirmBlockExecution = () => {
    if (!activeFriend) return;
    try {
      const blockedStr = localStorage.getItem("fitgenie_blocked_users");
      const blockedIds = blockedStr ? JSON.parse(blockedStr) : [];
      if (!blockedIds.includes(activeFriend.uid)) {
        blockedIds.push(activeFriend.uid);
        localStorage.setItem("fitgenie_blocked_users", JSON.stringify(blockedIds));
      }
      setConfirmBlockOpen(false);
      triggerToast(`🛡️ ${activeFriend.userName} has been blocked.`);
      setActiveScreen("list");
      setActiveFriend(null);
      loadMutualFriends();
    } catch (e) {
      console.error(e);
    }
  };

  const reportUser = () => {
    if (!activeFriend || activeFriend.isAi || !currentUserId) return;
    setReportReason("");
    setReportModalOpen(true);
  };

  const submitReportExecution = async () => {
    if (!activeFriend || !currentUserId || !reportReason.trim()) return;
    try {
      await addDoc(collection(db, "reports"), {
        reporterId: currentUserId,
        reportedUserId: activeFriend.uid,
        reason: reportReason.trim(),
        timestamp: Date.now()
      });
      setReportModalOpen(false);
      setReportReason("");
      triggerToast("✅ Report submitted to FitGenie Security Ops.");
    } catch (e) {
      console.error(e);
      triggerToast("⚠️ Failed to submit report. Try again.");
    }
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-[#050B1A]">
      <AnimatePresence mode="wait">
        {activeScreen === "list" ? (
          <motion.div
            key="list"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 flex flex-col min-h-0"
          >
            {/* Top Bar */}
            <div className="p-4 border-b border-[#1A2642] bg-[#0A1128] flex items-center justify-between z-10 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#14F1E1]/20 to-[#B66DFF]/20 border border-[#14F1E1]/30 flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-[#14F1E1]" />
                </div>
                <div>
                  <h1 className="text-xl font-black uppercase tracking-tight text-white leading-none">Chats</h1>
                  <p className="text-[10px] uppercase font-bold tracking-widest text-[#14F1E1] mt-0.5">AI Coach & Athlete Friends</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setShowNotifications(true)} 
                  title="Followers"
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white transition-colors relative"
                >
                  <Bell className="w-4 h-4" />
                  {notifications.filter(n => !followingMap[n.id]).length > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                  )}
                </button>
                <button 
                  onClick={loadMutualFriends} 
                  title="Refresh Friends"
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white transition-colors"
                >
                  <RefreshCw className={`w-4 h-4 ${loadingFriends ? 'animate-spin' : ''}`} />
                </button>
                <button 
                  onClick={() => setShowSearch(true)} 
                  title="Find Athletes"
                  className="p-2 rounded-lg bg-[#B66DFF]/20 text-[#B66DFF] hover:bg-[#B66DFF]/30 transition-colors"
                >
                  <Search className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Filter Tabs Removed */}

            {/* Chat List Scrollable */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
              {/* Pinned FitGenie AI Coach Card */}
              <div className="mb-2">
                <div className="flex items-center justify-between px-1 mb-2">
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#14F1E1] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" /> Pinned 24/7 Cyber Mentor
                  </span>
                  <span className="text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-[#14F1E1]/15 text-[#14F1E1] border border-[#14F1E1]/30">
                    3D Form Ready
                  </span>
                </div>
                <button
                  onClick={() => openChat(FITGENIE_FRIEND)}
                  className="w-full flex items-center gap-3.5 p-4 bg-gradient-to-r from-[#0A1128] via-[#0F1B3D] to-[#0A1128] border border-[#14F1E1]/40 rounded-2xl hover:border-[#14F1E1] shadow-[0_0_25px_rgba(20,241,225,0.12)] transition-all text-left group relative overflow-hidden"
                >
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center font-black text-xl text-[#050B1A] shrink-0 bg-gradient-to-tr from-[#14F1E1] to-[#B66DFF] shadow-[0_0_15px_rgba(20,241,225,0.4)]">
                    ⚡
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-black text-white text-base truncate group-hover:text-[#14F1E1] transition-colors">
                        {FITGENIE_FRIEND.userName}
                      </h4>
                      <span className="text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded bg-[#14F1E1]/20 text-[#14F1E1] border border-[#14F1E1]/40">
                        AI COACH
                      </span>
                    </div>
                    <p className="text-[10px] uppercase font-bold tracking-widest text-zinc-400 mt-0.5 truncate">
                      {FITGENIE_FRIEND.tagline} • Instant 3D Exercise Demos
                    </p>
                  </div>
                  <ChevronLeft className="w-5 h-5 text-[#14F1E1] rotate-180 opacity-80 group-hover:translate-x-1 transition-all" />
                </button>
              </div>

              {/* Mutual Athlete Friends Header */}
              <div className="flex items-center justify-between px-1 pt-2">
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#B66DFF]">
                  Mutual Squad Athletes ({friends.length})
                </span>
              </div>

              {/* Athletes List */}
              <>
                  {loadingFriends ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="w-6 h-6 text-[#B66DFF] animate-spin" />
                    </div>
                  ) : friends.length === 0 ? (
                    <div className="py-8 flex flex-col items-center justify-center text-center bg-[#0A1128]/60 border border-[#1A2642] rounded-2xl p-6">
                      <User className="w-10 h-10 text-[#B66DFF] mb-2 opacity-70" />
                      <h3 className="text-sm font-black uppercase tracking-widest text-white mb-1">No Mutual Friends Yet</h3>
                      <p className="text-xs text-brand-muted max-w-[240px] leading-relaxed">
                        Follow athletes who follow you back to unlock direct peer messaging, or train above with FitGenie AI Coach!
                      </p>
                      <button 
                        onClick={() => setShowSearch(true)}
                        className="mt-3 px-4 py-2 bg-[#B66DFF]/20 hover:bg-[#B66DFF]/30 border border-[#B66DFF]/40 text-[#B66DFF] text-xs font-black uppercase tracking-widest rounded-xl transition-colors flex items-center gap-1.5"
                      >
                        <Search className="w-3.5 h-3.5" /> Find Athletes
                      </button>
                    </div>
                  ) : (
                    friends.map(friend => (
                      <button
                        key={friend.uid}
                        onClick={() => openChat(friend)}
                        className="w-full flex items-center gap-3 p-4 bg-[#0A1128] border border-[#1A2642] rounded-2xl hover:bg-[#111A3A] hover:border-[#B66DFF]/40 transition-all text-left group"
                      >
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-lg text-white shrink-0 border-2 shadow-lg ${friend.avatarBg} border-white/10`}>
                          {friend.userName.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-white text-base truncate group-hover:text-[#B66DFF] transition-colors">{friend.userName}</h4>
                          <p className="text-[10px] uppercase font-bold tracking-widest text-brand-muted mt-0.5 truncate">{friend.tagline || "Mutual Friend"}</p>
                        </div>
                        <ChevronLeft className="w-5 h-5 text-brand-muted rotate-180 opacity-50 group-hover:opacity-100 group-hover:text-[#B66DFF] transition-all" />
                      </button>
                    ))
                  )}
                </>
            </div>

            {/* Find Athletes Modal */}
            {showSearch && (
              <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
                <div className="bg-[#0A1128] border border-[#1A2642] rounded-2xl w-full max-w-md p-4 flex flex-col max-h-[80vh]">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-black uppercase tracking-widest text-white">Find Athletes</h2>
                    <button onClick={() => setShowSearch(false)} className="p-2 rounded-lg hover:bg-white/5 text-brand-muted"><X className="w-5 h-5"/></button>
                  </div>
                  <div className="relative mb-4">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-muted" />
                    <input 
                      type="text" 
                      value={searchQuery}
                      onChange={(e) => searchUsers(e.target.value)}
                      placeholder="Search username or #code (min 3 chars)..."
                      className="w-full bg-[#050B1A] border border-[#1A2642] text-white rounded-xl pl-9 pr-4 py-3 text-sm focus:outline-none focus:border-[#B66DFF]/50 transition-colors"
                    />
                  </div>
                  <div className="flex-1 overflow-y-auto custom-scrollbar space-y-2">
                    {searching ? (
                      <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-[#B66DFF] animate-spin" /></div>
                    ) : searchResults.length > 0 ? (
                      searchResults.map(user => (
                        <div key={user.id} className="flex items-center justify-between p-3 bg-[#050B1A] border border-[#1A2642] rounded-xl">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-black text-white shrink-0 ${user.avatarBg || 'bg-zinc-800'}`}>
                              {user.userName.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <h4 className="font-bold text-white text-sm">{user.userName}</h4>
                              {user.fighterId && (
                                <span className="text-[10px] font-black uppercase tracking-widest text-[#14F1E1]">
                                  {user.fighterId}
                                </span>
                              )}
                            </div>
                          </div>
                          <button onClick={() => followUser(user.id)} className="px-3 py-1.5 bg-[#B66DFF] text-white text-[10px] font-black uppercase tracking-widest rounded-lg hover:bg-[#A352FF] transition-colors">
                            Follow
                          </button>
                        </div>
                      ))
                    ) : searchQuery.length >= 3 ? (
                      <div className="text-center py-8 text-brand-muted text-xs uppercase font-bold tracking-widest">No athletes found</div>
                    ) : null}
                  </div>
                </div>
              </div>
            )}

            {/* Notifications Modal */}
            {showNotifications && (
              <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
                <div className="bg-[#0A1128] border border-[#1A2642] rounded-2xl w-full max-w-md p-4 flex flex-col max-h-[80vh]">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-black uppercase tracking-widest text-white flex items-center gap-2">
                      <Bell className="w-5 h-5 text-[#B66DFF]" /> Notifications
                    </h2>
                    <button onClick={() => setShowNotifications(false)} className="p-2 rounded-lg hover:bg-white/5 text-brand-muted"><X className="w-5 h-5"/></button>
                  </div>
                  <div className="flex-1 overflow-y-auto custom-scrollbar space-y-2">
                    {loadingNotifications ? (
                      <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-[#B66DFF] animate-spin" /></div>
                    ) : notifications.length > 0 ? (
                      notifications.map(user => {
                        const isMutual = followingMap[user.id];
                        return (
                          <div key={user.id} className="flex items-center justify-between p-3 bg-[#050B1A] border border-[#1A2642] rounded-xl">
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-black text-white shrink-0 ${user.avatarBg || 'bg-zinc-800'}`}>
                                {user.userName?.charAt(0).toUpperCase() || user.username?.charAt(0).toUpperCase()}
                              </div>
                              <div>
                                <h4 className="font-bold text-white text-sm">{user.userName || user.username}</h4>
                                <p className="text-[10px] text-brand-muted font-bold tracking-widest uppercase">Started following you</p>
                              </div>
                            </div>
                            {isMutual ? (
                              <span className="px-3 py-1.5 bg-white/5 text-brand-muted text-[10px] font-black uppercase tracking-widest rounded-lg">
                                Friends
                              </span>
                            ) : (
                              <button onClick={() => followUser(user.id)} className="px-3 py-1.5 bg-[#14F1E1] text-[#050B1A] text-[10px] font-black uppercase tracking-widest rounded-lg hover:bg-[#0DE2D3] transition-colors flex items-center gap-1">
                                <UserPlus className="w-3 h-3" /> Follow Back
                              </button>
                            )}
                          </div>
                        );
                      })
                    ) : (
                      <div className="text-center py-8 text-brand-muted text-xs uppercase font-bold tracking-widest">No notifications</div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="chat"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="flex-1 flex flex-col min-h-0 bg-[#050B1A]"
          >
            {/* Chat Screen Header */}
            <div className="p-3 border-b border-[#1A2642] bg-[#0A1128] flex items-center justify-between z-10 shrink-0">
              <div className="flex items-center gap-2.5">
                <button onClick={() => setActiveScreen("list")} className="p-2 rounded-lg hover:bg-white/5 text-white transition-colors">
                  <ChevronLeft className="w-6 h-6" />
                </button>
                {activeFriend && (
                  <div className="flex items-center gap-2.5">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-black text-sm text-white shrink-0 shadow-md ${activeFriend.avatarBg}`}>
                      {activeFriend.isAi ? "⚡" : activeFriend.userName.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h2 className="text-sm font-black uppercase text-white leading-none">{activeFriend.userName}</h2>
                        {activeFriend.isAi && (
                          <span className="bg-[#14F1E1]/20 text-[#14F1E1] text-[9px] font-black px-1.5 py-0.2 rounded border border-[#14F1E1]/30">
                            AI COACH
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-brand-muted mt-0.5">
                        {activeFriend.isAi ? "Focused on your Fitness Goals" : "Direct Message"}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Chat Actions */}
              <div className="flex items-center gap-1 relative">
                <button 
                  onClick={() => activeFriend && loadMessages(activeFriend.uid)} 
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white transition-colors"
                >
                  <RefreshCw className={`w-4 h-4 ${loadingMessages ? 'animate-spin text-[#B66DFF]' : ''}`} />
                </button>
                <button 
                  onClick={() => setShowMenu(!showMenu)} 
                  className="p-2 rounded-lg hover:bg-white/5 text-white transition-colors"
                >
                  <MoreVertical className="w-5 h-5" />
                </button>
                
                {showMenu && (
                  <div className="absolute top-full right-0 mt-2 w-48 bg-[#0C0C0C] border border-neutral-800 rounded-xl shadow-2xl py-2 z-50">
                    <button onClick={() => { setShowMenu(false); blockUser(); }} className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/5 text-left text-sm text-white font-bold">
                      <Ban className="w-4 h-4 text-red-500" /> Block User
                    </button>
                    <button onClick={() => { setShowMenu(false); reportUser(); }} className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/5 text-left text-sm text-white font-bold">
                      <ShieldAlert className="w-4 h-4 text-orange-500" /> Report User
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-4 flex flex-col gap-3.5">
              {loadingMessages ? (
                <div className="flex-1 flex items-center justify-center">
                  <Loader2 className="w-8 h-8 text-[#14F1E1] animate-spin" />
                </div>
              ) : messages.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center opacity-50">
                  <MessageCircle className="w-12 h-12 text-brand-muted mb-3" />
                  <p className="text-[10px] font-black uppercase tracking-widest text-brand-muted">No messages yet</p>
                  <p className="text-[9px] font-bold text-zinc-500 mt-1 max-w-[200px] text-center">Start a conversation!</p>
                </div>
              ) : (
                <>
                  <div className="text-center mb-1">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-brand-muted bg-white/5 px-3 py-1 rounded-full">
                      Messages are NOT end-to-end encrypted
                    </span>
                  </div>

                  {messages.map((msg) => {
                    const isMe = msg.senderId === currentUserId;
                    const timeString = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    const detectedEx = detectExerciseInText(msg.text);
                    
                    return (
                      <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                          <div 
                            className={`max-w-[88%] sm:max-w-[78%] p-3.5 rounded-2xl ${
                              isMe 
                                ? 'bg-gradient-to-r from-[#14F1E1] to-[#0DE2D3] text-[#050B1A] font-bold rounded-tr-sm shadow-md' 
                                : 'bg-[#101935] border border-[#14F1E1]/20 text-zinc-100 rounded-tl-sm'
                            }`}
                          >
                            <p className="text-sm font-semibold whitespace-pre-wrap break-words">{msg.text}</p>
                            {detectedEx && (
                              <div className="mt-3 rounded-xl overflow-hidden border border-[#14F1E1]/40 bg-[#050B1A]">
                                <div className="px-3 py-1.5 bg-[#0A1128] border-b border-[#14F1E1]/20 flex items-center justify-between">
                                  <span className="text-[9px] font-black uppercase tracking-widest text-[#14F1E1]">
                                    ⚡ 3D Hologram Form: {detectedEx.name}
                                  </span>
                                  <span className="text-[8px] font-bold uppercase tracking-widest text-[#B66DFF]">
                                    Interactive 360°
                                  </span>
                                </div>
                                <Exercise3DCharacterLoop
                                  exerciseName={detectedEx.name}
                                  targetMuscles={detectedEx.muscles}
                                  compact={true}
                                  showControls={true}
                                />
                              </div>
                            )}
                          </div>

                        <span className="text-[9px] font-bold uppercase tracking-widest text-zinc-500 mt-1 mx-1">
                          {timeString}
                        </span>
                      </div>
                    );
                  })}
                  <div ref={messagesEndRef} className="h-1" />
                </>
              )}
            </div>

            {/* Quick Fitness Prompts Bar when chatting with FitGenie AI Coach */}
            {activeFriend?.isAi && (
              <div className="px-3 py-2 bg-[#080F24] border-t border-[#1A2642] flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
                {SUGGESTED_FITNESS_ACTIONS.map((action, idx) => (
                  <button
                    key={idx}
                    onClick={() => sendMessage(action.query)}
                    disabled={sending}
                    className="px-3 py-1.5 rounded-full bg-[#111A3A] hover:bg-[#14F1E1]/20 border border-[#14F1E1]/30 text-[10px] font-black uppercase tracking-wider text-[#14F1E1] whitespace-nowrap transition-all shrink-0 cursor-pointer"
                  >
                    {action.label}
                  </button>
                ))}
              </div>
            )}

            {/* Message Input Bar */}
            <div className="p-3 border-t border-[#1A2642] bg-[#0A1128] shrink-0">
              <div className="flex gap-2 items-end">
                <textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value.slice(0, 500))}
                  placeholder={
                    activeFriend?.isAi 
                      ? "Ask FitGenie about exercises, diet, protein, recovery..." 
                      : "Type a message..."
                  }
                  className="flex-1 bg-[#111A3A] border border-[#1A2642] text-white rounded-2xl p-3 text-sm focus:outline-none focus:border-[#14F1E1]/60 transition-colors resize-none max-h-32 min-h-[44px] placeholder:text-neutral-500"
                  rows={1}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                />
                <button
                  onClick={() => sendMessage()}
                  disabled={!inputText.trim() || sending}
                  className={`p-3 rounded-xl flex items-center justify-center transition-all ${
                    !inputText.trim() || sending 
                      ? 'bg-[#111A3A] text-zinc-500 cursor-not-allowed' 
                      : activeFriend?.isAi
                        ? 'bg-[#14F1E1] text-[#050B1A] hover:bg-[#0DE2D3] active:scale-95 shadow-[0_0_15px_rgba(20,241,225,0.4)]'
                        : 'bg-[#B66DFF] text-white hover:bg-[#A352FF] active:scale-95 shadow-[0_0_15px_rgba(182,109,255,0.4)]'
                  }`}
                >
                  {sending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                </button>
              </div>
              <div className="flex justify-between items-center mt-1 px-1">
                <span className="text-[9px] font-bold text-neutral-500">
                  {activeFriend?.isAi ? "⚡ AI Fitness Coach" : "🔒 Direct Message"}
                </span>
                <span className={`text-[9px] font-bold uppercase tracking-widest ${inputText.length >= 490 ? 'text-red-400' : 'text-zinc-600'}`}>
                  {inputText.length}/500
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Cyberpunk Toast Banner */}
      <AnimatePresence>
        {toastNotice && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[120] px-4 py-2.5 rounded-xl bg-[#0A1128] border border-[#14F1E1] text-[#14F1E1] text-xs font-black uppercase tracking-widest shadow-[0_0_25px_rgba(20,241,225,0.3)]"
          >
            {toastNotice}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Custom Block Confirmation Modal */}
      {confirmBlockOpen && activeFriend && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[130] flex items-center justify-center p-4">
          <div className="bg-[#0A1128] border border-red-500/40 rounded-2xl w-full max-w-sm p-5 space-y-4 shadow-2xl">
            <div className="flex items-center gap-2 text-red-400">
              <Ban className="w-5 h-5" />
              <h3 className="text-sm font-black uppercase tracking-widest">Block {activeFriend.userName}?</h3>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              This athlete will be removed from your mutual squad list and blocked from sending direct messages.
            </p>
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setConfirmBlockOpen(false)}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-black uppercase tracking-widest text-zinc-300"
              >
                Cancel
              </button>
              <button
                onClick={confirmBlockExecution}
                className="px-4 py-2 rounded-xl bg-red-500 hover:bg-red-600 text-xs font-black uppercase tracking-widest text-white"
              >
                Confirm Block
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Report Modal */}
      {reportModalOpen && activeFriend && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[130] flex items-center justify-center p-4">
          <div className="bg-[#0A1128] border border-orange-500/40 rounded-2xl w-full max-w-sm p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-orange-400">
                <ShieldAlert className="w-5 h-5" />
                <h3 className="text-sm font-black uppercase tracking-widest">Report {activeFriend.userName}</h3>
              </div>
              <button onClick={() => setReportModalOpen(false)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <textarea
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              placeholder="Describe the issue or violation..."
              className="w-full bg-[#050B1A] border border-[#1A2642] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-orange-500/60 h-24 resize-none"
            />
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setReportModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-black uppercase tracking-widest text-zinc-300"
              >
                Cancel
              </button>
              <button
                onClick={submitReportExecution}
                disabled={!reportReason.trim()}
                className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:opacity-40 text-xs font-black uppercase tracking-widest text-black"
              >
                Submit Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
