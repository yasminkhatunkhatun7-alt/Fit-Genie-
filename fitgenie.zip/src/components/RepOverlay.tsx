import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface RepOverlayProps {
  reps: number;
}

export function RepOverlay({ reps }: RepOverlayProps) {
  const [increments, setIncrements] = useState<{ id: number; val: number }[]>([]);

  useEffect(() => {
    if (reps > 0) {
      const id = Date.now();
      setIncrements((prev) => [...prev, { id, val: reps }]);
      setTimeout(() => {
        setIncrements((prev) => prev.filter((inc) => inc.id !== id));
      }, 1000);
    }
  }, [reps]);

  return (
    <div className="absolute top-12 left-0 right-0 flex justify-center pointer-events-none z-50">
      <div className="relative">
        <motion.div
          key={reps}
          initial={{ scale: 1.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 15 }}
          className="relative z-10 flex flex-col items-center"
        >
          <div className="text-[120px] font-black leading-none text-transparent bg-clip-text bg-gradient-to-b from-[#14F1E1] to-[#4DA8FF] drop-shadow-[0_0_30px_rgba(20,241,225,0.8)] font-mono">
            {reps}
          </div>
          <div className="text-center text-[#14F1E1] text-lg font-bold tracking-widest uppercase mt-[-10px] drop-shadow-[0_0_10px_rgba(20,241,225,1)]">
            REPS
          </div>
        </motion.div>

        {/* Ripple effect on change */}
        <AnimatePresence>
          {increments.map((inc) => (
            <React.Fragment key={`ripple-${inc.id}`}>
              {/* Expanding Ring */}
              <motion.div
                initial={{ scale: 0.8, opacity: 0.8 }}
                animate={{ scale: 2.5, opacity: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full border-4 border-[#14F1E1]"
              />
              
              {/* Floating +1 */}
              <motion.div
                initial={{ y: 0, opacity: 1, scale: 0.5, x: '-50%' }}
                animate={{ y: -100, opacity: 0, scale: 1.5, x: '-50%' }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="absolute top-0 left-1/2 text-4xl font-black text-white drop-shadow-[0_0_15px_rgba(20,241,225,1)]"
              >
                +1
              </motion.div>
            </React.Fragment>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
