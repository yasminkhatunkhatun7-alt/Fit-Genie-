import React, { useRef, useState, useEffect, useCallback } from "react";
import { RepOverlay } from "./RepOverlay";
import { X, Play, Square, RotateCcw, Save, Camera, CameraOff, AlertCircle, Volume2, VolumeX, AlertTriangle, CheckCircle2, Ghost, Trophy, Mic, Swords, Share2, Copy, Check, Activity, Target, Sliders, Sparkles, ShieldCheck, CheckCheck } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import { useAuth } from "../context/AuthContext";
import { useGhostChallenge } from "../hooks/useGhostChallenge";
import { enqueueOfflineAction } from "../hooks/useCachedProfile";
import { 
  speakGenie, 
  stopGenieSpeech, 
  isVoiceCoachEnabled, 
  setVoiceCoachEnabled, 
  subscribeToSpeakingState,
  getWorkoutStartLine, 
  getMidWorkoutMotivation, 
  getIdleWarning, 
  getWorkoutCompleteLine,
  isVoiceRecognitionSupported,
  startHandsFreeCommandListener,
  VoiceCommandAction
} from "../utils/voiceCoach";
import { checkForm, FormVoiceCooldown, FormFeedback } from "../utils/formCorrectionEngine";
import {
  recordGhostFrame,
  saveGhostRace,
  loadGhostRace,
  getInterpolatedGhostFrame,
  drawGhostSkeleton,
  exportGhostDuelCode,
  importGhostDuelCode,
  GhostWorkoutRace,
  GhostJointData
} from "../utils/ghostRaceEngine";
import * as mpPose from "@mediapipe/pose";
import { playSound } from "../utils/audio";
import {
  createInitialRepTrackerState,
  evaluatePoseFrame,
  calculateRomThresholds,
  type RepTrackerState,
  type DiagnosticTelemetry,
  type TrackingSensitivity,
  type RomCalibration,
} from "../workers/poseWorker";
import FlexCardModal from "./FlexCardModal";

interface AiRepCounterProps {
  initialExercise?: "Pushups" | "Squats";
  onClose: () => void;
  onComplete?: (reps: number) => void;
  challengeTarget?: { userId: string; userName: string; score: number };
}

// Major POSE landmark pairs for rendering skeleton connectors
const SKELETON_CONNECTIONS: [number, number][] = [
  // Upper body
  [11, 12], // shoulder to shoulder
  [11, 13], // left shoulder to left elbow
  [13, 15], // left elbow to left wrist
  [12, 14], // right shoulder to right elbow
  [14, 16], // right elbow to right wrist
  // Torso
  [11, 23], // left shoulder to left hip
  [12, 24], // right shoulder to right hip
  [23, 24], // hip to hip
  // Lower body
  [23, 25], // left hip to left knee
  [25, 27], // left knee to left ankle
  [24, 26], // right hip to right knee
  [26, 28]  // right knee to right ankle
];

export function AiRepCounter({ initialExercise = "Pushups", onClose, onComplete, challengeTarget }: AiRepCounterProps) {
  const { profile, updateUserProfileFields } = useAuth();
  const { processChallengeResult } = useGhostChallenge(profile);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const poseInstanceRef = useRef<any | null>(null);
  const poseBusyRef = useRef<boolean>(false);
  const lastFrameSentTimeRef = useRef<number>(0);
  const repTrackerRef = useRef<RepTrackerState>(createInitialRepTrackerState());
  const animationFrameRef = useRef<number | null>(null);
  const wasActiveBeforeHideRef = useRef<boolean>(false);
  const latestLandmarksRef = useRef<any[] | null>(null);

  const [exercise, setExercise] = useState<"Pushups" | "Squats">(initialExercise);
  const [cameraAccess, setCameraAccess] = useState<boolean | null>(null);
  const [modelLoading, setModelLoading] = useState(true);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<"free" | "test">(challengeTarget ? "test" : "free");
  const [testTimeLeft, setTestTimeLeft] = useState<number | null>(null);
  const [cheatAlert, setCheatAlert] = useState<string | null>(null);

  const [reps, setReps] = useState(0);
  const [state, setState] = useState<"up" | "down">("up");
  const [trackedAngle, setTrackedAngle] = useState<number>(170);
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");
  const [lowConfidence, setLowConfidence] = useState(false);
  const [showDiagnostic, setShowDiagnostic] = useState(true);
  const [sensitivity, setSensitivity] = useState<TrackingSensitivity>("standard");
  const [diagnosticData, setDiagnosticData] = useState<DiagnosticTelemetry | null>(null);

  const timerRef = useRef<number | null>(null);
  const sessionStartTimeRef = useRef<number | null>(null);

  // Voice Coach State and Triggers
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(() => isVoiceCoachEnabled());
  const [isGenieSpeaking, setIsGenieSpeaking] = useState<boolean>(false);
  const [genieSpokenText, setGenieSpokenText] = useState<string>("");

  // Real-Time Form Correction State & Cooldown Ref
  const [formStatus, setFormStatus] = useState<FormFeedback>({ isCorrect: true, feedback: "" });
  const [isFormFlashingRed, setIsFormFlashingRed] = useState<boolean>(false);
  const [isFormFlashingGreen, setIsFormFlashingGreen] = useState<boolean>(false);
  const formVoiceCooldownRef = useRef(new FormVoiceCooldown(4000));
  const greenFlashTimerRef = useRef<number | null>(null);
  const exerciseRef = useRef(exercise);

  // Module 4: 3D Skeleton Ghost Race State
  const recordedGhostFramesRef = useRef<GhostJointData[]>([]);
  const currentGhostFrameRef = useRef<GhostJointData | null>(null);
  const isGhostOverlayEnabledRef = useRef<boolean>(true);
  const [activeGhostRace, setActiveGhostRace] = useState<GhostWorkoutRace | null>(null);
  const [currentGhostFrame, setCurrentGhostFrame] = useState<GhostJointData | null>(null);
  const [isGhostOverlayEnabled, setIsGhostOverlayEnabled] = useState<boolean>(true);
  const [newPrSavedToast, setNewPrSavedToast] = useState<boolean>(false);

  // IDEA 1: HANDS-FREE VOICE COMMAND LISTENER ("Start", "Stop", "Reset", "Save")
  const [handsFreeMicOn, setHandsFreeMicOn] = useState<boolean>(false);
  const [lastVoiceCmdToast, setLastVoiceCmdToast] = useState<string | null>(null);
  const stopHandsFreeRef = useRef<(() => void) | null>(null);

  // IDEA 6 & IDEA 8: FLEX CARD & 1V1 BRO DUEL CODE MODAL STATE
  const [showFlexCardModal, setShowFlexCardModal] = useState<boolean>(false);
  const [showDuelModal, setShowDuelModal] = useState<boolean>(false);
  const [duelInputCode, setDuelInputCode] = useState<string>("");
  const [duelCopied, setDuelCopied] = useState<boolean>(false);
  const [duelStatusMsg, setDuelStatusMsg] = useState<string | null>(null);

  // ROM CALIBRATION (101% ACCURACY ENGINE)
  type CalibrationPhase = "idle" | "intro" | "top_hold" | "bottom_hold" | "completed";
  const [calibrationPhase, setCalibrationPhase] = useState<CalibrationPhase>("idle");
  const [calibratedRom, setCalibratedRom] = useState<RomCalibration | null>(null);
  const [calibrationCountdown, setCalibrationCountdown] = useState<number>(3);
  const [capturedTopAngle, setCapturedTopAngle] = useState<number | null>(null);
  const [capturedBottomAngle, setCapturedBottomAngle] = useState<number | null>(null);
  const [calibrationError, setCalibrationError] = useState<string | null>(null);

  const calibrationPhaseRef = useRef<CalibrationPhase>("idle");
  const holdSamplesRef = useRef<number[]>([]);
  const calibrationCountdownTimerRef = useRef<number | null>(null);
  const trackedAngleRef = useRef<number>(170);

  useEffect(() => {
    calibrationPhaseRef.current = calibrationPhase;
  }, [calibrationPhase]);

  useEffect(() => {
    trackedAngleRef.current = trackedAngle;
  }, [trackedAngle]);

  const loadSavedRom = useCallback((ex: "Pushups" | "Squats"): RomCalibration | null => {
    try {
      const saved = localStorage.getItem(`fitgenie_rom_calibration_${ex.toLowerCase()}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed.upAngle === "number" && typeof parsed.downAngle === "number") {
          return parsed as RomCalibration;
        }
      }
    } catch (e) {
      console.warn("Failed to load saved ROM calibration:", e);
    }
    return null;
  }, []);

  const shouldRunCamera = isActive || calibrationPhase !== "idle";

  const cancelCalibrationFlow = useCallback(() => {
    if (calibrationCountdownTimerRef.current) {
      clearInterval(calibrationCountdownTimerRef.current);
      calibrationCountdownTimerRef.current = null;
    }
    setCalibrationPhase("idle");
    setCalibrationError(null);
    holdSamplesRef.current = [];
  }, []);

  const startCalibrationFlow = useCallback(() => {
    if (isActive) setIsActive(false);
    setCalibrationError(null);
    setCapturedTopAngle(null);
    setCapturedBottomAngle(null);
    holdSamplesRef.current = [];
    setCalibrationPhase("intro");
    speakGenie("Let's calibrate your range of motion for 101% accurate counting. Get in position!");
  }, [isActive]);

  const finishBottomHoldStep = useCallback((topAngleVal: number) => {
    const samples = holdSamplesRef.current;
    let avgBottom = trackedAngleRef.current;
    if (samples.length >= 3) {
      const sorted = [...samples].sort((a, b) => a - b);
      avgBottom = Math.round(sorted[Math.floor(sorted.length / 2)]);
    } else {
      avgBottom = Math.round(trackedAngleRef.current);
    }

    const rom = topAngleVal - avgBottom;
    if (rom < 20) {
      setCalibrationError(`ROM too shallow (${Math.round(rom)}°). Need at least 20° difference between top lockout and bottom depth.`);
      speakGenie("Movement depth too shallow! Go deeper and try again.");
      setCalibrationPhase("intro");
      return;
    }

    setCapturedBottomAngle(avgBottom);
    const newCalibration = calculateRomThresholds(topAngleVal, avgBottom, exerciseRef.current);
    setCalibratedRom(newCalibration);
    repTrackerRef.current.customCalibration = newCalibration;
    try {
      localStorage.setItem(`fitgenie_rom_calibration_${exerciseRef.current.toLowerCase()}`, JSON.stringify(newCalibration));
    } catch (e) {
      console.warn("Error saving calibration:", e);
    }

    playSound("timer_complete");
    speakGenie(`101% calibrated! Range of motion: ${newCalibration.rom} degrees. Down trigger: ${newCalibration.downThreshold} degrees.`);
    setCalibrationPhase("completed");
  }, []);

  const finishTopHoldStep = useCallback(() => {
    const samples = holdSamplesRef.current;
    let avgTop = trackedAngleRef.current;
    if (samples.length >= 3) {
      const sorted = [...samples].sort((a, b) => a - b);
      avgTop = Math.round(sorted[Math.floor(sorted.length / 2)]);
    } else {
      avgTop = Math.round(trackedAngleRef.current);
    }

    if (avgTop < 120) {
      setCalibrationError(`Top angle too low (${avgTop}°). Fully extend arms/legs at the top.`);
      speakGenie("Lockout too low. Please straighten up and retry.");
      setCalibrationPhase("intro");
      return;
    }

    setCapturedTopAngle(avgTop);
    playSound("success");
    speakGenie(`Top position locked at ${avgTop} degrees! Now get ready for bottom depth.`);

    setTimeout(() => {
      setCalibrationPhase("bottom_hold");
      setCalibrationCountdown(3);
      holdSamplesRef.current = [];
      const bottomPrompt = exerciseRef.current === "Squats"
        ? "Now squat deep to parallel and hold!"
        : "Lower chest to bottom position and hold!";
      speakGenie(bottomPrompt);

      let bCount = 3;
      if (calibrationCountdownTimerRef.current) clearInterval(calibrationCountdownTimerRef.current);
      calibrationCountdownTimerRef.current = window.setInterval(() => {
        bCount -= 1;
        setCalibrationCountdown(bCount);
        if (bCount <= 0) {
          if (calibrationCountdownTimerRef.current) clearInterval(calibrationCountdownTimerRef.current);
          finishBottomHoldStep(avgTop);
        }
      }, 1000);
    }, 1200);
  }, [finishBottomHoldStep]);

  const startTopHoldStep = useCallback(() => {
    setCalibrationPhase("top_hold");
    setCalibrationError(null);
    setCalibrationCountdown(3);
    holdSamplesRef.current = [];

    const promptText = exerciseRef.current === "Squats"
      ? "Stand tall with legs straight and hold!"
      : "Hold top lockout plank with arms extended!";
    speakGenie(promptText);

    let count = 3;
    if (calibrationCountdownTimerRef.current) clearInterval(calibrationCountdownTimerRef.current);
    calibrationCountdownTimerRef.current = window.setInterval(() => {
      count -= 1;
      setCalibrationCountdown(count);
      if (count <= 0) {
        if (calibrationCountdownTimerRef.current) clearInterval(calibrationCountdownTimerRef.current);
        finishTopHoldStep();
      }
    }, 1000);
  }, [finishTopHoldStep]);

  const startWorkoutFromCalibration = useCallback(() => {
    setCalibrationPhase("idle");
    setReps(0);
    setState("up");
    setTrackedAngle(calibratedRom?.upAngle || 170);
    sessionStartTimeRef.current = Date.now();
    setIsActive(true);
  }, [calibratedRom]);

  useEffect(() => {
    if (!handsFreeMicOn) {
      if (stopHandsFreeRef.current) {
        stopHandsFreeRef.current();
        stopHandsFreeRef.current = null;
      }
      return;
    }

    const stopFn = startHandsFreeCommandListener((action: VoiceCommandAction, transcript: string) => {
      setLastVoiceCmdToast(`🎙️ "${transcript}" → ${action.toUpperCase()}`);
      setTimeout(() => setLastVoiceCmdToast(null), 3000);

      if (action === "start") {
        sessionStartTimeRef.current = Date.now();
        setIsActive(true);
      } else if (action === "stop") {
        setIsActive(false);
      } else if (action === "reset") {
        setReps(0);
        setState("up");
        setTrackedAngle(calibratedRom?.upAngle || 170);
        repTrackerRef.current = createInitialRepTrackerState(sensitivity, calibratedRom);
        speakGenie("Counter reset boss!");
      } else if (action === "squats") {
        setExercise("Squats");
        speakGenie("Switched to Squats!");
      } else if (action === "pushups") {
        setExercise("Pushups");
        speakGenie("Switched to Pushups!");
      } else if (action === "ghost") {
        setIsGhostOverlayEnabled((prev) => {
          const next = !prev;
          isGhostOverlayEnabledRef.current = next;
          return next;
        });
      }
    });

    stopHandsFreeRef.current = stopFn;
    return () => {
      stopFn();
    };
  }, [handsFreeMicOn, calibratedRom, sensitivity]);

  useEffect(() => {
    exerciseRef.current = exercise;
    formVoiceCooldownRef.current.reset();
    setFormStatus({ isCorrect: true, feedback: "" });
    setIsFormFlashingRed(false);
    setIsFormFlashingGreen(false);

    // Module 4: Load PR Ghost Race for this exercise
    const existingGhost = loadGhostRace(exercise);
    setActiveGhostRace(existingGhost);
    recordedGhostFramesRef.current = [];
    currentGhostFrameRef.current = null;
    setCurrentGhostFrame(null);
  }, [exercise]);

  const lastSpokenRepRef = useRef<number>(0);
  const lastRepTimeRef = useRef<number>(Date.now());
  const idleWarningIssuedRef = useRef<boolean>(false);
  const prevIsActiveRef = useRef<boolean>(false);

  // Subscribe to real-time voice speech feedback
  useEffect(() => {
    return subscribeToSpeakingState((speaking, text) => {
      setIsGenieSpeaking(speaking);
      setGenieSpokenText(text);
    });
  }, []);

  // 1. Workout Start Trigger
  useEffect(() => {
    if (isActive && !prevIsActiveRef.current) {
      sessionStartTimeRef.current = Date.now();
      recordedGhostFramesRef.current = [];
      currentGhostFrameRef.current = null;
      lastRepTimeRef.current = Date.now();
      idleWarningIssuedRef.current = false;
      lastSpokenRepRef.current = 0;
      speakGenie(getWorkoutStartLine());
    } else if (!isActive && prevIsActiveRef.current) {
      stopGenieSpeech();
    }
    prevIsActiveRef.current = isActive;
  }, [isActive]);

  // Module 4: 100ms Ghost Recorder & Playback Loop
  useEffect(() => {
    if (!isActive) {
      setCurrentGhostFrame(null);
      currentGhostFrameRef.current = null;
      return;
    }

    const interval = setInterval(() => {
      const elapsedMs = sessionStartTimeRef.current 
        ? Date.now() - sessionStartTimeRef.current 
        : 0;

      // 1. Record live biometric frame every 100ms
      const liveFrame = recordGhostFrame(latestLandmarksRef.current, reps, elapsedMs);
      if (liveFrame) {
        recordedGhostFramesRef.current.push(liveFrame);
      }

      // 2. Playback past PR ghost frame
      if (activeGhostRace) {
        const ghostFrame = getInterpolatedGhostFrame(activeGhostRace, elapsedMs);
        setCurrentGhostFrame(ghostFrame);
        currentGhostFrameRef.current = ghostFrame;
      }
    }, 100);

    return () => clearInterval(interval);
  }, [isActive, reps, activeGhostRace]);

  // 2. Mid-Workout Motivation: Every 5 Reps Trigger
  useEffect(() => {
    if (reps > 0) {
      lastRepTimeRef.current = Date.now();
      idleWarningIssuedRef.current = false;

      if (reps % 5 === 0 && reps !== lastSpokenRepRef.current) {
        lastSpokenRepRef.current = reps;
        speakGenie(getMidWorkoutMotivation(reps));
      }
    }
  }, [reps]);

  // 3. Idle Inactivity Warning (10 Seconds of Pause)
  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      if (isActive && !idleWarningIssuedRef.current) {
        const timeSinceLastRep = Date.now() - lastRepTimeRef.current;
        if (timeSinceLastRep >= 10000) {
          idleWarningIssuedRef.current = true;
          speakGenie(getIdleWarning());
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive]);

  // 1-minute countdown timer logic
  useEffect(() => {
    if (mode === "test" && isActive && testTimeLeft !== null && testTimeLeft > 0) {
      timerRef.current = window.setInterval(() => {
        setTestTimeLeft(prev => {
          if (prev && prev <= 1) {
            setIsActive(false);
            return 0;
          }
          return prev ? prev - 1 : 0;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, mode, testTimeLeft]);

  // Sync exercise and sensitivity change to rep tracker with saved ROM
  useEffect(() => {
    const savedRom = loadSavedRom(exercise);
    setCalibratedRom(savedRom);
    setReps(0);
    setState("up");
    setTrackedAngle(savedRom ? savedRom.upAngle : 170);
    latestLandmarksRef.current = null;
    repTrackerRef.current = createInitialRepTrackerState(sensitivity, savedRom);
  }, [exercise, sensitivity, loadSavedRom]);

  // 1. INITIALIZE MEDIAPIPE POSE ON MAIN THREAD (WHERE DOM & WEBGL CONTEXT EXIST)
  useEffect(() => {
    let isCancelled = false;

    const loadPoseConstructor = async (): Promise<any> => {
      const existing =
        (mpPose as any)?.Pose ||
        (mpPose as any)?.default?.Pose ||
        (window as any)?.Pose;
      if (existing) return existing;

      return new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = "https://cdn.jsdelivr.net/npm/@mediapipe/pose/pose.js";
        script.crossOrigin = "anonymous";
        script.onload = () => {
          if ((window as any)?.Pose) {
            resolve((window as any).Pose);
          } else {
            reject(new Error("window.Pose not found after loading script"));
          }
        };
        script.onerror = (e) => reject(e);
        document.head.appendChild(script);
      });
    };

    const initPoseEngine = async () => {
      try {
        const PoseConstructor = await loadPoseConstructor();
        if (isCancelled) return;

        const pose = new PoseConstructor({
          locateFile: (file: string) =>
            `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`,
        });

        pose.setOptions({
          modelComplexity: 1,
          smoothLandmarks: true,
          enableSegmentation: false,
          smoothSegmentation: false,
          minDetectionConfidence: 0.45,
          minTrackingConfidence: 0.45,
        });

        pose.onResults((results: any) => {
          if (isCancelled) return;
          poseBusyRef.current = false;

          const landmarks = results?.poseLandmarks || null;
          const evalRes = evaluatePoseFrame(
            landmarks,
            exerciseRef.current,
            repTrackerRef.current
          );

          setReps(evalRes.repCount);
          setState(evalRes.state);
          setTrackedAngle(evalRes.angle);
          setLowConfidence(evalRes.lowConfidence);
          setDiagnosticData(evalRes.diagnostic);

          // Collect angle samples during active calibration holds
          if (
            (calibrationPhaseRef.current === "top_hold" ||
              calibrationPhaseRef.current === "bottom_hold") &&
            !evalRes.lowConfidence &&
            evalRes.angle > 0
          ) {
            holdSamplesRef.current.push(evalRes.angle);
          }

          if (evalRes.repJustCompleted) {
            playSound("success");
            setIsFormFlashingRed(false);
            setIsFormFlashingGreen(true);
            if (greenFlashTimerRef.current)
              clearTimeout(greenFlashTimerRef.current);
            greenFlashTimerRef.current = window.setTimeout(() => {
              setIsFormFlashingGreen(false);
            }, 1100);
          }

          if (landmarks && landmarks.length > 0) {
            latestLandmarksRef.current = landmarks;

            // Real-Time Biomechanical Form Analysis
            const formResult = checkForm(
              exerciseRef.current,
              landmarks,
              evalRes.state
            );
            setFormStatus({
              ...formResult,
              kneeAngle:
                exerciseRef.current === "Squats"
                  ? evalRes.angle
                  : formResult.kneeAngle,
              elbowAngle:
                exerciseRef.current === "Pushups"
                  ? evalRes.angle
                  : formResult.elbowAngle,
            });

            if (!formResult.isCorrect && formResult.errorType) {
              setIsFormFlashingRed(true);
              setIsFormFlashingGreen(false);
              if (greenFlashTimerRef.current)
                clearTimeout(greenFlashTimerRef.current);

              if (formVoiceCooldownRef.current.canSpeak(formResult.errorType)) {
                speakGenie(formResult.feedback);
              }
            } else {
              setIsFormFlashingRed(false);
            }
          } else {
            latestLandmarksRef.current = null;
            setIsFormFlashingRed(false);
          }
        });

        poseInstanceRef.current = pose;
        setModelLoading(false);
      } catch (err) {
        console.error("Failed to initialize MediaPipe Pose:", err);
        setModelLoading(false);
      }
    };

    initPoseEngine();

    // 3. CAMERA & POSE CLEANUP ON UNMOUNT
    return () => {
      isCancelled = true;
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
      if (poseInstanceRef.current) {
        try {
          poseInstanceRef.current.close();
        } catch (e) {
          console.warn("Error closing pose instance:", e);
        }
        poseInstanceRef.current = null;
      }
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => {
          try {
            track.stop();
          } catch (e) {
            console.warn("Error stopping camera track:", e);
          }
        });
        streamRef.current = null;
      }
    };
  }, []);

  // 2. BACKGROUND TAB HANDLING (Battery Save)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        if (isActive) {
          wasActiveBeforeHideRef.current = true;
          setIsActive(false);

          if (streamRef.current) {
            streamRef.current.getVideoTracks().forEach((track) => {
              track.enabled = false;
            });
          }
          if (videoRef.current) {
            videoRef.current.pause();
          }
        }
      } else {
        if (wasActiveBeforeHideRef.current) {
          wasActiveBeforeHideRef.current = false;

          if (streamRef.current) {
            streamRef.current.getVideoTracks().forEach((track) => {
              track.enabled = true;
            });
          }
          if (videoRef.current) {
            videoRef.current.play().catch(console.warn);
          }
          setIsActive(true);
        }
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [isActive]);

  // CAMERA INITIALIZATION AND STREAM LIFECYCLE
  useEffect(() => {
    if (!shouldRunCamera) {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => {
          try {
            track.stop();
          } catch (e) {
            console.warn("Error stopping camera track:", e);
          }
        });
        streamRef.current = null;
      }
      return;
    }

    let isSubscribed = true;

    const startCamera = async () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode,
            width: { ideal: 640 },
            height: { ideal: 480 },
          },
          audio: false,
        });

        if (!isSubscribed) {
          stream.getTracks().forEach((track) => track.stop());
          return;
        }

        streamRef.current = stream;
        setCameraAccess(true);

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
      } catch (err) {
        if (!isSubscribed) return;
        console.warn("Camera access denied or unavailable:", err);
        setCameraAccess(false);
        setIsActive(false);
      }
    };

    startCamera();

    return () => {
      isSubscribed = false;
    };
  }, [shouldRunCamera, facingMode]);

  // SKELETON DRAWING HELPER
  const drawOverlayAndSkeleton = useCallback(() => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video || video.readyState < 2) return;

    if (
      canvas.width !== video.videoWidth ||
      canvas.height !== video.videoHeight
    ) {
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
    }

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.save();
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw live video feed
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Module 4: Render Ghost Skeleton (if enabled and playing)
    if (isGhostOverlayEnabledRef.current && currentGhostFrameRef.current) {
      drawGhostSkeleton(
        ctx,
        canvas.width,
        canvas.height,
        currentGhostFrameRef.current
      );
    }

    // Render skeleton if landmarks exist
    const landmarks = latestLandmarksRef.current;
    if (landmarks && landmarks.length > 0) {
      // 1. Draw connections
      ctx.lineWidth = 4;
      ctx.strokeStyle = state === "down" ? "#10B981" : "#14F1E1";
      ctx.lineCap = "round";

      for (const [startIdx, endIdx] of SKELETON_CONNECTIONS) {
        const startPoint = landmarks[startIdx];
        const endPoint = landmarks[endIdx];

        if (
          startPoint &&
          endPoint &&
          (startPoint.visibility ?? 1) > 0.25 &&
          (endPoint.visibility ?? 1) > 0.25
        ) {
          ctx.beginPath();
          ctx.moveTo(startPoint.x * canvas.width, startPoint.y * canvas.height);
          ctx.lineTo(endPoint.x * canvas.width, endPoint.y * canvas.height);
          ctx.stroke();
        }
      }

      // 2. Draw landmark joints with confidence-based color and diagnostic indices
      const keyLandmarks: Record<number, string> = {
        11: "L-Shld",
        12: "R-Shld",
        13: "L-Elb",
        14: "R-Elb",
        15: "L-Wrst",
        16: "R-Wrst",
        23: "L-Hip",
        24: "R-Hip",
        25: "L-Knee",
        26: "R-Knee",
        27: "L-Ank",
        28: "R-Ank",
      };

      for (let i = 0; i < landmarks.length; i++) {
        const pt = landmarks[i];
        if (pt && (pt.visibility ?? 1) > 0.25) {
          const px = pt.x * canvas.width;
          const py = pt.y * canvas.height;
          const isKeyJoint = !!keyLandmarks[i];
          const radius = isKeyJoint ? 5.5 : 3.5;

          ctx.beginPath();
          ctx.arc(px, py, radius, 0, 2 * Math.PI);
          const jointColor = state === "down" ? "#10B981" : isKeyJoint ? "#FFE600" : "#B66DFF";
          ctx.fillStyle = jointColor;
          ctx.shadowColor = jointColor;
          ctx.shadowBlur = 8;
          ctx.fill();

          // Diagnostic text on key joints if diagnostic overlay is enabled
          if (showDiagnostic && isKeyJoint) {
            ctx.shadowBlur = 0;
            ctx.font = "bold 9px monospace";
            ctx.fillStyle = "#000000";
            ctx.fillRect(px + 6, py - 10, 36, 12);
            ctx.fillStyle = jointColor;
            ctx.fillText(keyLandmarks[i], px + 8, py - 1);
          }
        }
      }
    }

    ctx.restore();
  }, [state, showDiagnostic]);

  // FRAME CAPTURE & POSE DETECTION LOOP
  useEffect(() => {
    if (!shouldRunCamera) {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
      return;
    }

    let isLoopRunning = true;

    const processFrame = async () => {
      if (!isLoopRunning || !shouldRunCamera) return;

      const video = videoRef.current;
      if (video && video.readyState >= 2 && video.videoWidth > 0) {
        // Always draw smooth 60fps video + skeleton overlay onto canvas
        drawOverlayAndSkeleton();

        // Send frame to MediaPipe Pose at ~20 FPS if not currently processing a frame
        const now = performance.now();
        if (
          poseInstanceRef.current &&
          !poseBusyRef.current &&
          now - lastFrameSentTimeRef.current >= 48
        ) {
          poseBusyRef.current = true;
          lastFrameSentTimeRef.current = now;
          try {
            await poseInstanceRef.current.send({ image: video });
          } catch (err) {
            poseBusyRef.current = false;
          }
        }
      }

      if (isLoopRunning && shouldRunCamera) {
        animationFrameRef.current = requestAnimationFrame(processFrame);
      }
    };

    animationFrameRef.current = requestAnimationFrame(processFrame);

    return () => {
      isLoopRunning = false;
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
    };
  }, [shouldRunCamera, drawOverlayAndSkeleton]);

  // LOG / SCORE SUBMISSION (SERVER ANTI-CHEAT PROTECTED)
  const handleSaveToLog = async () => {
    if (reps === 0) return;

    if (updateUserProfileFields && profile) {
      const timeElapsed = sessionStartTimeRef.current
        ? Math.max(1, (Date.now() - sessionStartTimeRef.current) / 1000)
        : (mode === "test" ? Math.max(1, 60 - (testTimeLeft || 0)) : Math.max(1, reps * 1.5));

      const scorePayload = {
        userId: profile.uid,
        exerciseName: exercise,
        reps,
        timeElapsed,
        mode,
        userName: profile.username || profile.name || "Athlete"
      };

      if (!navigator.onLine) {
        console.log("[Offline Mode] Enqueuing score submission to LocalStorage.");
        enqueueOfflineAction({
          type: "SUBMIT_SCORE",
          payload: scorePayload
        });
      } else {
        try {
          const response = await fetch("/api/submit-score", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(scorePayload)
          });

          const data = await response.json();

          if (!response.ok) {
            console.warn("[Anti-Cheat Server Rejection]:", data.error);
            setCheatAlert(data.error || "Cheat detected: Rep completion speed exceeds biomechanical limits.");
            return;
          }

          setCheatAlert(null);
        } catch (err) {
          console.warn("[Score Submission Network Offline Note]:", err);
          enqueueOfflineAction({
            type: "SUBMIT_SCORE",
            payload: scorePayload
          });
        }
      }

      const updates: any = {};
      let xpEarned = 0;
      if (mode === "test") {
        xpEarned = 150;
      }

      if (challengeTarget && mode === "test") {
        if (reps > challengeTarget.score) {
          xpEarned += 350;
        }
        await processChallengeResult(challengeTarget as any, reps);
      }

      if (xpEarned > 0) {
        updates.xp = (profile.xp || 0) + xpEarned;
      }

      const currentStats = profile.stats || {};
      const newStats = { ...currentStats };
      let shouldUpdateStats = false;

      if (exercise === "Squats") {
        updates.totalSquats = (profile.totalSquats || 0) + reps;
        if (mode === "test" && reps > (profile.bestSquat1Min || 0)) {
          updates.bestSquat1Min = reps;
        }
        if (reps > (newStats.squats_all || 0)) {
          newStats.squats_all = reps;
          shouldUpdateStats = true;
        }
        if (mode === "test" && reps > (newStats.squats_1min || 0)) {
          newStats.squats_1min = reps;
          shouldUpdateStats = true;
        }
      } else {
        updates.totalPushups = (profile.totalPushups || 0) + reps;
        if (mode === "test" && reps > (profile.bestPushup1Min || 0)) {
          updates.bestPushup1Min = reps;
        }
        if (reps > (newStats.pushups_all || 0)) {
          newStats.pushups_all = reps;
          shouldUpdateStats = true;
        }
        if (mode === "test" && reps > (newStats.pushups_1min || 0)) {
          newStats.pushups_1min = reps;
          shouldUpdateStats = true;
        }
      }

      if (shouldUpdateStats) {
        updates.stats = newStats;
      }

      // Module 4: Save Ghost Race recording if user finished reps and beat PR (or first recorded run)
      if (reps > 0 && recordedGhostFramesRef.current.length > 5) {
        const totalDurationMs = sessionStartTimeRef.current
          ? Date.now() - sessionStartTimeRef.current
          : reps * 1500;
        
        const previousPr = activeGhostRace ? activeGhostRace.prReps : 0;
        if (reps > previousPr) {
          saveGhostRace(exercise, reps, totalDurationMs, recordedGhostFramesRef.current);
          const newRace = loadGhostRace(exercise);
          setActiveGhostRace(newRace);
          setNewPrSavedToast(true);
          setTimeout(() => setNewPrSavedToast(false), 5000);
        }
      }

      await updateUserProfileFields(updates).catch(console.error);
    }
  };

  const handleManualSave = async () => {
    speakGenie(getWorkoutCompleteLine(reps));
    await handleSaveToLog();
    if (onComplete) {
      onComplete(reps);
    }
  };

  useEffect(() => {
    if (mode === "test" && testTimeLeft === 0) {
      speakGenie(getWorkoutCompleteLine(reps));
      handleSaveToLog();
      const t = setTimeout(() => {
        if (onComplete) onComplete(reps);
        else if (onClose) onClose();
      }, 5000);
      return () => clearTimeout(t);
    }
  }, [testTimeLeft, mode]);

  return (
    <div className="fixed inset-0 bg-[#050B1A] z-50 flex flex-col font-sans">
      {/* Top Header */}
      <div className="flex items-center justify-between p-4 bg-[#0D1328] border-b border-[#14F1E1]/20">
        <div>
          <h2 className="text-xl font-black uppercase tracking-widest text-white">AI REP COUNTER</h2>
          <p className="text-[10px] text-[#14F1E1] font-bold uppercase tracking-widest flex items-center gap-1 mt-0.5">
            <span className="w-2 h-2 rounded-full bg-[#14F1E1] animate-pulse" /> Live Pose & Form Tracker
          </p>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* IDEA 1: Hands-Free Voice Command Mic Toggle */}
          {isVoiceRecognitionSupported() && (
            <button
              onClick={() => {
                const next = !handsFreeMicOn;
                setHandsFreeMicOn(next);
                if (next) {
                  speakGenie("Hands free voice commands active! Say Start, Pause, Reset, or Squats.");
                }
              }}
              className={`p-2 px-2.5 rounded-xl transition-all flex items-center gap-1 text-xs font-bold font-mono uppercase tracking-wider border cursor-pointer ${
                handsFreeMicOn
                  ? "bg-emerald-500/20 border-emerald-400 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.35)]"
                  : "bg-white/5 border-white/10 text-neutral-400 hover:text-white"
              }`}
              title="Hands-Free Voice Commands (Say 'Start', 'Stop', 'Reset')"
            >
              <Mic className={`w-4 h-4 ${handsFreeMicOn ? "text-emerald-400 animate-pulse" : "text-neutral-400"}`} />
              <span className="hidden md:inline">{handsFreeMicOn ? "Mic ON" : "Voice Cmd"}</span>
            </button>
          )}

          {/* ROM Calibration Status / Recalibrate Button */}
          <button
            onClick={startCalibrationFlow}
            className={`p-2 px-2.5 rounded-xl transition-all flex items-center gap-1.5 text-xs font-bold font-mono uppercase tracking-wider border cursor-pointer ${
              calibratedRom
                ? "bg-emerald-500/15 border-emerald-400/60 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.3)] hover:bg-emerald-500/25"
                : "bg-amber-500/20 border-amber-400 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.3)] hover:bg-amber-500/30 animate-pulse"
            }`}
            title={calibratedRom ? `101% ROM Calibrated (${calibratedRom.rom}°) - Click to Recalibrate` : "Calibrate Range of Motion (101% Rep Accuracy)"}
          >
            {calibratedRom ? (
              <ShieldCheck className="w-4 h-4 text-emerald-400 animate-pulse" />
            ) : (
              <Target className="w-4 h-4 text-amber-400" />
            )}
            <span className="hidden sm:inline">
              {calibratedRom ? `101% ROM (${calibratedRom.rom}°)` : "Calibrate ROM"}
            </span>
          </button>

          {/* Diagnostic Visualizer Toggle Button */}
          <button
            onClick={() => setShowDiagnostic((prev) => !prev)}
            className={`p-2 px-2.5 rounded-xl transition-all flex items-center gap-1.5 text-xs font-bold font-mono uppercase tracking-wider border cursor-pointer ${
              showDiagnostic
                ? "bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.35)]"
                : "bg-white/5 border-white/10 text-neutral-400 hover:text-white"
            }`}
            title="Toggle Live Skeleton & Telemetry Diagnostic Overlay"
          >
            <Activity className={`w-4 h-4 ${showDiagnostic ? "text-cyan-400 animate-pulse" : "text-neutral-400"}`} />
            <span className="hidden sm:inline">Diagnostic {showDiagnostic ? "ON" : "OFF"}</span>
          </button>

          {/* IDEA 8: 1v1 Bro Ghost Duel Code Modal Button */}
          <button
            onClick={() => setShowDuelModal(true)}
            className="p-2 px-2.5 rounded-xl transition-all flex items-center gap-1 text-xs font-bold font-mono uppercase tracking-wider border bg-[#B66DFF]/15 border-[#B66DFF]/50 text-[#B66DFF] hover:bg-[#B66DFF]/25 cursor-pointer"
            title="1v1 Gym Bro Ghost Duel Code"
          >
            <Swords className="w-4 h-4 text-[#B66DFF]" />
            <span className="hidden md:inline">1v1 Duel</span>
          </button>

          {/* Ghost Race Hologram Toggle Button */}
          <button
            onClick={() => {
              const nextState = !isGhostOverlayEnabled;
              setIsGhostOverlayEnabled(nextState);
              isGhostOverlayEnabledRef.current = nextState;
            }}
            className={`p-2 px-3 rounded-xl transition-all flex items-center gap-1.5 text-xs font-bold font-mono uppercase tracking-wider border ${
              isGhostOverlayEnabled
                ? "bg-[#FFE600]/15 border-[#FFE600]/50 text-[#FFE600] shadow-[0_0_12px_rgba(255,230,0,0.25)]"
                : "bg-white/5 border-white/10 text-neutral-400 hover:text-white"
            }`}
            title={isGhostOverlayEnabled ? "Hide Ghost Hologram" : "Show Ghost Hologram"}
          >
            <Ghost className={`w-4 h-4 ${isGhostOverlayEnabled ? "text-[#FFE600] animate-pulse" : "text-neutral-400"}`} />
            <span className="hidden sm:inline">Ghost {isGhostOverlayEnabled ? "ON" : "OFF"}</span>
          </button>

          {/* Voice Coach Toggle Button (Speaker Icon) */}
          <button
            onClick={() => {
              const nextState = !voiceEnabled;
              setVoiceEnabled(nextState);
              setVoiceCoachEnabled(nextState);
              if (nextState) {
                speakGenie("Genie Voice Coach active! Push your limits today warrior!");
              } else {
                stopGenieSpeech();
              }
            }}
            className={`p-2 px-3 rounded-xl transition-all flex items-center gap-1.5 text-xs font-bold font-mono uppercase tracking-wider border ${
              voiceEnabled
                ? "bg-[#14F1E1]/15 border-[#14F1E1]/50 text-[#14F1E1] shadow-[0_0_12px_rgba(20,241,225,0.25)]"
                : "bg-white/5 border-white/10 text-neutral-400 hover:text-white"
            }`}
            title={voiceEnabled ? "Mute Voice Coach" : "Unmute Voice Coach"}
          >
            {voiceEnabled ? (
              <>
                <Volume2 className="w-4 h-4 text-[#14F1E1] animate-pulse" />
                <span className="hidden sm:inline">Voice ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-neutral-400" />
                <span className="hidden sm:inline">Muted</span>
              </>
            )}
          </button>

          <button onClick={onClose} className="p-2 bg-white/5 rounded-xl text-white hover:bg-white/10 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {lastVoiceCmdToast && (
        <div className="bg-emerald-500/20 border-b border-emerald-500/50 px-4 py-2 flex items-center justify-center gap-2 text-emerald-300 text-xs font-mono font-bold z-20">
          <Mic className="w-3.5 h-3.5 text-emerald-400 animate-ping" />
          <span>{lastVoiceCmdToast}</span>
        </div>
      )}

      {cheatAlert && (
        <div className="bg-red-500/20 border-b border-red-500/50 px-4 py-2.5 flex items-center gap-2 text-red-400 text-xs font-bold animate-pulse z-20">
          <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
          <span>{cheatAlert}</span>
        </div>
      )}

      <div className="flex-1 relative overflow-hidden bg-black flex flex-col">
        {/* Main View Area */}
        <div className="relative flex-1 bg-black">
          {/* Always-mounted hidden video element so stream attaches without race conditions */}
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="hidden"
          />
          {cameraAccess === false ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
              <CameraOff className="w-16 h-16 text-red-500 mb-4" />
              <p className="text-white font-bold text-lg">Camera access chahiye rep count karne ke liye bhai!</p>
              <p className="text-[#9CA3AF] text-sm mt-2 max-w-sm">
                Please enable camera permissions in your browser or device settings and reload the app.
              </p>
            </div>
          ) : modelLoading ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <div className="w-12 h-12 border-4 border-[#14F1E1]/30 border-t-[#14F1E1] rounded-full animate-spin mb-4" />
              <p className="text-[#14F1E1] font-bold tracking-widest">Loading AI Pose Tracker...</p>
            </div>
          ) : !shouldRunCamera ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6">
              <Camera className="w-16 h-16 text-[#14F1E1]/50 mb-4" />
              {mode === "test" && testTimeLeft === 0 ? (
                <>
                  {challengeTarget ? (
                    reps > challengeTarget.score ? (
                      <>
                        <p className="text-white font-black text-2xl mb-2 text-[#14F1E1] animate-bounce">🔥 RECORD BEATEN! 🔥</p>
                        <p className="text-white font-bold text-lg">You scored {reps}, beating {challengeTarget.userName}&apos;s {challengeTarget.score}!</p>
                      </>
                    ) : (
                      <>
                        <p className="text-white font-black text-2xl mb-2 text-[#FF5A5F]">SO CLOSE!</p>
                        <p className="text-white font-bold text-lg">{challengeTarget.userName} scored {challengeTarget.score}, you got {reps}. Try again?</p>
                      </>
                    )
                  ) : (
                    <>
                      <p className="text-white font-black text-2xl mb-2 text-[#B66DFF]">TEST COMPLETE</p>
                      <p className="text-white font-bold text-lg">You scored {reps} {exercise}!</p>
                    </>
                  )}
                </>
              ) : (
                <>
                  {challengeTarget && mode === "test" && testTimeLeft === null ? (
                    <div className="mb-4">
                      <p className="text-[#14F1E1] font-black text-2xl mb-1 uppercase tracking-widest">GHOST CHALLENGE</p>
                      <p className="text-white font-bold text-md bg-[#14F1E1]/20 px-4 py-2 rounded-xl border border-[#14F1E1]/30">
                        Beat {challengeTarget.userName}&apos;s {challengeTarget.score} {exercise}!
                      </p>
                    </div>
                  ) : (
                    <p className="text-white font-bold text-lg">Ready to track {exercise}</p>
                  )}
                </>
              )}
              <p className="text-[#9CA3AF] text-sm mt-2">Position your device so your upper body &amp; hips are visible (Front or Side view works!).</p>
              <p className="text-[#14F1E1] text-xs font-bold mt-4 animate-pulse">TAP START TO ACTIVATE CAMERA</p>
            </div>
          ) : (
            <>
              {/* Hardware-accelerated Canvas with mirrored display if user-facing */}
              <canvas
                ref={canvasRef}
                className={`w-full h-full object-cover transition-all duration-300 ${
                  facingMode === "user" ? "-scale-x-100" : ""
                } ${
                  isFormFlashingRed
                    ? "ring-8 ring-red-500 shadow-[inset_0_0_60px_rgba(239,68,68,0.7)]"
                    : isFormFlashingGreen
                    ? "ring-6 ring-emerald-400 shadow-[inset_0_0_40px_rgba(52,211,153,0.5)]"
                    : isGenieSpeaking
                    ? "ring-4 ring-[#14F1E1] shadow-[inset_0_0_40px_rgba(20,241,225,0.4)]"
                    : ""
                }`}
              />

              {/* ROM Calibration AR HUD Overlay */}
              <AnimatePresence>
                {calibrationPhase !== "idle" && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 z-30 bg-[#050B1A]/85 backdrop-blur-sm flex flex-col p-4 sm:p-6 overflow-y-auto"
                  >
                    {/* Calibration Header */}
                    <div className="flex items-center justify-between border-b border-[#14F1E1]/30 pb-3 mb-4 shrink-0">
                      <div className="flex items-center gap-2">
                        <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center shrink-0">
                          <Target className="w-5 h-5 text-emerald-400 animate-pulse" />
                        </div>
                        <div>
                          <h3 className="text-sm font-black text-white uppercase tracking-wider font-mono flex items-center gap-2">
                            101% ROM CALIBRATOR{" "}
                            <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-500/30 text-emerald-300 font-bold">
                              ANTI-FAKE
                            </span>
                          </h3>
                          <p className="text-[10px] text-zinc-400 font-mono">
                            {exercise.toUpperCase()} • Tailored Joint Tripwires & Biometrics
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={cancelCalibrationFlow}
                        className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Step Progress Indicators */}
                    <div className="grid grid-cols-3 gap-2 mb-4 shrink-0">
                      <div
                        className={`p-2 rounded-xl border text-center transition-all ${
                          calibrationPhase === "top_hold"
                            ? "bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.3)]"
                            : capturedTopAngle !== null
                            ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-400"
                            : "bg-black/40 border-white/10 text-zinc-500"
                        }`}
                      >
                        <span className="text-[9px] uppercase font-mono font-bold block">Step 1</span>
                        <span className="text-xs font-black">Top Lockout</span>
                        {capturedTopAngle !== null && (
                          <span className="text-[10px] block font-mono text-emerald-300">
                            {capturedTopAngle}°
                          </span>
                        )}
                      </div>

                      <div
                        className={`p-2 rounded-xl border text-center transition-all ${
                          calibrationPhase === "bottom_hold"
                            ? "bg-amber-500/20 border-amber-400 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.3)]"
                            : capturedBottomAngle !== null
                            ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-400"
                            : "bg-black/40 border-white/10 text-zinc-500"
                        }`}
                      >
                        <span className="text-[9px] uppercase font-mono font-bold block">Step 2</span>
                        <span className="text-xs font-black">Bottom Depth</span>
                        {capturedBottomAngle !== null && (
                          <span className="text-[10px] block font-mono text-emerald-300">
                            {capturedBottomAngle}°
                          </span>
                        )}
                      </div>

                      <div
                        className={`p-2 rounded-xl border text-center transition-all ${
                          calibrationPhase === "completed"
                            ? "bg-emerald-500/20 border-emerald-400 text-emerald-300 shadow-[0_0_15px_rgba(52,211,153,0.35)]"
                            : "bg-black/40 border-white/10 text-zinc-500"
                        }`}
                      >
                        <span className="text-[9px] uppercase font-mono font-bold block">Step 3</span>
                        <span className="text-xs font-black">101% Verified</span>
                        {calibratedRom && (
                          <span className="text-[10px] block font-mono text-emerald-300">
                            ROM: {calibratedRom.rom}°
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Calibration Error Notification */}
                    {calibrationError && (
                      <div className="mb-4 p-3 rounded-2xl bg-red-500/20 border border-red-500/50 flex items-center gap-3 text-red-300 text-xs font-bold shrink-0">
                        <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
                        <span>{calibrationError}</span>
                      </div>
                    )}

                    {/* Step 0: Intro */}
                    {calibrationPhase === "intro" && (
                      <div className="flex-1 flex flex-col justify-center items-center text-center max-w-md mx-auto space-y-4 my-auto">
                        <div className="w-16 h-16 rounded-full bg-cyan-500/10 border-2 border-cyan-400/50 flex items-center justify-center">
                          <Sliders className="w-8 h-8 text-cyan-400 animate-pulse" />
                        </div>
                        <div>
                          <h4 className="text-lg font-black text-white uppercase tracking-wider">
                            Biomechanical ROM Calibration
                          </h4>
                          <p className="text-xs text-zinc-300 mt-1 leading-relaxed">
                            Personalize tripwire angles to your body proportions & camera perspective.
                            Guarantees <strong className="text-emerald-400">101% rep accuracy</strong> and prevents fake counts.
                          </p>
                        </div>

                        <div className="w-full bg-black/50 border border-white/10 rounded-2xl p-3.5 text-left text-xs font-mono space-y-2">
                          <div className="flex items-center gap-2 text-cyan-300 font-bold">
                            <CheckCheck className="w-4 h-4 text-cyan-400 shrink-0" />
                            <span>1. Hold Lockout (Top) for 3 seconds</span>
                          </div>
                          <div className="flex items-center gap-2 text-amber-300 font-bold">
                            <CheckCheck className="w-4 h-4 text-amber-400 shrink-0" />
                            <span>2. Hold Full Depth (Bottom) for 3 seconds</span>
                          </div>
                          <div className="flex items-center gap-2 text-emerald-300 font-bold">
                            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                            <span>3. Dynamic anti-cheat tripwires lock in</span>
                          </div>
                        </div>

                        <button
                          onClick={startTopHoldStep}
                          className="w-full py-4 rounded-xl bg-gradient-to-r from-[#14F1E1] to-[#0DE0D1] text-black font-black uppercase tracking-widest text-xs shadow-[0_0_25px_rgba(20,241,225,0.4)] hover:brightness-110 transition-all cursor-pointer"
                        >
                          Begin Step 1 (Hold Top Lockout)
                        </button>
                      </div>
                    )}

                    {/* Step 1 & 2: Active Holds */}
                    {(calibrationPhase === "top_hold" || calibrationPhase === "bottom_hold") && (
                      <div className="flex-1 flex flex-col justify-between items-center text-center max-w-md mx-auto w-full py-2 my-auto">
                        <div className="space-y-1">
                          <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 font-bold">
                            {calibrationPhase === "top_hold" ? "STEP 1 OF 2: TOP LOCKOUT" : "STEP 2 OF 2: BOTTOM DEPTH"}
                          </span>
                          <h4 className="text-lg font-black text-white">
                            {calibrationPhase === "top_hold"
                              ? exercise === "Squats"
                                ? "Stand Tall • Legs Straight"
                                : "Hold Plank • Arms Extended"
                              : exercise === "Squats"
                              ? "Squat Deep • Thighs Parallel"
                              : "Chest Down • Deep Pushup"}
                          </h4>
                        </div>

                        {/* Circular Countdown Ring & Live Angle Gauge */}
                        <div className="relative my-4 flex items-center justify-center">
                          <svg viewBox="0 0 100 100" className="w-40 h-40 -rotate-90">
                            <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="6" />
                            <circle
                              cx="50"
                              cy="50"
                              r="42"
                              fill="none"
                              stroke={calibrationPhase === "top_hold" ? "#14F1E1" : "#F59E0B"}
                              strokeWidth="6"
                              strokeLinecap="round"
                              strokeDasharray={263.9}
                              strokeDashoffset={263.9 * (1 - calibrationCountdown / 3)}
                              style={{
                                filter: `drop-shadow(0 0 10px ${calibrationPhase === "top_hold" ? "#14F1E1" : "#F59E0B"})`,
                                transition: "all 0.4s ease"
                              }}
                            />
                          </svg>
                          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                            <span className="text-4xl font-black font-mono text-white leading-none">
                              {calibrationCountdown}
                            </span>
                            <span className="text-xs font-mono font-black mt-1 text-emerald-400">
                              {trackedAngle}°
                            </span>
                            <span className="text-[8px] uppercase tracking-wider text-zinc-400">
                              Live Angle
                            </span>
                          </div>
                        </div>

                        <div className="w-full bg-black/60 border border-white/10 rounded-2xl p-3 text-center">
                          <p className="text-xs text-zinc-300 font-mono">
                            {calibrationPhase === "top_hold"
                              ? "Keep steady. Sampling your top lockout extension..."
                              : "Hold depth steady. Sampling your bottom position..."}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Step 3: Completed */}
                    {calibrationPhase === "completed" && calibratedRom && (
                      <div className="flex-1 flex flex-col justify-center items-center text-center max-w-md mx-auto space-y-4 my-auto">
                        <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center shadow-[0_0_30px_rgba(52,211,153,0.4)]">
                          <ShieldCheck className="w-9 h-9 text-emerald-400" />
                        </div>

                        <div>
                          <h4 className="text-xl font-black text-white uppercase tracking-wider">
                            101% Calibrated &amp; Ready!
                          </h4>
                          <p className="text-xs text-emerald-300 font-mono mt-0.5">
                            Biomechanical Profile Saved for {exercise}
                          </p>
                        </div>

                        {/* Biomechanical Telemetry Card */}
                        <div className="w-full bg-black/60 border border-emerald-500/30 rounded-2xl p-4 grid grid-cols-2 gap-3 text-left font-mono">
                          <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                            <span className="text-[9px] text-zinc-400 uppercase block">Top Lockout</span>
                            <span className="text-base font-black text-cyan-300">{calibratedRom.upAngle}°</span>
                          </div>
                          <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                            <span className="text-[9px] text-zinc-400 uppercase block">Bottom Depth</span>
                            <span className="text-base font-black text-amber-300">{calibratedRom.downAngle}°</span>
                          </div>
                          <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                            <span className="text-[9px] text-zinc-400 uppercase block">Active ROM</span>
                            <span className="text-base font-black text-emerald-400">{calibratedRom.rom}°</span>
                          </div>
                          <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                            <span className="text-[9px] text-zinc-400 uppercase block">Down Tripwire</span>
                            <span className="text-base font-black text-yellow-400">&le; {calibratedRom.downThreshold}°</span>
                          </div>
                        </div>

                        <div className="w-full flex gap-2">
                          <button
                            onClick={startTopHoldStep}
                            className="flex-1 py-3.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs uppercase tracking-wider transition-all cursor-pointer"
                          >
                            Recalibrate
                          </button>
                          <button
                            onClick={startWorkoutFromCalibration}
                            className="flex-1 py-3.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-black font-black text-xs uppercase tracking-widest shadow-[0_0_25px_rgba(52,211,153,0.4)] transition-all cursor-pointer flex items-center justify-center gap-1.5"
                          >
                            <Play className="w-4 h-4 fill-current" />
                            Start Workout
                          </button>
                        </div>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Real-Time Form Correction Visual Alert & Feedback Banner */}
              <AnimatePresence>
                {isActive && !formStatus.isCorrect && (
                  <motion.div
                    initial={{ opacity: 0, y: 15, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    className="absolute top-20 left-4 right-4 z-30 mx-auto max-w-sm bg-black/90 backdrop-blur-md border-2 border-red-500 shadow-[0_0_35px_rgba(239,68,68,0.7)] rounded-2xl p-3 flex items-center gap-3 animate-pulse"
                  >
                    <div className="w-10 h-10 rounded-xl bg-red-500/25 border border-red-500/60 flex items-center justify-center shrink-0">
                      <AlertTriangle className="w-5 h-5 text-amber-400 animate-bounce" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9.5px] font-black uppercase tracking-widest text-amber-400 font-mono">
                          FORM CORRECTION
                        </span>
                        {formStatus.kneeAngle !== undefined && (
                          <span className="text-[8.5px] text-zinc-400 font-mono">
                            Knee: {formStatus.kneeAngle}°
                          </span>
                        )}
                        {formStatus.elbowAngle !== undefined && (
                          <span className="text-[8.5px] text-zinc-400 font-mono">
                            Elbow: {formStatus.elbowAngle}°
                          </span>
                        )}
                      </div>
                      <p className="text-white text-xs sm:text-sm font-black leading-snug mt-0.5 text-yellow-300 drop-shadow-sm">
                        {formStatus.feedback}
                      </p>
                    </div>
                  </motion.div>
                )}

                {isActive && formStatus.isCorrect && isFormFlashingGreen && reps > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="absolute top-20 left-4 right-4 z-30 mx-auto max-w-xs bg-black/85 backdrop-blur-md border border-emerald-400/80 shadow-[0_0_25px_rgba(52,211,153,0.4)] rounded-2xl p-2.5 flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="text-emerald-300 font-black text-xs uppercase tracking-wider font-mono">
                      Form Solid! Full Rep
                    </span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Visual Speaking Banner & Dynamic Sound Waves */}
              <AnimatePresence>
                {isGenieSpeaking && (
                  <motion.div
                    initial={{ opacity: 0, y: -20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -20, scale: 0.95 }}
                    className="absolute top-4 left-4 right-4 z-30 mx-auto max-w-sm bg-black/85 backdrop-blur-md border border-[#14F1E1]/60 shadow-[0_0_30px_rgba(20,241,225,0.4)] rounded-2xl p-3 flex items-center gap-3"
                  >
                    <div className="w-9 h-9 rounded-xl bg-[#14F1E1]/20 border border-[#14F1E1]/40 flex items-center justify-center shrink-0">
                      <Volume2 className="w-5 h-5 text-[#14F1E1] animate-pulse" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-black uppercase tracking-widest text-[#14F1E1] font-mono">
                          GENIE VOICE COACH
                        </span>
                        {/* Sound Wave Equalizer Bars */}
                        <div className="flex items-center gap-0.5">
                          <span className="w-1 h-3 bg-[#14F1E1] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-1 h-4 bg-[#14F1E1] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-1 h-2 bg-[#14F1E1] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                          <span className="w-1 h-3.5 bg-[#14F1E1] rounded-full animate-bounce" style={{ animationDelay: '75ms' }} />
                        </div>
                      </div>
                      <p className="text-white text-xs font-bold truncate mt-0.5 tracking-wide">
                        &ldquo;{genieSpokenText}&rdquo;
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Rep Overlay with dynamic animation */}
              {isActive && <RepOverlay reps={reps} />}

              {/* 1-Minute Countdown Badge */}
              {isActive && mode === "test" && testTimeLeft !== null && (
                <div className="absolute top-8 left-1/2 -translate-x-1/2 bg-black/80 px-6 py-2 rounded-full border border-[#B66DFF]/50 shadow-[0_0_20px_rgba(182,109,255,0.4)] z-10 flex flex-col items-center">
                  <span className="text-[10px] text-[#B66DFF] font-black uppercase tracking-widest">Time Left</span>
                  <span className={`text-3xl font-black ${testTimeLeft <= 10 ? "text-red-500 animate-pulse" : "text-white"}`}>
                    00:{testTimeLeft.toString().padStart(2, "0")}
                  </span>
                </div>
              )}

              {/* Low Confidence warning */}
              {isActive && lowConfidence && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black/85 px-6 py-4 rounded-2xl border border-red-500/50 flex flex-col items-center gap-2 text-center w-[85%] max-w-sm backdrop-blur-sm">
                  <AlertCircle className="w-8 h-8 text-red-500 animate-pulse" />
                  <p className="text-white font-bold text-sm">Thoda peeche/side ho jao, pura body camera me aana chahiye</p>
                </div>
              )}

              {/* Cyberpunk 3D AR HUD Corner Brackets, Telemetry Reticle & Live Joint Angle Arc Gauge */}
              {isActive && (
                <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden">
                  {/* 4 Corner Sci-Fi Targeting Brackets */}
                  <div className="absolute top-3 left-3 w-7 h-7 border-t-2 border-l-2 border-[#14F1E1]/70 rounded-tl-lg shadow-[-2px_-2px_10px_rgba(20,241,225,0.3)]" />
                  <div className="absolute top-3 right-3 w-7 h-7 border-t-2 border-r-2 border-[#14F1E1]/70 rounded-tr-lg shadow-[2px_-2px_10px_rgba(20,241,225,0.3)]" />
                  <div className="absolute bottom-3 left-3 w-7 h-7 border-b-2 border-l-2 border-[#14F1E1]/70 rounded-bl-lg shadow-[-2px_2px_10px_rgba(20,241,225,0.3)]" />
                  <div className="absolute bottom-3 right-3 w-7 h-7 border-b-2 border-r-2 border-[#14F1E1]/70 rounded-br-lg shadow-[2px_2px_10px_rgba(20,241,225,0.3)]" />

                  {/* Subtle Center Holographic Scan Reticle */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-44 h-44 rounded-full border border-[#14F1E1]/15 flex items-center justify-center">
                    <div className="w-36 h-36 rounded-full border border-dashed border-[#B66DFF]/20 animate-spin" style={{ animationDuration: "18s" }} />
                  </div>

                  {/* Real-Time Diagnostic Visualizer Overlay */}
                  {showDiagnostic && (
                    <div className="absolute top-4 left-4 z-20 bg-[#080E20]/90 backdrop-blur-md border border-cyan-400/40 rounded-2xl p-3 shadow-[0_0_25px_rgba(6,182,212,0.25)] text-left font-mono max-w-[260px] pointer-events-auto">
                      <div className="flex items-center justify-between border-b border-white/10 pb-1.5 mb-2">
                        <div className="flex items-center gap-1.5">
                          <Activity className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                          <span className="text-[10px] font-black uppercase tracking-wider text-cyan-300">
                            POSE DIAGNOSTICS
                          </span>
                        </div>
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-400/30 text-cyan-300 font-bold">
                          {diagnosticData?.fps || 0} FPS
                        </span>
                      </div>

                      <div className="space-y-1 text-[10px]">
                        <div className="flex justify-between items-center">
                          <span className="text-zinc-400">Tracked Side:</span>
                          <span className="text-white font-bold uppercase">{diagnosticData?.trackedSide || "Detecting..."}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-zinc-400">Joint Angle (2D):</span>
                          <span className="text-cyan-300 font-bold">{diagnosticData?.rawAngle2D ?? 170}°</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-zinc-400">Effective Angle:</span>
                          <span className={`font-black ${state === "down" ? "text-emerald-400" : "text-amber-300"}`}>
                            {diagnosticData?.effectiveAngle ?? trackedAngle}°
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-zinc-400">Thresholds:</span>
                          <span className="text-zinc-300 text-[9px]">
                            {diagnosticData?.calibratedDownThreshold && diagnosticData?.calibratedUpThreshold
                              ? `Down ≤ ${diagnosticData.calibratedDownThreshold}° | Up ≥ ${diagnosticData.calibratedUpThreshold}°`
                              : "Down ≤ 132° | Up ≥ 142°"}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-zinc-400">Calibrated:</span>
                          <span className={`text-[9px] font-bold ${calibratedRom ? "text-emerald-400" : "text-amber-400"}`}>
                            {calibratedRom ? `101% ACTIVE (ROM: ${calibratedRom.rom}°)` : "DEFAULT (UNCALIBRATED)"}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-zinc-400">Rep Phase:</span>
                          <span className={`font-black uppercase px-1.5 py-0.2 rounded text-[9px] ${state === "down" ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40" : "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"}`}>
                            {state === "down" ? "DOWN (ARMED)" : "UP (WAITING)"}
                          </span>
                        </div>

                        {/* Visibility Confidence Meter */}
                        <div className="pt-1.5 border-t border-white/10 space-y-1">
                          <span className="text-[9px] text-zinc-400 uppercase block font-bold">Landmark Confidence:</span>
                          <div className="grid grid-cols-2 gap-1 text-[8.5px]">
                            <span className={diagnosticData?.visibilityScores?.leftArm ? "text-emerald-400" : "text-zinc-500"}>
                              L-Arm: {diagnosticData?.visibilityScores?.leftArm ?? 0}%
                            </span>
                            <span className={diagnosticData?.visibilityScores?.rightArm ? "text-emerald-400" : "text-zinc-500"}>
                              R-Arm: {diagnosticData?.visibilityScores?.rightArm ?? 0}%
                            </span>
                            <span className={diagnosticData?.visibilityScores?.leftLeg ? "text-emerald-400" : "text-zinc-500"}>
                              L-Leg: {diagnosticData?.visibilityScores?.leftLeg ?? 0}%
                            </span>
                            <span className={diagnosticData?.visibilityScores?.rightLeg ? "text-emerald-400" : "text-zinc-500"}>
                              R-Leg: {diagnosticData?.visibilityScores?.rightLeg ?? 0}%
                            </span>
                          </div>
                        </div>

                        {/* Diagnostic reason text */}
                        <div className="mt-1.5 pt-1.5 border-t border-white/10 bg-black/40 p-1.5 rounded-lg">
                          <p className="text-[8.5px] leading-tight text-cyan-200">
                            {diagnosticData?.reasonForState || "Looking for athlete..."}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Live Biomechanical Joint Angle & Depth Gauge (Right Side HUD) */}
                  {!lowConfidence && (
                    <div className="absolute bottom-8 right-4 bg-black/80 backdrop-blur-md px-3.5 py-2.5 rounded-2xl border border-[#14F1E1]/40 shadow-[0_10px_25px_rgba(0,0,0,0.8),0_0_15px_rgba(20,241,225,0.2)] flex items-center gap-3">
                      {(() => {
                        const rawAngle = trackedAngle;
                        const clampedAngle = Math.max(50, Math.min(180, rawAngle));
                        const downGoal = calibratedRom?.downThreshold ?? 126;
                        const upGoal = calibratedRom?.upThreshold ?? 144;
                        const totalSpan = Math.max(20, (calibratedRom?.upAngle ?? 170) - (calibratedRom?.downAngle ?? 75));
                        const depthPct = Math.round((((calibratedRom?.upAngle ?? 170) - clampedAngle) / totalSpan) * 100);
                        const phaseLabel =
                          state === "down" || clampedAngle <= downGoal
                            ? "BOTTOM — PUSH UP!"
                            : clampedAngle <= Math.round((upGoal + downGoal) / 2)
                            ? "GOING DOWN..."
                            : "READY / LOCKOUT";
                        const phaseColor =
                          state === "down" || clampedAngle <= downGoal
                            ? "#10B981"
                            : clampedAngle <= Math.round((upGoal + downGoal) / 2)
                            ? "#FFB703"
                            : "#14F1E1";

                        return (
                          <>
                            <div className="relative w-12 h-12 flex items-center justify-center shrink-0">
                              <svg viewBox="0 0 50 50" className="w-full h-full -rotate-90">
                                <circle cx="25" cy="25" r="20" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="4" />
                                <circle
                                  cx="25"
                                  cy="25"
                                  r="20"
                                  fill="none"
                                  stroke={phaseColor}
                                  strokeWidth="4"
                                  strokeLinecap="round"
                                  strokeDasharray={125.6}
                                  strokeDashoffset={125.6 - (125.6 * Math.min(100, Math.max(10, depthPct))) / 100}
                                  style={{ filter: `drop-shadow(0 0 6px ${phaseColor})`, transition: "all 0.15s ease" }}
                                />
                              </svg>
                              <div className="absolute inset-0 flex flex-col items-center justify-center">
                                <span className="text-[11px] font-black font-mono text-white leading-none">{clampedAngle}°</span>
                                <span className="text-[6.5px] font-bold uppercase text-zinc-400">
                                  {exercise === "Squats" ? "DEPTH" : "ELBOW"}
                                </span>
                              </div>
                            </div>

                            <div className="flex flex-col">
                              <div className="flex items-center gap-1.5">
                                <span
                                  className="w-2 h-2 rounded-full"
                                  style={{ backgroundColor: phaseColor, boxShadow: `0 0 8px ${phaseColor}` }}
                                />
                                <span className="text-[10px] font-black uppercase tracking-wider font-mono text-white">
                                  {phaseLabel}
                                </span>
                              </div>
                              <span className="text-[8.5px] font-bold uppercase tracking-widest text-zinc-400 mt-0.5">
                                STATE: <strong className={state === "down" ? "text-emerald-400" : "text-[#14F1E1]"}>{state === "up" ? "UP (TOP)" : "DOWN (REP ARMED)"}</strong>
                              </span>
                            </div>
                          </>
                        );
                      })()}
                    </div>
                  )}
                </div>
              )}

              {/* Module 4: 3D Holographic Ghost Race HUD */}
              {isActive && isGhostOverlayEnabled && (
                <div className="absolute bottom-8 left-4 z-20 flex flex-col gap-2 max-w-[210px] sm:max-w-[240px]">
                  {activeGhostRace ? (
                    <div className="bg-black/85 backdrop-blur-md border border-[#FFE600]/40 shadow-[0_0_20px_rgba(255,230,0,0.25)] rounded-2xl p-3 flex flex-col gap-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <Ghost className="w-3.5 h-3.5 text-[#FFE600] animate-pulse" />
                          <span className="text-[9px] font-black uppercase tracking-wider text-[#FFE600] font-mono truncate max-w-[115px]">
                            {activeGhostRace.rivalName ? `VS ${activeGhostRace.rivalName}` : "PAST PR GHOST"}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono text-zinc-400">
                          PR: {activeGhostRace.prReps}
                        </span>
                      </div>

                      {/* Rep Comparison and Live Delta */}
                      <div className="flex items-center justify-between pt-1 border-t border-white/10">
                        <div className="flex flex-col">
                          <span className="text-[8px] text-zinc-400 uppercase font-mono">Ghost Reps</span>
                          <span className="text-sm font-black font-mono text-amber-300">
                            {currentGhostFrame ? currentGhostFrame.repCount : 0}
                          </span>
                        </div>

                        {/* Delta Badge */}
                        {(() => {
                          const ghostReps = currentGhostFrame ? currentGhostFrame.repCount : 0;
                          const delta = reps - ghostReps;
                          if (delta > 0) {
                            return (
                              <span className="text-[9px] font-black font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 animate-pulse">
                                +{delta} AHEAD 🔥
                              </span>
                            );
                          } else if (delta < 0) {
                            return (
                              <span className="text-[9px] font-black font-mono px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40">
                                {delta} BEHIND ⚠️
                              </span>
                            );
                          } else {
                            return (
                              <span className="text-[9px] font-black font-mono px-2 py-0.5 rounded-full bg-[#14F1E1]/20 text-[#14F1E1] border border-[#14F1E1]/40">
                                TIED ⚔️
                              </span>
                            );
                          }
                        })()}
                      </div>

                      {/* Joint Angle Telemetry Comparison */}
                      {currentGhostFrame && (
                        <div className="flex items-center justify-between text-[8px] font-mono text-zinc-400 pt-1 border-t border-white/5">
                          <span>
                            {exercise === "Squats" ? "Ghost Knee:" : "Ghost Elbow:"}{" "}
                            <span className="text-[#FFE600] font-bold">
                              {exercise === "Squats"
                                ? `${currentGhostFrame.angles?.knee ?? 0}°`
                                : `${currentGhostFrame.angles?.elbow ?? 0}°`}
                            </span>
                          </span>
                          <span>
                            Live:{" "}
                            <span className="text-[#14F1E1] font-bold">
                              {exercise === "Squats"
                                ? `${formStatus.kneeAngle ?? 0}°`
                                : `${formStatus.elbowAngle ?? 0}°`}
                            </span>
                          </span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="bg-black/80 backdrop-blur-md border border-[#FFE600]/30 rounded-xl px-3 py-1.5 flex items-center gap-2 shadow-lg">
                      <Ghost className="w-3.5 h-3.5 text-[#FFE600] animate-pulse" />
                      <span className="text-[9px] font-mono font-bold text-amber-300">
                        Recording New PR Ghost (10Hz)
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Module 4: New PR Ghost Saved Celebration Toast */}
              <AnimatePresence>
                {newPrSavedToast && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8, y: -20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-40 bg-[#0D1328]/95 border-2 border-[#FFE600] rounded-2xl p-5 shadow-[0_0_40px_rgba(255,230,0,0.5)] text-center max-w-xs backdrop-blur-xl"
                  >
                    <Trophy className="w-12 h-12 text-[#FFE600] mx-auto mb-2 animate-bounce" />
                    <h3 className="text-lg font-black text-white uppercase tracking-wider">
                      NEW PR SKELETON GHOST!
                    </h3>
                    <p className="text-xs text-amber-300 font-mono mt-1">
                      {reps} {exercise.toUpperCase()} RECORDED
                    </p>
                    <p className="text-[10px] text-zinc-400 mt-2 leading-relaxed">
                      Your 3D joint telemetry and ghost skeleton have been archived for your next race!
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </>
          )}
        </div>

        {/* Controls Section */}
        <div className="p-6 bg-[#0D1328] border-t border-[#14F1E1]/20 rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.5)] z-10">
          {!challengeTarget && (
            <div className="flex bg-white/5 rounded-xl p-1 mb-4">
              <button
                onClick={() => {
                  setMode("free");
                  setTestTimeLeft(null);
                  setIsActive(false);
                }}
                className={`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${
                  mode === "free" ? "bg-[#14F1E1] text-[#050B1A]" : "text-white hover:text-[#14F1E1]"
                }`}
              >
                Free Flow
              </button>
              <button
                onClick={() => {
                  setMode("test");
                  setTestTimeLeft(60);
                  setIsActive(false);
                  setReps(0);
                  setState("up");
                  setTrackedAngle(calibratedRom?.upAngle || 170);
                  repTrackerRef.current = createInitialRepTrackerState(sensitivity, calibratedRom);
                }}
                className={`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${
                  mode === "test" ? "bg-[#B66DFF] text-white" : "text-white hover:text-[#B66DFF]"
                }`}
              >
                1-Min Test
              </button>
            </div>
          )}

          {/* 101% Accuracy Range of Motion (ROM) Calibration Card */}
          <div className="mb-4 bg-gradient-to-r from-emerald-950/40 to-cyan-950/40 border border-emerald-500/30 rounded-2xl p-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0">
                <Target className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-black uppercase tracking-wider text-emerald-300 font-mono">
                    {calibratedRom ? "101% Biomechanical ROM" : "Dynamic ROM Calibration"}
                  </span>
                  {calibratedRom ? (
                    <span className="text-[8px] px-1.5 py-0.2 rounded bg-emerald-500/30 text-emerald-200 font-mono font-bold">
                      ACTIVE
                    </span>
                  ) : (
                    <span className="text-[8px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono font-bold animate-pulse">
                      RECOMMENDED
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-zinc-400 mt-0.5">
                  {calibratedRom
                    ? `ROM: ${calibratedRom.rom}° • Down ≤ ${calibratedRom.downThreshold}° • Up ≥ ${calibratedRom.upThreshold}°`
                    : "Calibrate 2 quick holds for your body & camera angle to stop fake counts"}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={startCalibrationFlow}
              className={`py-1.5 px-3 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all shrink-0 cursor-pointer ${
                calibratedRom
                  ? "bg-white/10 hover:bg-white/20 text-emerald-300 border border-emerald-500/30"
                  : "bg-emerald-400 hover:bg-emerald-300 text-black shadow-[0_0_15px_rgba(52,211,153,0.4)]"
              }`}
            >
              {calibratedRom ? "Recalibrate" : "Calibrate"}
            </button>
          </div>

          {/* Sensitivity Selector: Lenient (Home / Casual) | Standard | Strict (Gym / Competition) */}
          <div className="mb-4 bg-black/40 border border-white/10 rounded-2xl p-2.5">
            <div className="flex items-center justify-between mb-1.5 px-1">
              <span className="text-[10px] font-mono font-black uppercase text-cyan-400 tracking-wider">
                DETECTION SENSITIVITY
              </span>
              <span className="text-[9px] font-mono text-zinc-400">
                {sensitivity === "lenient"
                  ? "Lenient (Easy Detection • &le;136°)"
                  : sensitivity === "strict"
                  ? "Strict (Deep Lockout • &le;120°)"
                  : "Standard (Balanced • &le;132°)"}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {(["lenient", "standard", "strict"] as TrackingSensitivity[]).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => setSensitivity(mode)}
                  className={`py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                    sensitivity === mode
                      ? mode === "lenient"
                        ? "bg-emerald-400 text-black shadow-[0_0_12px_rgba(52,211,153,0.4)]"
                        : mode === "strict"
                        ? "bg-purple-500 text-white shadow-[0_0_12px_rgba(168,85,247,0.4)]"
                        : "bg-cyan-400 text-black shadow-[0_0_12px_rgba(6,182,212,0.4)]"
                      : "bg-white/5 text-zinc-400 hover:text-white"
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4 mb-6">
            <select
              value={exercise}
              onChange={(e) => setExercise(e.target.value as "Pushups" | "Squats")}
              className="flex-1 bg-black border border-[#14F1E1]/30 text-white rounded-xl px-4 py-3 font-bold uppercase tracking-wider outline-none focus:border-[#14F1E1]"
            >
              <option value="Pushups">Pushups</option>
              <option value="Squats">Squats</option>
            </select>

            <button
              onClick={() => setFacingMode((f) => (f === "user" ? "environment" : "user"))}
              className="p-3 bg-white/5 rounded-xl border border-white/10 text-white hover:bg-white/10 transition-colors"
              title="Flip camera"
            >
              <Camera className="w-6 h-6" />
            </button>
          </div>

          <div className="flex items-center gap-3 mb-6">
            <button
              onClick={() => {
                if (!isActive) {
                  sessionStartTimeRef.current = Date.now();
                  setCheatAlert(null);
                }
                if (!isActive && mode === "test") {
                  setTestTimeLeft(60);
                  setReps(0);
                  setState("up");
                  setTrackedAngle(calibratedRom?.upAngle || 170);
                  repTrackerRef.current = createInitialRepTrackerState(sensitivity, calibratedRom);
                }
                setIsActive(!isActive);
              }}
              disabled={modelLoading || cameraAccess === false}
              className={`flex-1 py-4 rounded-xl flex items-center justify-center gap-2 font-black uppercase tracking-widest transition-all ${
                isActive
                  ? "bg-red-500/20 text-red-500 border border-red-500/50 hover:bg-red-500/30"
                  : "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_20px_rgba(20,241,225,0.4)] hover:bg-[#0DE0D1]"
              } disabled:opacity-50`}
            >
              {isActive ? (
                <>
                  <Square className="w-5 h-5 fill-current" /> Pause
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current" /> Start AI Tracker
                </>
              )}
            </button>

            <button
              onClick={() => {
                setReps(0);
                setState("up");
                setTrackedAngle(calibratedRom?.upAngle || 170);
                repTrackerRef.current = createInitialRepTrackerState(sensitivity, calibratedRom);
              }}
              className="p-4 bg-white/5 rounded-xl border border-white/10 text-white hover:bg-white/10 transition-colors"
              title="Reset reps"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleManualSave}
              disabled={reps === 0}
              className="flex-1 py-4 rounded-xl bg-gradient-to-r from-[#4DA8FF] to-[#B66DFF] text-white font-black uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-50 disabled:grayscale transition-all hover:shadow-[0_0_20px_rgba(182,109,255,0.4)]"
            >
              <Save className="w-5 h-5" /> Save to Workout Log
            </button>
            <button
              onClick={() => setShowFlexCardModal(true)}
              className="px-4 py-4 rounded-xl bg-[#14F1E1]/15 border border-[#14F1E1]/40 text-[#14F1E1] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 hover:bg-[#14F1E1]/25 transition-all cursor-pointer"
              title="Share Fighter Flex Card"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </div>

          <div className="mt-4 text-center">
            <span className="text-[#9CA3AF] text-[10px] font-bold uppercase tracking-widest opacity-60">
              AI Pose Engine • Front &amp; Side Angle Tracking Active
            </span>
          </div>
        </div>
      </div>

      {/* IDEA 8: 1V1 BRO GHOST DUEL CODE MODAL */}
      <AnimatePresence>
        {showDuelModal && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.92 }}
              className="bg-[#0D1328] border border-[#B66DFF]/40 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-[0_0_50px_rgba(182,109,255,0.25)]"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-[#B66DFF]/20 border border-[#B66DFF]/40 flex items-center justify-center">
                    <Swords className="w-5 h-5 text-[#B66DFF]" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white uppercase tracking-wider">
                      1v1 Gym Bro Ghost Duel
                    </h3>
                    <p className="text-[10px] text-neutral-400 font-mono">
                      Zero-Server Battle Code • Race Friend&apos;s Skeleton
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowDuelModal(false)}
                  className="p-2 rounded-xl bg-white/5 text-neutral-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Export My PR Battle Code */}
              <div className="bg-black/50 border border-white/10 rounded-2xl p-4 space-y-2.5">
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#14F1E1] font-bold block">
                  1. SHARE YOUR {exercise.toUpperCase()} GHOST CODE
                </span>
                <p className="text-xs text-neutral-400">
                  Copy your Battle Code and send it on WhatsApp so your friend can race your holographic skeleton!
                </p>
                <button
                  onClick={() => {
                    const prRepsVal = activeGhostRace?.prReps || Math.max(reps, 20);
                    const durationVal = activeGhostRace?.totalDurationMs || 45000;
                    const code = exportGhostDuelCode(
                      exercise,
                      prRepsVal,
                      durationVal,
                      profile?.username || "Warrior",
                      activeGhostRace
                    );
                    navigator.clipboard?.writeText(code);
                    setDuelCopied(true);
                    setTimeout(() => setDuelCopied(false), 3000);
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#14F1E1]/15 hover:bg-[#14F1E1]/25 border border-[#14F1E1]/40 text-[#14F1E1] font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  {duelCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {duelCopied ? "Battle Code Copied to Clipboard!" : "Copy My Ghost Battle Code"}
                </button>
              </div>

              {/* Import Friend's Battle Code */}
              <div className="bg-black/50 border border-white/10 rounded-2xl p-4 space-y-2.5">
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#B66DFF] font-bold block">
                  2. PASTE FRIEND&apos;S BATTLE CODE (FG-DUEL-...)
                </span>
                <input
                  type="text"
                  placeholder="Paste FG-DUEL-... code here"
                  value={duelInputCode}
                  onChange={(e) => setDuelInputCode(e.target.value)}
                  className="w-full bg-black border border-white/15 rounded-xl px-3.5 py-2.5 text-xs font-mono text-white placeholder-neutral-600 focus:outline-none focus:border-[#B66DFF]"
                />
                {duelStatusMsg && (
                  <p className="text-xs font-bold text-amber-300">{duelStatusMsg}</p>
                )}
                <button
                  onClick={() => {
                    const imported = importGhostDuelCode(duelInputCode);
                    if (!imported) {
                      setDuelStatusMsg("Invalid Battle Code! Make sure it starts with FG-DUEL-");
                      return;
                    }
                    const nextEx = imported.exercise === "Squats" ? "Squats" : "Pushups";
                    setExercise(nextEx);
                    setActiveGhostRace(imported);
                    setIsGhostOverlayEnabled(true);
                    isGhostOverlayEnabledRef.current = true;
                    setDuelStatusMsg(`Loaded ${imported.rivalName}'s ${imported.prReps}-Rep ${imported.exercise} Ghost!`);
                    speakGenie(`Challenge accepted! Beat ${imported.rivalName}'s ${imported.prReps} ${imported.exercise}!`);
                    setTimeout(() => {
                      setShowDuelModal(false);
                      setDuelStatusMsg(null);
                    }, 1400);
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#B66DFF] to-[#4DA8FF] text-black font-black text-xs uppercase tracking-widest transition-all cursor-pointer"
                >
                  Load Friend&apos;s Ghost Skeleton
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* IDEA 6: FLEX CARD MODAL */}
      {showFlexCardModal && (
        <FlexCardModal
          onClose={() => setShowFlexCardModal(false)}
          highlightAchievement={reps > 0 ? `Crushed ${reps} AI-Verified ${exercise}` : undefined}
        />
      )}
    </div>
  );
}
