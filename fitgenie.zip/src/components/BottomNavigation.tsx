import { Home, Swords, User, MessageCircle, Diamond } from "lucide-react";
import { motion } from "motion/react";
import { AppView } from "../types";
import { playSound } from "../utils/audio";

interface BottomNavigationProps {
  currentView: AppView;
  onSetView: (view: AppView) => void;
  completedCount: number;
  streakCount: number;
}

export default function BottomNavigation({
  currentView,
  onSetView,
  completedCount,
}: BottomNavigationProps) {
  const navItems = [
    {
      view: "home" as AppView,
      label: "Home",
      icon: <Home className="w-5 h-5" />,
      accent: "#14F1E1",
    },
    {
      view: "dojo" as AppView,
      label: "Challenges",
      icon: <Swords className="w-5 h-5" />,
      accent: "#FFB703",
    },
    {
      view: "chat" as AppView,
      label: "Chat",
      icon: <MessageCircle className="w-5 h-5" />,
      accent: "#B66DFF",
    },
    {
      view: "mogged" as AppView,
      label: "Mogged",
      icon: <Diamond className="w-5 h-5" />,
      accent: "#14F1E1",
    },
    {
      view: "profile" as AppView,
      label: "Profile",
      icon: <User className="w-5 h-5" />,
      accent: "#14F1E1",
    },
  ];

  return (
    <div
      className="fixed bottom-2.5 left-0 right-0 z-50 px-3 pointer-events-none select-none"
      id="mobile-bottom-navigation"
    >
      <div
        className="max-w-md mx-auto pointer-events-auto relative rounded-3xl bg-gradient-to-b from-[#0D162D]/95 via-[#070D1F]/95 to-[#040814]/98 backdrop-blur-2xl border border-[#14F1E1]/30 px-2 py-2 shadow-[0_20px_45px_rgba(0,0,0,0.9),0_0_28px_rgba(20,241,225,0.16),inset_0_1px_1px_rgba(255,255,255,0.22)] overflow-hidden"
        style={{ transform: "perspective(800px) rotateX(4deg)" }}
      >
        {/* Top 3D Specular Horizon Line */}
        <div className="absolute top-0 left-6 right-6 h-[1.5px] bg-gradient-to-r from-transparent via-[#14F1E1]/80 to-transparent opacity-80 pointer-events-none" />
        {/* Bottom Subtle Reflection */}
        <div className="absolute bottom-0 left-10 right-10 h-[1px] bg-gradient-to-r from-transparent via-[#B66DFF]/50 to-transparent opacity-60 pointer-events-none" />

        <div className="flex items-center justify-around relative z-10">
          {navItems.map((item) => {
            const isActive = currentView === item.view;

            return (
              <button
                key={item.view}
                onClick={() => {
                  playSound("click");
                  onSetView(item.view);
                }}
                className="flex flex-col items-center justify-center py-1.5 px-2.5 min-w-[60px] flex-1 rounded-2xl transition-all duration-300 active:scale-[0.9] cursor-pointer relative group"
                id={`bottom-nav-tab-${item.view}`}
              >
                {/* Active 3D Neon Plasma Spotlight Pedestal */}
                {isActive && (
                  <motion.div
                    layoutId="active3DDockPedestal"
                    transition={{ type: "spring", stiffness: 380, damping: 28 }}
                    className="absolute inset-0 rounded-2xl bg-gradient-to-b from-[#14F1E1]/20 via-[#14F1E1]/5 to-[#B66DFF]/20 border border-[#14F1E1]/45 shadow-[0_0_20px_rgba(20,241,225,0.28),inset_0_1px_1px_rgba(255,255,255,0.3)]"
                  >
                    {/* Bottom 3D Projector Beam */}
                    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-1 rounded-t-full bg-[#14F1E1] shadow-[0_-4px_14px_#14F1E1]" />
                  </motion.div>
                )}

                <motion.div
                  animate={isActive ? { y: [0, -2.5, 0], scale: 1.12 } : { y: 0, scale: 1 }}
                  transition={
                    isActive
                      ? { duration: 2.4, repeat: Infinity, ease: "easeInOut" }
                      : { duration: 0.2 }
                  }
                  className="relative flex items-center justify-center z-10"
                >
                  {/* 3D Hexagonal Halo behind active icon */}
                  {isActive && (
                    <svg
                      viewBox="0 0 36 36"
                      className="absolute -inset-2 w-9 h-9 pointer-events-none opacity-85"
                    >
                      <polygon
                        points="18,2 32,10 32,26 18,34 4,26 4,10"
                        fill="rgba(20,241,225,0.12)"
                        stroke="#14F1E1"
                        strokeWidth="1"
                        strokeDasharray="3 2"
                      />
                    </svg>
                  )}

                  <span
                    className={`text-xl transition-all duration-300 relative z-10 ${
                      isActive
                        ? "text-[#14F1E1] drop-shadow-[0_0_12px_rgba(20,241,225,0.95)]"
                        : "text-[#9CA3AF] group-hover:text-white"
                    }`}
                  >
                    {item.icon}
                  </span>

                  {item.view === "profile" && completedCount > 0 && (
                    <span className="absolute -top-1.5 -right-3 bg-gradient-to-r from-[#0A1128] to-[#16224A] text-[#14F1E1] font-mono text-[9px] font-black px-1.5 rounded-full border border-[#14F1E1]/60 shadow-[0_0_8px_rgba(20,241,225,0.4)]">
                      {completedCount}
                    </span>
                  )}
                </motion.div>

                <span
                  className={`text-[9.5px] uppercase font-black tracking-widest mt-1.5 transition-colors duration-200 relative z-10 ${
                    isActive
                      ? "text-white drop-shadow-[0_0_6px_rgba(20,241,225,0.8)]"
                      : "text-neutral-400 group-hover:text-[#14F1E1]/80"
                  }`}
                >
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
