import { Flame, Target, X, Settings, Droplet, Scale, Plus, Minus, Calendar as CalendarIcon, Check, ChevronLeft, ChevronRight, Apple, RotateCcw, Settings2, UtensilsCrossed, Trophy, TrendingUp } from "lucide-react";
import React, { useState, useEffect } from "react";

import { motion, AnimatePresence } from "motion/react";
import { playSound } from "../utils/audio";
import { ConfirmModal } from "./ConfirmModal";
import DesiFuelBoosterAndSurvival from "./DesiFuelBoosterAndSurvival";
import VisualDesiThaliBuilder from "./VisualDesiThaliBuilder";

interface DailyNutrition {
  protein: number; // in grams
  water: number;   // in ml
}

interface NutritionGoals {
  proteinGoal: number; // in grams
  waterGoal: number;   // in ml
}

interface NutritionLogs {
  [dateStr: string]: DailyNutrition;
}

export default function NutritionLog() {
  // Key names in LocalStorage
  const LOGS_KEY = "fitgenie_nutrition_logs";
  const GOALS_KEY = "fitgenie_nutrition_goals";

  const [logs, setLogs] = useState<NutritionLogs>(() => {
    try {
      const stored = localStorage.getItem(LOGS_KEY);
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  const [goals, setGoals] = useState<NutritionGoals>(() => {
    try {
      const stored = localStorage.getItem(GOALS_KEY);
      return stored ? JSON.parse(stored) : { proteinGoal: 100, waterGoal: 3000 };
    } catch {
      return { proteinGoal: 100, waterGoal: 3000 };
    }
  });

  // Track the currently active date for logging
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const today = new Date();
    return today.toISOString().split("T")[0];
  });

  const [isEditingGoals, setIsEditingGoals] = useState(false);
  const [proteinGoalInput, setProteinGoalInput] = useState(goals.proteinGoal);
  const [waterGoalInput, setWaterGoalInput] = useState(goals.waterGoal);

  const [errorAlert, setErrorAlert] = useState("");
  const [confirmResetState, setConfirmResetState] = useState<{isOpen: boolean} | null>(null);

  const [customProteinInput, setCustomProteinInput] = useState("");
  // FEATURE #6: DIET & KITCHEN AUTO-FILTER (Syncs with Onboarding)
  const [dietFilter, setDietFilter] = useState<"veg" | "egg" | "nonveg">(() => {
    const saved = localStorage.getItem("fitgenie_diet_pref");
    if (saved === "veg" || saved === "egg" || saved === "nonveg") return saved;
    return "veg";
  });

  const [kitchenFilter, setKitchenFilter] = useState<"hostel_mess" | "home_kitchen">(() => {
    const saved = localStorage.getItem("fitgenie_kitchen_setup");
    if (saved === "hostel_mess" || saved === "home_kitchen") return saved;
    return "home_kitchen";
  });

  const handleSelectDietFilter = (mode: "veg" | "egg" | "nonveg") => {
    playSound("click");
    setDietFilter(mode);
    try {
      localStorage.setItem("fitgenie_diet_pref", mode);
    } catch {}
  };

  const handleSelectKitchenFilter = (mode: "hostel_mess" | "home_kitchen") => {
    playSound("click");
    setKitchenFilter(mode);
    try {
      localStorage.setItem("fitgenie_kitchen_setup", mode);
    } catch {}
  };

  // IDEA #3: POCKET BUDGET SLIDER (₹50/Day Student vs ₹120/Day Regular vs ₹250+/Day Beast)
  const [budgetTier, setBudgetTier] = useState<"50" | "120" | "250">(() => {
    const saved = localStorage.getItem("fitgenie_budget_tier");
    if (saved === "50" || saved === "120" || saved === "250") return saved;
    return "120";
  });

  const handleSelectBudgetTier = (tier: "50" | "120" | "250") => {
    playSound("click");
    setBudgetTier(tier);
    try {
      localStorage.setItem("fitgenie_budget_tier", tier);
      window.dispatchEvent(new Event("fitgenie_personalization_updated"));
    } catch {}
  };

  const budgetMealBlueprint = {
    "50": {
      title: "🪙 ₹50/Day Broke Student High-Protein Plan",
      totalProtein: dietFilter === "veg" ? 84 : 92,
      totalCost: "₹48 / Day",
      meals:
        dietFilter === "veg"
          ? [
              "🌅 Morning: 60g Roasted Chana Sattu Drink (14g Protein • ₹12)",
              "☀️ Lunch: 60g Soya Chunks Pulao + Mess Dal (36g Protein • ₹15)",
              "🔥 Evening: 50g Sprouted Kala Chana Chaat (12g Protein • ₹10)",
              "🌙 Dinner: 2 Roti + Dal + 1 Katori Dahi (22g Protein • ₹11)",
            ]
          : [
              "🌅 Morning: 3 Boiled Desi Anda + Chana (18g Protein • ₹21)",
              "☀️ Lunch: 50g Soya Chunks + Mess Dal-Chawal (32g Protein • ₹12)",
              "🔥 Evening: 2 Egg Whites + Roasted Peanuts (14g Protein • ₹10)",
              "🌙 Dinner: 3 Roti + Mess Dal Tadka (28g Protein • ₹5)",
            ],
    },
    "120": {
      title: "💵 ₹120/Day Balanced Muscle Recomp Plan",
      totalProtein: dietFilter === "veg" ? 112 : 126,
      totalCost: "₹115 / Day",
      meals:
        dietFilter === "veg"
          ? [
              "🌅 Morning: Oats + 2 tbsp Peanut Butter + Milk + Sattu (26g Protein • ₹30)",
              "☀️ Lunch: 100g Low-Fat Paneer Bhurji + 2 Roti + Dahi (32g Protein • ₹45)",
              "🔥 Post-Workout: 50g Soya Chunks Stir-Fry (26g Protein • ₹12)",
              "🌙 Dinner: Kala Chana Curry + Dal + Paneer Salad (28g Protein • ₹28)",
            ]
          : dietFilter === "egg"
          ? [
              "🌅 Morning: 4 Whole Eggs Masala Omelette + 2 Toast (28g Protein • ₹32)",
              "☀️ Lunch: 100g Paneer / Soya + Dal + Dahi (34g Protein • ₹40)",
              "🔥 Post-Workout: 5 Egg Whites Boiled (20g Protein • ₹25)",
              "🌙 Dinner: 2 Egg Bhurji + Dal + 2 Roti (44g Protein • ₹18)",
            ]
          : [
              "🌅 Morning: 3 Whole Boiled Eggs + Oats (24g Protein • ₹24)",
              "☀️ Lunch: 150g Chicken Breast Curry + Rice/Roti (42g Protein • ₹60)",
              "🔥 Post-Workout: 50g Soya Chunks / 3 Egg Whites (26g Protein • ₹15)",
              "🌙 Dinner: Dal + Dahi + 100g Paneer/Egg (34g Protein • ₹16)",
            ],
    },
    "250": {
      title: "💎 ₹250+/Day Aesthetics Beast Plan",
      totalProtein: dietFilter === "veg" ? 140 : 155,
      totalCost: "₹245 / Day",
      meals:
        dietFilter === "veg"
          ? [
              "🌅 Morning: 1 Scoop Whey Isolate + Oats + Almonds (32g Protein • ₹105)",
              "☀️ Lunch: 150g Paneer Tikka + Dal + Greek Yogurt/Dahi (42g Protein • ₹75)",
              "🔥 Post-Workout: 1 Scoop Plant/Whey Protein Shake (25g Protein • ₹45)",
              "🌙 Dinner: Tofu/Soya Steak + Mixed Sprouts Bowl (41g Protein • ₹20)",
            ]
          : [
              "🌅 Morning: 4 Eggs + Oats + Almonds (30g Protein • ₹45)",
              "☀️ Lunch: 200g Grilled Chicken Breast + Salad + Dahi (54g Protein • ₹85)",
              "🔥 Post-Workout: 1 Scoop Pure Whey Isolate (25g Protein • ₹95)",
              "🌙 Dinner: 150g Fish/Chicken/Paneer + Veggies (46g Protein • ₹20)",
            ],
    },
  }[budgetTier];

  const ALL_QUICK_PROTEIN_MEALS = [
    { name: "Paneer Cubes (100g)", protein: 18, icon: "🧀", diet: "veg" },
    { name: "Soya Chunks Bowl", protein: 26, icon: "🥘", diet: "veg" },
    { name: "Whey / Plant Shake", protein: 24, icon: "🥤", diet: "veg" },
    { name: "Roasted Kala Chana", protein: 15, icon: "🫘", diet: "veg" },
    { name: "Egg Whites (6)", protein: 24, icon: "🥚", diet: "egg" },
    { name: "Chicken Breast", protein: 30, icon: "🍗", diet: "nonveg" },
  ];

  const quickProteinMeals = ALL_QUICK_PROTEIN_MEALS.filter((m) => {
    if (dietFilter === "veg") return m.diet === "veg";
    if (dietFilter === "egg") return m.diet === "veg" || m.diet === "egg";
    return true;
  });

  // IDEA 4: DESI THALI BUILDER & SAMOSA TAX CALCULATOR STATE
  const ALL_DESI_THALI_ITEMS = [
    { id: "roti", name: "Wheat Roti", icon: "🫓", protein: 3, carbs: 15, fat: 1, kcal: 85, diet: "veg" },
    { id: "dal", name: "Dal Tadka (Katori)", icon: "🥣", protein: 7, carbs: 18, fat: 4, kcal: 140, diet: "veg" },
    { id: "paneer", name: "Paneer Bhurji (100g)", icon: "🧀", protein: 18, carbs: 4, fat: 14, kcal: 215, diet: "veg" },
    { id: "chole", name: "Kala Chana / Chole", icon: "🫘", protein: 12, carbs: 24, fat: 5, kcal: 190, diet: "veg" },
    { id: "dahi", name: "Desi Dahi (Bowl)", icon: "🥛", protein: 6, carbs: 7, fat: 4, kcal: 90, diet: "veg" },
    { id: "soya", name: "Soya Chunks (50g)", icon: "🥘", protein: 26, carbs: 16, fat: 1, kcal: 170, diet: "veg" },
    { id: "sattu", name: "Desi Sattu Drink", icon: "🌾", protein: 14, carbs: 28, fat: 3, kcal: 195, diet: "veg" },
    { id: "eggs", name: "2 Boiled Anda", icon: "🥚", protein: 12, carbs: 1, fat: 10, kcal: 140, diet: "egg" },
    { id: "chicken", name: "Desi Chicken Curry", icon: "🍗", protein: 28, carbs: 5, fat: 11, kcal: 235, diet: "nonveg" },
  ];

  const DESI_THALI_ITEMS = ALL_DESI_THALI_ITEMS.filter((item) => {
    if (dietFilter === "veg") return item.diet === "veg";
    if (dietFilter === "egg") return item.diet === "veg" || item.diet === "egg";
    return true;
  });

  const SAMOSA_TAX_SNACKS = [
    { id: "samosa", name: "1 Crispy Samosa", icon: "🥟", kcal: 260, squats: 85, pushups: 65, steps: 3200 },
    { id: "gulab", name: "2 Gulab Jamun", icon: "🍯", kcal: 350, squats: 115, pushups: 90, steps: 4300 },
    { id: "bhature", name: "Chole Bhature Plate", icon: "🍽️", kcal: 540, squats: 180, pushups: 140, steps: 6700 },
    { id: "momos", name: "8 Fried Momos", icon: "🥟", kcal: 380, squats: 125, pushups: 95, steps: 4700 },
    { id: "chai", name: "Masala Chai + 2 Parle-G", icon: "☕", kcal: 190, squats: 60, pushups: 45, steps: 2400 },
  ];

  const [thaliCounts, setThaliCounts] = useState<Record<string, number>>({
    roti: 2,
    dal: 1,
    paneer: 1,
    dahi: 1,
  });
  const [selectedSnackId, setSelectedSnackId] = useState<string>("samosa");
  const [thaliLoggedToast, setThaliLoggedToast] = useState<string | null>(null);

  const thaliTotals = DESI_THALI_ITEMS.reduce(
    (acc, item) => {
      const qty = thaliCounts[item.id] || 0;
      acc.protein += item.protein * qty;
      acc.carbs += item.carbs * qty;
      acc.fat += item.fat * qty;
      acc.kcal += item.kcal * qty;
      return acc;
    },
    { protein: 0, carbs: 0, fat: 0, kcal: 0 }
  );

  const activeSnack = SAMOSA_TAX_SNACKS.find((s) => s.id === selectedSnackId) || SAMOSA_TAX_SNACKS[0];

  // IDEA #5: DESI BUDGET PROTEIN & FAKE SUPPLEMENT PURITY CALCULATOR
  const ALL_DESI_PROTEIN_PRESETS = [
    { id: "soya", name: "Soya Chunks (100g)", servingG: 100, proteinG: 52, kcal: 345, priceRs: 18, diet: "veg" },
    { id: "whey", name: "Pure Whey Isolate (1 Scoop)", servingG: 32, proteinG: 25, kcal: 120, priceRs: 95, diet: "veg" },
    { id: "paneer", name: "Low-Fat Paneer (100g)", servingG: 100, proteinG: 18, kcal: 215, priceRs: 45, diet: "veg" },
    { id: "sattu", name: "Roasted Chana Sattu (100g)", servingG: 100, proteinG: 22, kcal: 360, priceRs: 20, diet: "veg" },
    { id: "eggs", name: "4 Boiled Eggs (Desi)", servingG: 200, proteinG: 24, kcal: 280, priceRs: 32, diet: "egg" },
    { id: "chicken", name: "Chicken Breast (150g)", servingG: 150, proteinG: 42, kcal: 245, priceRs: 65, diet: "nonveg" },
    { id: "scam_gainer", name: "Cheap Mass Gainer (Scam)", servingG: 100, proteinG: 12, kcal: 395, priceRs: 55, diet: "veg" },
  ];

  const DESI_PROTEIN_PRESETS = ALL_DESI_PROTEIN_PRESETS.filter((p) => {
    if (dietFilter === "veg") return p.diet === "veg";
    if (dietFilter === "egg") return p.diet === "veg" || p.diet === "egg";
    return true;
  });

  const [suppName, setSuppName] = useState<string>("Pure Whey Isolate (1 Scoop)");
  const [suppProteinG, setSuppProteinG] = useState<number>(25);
  const [suppKcal, setSuppKcal] = useState<number>(120);
  const [suppPriceRs, setSuppPriceRs] = useState<number>(95);

  // Protein Purity = (Protein Grams * 4 kcal) / Total Calories * 100
  const proteinCaloriePurity = Math.min(100, Math.round(((suppProteinG * 4) / Math.max(1, suppKcal)) * 100));
  // Cost in ₹ per 10g of pure protein
  const costPer10gProteinRs = Number(((suppPriceRs / Math.max(1, suppProteinG)) * 10).toFixed(1));
  const purityVerdict =
    proteinCaloriePurity >= 70
      ? { label: "ULTRA-PURE LEAN PROTEIN ✅", color: "text-emerald-400 border-emerald-500/40 bg-emerald-500/15" }
      : proteinCaloriePurity >= 38
      ? { label: "BALANCED WHOLE FOOD ⚖️", color: "text-[#14F1E1] border-[#14F1E1]/40 bg-[#14F1E1]/15" }
      : { label: "🚨 FAKE / CARB-SPIKED SCAM ALERT", color: "text-red-400 border-red-500/50 bg-red-500/20" };


  // Sync goals to local storage
  useEffect(() => {
    localStorage.setItem(GOALS_KEY, JSON.stringify(goals));
  }, [goals]);

  // Sync logs to local storage
  useEffect(() => {
    localStorage.setItem(LOGS_KEY, JSON.stringify(logs));
  }, [logs]);

  // Read current date's metrics
  const currentDateLog = logs[selectedDate] || { protein: 0, water: 0 };

  const handleUpdateIntake = (proteinDiff: number, waterDiff: number) => {
    const current = logs[selectedDate] || { protein: 0, water: 0 };
    const nextProtein = Math.max(0, current.protein + proteinDiff);
    const nextWater = Math.max(0, current.water + waterDiff);

    if (nextProtein > 200 || nextWater > 5000) {
      playSound("timer_pause");
      setErrorAlert("mujhe vishwas nahi ho raha hai ki aapne isse jyada consum kiya hoga");
      setTimeout(() => setErrorAlert(""), 4000);
      return;
    }

    playSound("click");
    setLogs((prev) => {
      const updated = { ...prev };
      
      updated[selectedDate] = {
        protein: nextProtein,
        water: nextWater,
      };

      // Play success sound if goal is reached by this addition
      const metProteinBefore = current.protein >= goals.proteinGoal;
      const metWaterBefore = current.water >= goals.waterGoal;
      const metProteinAfter = nextProtein >= goals.proteinGoal;
      const metWaterAfter = nextWater >= goals.waterGoal;

      if ((!metProteinBefore && metProteinAfter) || (!metWaterBefore && metWaterAfter)) {
        setTimeout(() => playSound("success"), 100);
      }

      return updated;
    });
  };

  const handleSaveGoals = (e: React.FormEvent) => {
    e.preventDefault();
    playSound("success");
    setGoals({
      proteinGoal: Math.max(20, Number(proteinGoalInput) || 100),
      waterGoal: Math.max(500, Number(waterGoalInput) || 3000),
    });
    setIsEditingGoals(false);
  };

  const requestResetCurrentDay = () => {
    setConfirmResetState({ isOpen: true });
  };

  const executeResetCurrentDay = () => {
    playSound("success");
    setLogs((prev) => {
      const updated = { ...prev };
      updated[selectedDate] = { protein: 0, water: 0 };
      return updated;
    });
  };

  // Convert date string of format YYYY-MM-DD to friendly human format
  const getFriendlyDateStr = (dateStr: string) => {
    const today = new Date().toISOString().split("T")[0];
    const yesterdayDate = new Date();
    yesterdayDate.setDate(yesterdayDate.getDate() - 1);
    const yesterday = yesterdayDate.toISOString().split("T")[0];

    if (dateStr === today) return "Today (आज)";
    if (dateStr === yesterday) return "Yesterday (कल)";

    const dateObj = new Date(dateStr);
    return dateObj.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
    });
  };

  // Navigate calendar day
  const changeDayBy = (daysOffset: number) => {
    playSound("click");
    const doc = new Date(selectedDate);
    doc.setDate(doc.getDate() + daysOffset);
    setSelectedDate(doc.toISOString().split("T")[0]);
  };

  // Progress calculations
  const proteinPercent = Math.min(Math.round((currentDateLog.protein / goals.proteinGoal) * 100), 100);
  const waterPercent = Math.min(Math.round((currentDateLog.water / goals.waterGoal) * 100), 100);

  // Suggested high-protein food cards for quick logging
  const quickProteinFoods = [
    { label: "🥚 2 Boiled Eggs", protein: 12, labelHi: "२ उबले अंडे" },
    { label: "🫘 Kala Chana (Bowl)", protein: 15, labelHi: "काला चना" },
    { label: "🥛 Whey Shake", protein: 25, labelHi: "व्हे प्रोटीन" },
    { label: "🧀 Paneer (100g)", protein: 18, labelHi: "पनीर १०० ग्राम" },
    { label: "🥜 Peanut Butter", protein: 8, labelHi: "पीनट बटर" },
    { label: "🫚 Tofu / Soya (100g)", protein: 14, labelHi: "सोयाबीन" },
  ];

  // Quick water units
  const quickWaterUnits = [
    { label: "🥛 Small Glass (250 ml)", amount: 250 },
    { label: "🍼 Shaker Bottle (500 ml)", amount: 500 },
    { label: "🧪 Large Bottle (1000 ml)", amount: 1000 },
  ];

  // Compute 7 days history for a mini-bar visual list
  const getPastSevenDaysArray = () => {
    const arr = [];
    const baseDate = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(baseDate);
      d.setDate(d.getDate() - i);
      const str = d.toISOString().split("T")[0];
      const log = logs[str] || { protein: 0, water: 0 };
      arr.push({
        dateStr: str,
        label: d.toLocaleDateString("en-US", { weekday: "narrow" }),
        ...log
      });
    }
    return arr;
  };

  const pastSevenDays = getPastSevenDaysArray();

  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#14F1E1]/30">
      <div className="p-4 md:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-white/5 border border-white/10 rounded-xl group">
            <Apple className="w-5 h-5 text-[#14F1E1]" />
          </div>
          <div>
            <h1 className="text-sm md:text-base font-black text-white uppercase tracking-widest">Nutrition & Diet</h1>
            <p className="text-[10px] text-neutral-500 font-bold tracking-widest uppercase mt-0.5">
              Auto-Filtered for {dietFilter === "veg" ? "Pure Vegetarian (No Egg/Meat)" : dietFilter === "egg" ? "Eggetarian (Veg + Anda)" : "Hardcore Non-Veg"}
            </p>
          </div>
        </div>

        {/* FEATURE #6: INLINE DIET & KITCHEN SWITCHER PILLS */}
        <div className="flex flex-wrap items-center gap-1.5">
          {[
            { id: "veg", label: "🌱 Pure Veg" },
            { id: "egg", label: "🥚 Eggetarian" },
            { id: "nonveg", label: "🍗 Non-Veg" },
          ].map((d) => (
            <button
              key={d.id}
              onClick={() => handleSelectDietFilter(d.id as any)}
              className={`px-2.5 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider border transition-all cursor-pointer ${
                dietFilter === d.id
                  ? "bg-[#14F1E1] text-black border-[#14F1E1] shadow-[0_0_12px_rgba(20,241,225,0.3)]"
                  : "bg-white/5 border-white/10 text-neutral-400 hover:text-white"
              }`}
            >
              {d.label}
            </button>
          ))}
          <button
            onClick={() =>
              handleSelectKitchenFilter(
                kitchenFilter === "hostel_mess" ? "home_kitchen" : "hostel_mess"
              )
            }
            className="px-2.5 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider border border-[#B66DFF]/40 bg-[#B66DFF]/15 text-[#B66DFF] cursor-pointer"
          >
            {kitchenFilter === "hostel_mess" ? "🍱 Hostel Mess" : "🏠 Home Kitchen"}
          </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#14F1E1]/5 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-4xl mx-auto space-y-8 relative z-10 pb-24" id="nutrition-log-container">
          <ConfirmModal
            isOpen={!!confirmResetState?.isOpen}
            message="Purge active telemetry? All logged fuel for this date will be wiped."
            onCancel={() => setConfirmResetState(null)}
            onConfirm={() => {
              if (confirmResetState) {
                requestResetCurrentDay();
                setConfirmResetState(null);
              }
            }}
          />

          {/* UPGRADED: 1-TAP VISUAL DESI MEAL & HOSTEL THALI BUILDER */}
          <VisualDesiThaliBuilder
            dietFilter={dietFilter}
            onLogThaliProtein={(proteinGrams, waterMl) =>
              handleUpdateIntake(proteinGrams, waterMl)
            }
          />

          {/* Goals Dashboard Card */}
          <div className="bg-gradient-to-br from-[#050B1A] to-[#0A1020] border border-[#14F1E1]/20 rounded-3xl p-6 md:p-8 shadow-[0_0_40px_rgba(20,241,225,0.05)] relative overflow-hidden">
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#14F1E1]/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="flex items-center justify-between mb-6 relative z-10">
              <h2 className="text-xl font-black uppercase tracking-tight text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-[#14F1E1]" /> Target Telemetry
              </h2>
              <button
                onClick={() => setIsEditingGoals(!isEditingGoals)}
                className="text-[10px] font-black uppercase bg-white/5 hover:bg-white/10 border border-white/10 px-4 py-2 rounded-lg text-neutral-400 hover:text-white transition-all flex items-center gap-2"
              >
                {isEditingGoals ? <X className="w-3.5 h-3.5" /> : <Settings className="w-3.5 h-3.5" />}
                {isEditingGoals ? "Close Settings" : "Configure Targets"}
              </button>
            </div>

            <AnimatePresence>
              {isEditingGoals && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden relative z-10"
                >
                  <div className="p-5 bg-black/40 border border-white/10 rounded-2xl mb-6">
                    <NutritionGoalModal goals={goals} onSaveGoals={handleSaveGoals} onClose={() => setIsEditingGoals(false)} />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center relative z-10">
              {/* 3D Concentric Plasma Macro Reactor (5 Cols) */}
              <div className="lg:col-span-5 flex flex-col items-center justify-center bg-[#040917]/90 border border-[#14F1E1]/25 rounded-3xl p-5 shadow-[inset_0_0_30px_rgba(20,241,225,0.08)] relative overflow-hidden">
                <div className="relative w-44 h-44 flex items-center justify-center">
                  {/* Outer Rotating 3D Gimbal Ring */}
                  <motion.div
                    animate={{ rotateZ: 360 }}
                    transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
                    className="absolute inset-0 rounded-full border border-dashed border-[#14F1E1]/30 pointer-events-none"
                  />
                  <svg viewBox="0 0 160 160" className="w-40 h-40 -rotate-90 overflow-visible">
                    {/* Outer Ring: Protein (#14F1E1) */}
                    <circle cx="80" cy="80" r="66" fill="none" stroke="rgba(20,241,225,0.12)" strokeWidth="9" />
                    <motion.circle
                      cx="80"
                      cy="80"
                      r="66"
                      fill="none"
                      stroke="#14F1E1"
                      strokeWidth="9"
                      strokeLinecap="round"
                      strokeDasharray={2 * Math.PI * 66}
                      animate={{
                        strokeDashoffset:
                          2 * Math.PI * 66 * (1 - Math.min(1, proteinPercent / 100)),
                      }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                      style={{ filter: "drop-shadow(0 0 8px rgba(20,241,225,0.65))" }}
                    />

                    {/* Middle Ring: Hydration (#B66DFF) */}
                    <circle cx="80" cy="80" r="52" fill="none" stroke="rgba(182,109,255,0.12)" strokeWidth="8" />
                    <motion.circle
                      cx="80"
                      cy="80"
                      r="52"
                      fill="none"
                      stroke="#B66DFF"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={2 * Math.PI * 52}
                      animate={{
                        strokeDashoffset:
                          2 * Math.PI * 52 * (1 - Math.min(1, waterPercent / 100)),
                      }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                      style={{ filter: "drop-shadow(0 0 8px rgba(182,109,255,0.6))" }}
                    />

                    {/* Inner Ring: Thali Carbs & Fat Energy (#FFB703) */}
                    <circle cx="80" cy="80" r="38" fill="none" stroke="rgba(255,183,3,0.12)" strokeWidth="7" />
                    <motion.circle
                      cx="80"
                      cy="80"
                      r="38"
                      fill="none"
                      stroke="#FFB703"
                      strokeWidth="7"
                      strokeLinecap="round"
                      strokeDasharray={2 * Math.PI * 38}
                      animate={{
                        strokeDashoffset:
                          2 *
                          Math.PI *
                          38 *
                          (1 - Math.min(1, thaliTotals.kcal / 1200)),
                      }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                    />
                  </svg>

                  {/* Center 3D Core Telemetry Readout */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
                    <span className="text-[8px] font-mono font-black uppercase tracking-widest text-[#14F1E1]">
                      BIO-REACTOR
                    </span>
                    <span className="text-xl font-black font-mono text-white leading-tight">
                      {Math.round((proteinPercent + waterPercent) / 2)}%
                    </span>
                    <span className="text-[8px] font-mono text-neutral-400 uppercase">
                      Daily Sync
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3 mt-2 text-[9px] font-mono font-bold uppercase">
                  <span className="flex items-center gap-1 text-[#14F1E1]">
                    <span className="w-2 h-2 rounded-full bg-[#14F1E1]" /> Protein {proteinPercent}%
                  </span>
                  <span className="flex items-center gap-1 text-[#B66DFF]">
                    <span className="w-2 h-2 rounded-full bg-[#B66DFF]" /> Water {waterPercent}%
                  </span>
                  <span className="flex items-center gap-1 text-[#FFB703]">
                    <span className="w-2 h-2 rounded-full bg-[#FFB703]" /> Thali
                  </span>
                </div>
              </div>

              {/* 4 Macro Stat Cards (7 Cols) */}
              <div className="lg:col-span-7 grid grid-cols-2 gap-4">
                <div className="bg-white/5 border border-white/10 p-5 rounded-2xl text-center shadow-inner group hover:bg-[#14F1E1]/5 hover:border-[#14F1E1]/30 transition-all">
                  <div className="text-[10px] font-black uppercase text-neutral-400 tracking-widest mb-1 group-hover:text-[#14F1E1]">Protein Target</div>
                  <div className="text-2xl font-black text-white font-mono">
                    {currentDateLog.protein} <span className="text-sm text-neutral-500">/ {goals.proteinGoal}g</span>
                  </div>
                </div>
                <div className="bg-white/5 border border-white/10 p-5 rounded-2xl text-center shadow-inner group hover:bg-[#B66DFF]/5 hover:border-[#B66DFF]/30 transition-all">
                  <div className="text-[10px] font-black uppercase text-neutral-400 tracking-widest mb-1 group-hover:text-[#B66DFF]">Water Target</div>
                  <div className="text-2xl font-black text-white font-mono">
                    {(currentDateLog.water / 1000).toFixed(1)} <span className="text-sm text-neutral-500">/ {(goals.waterGoal / 1000).toFixed(1)}L</span>
                  </div>
                </div>
                <div className="bg-white/5 border border-white/10 p-5 rounded-2xl text-center shadow-inner group hover:bg-amber-500/5 hover:border-amber-500/30 transition-all">
                  <div className="text-[10px] font-black uppercase text-neutral-400 tracking-widest mb-1 group-hover:text-amber-500">Thali Fat</div>
                  <div className="text-2xl font-black text-white font-mono">{thaliTotals.fat}<span className="text-xs text-neutral-500 ml-1">g</span></div>
                </div>
                <div className="bg-white/5 border border-white/10 p-5 rounded-2xl text-center shadow-inner group hover:bg-blue-500/5 hover:border-blue-500/30 transition-all">
                  <div className="text-[10px] font-black uppercase text-neutral-400 tracking-widest mb-1 group-hover:text-blue-500">Thali Carbs</div>
                  <div className="text-2xl font-black text-white font-mono">{thaliTotals.carbs}<span className="text-xs text-neutral-500 ml-1">g</span></div>
                </div>
              </div>
            </div>
          </div>

          {/* IDEA 4: DESI THALI BUILDER & SAMOSA TAX BURN CALCULATOR */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Virtual Desi Thali Builder (7 Cols) */}
            <div className="lg:col-span-7 bg-gradient-to-br from-[#0D1328] to-[#050B1A] border border-[#14F1E1]/30 rounded-3xl p-6 shadow-[0_0_35px_rgba(20,241,225,0.06)] flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <span className="text-[9px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-[#14F1E1]/15 text-[#14F1E1] border border-[#14F1E1]/30">
                      INDIAN HOME MEAL MACROS
                    </span>
                    <h3 className="text-lg font-black uppercase tracking-tight text-white mt-1.5 flex items-center gap-2">
                      <UtensilsCrossed className="w-5 h-5 text-[#14F1E1]" /> Desi Thali Builder
                    </h3>
                  </div>
                  <div className="text-right bg-black/50 border border-white/10 px-3.5 py-2 rounded-2xl">
                    <span className="text-[9px] font-mono uppercase text-neutral-400 block">Plate Macros</span>
                    <span className="text-base font-black font-mono text-[#14F1E1]">{thaliTotals.protein}g Protein</span>
                    <span className="text-[10px] font-mono text-amber-400 block">{thaliTotals.kcal} kcal</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {DESI_THALI_ITEMS.map((item) => {
                    const count = thaliCounts[item.id] || 0;
                    return (
                      <div
                        key={item.id}
                        className={`p-3 rounded-2xl border transition-all flex flex-col justify-between ${
                          count > 0
                            ? "bg-[#14F1E1]/10 border-[#14F1E1]/50 shadow-[0_0_15px_rgba(20,241,225,0.1)]"
                            : "bg-black/40 border-white/10"
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <span className="text-xl">{item.icon}</span>
                            <span className="text-[10px] font-mono font-black text-[#14F1E1]">+{item.protein}g P</span>
                          </div>
                          <p className="text-[11px] font-bold text-white mt-1.5 leading-tight">{item.name}</p>
                          <p className="text-[9px] font-mono text-neutral-400">{item.kcal} kcal</p>
                        </div>

                        <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/10">
                          <button
                            onClick={() => {
                              playSound("click");
                              setThaliCounts((prev) => ({
                                ...prev,
                                [item.id]: Math.max(0, (prev[item.id] || 0) - 1),
                              }));
                            }}
                            className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-xs font-black cursor-pointer"
                          >
                            -
                          </button>
                          <span className="text-xs font-mono font-black text-white">{count}</span>
                          <button
                            onClick={() => {
                              playSound("click");
                              setThaliCounts((prev) => ({
                                ...prev,
                                [item.id]: Math.min(10, (prev[item.id] || 0) + 1),
                              }));
                            }}
                            className="w-6 h-6 rounded-lg bg-[#14F1E1] text-black flex items-center justify-center text-xs font-black cursor-pointer"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="text-xs text-neutral-400 font-mono">
                  Total: <span className="text-white font-bold">{thaliTotals.protein}g P</span> •{" "}
                  <span className="text-white font-bold">{thaliTotals.carbs}g C</span> •{" "}
                  <span className="text-white font-bold">{thaliTotals.fat}g F</span>
                </div>
                <button
                  onClick={() => {
                    if (thaliTotals.protein <= 0) return;
                    handleUpdateIntake(thaliTotals.protein, 250);
                    setThaliLoggedToast(`+${thaliTotals.protein}g Thali Protein & 250ml Water Logged!`);
                    setTimeout(() => setThaliLoggedToast(null), 3500);
                  }}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#14F1E1] to-[#00B4D8] text-black font-black text-xs uppercase tracking-widest shadow-[0_0_15px_rgba(20,241,225,0.3)] hover:brightness-110 active:scale-95 transition-all cursor-pointer"
                >
                  Log Thali (+{thaliTotals.protein}g Protein)
                </button>
              </div>

              {thaliLoggedToast && (
                <div className="mt-3 p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold text-center">
                  {thaliLoggedToast}
                </div>
              )}
            </div>

            {/* "Samosa Tax" Cheat Meal Rep Calculator (5 Cols) */}
            <div className="lg:col-span-5 bg-gradient-to-br from-[#1A0D1E] via-[#0D0B18] to-[#050B1A] border border-amber-500/30 rounded-3xl p-6 shadow-[0_0_35px_rgba(245,158,11,0.08)] flex flex-col justify-between">
              <div>
                <span className="text-[9px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  CHEAT MEAL REP PENALTY
                </span>
                <h3 className="text-lg font-black uppercase tracking-tight text-white mt-1.5 flex items-center gap-2">
                  <Flame className="w-5 h-5 text-amber-400" /> &ldquo;Samosa Tax&rdquo; Calculator
                </h3>
                <p className="text-xs text-neutral-400 mt-1">
                  Ate street food? See the exact workout tax required to burn it off!
                </p>

                <div className="space-y-2 mt-4">
                  {SAMOSA_TAX_SNACKS.map((snack) => {
                    const isSelected = snack.id === selectedSnackId;
                    return (
                      <button
                        key={snack.id}
                        onClick={() => {
                          playSound("click");
                          setSelectedSnackId(snack.id);
                        }}
                        className={`w-full p-3 rounded-2xl border text-left transition-all flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? "bg-amber-500/15 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.2)]"
                            : "bg-black/40 border-white/10 hover:border-white/20"
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="text-xl">{snack.icon}</span>
                          <div>
                            <p className="text-xs font-black text-white uppercase tracking-wide">{snack.name}</p>
                            <p className="text-[10px] font-mono text-amber-400 font-bold">{snack.kcal} KCAL</p>
                          </div>
                        </div>
                        <ChevronRight className={`w-4 h-4 ${isSelected ? "text-amber-400" : "text-neutral-600"}`} />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Tax Breakdown Box */}
              <div className="mt-4 bg-black/60 border border-amber-500/30 rounded-2xl p-4">
                <span className="text-[9px] font-mono uppercase tracking-widest text-amber-300 font-bold block mb-2">
                  WORKOUT TAX TO BURN {activeSnack.kcal} KCAL:
                </span>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-white/5 rounded-xl p-2 border border-white/10">
                    <span className="text-base font-black font-mono text-[#14F1E1] block">{activeSnack.squats}</span>
                    <span className="text-[9px] font-bold uppercase text-neutral-400">AI Squats</span>
                  </div>
                  <div className="bg-white/5 rounded-xl p-2 border border-white/10">
                    <span className="text-base font-black font-mono text-[#B66DFF] block">{activeSnack.pushups}</span>
                    <span className="text-[9px] font-bold uppercase text-neutral-400">Pushups</span>
                  </div>
                  <div className="bg-white/5 rounded-xl p-2 border border-white/10">
                    <span className="text-base font-black font-mono text-amber-400 block">{activeSnack.steps}</span>
                    <span className="text-[9px] font-bold uppercase text-neutral-400">Steps</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* IDEA #3: POCKET BUDGET SLIDER (₹50 STUDENT VS ₹120 BALANCED VS ₹250+ BEAST) */}
          <div className="bg-gradient-to-br from-[#0A191E] via-[#0D1328] to-[#050B1A] border border-emerald-500/35 rounded-3xl p-6 md:p-7 shadow-[0_0_35px_rgba(16,185,129,0.08)] space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[9px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  ✨ IDEA #3 & #10 • MATCHED FOR YOUR POCKET & {dietFilter.toUpperCase()} DIET
                </span>
                <h3 className="text-lg font-black uppercase tracking-tight text-white mt-1.5">
                  💰 Daily Pocket Budget Protein Blueprint
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Har jeb ke hisaab se 100% real protein — select your daily food budget:
                </p>
              </div>
              <div className="text-right bg-black/50 border border-white/10 px-4 py-2 rounded-2xl shrink-0">
                <span className="text-[9px] font-mono uppercase text-neutral-400 block">Daily Output</span>
                <span className="text-base font-black font-mono text-emerald-400">
                  {budgetMealBlueprint.totalProtein}g Protein
                </span>
                <span className="text-[10px] font-mono text-amber-300 block">
                  {budgetMealBlueprint.totalCost}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { id: "50", label: "🪙 ₹50/Day (Student)" },
                { id: "120", label: "💵 ₹120/Day (Regular)" },
                { id: "250", label: "💎 ₹250+/Day (Beast)" },
              ].map((b) => (
                <button
                  key={b.id}
                  onClick={() => handleSelectBudgetTier(b.id as any)}
                  className={`py-2.5 px-3 rounded-2xl text-xs font-black uppercase tracking-wider border transition-all cursor-pointer ${
                    budgetTier === b.id
                      ? "bg-emerald-400 text-black border-emerald-400 shadow-[0_0_15px_rgba(52,211,153,0.3)]"
                      : "bg-black/40 border-white/10 text-neutral-400 hover:text-white"
                  }`}
                >
                  {b.label}
                </button>
              ))}
            </div>

            <div className="bg-black/50 border border-white/10 rounded-2xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-white">
                  {budgetMealBlueprint.title}
                </span>
                <span className="text-[10px] font-mono text-[#14F1E1]">
                  {kitchenFilter === "hostel_mess" ? "🍱 Hostel-Friendly" : "🏠 Home Kitchen"}
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-1">
                {budgetMealBlueprint.meals.map((mealLine, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-xs text-neutral-200 font-semibold"
                  >
                    {mealLine}
                  </div>
                ))}
              </div>
              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => {
                    handleUpdateIntake(Math.round(budgetMealBlueprint.totalProtein / 3), 300);
                    setThaliLoggedToast(
                      `+${Math.round(budgetMealBlueprint.totalProtein / 3)}g Budget Meal Protein Logged!`
                    );
                    setTimeout(() => setThaliLoggedToast(null), 3500);
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-400 text-black text-[10px] font-black uppercase tracking-widest hover:brightness-110 cursor-pointer"
                >
                  + Log 1 Meal From My ₹{budgetTier} Plan (+{Math.round(budgetMealBlueprint.totalProtein / 3)}g P)
                </button>
              </div>
            </div>
          </div>

          {/* IDEA #1 & #6: PRE-WORKOUT DESI BOOSTER LAB & OUTSIDE/MESS CHEAT SURVIVAL GUIDE */}
          <DesiFuelBoosterAndSurvival
            dietFilter={dietFilter}
            onLogBonusMacros={(proteinG, waterMl, label) => {
              handleUpdateIntake(proteinG, waterMl);
              setThaliLoggedToast(`+${proteinG}g Protein & +${waterMl}ml Water Logged (${label})!`);
              setTimeout(() => setThaliLoggedToast(null), 3500);
            }}
          />

          {/* IDEA #5: DESI BUDGET PROTEIN & FAKE SUPPLEMENT PURITY SCANNER ("BAZAAR LABEL BUSTER") */}
          <div className="bg-gradient-to-br from-[#0D1328] via-[#080F22] to-[#050B1A] border border-[#B66DFF]/30 rounded-3xl p-6 md:p-7 shadow-[0_0_35px_rgba(182,109,255,0.08)] space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[9px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-[#B66DFF]/20 text-[#B66DFF] border border-[#B66DFF]/40">
                  FAKE SUPPLEMENT & STUDENT BUDGET DETECTOR
                </span>
                <h3 className="text-lg font-black uppercase tracking-tight text-white mt-1.5 flex items-center gap-2">
                  <Scale className="w-5 h-5 text-[#B66DFF]" /> Desi Protein Purity & ₹ Cost-Per-10g Analyzer
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Check if a supplement packet is spiked with cheap carbs/sugar, and compare ₹ cost per 10g of real protein!
                </p>
              </div>
            </div>

            {/* Quick Presets */}
            <div className="flex flex-wrap gap-2">
              {DESI_PROTEIN_PRESETS.map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    playSound("click");
                    setSuppName(p.name);
                    setSuppProteinG(p.proteinG);
                    setSuppKcal(p.kcal);
                    setSuppPriceRs(p.priceRs);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider border transition-all cursor-pointer ${
                    suppName === p.name
                      ? "bg-[#B66DFF] text-black border-[#B66DFF]"
                      : "bg-black/40 border-white/10 text-neutral-400 hover:text-white"
                  }`}
                >
                  {p.name} (₹{p.priceRs})
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
              {/* Inputs */}
              <div className="md:col-span-7 grid grid-cols-3 gap-3 bg-black/50 border border-white/10 rounded-2xl p-4">
                <div>
                  <label className="text-[9px] font-mono uppercase text-neutral-400 block mb-1">
                    Protein / Serve (g)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={suppProteinG}
                    onChange={(e) => setSuppProteinG(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm font-mono font-black text-white focus:outline-none focus:border-[#14F1E1]"
                  />
                </div>
                <div>
                  <label className="text-[9px] font-mono uppercase text-neutral-400 block mb-1">
                    Total Calories
                  </label>
                  <input
                    type="number"
                    min={10}
                    max={1500}
                    value={suppKcal}
                    onChange={(e) => setSuppKcal(Math.max(10, Number(e.target.value)))}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm font-mono font-black text-white focus:outline-none focus:border-[#14F1E1]"
                  />
                </div>
                <div>
                  <label className="text-[9px] font-mono uppercase text-neutral-400 block mb-1">
                    Price / Serve (₹)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={1000}
                    value={suppPriceRs}
                    onChange={(e) => setSuppPriceRs(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm font-mono font-black text-amber-400 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Purity & Budget Output */}
              <div className="md:col-span-5 bg-black/60 border border-white/15 rounded-2xl p-4 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase text-neutral-400">Protein Calorie Purity</span>
                  <span className="text-lg font-black font-mono text-[#14F1E1]">{proteinCaloriePurity}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase text-neutral-400">Budget Cost / 10g Protein</span>
                  <span className="text-lg font-black font-mono text-amber-400">₹{costPer10gProteinRs}</span>
                </div>
                <div className={`px-3 py-1.5 rounded-xl border text-[10px] font-black uppercase text-center ${purityVerdict.color}`}>
                  {purityVerdict.label}
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* FUEL LOGGING */}
            <div className="bg-[#050B1A] border border-[#B66DFF]/20 rounded-3xl p-6 md:p-8 shadow-[0_0_40px_rgba(182,109,255,0.05)] relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#B66DFF]/10 rounded-full blur-[50px] pointer-events-none" />
              
              <div className="flex items-center justify-between mb-6 relative z-10">
                <h3 className="text-lg font-black uppercase tracking-tight text-white flex items-center gap-2">
                  <Flame className="w-5 h-5 text-[#B66DFF]" /> Fuel Logging
                </h3>
              </div>
              
              <div className="space-y-6 relative z-10">
                <div className="space-y-2">
                  <div className="flex justify-between items-end">
                    <div>
                      <span className="text-[10px] font-black uppercase text-neutral-500 tracking-[0.2em] block mb-1">Current Intake</span>
                      <div className="text-3xl font-black text-[#B66DFF] tracking-tighter">
                        {currentDateLog.protein} / {goals.proteinGoal} <span className="text-sm text-neutral-500">g</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="w-full h-3 bg-black/50 border border-white/10 rounded-full overflow-hidden relative">
                    <motion.div
                      className="h-full bg-gradient-to-r from-[#B66DFF] to-purple-400"
                      initial={{ width: 0 }}
                      animate={{ width: `${proteinPercent}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                  
                  <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-widest text-neutral-500 pt-1">
                    <span>0%</span>
                    {currentDateLog.protein >= goals.proteinGoal ? (
                      <span className="text-[#B66DFF] animate-pulse">Optimal Levels Reached!</span>
                    ) : (
                      <span>Req: {Math.max(0, goals.proteinGoal - currentDateLog.protein)}g</span>
                    )}
                    <span>100%</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-[10px] font-black uppercase text-neutral-400 tracking-[0.2em] mb-4">Quick Deploy Macros</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {quickProteinMeals.map((meal) => (
                      <button
                        key={meal.name}
                        onClick={() => handleUpdateIntake(meal.protein, 0)}
                        className="bg-white/5 border border-white/10 hover:border-[#B66DFF]/40 hover:bg-[#B66DFF]/5 rounded-xl p-3 flex flex-col items-center justify-center text-center transition-all group active:scale-95"
                      >
                        <span className="text-lg mb-1">{meal.icon}</span>
                        <span className="text-[9px] font-bold text-neutral-300 uppercase tracking-widest group-hover:text-white mb-0.5">{meal.name}</span>
                        <span className="text-[10px] font-black text-[#B66DFF]">+{meal.protein}g</span>
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-[10px] font-black uppercase text-neutral-400 tracking-[0.2em] mb-4">Manual Input Override</h4>
                  <div className="flex gap-2 bg-black/40 border border-white/10 p-2 rounded-2xl">
                    <button onClick={() => handleUpdateIntake(-10, 0)} className="w-10 h-10 shrink-0 bg-white/5 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 border border-white/5 font-black text-sm">-10</button>
                    <input 
                      type="number" 
                      placeholder="Custom g"
                      value={customProteinInput}
                      onChange={(e) => setCustomProteinInput(e.target.value)}
                      className="flex-1 min-w-0 bg-transparent text-center text-sm font-bold text-white focus:outline-none placeholder:text-neutral-600"
                    />
                    <button 
                      onClick={() => {
                        const val = parseInt(customProteinInput);
                        if (!isNaN(val) && val > 0) {
                          handleUpdateIntake(val, 0);
                          setCustomProteinInput("");
                        }
                      }}
                      className="w-10 h-10 shrink-0 bg-[#B66DFF]/20 text-[#B66DFF] rounded-xl hover:bg-[#B66DFF] hover:text-black border border-[#B66DFF]/30 font-black text-sm transition-colors"
                    >
                      <Plus className="w-4 h-4 mx-auto" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* HYDRATION */}
            <div className="bg-[#050B1A] border border-[#14F1E1]/20 rounded-3xl p-6 md:p-8 shadow-[0_0_40px_rgba(20,241,225,0.05)] relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#14F1E1]/10 rounded-full blur-[50px] pointer-events-none" />
              
              <div className="flex items-center justify-between mb-6 relative z-10">
                <h3 className="text-lg font-black uppercase tracking-tight text-white flex items-center gap-2">
                  <Droplet className="w-5 h-5 text-[#14F1E1]" /> Hydration Metrics
                </h3>
              </div>
              
              <div className="space-y-6 relative z-10">
                <div className="space-y-2">
                  <div className="flex justify-between items-end">
                    <div>
                      <span className="text-[10px] font-black uppercase text-neutral-500 tracking-[0.2em] block mb-1">Fluid Intake</span>
                      <div className="text-3xl font-black text-[#14F1E1] tracking-tighter">
                        {(currentDateLog.water / 1000).toFixed(2)} / {(goals.waterGoal / 1000).toFixed(1)} <span className="text-sm text-neutral-500">L</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="w-full h-3 bg-black/50 border border-white/10 rounded-full overflow-hidden relative">
                    <motion.div
                      className="h-full bg-gradient-to-r from-[#14F1E1] to-cyan-400"
                      initial={{ width: 0 }}
                      animate={{ width: `${waterPercent}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                  
                  <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-widest text-neutral-500 pt-1">
                    <span>0%</span>
                    {currentDateLog.water >= goals.waterGoal ? (
                      <span className="text-[#14F1E1] animate-pulse">Hydration Target Secure!</span>
                    ) : (
                      <span>Req: {Math.max(0, goals.waterGoal - currentDateLog.water)} ml</span>
                    )}
                    <span>100%</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-[10px] font-black uppercase text-neutral-400 tracking-[0.2em] mb-4">Quick Deploy Fluids</h4>
                  <div className="grid grid-cols-3 gap-2">
                    {quickWaterUnits.map((unit) => (
                      <button
                        key={unit.label}
                        onClick={() => handleUpdateIntake(0, unit.amount)}
                        className="bg-white/5 border border-white/10 hover:border-[#14F1E1]/40 hover:bg-[#14F1E1]/5 rounded-xl py-3 px-2 flex flex-col items-center justify-center text-center transition-all group active:scale-95"
                      >
                        <span className="text-[10px] font-bold text-neutral-300 uppercase tracking-widest group-hover:text-white mb-1 line-clamp-1 truncate w-full">{unit.label.split(" (")[0]}</span>
                        <span className="text-xs font-black text-[#14F1E1]">+{unit.amount}ml</span>
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-[10px] font-black uppercase text-neutral-400 tracking-[0.2em] mb-4">Manual Input Override</h4>
                  <div className="flex gap-2">
                    <button onClick={() => handleUpdateIntake(0, -100)} className="flex-1 py-3 bg-white/5 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 border border-white/5 font-black text-sm uppercase tracking-widest">-100 ML</button>
                    <button onClick={() => handleUpdateIntake(0, 100)} className="flex-1 py-3 bg-[#14F1E1]/10 text-[#14F1E1] border border-[#14F1E1]/30 rounded-xl hover:bg-[#14F1E1]/20 font-black text-sm uppercase tracking-widest transition-colors">+100 ML</button>
                    <button onClick={() => handleUpdateIntake(0, 250)} className="flex-1 py-3 bg-[#14F1E1]/10 text-[#14F1E1] border border-[#14F1E1]/30 rounded-xl hover:bg-[#14F1E1]/20 font-black text-sm uppercase tracking-widest transition-colors">+250 ML</button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 7-Day History Chart */}
          <div className="bg-[#050B1A] border border-white/10 rounded-3xl p-6 md:p-8 shadow-[0_0_40px_rgba(255,255,255,0.02)] relative overflow-hidden">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-sm font-black uppercase tracking-[0.2em] text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" /> Consistency Graph
              </h3>
              <button
                onClick={requestResetCurrentDay}
                className="text-[9px] font-black uppercase text-rose-500 hover:text-rose-400 transition-colors flex items-center gap-1 bg-rose-500/10 px-3 py-1.5 rounded-lg border border-rose-500/20"
              >
                <RotateCcw className="w-3 h-3" /> Purge Day
              </button>
            </div>
            
            <div className="grid grid-cols-7 gap-2 md:gap-4">
              {pastSevenDays.map((day) => {
                const isSelected = day.dateStr === selectedDate;
                const metProtein = day.protein >= goals.proteinGoal;
                const metWater = day.water >= goals.waterGoal;
                
                return (
                  <div
                    key={day.dateStr}
                    onClick={() => { playSound("click"); setSelectedDate(day.dateStr); }}
                    className={`p-3 rounded-2xl text-center cursor-pointer transition-all border flex flex-col items-center justify-between min-h-[90px] ${
                      isSelected
                        ? "bg-[#14F1E1]/10 border-[#14F1E1]/50 shadow-[0_0_15px_rgba(20,241,225,0.15)] transform scale-105"
                        : "bg-black/40 border-white/5 hover:bg-white/5 hover:border-white/20"
                    }`}
                  >
                    <div className={`text-[9px] font-black uppercase tracking-widest ${isSelected ? "text-white" : "text-neutral-500"}`}>
                      {day.label}
                    </div>
                    
                    <div className="flex gap-1.5 mt-2">
                      <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-black ${
                        metProtein ? "bg-[#B66DFF] text-black shadow-[0_0_10px_rgba(182,109,255,0.4)]" : day.protein > 0 ? "bg-[#B66DFF]/20 text-[#B66DFF] border border-[#B66DFF]/30" : "bg-white/5 border border-white/10 text-neutral-600"
                      }`}>P</div>
                      <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-black ${
                        metWater ? "bg-[#14F1E1] text-black shadow-[0_0_10px_rgba(20,241,225,0.4)]" : day.water > 0 ? "bg-[#14F1E1]/20 text-[#14F1E1] border border-[#14F1E1]/30" : "bg-white/5 border border-white/10 text-neutral-600"
                      }`}>W</div>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="flex items-center justify-center gap-6 mt-6 pt-4 border-t border-white/10">
              <div className="flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-neutral-400">
                <span className="w-2 h-2 rounded-full bg-[#B66DFF]" /> Fuel Validated
              </div>
              <div className="flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-neutral-400">
                <span className="w-2 h-2 rounded-full bg-[#14F1E1]" /> Hydration Validated
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function NutritionGoalModal({ goals, onSaveGoals, onClose }: { goals: any, onSaveGoals: any, onClose: any }) { return null; }
