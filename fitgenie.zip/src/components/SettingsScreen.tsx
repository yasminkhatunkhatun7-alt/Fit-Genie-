import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, User, Shield, Book, Bell, HelpCircle, Mail, AlertTriangle, X, LogOut, Loader2, Check, Gift, Code } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { db } from "../lib/firebase";
import { doc, getDoc, updateDoc, collection, query, where, getDocs, writeBatch, addDoc } from "firebase/firestore";
import DeveloperProfileView from "./DeveloperProfileView";

interface SettingsScreenProps {
  onBack: () => void;
  onNavigateToView?: (view: string) => void;
}

export default function SettingsScreen({ onBack, onNavigateToView }: SettingsScreenProps) {
  const { profile, user, signOutUser } = useAuth();
  const [activeSection, setActiveSection] = useState<string | null>(null);

  if (activeSection === "developer") {
    return <DeveloperProfileView onBack={() => setActiveSection(null)} />;
  }

  if (activeSection) {
    return <SettingsDetail section={activeSection} onBack={() => setActiveSection(null)} onNavigateToView={onNavigateToView} />;
  }

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-[#050B1A] relative z-50">
      {/* Header */}
      <div className="p-4 border-b border-[#1A2642] bg-[#0A1128] flex items-center gap-3 shrink-0">
        <button onClick={onBack} className="p-2 rounded-lg hover:bg-white/5 text-white transition-colors">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div>
          <h1 className="text-xl font-black uppercase tracking-tight text-white leading-none">Settings</h1>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-6">
        <SettingsGroup 
          title="Account" 
          items={[
            { icon: User, label: "Edit Profile & Username", onClick: () => setActiveSection("account") },
          ]} 
        />
        
        <SettingsGroup 
          title="Rewards" 
          items={[
            { icon: Gift, label: "Redeem Promo Code", onClick: () => setActiveSection("promo") },
          ]} 
        />
        
        <SettingsGroup 
          title="Privacy & Safety" 
          items={[
            { icon: Shield, label: "Privacy Policy", onClick: () => setActiveSection("privacy") },
            { icon: Shield, label: "Profile Visibility", onClick: () => setActiveSection("visibility") },
            { icon: Shield, label: "Blocked Users", onClick: () => setActiveSection("blocked") },
          ]} 
        />
        
        <SettingsGroup 
          title="Game Rules" 
          items={[
            { icon: Book, label: "Game Rules & Terms", onClick: () => setActiveSection("rules") },
          ]} 
        />
        
        <SettingsGroup 
          title="Notifications" 
          items={[
            { icon: Bell, label: "Notification Preferences", onClick: () => setActiveSection("notifications") },
          ]} 
        />

        <SettingsGroup 
          title="Support & About" 
          items={[
            { icon: Code, label: "Meet the Developer", onClick: () => setActiveSection("developer") },
            { icon: HelpCircle, label: "About Fit Genie", onClick: () => setActiveSection("about") },
            { icon: Mail, label: "Support & Feedback", onClick: () => setActiveSection("support") },
          ]} 
        />

        <div className="pt-4 pb-8 space-y-4">
          <button onClick={signOutUser} className="w-full flex items-center justify-center gap-2 p-4 rounded-xl bg-white/5 text-white font-bold uppercase tracking-widest text-xs hover:bg-white/10 transition-colors">
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
          <button onClick={() => setActiveSection("delete_account")} className="w-full flex items-center justify-center gap-2 p-4 rounded-xl bg-red-500/10 text-red-500 font-black uppercase tracking-widest text-xs hover:bg-red-500/20 transition-colors border border-red-500/20">
            <AlertTriangle className="w-4 h-4" /> Delete Account
          </button>
        </div>
      </div>
    </div>
  );
}

function SettingsGroup({ title, items }: { title: string, items: any[] }) {
  return (
    <div>
      <h3 className="text-[10px] font-black uppercase tracking-widest text-[#B66DFF] mb-2 ml-1">{title}</h3>
      <div className="bg-[#0A1128] border border-[#1A2642] rounded-2xl overflow-hidden">
        {items.map((item, i) => (
          <button 
            key={i} 
            onClick={item.onClick}
            className={`w-full flex items-center justify-between p-4 bg-transparent hover:bg-white/5 transition-colors text-left ${i !== items.length - 1 ? 'border-b border-[#1A2642]' : ''}`}
          >
            <div className="flex items-center gap-3">
              <item.icon className="w-5 h-5 text-brand-muted" />
              <span className="text-sm font-bold text-white">{item.label}</span>
            </div>
            <ChevronLeft className="w-5 h-5 text-brand-muted rotate-180" />
          </button>
        ))}
      </div>
    </div>
  );
}

// Settings Detail Component handles sub-screens
function SettingsDetail({ section, onBack, onNavigateToView }: { section: string, onBack: () => void, onNavigateToView?: (v: string) => void }) {
  const { profile, signOutUser } = useAuth();
  
  // Renders the correct subscreen
  return (
    <div className="flex-1 flex flex-col min-h-0 bg-[#050B1A] relative z-50">
      <div className="p-4 border-b border-[#1A2642] bg-[#0A1128] flex items-center gap-3 shrink-0">
        <button onClick={onBack} className="p-2 rounded-lg hover:bg-white/5 text-white transition-colors">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div>
          <h1 className="text-lg font-black uppercase tracking-tight text-white leading-none">
            {section === "developer" ? "The Architect" :
             section === "account" ? "Edit Profile" :
             section === "privacy" ? "Privacy Policy" :
             section === "visibility" ? "Profile Visibility" :
             section === "blocked" ? "Blocked Users" :
             section === "rules" ? "Game Rules & Terms" :
             section === "notifications" ? "Notifications" :
             section === "about" ? "About Fit Genie" :
             section === "support" ? "Support & Feedback" :
             section === "promo" ? "Redeem Code" :
             section === "delete_account" ? "Delete Account" : "Settings"}
          </h1>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
        {section === "developer" && <DeveloperProfileView onBack={onBack} />}
        {section === "account" && <AccountEdit />}
        {section === "promo" && <PromoCode />}
        {section === "privacy" && <PrivacyPolicy />}
        {section === "visibility" && <VisibilityToggle />}
        {section === "blocked" && <BlockedUsers />}
        {section === "rules" && <GameRules />}
        {section === "notifications" && <NotificationsToggle />}
        {section === "about" && <AboutFitGenie />}
        {section === "support" && <SupportForm />}
        {section === "delete_account" && <DeleteAccount onBack={onBack} />}
      </div>
    </div>
  );
}

function AccountEdit() {
  const { profile, user, refreshProfile } = useAuth();
  const [username, setUsername] = useState(profile?.username || "");
  const [bio, setBio] = useState(profile?.bio || "");
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleSave = async () => {
    if (!profile?.uid) return;
    setSaving(true);
    setError("");
    setSuccess(false);
    try {
      const cleanUsername = username.trim();
      
      if (cleanUsername !== profile.username) {
        // Check uniqueness
        const docRef = doc(db, "usernames", cleanUsername.toLowerCase());
        const snap = await getDoc(docRef);
        if (snap.exists() && snap.data().uid !== profile.uid) {
          setError("Username is already taken.");
          setSaving(false);
          return;
        }
      }

      const batch = writeBatch(db);
      const userRef = doc(db, "users", profile.uid);
      batch.update(userRef, { username: cleanUsername, bio: bio.trim() });
      
      // Update usernames collection
      if (cleanUsername !== profile.username) {
        // delete old if exists
        if (profile.username) {
          const oldRef = doc(db, "usernames", profile.username.toLowerCase());
          batch.delete(oldRef);
        }
        const newRef = doc(db, "usernames", cleanUsername.toLowerCase());
        batch.set(newRef, { uid: profile.uid });
      }

      await batch.commit();
      
      // Refresh context to update UI immediately
      if (typeof refreshProfile === 'function') {
        await refreshProfile();
      }

      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (e: any) {
      setError(e.message || "Failed to save profile.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      {profile?.fighterId && (
        <div className="bg-[#0A1128] border border-[#1A2642] p-4 rounded-xl flex items-center justify-between">
          <div>
            <h4 className="text-white font-bold text-sm">Fighter Code</h4>
            <p className="text-brand-muted text-[10px] uppercase font-bold tracking-widest mt-0.5">Share this to connect with friends</p>
          </div>
          <span className="text-[#14F1E1] font-black tracking-widest bg-[#14F1E1]/10 px-3 py-1 rounded-lg">
            {profile.fighterId}
          </span>
        </div>
      )}
      <div>
        <label className="text-[10px] font-black uppercase tracking-widest text-[#B66DFF] mb-2 block">Username</label>
        <input 
          type="text" 
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="w-full bg-[#0A1128] border border-[#1A2642] rounded-xl p-4 text-white focus:outline-none focus:border-[#B66DFF] transition-colors"
        />
      </div>
      <div>
        <label className="text-[10px] font-black uppercase tracking-widest text-[#B66DFF] mb-2 block">Bio</label>
        <textarea 
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          className="w-full bg-[#0A1128] border border-[#1A2642] rounded-xl p-4 text-white focus:outline-none focus:border-[#B66DFF] transition-colors h-32 resize-none"
        />
      </div>
      {error && <p className="text-red-500 text-xs font-bold">{error}</p>}
      {success && <p className="text-emerald-500 text-xs font-bold flex items-center gap-1"><Check className="w-4 h-4"/> Saved successfully!</p>}
      <button 
        onClick={handleSave}
        disabled={saving}
        className="w-full bg-[#B66DFF] text-white p-4 rounded-xl font-black uppercase tracking-widest text-sm hover:bg-[#A352FF] transition-colors disabled:opacity-50 flex justify-center"
      >
        {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : "Save Changes"}
      </button>
    </div>
  );
}

function PrivacyPolicy() {
  return (
    <div className="space-y-6 text-sm text-zinc-300 leading-relaxed">
      <div>
        <h2 className="text-white font-bold mb-2">Information We Collect</h2>
        <p>We collect your Google account name, email, and profile photo when you sign in. We also store fitness data you generate while using the app: workout logs, rep counts, XP, streaks, rank, username, and social data (followers/following).</p>
      </div>
      <div>
        <h2 className="text-white font-bold mb-2">Camera & AI Tracking</h2>
        <p>All AI movement tracking processing happens entirely on-device via MediaPipe. No video streams, frames, or images ever leave your device or get uploaded to our servers.</p>
      </div>
      <div>
        <h2 className="text-white font-bold mb-2">How We Use Your Data</h2>
        <p>Your data is used to provide the Fit Genie service, calculate leaderboards, maintain streaks, and enable social features.</p>
      </div>
      <div>
        <h2 className="text-white font-bold mb-2">Data Storage</h2>
        <p>Your data is stored securely on Google Firebase. We do not sell your personal data to third parties.</p>
      </div>
      <div>
        <h2 className="text-white font-bold mb-2">Your Rights</h2>
        <p>You can request full account deletion via officialfitgenie@gmail.com, or use the Delete Account option in the app.</p>
      </div>
      <div>
        <h2 className="text-white font-bold mb-2">Children's Privacy</h2>
        <p>This application is intended to be used with parental awareness for users under 18 years of age.</p>
      </div>
      <div>
        <h2 className="text-white font-bold mb-2">Changes & Contact</h2>
        <p>We may update this policy periodically. Contact officialfitgenie@gmail.com for questions.</p>
      </div>
    </div>
  );
}

function VisibilityToggle() {
  const { profile } = useAuth();
  const [isPrivate, setIsPrivate] = useState((profile as any)?.isPrivate || false);
  const [saving, setSaving] = useState(false);

  const toggle = async () => {
    if (!profile?.uid) return;
    setSaving(true);
    const newValue = !isPrivate;
    try {
      await updateDoc(doc(db, "users", profile.uid), { isPrivate: newValue });
      setIsPrivate(newValue);
    } catch(e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-[#0A1128] border border-[#1A2642] rounded-xl p-4 flex items-center justify-between">
      <div>
        <h3 className="text-white font-bold">Private Profile</h3>
        <p className="text-xs text-brand-muted mt-1">If active, only followers can see your stats.</p>
      </div>
      <button 
        onClick={toggle}
        disabled={saving}
        className={`w-12 h-6 rounded-full relative transition-colors ${isPrivate ? 'bg-[#B66DFF]' : 'bg-neutral-700'}`}
      >
        <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${isPrivate ? 'right-1' : 'left-1'}`} />
      </button>
    </div>
  );
}

function BlockedUsers() {
  const { profile } = useAuth();
  const [blocked, setBlocked] = useState<{id: string, name: string}[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBlocked = async () => {
      if (!profile?.uid) return;
      try {
        const uDoc = await getDoc(doc(db, "users", profile.uid));
        const ids = uDoc.data()?.blockedUsers || [];
        const fetched = [];
        for (const id of ids) {
          const bd = await getDoc(doc(db, "users", id));
          if (bd.exists()) {
            fetched.push({ id, name: bd.data().username || "User" });
          }
        }
        setBlocked(fetched);
      } catch(e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchBlocked();
  }, [profile]);

  const unblock = async (id: string) => {
    if (!profile?.uid) return;
    try {
      const uDoc = await getDoc(doc(db, "users", profile.uid));
      const current = uDoc.data()?.blockedUsers || [];
      const updated = current.filter((uid: string) => uid !== id);
      await updateDoc(doc(db, "users", profile.uid), { blockedUsers: updated });
      setBlocked(prev => prev.filter(u => u.id !== id));
      
      // also clean local storage just in case
      try {
        const local = localStorage.getItem("fitgenie_blocked_users");
        if (local) {
          const parsed = JSON.parse(local).filter((uid: string) => uid !== id);
          localStorage.setItem("fitgenie_blocked_users", JSON.stringify(parsed));
        }
      } catch(e){}
    } catch(e) {
      console.error(e);
    }
  };

  if (loading) return <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 text-[#B66DFF] animate-spin"/></div>;

  if (blocked.length === 0) {
    return <div className="text-center p-8 text-brand-muted text-sm font-bold">No blocked users.</div>;
  }

  return (
    <div className="space-y-3">
      {blocked.map(u => (
        <div key={u.id} className="bg-[#0A1128] border border-[#1A2642] rounded-xl p-4 flex items-center justify-between">
          <span className="text-white font-bold">{u.name}</span>
          <button onClick={() => unblock(u.id)} className="px-3 py-1 bg-white/10 text-white rounded-lg text-xs font-black uppercase tracking-widest hover:bg-white/20">
            Unblock
          </button>
        </div>
      ))}
    </div>
  );
}

function GameRules() {
  return (
    <div className="space-y-6 text-sm text-zinc-300 leading-relaxed">
      <div>
        <h2 className="text-white font-bold mb-2">Acceptance of Terms</h2>
        <p>By using Fit Genie, you agree to these Game Rules & Terms.</p>
      </div>
      <div>
        <h2 className="text-white font-bold mb-2">Fair Play</h2>
        <p>Use Fit Genie honestly. Do not manipulate AI tracking, the Genie Guardian trust score, or leaderboards. Users caught repeatedly cheating may have scores reset or accounts restricted.</p>
      </div>
      <div>
        <h2 className="text-white font-bold mb-2">Account Responsibility</h2>
        <p>You are responsible for securing your Google Sign-In account. Do not share accounts.</p>
      </div>
      <div>
        <h2 className="text-white font-bold mb-2">No Medical Advice</h2>
        <p>This app is for fitness tracking and gamification only. Always consult a doctor before starting new exercise programs.</p>
      </div>
      <div>
        <h2 className="text-white font-bold mb-2">Limitation of Liability</h2>
        <p>The app is provided "as is". We are not liable for injuries sustained during exercises.</p>
      </div>
      <div>
        <h2 className="text-white font-bold mb-2">Changes to Service</h2>
        <p>Features, ranks, and mechanics may evolve over time.</p>
      </div>
      <div>
        <p>Contact: officialfitgenie@gmail.com</p>
      </div>
    </div>
  );
}

function NotificationsToggle() {
  const { profile } = useAuth();
  
  // Default all to true if undefined
  const [prefs, setPrefs] = useState({
    notifyFriendRequests: (profile as any)?.notifyFriendRequests ?? true,
    notifyRecordBeaten: (profile as any)?.notifyRecordBeaten ?? true,
    notifyChatMessages: (profile as any)?.notifyChatMessages ?? true,
    notifyStreakReminders: (profile as any)?.notifyStreakReminders ?? true,
  });

  const toggle = async (key: keyof typeof prefs) => {
    if (!profile?.uid) return;
    const newVal = !prefs[key];
    setPrefs(p => ({ ...p, [key]: newVal }));
    try {
      await updateDoc(doc(db, "users", profile.uid), { [key]: newVal });
    } catch(e) {
      console.error(e);
      // Revert on fail
      setPrefs(p => ({ ...p, [key]: !newVal }));
    }
  };

  const Option = ({ label, k }: { label: string, k: keyof typeof prefs }) => (
    <div className="bg-[#0A1128] border border-[#1A2642] rounded-xl p-4 flex items-center justify-between">
      <span className="text-white font-bold">{label}</span>
      <button 
        onClick={() => toggle(k)}
        className={`w-12 h-6 rounded-full relative transition-colors ${prefs[k] ? 'bg-[#14F1E1]' : 'bg-neutral-700'}`}
      >
        <div className={`absolute top-1 w-4 h-4 rounded-full bg-black transition-all ${prefs[k] ? 'right-1' : 'left-1'}`} />
      </button>
    </div>
  );

  return (
    <div className="space-y-3">
      <Option label="Friend Requests" k="notifyFriendRequests" />
      <Option label="Record Beaten Alerts" k="notifyRecordBeaten" />
      <Option label="Chat Messages" k="notifyChatMessages" />
      <Option label="Streak Reminders" k="notifyStreakReminders" />
    </div>
  );
}

function AboutFitGenie() {
  return (
    <div className="text-center space-y-6 pt-8">
      <div className="w-24 h-24 mx-auto bg-gradient-to-br from-[#B66DFF] to-[#14F1E1] rounded-3xl flex items-center justify-center shadow-2xl">
        <SparklesIcon className="w-12 h-12 text-[#050B1A]" />
      </div>
      <h2 className="text-2xl font-black uppercase text-white tracking-widest">Fit Genie</h2>
      <p className="text-zinc-400 text-sm leading-relaxed max-w-sm mx-auto">
        Fit Genie is an AI-powered, gamified fitness app built for Indian athletes. Combining real-time AI movement tracking, RPG-style progression, a social community, and an honest fair-play system, Fit Genie turns everyday workouts into an engaging journey.
      </p>
      <div className="p-4 bg-white/5 rounded-xl inline-block mt-4">
        <p className="text-sm font-bold text-white">Crafted for Indian Athletes. Built in India. 🇮🇳</p>
      </div>
      <p className="text-xs text-[#14F1E1] font-mono pt-8">v2.0.0 • Cyber Hologram Edition</p>
    </div>
  );
}

function SparklesIcon(props: any) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>;
}

function SupportForm() {
  const { profile } = useAuth();
  const [type, setType] = useState("Bug Report");
  const [desc, setDesc] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async () => {
    if (!desc.trim() || !profile?.uid) return;
    setSubmitting(true);
    try {
      await addDoc(collection(db, "feedback"), {
        userId: profile.uid,
        issueType: type,
        description: desc.trim(),
        timestamp: Date.now()
      });
      setDone(true);
      setDesc("");
    } catch(e) {
      console.error(e);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <a href="mailto:officialfitgenie@gmail.com" className="w-full flex items-center justify-center gap-2 p-4 bg-white/5 text-white rounded-xl font-bold hover:bg-white/10 transition-colors">
        <Mail className="w-5 h-5" /> Contact via Email
      </a>
      
      <div className="h-px bg-[#1A2642] w-full" />

      <div className="space-y-4">
        <h3 className="text-white font-bold">Send Feedback</h3>
        <select 
          value={type} 
          onChange={e => setType(e.target.value)}
          className="w-full bg-[#0A1128] border border-[#1A2642] rounded-xl p-4 text-white focus:outline-none focus:border-[#B66DFF]"
        >
          <option>Bug Report</option>
          <option>Feature Suggestion</option>
          <option>Account Issue</option>
          <option>Other</option>
        </select>
        <textarea 
          value={desc}
          onChange={e => setDesc(e.target.value)}
          placeholder="Describe your issue or suggestion..."
          className="w-full bg-[#0A1128] border border-[#1A2642] rounded-xl p-4 text-white focus:outline-none focus:border-[#B66DFF] h-32 resize-none"
        />
        {done && <p className="text-emerald-500 text-xs font-bold">Thanks! We'll look into it.</p>}
        <button 
          onClick={submit}
          disabled={submitting || !desc.trim()}
          className="w-full bg-[#B66DFF] text-white p-4 rounded-xl font-black uppercase tracking-widest text-sm hover:bg-[#A352FF] transition-colors disabled:opacity-50 flex justify-center"
        >
          {submitting ? <Loader2 className="w-5 h-5 animate-spin"/> : "Submit"}
        </button>
      </div>
    </div>
  );
}

function DeleteAccount({ onBack }: { onBack: () => void }) {
  const { profile, signOutUser } = useAuth();
  const [confirming, setConfirming] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const performDelete = async () => {
    if (!profile?.uid) return;
    setDeleting(true);
    setDeleteError(null);
    try {
      const batch = writeBatch(db);
      
      // Delete from users
      batch.delete(doc(db, "users", profile.uid));
      
      // Delete from usernames
      if (profile.username) {
        batch.delete(doc(db, "usernames", profile.username.toLowerCase()));
      }

      // Remove follows where follower is me
      const myFollows = await getDocs(query(collection(db, "follows"), where("followerId", "==", profile.uid)));
      myFollows.forEach(d => batch.delete(d.ref));
      
      // Remove follows where I am followed
      const followingMe = await getDocs(query(collection(db, "follows"), where("followingId", "==", profile.uid)));
      followingMe.forEach(d => batch.delete(d.ref));

      await batch.commit();

      // Sign out
      await signOutUser();
    } catch(e: any) {
      console.error(e);
      setDeleteError(e?.message || "Failed to delete account. Please re-authenticate and try again.");
      setDeleting(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center text-center p-4">
      <AlertTriangle className="w-16 h-16 text-red-500 mb-6" />
      <h2 className="text-2xl font-black uppercase text-white mb-4">Delete Account?</h2>
      <p className="text-zinc-400 text-sm leading-relaxed max-w-sm mx-auto mb-8">
        Are you sure? This will permanently delete your profile, workout history, and remove you from leaderboards. This cannot be undone.
      </p>

      {deleteError && (
        <div className="w-full max-w-xs mb-4 p-3 rounded-xl bg-red-500/15 border border-red-500/40 text-red-300 text-xs font-bold">
          {deleteError}
        </div>
      )}

      {!confirming ? (
        <div className="space-y-4 w-full max-w-xs">
          <button onClick={() => setConfirming(true)} className="w-full p-4 bg-red-500 text-white rounded-xl font-black uppercase tracking-widest text-sm hover:bg-red-600 cursor-pointer">
            Yes, Delete Everything
          </button>
          <button onClick={onBack} className="w-full p-4 bg-white/10 text-white rounded-xl font-bold uppercase tracking-widest text-sm hover:bg-white/20 cursor-pointer">
            Cancel
          </button>
        </div>
      ) : (
        <div className="space-y-4 w-full max-w-xs p-6 border border-red-500/50 bg-red-500/10 rounded-2xl">
          <p className="text-red-400 font-bold text-sm mb-4">Final Warning. This is permanent.</p>
          <button onClick={performDelete} disabled={deleting} className="w-full p-4 bg-red-500 text-white rounded-xl font-black uppercase tracking-widest text-sm hover:bg-red-600 disabled:opacity-50 flex justify-center cursor-pointer">
            {deleting ? <Loader2 className="w-5 h-5 animate-spin"/> : "Confirm Deletion"}
          </button>
          <button onClick={onBack} disabled={deleting} className="w-full p-4 bg-transparent text-white rounded-xl font-bold uppercase tracking-widest text-sm hover:bg-white/5 cursor-pointer">
            Keep Account
          </button>
        </div>
      )}
    </div>
  );
}


function PromoCode() {
  const { profile, refreshProfile } = useAuth();
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<{type: "error" | "success" | null, msg: string}>({ type: null, msg: "" });

  const handleRedeem = async () => {
    const trimmed = code.trim();
    if (!trimmed || !profile?.uid) return;
    
    setLoading(true);
    setStatus({ type: null, msg: "" });

    try {
      // Check if it's the 500 XP fitGenie1 code
      if (trimmed.toLowerCase() === "fitgenie1") {
        const claimedPromos = profile.claimedPromos || [];
        if (claimedPromos.includes("fitgenie1")) {
          setStatus({ type: "error", msg: "You have already claimed this promo code." });
          setLoading(false);
          return;
        }

        // Add 500 XP and mark as claimed
        await updateDoc(doc(db, "users", profile.uid), {
          xp: (profile.xp || 0) + 500,
          claimedPromos: [...claimedPromos, "fitgenie1"]
        });

        if (refreshProfile) await refreshProfile();

        setStatus({ type: "success", msg: "500 XP successfully claimed! 🎉" });
        setCode("");
      } else {
        setStatus({ type: "error", msg: "Invalid or expired promo code." });
      }
    } catch (e) {
      console.error(e);
      setStatus({ type: "error", msg: "An error occurred while redeeming." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#0A1128] border border-brand-accent/20 p-6 rounded-2xl flex flex-col items-center text-center">
        <div className="w-16 h-16 bg-brand-accent/10 rounded-2xl flex items-center justify-center mb-4 border border-brand-accent/20">
          <Gift className="w-8 h-8 text-brand-accent" />
        </div>
        <h2 className="text-xl font-black text-white uppercase tracking-tight mb-2">Redeem Promo Code</h2>
        <p className="text-zinc-400 text-sm font-medium mb-6">Enter your exclusive promo code below to claim XP boosts, badges, and hidden rewards.</p>
        
        <div className="w-full relative">
          <input 
            type="text" 
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="ENTER CODE..."
            className="w-full bg-[#050B1A] border-2 border-[#1A2642] rounded-xl px-4 py-4 text-white text-center font-black uppercase tracking-widest focus:outline-none focus:border-brand-accent transition-colors"
          />
        </div>

        {status.msg && (
          <div className={`w-full mt-4 p-3 rounded-lg text-xs font-bold uppercase tracking-widest ${status.type === "success" ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-red-500/10 text-red-400 border border-red-500/20"}`}>
            {status.msg}
          </div>
        )}

        <button 
          onClick={handleRedeem}
          disabled={loading || !code.trim()}
          className="w-full mt-6 bg-[#B66DFF] text-white py-4 rounded-xl font-black uppercase tracking-widest hover:bg-[#B66DFF]/90 transition-colors disabled:opacity-50 flex items-center justify-center"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Claim Reward"}
        </button>
      </div>
    </div>
  );
}
