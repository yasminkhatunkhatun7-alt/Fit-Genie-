import React, { useMemo } from "react";
import { motion } from "motion/react";
import {
  Trophy,
  Shield,
  Flame,
  Target,
  Star,
  Award,
  CheckCircle,
  Lock,
  Crown,
  Zap,
  Dumbbell,
  Swords,
  Activity,
} from "lucide-react";
import { useAuth, getRankDetails } from "../context/AuthContext";
import { CompletedSession } from "../types";

export default function AchievementsScreen() {
  const { profile } = useAuth();

  const historyStr = localStorage.getItem("fitgenie_history");
  const history: CompletedSession[] = historyStr ? JSON.parse(historyStr) : [];

  const xp = profile?.xp || 0;

  const rank = getRankDetails(xp);
  const xpNeeded = rank.next === "Max" ? 0 : rank.nextXP - xp;
  const progressPercent =
    rank.next === "Max"
      ? 100
      : Math.min(
          100,
          Math.max(0, ((xp - rank.base) / (rank.nextXP - rank.base)) * 100)
        );

  const streak = profile?.streak || 0;
  const longestStreak = Math.max(
    streak,
    parseInt(localStorage.getItem("fitgenie_longest_streak") || "0", 10)
  );
  if (streak > longestStreak) {
    localStorage.setItem("fitgenie_longest_streak", streak.toString());
  }

  const integrityScore = profile?.integrityScore ?? 100;
  let trustRank = "Needs Improvement";
  if (integrityScore === 100) trustRank = "Iron Will";
  else if (integrityScore >= 90) trustRank = "Elite Warrior";
  else if (integrityScore >= 80) trustRank = "Disciplined";
  else if (integrityScore >= 70) trustRank = "Consistent";

  // Case-insensitive + anatomical group normalization so Chest, Core, and Legs badges unlock reliably
  const musclesTrained = useMemo(() => {
    const counts: Record<string, number> = {
      chest: 0,
      core: 0,
      legs: 0,
    };
    history.forEach((session) => {
      const sessionGroups = new Set<string>();
      session.muscles?.forEach((rawM) => {
        const m = rawM.toLowerCase();
        counts[m] = (counts[m] || 0) + 1;
        if (m.includes("chest") || m.includes("pec")) {
          sessionGroups.add("chest");
        }
        if (
          m.includes("core") ||
          m.includes("abs") ||
          m.includes("oblique")
        ) {
          sessionGroups.add("core");
        }
        if (
          m.includes("leg") ||
          m.includes("quad") ||
          m.includes("hamstring") ||
          m.includes("glute") ||
          m.includes("calf") ||
          m.includes("calves")
        ) {
          sessionGroups.add("legs");
        }
      });
      sessionGroups.forEach((g) => {
        counts[g] = (counts[g] || 0) + 1;
      });
    });
    return counts;
  }, [history]);

  const challengeWins = profile?.challengeWins || 0;

  const badges = [
    {
      id: "first",
      name: "First Blood",
      desc: "Complete 1 workout session",
      unlocked: history.length > 0,
      current: Math.min(1, history.length),
      target: 1,
      icon: Target,
      accent: "text-[#14F1E1] border-[#14F1E1]/40 bg-[#14F1E1]/10",
    },
    {
      id: "streak7",
      name: "7-Day Igniter",
      desc: "Train 7 days in a row",
      unlocked: longestStreak >= 7,
      current: Math.min(7, longestStreak),
      target: 7,
      icon: Flame,
      accent: "text-orange-400 border-orange-500/40 bg-orange-500/10",
    },
    {
      id: "streak30",
      name: "30-Day Cyber Titan",
      desc: "Train 30 days in a row",
      unlocked: longestStreak >= 30,
      current: Math.min(30, longestStreak),
      target: 30,
      icon: Zap,
      accent: "text-[#B66DFF] border-[#B66DFF]/40 bg-[#B66DFF]/10",
    },
    {
      id: "chest",
      name: "Chest Vanguard",
      desc: "Train Chest 5 times",
      unlocked: (musclesTrained["chest"] || 0) >= 5,
      current: Math.min(5, musclesTrained["chest"] || 0),
      target: 5,
      icon: Dumbbell,
      accent: "text-[#14F1E1] border-[#14F1E1]/40 bg-[#14F1E1]/10",
    },
    {
      id: "core",
      name: "Core Sovereign",
      desc: "Train Core & Abs 5 times",
      unlocked: (musclesTrained["core"] || 0) >= 5,
      current: Math.min(5, musclesTrained["core"] || 0),
      target: 5,
      icon: Crown,
      accent: "text-amber-400 border-amber-500/40 bg-amber-500/10",
    },
    {
      id: "legs",
      name: "Leg Destroyer",
      desc: "Train Legs & Quads 5 times",
      unlocked: (musclesTrained["legs"] || 0) >= 5,
      current: Math.min(5, musclesTrained["legs"] || 0),
      target: 5,
      icon: Activity,
      accent: "text-emerald-400 border-emerald-500/40 bg-emerald-500/10",
    },
    {
      id: "integrity",
      name: "Iron Integrity",
      desc: "100% Trust Score over 5+ sessions",
      unlocked: integrityScore === 100 && history.length >= 5,
      current: Math.min(5, history.length),
      target: 5,
      icon: Shield,
      accent: "text-sky-400 border-sky-500/40 bg-sky-500/10",
    },
    {
      id: "legendary",
      name: "Boss Slayer",
      desc: "Conquer 5 Dojo Challenges",
      unlocked: challengeWins >= 5,
      current: Math.min(5, challengeWins),
      target: 5,
      icon: Swords,
      accent: "text-rose-400 border-rose-500/40 bg-rose-500/10",
    },
  ];

  const titles = [
    { name: "Rookie", unlocked: xp >= 0 },
    { name: "Warrior", unlocked: xp >= 500 },
    { name: "Discipline King", unlocked: longestStreak >= 14 },
    { name: "Titan Slayer", unlocked: challengeWins >= 10 },
    { name: "Legendary Beast", unlocked: xp >= 8000 },
  ];

  const unlockedCount = badges.filter((b) => b.unlocked).length;

  return (
    <div className="pb-24 pt-6 px-4 max-w-md mx-auto space-y-6">
      {/* HEADER */}
      <div className="text-center space-y-1">
        <h1 className="text-3xl font-black text-white uppercase tracking-wider flex items-center justify-center gap-2">
          <Trophy className="w-8 h-8 text-[#14F1E1]" /> ACHIEVEMENTS
        </h1>
        <p className="text-[11px] text-[#9CA3AF] font-bold uppercase tracking-widest">
          {unlockedCount} / {badges.length} Cyber Emblems Unlocked
        </p>
      </div>

      {/* 1. XP OVERVIEW & 3D RANK CRYSTAL PEDESTAL */}
      <motion.div
        className="glass-card p-5 rounded-3xl glow-cyan space-y-4 relative overflow-hidden border border-[#14F1E1]/35"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-[#14F1E1]" />
            <h2 className="text-sm font-black text-white uppercase tracking-wider">
              Current Rank & XP
            </h2>
          </div>
          <span className="text-[9px] font-mono font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-[#14F1E1]/15 border border-[#14F1E1]/40 text-[#14F1E1]">
            TIER: {rank.title}
          </span>
        </div>

        {/* 3D Floating Rank Crystal Emblem */}
        <div className="flex items-center gap-4 bg-[#040917]/80 border border-white/10 rounded-2xl p-3.5">
          <div className="relative w-20 h-20 shrink-0 flex items-center justify-center">
            <motion.div
              animate={{ rotateZ: 360 }}
              transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
              className="absolute inset-1 rounded-full border border-dashed border-[#14F1E1]/45"
            />
            <motion.svg
              viewBox="0 0 80 80"
              className="w-16 h-16 relative z-10 overflow-visible"
              animate={{ y: [0, -4, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            >
              <defs>
                <linearGradient id="rankGemTop" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FFFFFF" />
                  <stop offset="45%" stopColor="#14F1E1" />
                  <stop offset="100%" stopColor="#0284C7" />
                </linearGradient>
                <linearGradient id="rankGemBottom" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#B66DFF" />
                  <stop offset="100%" stopColor="#1E1B4B" />
                </linearGradient>
              </defs>
              <ellipse cx="40" cy="72" rx="22" ry="4.5" fill="rgba(20,241,225,0.28)" />
              <polygon points="40,8 62,32 40,44 18,32" fill="url(#rankGemTop)" stroke="#FFF" strokeWidth="1" />
              <polygon points="18,32 40,44 62,32 40,66" fill="url(#rankGemBottom)" stroke="#14F1E1" strokeWidth="1" />
              <polygon points="40,8 40,66 62,32" fill="rgba(255,255,255,0.18)" />
            </motion.svg>
          </div>

          <div className="flex-1 flex justify-between items-end">
            <div>
              <div className="text-3xl font-black text-white font-mono leading-none">
                {xp.toLocaleString()}
              </div>
              <div className="text-[10px] text-[#9CA3AF] uppercase font-bold tracking-widest mt-1">
                Total Warrior XP
              </div>
            </div>
            <div className="text-right">
              <div className="text-lg font-black text-[#14F1E1] uppercase">{rank.title}</div>
              <div className="text-[10px] text-[#9CA3AF] uppercase font-bold tracking-widest mt-0.5">
                Active Rank
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-1">
          <div className="flex justify-between text-[10px] text-[#9CA3AF] font-mono font-bold">
            <span>{rank.title}</span>
            <span>{rank.next}</span>
          </div>
          <div className="h-2.5 w-full bg-[#050B1A] rounded-full overflow-hidden border border-[rgba(20,241,225,0.25)] p-0.5">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progressPercent}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="h-full rounded-full bg-gradient-to-r from-[#14F1E1] to-[#B66DFF] shadow-[0_0_10px_#14F1E1]"
            />
          </div>
          <div className="text-right text-[9px] text-[#9CA3AF] uppercase font-bold pt-1">
            {xpNeeded > 0 ? `${xpNeeded} XP to next rank` : "Max rank reached"}
          </div>
        </div>
      </motion.div>

      {/* 2. STREAK SECTION */}
      <div className="grid grid-cols-2 gap-4">
        <motion.div
          className="glass-card p-5 rounded-2xl glow-orange text-center flex flex-col items-center justify-center"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Flame className="w-6 h-6 text-[#FF4D4D] mb-2" />
          <div className="text-3xl font-black text-white font-mono">{streak}</div>
          <div className="text-[10px] text-[#9CA3AF] uppercase font-bold tracking-widest mt-1">
            Current Streak
          </div>
        </motion.div>
        <motion.div
          className="glass-card p-5 rounded-2xl glow-purple text-center flex flex-col items-center justify-center"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Zap className="w-6 h-6 text-[#B66DFF] mb-2" />
          <div className="text-3xl font-black text-white font-mono">
            {longestStreak}
          </div>
          <div className="text-[10px] text-[#9CA3AF] uppercase font-bold tracking-widest mt-1">
            Longest Streak
          </div>
        </motion.div>
      </div>

      {/* 3. INTEGRITY SCORE */}
      <motion.div
        className="glass-card p-5 rounded-2xl space-y-4 glow-blue"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-[#4DA8FF]" />
            <h2 className="text-sm font-black text-white uppercase tracking-wider">
              Integrity Score
            </h2>
          </div>
          <div className="text-2xl font-black text-[#4DA8FF] font-mono">
            {integrityScore}%
          </div>
        </div>
        <div className="bg-[#050B1A]/50 p-3 rounded-xl border border-[#4DA8FF]/20 flex justify-between items-center">
          <span className="text-xs text-[#9CA3AF] uppercase font-bold tracking-widest">
            Trust Rank
          </span>
          <span className="text-sm font-black uppercase tracking-wider text-[#4DA8FF]">
            {trustRank}
          </span>
        </div>
      </motion.div>

      {/* 4. 3D VOLUMETRIC CYBER TROPHY VAULT */}
      <motion.div
        className="glass-card p-5 rounded-3xl space-y-4"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-[#14F1E1]" />
            <h2 className="text-sm font-black text-white uppercase tracking-wider">
              Achievements & Trophies
            </h2>
          </div>
          <span className="text-[10px] font-mono font-bold text-[#14F1E1]">
            {unlockedCount}/{badges.length} UNLOCKED
          </span>
        </div>
        <div className="grid grid-cols-2 gap-3.5">
          {badges.map((badge, idx) => {
            const IconComponent = badge.icon;
            const pct = Math.min(
              100,
              Math.round((badge.current / badge.target) * 100)
            );
            const hexColors = [
              "#14F1E1",
              "#FB923C",
              "#B66DFF",
              "#00BBF9",
              "#FBBF24",
              "#10B981",
              "#38BDF8",
              "#F43F5E",
            ];
            const gemHex = hexColors[idx % hexColors.length];

            return (
              <div
                key={badge.id}
                style={{
                  boxShadow: badge.unlocked
                    ? `0 16px 32px -10px rgba(0,0,0,0.85), 0 0 22px ${gemHex}28, inset 0 1px 0 rgba(255,255,255,0.2)`
                    : "inset 0 1px 0 rgba(255,255,255,0.05)",
                }}
                className={`p-4 rounded-2xl border ${
                  badge.unlocked
                    ? "bg-gradient-to-b from-[#0E1938] to-[#060B19] border-[#14F1E1]/45"
                    : "bg-[#050B1A]/75 border-white/10 opacity-70"
                } relative overflow-hidden flex flex-col items-center text-center gap-2.5 transition-all`}
              >
                {/* 3D Hexagonal Crystal Shield Trophy */}
                <div className="relative w-14 h-14 flex items-center justify-center">
                  {badge.unlocked && (
                    <motion.div
                      animate={{ rotateZ: 360 }}
                      transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                      className="absolute inset-0 rounded-full border border-dashed opacity-60"
                      style={{ borderColor: gemHex }}
                    />
                  )}
                  <svg viewBox="0 0 64 64" className="w-14 h-14 absolute inset-0">
                    <polygon
                      points="32,4 56,18 56,46 32,60 8,46 8,18"
                      fill={badge.unlocked ? `${gemHex}24` : "rgba(255,255,255,0.03)"}
                      stroke={badge.unlocked ? gemHex : "#334155"}
                      strokeWidth="2"
                    />
                    <polygon
                      points="32,10 50,21 50,43 32,54 14,43 14,21"
                      fill="rgba(5,11,26,0.75)"
                      stroke={badge.unlocked ? "#FFFFFF" : "#1E293B"}
                      strokeWidth="0.8"
                      opacity="0.7"
                    />
                  </svg>
                  <div
                    className="relative z-10"
                    style={{ color: badge.unlocked ? gemHex : "#64748B" }}
                  >
                    <IconComponent className="w-5 h-5" />
                  </div>
                </div>

                <div className="w-full">
                  <div
                    className={`text-[11px] font-black uppercase tracking-wider ${
                      badge.unlocked ? "text-white" : "text-neutral-400"
                    }`}
                  >
                    {badge.name}
                  </div>
                  <div className="text-[9px] text-neutral-400 font-bold leading-tight mt-0.5">
                    {badge.desc}
                  </div>
                  <div className="mt-2.5 space-y-1">
                    <div className="h-1.5 w-full bg-black/60 rounded-full overflow-hidden border border-white/5">
                      <div
                        className="h-full transition-all duration-500"
                        style={{
                          width: `${pct}%`,
                          backgroundColor: badge.unlocked ? gemHex : "#475569",
                        }}
                      />
                    </div>
                    <div className="text-[8.5px] font-mono font-bold text-neutral-400">
                      {badge.current} / {badge.target}
                    </div>
                  </div>
                </div>
                {!badge.unlocked && (
                  <Lock className="w-3 h-3 absolute top-2.5 right-2.5 text-neutral-500" />
                )}
              </div>
            );
          })}
        </div>
      </motion.div>

      {/* 5. TITLES */}
      <motion.div
        className="glass-card p-5 rounded-2xl space-y-4"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <div className="flex items-center gap-2">
          <Crown className="w-5 h-5 text-[#B66DFF]" />
          <h2 className="text-sm font-black text-white uppercase tracking-wider">
            Titles
          </h2>
        </div>
        <div className="flex flex-wrap gap-2">
          {titles.map((t) => (
            <div
              key={t.name}
              className={`px-3 py-1.5 rounded-lg border text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 ${
                t.unlocked
                  ? "bg-[#B66DFF]/10 border-[#B66DFF]/30 text-[#B66DFF]"
                  : "bg-transparent border-neutral-800 text-neutral-600"
              }`}
            >
              {t.unlocked ? (
                <CheckCircle className="w-3 h-3" />
              ) : (
                <Lock className="w-3 h-3" />
              )}
              {t.name}
            </div>
          ))}
        </div>
      </motion.div>

      {/* 6. CHALLENGE RECORDS */}
      <motion.div
        className="glass-card p-5 rounded-2xl space-y-4"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
      >
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-[#FF4D4D]" />
          <h2 className="text-sm font-black text-white uppercase tracking-wider">
            Challenge Records
          </h2>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between items-center bg-[#050B1A]/50 p-3 rounded-xl border border-neutral-800/50">
            <span className="text-[10px] text-[#9CA3AF] uppercase font-bold tracking-widest">
              Total Workouts Logged
            </span>
            <span className="text-sm font-black text-white font-mono">
              {history.length}
            </span>
          </div>
          <div className="flex justify-between items-center bg-[#050B1A]/50 p-3 rounded-xl border border-neutral-800/50">
            <span className="text-[10px] text-[#9CA3AF] uppercase font-bold tracking-widest">
              30-Day Cycles Completed
            </span>
            <span className="text-sm font-black text-white font-mono">
              {Math.floor(history.length / 30)}
            </span>
          </div>
          <div className="flex justify-between items-center bg-[#050B1A]/50 p-3 rounded-xl border border-neutral-800/50">
            <span className="text-[10px] text-[#9CA3AF] uppercase font-bold tracking-widest">
              Dojo Bosses Defeated
            </span>
            <span className="text-sm font-black text-white font-mono">
              {challengeWins}
            </span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
