import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { CompletedSession } from '../types';

interface WorkoutProgressChartProps {
  history: CompletedSession[];
}

export default function WorkoutProgressChart({ history }: WorkoutProgressChartProps) {
  const chartRef = useRef<SVGSVGElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [metric, setMetric] = useState<'volume' | 'duration'>('volume');
  const [tooltip, setTooltip] = useState<{ visible: boolean; x: number; y: number; text: string }>({
    visible: false,
    x: 0,
    y: 0,
    text: ''
  });

  useEffect(() => {
    if (!chartRef.current || !containerRef.current || history.length === 0) return;

    // Filter last 30 days
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    thirtyDaysAgo.setHours(0, 0, 0, 0);

    const recentHistory = history.filter(session => {
      const d = new Date(session.date);
      return d >= thirtyDaysAgo;
    });

    if (recentHistory.length === 0) {
      d3.select(chartRef.current).selectAll('*').remove();
      return;
    }

    // Group by date
    const dailyDataMap = new Map<string, { date: Date; volume: number; duration: number }>();
    recentHistory.forEach(session => {
      const d = new Date(session.date);
      d.setHours(0, 0, 0, 0);
      const dateStr = d.toISOString().split('T')[0];

      let sessionVolume = 0;
      session.exercises.forEach(ex => {
        sessionVolume += (ex.sets * ex.reps * (ex.weight || 0));
      });

      if (dailyDataMap.has(dateStr)) {
        const existing = dailyDataMap.get(dateStr)!;
        existing.volume += sessionVolume;
        existing.duration += session.totalDurationMin;
      } else {
        dailyDataMap.set(dateStr, {
          date: d,
          volume: sessionVolume,
          duration: session.totalDurationMin
        });
      }
    });

    const data = Array.from(dailyDataMap.values()).sort((a, b) => a.date.getTime() - b.date.getTime());

    // Setup chart dimensions
    const width = containerRef.current.clientWidth;
    const height = 240;
    const margin = { top: 20, right: 30, bottom: 30, left: 50 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const svg = d3.select(chartRef.current);
    svg.selectAll('*').remove(); // Clear previous
    svg.attr('width', width).attr('height', height);

    const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

    // X Scale
    const xScale = d3.scaleTime()
      .domain(d3.extent(data, d => d.date) as [Date, Date])
      .range([0, innerWidth]);

    // Y Scale
    const yMax = d3.max(data, d => d[metric]) || 1;
    const yScale = d3.scaleLinear()
      .domain([0, yMax])
      .range([innerHeight, 0])
      .nice();

    // Axes
    const xAxis = d3.axisBottom(xScale).ticks(5).tickFormat(d => d3.timeFormat('%b %d')(d as Date));
    const yAxis = d3.axisLeft(yScale).ticks(5);

    g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(xAxis)
      .attr('class', 'text-neutral-500 font-mono text-[10px]')
      .call(g => g.select('.domain').attr('stroke', '#333'))
      .call(g => g.selectAll('.tick line').attr('stroke', '#333'));

    g.append('g')
      .call(yAxis)
      .attr('class', 'text-neutral-500 font-mono text-[10px]')
      .call(g => g.select('.domain').attr('stroke', '#333'))
      .call(g => g.selectAll('.tick line').attr('stroke', '#333'))
      .call(g => g.selectAll('.tick text').attr('x', -8));

    // Grid lines
    g.append('g')
      .attr('class', 'grid')
      .call(d3.axisLeft(yScale).ticks(5).tickSize(-innerWidth).tickFormat(() => ''))
      .call(g => g.select('.domain').remove())
      .call(g => g.selectAll('.tick line').attr('stroke', '#222').attr('stroke-dasharray', '4,4'));

    // Line generator
    const line = d3.line<{ date: Date; volume: number; duration: number }>()
      .x(d => xScale(d.date))
      .y(d => yScale(d[metric]))
      .curve(d3.curveMonotoneX);

    // Draw line
    const path = g.append('path')
      .datum(data)
      .attr('fill', 'none')
      .attr('stroke', '#14F1E1')
      .attr('stroke-width', 3)
      .attr('d', line);

    // Animate line
    const totalLength = path.node()!.getTotalLength();
    path
      .attr('stroke-dasharray', `${totalLength} ${totalLength}`)
      .attr('stroke-dashoffset', totalLength)
      .transition()
      .duration(1500)
      .ease(d3.easeLinear)
      .attr('stroke-dashoffset', 0);

    // Area generator
    const area = d3.area<{ date: Date; volume: number; duration: number }>()
      .x(d => xScale(d.date))
      .y0(innerHeight)
      .y1(d => yScale(d[metric]))
      .curve(d3.curveMonotoneX);

    // Draw area
    const gradientId = 'chart-gradient';
    const defs = svg.append('defs');
    const gradient = defs.append('linearGradient')
      .attr('id', gradientId)
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');
    
    gradient.append('stop').attr('offset', '0%').attr('stop-color', '#14F1E1').attr('stop-opacity', 0.4);
    gradient.append('stop').attr('offset', '100%').attr('stop-color', '#14F1E1').attr('stop-opacity', 0);

    const areaPath = g.append('path')
      .datum(data)
      .attr('fill', `url(#${gradientId})`)
      .attr('d', area)
      .attr('opacity', 0);

    areaPath.transition().delay(1000).duration(1000).attr('opacity', 1);

    // Dots & Interactions
    g.selectAll('.dot')
      .data(data)
      .enter()
      .append('circle')
      .attr('class', 'dot')
      .attr('cx', d => xScale(d.date))
      .attr('cy', d => yScale(d[metric]))
      .attr('r', 4)
      .attr('fill', '#050B1A')
      .attr('stroke', '#14F1E1')
      .attr('stroke-width', 2)
      .attr('opacity', 0)
      .on('mouseover', (event, d) => {
        d3.select(event.currentTarget).attr('r', 6).attr('fill', '#14F1E1');
        const containerRect = containerRef.current?.getBoundingClientRect();
        if (containerRect) {
          setTooltip({
            visible: true,
            x: event.clientX - containerRect.left,
            y: event.clientY - containerRect.top - 40,
            text: `${d.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}: ${d[metric]} ${metric === 'volume' ? 'kg' : 'min'}`
          });
        }
      })
      .on('mouseout', (event) => {
        d3.select(event.currentTarget).attr('r', 4).attr('fill', '#050B1A');
        setTooltip(prev => ({ ...prev, visible: false }));
      })
      .transition()
      .delay(d => {
        const t = (xScale(d.date) / innerWidth) * 1500;
        return t;
      })
      .attr('opacity', 1);

  }, [history, metric]);

  const hasRecentHistory = history.some(session => {
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    return new Date(session.date) >= thirtyDaysAgo;
  });

  return (
    <div className="bg-brand-surface border border-brand-border p-5 md:p-6 rounded-2xl space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xs uppercase font-extrabold tracking-wider text-white">30-Day Progress</h3>
          <p className="text-[10px] text-brand-muted uppercase">Past month overview</p>
        </div>
        <div className="flex bg-[#050B1A] border border-brand-border rounded-xl overflow-hidden p-1">
          <button 
            onClick={() => setMetric('volume')}
            className={`px-3 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-lg transition-colors ${metric === 'volume' ? 'bg-[#14F1E1] text-[#050B1A]' : 'text-neutral-500 hover:text-white'}`}
          >
            Volume
          </button>
          <button 
            onClick={() => setMetric('duration')}
            className={`px-3 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-lg transition-colors ${metric === 'duration' ? 'bg-[#14F1E1] text-[#050B1A]' : 'text-neutral-500 hover:text-white'}`}
          >
            Duration
          </button>
        </div>
      </div>
      
      <div ref={containerRef} className="relative w-full min-h-[240px]">
        {!hasRecentHistory ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <p className="text-brand-muted text-xs uppercase font-bold tracking-widest">No data for the past 30 days</p>
          </div>
        ) : (
          <>
            <svg ref={chartRef} className="w-full h-[240px]" />
            {tooltip.visible && (
              <div 
                className="absolute bg-white text-black font-black text-[10px] uppercase tracking-widest px-3 py-1.5 rounded-lg shadow-[0_0_15px_rgba(20,241,225,0.4)] pointer-events-none z-10 transform -translate-x-1/2"
                style={{ left: tooltip.x, top: tooltip.y }}
              >
                {tooltip.text}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
