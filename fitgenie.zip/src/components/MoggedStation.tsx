import React, { useState } from 'react';
import { Search, Flame, Target, Clock, CheckCircle2, ChevronRight, Zap, Sparkles, Droplets, Dumbbell, ShieldCheck, HeartPulse } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { playSound } from '../utils/audio';
import MoggedActiveWorkout from './MoggedActiveWorkout';
import MysteryDojo from './MysteryDojo';
import PostureSymmetryScanner from './PostureSymmetryScanner';
import GeneticsAndDebloatLab from './GeneticsAndDebloatLab';
import { Exercise3DCharacterLoop } from './Exercise3DCharacterLoop';
import Mogged3DFaceViewer from './Mogged3DFaceViewer';

interface MoggedStationProps {
  onSaveSmartSession?: (session: any) => void;
}

const MOGGED_PROGRESS_STORAGE_KEY = "fitgenie_mogged_daily_progress_v1";

function getTodayDateKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
}

export default function MoggedStation({ onSaveSmartSession }: MoggedStationProps) {
  const [completedExercises, setCompletedExercises] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(MOGGED_PROGRESS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.date === getTodayDateKey() && Array.isArray(parsed.completed)) {
          return parsed.completed;
        }
      }
    } catch {}
    return [];
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeWorkoutExercise, setActiveWorkoutExercise] = useState<any>(null);

  const initiateExercise = (ex: any) => {
    if (completedExercises.includes(ex.name)) return;
    setActiveWorkoutExercise(ex);
  };

  const handleExerciseComplete = (ex: any) => {
    if (completedExercises.includes(ex.name)) return;
    const nextCompleted = [...completedExercises, ex.name];
    setCompletedExercises(nextCompleted);
    try {
      localStorage.setItem(
        MOGGED_PROGRESS_STORAGE_KEY,
        JSON.stringify({
          date: getTodayDateKey(),
          completed: nextCompleted,
        })
      );
    } catch {}
    playSound("success");

    if (onSaveSmartSession) {
      const durationMin = parseInt(ex.duration) || 2;
      const repsNum = parseInt(ex.reps) || 15;
          
      onSaveSmartSession({
        id: `mogged_${Date.now()}`,
        date: new Date().toISOString(),
        muscles: [ex.target],
        equipment: ["Bodyweight"],
        exercisesCount: 1,
        totalDurationMin: durationMin,
        exercises: [{
          id: Date.now(),
          name_en: ex.name,
          name_hi: "Aesthetic Routine",
          sets: ex.sets || 3,
          reps: repsNum,
          difficulty: ex.difficulty?.toLowerCase() || "beginner",
        }],
        notes: "Mogged Station Routine",
        rating: 5,
        isSmartValidation: true
      });
    }
  };

  const categories = [
    { id: 'all', name: 'All' },
    { id: 'jawline', name: 'Jawline' },
    { id: 'cheekbones', name: 'Cheekbones' },
    { id: 'eyes', name: 'Eyes' },
    { id: 'mouth', name: 'Mewing' },
    { id: 'glow', name: 'Skin Glow' },
  ];

  const moggingData = [
    {
      id: 'jawline',
      name: 'JAWLINE',
      icon: <Dumbbell className="w-5 h-5 text-white" />,
      color: "from-[#FF3366] to-[#FF9933]",
      exercises: [
        { name: 'Chin Tucks', sets: 3, reps: '15 Reps', duration: '2 MIN', difficulty: 'Beginner', target: 'Jawline' },
        { name: 'Jaw Resistance Press', sets: 3, reps: '12 Reps', duration: '2 MIN', difficulty: 'Intermediate', target: 'Jawline' },
        { name: 'Neck Raises', sets: 3, reps: '15 Reps', duration: '3 MIN', difficulty: 'Beginner', target: 'Neck' },
      ],
      tips: ['High Protein', 'No Mouth Breathing']
    },
    {
      id: 'cheekbones',
      name: 'CHEEKBONES',
      icon: <Sparkles className="w-5 h-5 text-white" />,
      color: "from-[#B66DFF] to-[#14F1E1]",
      exercises: [
        { name: 'Fish Face Hold', sets: 3, reps: '20 Sec', duration: '1 MIN', difficulty: 'Beginner', target: 'Cheekbones' },
        { name: 'Cheek Lift', sets: 3, reps: '15 Reps', duration: '2 MIN', difficulty: 'Intermediate', target: 'Cheek Muscles' },
        { name: 'Smile Resistance', sets: 3, reps: '15 Reps', duration: '2 MIN', difficulty: 'Advanced', target: 'Cheeks' },
      ],
      tips: ['Ice Massage', 'High Protein']
    },
    {
      id: 'eyes',
      name: 'HUNTER EYES',
      icon: <Target className="w-5 h-5 text-white" />,
      color: "from-[#14F1E1] to-[#00B4D8]",
      exercises: [
        { name: 'Eye Tightener', sets: 3, reps: '20 Reps', duration: '2 MIN', difficulty: 'Intermediate', target: 'Eye Area' },
        { name: 'Eyebrow Raises', sets: 3, reps: '15 Reps', duration: '1.5 MIN', difficulty: 'Beginner', target: 'Forehead/Eyes' },
        { name: 'Under Eye Lift', sets: 3, reps: '15 Reps', duration: '2 MIN', difficulty: 'Advanced', target: 'Under Eyes' },
      ],
      tips: ['Cold Compress', 'No Late Night Screens']
    },
    {
      id: 'mouth',
      name: 'MEWING',
      icon: <ShieldCheck className="w-5 h-5 text-white" />,
      color: "from-[#F72585] to-[#7209B7]",
      exercises: [
        { name: 'Tongue Posture Hold', sets: 3, reps: '30 Sec', duration: '1.5 MIN', difficulty: 'Intermediate', target: 'Mouth/Jaw' },
        { name: 'Tongue Roof Press', sets: 3, reps: '20 Reps', duration: '2 MIN', difficulty: 'Advanced', target: 'Palate' },
        { name: 'Mewing Hold Practice', sets: 3, reps: '1 Min', duration: '3 MIN', difficulty: 'Advanced', target: 'Face Structure' },
      ],
      tips: ['Correct Posture', 'Breathe through nose']
    },
    {
      id: 'glow',
      name: 'FACE GLOW',
      icon: <Droplets className="w-5 h-5 text-white" />,
      color: "from-[#FFD166] to-[#06D6A0]",
      exercises: [
        { name: 'Cold Water Splash', sets: 1, reps: '2 Min', duration: '2 MIN', difficulty: 'Beginner', target: 'Skin' },
        { name: 'Face Massage', sets: 1, reps: '3 Min', duration: '3 MIN', difficulty: 'Beginner', target: 'Blood Flow' },
        { name: 'Facial Blood Flow', sets: 3, reps: '20 Reps', duration: '3 MIN', difficulty: 'Intermediate', target: 'Face' },
      ],
      tips: ['Water', 'Moisturizer & Sunscreen']
    }
  ];

  const filteredData = moggingData.filter(section => {
    const matchesSearch = section.exercises.some(ex => ex.name.toLowerCase().includes(searchQuery.toLowerCase())) || section.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'all' || section.id === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const totalExercises = moggingData.reduce((acc, curr) => acc + curr.exercises.length, 0);
  const progressPercent = Math.round((completedExercises.length / totalExercises) * 100);

  return (
    <div className="flex-1 flex flex-col bg-[#050B1A] min-h-0 overflow-y-auto custom-scrollbar">
      {/* HERO SECTION */}
      <div className="relative pt-8 pb-12 px-6 overflow-hidden shrink-0">
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
           <div className="absolute top-[-50%] left-[-20%] w-[140%] h-[140%] bg-[radial-gradient(ellipse_at_center,rgba(20,241,225,0.1)_0%,rgba(5,11,26,0)_70%)] opacity-50 pointer-events-none" />
           <div className="absolute top-[20%] right-[-30%] w-[100%] h-[100%] bg-[radial-gradient(ellipse_at_center,rgba(182,109,255,0.1)_0%,rgba(5,11,26,0)_70%)] opacity-50 pointer-events-none" />
        </div>
        
        <div className="relative z-10 flex flex-col items-center text-center">
          <div className="inline-flex items-center gap-2 bg-[#14F1E1]/10 border border-[#14F1E1]/30 px-4 py-1.5 rounded-full mb-4">
            <Flame className="w-4 h-4 text-[#14F1E1]" />
            <span className="text-[10px] font-black text-[#14F1E1] uppercase tracking-widest">Aesthetics & Mogging</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-black text-white uppercase tracking-tighter mb-4 leading-none">
            Level Up <br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-[#14F1E1] to-[#B66DFF]">Your Look</span>
          </h1>
          <p className="text-neutral-400 text-sm font-medium max-w-md mx-auto">
            Train your jawline, neck, and facial muscles. Complete the daily aesthetic routines to maximize your physical presence.
          </p>
        </div>

        {/* PROGRESS BAR */}
        <div className="relative z-10 mt-8 max-w-md mx-auto bg-black/40 backdrop-blur-md border border-neutral-800 rounded-2xl p-4">
          <div className="flex items-center justify-between mb-2">
             <span className="text-xs font-bold text-white uppercase tracking-wider">Today's Progress</span>
             <span className="text-xs font-black text-[#14F1E1]">{completedExercises.length} / {totalExercises}</span>
          </div>
          <div className="w-full bg-neutral-900 rounded-full h-2 overflow-hidden">
             <motion.div 
               initial={{ width: 0 }} 
               animate={{ width: `${progressPercent}%` }} 
               className="h-full bg-gradient-to-r from-[#14F1E1] to-[#B66DFF]" 
             />
          </div>
        </div>

        {/* IDEA 2 & 11: AI POSTURE, JAWLINE & T-POSE APE-INDEX SCANNER */}
        <div className="relative z-10 mt-8 max-w-2xl mx-auto">
          <PostureSymmetryScanner />
        </div>

        {/* IDEAS 16, 17, 18: V-TAPER SOMATOTYPE, CASEY BUTT NATTY CEILING & 24H FACE DE-BLOAT */}
        <div className="relative z-10 mt-6 max-w-2xl mx-auto">
          <GeneticsAndDebloatLab />
        </div>

        {/* MODULE 2: THE MYSTERY DOJO (HIGH RISK / HIGH REWARD XP GAMBLE) */}
        <div className="relative z-10 mt-6 max-w-2xl mx-auto">
          <MysteryDojo />
        </div>
      </div>

      <div className="px-4 pb-6 sticky top-0 z-20 bg-[#050B1A]/90 backdrop-blur-xl pt-4 border-b border-neutral-800/50">
         {/* SEARCH */}
         <div className="relative mb-4">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-neutral-500" />
            </div>
            <input
              type="text"
              placeholder="Search routines..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="block w-full pl-12 pr-4 py-3.5 border border-neutral-800 rounded-xl leading-5 bg-black/50 text-white placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-[#14F1E1]/50 focus:border-[#14F1E1]/50 font-bold tracking-wide transition-colors"
            />
          </div>

          {/* CATEGORIES */}
          <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-2">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`shrink-0 px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
                  activeCategory === cat.id 
                  ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.3)]' 
                  : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
      </div>

      {/* CONTENT */}
      <div className="flex-1 p-4 space-y-8">
        <AnimatePresence mode="popLayout">
          {filteredData.map((section, idx) => (
            <motion.div 
              key={section.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-black/40 rounded-3xl border border-neutral-800 overflow-hidden"
            >
               {/* Section Header */}
               <div className={`p-5 bg-gradient-to-r ${section.color} relative overflow-hidden`}>
                 <div className="absolute inset-0 bg-black/40" />
                 <div className="relative z-10 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                       <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 shadow-lg">
                          {section.icon}
                       </div>
                       <h2 className="text-xl font-black text-white uppercase tracking-tighter drop-shadow-md">{section.name}</h2>
                    </div>
                    <div className="bg-black/30 backdrop-blur px-3 py-1.5 rounded-full border border-white/20">
                       <span className="text-[10px] font-black text-white uppercase tracking-widest">{section.exercises.length} Drills</span>
                    </div>
                 </div>
               </div>

               <div className="p-4 sm:p-5">
                 {/* Tips */}
                 <div className="flex flex-wrap gap-2 mb-6">
                    {section.tips.map((tip, i) => (
                       <span key={i} className="inline-flex items-center gap-1.5 bg-neutral-900 border border-neutral-800 px-2.5 py-1 rounded text-[10px] font-bold text-neutral-300 uppercase tracking-wider">
                          <Zap className="w-3 h-3 text-yellow-500 fill-current" /> {tip}
                       </span>
                    ))}
                 </div>

                 {/* Exercises Grid */}
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {section.exercises.map((ex, i) => {
                       const isCompleted = completedExercises.includes(ex.name);
                       return (
                         <div 
                           key={i}
                           onClick={() => initiateExercise(ex)}
                           className={`group relative overflow-hidden rounded-2xl border p-3 flex gap-4 cursor-pointer transition-all duration-300 ${
                             isCompleted 
                             ? 'bg-[#14F1E1]/10 border-[#14F1E1]/40 shadow-[0_0_15px_rgba(20,241,225,0.1)]' 
                             : 'bg-neutral-900/50 border-neutral-800 hover:border-neutral-600'
                           }`}
                         >
                           {isCompleted && (
                             <div className="absolute inset-0 bg-[#14F1E1]/5 pointer-events-none" />
                           )}
                           
                           {/* 3D Realistic Craniofacial & Holographic Anatomy Viewer */}
                           <div className="w-36 sm:w-48 shrink-0">
                             <Mogged3DFaceViewer
                               exerciseName={ex.name}
                               category="mogged"
                               compact={true}
                               interactive={true}
                             />
                           </div>

                           {/* Content */}
                           <div className="flex-1 min-w-0 py-1 flex flex-col justify-center">
                              <div className="flex justify-between items-start mb-1.5">
                                 <h4 className="text-white font-black text-sm sm:text-base uppercase tracking-tight truncate pr-2">{ex.name}</h4>
                                 <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 border transition-all ${
                                   isCompleted 
                                   ? 'bg-[#14F1E1] border-[#14F1E1] text-black shadow-[0_0_10px_rgba(20,241,225,0.5)] scale-110' 
                                   : 'bg-black border-neutral-700 text-neutral-500 group-hover:border-neutral-500'
                                 }`}>
                                   <CheckCircle2 className="w-4 h-4" />
                                 </div>
                              </div>
                              
                              <div className="flex flex-wrap gap-2 mb-2">
                                 <div className="flex items-center gap-1 text-[10px] font-black tracking-widest text-[#14F1E1] uppercase">
                                   <Target className="w-3 h-3" /> {ex.target}
                                 </div>
                                 <div className="flex items-center gap-1 text-[10px] font-black tracking-widest text-neutral-400 uppercase">
                                   <Clock className="w-3 h-3" /> {ex.duration}
                                 </div>
                              </div>
                              
                              <div className="bg-black border border-neutral-800 rounded px-2 py-1 inline-flex w-fit">
                                <span className="text-[10px] font-mono font-bold text-neutral-300">
                                  {ex.sets} SETS <span className="text-neutral-600 mx-1">×</span> {ex.reps}
                                </span>
                              </div>
                           </div>
                         </div>
                       );
                    })}
                 </div>
               </div>
            </motion.div>
          ))}
          {filteredData.length === 0 && (
             <div className="py-12 text-center">
                <Dumbbell className="w-12 h-12 text-neutral-700 mx-auto mb-4" />
                <h3 className="text-white font-black text-lg uppercase tracking-wider mb-2">No Routines Found</h3>
                <p className="text-neutral-500 text-sm">Try a different search term or category.</p>
             </div>
          )}
        </AnimatePresence>
      </div>
      <AnimatePresence>
        {activeWorkoutExercise && (
          <MoggedActiveWorkout 
            exercise={activeWorkoutExercise}
            onClose={() => setActiveWorkoutExercise(null)}
            onComplete={() => {
              handleExerciseComplete(activeWorkoutExercise);
              setActiveWorkoutExercise(null);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
