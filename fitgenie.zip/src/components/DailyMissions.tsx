import { doc, getDoc, setDoc, onSnapshot, collection, increment } from '../lib/firestore';
import { db } from '../lib/firebase';
import React, { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useAuth } from "../context/AuthContext";
import { useGuardianContext } from "../context/GuardianContext";
import { playSound } from "../utils/audio";
import {
  CheckCircle2,
  Flame,
  Target,
  Sparkles,
  Trophy,
  Package,
  PackageOpen,
  Crown,
} from "lucide-react";
import {
  getLocalDateString,
  fetchOrGenerateMissions,
} from "../utils/DailyMissionEngine";
import { ConfirmModal } from "./ConfirmModal";

export default function DailyMissions({
  onNavigateToExercises,
  onNavigateToGenerator,
}: {
  onNavigateToExercises?: (query: string) => void;
  onNavigateToGenerator?: () => void;
}) {
  const { user, updateProfileStats, updateUserXP } = useAuth();
  const { reportSuspiciousActivity } = useGuardianContext();
  const missionStartedAtRef = useRef<Record<string, number>>({});

  
  const [todayStr, setTodayStr] = useState(getLocalDateString());

  useEffect(() => {
    const handleFocus = () => {
      const current = getLocalDateString();
      if (current !== todayStr) {
        setTodayStr(current);
      }
    };
    
    window.addEventListener('focus', handleFocus);
    window.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') handleFocus();
    });
    
    const interval = setInterval(handleFocus, 60000);
    return () => {
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('visibilitychange', handleFocus);
      clearInterval(interval);
    };
  }, [todayStr]);

  const [missions, setMissions] = useState<any>(null);
  const [missionState, setMissionState] = useState<Record<string, 'idle' | 'started' | 'completed'>>({});
  const [missionStreak, setMissionStreak] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);
  const [celebrationText, setCelebrationText] = useState("");
  const [loading, setLoading] = useState(true);
  const [rewardClaimed, setRewardClaimed] = useState(false);
  const [showClaimModal, setShowClaimModal] = useState(false);

  useEffect(() => {
    async function loadMissions() {
      if (!user) {
        const localHistory = JSON.parse(localStorage.getItem('fitgenie_mission_history') || '[]');
        const todaysMissions = await fetchOrGenerateMissions(todayStr, localHistory);
        setMissions(todaysMissions);

        let streak = Number(localStorage.getItem('fitgenie_mission_streak') || '0');
        const lastDate = localStorage.getItem('lastMissionResetDate') || '';

        if (lastDate && lastDate !== todayStr) {
          const prevState = JSON.parse(localStorage.getItem(`fitgenie_mission_state_${lastDate}`) || '{}');
          const prevCompleted = Object.values(prevState).filter(s => s === 'completed').length;
          
          const [y1, m1, d1] = todayStr.split('-').map(Number);
          const [y2, m2, d2] = lastDate.split('-').map(Number);
          const diff = Math.floor((Date.UTC(y1, m1 - 1, d1) - Date.UTC(y2, m2 - 1, d2)) / (1000 * 60 * 60 * 24));
          
          if (diff > 1 || prevCompleted === 0) {
            streak = 0;
            localStorage.setItem('fitgenie_mission_streak', '0');
          }
        }

        if (lastDate !== todayStr) {
          localStorage.setItem('lastMissionResetDate', todayStr);
        }

        const localState = JSON.parse(localStorage.getItem(`fitgenie_mission_state_${todayStr}`) || '{}');
        setMissionState(localState);
        setMissionStreak(streak);
        setRewardClaimed(localStorage.getItem(`fitgenie_mission_reward_claimed_${todayStr}`) === 'true');
        setLoading(false);
        return;
      }
      try {
        const ref = doc(db, 'users', user.uid, 'mission_data', 'status');
        const snap = await getDoc(ref);
        
        let history: string[] = [];
        let state: any = {};
        let streak = 0;
        let lastDate = "";
        let claimed = false;
        
        if (snap.exists()) {
          const data = snap.data();
          history = data.history || [];
          streak = data.streak || 0;
          lastDate = data.lastDate || "";
          
          if (lastDate === todayStr) {
            state = data.state || {};
            claimed = data.rewardClaimed || false;
          } else if (lastDate) {
            const prevState = data.state || {};
            const prevCompleted = Object.values(prevState).filter(s => s === 'completed').length;
            
            const [y1, m1, d1] = todayStr.split('-').map(Number);
            const [y2, m2, d2] = lastDate.split('-').map(Number);
            const diff = Math.floor((Date.UTC(y1, m1 - 1, d1) - Date.UTC(y2, m2 - 1, d2)) / (1000 * 60 * 60 * 24));
            
            if (diff > 1 || prevCompleted === 0) {
              streak = 0;
            }
          }
        }
        
        const todaysMissions = await fetchOrGenerateMissions(todayStr, history, user.uid);
        setMissions(todaysMissions);
        setMissionState(state);
        setMissionStreak(streak);
        setRewardClaimed(claimed);
        
        if (lastDate !== todayStr) {
          await setDoc(
            ref,
            {
              history,
              streak,
              lastDate: todayStr,
              state: {},
              rewardClaimed: false,
            },
            { merge: true },
          );
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadMissions();
  }, [user, todayStr]);

  const completedCount = useMemo(() => {
    return Object.values(missionState).filter((s) => s === "completed").length;
  }, [missionState]);

  const isAllCompleted = completedCount === 3;

  useEffect(() => {
    if (
      isAllCompleted &&
      !rewardClaimed &&
      !showClaimModal &&
      completedCount > 0
    ) {
      setTimeout(() => {
        setShowClaimModal(true);
        playSound("success");
      }, 800);
    }
  }, [isAllCompleted, rewardClaimed, showClaimModal, completedCount]);

  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    missionId: string;
    currentStatus: string;
    title: string;
  } | null>(null);

  const processingMissions = useRef<Set<string>>(new Set());

  const handleAction = async (
    missionId: string,
    currentStatus: string,
    title: string,
  ) => {
    if (processingMissions.current.has(missionId)) return;

    if (currentStatus === "started") {
      const startedAt = missionStartedAtRef.current[missionId];
      if (startedAt) {
        const elapsedSec = (Date.now() - startedAt) / 1000;
        if (elapsedSec < 12) {
          reportSuspiciousActivity(
            `Daily Mission "${title}" start karte hi ${Math.max(1, Math.round(elapsedSec))}s me complete? Pehle sach me workout karo bro! Orb dekh raha hai 🛑`,
            "critical"
          );
          return;
        }
      }
      setConfirmState({ isOpen: true, missionId, currentStatus, title });
      return;
    }

    missionStartedAtRef.current[missionId] = Date.now();
    await performAction(missionId, currentStatus, title);
  };

  const performAction = async (
    missionId: string,
    currentStatus: string,
    title: string,
  ) => {
    processingMissions.current.add(missionId);

    try {
      playSound("click");
      if (currentStatus === "completed") return;

      const newStatus = (currentStatus === "idle" ? "started" : "completed") as
        "started" | "completed";
      const newState: Record<string, "idle" | "started" | "completed"> = {
        ...missionState,
        [missionId]: newStatus,
      };
      setMissionState(newState);

      if (newStatus === "completed") {
        playSound("success");
        setCelebrationText(`✅ ${title} Completed! +50 XP`);
        setShowCelebration(true);
        if (updateProfileStats) await updateProfileStats({ xpGained: 50, dailyGoalCompleted: true });
        else await updateUserXP(50);
        setTimeout(() => setShowCelebration(false), 2000);

        if (user) {
          try {
            const ref = doc(db, "users", user.uid, "mission_data", "status");
            const snap = await getDoc(ref);
            const history = snap.exists() ? snap.data().history || [] : [];
            if (!history.includes(missionId)) history.push(missionId);
            await setDoc(ref, { history, state: newState }, { merge: true });
          } catch (e) {
            console.error(e);
          }
        } else {
          localStorage.setItem(
            `fitgenie_mission_state_${todayStr}`,
            JSON.stringify(newState),
          );
        }
      } else {
        if (user) {
          const ref = doc(db, "users", user.uid, "mission_data", "status");
          await setDoc(ref, { state: newState }, { merge: true });
        } else {
          localStorage.setItem(
            `fitgenie_mission_state_${todayStr}`,
            JSON.stringify(newState),
          );
        }

        if (/workout/i.test(title) && onNavigateToGenerator) {
          onNavigateToGenerator();
        } else if (onNavigateToExercises) {
          onNavigateToExercises(title);
        }
      }
    } finally {
      processingMissions.current.delete(missionId);
    }
  };

  const isClaimingReward = useRef(false);

  const claimReward = async () => {
    if (isClaimingReward.current || rewardClaimed) return;
    isClaimingReward.current = true;

    try {
      setShowClaimModal(false);
      playSound("success");
      let newStreak = missionStreak + 1;
      setMissionStreak(newStreak);
      setRewardClaimed(true);

      let streakBonus = 50;
      await updateUserXP(streakBonus);

      setCelebrationText(`🔥 REWARD CLAIMED! +${streakBonus} XP`);
      setShowCelebration(true);
      setTimeout(() => setShowCelebration(false), 3000);

      if (user) {
        const ref = doc(db, "users", user.uid, "mission_data", "status");
        await setDoc(
          ref,
          { streak: newStreak, rewardClaimed: true },
          { merge: true },
        );
      } else {
        localStorage.setItem("fitgenie_mission_streak", String(newStreak));
        localStorage.setItem(
          `fitgenie_mission_reward_claimed_${todayStr}`,
          "true",
        );
      }
    } finally {
      isClaimingReward.current = false;
    }
  };

  if (loading || !missions) {
    return <div className="animate-pulse h-40 bg-[#0D1328] rounded-3xl" />;
  }

  return (
    <div className="space-y-4">
      <ConfirmModal
        isOpen={!!confirmState?.isOpen}
        message="Kya aapne sach me kiya hai? Agar ha to bahut achi bat hai great progress, agar app ese hi complete tap kar rahe ho to aap apne aap ko dhokha doge."
        onCancel={() => setConfirmState(null)}
        onConfirm={() => {
          if (confirmState) {
            performAction(
              confirmState.missionId,
              confirmState.currentStatus,
              confirmState.title,
            );
            setConfirmState(null);
          }
        }}
      />
      {showCelebration && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-[#14F1E1]/20 border border-[#14F1E1] text-[#14F1E1] px-4 py-2 rounded-xl text-xs font-bold uppercase backdrop-blur-md shadow-[0_0_20px_rgba(20,241,225,0.4)]"
        >
          {celebrationText}
        </motion.div>
      )}

      {showClaimModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#050B1A]/90 backdrop-blur-sm">
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            className="bg-[#0D1328] border border-[rgba(20,241,225,0.3)] p-6 rounded-3xl max-w-sm w-full text-center space-y-4 shadow-[0_0_30px_rgba(20,241,225,0.15)]"
          >
            <div className="w-20 h-20 bg-[#14F1E1]/10 rounded-full mx-auto flex items-center justify-center text-4xl shadow-[0_0_20px_#14F1E1]">
              🎁
            </div>
            <h3 className="text-2xl font-black uppercase text-white tracking-widest">
              MISSION COMPLETE
            </h3>
            <p className="text-xs text-[#9CA3AF] uppercase font-bold tracking-wider">
              All daily missions finished!
            </p>
            <button
              onClick={claimReward}
              className="w-full py-4 bg-[#14F1E1] text-[#050B1A] rounded-2xl font-black uppercase tracking-widest hover:shadow-[0_0_20px_#14F1E1] transition-all mt-4"
            >
              Claim Reward
            </button>
          </motion.div>
        </div>
      )}

      <div className="glass-card rounded-3xl p-5 relative overflow-hidden">
        <div className="flex justify-between items-center mb-4 border-b border-[rgba(20,241,225,0.15)] pb-3">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Target className="w-4 h-4 text-[#14F1E1]" /> DAILY MISSIONS
          </h2>
          <span className="text-xs font-mono text-[#14F1E1] font-bold">
            {completedCount}/3 Done
          </span>
        </div>

        <div className="space-y-3">
          {Object.values(missions).map((mission: any, idx: number) => {
            const status = missionState[mission.id] || "idle";
            const isDone = status === "completed";
            const isStarted = status === "started";

            return (
              <div
                key={mission.id}
                className={`p-3 rounded-2xl border flex items-center justify-between transition-all ${isDone ? "bg-[#0D1328] border-[#14F1E1]/30 opacity-60" : "bg-[#050B1A] border-[#4DA8FF]/20 hover:border-[#14F1E1]/50"}`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl ${isDone ? "bg-[#14F1E1]/20" : "bg-[#0D1328]"}`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-5 h-5 text-[#14F1E1]" />
                    ) : (
                      mission.icon
                    )}
                  </div>
                  <div>
                    <div
                      className={`text-xs font-bold uppercase tracking-wide ${isDone ? "text-white line-through" : "text-white"}`}
                    >
                      {mission.title}
                    </div>
                    <div className="text-[10px] text-[#9CA3AF] uppercase mt-0.5">
                      {mission.xpReward} XP
                    </div>
                  </div>
                </div>
                {!isDone && (
                  <button
                    onClick={() =>
                      handleAction(mission.id, status, mission.title)
                    }
                    className={`px-3 py-1.5 rounded-lg text-[9px] font-bold uppercase tracking-widest transition-all ${isStarted ? "bg-[#14F1E1] text-[#050B1A]" : "bg-[#4DA8FF]/20 text-[#4DA8FF] hover:bg-[#4DA8FF]/40"}`}
                  >
                    {isStarted ? "Complete" : "Start"}
                  </button>
                )}
                {isDone && (
                  <span className="px-3 py-1.5 rounded-lg text-[9px] font-bold uppercase tracking-widest bg-[#14F1E1]/10 text-[#14F1E1]">
                    Master
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
