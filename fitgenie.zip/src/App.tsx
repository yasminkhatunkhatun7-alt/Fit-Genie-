import { useWorkoutReminder } from "./hooks/useWorkoutReminder";
import { useFollowNotifications } from "./hooks/useFollowNotifications";
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AboutSection, PrivacyPolicySection, ContactUsSection, TermsOfServiceSection, SupportFeedbackSection } from "./components/InfoPages";
import { useState, useEffect, useMemo } from "react";
import BottomNavigation from "./components/BottomNavigation";
import AboutPage from "./components/AboutPage";
import ChatView from "./components/ChatView";
import WorkoutHistory from "./components/WorkoutHistory";
import MoggedStation from "./components/MoggedStation";
import Onboarding from "./components/Onboarding";
import HomeDashboard from "./components/HomeDashboard";
import StreakAnalyticsModal from "./components/StreakAnalyticsModal";
import { AppView, CompletedSession, Exercise } from "./types";
import { 
  Info, Zap, Flame, Award, Palette, Check, Sparkles,
  Menu, X, Home, MessageSquare, Dumbbell, Apple, TrendingUp, 
  Video, Calculator, CupSoda, Footprints, Target, Crown, 
  Bell, Settings, HelpCircle, Share2, Star, Shield, LogOut, BookOpen,
  Swords, User, Lock
, Mail, FileText} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useLocalStorageSync } from "./hooks/useLocalStorageSync";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { useGuardianContext } from "./context/GuardianContext";
import GuardianOrb from "./components/GuardianOrb";
import { playSound } from "./utils/audio";
import { useAppLanguage, setSavedAppLanguage } from "./utils/language";

import { BackgroundStepTracker } from "./components/BackgroundStepTracker";
import { useNativeFeatures } from "./hooks/useNativeFeatures";
import { useGenieTracker, GenieTrackerProvider } from "./context/GenieTrackerContext";

// Import sidebar component sectors
import ExerciseVideos from "./components/ExerciseVideos";
import NutritionLog from "./components/NutritionLog";
import PlateCalculator from "./components/PlateCalculator";
import MartialArts from "./components/MartialArts";
import HeightIncrease from "./components/HeightIncrease";
import ProfileView from "./components/ProfileView";
import SettingsScreen from "./components/SettingsScreen";
import DeveloperProfileView from "./components/DeveloperProfileView";
import AchievementsScreen from "./components/AchievementsScreen";
import CalisthenicsVideoLibrary from "./components/CalisthenicsVideoLibrary";
import ExercisesLibrary from "./components/ExercisesLibrary";
import ChallengesScreen from "./components/ChallengesScreen";
import GuildScreen from "./components/GuildScreen";
import RestRecoveryHub from "./components/RestRecoveryHub";
import { CalorieCalculator, WaterTrackerSection, StepCounterSection, 
  GoalsSection, PremiumSection, NotificationsSection, 
  ShareModal, RateModal, PrivacySection 
} from "./components/SidebarSections";
import { initBilling, verifyCoupon, GooglePlayBillingSimulator, PremiumGuard, handleSubscription } from "./components/PremiumGuard";
import { ErrorBoundary } from "./components/ErrorBoundary";

// Calculate any workout streak dynamically based on consecutive days (12:00 AM - 11:59 PM calendar days)
function calculateStreakForList(historyList: CompletedSession[]): number {
  let checkInDates: string[] = [];
  try {
    const raw = localStorage.getItem("fitgenie_daily_streak_dates");
    if (raw) checkInDates = JSON.parse(raw);
  } catch {
    // ignore
  }

  const allDateStrings = [
    ...historyList.map((s) => {
      const d = new Date(s.date);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      return `${yyyy}-${mm}-${dd}`;
    }),
    ...checkInDates.filter((d) => /^\d{4}-\d{2}-\d{2}$/.test(d)),
  ];

  if (allDateStrings.length === 0) return 0;

  const uniqueDates = Array.from(new Set(allDateStrings)).sort((a, b) =>
    b.localeCompare(a)
  ); // sort descending chronologically

  if (uniqueDates.length === 0) return 0;

  const today = new Date();
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;

  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, "0")}-${String(yesterday.getDate()).padStart(2, "0")}`;

  // If the most recent active date is neither today nor yesterday, active streak is 0
  if (uniqueDates[0] !== todayStr && uniqueDates[0] !== yesterdayStr) {
    return 0;
  }

  let streak = 1;
  let currentCheck = new Date(uniqueDates[0] + "T00:00:00");

  for (let i = 1; i < uniqueDates.length; i++) {
    const prevDate = new Date(uniqueDates[i] + "T00:00:00");
    const diffTime = currentCheck.getTime() - prevDate.getTime();
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) {
      streak++;
      currentCheck = prevDate;
    } else if (diffDays > 1) {
      break; // Streak broken
    }
  }

  return streak;
}

// Premium Luxury Visual Theme Definitions
const PREMIUM_THEMES = [
  {
    id: "akharas-lime",
    name: "Cyan Breeze",
    emoji: "💎",
    primary: "#06B6D4",
    bgClass: "bg-[#06B6D4]",
    borderClass: "border-[#06B6D4]",
    desc: "Vibrant custom cyan accent. Cold, crisp, high-performance vitality."
  },
  {
    id: "midnight-blue",
    name: "Midnight Blue",
    emoji: "🌌",
    primary: "#38bdf8",
    bgClass: "bg-[#38bdf8]",
    borderClass: "border-[#38bdf8]",
    desc: "Cosmic science engine blue. Sophisticated, cold, and calculated aesthetic."
  },
  {
    id: "electric-violet",
    name: "Electric Violet",
    emoji: "🔮",
    primary: "#a855f7",
    bgClass: "bg-[#a855f7]",
    borderClass: "border-[#a855f7]",
    desc: "Fluorescent synthwave high-octane purple. Tailored for late-night iron lifters."
  },
  {
    id: "crimson-edge",
    name: "Crimson Edge",
    emoji: "🩸",
    primary: "#ef4444",
    bgClass: "bg-[#ef4444]",
    borderClass: "border-[#ef4444]",
    desc: "Primal crimson and magma carbon. For explosive compound and power lift days."
  },
  {
    id: "gold-luxury",
    name: "Gold Luxury",
    emoji: "👑",
    primary: "#EAB308",
    bgClass: "bg-[#EAB308]",
    borderClass: "border-[#EAB308]",
    desc: "Pure imperial championship brass. Sleek luxury for dedicated gym builders."
  },
  {
    id: "teal-warrior",
    name: "Teal Warrior",
    emoji: "🥋",
    primary: "#00e5ff",
    bgClass: "bg-[#0a1416]",
    borderClass: "border-[#00e5ff]",
    desc: "Premium cyber-black foundation with high-contrast neon cyan highlights. Dynamic and technical."
  }
];

const VIEW_ORDER: Record<AppView, number> = {
  home: 0,
  dojo: 0.5,
  exercises: 2,
  calisthenics: 2.5,
  calisthenics_videos: 2.6,
  mogged: 3,
  achievements: 4,
  chat: 4.5,
  
  history: 5,
  about: 6,
  exercise_videos: 7,
  diet: 8,
  calorie_calc: 9,
  plate_calc: 9.1,
  water: 10,
  steps: 11,
  goals: 12,
  notifications: 13,
  support: 14,
  privacy: 15,
  martial_arts: 16,
  height_increase: 17,
  guilds: 17.5,
  recovery: 17.8,
  profile: 18, contact: 19, terms: 20, settings: 21, developer: 21.5,
};

const slideVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? "100%" : direction < 0 ? "-100%" : 0,
    opacity: 0,
  }),
  center: {
    x: 0,
    opacity: 1,
  },
  exit: (direction: number) => ({
    x: direction < 0 ? "100%" : direction > 0 ? "-100%" : 0,
    opacity: 0,
  }),
};

export default function App() {
  return (
    <AuthProvider>
      <GenieTrackerProvider>
        <AppContent />
        <GuardianOrb />
      </GenieTrackerProvider>
    </AuthProvider>
  );
}

export function AppContent() {
  useNativeFeatures();
  useWorkoutReminder();
  const { inAppNotification, setInAppNotification } = useFollowNotifications();
  const { logEvent } = useGenieTracker();
  const { user, profile, loading, profileRequired, updateProfileStats, signOutUser, refreshProfile, updateUserProfileFields } = useAuth();
  const [view, setView] = useState<AppView>("home");
  const { triggerEvent, setIsPanelOpen } = useGuardianContext();
  const [trustWarningToast, setTrustWarningToast] = useState<{ visible: boolean, score: number }>({ visible: false, score: 0 });

  useEffect(() => {
    const handleTrustWarning = (e: Event) => {
        const customEvent = e as CustomEvent;
        setTrustWarningToast({ visible: true, score: customEvent.detail?.score || 0 });
        setTimeout(() => {
            setTrustWarningToast(prev => ({ ...prev, visible: false }));
        }, 8000);
    };
    window.addEventListener('trust_warning', handleTrustWarning);
    return () => window.removeEventListener('trust_warning', handleTrustWarning);
  }, []);
  const [prevView, setPrevView] = useState<AppView>("home");
  const [showSidebar, setShowSidebar] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showRateModal, setShowRateModal] = useState(false);
  const [showStreakModal, setShowStreakModal] = useState(false);

  useEffect(() => {
    const handleOpenStreak = () => setShowStreakModal(true);
    window.addEventListener("open_streak_modal", handleOpenStreak);
    return () => window.removeEventListener("open_streak_modal", handleOpenStreak);
  }, []);

  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== "undefined" ? navigator.onLine : true);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  const [lastNavTime, setLastNavTime] = useState<number>(0);
  const [exerciseSearchQuery, setExerciseSearchQuery] = useState("");
  const [profileTargetId, setProfileTargetId] = useState<string | undefined>(undefined);

  const navigateToView = (newView: AppView, params?: any) => {
    const now = Date.now();
    if (now - lastNavTime < 120) return; // Guard against rapid multi-clicking
    setLastNavTime(now);
    if (newView !== view) {
      logEvent('NAVIGATE', { view: newView, from: view });
      if (newView === 'home') triggerEvent("nav_home");
      else if (newView === 'dojo') triggerEvent("nav_challenge");
      else if (newView === 'exercises' || newView === 'calisthenics') triggerEvent("nav_workout");
      else if (newView === 'profile') triggerEvent("nav_profile");
      else triggerEvent("focused");
      setPrevView(view);
      setView(newView);
      if (newView === 'exercises' && params?.searchQuery) {
        setExerciseSearchQuery(params.searchQuery);
      } else if (newView === "profile" && params?.userId) {
        setProfileTargetId(params.userId);
      } else if (newView === "profile") {
        setProfileTargetId(undefined);
      } else {
        setExerciseSearchQuery("");
      }
    }
  };

  const direction = VIEW_ORDER[view] === VIEW_ORDER[prevView]
    ? 0
    : VIEW_ORDER[view] > VIEW_ORDER[prevView] ? 1 : -1;
  const [showSplash, setShowSplash] = useState(true);
  const [milestoneCelebration, setMilestoneCelebration] = useState<{ title: string; subtitle: string; emoji: string } | null>(null);

  // Synced User storage state
  const [userPayload, setUserPayload] = useLocalStorageSync<{
    user: {
      name: string;
      age: number;
      gender: string;
      goal: string;
      level: string;
      onboardingDone: boolean;
    } | null;
  } | null>("fitgenie_user", null);

  const [onboardingDone, setOnboardingDone] = useState(() => {
    try {
      return !!localStorage.getItem("fitgenie_onboarding_completed");
    } catch {
      return false;
    }
  });

  // ADDED LOGGING FOR INVESTIGATION
  console.log("[App.tsx] Auth State Check:", {
    hasUser: !!user,
    userId: user?.uid,
    hasProfile: !!profile,
    profileOnboardingFlag: profile?.onboardingCompleted,
    localPayloadFlag: userPayload?.user?.onboardingDone,
    localStateFlag: onboardingDone
  });

  const isOnboardingDone = profile?.onboardingCompleted === true || (!profile && (!!userPayload?.user?.onboardingDone || onboardingDone));

  // Sync Firestore onboarding flags back to local storage on new login
  useEffect(() => {
    if (profile && profile.onboardingCompleted && !userPayload?.user?.onboardingDone) {
      const mappedGoal = profile.mainGoal || "fatburn";
      setUserPayload({
        user: {
          name: profile.name || profile.username || "Bhai",
          age: profile.age || 22,
          gender: profile.gender || "male",
          goal: mappedGoal,
          level: profile.level || "beginner",
          onboardingDone: true,
        },
      });
      localStorage.setItem("fitgenie_onboarding_completed", "true");
    }
  }, [profile, userPayload, setUserPayload]);

  useEffect(() => {
    initBilling();
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);
  
  // Synced Workout History storage state
  const [history, setHistory] = useLocalStorageSync<CompletedSession[]>("fitgenie_history", []);

  // Theme management with local storage and root document element updates
  const [theme, setTheme] = useLocalStorageSync<string>("fitgenie_theme", "midnight-blue");
  const [showSettings, setShowSettings] = useState(false);
  const [animationsEnabled, setAnimationsEnabled] = useLocalStorageSync<boolean>("celebratory_animations_enabled", true);

  useEffect(() => {
    let activeTheme = theme;
    if (theme === "royal-white") {
      activeTheme = "midnight-blue";
      setTheme("midnight-blue");
    }
    document.documentElement.setAttribute("data-theme", activeTheme);
  }, [theme]);

  // Sync and restore theme selection from the user's active cloud profile
  useEffect(() => {
    if (profile?.theme && profile.theme !== theme) {
      if (profile.theme === "royal-white") {
        setTheme("midnight-blue");
      } else {
        setTheme(profile.theme);
      }
    }
  }, [profile?.theme]);

  // Save changes callback
  const handleAddSession = (
    muscles: string[],
    equipment: string[],
    exercises: Exercise[],
    duration: number,
    rating: number,
    notes: string
  ) => {
    const newSession: CompletedSession = {
      id: `session_${Date.now()}`,
      date: new Date().toISOString(),
      muscles,
      equipment,
      exercisesCount: exercises.length,
      totalDurationMin: duration,
      exercises: exercises.map((ex) => ({
        id: ex.id,
        name_en: ex.name_en,
        name_hi: ex.name_hi,
        sets: ex.sets,
        reps: ex.reps,
        difficulty: ex.difficulty,
      })),
      rating,
      notes,
    };

    // Calculate if first workout of the day (before appending)
    const isFirstWorkoutToday = !history.some((s) => {
      const sDate = new Date(s.date);
      const now = new Date();
      return sDate.getFullYear() === now.getFullYear() &&
             sDate.getMonth() === now.getMonth() &&
             sDate.getDate() === now.getDate();
    });

    const oldStreak = calculateStreakForList(history);
    const updated = [newSession, ...history];
    const newStreak = calculateStreakForList(updated);

    setHistory(updated);

    // Trigger celebratory milestones & confetti
    if (isFirstWorkoutToday) {
      if (newStreak > oldStreak) {
        // Enriched streak count
        if (newStreak === 3 || newStreak === 5 || newStreak === 7 || newStreak === 10 || newStreak === 15 || newStreak === 30) {
          // Epic star shower for milestones
          setTimeout(() => {
            setMilestoneCelebration({
              title: `${newStreak}-Day Streak Milestone Reached! 👑`,
              subtitle: "Shabash! Keep leading the chart with incredible consistency!",
              emoji: "🏆",
            });
          }, 350);
        } else {
          // Standard day increase
          setTimeout(() => {
            setMilestoneCelebration({
              title: `Workout Logged! Day ${newStreak} Streak active! 🔥`,
              subtitle: "Terrific work! Your daily streak is burning bright!",
              emoji: "⚡",
            });
          }, 350);
        }
      } else {
        // First of the day, but streak did not increment (e.g. rest day broken, or first workout of overall record)
        setTimeout(() => {
          setMilestoneCelebration({
            title: "First Workout Today Completed! 🏅",
            subtitle: "Perfect start to the day. Let's build healthy habits!",
            emoji: "🎉",
          });
        }, 350);
      }

      // Auto dismiss celebration banner
      setTimeout(() => {
        setMilestoneCelebration(null);
      }, 4200);
    }

    if (profile) {
      updateProfileStats({
        xpGained: exercises.length * 30 + 100,
        workoutCompleted: true,
        completedWorkoutName: `Custom Workout: ${muscles.join(", ")} Split`
      });
    }
  };

  const handleDeleteSession = (id: string) => {
    const updated = history.filter((s) => s.id !== id);
    setHistory(updated);
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  const handleSaveSmartSession = (session: CompletedSession) => {
    // Calculate if first workout of the day (before appending)
    const isFirstWorkoutToday = !history.some((s) => {
      const sDate = new Date(s.date);
      const now = new Date();
      return sDate.getFullYear() === now.getFullYear() &&
             sDate.getMonth() === now.getMonth() &&
             sDate.getDate() === now.getDate();
    });

    const oldStreak = calculateStreakForList(history);
    const updated = [session, ...history];
    const newStreak = calculateStreakForList(updated);

    setHistory(updated);

    // Trigger celebratory milestones & confetti
    if (isFirstWorkoutToday) {
      if (newStreak > oldStreak) {
        // Enriched streak count
        if (newStreak === 3 || newStreak === 5 || newStreak === 7 || newStreak === 10 || newStreak === 15 || newStreak === 30) {
          // Epic star shower for milestones
          setTimeout(() => {
            setMilestoneCelebration({
              title: `${newStreak}-Day Streak Milestone Reached! 👑`,
              subtitle: "Shabash! Keep leading the chart with incredible consistency!",
              emoji: "🏆",
            });
          }, 350);
        } else {
          // Standard day increase
          setTimeout(() => {
            setMilestoneCelebration({
              title: `Workout Logged! Day ${newStreak} Streak active! 🔥`,
              subtitle: "Terrific work! Your daily streak is burning bright!",
              emoji: "⚡",
            });
          }, 350);
        }
      } else {
        // First of the day, but streak did not increment
        setTimeout(() => {
          setMilestoneCelebration({
            title: "First Workout Today Completed! 🏅",
            subtitle: "Perfect start to the day. Let's build healthy habits!",
            emoji: "🎉",
          });
        }, 350);
      }
    }
  };

  const handleUpdateSession = (updatedSession: CompletedSession) => {
    const updated = history.map((s) => s.id === updatedSession.id ? updatedSession : s);
    setHistory(updated);
  };

  // Seed sample data helper
  const handleSeedMockData = () => {
    const today = new Date();
    
    // Day objects for streak simulation
    const oneDayAgo = new Date();
    oneDayAgo.setDate(today.getDate() - 1);
    
    const twoDaysAgo = new Date();
    twoDaysAgo.setDate(today.getDate() - 2);

    const seeded: CompletedSession[] = [
      {
        id: "mock_1",
        date: today.toISOString(),
        muscles: ["Chest", "Triceps"],
        equipment: ["dumbbells"],
        exercisesCount: 3,
        totalDurationMin: 35,
        exercises: [
          { id: 101, name_en: "Dumbbell Bench Press", name_hi: "डम्बल बेंच प्रेस", sets: 4, reps: 12, difficulty: "intermediate" },
          { id: 102, name_en: "Triceps Overhead Extension", name_hi: "ट्राइसेप्स ओवरहेड एक्सटेंशन", sets: 3, reps: 15, difficulty: "beginner" },
          { id: 103, name_en: "Diamond Pushups", name_hi: "डायमंड पुशअप्स", sets: 3, reps: 10, difficulty: "intermediate" }
        ],
        rating: 5,
        notes: "Chest felt completely pumped! Drank a cold banana shake with almonds straight after training. Desi fuel works wonders."
      },
      {
        id: "mock_2",
        date: oneDayAgo.toISOString(),
        muscles: ["Back", "Biceps"],
        equipment: ["none"],
        exercisesCount: 2,
        totalDurationMin: 25,
        exercises: [
          { id: 201, name_en: "Towel Pull-ups", name_hi: "तौलिया पुल-अप्स", sets: 4, reps: 8, difficulty: "advanced" },
          { id: 202, name_en: "Chin-ups", name_hi: "चिन-अप्स", sets: 3, reps: 10, difficulty: "intermediate" }
        ],
        rating: 4,
        notes: "Did bodyweight training in the local garden outside. Clean strict form, felt amazing."
      },
      {
        id: "mock_3",
        date: twoDaysAgo.toISOString(),
        muscles: ["Legs", "Core"],
        equipment: ["none"],
        exercisesCount: 3,
        totalDurationMin: 40,
        exercises: [
          { id: 301, name_en: "Desi Baithak (Squats)", name_hi: "देसी बैठक", sets: 4, reps: 25, difficulty: "beginner" },
          { id: 302, name_en: "Plank Hold", name_hi: "प्लैंक होल्ड", sets: 3, reps: 60, difficulty: "intermediate" },
          { id: 303, name_en: "Flutter Kicks", name_hi: "फ्लटर किक्स", sets: 3, reps: 20, difficulty: "beginner" }
        ],
        rating: 5,
        notes: "25 reps per set on squats was highly taxing! Consumed soaked chana and paneer post workout for lean nitrogen uptake."
      }
    ];

    setHistory(seeded);
  };

  // Force-reset step or generation state when clicking logo
  const handleReset = () => {
    // Simply transitions smoothly
  };

  const { lang: appLanguage, setLang: setAppLanguage, t } = useAppLanguage();
  const [showRecalibrateOnboarding, setShowRecalibrateOnboarding] = useState(false);

  const handleOnboardingComplete = async (userData: {
    name: string;
    gender: string;
    dateOfBirth: string;
    height: number;
    weight: number;
    targetWeight: number;
    bodyType: string;
    activityLevel: string;
    mainGoal: string;
    progressPace: string;
    bmi: number;
    bmr: number;
    dailyCalorieTarget: number;
    waterIntakeGoal: number;
    onboardingCompleted: boolean;
    appLanguage?: "hinglish" | "english";
    trainingPath?: "calisthenics" | "gym" | "home_jugaad" | "aesthetics";
    dietPreference?: "veg" | "egg" | "nonveg";
    kitchenSetup?: "hostel" | "home";
    currentBfPercent?: number;
    dreamPhysique?: string;
    warriorClass?: string;
    glowUpStartDate?: string;
    aiBaselineScore?: number;
  }) => {
    const fullPayload = {
      user: {
        name: userData.name,
        age: 22,
        gender: userData.gender,
        goal: userData.mainGoal,
        level: "beginner",
        onboardingDone: true,
      },
    };
    
    try {
      // Clear chat history and set onboarding local indicator
      localStorage.removeItem("fitgenie_mogged_chat");
      localStorage.setItem("fitgenie_onboarding_completed", "true");
      if (userData.appLanguage) setSavedAppLanguage(userData.appLanguage);
      if (userData.trainingPath) localStorage.setItem("fitgenie_training_path", userData.trainingPath);
      if (userData.dietPreference) localStorage.setItem("fitgenie_diet_pref", userData.dietPreference);
      if (userData.kitchenSetup) localStorage.setItem("fitgenie_kitchen_setup", userData.kitchenSetup);
      if (userData.warriorClass) localStorage.setItem("fitgenie_warrior_class", userData.warriorClass);
      if (userData.mainGoal) localStorage.setItem("fitgenie_main_goal", userData.mainGoal);
      if (userData.dreamPhysique) localStorage.setItem("fitgenie_dream_physique", userData.dreamPhysique);
      
      // Sync water goals to local nutrition state
      localStorage.setItem("fitgenie_nutrition_goals", JSON.stringify({
        proteinGoal: Math.max(Math.round(userData.weight * 2), 80),
        waterGoal: userData.waterIntakeGoal
      }));
    } catch (e) {
      console.warn("localStorage blocked:", e);
    }

    setUserPayload(fullPayload);
    setShowRecalibrateOnboarding(false);

    // Save full data profile to Firestore databases
    if (user) {
      try {
        // Use local AuthContext directly
        const fGoal = userData.mainGoal === "muscle" ? "Muscle Gain" : userData.mainGoal === "fatburn" ? "Fat Loss" : userData.mainGoal === "strength" ? "Strength & Power" : "General Fitness";
        
        // Calculate age from DOB
        const today = new Date();
        const birthDate = new Date(userData.dateOfBirth);
        let calculatedAge = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
          calculatedAge--;
        }
        const ageVal = Math.max(12, calculatedAge || 22);
        const currentXp = Number(profile?.xp || 0);

        await updateUserProfileFields({
          name: userData.name.trim(),
          username: profile?.username || userData.name.trim(),
          gender: userData.gender,
          dateOfBirth: userData.dateOfBirth,
          age: ageVal,
          height: userData.height,
          weight: userData.weight,
          targetWeight: userData.targetWeight,
          bodyType: userData.bodyType,
          activityLevel: userData.activityLevel,
          mainGoal: userData.mainGoal,
          progressPace: userData.progressPace,
          bmi: userData.bmi,
          bmr: userData.bmr,
          dailyCalorieTarget: userData.dailyCalorieTarget,
          waterIntakeGoal: userData.waterIntakeGoal,
          appLanguage: userData.appLanguage || "hinglish",
          trainingPath: userData.trainingPath || "calisthenics",
          dietPreference: userData.dietPreference || "veg",
          kitchenSetup: userData.kitchenSetup || "home",
          currentBfPercent: userData.currentBfPercent || 18,
          dreamPhysique: userData.dreamPhysique || "cali_ninja",
          warriorClass: userData.warriorClass || "Street Calisthenics Assassin",
          glowUpStartDate: userData.glowUpStartDate || new Date().toISOString().split("T")[0],
          aiBaselineScore: userData.aiBaselineScore || 78,
          xp: currentXp + 100,
          goal: fGoal,
          onboardingDone: true,
          onboardingCompleted: true
        });
        await refreshProfile();
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : String(err);
        if (!errMsg.includes("the client is offline")) {
          console.error("Failed to sync onboarding details to Firestore:", err);
        }
      }
    }
  };

  // Calculate current workout streak based on consecutive days
  const streakCount = profile?.streak || 0;

  // Calculate dynamic calendar grid mapping the last 7 days ending today
  const headerCalendar = useMemo(() => {
    const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const result = [];
    
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      const targetDateStr = `${yyyy}-${mm}-${dd}`;
      
      const workoutsCount = history.filter((s) => {
        const sDate = new Date(s.date);
        const sDateStr = `${sDate.getFullYear()}-${String(sDate.getMonth() + 1).padStart(2, "0")}-${String(sDate.getDate()).padStart(2, "0")}`;
        return sDateStr === targetDateStr;
      }).length;
      const hasWorkout = workoutsCount > 0;

      const dayName = daysOfWeek[d.getDay()];
      const dayInitial = dayName.charAt(0);

      result.push({
        dayName,
        dayInitial,
        dateNum: d.getDate(),
        dateStr: targetDateStr,
        done: hasWorkout,
        workoutsCount,
        isToday: i === 0,
      });
    }
    return result;
  }, [history]);

  if (showSplash || loading) {
    return (
      <div 
        className="fixed inset-0 z-[9999] bg-[#050B1A] flex flex-col items-center justify-center select-none" 
        id="app-splash-screen"
      >
        <div className="text-center space-y-6">
          <motion.div
            initial={{ scale: 0.85, opacity: 0 }}
            animate={{ 
              scale: [0.96, 1.04, 1],
              opacity: 1,
              boxShadow: [
                "0 0 15px rgba(20,241,225,0.2)",
                "0 0 35px rgba(20,241,225,0.45)",
                "0 0 15px rgba(20,241,225,0.2)"
              ]
            }}
            transition={{ 
              duration: 2, 
              ease: "easeInOut",
              repeat: Infinity
            }}
            className="w-24 h-24 rounded-3xl bg-[#0A1128] border-2 border-[#14F1E1] flex items-center justify-center mx-auto"
          >
            <Sparkles className="w-11 h-11 text-[#14F1E1] animate-pulse" />
          </motion.div>

          <div className="space-y-1.5">
            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="text-4xl font-black uppercase tracking-widest text-white"
            >
              FIT <span className="text-[#14F1E1]">GENIE</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="text-[10px] text-[#9CA3AF] uppercase tracking-[0.25em] font-bold"
            >
              Personal Fitness & Training Partner
            </motion.p>
          </div>
        </div>

        <div className="absolute bottom-10 flex flex-col items-center gap-1.5">
          <div className="flex gap-1.5 animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-[#14F1E1]" />
            <span className="w-1.5 h-1.5 rounded-full bg-[#B66DFF]" />
            <span className="w-1.5 h-1.5 rounded-full bg-[#14F1E1]" />
          </div>
          <span className="text-[9px] text-neutral-500 font-mono font-black uppercase tracking-widest mt-1">v2.0.0 Pro Edition</span>
        </div>
      </div>
    );
  }

  if (!user || !isOnboardingDone || showRecalibrateOnboarding) {
    return (
      <Onboarding
        onComplete={handleOnboardingComplete}
        isRecalibrating={showRecalibrateOnboarding}
        onCancelRecalibrate={() => setShowRecalibrateOnboarding(false)}
      />
    );
  }

  return (
    <div className="min-h-screen w-full overflow-x-hidden bg-brand-bg text-white font-sans flex flex-col selection:bg-brand-accent selection:text-brand-bg pb-24" id="app-viewport">

      <BackgroundStepTracker />
      
      {/* Trust Warning Toast */}
      <AnimatePresence>
        {trustWarningToast.visible && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -50, scale: 0.95 }}
            className="fixed top-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-[9999] bg-zinc-950 border border-red-500/30 rounded-2xl p-4 shadow-2xl overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-red-500/20">
              <motion.div 
                initial={{ width: "100%" }}
                animate={{ width: "0%" }}
                transition={{ duration: 8, ease: "linear" }}
                className="h-full bg-red-500"
              />
            </div>
            <div className="flex items-start gap-4">
              <div className="p-3 bg-red-500/10 rounded-xl text-red-500 shrink-0">
                <Flame className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-white font-bold text-sm mb-1 uppercase tracking-wider">Critical Trust Alert</h4>
                <p className="text-zinc-400 text-xs mb-3 leading-relaxed">
                  Your Trust Score has dropped to <span className="text-red-400 font-bold">{trustWarningToast.score}%</span>. Complete recovery missions to restore access to features.
                </p>
                <div className="flex gap-2">
                  <button 
                    onClick={() => {
                      setTrustWarningToast(prev => ({ ...prev, visible: false }));
                      setIsPanelOpen(true);
                    }}
                    className="flex-1 bg-red-500 hover:bg-red-600 text-white text-xs font-bold uppercase tracking-wider py-2 rounded-lg transition-colors cursor-pointer"
                  >
                    View Recovery Missions
                  </button>
                  <button 
                    onClick={() => setTrustWarningToast(prev => ({ ...prev, visible: false }))}
                    className="px-3 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-lg transition-colors flex items-center justify-center cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Offline Alert Banner */}
      {!isOnline && (
        <div className="bg-red-950/95 border-b border-red-800 text-white px-4 py-2 text-center text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 select-none z-[100] animate-pulse shrink-0" id="offline-network-banner">
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping shrink-0" />
          <span>OFFLINE: Fit Genie running in offline local mode. Workout logs save to local cache, but videos/syncing require internet.</span>
        </div>
      )}

      {/* Immersive 3D Glass Command Header */}
      <div className="bg-gradient-to-r from-[#060C1E]/95 via-[#0B142C]/95 to-[#060C1E]/95 backdrop-blur-xl border-b border-[#14F1E1]/25 py-3 px-3 sm:px-5 text-center select-none flex flex-wrap items-center justify-between gap-2 sticky top-0 z-40 shadow-[0_10px_30px_rgba(0,0,0,0.85),0_1px_0_rgba(20,241,225,0.2)] md:px-8" id="app-main-header">
        <div className="flex items-center gap-1.5 sm:gap-2.5 flex-wrap">
          {/* Sidebar Menu Trigger */}
          <button
            onClick={() => {
              playSound("click");
              setShowSidebar(true);
            }}
            className="p-1.5 px-2.5 rounded-xl border border-[#14F1E1]/35 bg-[#0A1329]/90 hover:border-[#14F1E1] text-neutral-300 hover:text-[#14F1E1] transition-all cursor-pointer active:scale-95 flex items-center gap-1.5 shadow-[0_0_15px_rgba(20,241,225,0.12),inset_0_1px_1px_rgba(255,255,255,0.15)]"
            title="Open Menu"
            id="open-sidebar-menu-btn"
          >
            <Menu className="w-4 h-4 text-brand-accent" />
            <span className="text-[10px] uppercase font-black tracking-wider text-zinc-200 hidden xs:inline">Menu</span>
          </button>

          {/* 3D Holographic Core Emblem */}
          <div className="relative w-7 h-7 flex items-center justify-center">
            <svg viewBox="0 0 36 36" className="w-full h-full">
              <polygon
                points="18,2 32,10 32,26 18,34 4,26 4,10"
                fill="rgba(20,241,225,0.12)"
                stroke="#14F1E1"
                strokeWidth="1.8"
              />
              <polygon
                points="18,7 27,12 27,24 18,29 9,24 9,12"
                fill="rgba(182,109,255,0.2)"
                stroke="#B66DFF"
                strokeWidth="1.2"
              />
              <circle cx="18" cy="18" r="3.5" fill="#14F1E1" />
            </svg>
          </div>

          <h1 className="text-sm sm:text-lg font-black tracking-widest uppercase flex items-center gap-1 drop-shadow-[0_0_10px_rgba(20,241,225,0.3)]">
            FIT <span className="text-brand-accent">GENIE</span>
          </h1>
          
          {/* Premium Theme Switcher Trigger */}
          <button
            onClick={() => setShowSettings(true)}
            className="p-1 px-2 shrink-0 rounded-full bg-brand-surface border border-brand-border hover:border-brand-accent/40 text-neutral-400 hover:text-brand-accent transition-all text-[9px] uppercase font-black tracking-widest flex items-center gap-1 cursor-pointer active:scale-95"
            title="Premium Theme Studio"
            id="premium-theme-button-header"
          >
            <Palette className="w-3 h-3 text-brand-accent animate-pulse" />
            <span className="hidden sm:inline text-white/90">{t("Theme", "Theme")}</span>
          </button>

          {/* 1-Tap Bilingual Switcher (Hinglish vs English) */}
          <button
            onClick={() => {
              playSound("click");
              setAppLanguage(appLanguage === "hinglish" ? "english" : "hinglish");
            }}
            className="p-1 px-2.5 shrink-0 rounded-full bg-[#14F1E1]/15 border border-[#14F1E1]/40 text-[#14F1E1] text-[9px] uppercase font-black tracking-widest flex items-center gap-1 cursor-pointer active:scale-95"
            title="Switch App Language (Hinglish / English)"
          >
            <span>{appLanguage === "hinglish" ? "🇮🇳 Hinglish" : "🌐 English"}</span>
          </button>
        </div>
        
        {/* Streak & Last 7 Days calendar grid at top bar */}
        <div className="flex items-center gap-2" id="header-streak-calendar-wrapper">
          {/* Flame streak count pill (Click to open Streak & Consistency Tracker) */}
          <button
            type="button"
            onClick={() => {
              playSound("click");
              setShowStreakModal(true);
            }}
            className={`flex items-center gap-1 border px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider transition-all active:scale-95 cursor-pointer ${
              streakCount > 0 
                ? "bg-brand-accent/10 border-brand-accent/30 text-brand-accent hover:border-brand-accent animate-pulse-slow shadow-[0_0_12px_rgba(20,241,225,0.18)]" 
                : "bg-neutral-900 border-neutral-850 text-neutral-500 hover:text-white"
            }`}
            title={`Active streak: ${streakCount} consecutive days — Tap to view Streak Calendar`}
          >
            <Flame className={`w-3 h-3 ${streakCount > 0 ? "fill-brand-accent" : ""} ${headerCalendar.find(d => d.isToday)?.done ? "drop-shadow-[0_0_8px_rgba(20,241,225,0.9)] scale-110 animate-pulse transition-all duration-300" : "transition-all duration-300"}`} />
            <span>{streakCount} {streakCount === 1 ? "Day" : "Days"}</span>
          </button>

          {/* Mini 7-day calendar row (shown on tablet/desktop to keep mobile header clean) */}
          <div className="hidden md:flex items-center gap-1 select-none" id="header-mini-calendar-row">
            {headerCalendar.map((day, idx) => (
              <div 
                key={`${day.dateStr}-${idx}`}
                className={`group relative w-4 h-5 rounded-md flex flex-col items-center justify-center text-[7px] font-mono font-black border transition-all ${
                  day.done 
                    ? "bg-brand-accent border-brand-accent text-brand-bg shadow-sm cursor-pointer" 
                    : day.isToday 
                      ? "bg-brand-accent/15 border-brand-accent/35 text-brand-accent cursor-pointer" 
                      : "bg-[#141414] border-[#222] text-[#444] cursor-pointer"
                }`}
              >
                <span className="scale-[0.85] leading-none">{day.dayInitial}</span>

                {/* Custom Tooltip */}
                <div className="absolute top-full right-0 md:left-1/2 md:-translate-x-1/2 mt-3 bg-[#0A0A0A] border border-white/10 text-white py-2 px-3 rounded-xl opacity-0 group-hover:opacity-100 group-active:opacity-100 pointer-events-none transition-all duration-200 whitespace-nowrap z-50 shadow-2xl flex items-center gap-3">
                  <span className="font-black text-white/50 uppercase tracking-widest text-[9px]">{day.dayName} {day.dateNum}</span>
                  <div className="w-px h-3 bg-white/20"></div>
                  <span className="font-black text-[11px] text-brand-accent">
                    {day.workoutsCount > 0 ? `${day.workoutsCount} Workout${day.workoutsCount > 1 ? 's' : ''} 🔥` : 'Rest Day 💤'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Global 3D Perspective Cyber-Grid Floor & Ambient Energy Spores */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        {/* Top Radial Nebula Glow */}
        <div
          className="absolute -top-32 left-1/2 -translate-x-1/2 w-[650px] h-[320px] rounded-full opacity-20 blur-[110px]"
          style={{
            background: "radial-gradient(circle, #14F1E1 0%, #B66DFF 60%, transparent 100%)",
          }}
        />
        {/* 3D Perspective Floor Grid */}
        <div
          className="absolute bottom-0 left-0 right-0 h-[42vh] opacity-[0.14]"
          style={{
            backgroundImage:
              "linear-gradient(to right, rgba(20,241,225,0.28) 1px, transparent 1px), linear-gradient(to bottom, rgba(182,109,255,0.24) 1px, transparent 1px)",
            backgroundSize: "44px 44px",
            transform: "perspective(420px) rotateX(68deg) scale(1.6)",
            transformOrigin: "bottom center",
            maskImage: "linear-gradient(to top, rgba(0,0,0,1) 15%, transparent 95%)",
            WebkitMaskImage: "linear-gradient(to top, rgba(0,0,0,1) 15%, transparent 95%)",
          }}
        />
      </div>

      {/* Main Page Layout Wrapper */}
      <main className="flex-grow overflow-x-hidden relative z-10">
        <div className="w-full">
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={view}
              custom={direction}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: "spring", stiffness: 380, damping: 38 },
                opacity: { duration: 0.15 },
              }}
            >
              <ErrorBoundary key={view}>
                {view === "home" && (
                  <HomeDashboard
                    onNavigateToCoach={() => navigateToView("mogged")}
                    onNavigateToExercises={(query) => navigateToView("exercises", { searchQuery: query })}
                    onOpenRecalibrate={() => setShowRecalibrateOnboarding(true)}
                    onSaveSmartSession={handleSaveSmartSession}
                    streakCount={streakCount}
                    history={history}
                  />
                )}
                {view === "dojo" && (
                  <ChallengesScreen onNavigateToView={navigateToView} />
                )}
                {view === "exercises" && <ExercisesLibrary forceMode="workouts" initialSearchQuery={exerciseSearchQuery} onSaveSmartSession={handleSaveSmartSession} />}
                {view === "calisthenics" && <ExercisesLibrary forceMode="calisthenics" onSaveSmartSession={handleSaveSmartSession} />}
                {view === "calisthenics_videos" && <CalisthenicsVideoLibrary />}
                {view === "mogged" && <MoggedStation onSaveSmartSession={handleSaveSmartSession} />}
                {view === "chat" && <ChatView />}
                {view === "achievements" && <AchievementsScreen />}
                {view === "history" && (
                  <WorkoutHistory
                    history={history}
                    onDeleteSession={handleDeleteSession}
                    onClearAll={handleClearHistory}
                    onUpdateSession={handleUpdateSession}
                    onSeedMockData={handleSeedMockData}
                    onNavigateToExercises={() => navigateToView("exercises")}
                  />
                )}
                {view === "exercise_videos" && (
                  <PremiumGuard>
                    <ExerciseVideos />
                  </PremiumGuard>
                )}
                {view === "martial_arts" && <MartialArts />}
                {view === "height_increase" && <HeightIncrease />}
                {view === "guilds" && <GuildScreen onNavigateToView={navigateToView} />}
                {view === "recovery" && <RestRecoveryHub onNavigateToView={navigateToView} />}
                {view === "diet" && <NutritionLog />}
                {view === "calorie_calc" && <CalorieCalculator />}
                {view === "plate_calc" && <PlateCalculator />}
                {view === "water" && <WaterTrackerSection />}
                {view === "steps" && <StepCounterSection />}
                {view === "goals" && <GoalsSection />}
                {view === "notifications" && <NotificationsSection />}
                {view === "support" && <SupportFeedbackSection onNavigateToView={navigateToView} />}
                {view === "about" && <AboutSection onNavigateToView={navigateToView} />}
                {view === "contact" && <ContactUsSection onNavigateToView={navigateToView} />}
                {view === "terms" && <TermsOfServiceSection onNavigateToView={navigateToView} />}
                {view === "privacy" && <PrivacyPolicySection onNavigateToView={navigateToView} />}
                {view === "settings" && <SettingsScreen onBack={() => navigateToView("profile")} onNavigateToView={navigateToView} />}
                {view === "developer" && <DeveloperProfileView onBack={() => navigateToView("settings")} />}
                {view === "profile" && <ProfileView history={history} streakCount={streakCount} onNavigateToView={navigateToView} targetUserId={profileTargetId} />}
              </ErrorBoundary>
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      <AnimatePresence>
        {inAppNotification && (
          <motion.div
            key="in-app-notif"
            initial={{ opacity: 0, scale: 0.9, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: -20 }}
            onClick={() => setInAppNotification(null)}
            className="fixed top-4 left-4 right-4 md:left-auto md:right-6 md:w-80 z-[100] p-4 bg-[#0A1128] border border-[#14F1E1]/40 rounded-2xl shadow-[0_0_20px_rgba(20,241,225,0.2)] flex gap-4 items-center overflow-hidden cursor-pointer backdrop-blur-md"
          >
            <div className="w-10 h-10 shrink-0 rounded-xl bg-[#14F1E1]/20 flex items-center justify-center relative z-10 text-white">
              <Bell className="w-5 h-5 text-[#14F1E1] animate-pulse" />
            </div>
            <div className="relative z-10 flex-1 min-w-0">
              <h4 className="text-sm font-black uppercase text-white truncate tracking-tight">{inAppNotification.title}</h4>
              <p className="text-xs text-brand-muted font-bold truncate mt-0.5">{inAppNotification.body}</p>
            </div>
            <button 
              onClick={(e) => { e.stopPropagation(); setInAppNotification(null); }}
              className="p-1 rounded-full bg-white/10 text-brand-muted hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Milestone celebration toast */}
      <AnimatePresence>
        {milestoneCelebration && (
          <motion.div
            initial={{ opacity: 0, scale: 0.85, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: -20 }}
            className="fixed bottom-26 left-4 right-4 md:left-auto md:right-6 md:w-96 z-50 p-5 bg-[#0C0C0C] border border-brand-accent/40 rounded-2xl shadow-[0_0_25px_var(--brand-accent-glow)] flex gap-4 items-center overflow-hidden"
            id="milestone-toast-celebration"
          >
            {/* Ambient radial dynamic glow background */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,var(--brand-accent-glow-subtle),transparent_70%)] pointer-events-none" />

            <div className="w-12 h-12 shrink-0 rounded-xl bg-brand-accent/10 border border-brand-accent/20 flex items-center justify-center text-2xl relative z-10">
              <motion.span 
                animate={{ scale: [1, 1.25, 1] }} 
                transition={{ repeat: Infinity, duration: 1.8 }}
              >
                {milestoneCelebration.emoji}
              </motion.span>
            </div>
            
            <div className="flex-grow text-left relative z-10">
              <h4 className="text-[10px] font-black uppercase text-brand-accent tracking-widest font-mono">
                Milestone Earned!
              </h4>
              <p className="text-xs font-black text-white leading-snug mt-0.5">
                {milestoneCelebration.title}
              </p>
              <p className="text-[9px] text-[#A3A3A3] uppercase font-bold tracking-wider mt-0.5">
                {milestoneCelebration.subtitle}
              </p>
            </div>

            <button
              onClick={() => setMilestoneCelebration(null)}
              className="text-xs text-neutral-500 hover:text-white cursor-pointer px-2 py-1 uppercase font-black relative z-10"
            >
              ✕
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Full-screen backdrop & Right Side Slide-out Drawer */}
      <AnimatePresence>
        {showSettings && (
          <>
            {/* Backdrop Blur overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettings(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] cursor-pointer"
              id="theme-drawer-backdrop"
            />
            
            {/* Theme Sheet Drawer */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 24, stiffness: 220 }}
              className="fixed top-0 right-0 bottom-0 h-full w-full max-w-sm bg-[#0C0C0C] border-l border-brand-border z-[101] shadow-[0_0_50px_rgba(0,0,0,0.95)] p-6 overflow-y-auto flex flex-col justify-between"
              id="theme-cabinet-drawer"
            >
              <div className="space-y-6">
                {/* Header section of Drawer */}
                <div className="flex items-center justify-between pb-4 border-b border-neutral-900">
                  <div className="flex items-center gap-2">
                    <Palette className="w-5 h-5 text-brand-accent animate-pulse" />
                    <div>
                      <h3 className="text-sm font-black uppercase tracking-wider text-white">THEME STUDIO</h3>
                      <p className="text-[10px] text-brand-muted uppercase font-bold tracking-tight">Select premium visual skin</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setShowSettings(false)}
                    className="p-1 px-2.5 bg-neutral-900 border border-brand-border hover:bg-brand-accent hover:text-brand-bg rounded-lg text-[10px] font-black uppercase tracking-wider cursor-pointer transition-all"
                  >
                    Close
                  </button>
                </div>

                {/* Info Card */}
                <div className="bg-brand-surface border border-brand-border/60 rounded-xl p-3.5 space-y-1 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-16 h-16 bg-brand-accent/5 rounded-full blur-xl" />
                  <span className="text-[9px] uppercase font-black tracking-widest text-brand-accent font-mono flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5" /> LUXURY SKIN SWITCHER
                  </span>
                  <p className="text-[10px] text-zinc-400 leading-relaxed font-bold">
                    Adjusts contrast ratio, global highlights, graph gradients, status tags, and neon emission colors seamlessly.
                  </p>
                </div>

                {/* Beautiful custom list of themes */}
                <div className="space-y-3 pt-1" id="theme-selector-radio-group">
                  {PREMIUM_THEMES.map((item) => {
                    const isSelected = theme === item.id;
                    const isLocked = false;

                    return (
                      <button
                        key={item.id}
                        onClick={async () => {
                          if (isLocked) return;
                          setTheme(item.id);
                          if (updateProfileStats) {
                            await updateProfileStats({ theme: item.id });
                          }
                        }}
                        className={`w-full text-left p-3.5 rounded-2xl border transition-all duration-300 relative overflow-hidden flex flex-col gap-2.5 group ${
                          isLocked ? "cursor-not-allowed opacity-75 grayscale-[0.3]" : "cursor-pointer"
                        } ${
                          isSelected
                            ? "bg-brand-surface border-brand-accent shadow-[0_0_15px_rgba(201,243,29,0.05)]"
                            : "bg-[#111111]/45 border-brand-border hover:border-neutral-700 hover:bg-[#111111]"
                        }`}
                        id={`theme-opt-${item.id}`}
                      >
                        {/* Selected Indicator Checkmark */}
                        {isSelected && (
                          <div className="absolute top-3 right-3 bg-brand-accent text-brand-bg rounded-full p-0.5 shadow-[0_0_8px_var(--brand-accent-glow)]">
                            <Check className="w-3 h-3 stroke-[4]" />
                          </div>
                        )}
                        
                        {/* Locked Indicator */}
                        {isLocked && !isSelected && (
                          <div className="absolute top-3 right-3 text-neutral-600 bg-[#0C0C0C] rounded-full p-1 border border-neutral-800">
                            <Lock className="w-3.5 h-3.5" />
                          </div>
                        )}

                        <div className="flex items-center gap-2.5">
                          {/* Color Swatch Dot */}
                          <div className={`w-9 h-9 shrink-0 bg-[#060606] border border-neutral-850 rounded-xl flex items-center justify-center relative ${isLocked ? "opacity-50" : ""}`}>
                            <span className="text-lg relative z-10">{item.emoji}</span>
                            <div className={`absolute bottom-1 right-1 w-2.5 h-2.5 rounded-full border border-black ${item.bgClass}`} />
                          </div>

                          <div className="flex-1">
                            <span className={`block text-xs font-black uppercase tracking-wide transition-colors ${
                              isSelected ? "text-brand-accent" : (isLocked ? "text-neutral-500" : "text-white")
                            }`}>
                              {item.name}
                            </span>
                            <span className="block text-[8.5px] font-mono text-neutral-500 font-bold uppercase tracking-wider mt-0.5">
                              {isLocked ? "Pro Plan Required" : (isSelected ? "Active Preset" : "Alternative Engine")}
                            </span>
                          </div>
                        </div>

                        <p className={`text-[10px] ${isLocked ? "text-neutral-600" : "text-zinc-400"} font-medium leading-relaxed mt-0.5`}>
                          {item.desc}
                        </p>
                      </button>
                    );
                  })}
                </div>

                {/* Experience Options Section */}
                <div className="pt-4 border-t border-neutral-900 space-y-4">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-brand-accent animate-pulse" />
                    <div>
                      <h4 className="text-[10px] font-black uppercase text-white tracking-widest">Experience Options</h4>
                      <p className="text-[8px] text-brand-muted uppercase font-bold tracking-tight">Personalize workout visual cues</p>
                    </div>
                  </div>

                  <div className="bg-brand-surface border border-brand-border/60 rounded-xl p-3 flex items-center justify-between gap-3">
                    <div className="text-left space-y-0.5">
                      <span className="block text-[10px] font-black uppercase tracking-wide text-white">Animations</span>
                      <span className="block text-[8.5px] text-zinc-400 font-bold leading-tight uppercase">Confetti & star showers</span>
                    </div>

                    <button
                      onClick={() => {
                        playSound("toggle");
                        setAnimationsEnabled(!animationsEnabled);
                      }}
                      className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        animationsEnabled ? "bg-brand-accent" : "bg-neutral-850"
                      }`}
                      id="theme-toggle-celebratory-animations"
                      title="Toggle Celebratory Confetti & Star Shower Animations"
                    >
                      <span
                        className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-205 ease-in-out ${
                          animationsEnabled ? "translate-x-5 bg-black" : "translate-x-0"
                        }`}
                      />
                    </button>
                  </div>
                </div>

                {/* Active Device / App Environment Information */}
                <div className="pt-4 border-t border-neutral-900 space-y-4">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-brand-accent" />
                    <div>
                      <h4 className="text-[10px] font-black uppercase text-white tracking-widest">App Version</h4>
                      <p className="text-[8px] text-[#A0A0A0] uppercase font-bold tracking-tight">System edition and licensing status</p>
                    </div>
                  </div>

                  <div className="bg-[#0A1128] border border-[#14F1E1]/20 rounded-xl p-3 relative overflow-hidden">
                    <div className="text-left space-y-1">
                      <span className="block text-[10px] font-mono font-bold text-[#14F1E1] uppercase mt-1">Data Storage: Cloud + Local Cache</span>
                      <p className="text-[9px] text-zinc-400 font-medium leading-normal">
                        Your XP, Rank, Streak, and Athlete Profile sync with Firebase Cloud and cache locally for instant offline access.
                      </p>
                    </div>
                    <div className="text-left space-y-1 mt-3">
                      <span className="block text-[8.5px] font-mono font-bold text-zinc-500 uppercase">EDITION ID</span>
                      <span className="text-xs font-black text-[#14F1E1] uppercase flex items-center gap-1">
                        Fit Genie v2.0 • Pro Edition
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Drawer footer signature */}
              <div className="pt-4 border-t border-neutral-900 text-center space-y-1.5 select-none">
                <p className="text-[8px] font-mono font-black text-neutral-600 uppercase tracking-widest">
                  ★ FITGENIE PERFORMANCE SUITE ★
                </p>
                <div className="flex justify-center gap-1.5 text-neutral-750">
                  <span className="w-1 h-1 rounded-full bg-brand-accent" />
                  <span className="w-1 h-1 rounded-full bg-brand-accent/60" />
                  <span className="w-1 h-1 rounded-full bg-brand-accent/20" />
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Immersive Left Side Collapsible Sidebar Drawer */}
      <AnimatePresence>
        {showSidebar && (
          <>
            {/* Backdrop Blur overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSidebar(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[110] cursor-pointer"
              id="sidebar-drawer-backdrop"
            />
            
            {/* Sidebar Menu Cabinet */}
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 24, stiffness: 220 }}
              className="fixed top-0 left-0 bottom-0 h-full w-full max-w-[290px] bg-[#050B1A] border-r border-[#14F1E1]/20 z-[111] shadow-[5px_0_50px_rgba(0,0,0,0.95)] p-5 overflow-y-auto flex flex-col justify-between"
              id="sidebar-cabinet-drawer"
            >
              <div className="space-y-6">
                {/* Header Section */}
                <div className="flex items-center justify-between pb-3.5 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-[#14F1E1]" />
                    <div>
                      <h3 className="text-xs font-black uppercase tracking-widest text-white">FITGENIE MENU</h3>
                      <p className="text-[8px] text-[#14F1E1] uppercase font-black tracking-tight">Workouts & Trackers</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setShowSidebar(false)}
                    className="p-1 px-2.5 bg-[#0A1128] border border-white/10 hover:bg-[#14F1E1] hover:text-[#050B1A] rounded-lg text-[9px] font-black uppercase tracking-wider cursor-pointer transition-all active:scale-95"
                  >
                    Close
                  </button>
                </div>

                {/* Subtitle / User Quick Profile Header inside Sidebar */}
                <button
                  onClick={() => {
                    playSound("click");
                    setShowSidebar(false);
                    setTimeout(() => navigateToView("profile"), 200);
                  }}
                  className="w-full text-left bg-[#0A1128] border border-[#14F1E1]/25 hover:border-[#14F1E1]/60 rounded-xl p-3 flex items-center gap-2.5 relative overflow-hidden transition-all duration-150 cursor-pointer group"
                >
                  <div className="w-8 h-8 rounded-full bg-[#14F1E1]/15 group-hover:bg-[#14F1E1]/25 flex items-center justify-center text-xs font-black text-[#14F1E1] border border-[#14F1E1]/30 transition-all">
                    {profile?.username ? profile.username.slice(0, 2).toUpperCase() : "FG"}
                  </div>
                  <div className="text-left">
                    <span className="block text-[10px] font-black uppercase text-white line-clamp-2 break-words group-hover:text-[#14F1E1] transition-colors">
                      {profile?.username || "Fit Genie Athlete"}
                    </span>
                    <span className="block text-[8px] text-[#14F1E1] font-black uppercase tracking-widest">
                      Rank: {profile?.rank || profile?.level || "Beginner"} • {profile?.xp || 0} XP
                    </span>
                  </div>
                </button>

                {/* Scrollable list of links with beautifully spaced category sections */}
                <div className="space-y-4 text-left" id="sidebar-menu-sections">
                  {/* Category: Workouts & Coach */}
                  <div className="space-y-1.5">
                    <h4 className="text-[8.5px] font-black text-zinc-500 uppercase tracking-widest px-2.5">
                      Main Hub
                    </h4>
                    <div className="space-y-0.5">
                      {[
                        { id: "home", name: "Home Dashboard", icon: <Home className="w-3.5 h-3.5" /> },
                        { id: "exercises", name: "Exercises Library", icon: <BookOpen className="w-3.5 h-3.5" /> },
                        { id: "calisthenics", name: "Calisthenics Academy", icon: <Award className="w-3.5 h-3.5 text-[#14F1E1]" /> },
                        { id: "calisthenics_videos", name: "Calisthenics Videos", icon: <Video className="w-3.5 h-3.5" /> },
                        { id: "martial_arts", name: "Martial Arts Library", icon: <Swords className="w-3.5 h-3.5" /> },
                        { id: "height_increase", name: "Height Increase", icon: <TrendingUp className="w-3.5 h-3.5" /> },
                        { id: "mogged", name: "Mogged Station", icon: <MessageSquare className="w-3.5 h-3.5" /> },
                        { id: "guilds", name: "Guilds & Clan Wars", icon: <Crown className="w-3.5 h-3.5 text-amber-400" /> },
                      ].map((item) => {
                        const isActive = view === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => {
                              playSound("click");
                              setShowSidebar(false);
                              setTimeout(() => navigateToView(item.id as AppView), 200);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all duration-150 cursor-pointer ${
                              isActive
                                ? "bg-[#14F1E1] text-[#050B1A] font-black shadow-[0_0_12px_rgba(20,241,225,0.35)]"
                                : "text-zinc-400 hover:text-white hover:bg-white/5"
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              {item.icon}
                              <span>{item.name}</span>
                            </div>
                            {isActive && <div className="w-1.5 h-1.5 rounded-full bg-[#050B1A]" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Category: Fitness Trackers */}
                  <div className="space-y-1.5">
                    <h4 className="text-[8.5px] font-black text-zinc-500 uppercase tracking-widest px-2.5">
                      Daily Trackers
                    </h4>
                    <div className="space-y-0.5">
                      {[
                        { id: "diet", name: "Nutrition & Diet", icon: <Apple className="w-3.5 h-3.5" /> },
                        { id: "calorie_calc", name: "Calorie Calculator", icon: <Calculator className="w-3.5 h-3.5" /> },
                        { id: "plate_calc", name: "Plate Calculator", icon: <Dumbbell className="w-3.5 h-3.5" /> },
                      ].map((item) => {
                        const isActive = view === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => {
                              playSound("click");
                              setShowSidebar(false);
                              setTimeout(() => navigateToView(item.id as AppView), 200);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all duration-150 cursor-pointer ${
                              isActive
                                ? "bg-[#14F1E1] text-[#050B1A] font-black shadow-[0_0_12px_rgba(20,241,225,0.35)]"
                                : "text-zinc-400 hover:text-white hover:bg-white/5"
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              {item.icon}
                              <span>{item.name}</span>
                            </div>
                            {isActive && <div className="w-1.5 h-1.5 rounded-full bg-[#050B1A]" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Category: Stats & Utility */}
                  <div className="space-y-1.5">
                    <h4 className="text-[8.5px] font-black text-zinc-500 uppercase tracking-widest px-2.5">
                      Athlete Progress
                    </h4>
                    <div className="space-y-0.5">
                      {[
                        { id: "profile", name: "My Athlete Profile", icon: <User className="w-3.5 h-3.5" /> },
                        { id: "achievements", name: "Achievements & Emblems", icon: <Award className="w-3.5 h-3.5 text-[#14F1E1]" /> },
                        { id: "history", name: "Workout Logs & Stats", icon: <BookOpen className="w-3.5 h-3.5" /> },
                        { id: "goals", name: "Set Targets & Goals", icon: <Target className="w-3.5 h-3.5" /> },
                        { id: "notifications", name: "System Alerts", icon: <Bell className="w-3.5 h-3.5" /> },
                        { id: "support", name: "Support & Feedback", icon: <HelpCircle className="w-3.5 h-3.5" /> },
                      ].map((item) => {
                        const isActive = view === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => {
                              playSound("click");
                              setShowSidebar(false);
                              setTimeout(() => navigateToView(item.id as AppView), 200);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all duration-150 cursor-pointer ${
                              isActive
                                ? "bg-[#14F1E1] text-[#050B1A] font-black shadow-[0_0_12px_rgba(20,241,225,0.35)]"
                                : "text-zinc-400 hover:text-white hover:bg-white/5"
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              {item.icon}
                              <span>{item.name}</span>
                            </div>
                            {isActive && <div className="w-1.5 h-1.5 rounded-full bg-[#050B1A]" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Category: Information */}
                  <div className="space-y-1.5">
                    <h4 className="text-[8.5px] font-black text-zinc-500 uppercase tracking-widest px-2.5">
                      Information
                    </h4>
                    <div className="space-y-0.5">
                      {[
                        { id: "about", name: "About Us", icon: <Info className="w-3.5 h-3.5" /> },
                        { id: "privacy", name: "Privacy Policy", icon: <Shield className="w-3.5 h-3.5" /> },
                        { id: "contact", name: "Contact Us", icon: <Mail className="w-3.5 h-3.5" /> },
                        { id: "terms", name: "Terms of Service", icon: <FileText className="w-3.5 h-3.5" /> },
                      ].map((item) => {
                        const isActive = view === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => {
                              playSound("click");
                              setShowSidebar(false);
                              setTimeout(() => navigateToView(item.id as AppView), 200);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all duration-150 cursor-pointer ${
                              isActive
                                ? "bg-brand-accent text-brand-bg font-black font-sans shadow-[0_0_10px_var(--brand-accent-glow-subtle)]"
                                : "text-zinc-400 hover:text-white hover:bg-neutral-900/60"
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              {item.icon}
                              <span>{item.name}</span>
                            </div>
                            {isActive && <div className="w-1.5 h-1.5 rounded-full bg-brand-bg" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>

              {/* Sidebar bottom section (Logout) */}
              <div className="pt-4 border-t border-neutral-900 text-center space-y-3 shrink-0">
                <button
                  onClick={() => {
                    playSound("click");
                    setShowSidebar(false);
                    signOutUser();
                  }}
                  className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl border border-rose-950/20 bg-rose-950/10 hover:bg-rose-950/20 text-rose-400 text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer active:scale-95"
                >
                  <LogOut className="w-3.5 h-3.5 text-rose-500" />
                  <span>Logout Account</span>
                </button>

                <p className="text-[7.5px] font-mono font-black text-neutral-600 uppercase tracking-widest select-none">
                  💪 Crafted for Indian Athletes • Built in India 🇮🇳
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>


      {/* Fixed Sticky Bottom Navigation Bar */}
      <BottomNavigation
        currentView={view}
        onSetView={navigateToView}
        completedCount={history.length}
        streakCount={streakCount}
      />

      {/* Full Streak & Consistency Analytics Modal (12:00 AM - 11:59 PM Daily Gate) */}
      <StreakAnalyticsModal
        isOpen={showStreakModal}
        onClose={() => setShowStreakModal(false)}
        history={history}
        onLogDailyStreakSession={handleSaveSmartSession}
        onCelebrateMilestone={() => {
          window.dispatchEvent(new CustomEvent("trigger_streak_explosion"));
        }}
      />

      {/* Google Play Billing Payment Dialog Simulator */}
      <GooglePlayBillingSimulator />

      {/* Outer Floating background graphic decor - purely cosmetic premium subtle sci-fi shapes */}
      <div className="fixed bottom-10 right-10 w-96 h-96 bg-brand-accent/2 rounded-full blur-3xl pointer-events-none -z-50" />
      <div className="fixed top-20 left-10 w-80 h-80 bg-pink-500/1 rounded-full blur-3xl pointer-events-none -z-50" />
    </div>
  );
}
