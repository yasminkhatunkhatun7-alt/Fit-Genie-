export interface Exercise {
  id: number;
  name_en: string;
  name_hi: string;
  muscles: string[]; // e.g. ["chest", "triceps", "shoulders"]
  equipment: string[]; // e.g. ["none"] or ["dumbbells"]
  sets: number;
  reps: number;
    weight?: number;
  difficulty: "beginner" | "intermediate" | "advanced";
  instruction_en: string;
  instruction_hi: string;
  duration_minutes: number;
  gif_url?: string; // We can show a high quality illust/placeholder or simple line icon
}

export interface EquipmentItem {
  id: string; // e.g. "none", "dumbbells", "barbell", "bands", "pullup", "gym"
  name: string;
  emoji: string;
}

export type MuscleZone = {
  id: string; // "chest", "back", "shoulders", "biceps", "triceps", "core", "glutes", "legs", "calves"
  name: string;
  label: string;
};

export type StepState = 1 | 2 | 3;
export type AppView = 
  | "home" 
  | "dojo"
  | "achievements"
  | "chat"
  | "exercises" 
  | "calisthenics"
  | "calisthenics_videos" 
  | "about" 
  | "history" 
  | "mogged" 
 
  | "exercise_videos"
  | "diet"
  | "calorie_calc"
  | "plate_calc"
  | "water"
  | "steps"
  | "goals"
  | "notifications"
  | "support"
  | "settings"
  | "privacy"
  | "contact"
  | "terms"
  | "martial_arts"
  | "height_increase"
  | "guilds"
  | "developer"
  | "recovery"
  | "profile";

export interface ChatMessage {
  id: string;
  sender: "user" | "bro";
  text: string;
  timestamp: string;
  image?: string;
}

export interface CompletedSession {
  id: string;
  date: string; // ISO date string
  muscles: string[];
  equipment: string[];
  exercisesCount: number;
  totalDurationMin: number;
  exercises: {
    id: number;
    name_en: string;
    name_hi: string;
    sets: number;
    reps: number;
    weight?: number;
    difficulty: "beginner" | "intermediate" | "advanced";
  }[];
  rating?: number; // scale of 1-5 stars if selected
  notes?: string;   // optional notes
  // Smart Workout Validation System Fields
  isSmartValidation?: boolean;
  targetReps?: number;
  completedReps?: number;
  progressPercentage?: number;
  unverified?: boolean;
  workoutTimeSec?: number;
}

export type GenieStage = 1 | 2 | 3;

export interface GenieEvolutionInfo {
  stage: GenieStage;
  name: string;
  title: string;
  minStreak: number;
  minTrust: number;
  description: string;
  glowColor: string;
  badge: string;
}

export type MysteryRarity = "legendary" | "epic" | "rare" | "cursed";

export interface MysteryCardReward {
  rarity: MysteryRarity;
  title: string;
  subtitle: string;
  description: string;
  icon: string;
  badge: string;
  skinUnlocked?: string;
  xpBonus?: number;
  doubleXpHours?: number;
  streakShieldsAdded?: number;
  cursePenaltyXp?: number;
  curseTimeLimitMin?: number;
  curseTargetReps?: number;
}

export interface CursedChallenge {
  id: string;
  title: string;
  targetReps: number;
  timeLimitSecs: number;
  startedAt: number;
  expiresAt: number;
  penaltyXp: number;
  completed?: boolean;
}

export interface GuildMember {
  uid: string;
  username: string;
  photoURL?: string;
  avatarBg?: string;
  rank?: string;
  weeklyXP?: number;
  totalXP?: number;
  isLeader?: boolean;
}

export interface Guild {
  guildId: string;
  name: string;
  tag?: string;
  motto?: string;
  bannerColor?: string;
  guildLeader: string; // leader UID
  leaderName?: string;
  members: string[]; // array of UIDs (max 10)
  memberDetails?: GuildMember[];
  totalWeeklyXP: number;
  createdAt?: string;
  rankPosition?: number;
}

export type { UserProfile } from './context/AuthContext';
