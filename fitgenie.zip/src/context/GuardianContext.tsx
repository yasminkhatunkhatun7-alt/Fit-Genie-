import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  useCallback,
  ReactNode,
} from "react";
import { playSound } from "../utils/audio";

export type GuardianEmotion =
  | "idle"
  | "sleepy"
  | "happy"
  | "focused"
  | "thinking"
  | "suspicious"
  | "angry"
  | "celebrating"
  | "sick";

export interface GuardianContextType {
  emotion: GuardianEmotion;
  setEmotion: (e: GuardianEmotion) => void;
  message: string;
  setMessage: (m: string, durationMs?: number) => void;
  isPanelOpen: boolean;
  setIsPanelOpen: (o: boolean) => void;
  activeWarning: boolean;
  setActiveWarning: (w: boolean) => void;
  observations: string[];
  addObservation: (obs: string) => void;
  triggerEvent: (type: string, data?: any) => void;
  triggerWarning: (msg: string) => void;
  reportSuspiciousActivity: (
    reason: string,
    severity?: "warning" | "critical"
  ) => void;
  suspiciousStrikeCount: number;
  evaluateRealism: (
    exerciseName: string,
    completedReps: number,
    elapsedTimeSecs: number
  ) => number;
}

const GuardianContext = createContext<GuardianContextType | null>(null);

export const GuardianProvider = ({ children }: { children: ReactNode }) => {
  const [emotion, setEmotion] = useState<GuardianEmotion>("focused");
  // Silent by default so user is never spammed with constant bubbles
  const [message, setMessageState] = useState("");
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [activeWarning, setActiveWarning] = useState(false);
  const [observations, setObservations] = useState<string[]>([]);
  const [suspiciousStrikeCount, setSuspiciousStrikeCount] = useState(0);

  const msgTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const emotionResetRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastSuspiciousWarningRef = useRef<number>(0);
  const strikeCountRef = useRef<number>(0);

  const setMessage = useCallback((m: string, durationMs: number = 4500) => {
    if (msgTimerRef.current) {
      clearTimeout(msgTimerRef.current);
      msgTimerRef.current = null;
    }
    setMessageState(m);
    if (m && durationMs > 0) {
      msgTimerRef.current = setTimeout(() => {
        setMessageState("");
      }, durationMs);
    }
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem("fitgenie_guardian_observations");
    if (saved) {
      try {
        setObservations(JSON.parse(saved));
      } catch (e) {}
    }
  }, []);

  const addObservation = useCallback((obs: string) => {
    const timeStr = new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
    const formatted = obs.startsWith("[") ? obs : `[${timeStr}] ${obs}`;
    setObservations((prev) => {
      if (prev[0] === formatted) return prev;
      const newObs = [formatted, ...prev].slice(0, 30);
      try {
        localStorage.setItem(
          "fitgenie_guardian_observations",
          JSON.stringify(newObs)
        );
      } catch {}
      return newObs;
    });
  }, []);

  useEffect(() => {
    const handleTrustIncrease = (e: Event) => {
      const customEvent = e as CustomEvent;
      const gain = customEvent.detail?.gain || 0;
      if (gain >= 15) {
        setEmotion("celebrating");
        setMessage("Trust score badh raha hai bro! 🔥", 3000);
      } else if (gain > 0) {
        setEmotion("happy");
      }
    };
    window.addEventListener("trust_increase", handleTrustIncrease);
    return () =>
      window.removeEventListener("trust_increase", handleTrustIncrease);
  }, [setMessage]);

  const triggerWarning = useCallback(
    (msg: string) => {
      setEmotion("angry");
      setMessage(msg, 6500);
      setActiveWarning(true);
      playSound("error");
      addObservation(`🚨 Critical Lock: ${msg}`);
    },
    [addObservation, setMessage]
  );

  const reportSuspiciousActivity = useCallback(
    (reason: string, severity: "warning" | "critical" = "warning") => {
      const now = Date.now();
      addObservation(`⚠️ Cheat Radar: ${reason}`);
      playSound("error");

      if (emotionResetRef.current) {
        clearTimeout(emotionResetRef.current);
      }

      const next = strikeCountRef.current + 1;
      strikeCountRef.current = next;
      setSuspiciousStrikeCount(next);

      if (severity === "critical" || next >= 2) {
        setEmotion("angry");
        setMessage(`🚨 ${reason}`, 6000);
      } else {
        setEmotion("suspicious");
        setMessage(`⚠️ ${reason}`, 5000);
      }

      // If user repeatedly cheats (3+ strikes or 2nd critical strike), trigger Orb Full-Screen Lock Modal
      if (next >= 3 || (severity === "critical" && next >= 2)) {
        setActiveWarning(true);
      }

      // Notify GenieTracker / AuthContext asynchronously so it never updates another provider mid-render
      setTimeout(() => {
        try {
          window.dispatchEvent(
            new CustomEvent("guardian_cheat_penalty", {
              detail: {
                reason,
                severity,
                strikes: next,
              },
            })
          );
        } catch {}
      }, 0);

      lastSuspiciousWarningRef.current = now;

      emotionResetRef.current = setTimeout(() => {
        setEmotion("focused");
      }, 6500);
    },
    [addObservation, setMessage]
  );

  const REP_CONSTRAINTS: Record<string, number> = {
    burpee: 1.4,
    pullup: 1.3,
    "pull-up": 1.3,
    "pull up": 1.3,
    chinup: 1.2,
    "muscle up": 2.0,
    squat: 0.85,
    baithak: 0.85,
    lunge: 1.0,
    pushup: 0.75,
    "push-up": 0.75,
    "push up": 0.75,
    dand: 0.9,
    dip: 0.8,
    crunch: 0.65,
    situp: 0.75,
    plank: 0.85,
    hold: 0.85,
    hang: 0.85,
    default: 0.75,
  };

  const evaluateRealism = useCallback(
    (
      exerciseName: string,
      completedReps: number,
      elapsedTimeSecs: number
    ): number => {
      if (completedReps <= 0) return 100;

      const lower = exerciseName.toLowerCase();
      const key =
        Object.keys(REP_CONSTRAINTS).find((k) => lower.includes(k)) ||
        "default";
      const minTimePerRep = REP_CONSTRAINTS[key];
      const theoreticalMinTime = completedReps * minTimePerRep;

      let score = 100;

      if (elapsedTimeSecs < theoreticalMinTime) {
        if (elapsedTimeSecs <= 0) {
          score = 0;
        } else {
          const ratio = elapsedTimeSecs / theoreticalMinTime;
          score = Math.max(0, Math.floor(ratio * 100));
        }
      }

      if (score < 45 && completedReps >= 5) {
        reportSuspiciousActivity(
          `${completedReps} ${exerciseName} sirf ${Math.round(
            elapsedTimeSecs
          )}s me? Orb ne speed cheat pakad liya bro! 🛑`,
          score < 25 || completedReps >= 20 ? "critical" : "warning"
        );
      } else if (score < 70 && completedReps >= 8) {
        setEmotion("suspicious");
        addObservation(
          `Unusually fast pace on ${exerciseName} (${score}% realism score)`
        );
      }

      return score;
    },
    [addObservation, reportSuspiciousActivity]
  );

  const triggerEvent = useCallback(
    (type: string, data?: any) => {
      switch (type) {
        case "challenge_complete":
          setEmotion("celebrating");
          setMessage("Mission Complete! 🔥", 3500);
          addObservation("Challenge completed.");
          setTimeout(() => {
            setEmotion("focused");
          }, 4000);
          break;
        case "boss_fight":
          setEmotion("focused");
          addObservation("Boss battle attack logged.");
          break;
        case "level_up":
          setEmotion("celebrating");
          setMessage("Level Up! Warrior stronger ho gaya 🔥", 4000);
          addObservation("Warrior leveled up.");
          break;
        case "suspicious":
          reportSuspiciousActivity(
            data?.message || "Unusual speed ya activity detect hui hai bro 👀",
            "warning"
          );
          break;
        case "cheating":
        case "angry":
          reportSuspiciousActivity(
            data?.message ||
              "Suspicious pattern! Numbers badhane se body nahi banegi bro ⚠️",
            "critical"
          );
          break;
        case "streak_7":
          setEmotion("happy");
          setMessage("7-Day Streak! Momentum solid hai 🔥", 3500);
          addObservation("7-day streak achieved.");
          break;
        case "streak_30":
          setEmotion("celebrating");
          setMessage("30-Day Streak! Beast discipline 👑", 4000);
          addObservation("30-day streak achieved.");
          break;
        case "streak_90":
          setEmotion("celebrating");
          setMessage("90-Day Legendary Consistency! 🏆", 4000);
          addObservation("90-day streak achieved.");
          break;
        case "focused":
        case "challenge_active":
        case "motivation":
        case "home_greet":
        case "happy":
        case "thinking":
        case "nav_home":
        case "nav_challenge":
        case "nav_workout":
        case "nav_profile":
          setEmotion(
            type === "happy"
              ? "happy"
              : type === "thinking"
              ? "thinking"
              : "focused"
          );
          if (data?.log) {
            addObservation(data.log);
          }
          break;
        case "inactive_1":
        case "inactive_3":
        case "inactive_7":
        case "inactive":
        case "sleepy":
          setEmotion("sleepy");
          break;
        default:
          setEmotion("focused");
          break;
      }
    },
    [addObservation, reportSuspiciousActivity, setMessage]
  );

  return (
    <GuardianContext.Provider
      value={{
        emotion,
        setEmotion,
        message,
        setMessage,
        isPanelOpen,
        setIsPanelOpen,
        activeWarning,
        setActiveWarning,
        observations,
        addObservation,
        triggerEvent,
        triggerWarning,
        reportSuspiciousActivity,
        suspiciousStrikeCount,
        evaluateRealism,
      }}
    >
      {children}
    </GuardianContext.Provider>
  );
};

export const useGuardianContext = () => {
  const ctx = useContext(GuardianContext);
  if (!ctx)
    throw new Error("useGuardianContext must be used within GuardianProvider");
  return ctx;
};
