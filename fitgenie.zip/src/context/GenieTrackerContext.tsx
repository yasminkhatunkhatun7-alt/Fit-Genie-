import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useRef,
  useCallback,
} from "react";
import { AnimatePresence, motion } from "motion/react";
import { AlertTriangle, ShieldAlert } from "lucide-react";
import { useAuth } from "./AuthContext";
import { useGuardianContext } from "./GuardianContext";

export type EventType =
  | "NAVIGATE"
  | "START_EXERCISE"
  | "COMPLETE_EXERCISE"
  | "VIEW_SECTION"
  | "CHALLENGE_COMPLETE"
  | "USER_ACTION"
  | "SUSPICIOUS_ACTIVITY";

export interface TrackerEvent {
  id: string;
  type: EventType;
  payload: any;
  timestamp: number;
}

export interface GenieContextType {
  logEvent: (type: EventType, payload: any) => void;
  startExercise: (exerciseId: string, name: string) => void;
  completeExercise: (
    exerciseId: string,
    name: string,
    repsOrDuration: number
  ) => void;
  history: TrackerEvent[];
  currentScreen: string;
  totalActionsCount: number;
  suspiciousFlagsCount: number;
  lastActionLabel: string;
}

const GenieTrackerContext = createContext<GenieContextType | undefined>(
  undefined
);

export const useGenieTracker = () => {
  const context = useContext(GenieTrackerContext);
  if (!context) {
    throw new Error(
      "useGenieTracker must be used within a GenieTrackerProvider"
    );
  }
  return context;
};

const VIEW_LABELS: Record<string, string> = {
  home: "Home Dashboard",
  dojo: "Challenges & Dojo",
  exercises: "Workouts Library",
  calisthenics: "Calisthenics Arena",
  calisthenics_videos: "Calisthenics Videos",
  mogged: "Glow-Up & Mogged Hub",
  achievements: "Achievements & Ranks",
  chat: "World & Bro Chat",
  history: "Workout History",
  about: "About App",
  exercise_videos: "Exercise Video Vault",
  diet: "Nutrition & Diet Log",
  calorie_calc: "Calorie Calculator",
  plate_calc: "Barbell Plate Calculator",
  water: "Hydration Tracker",
  steps: "Step Counter",
  goals: "Fitness Goals",
  notifications: "Notifications",
  support: "Support & Feedback",
  privacy: "Privacy Policy",
  martial_arts: "Combat & Martial Arts",
  height_increase: "Posture & Height Lab",
  guilds: "Warrior Guilds",
  profile: "Warrior Profile",
  settings: "App Settings",
};

export const GenieTrackerProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const { profile, updateUserProfileFields, updateProfileStats } = useAuth();
  const { addObservation, reportSuspiciousActivity, evaluateRealism } =
    useGuardianContext();

  const [history, setHistory] = useState<TrackerEvent[]>(() => {
    try {
      const saved = localStorage.getItem("fitgenie_user_telemetry");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [currentScreen, setCurrentScreen] = useState<string>("Home Dashboard");
  const [totalActionsCount, setTotalActionsCount] = useState<number>(0);
  const [suspiciousFlagsCount, setSuspiciousFlagsCount] = useState<number>(0);
  const [lastActionLabel, setLastActionLabel] = useState<string>(
    "Monitoring app session..."
  );

  // Warning banner state (shown whenever Orb catches suspicious/cheat activity)
  const [genieWarningBanner, setGenieWarningBanner] = useState<{
    text: string;
    severity: "warning" | "critical";
  } | null>(null);

  const activeExercises = useRef<Record<string, number>>({});
  const clickTimestampsRef = useRef<{ time: number; label: string }[]>([]);
  const navTimestampsRef = useRef<number[]>([]);
  const repTapTimestampsRef = useRef<{ time: number; amount: number }[]>([]);
  const warningTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastWarnTimeRef = useRef<number>(0);

  useEffect(() => {
    try {
      localStorage.setItem(
        "fitgenie_user_telemetry",
        JSON.stringify(history.slice(-100))
      );
    } catch {}
  }, [history]);

  const showTopRadarBanner = useCallback(
    (reason: string, severity: "warning" | "critical" = "warning") => {
      const now = Date.now();
      if (now - lastWarnTimeRef.current < 1800 && severity !== "critical") {
        return;
      }
      lastWarnTimeRef.current = now;

      if (warningTimeoutRef.current) clearTimeout(warningTimeoutRef.current);
      setGenieWarningBanner({ text: reason, severity });
      warningTimeoutRef.current = setTimeout(() => {
        setGenieWarningBanner(null);
      }, 5200);
    },
    []
  );

  // Listen to GuardianContext's "guardian_cheat_penalty" event so every Orb cheat trigger shows the HUD banner & penalizes Trust Score
  useEffect(() => {
    const handleCheatPenalty = (e: Event) => {
      const customEvent = e as CustomEvent;
      const reason =
        customEvent.detail?.reason || "Suspicious workout speed detected!";
      const severity: "warning" | "critical" =
        customEvent.detail?.severity || "warning";

      setSuspiciousFlagsCount((c) => c + 1);
      setLastActionLabel(`🚨 ${reason}`);
      showTopRadarBanner(reason, severity);

      updateProfileStats?.({
        integrityScoreChange: severity === "critical" ? -10 : -5,
      });
    };

    window.addEventListener("guardian_cheat_penalty", handleCheatPenalty);
    return () =>
      window.removeEventListener("guardian_cheat_penalty", handleCheatPenalty);
  }, [showTopRadarBanner, updateProfileStats]);

  const triggerSuspiciousAlert = useCallback(
    (reason: string, severity: "warning" | "critical" = "warning") => {
      reportSuspiciousActivity(reason, severity);
    },
    [reportSuspiciousActivity]
  );

  const logEvent = useCallback(
    (type: EventType, payload: any) => {
      const now = Date.now();
      const newEvent: TrackerEvent = {
        id: Math.random().toString(36).slice(2, 10),
        type,
        payload,
        timestamp: now,
      };
      setHistory((prev) => [...prev.slice(-99), newEvent]);
      setTotalActionsCount((c) => c + 1);

      if (type === "NAVIGATE") {
        const readableView =
          VIEW_LABELS[payload?.view] || payload?.view || "App Screen";
        setCurrentScreen(readableView);
        setLastActionLabel(`Opened ${readableView}`);
        addObservation(`Switched screen → ${readableView}`);

        // Detect unusual rapid screen jumping (6+ tab switches in 2.5 seconds)
        navTimestampsRef.current = [
          ...navTimestampsRef.current.filter((t) => now - t < 2500),
          now,
        ];
        if (navTimestampsRef.current.length >= 6) {
          navTimestampsRef.current = [];
          triggerSuspiciousAlert(
            "Itni tezi se tabs kyu switch kar rahe ho bro? Focus ek mission pe rakho 👀",
            "warning"
          );
        }
      } else if (type === "VIEW_SECTION") {
        const sec = payload?.section || "Section";
        setLastActionLabel(`Viewing ${sec}`);
        addObservation(`Opened section: ${sec}`);
      } else if (type === "START_EXERCISE") {
        const exName = payload?.name || "Exercise";
        setLastActionLabel(`Started ${exName}`);
        addObservation(`Started exercise: ${exName}`);
      } else if (type === "CHALLENGE_COMPLETE") {
        const chName = payload?.title || payload?.id || "Challenge";
        setLastActionLabel(`Completed ${chName}`);
        addObservation(`Completed challenge: ${chName}`);
      } else if (type === "SUSPICIOUS_ACTIVITY") {
        const reason = payload?.reason || "Unusual app behavior detected";
        setLastActionLabel(`⚠️ ${reason}`);
        triggerSuspiciousAlert(reason, payload?.severity || "warning");
      }
    },
    [addObservation, triggerSuspiciousAlert]
  );

  // Global Full-App Awareness Listener: Observes clicks, rep buttons, and unusual inputs across the entire app
  useEffect(() => {
    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;

      const interactiveEl = target.closest(
        "button, a, [role='button']"
      ) as HTMLElement | null;
      if (!interactiveEl) return;

      // Ignore clicks on the GuardianOrb itself so opening/closing Genie isn't flagged
      if (interactiveEl.closest("[data-genie-orb='true']")) return;

      const rawText = (
        interactiveEl.getAttribute("aria-label") ||
        interactiveEl.innerText ||
        interactiveEl.getAttribute("title") ||
        ""
      )
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 42);

      const label = rawText || "UI Control";
      const now = Date.now();

      setTotalActionsCount((c) => c + 1);
      if (rawText) {
        setLastActionLabel(`Tapped "${label}" on ${currentScreen}`);
      }

      // Check for rep logging or instant-XP buttons (+1, +5, +10, +15, +25, Max, +45 XP Done)
      const repMatch = rawText.match(/^\+(\d+)$/i);
      const isMaxBtn = /^max$/i.test(rawText);
      const isXpDoneBtn =
        /^\+\d+\s*xp\s*done$/i.test(rawText) ||
        /^complete\s*lesson/i.test(rawText);

      if (repMatch || isMaxBtn || isXpDoneBtn) {
        const repAdded = repMatch ? parseInt(repMatch[1], 10) : isMaxBtn ? 25 : 15;
        repTapTimestampsRef.current = [
          ...repTapTimestampsRef.current.filter((item) => now - item.time < 3200),
          { time: now, amount: repAdded },
        ];

        const recentTaps = repTapTimestampsRef.current;
        const totalRecentReps = recentTaps.reduce((s, r) => s + r.amount, 0);

        // If user spams rep/completion buttons 3+ times in 2.4s OR logs >= 25 reps in 3.2s via rapid clicking
        const tapsIn2_4s = recentTaps.filter((item) => now - item.time < 2400);
        if (
          tapsIn2_4s.length >= 3 ||
          (recentTaps.length >= 2 && totalRecentReps >= 25)
        ) {
          repTapTimestampsRef.current = [];
          triggerSuspiciousAlert(
            `3 second me ${totalRecentReps}+ reps button spam (${currentScreen})? Orb ne cheat pakad liya bro! 🛑`,
            "critical"
          );
          return;
        }
      }

      // Check for general rapid button spamming / rage clicking (5+ clicks on same button in 2.0s)
      clickTimestampsRef.current = [
        ...clickTimestampsRef.current.filter((item) => now - item.time < 2000),
        { time: now, label },
      ];
      const sameBtnClicks = clickTimestampsRef.current.filter(
        (item) => item.label === label
      );

      if (sameBtnClicks.length >= 5) {
        clickTimestampsRef.current = [];
        triggerSuspiciousAlert(
          `"${label}" button lagataar spam ho raha hai (${currentScreen})! Unusual activity detected 👀`,
          "warning"
        );
      } else if (rawText && Math.random() < 0.35) {
        addObservation(`Action on ${currentScreen}: "${label}"`);
      }
    };

    const handleGlobalInputChange = (e: Event) => {
      const target = e.target as HTMLInputElement | null;
      if (!target || target.tagName !== "INPUT") return;

      if (target.type === "number") {
        const val = parseFloat(target.value);
        if (isNaN(val)) return;
        const placeholder = (
          target.placeholder ||
          target.name ||
          target.getAttribute("aria-label") ||
          ""
        ).toLowerCase();

        // Check for unrealistic numeric entries
        if (val < 0) {
          triggerSuspiciousAlert(
            "Negative number input? Sahi data enter karo bro ⚠️",
            "warning"
          );
        } else if (
          (placeholder.includes("weight") || placeholder.includes("kg")) &&
          val > 260
        ) {
          triggerSuspiciousAlert(
            `${val} kg weight? Ye value unusual lag rahi hai bro 👀`,
            "warning"
          );
        } else if (
          (placeholder.includes("rep") || placeholder.includes("target")) &&
          val > 350
        ) {
          triggerSuspiciousAlert(
            `Ek set me ${val} reps? Realistic target rakho warrior ⚠️`,
            "warning"
          );
        } else if (placeholder.includes("cal") && val > 12000) {
          triggerSuspiciousAlert(
            `${val} kcal? Ye calorie number unusual hai bro 👀`,
            "warning"
          );
        }
      }
    };

    window.addEventListener("click", handleGlobalClick, { passive: true });
    window.addEventListener("change", handleGlobalInputChange, {
      passive: true,
    });
    return () => {
      window.removeEventListener("click", handleGlobalClick);
      window.removeEventListener("change", handleGlobalInputChange);
    };
  }, [currentScreen, addObservation, triggerSuspiciousAlert]);

  const inferMuscleFromName = (name: string): string | null => {
    const n = name.toLowerCase();
    if (
      n.includes("push") ||
      n.includes("bench") ||
      n.includes("chest") ||
      n.includes("dand") ||
      n.includes("fly")
    )
      return "chest";
    if (
      n.includes("squat") ||
      n.includes("lunge") ||
      n.includes("leg") ||
      n.includes("baithak")
    )
      return "legs";
    if (
      n.includes("pull") ||
      n.includes("row") ||
      n.includes("chin") ||
      n.includes("lat") ||
      n.includes("back")
    )
      return "back";
    if (
      n.includes("shoulder") ||
      n.includes("overhead") ||
      n.includes("pike") ||
      n.includes("handstand") ||
      n.includes("shrug")
    )
      return "shoulders";
    if (n.includes("curl") || n.includes("bicep")) return "biceps";
    if (n.includes("tricep") || n.includes("dip") || n.includes("pushdown"))
      return "triceps";
    if (
      n.includes("plank") ||
      n.includes("crunch") ||
      n.includes("core") ||
      n.includes("ab") ||
      n.includes("sit")
    )
      return "core";
    return null;
  };

  const startExercise = useCallback(
    (exerciseId: string, name: string) => {
      activeExercises.current[exerciseId] = Date.now();
      logEvent("START_EXERCISE", { exerciseId, name });

      // Smart Overtraining & Muscle Soreness Check (3D Anatomy Link)
      try {
        const targetMuscle = inferMuscleFromName(name);
        if (targetMuscle) {
          const savedMap = localStorage.getItem("fitgenie_muscle_last_trained");
          if (savedMap) {
            const parsed = JSON.parse(savedMap) as Record<string, number>;
            const lastTrainedTs = parsed[targetMuscle];
            if (lastTrainedTs) {
              const hoursSince = (Date.now() - lastTrainedTs) / (1000 * 60 * 60);
              const recoveryPct = Math.min(
                100,
                Math.round((hoursSince / 40) * 100)
              );
              if (recoveryPct < 45) {
                const allMuscles = [
                  "chest",
                  "back",
                  "legs",
                  "shoulders",
                  "core",
                  "biceps",
                ];
                const freshMuscle =
                  allMuscles.find((m) => {
                    const ts = parsed[m];
                    if (!ts) return true;
                    return (Date.now() - ts) / (1000 * 60 * 60) >= 32;
                  }) || "Core";
                triggerSuspiciousAlert(
                  `Overtraining Alert! Bro tera ${targetMuscle.toUpperCase()} abhi sirf ${recoveryPct}% recovered hai (Fatigued). Aaj ${freshMuscle.toUpperCase()} train kar ya light rakh! 🛡️`,
                  "warning"
                );
              }
            }
          }
        }
      } catch {}
    },
    [logEvent, triggerSuspiciousAlert]
  );

  const completeExercise = useCallback(
    (exerciseId: string, name: string, repsOrDuration: number) => {
      const startTime = activeExercises.current[exerciseId];
      const endTime = Date.now();

      let timeTaken = 0;
      if (startTime) {
        timeTaken = (endTime - startTime) / 1000;
        delete activeExercises.current[exerciseId];
      }

      logEvent("COMPLETE_EXERCISE", {
        exerciseId,
        name,
        timeTaken,
        repsOrDuration,
      });
      addObservation(
        `Completed ${name} (${repsOrDuration} reps/sec${
          timeTaken > 0 ? ` in ${timeTaken.toFixed(1)}s` : ""
        })`
      );

      // Update 3D Muscle Recovery Map telemetry
      try {
        const targetMuscle = inferMuscleFromName(name);
        if (targetMuscle) {
          const savedMap = localStorage.getItem("fitgenie_muscle_last_trained");
          const parsed = savedMap ? JSON.parse(savedMap) : {};
          parsed[targetMuscle] = endTime;
          localStorage.setItem(
            "fitgenie_muscle_last_trained",
            JSON.stringify(parsed)
          );
        }
      } catch {}

      if (timeTaken > 0 && profile) {
        const currentMetrics = profile.performance_metrics || [];
        const newMetric = {
          exerciseId,
          durationSecs: timeTaken,
          timestamp: endTime,
        };
        updateUserProfileFields({
          performance_metrics: [...currentMetrics.slice(-49), newMetric],
        }).catch(() => {});
      }

      // Biomechanical Realism Evaluation via GuardianContext
      if (timeTaken > 0 && repsOrDuration >= 5) {
        evaluateRealism(name, repsOrDuration, timeTaken);
      }
    },
    [
      logEvent,
      addObservation,
      profile,
      updateUserProfileFields,
      evaluateRealism,
    ]
  );

  return (
    <GenieTrackerContext.Provider
      value={{
        logEvent,
        startExercise,
        completeExercise,
        history,
        currentScreen,
        totalActionsCount,
        suspiciousFlagsCount,
        lastActionLabel,
      }}
    >
      {children}

      {/* Top Suspicious Activity Warning Banner (appears whenever Orb catches a cheat across any screen) */}
      <AnimatePresence>
        {genieWarningBanner && (
          <motion.div
            initial={{ opacity: 0, y: -40, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -25, scale: 0.92 }}
            className="fixed top-20 left-4 right-4 md:left-auto md:right-6 md:w-96 z-[9999] pointer-events-none"
          >
            <div
              className={`rounded-2xl p-3.5 border flex items-start gap-3.5 shadow-2xl backdrop-blur-xl ${
                genieWarningBanner.severity === "critical"
                  ? "border-red-500/60 bg-red-950/90 shadow-[0_0_30px_rgba(239,68,68,0.4)]"
                  : "border-amber-500/60 bg-amber-950/90 shadow-[0_0_25px_rgba(245,158,11,0.35)]"
              }`}
            >
              <div
                className={`w-9 h-9 shrink-0 rounded-xl flex items-center justify-center border ${
                  genieWarningBanner.severity === "critical"
                    ? "bg-red-500/20 border-red-500/50 text-red-400"
                    : "bg-amber-500/20 border-amber-500/50 text-amber-400"
                }`}
              >
                {genieWarningBanner.severity === "critical" ? (
                  <ShieldAlert className="w-5 h-5 animate-pulse" />
                ) : (
                  <AlertTriangle className="w-5 h-5" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-white font-black uppercase text-[11px] tracking-wider flex items-center gap-1.5">
                  ORB GENIE SECURITY RADAR
                </h4>
                <p className="text-xs text-neutral-100 mt-0.5 font-semibold leading-snug">
                  {genieWarningBanner.text}
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </GenieTrackerContext.Provider>
  );
};
