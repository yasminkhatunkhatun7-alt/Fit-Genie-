import { createContext, useContext, useState, useEffect, useCallback, useRef, ReactNode } from "react";
import { db } from "../lib/firebase";
import { doc, setDoc, getDoc } from "firebase/firestore";
import { auth } from "../lib/firebase";
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, User, browserPopupRedirectResolver } from "firebase/auth";
import { 
  getCachedProfile, 
  setCachedProfile, 
  getLastSyncedAt, 
  enqueueOfflineAction, 
  flushOfflineQueue,
  CACHE_KEYS 
} from "../hooks/useCachedProfile";

// Date time-frame helpers for Weekly/Monthly tracking
function getISOWeekString(date: Date): string {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

function getISOMonthString(date: Date): string {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

// YYYY-MM-DD local format helper
function getLocalDateString(d: Date): string {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

// Computes the number of calendar days of difference between two local dates YYYY-MM-DD
function getDaysBetween(dateStr1: string, dateStr2: string): number {
  if (!dateStr1 || !dateStr2 || dateStr1 === "" || dateStr2 === "") return 999;
  try {
    const d1 = new Date(dateStr1 + "T12:00:00");
    const d2 = new Date(dateStr2 + "T12:00:00");
    const diffTime = Math.abs(d2.getTime() - d1.getTime());
    return Math.round(diffTime / (1000 * 60 * 60 * 24));
  } catch (err) {
    console.error("Error parsing date strings in getDaysBetween:", err);
    return 999;
  }
}

export function getIntegrityData(score: number) {
  if (score >= 90) return { status: "Athlete 🏆", mood: "Proud", message: "Perfect discipline Boss." };
  if (score >= 80) return { status: "Something Feels Off 🤨", mood: "Watching", message: "Boss, kuch to gadbad lag rahi hai. Stay honest." };
  if (score >= 70) return { status: "Under Observation 👀", mood: "Suspicious", message: "Genie is monitoring your progress. Trust is unstable." };
  if (score >= 60) return { status: "Questionable Activity ⚠️", mood: "Concerned", message: "Boss, your behavior is becoming suspicious. Trust needs improvement." };
  if (score >= 50) return { status: "Red Flag User 🚩", mood: "Disappointed", message: "Too many unusual actions detected." };
  if (score >= 40) return { status: "Cheat Suspect 🚨", mood: "Annoyed", message: "Genie is losing confidence." };
  if (score >= 30) return { status: "Cheat Monster 👹", mood: "Angry", message: "Boss, this is getting serious." };
  if (score >= 20) return { status: "Fitness Criminal 😤", mood: "Very Angry", message: "Trust is critically damaged." };
  if (score >= 10) return { status: "Public Enemy 😈", mood: "Furious", message: "Genie no longer believes workout claims." };
  if (score >= 1) return { status: "Disowned By Genie 💔", mood: "Maximum Anger", message: "Boss... what happened to you?" };
  return { status: "Banned By Genie 💀", mood: "Nuclear", message: "Genie has completely lost trust." };
}

export const GENIE_STAGES = {
  1: {
    stage: 1 as const,
    name: "Baby Genie",
    title: "Sprout Guardian",
    minStreak: 0,
    minTrust: 0,
    description: "Curious and eager to grow. Complete consistent workouts to help it evolve!",
    glowColor: "#14F1E1",
    badge: "🌱 Baby"
  },
  2: {
    stage: 2 as const,
    name: "Warrior Genie",
    title: "Sentinel Guardian",
    minStreak: 7,
    minTrust: 80,
    description: "Battle-forged through discipline. Possesses dual energy rings and fiery ember core.",
    glowColor: "#4DA8FF",
    badge: "⚔️ Warrior"
  },
  3: {
    stage: 3 as const,
    name: "Legend Genie",
    title: "Celestial Ascendant",
    minStreak: 30,
    minTrust: 80,
    description: "Transcendent entity wielding triple celestial orbital rings and golden cosmic aura.",
    glowColor: "#FFC066",
    badge: "👑 Legend"
  }
};

/**
 * Evaluates whether Genie qualifies for an evolution upgrade
 * Requires consistency (streak/workouts) AND integrityScore >= 80%
 */
export function calculateGenieStage(
  currentStage: 1 | 2 | 3 = 1,
  streak: number = 0,
  integrityScore: number = 100,
  totalWorkouts: number = 0
): 1 | 2 | 3 {
  const isHighTrust = integrityScore >= 80;
  // Stage 3: Legend (30+ day streak or 30+ total verified workouts with high trust)
  if (isHighTrust && (streak >= 30 || totalWorkouts >= 30)) {
    return 3;
  }
  // Stage 2: Warrior (7+ day streak or 7+ workouts with high trust)
  if (isHighTrust && (streak >= 7 || totalWorkouts >= 7)) {
    return Math.max(currentStage, 2) as 1 | 2 | 3;
  }
  return currentStage || 1;
}

/**
 * Checks Genie's vitality based on user activity recency (>3 days = Sick/Weak)
 */
export function getGenieVitality(lastActiveDate?: string, lastWorkoutDate?: string): {
  isSick: boolean;
  daysInactive: number;
  statusText: string;
} {
  const today = getLocalDateString(new Date());
  const refDate = lastActiveDate || lastWorkoutDate || today;
  const daysInactive = getDaysBetween(refDate, today);
  const isSick = daysInactive > 3;
  return {
    isSick,
    daysInactive,
    statusText: isSick
      ? `Sick & Weak (${daysInactive} days inactive)`
      : "Vibrant & Energetic 🔥"
  };
}

export interface UserProfile {
  uid: string;
  username: string;
  fighterId?: string;
  email?: string;
  photoURL: string;
  xp: number;
  rank: string;
  streak: number;
  joinDate: string;
  totalWorkouts?: number;
  challengeWins?: number;
  calisthenicsUnlocked?: string[];
  fitnessScore?: number;
  dailyXP?: number;
  weeklyXP?: number;
  monthlyXP?: number;
  lastDate?: string;
  lastWeek?: string;
  lastMonth?: string;
  avatarBg?: string;
  friends?: string[];
  achievedCalisthenics?: string[];
  last_workout_date?: string;
  // Module 1: Genie Evolution & Inactivity
  genieStage?: 1 | 2 | 3;
  lastActiveDate?: string;
  // Module 2: The Mystery Dojo Rewards & Penalties
  streakShields?: number;
  doubleXpUntil?: number;
  unlockedOrbSkins?: string[];
  activeOrbSkin?: string;
  activeCursedChallenge?: {
    id: string;
    title: string;
    targetReps: number;
    timeLimitSecs: number;
    startedAt: number;
    expiresAt: number;
    penaltyXp: number;
    completed?: boolean;
  } | null;
  // Module 3: Guilds & Clan Wars
  guildId?: string;
  goal?: string;
  completed_workouts?: { date: string; exerciseName: string }[];
  mogged_exercises?: { date: string; exerciseName: string }[];
  recoveryWorkouts?: number;
  recoveringFromZero?: boolean;
  isPremium?: boolean;
  isPro?: boolean;
  subscriptionStatus?: string;
  expiry_date?: string;
  theme?: string;
  bio?: string;
  age?: number;
  gender?: string;
  level?: string;
  onboardingDone?: boolean;
  performance_metrics?: { exerciseId: string; durationSecs: number; timestamp: number }[];
  claimedTasks?: string[];
  claimedPromos?: string[];
  integrityScore?: number;
  integrityViolations?: number;
  consecutiveHonestDays?: number;
  totalSquats?: number;
  bestSquat1Min?: number;
  totalPushups?: number;
  bestPushup1Min?: number;
  stats?: { squats_all?: number; squats_1min?: number; pushups_all?: number; pushups_1min?: number };
  
  // Detailed Onboarding & 90-Day Glow-Up Personalization Fields
  name?: string;
  dateOfBirth?: string;
  height?: number;
  weight?: number;
  targetWeight?: number;
  bodyType?: string;
  activityLevel?: string;
  mainGoal?: string;
  progressPace?: string;
  bmi?: number;
  bmr?: number;
  dailyCalorieTarget?: number;
  waterIntakeGoal?: number;
  onboardingCompleted?: boolean;
  appLanguage?: "hinglish" | "english";
  trainingPath?: "calisthenics" | "gym" | "home_jugaad" | "aesthetics";
  dietPreference?: "veg" | "egg" | "nonveg";
  kitchenSetup?: "hostel" | "home";
  currentBfPercent?: number;
  dreamPhysique?: string;
  warriorClass?: string;
  glowUpStartDate?: string;
  aiBaselineScore?: number;
}

export function getRankFromXP(xp: number): string {
  if (xp >= 10000) return "Ascended";
  if (xp >= 7500) return "Mythic";
  if (xp >= 5000) return "Legend";
  if (xp >= 3000) return "Titan";
  if (xp >= 2000) return "Champion";
  if (xp >= 1000) return "Elite";
  if (xp >= 500) return "Warrior";
  return "Beginner";
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  profileRequired: boolean;
  isOnline: boolean;
  lastSyncedAt: number;
  signUpWithEmail: (email: string, password: string) => Promise<any>;
  signInWithEmail: (email: string, password: string) => Promise<any>;
  signInWithGoogle: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  completeProfileSetup: (username: string, photoURL: string) => Promise<UserProfile>;
  signOutUser: () => Promise<void>;
  refreshProfile: (force?: boolean) => Promise<void>;
  updateUserXP: (additionalXP: number) => Promise<void>;
  updateProfileStats: (stats: { 
    xpGained?: number; 
    workoutCompleted?: boolean; 
    workoutCompletedOnTime?: boolean;
    dailyGoalCompleted?: boolean;
    challengeWon?: boolean; 
    streakChange?: number;
    completedWorkoutName?: string;
    completedMoggedExerciseName?: string;
    goal?: string;
    theme?: string;
    taskClaimed?: string;
    integrityScoreChange?: number;
    integrityViolationsChange?: number;
    consecutiveHonestDaysChange?: number;
  }) => Promise<void>;
  toggleFriend: (friendUid: string) => Promise<void>;
  updateUserProfileFields: (fields: Partial<UserProfile>) => Promise<void>;
  logMoggedExercise: (exerciseName: string, xp?: number) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Profile comparison helper to prevent redundant Firestore writes
function areProfilesEqual(a: UserProfile | null, b: UserProfile | null): boolean {
  if (!a && !b) return true;
  if (!a || !b) return false;
  return (
    a.uid === b.uid &&
    a.xp === b.xp &&
    a.streak === b.streak &&
    a.last_workout_date === b.last_workout_date &&
    a.integrityScore === b.integrityScore &&
    a.totalWorkouts === b.totalWorkouts &&
    a.isPro === b.isPro &&
    a.fighterId === b.fighterId &&
    a.username === b.username &&
    JSON.stringify(a.stats || {}) === JSON.stringify(b.stats || {})
  );
}

export function AuthProvider({ children }: { children: ReactNode }) {
  // 1. SWR HYDRATION: Synchronously load profile from LocalStorage on first render
  const initialCachedProfile = getCachedProfile();
  const [profile, setProfile] = useState<UserProfile | null>(initialCachedProfile);
  const [user, setUser] = useState<User | null>(null);
  
  // Instant load if cached data is already present! (No blank screen, 0ms latency)
  const [loading, setLoading] = useState<boolean>(!initialCachedProfile);
  const [profileRequired, setProfileRequired] = useState(false);
  const [isOnline, setIsOnline] = useState<boolean>(() => (typeof navigator !== "undefined" ? navigator.onLine : true));
  const [lastSynced, setLastSynced] = useState<number>(getLastSyncedAt);

  // Track the last written payload to prevent duplicate Firestore writes
  const lastWrittenProfileRef = useRef<string>(initialCachedProfile ? JSON.stringify(initialCachedProfile) : "");
  const isSyncingRef = useRef<boolean>(false);

  // Network listener & auto-flush offline updates
  useEffect(() => {
    const handleOnline = async () => {
      setIsOnline(true);
      console.log("[AuthContext] Network restored. Flushing offline queue and revalidating profile...");
      await flushOfflineQueue();
      if (auth.currentUser) {
        revalidateFromCloud(auth.currentUser.uid);
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      console.log("[AuthContext] Network disconnected. Operating in zero-read offline mode.");
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // Background Cloud Revalidation (Stale-While-Revalidate)
  const revalidateFromCloud = useCallback(async (uid: string, force = false) => {
    if (!navigator.onLine) {
      console.log("[SWR] Device is offline. Skipping Firestore read.");
      return;
    }

    // Cost optimization: Throttling read if recently synced (< 60s) unless forced
    const now = Date.now();
    const lastSync = getLastSyncedAt();
    if (!force && lastSync > 0 && now - lastSync < 60_000) {
      console.log("[SWR] Profile was synced recently (<60s). Skipping redundant Firestore read to save quota.");
      return;
    }

    if (isSyncingRef.current) return;
    isSyncingRef.current = true;

    try {
      console.log("[SWR] Background revalidating profile from Firestore for uid:", uid);
      const userRef = doc(db, "users", uid);
      const userSnap = await getDoc(userRef);

      if (userSnap.exists()) {
        const cloudProfile = userSnap.data() as UserProfile;
        
        let needsCloudUpdate = false;
        const updates: Partial<UserProfile> = {};

        // Generate Fighter ID only if missing
        if (!cloudProfile.fighterId) {
          cloudProfile.fighterId = "#" + Math.floor(1000 + Math.random() * 9000).toString();
          updates.fighterId = cloudProfile.fighterId;
          needsCloudUpdate = true;
        }

        // Streak check with Streak Shield Protection (Module 2)
        if (cloudProfile.last_workout_date) {
          const todayStr = getLocalDateString(new Date());
          const diffDays = getDaysBetween(cloudProfile.last_workout_date, todayStr);
          if (diffDays > 1 && cloudProfile.streak > 0) {
            if (cloudProfile.streakShields && cloudProfile.streakShields > 0) {
              cloudProfile.streakShields -= 1;
              updates.streakShields = cloudProfile.streakShields;
              needsCloudUpdate = true;
              console.log("[AuthContext] Streak Shield consumed! Streak preserved.");
            } else {
              cloudProfile.streak = 0;
              updates.streak = 0;
              needsCloudUpdate = true;
            }
          }
        }

        // Module 1: Genie Evolution & Activity Recency check
        if (!cloudProfile.genieStage) {
          cloudProfile.genieStage = calculateGenieStage(
            1,
            cloudProfile.streak || 0,
            cloudProfile.integrityScore ?? 100,
            cloudProfile.totalWorkouts || 0
          );
          updates.genieStage = cloudProfile.genieStage;
          needsCloudUpdate = true;
        }
        if (!cloudProfile.lastActiveDate) {
          cloudProfile.lastActiveDate = cloudProfile.last_workout_date || getLocalDateString(new Date());
          updates.lastActiveDate = cloudProfile.lastActiveDate;
          needsCloudUpdate = true;
        }

        // If local profile had newer changes offline, resolve conflicts
        const local = getCachedProfile();
        let finalProfile = cloudProfile;
        if (local && local.uid === cloudProfile.uid) {
          // If local XP or stats are ahead due to offline workouts, preserve them
          if ((local.xp || 0) > (cloudProfile.xp || 0)) {
            finalProfile = { ...cloudProfile, ...local };
            needsCloudUpdate = true;
          }
        }

        // Save to LocalStorage and update state
        setCachedProfile(finalProfile);
        setProfile(finalProfile);
        setLastSynced(Date.now());
        lastWrittenProfileRef.current = JSON.stringify(finalProfile);

        if (finalProfile.onboardingCompleted) {
          localStorage.setItem("fitgenie_onboarding_completed", "true");
        }

        // Only write to Firestore if we actually fixed fighterId or streak
        if (needsCloudUpdate) {
          await setDoc(userRef, updates, { merge: true });
        }
      }
    } catch (err) {
      console.warn("[SWR] Background fetch error (falling back to cached data):", err);
    } finally {
      isSyncingRef.current = false;
      setLoading(false);
    }
  }, []);

  // Listen to Auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);

      if (currentUser) {
        // If current cached profile matches the user, keep it immediately active
        const cached = getCachedProfile();
        if (cached && cached.uid === currentUser.uid) {
          setProfile(cached);
          setLoading(false);
        }

        // Trigger background SWR fetch
        await revalidateFromCloud(currentUser.uid);
      } else {
        setProfile(null);
        setCachedProfile(null);
        localStorage.removeItem(CACHE_KEYS.PROFILE);
        localStorage.removeItem(CACHE_KEYS.LEGACY_PROFILE);
        localStorage.removeItem("fitgenie_onboarding_completed");
        localStorage.removeItem("fitgenie_user");
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, [revalidateFromCloud]);

  /**
   * COST-OPTIMIZED SAVE PROFILE:
   * 1. Updates React state and LocalStorage immediately.
   * 2. Checks if data actually changed before making any network request.
   * 3. If offline, enqueues the action for background sync when reconnected.
   * 4. If online, writes to Firestore using { merge: true }.
   */
  const saveProfile = async (updatedProfile: UserProfile): Promise<void> => {
    // 1. Instant local write
    setProfile(updatedProfile);
    setCachedProfile(updatedProfile);

    if (!updatedProfile.uid || updatedProfile.uid === "local_user") {
      return;
    }

    // 2. Diff check: If payload is identical to previous write, skip Firestore entirely!
    const serialized = JSON.stringify(updatedProfile);
    if (serialized === lastWrittenProfileRef.current) {
      console.log("[AuthContext] Profile data identical to last write. Skipped Firestore write (saved 1 write cost).");
      return;
    }

    // 3. Offline handling: Queue the update locally if network is down
    if (!navigator.onLine) {
      console.log("[AuthContext] Device offline. Storing profile update in offline queue.");
      enqueueOfflineAction({
        type: "PROFILE_UPDATE",
        payload: {
          uid: updatedProfile.uid,
          xp: updatedProfile.xp,
          stats: updatedProfile.stats,
          streak: updatedProfile.streak
        }
      });
      return;
    }

    // 4. Online Firestore write
    try {
      const avatarStyles = ["bg-blue-500", "bg-pink-500", "bg-purple-500", "bg-emerald-500", "bg-orange-500", "bg-indigo-500"];
      const avatarIndex = updatedProfile.uid.length % avatarStyles.length;
      const avatarBg = updatedProfile.avatarBg || `${avatarStyles[avatarIndex]} text-white border-${avatarStyles[avatarIndex].replace("bg-", "")}`;

      const userRef = doc(db, "users", updatedProfile.uid);
      await setDoc(
        userRef,
        {
          ...updatedProfile,
          userId: updatedProfile.uid,
          userName: updatedProfile.username || "Anonymous Athlete",
          xp: Number(updatedProfile.xp || 0),
          avatarBg
        },
        { merge: true }
      );

      lastWrittenProfileRef.current = serialized;
      setLastSynced(Date.now());
      console.log("[AuthContext] Successfully synced profile to Firestore.");
    } catch (e) {
      console.error("[AuthContext] Failed to write profile to Firestore, queued for retry:", e);
      enqueueOfflineAction({
        type: "PROFILE_UPDATE",
        payload: updatedProfile
      });
    }
  };

  const signInWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: "select_account" });
    try {
      const result = await signInWithPopup(auth, provider, browserPopupRedirectResolver);
      const currentUser = result.user;
      const userRef = doc(db, "users", currentUser.uid);
      const userSnap = await getDoc(userRef);

      if (userSnap.exists()) {
        const p = userSnap.data() as UserProfile;
        setProfile(p);
        setCachedProfile(p);
        lastWrittenProfileRef.current = JSON.stringify(p);
        if (p.onboardingCompleted) localStorage.setItem("fitgenie_onboarding_completed", "true");
      } else {
        const avatarStyles = ["bg-blue-500", "bg-pink-500", "bg-purple-500", "bg-emerald-500", "bg-orange-500", "bg-indigo-500"];
        const avatarIndex = currentUser.uid.length % avatarStyles.length;
        const avatarBg = `${avatarStyles[avatarIndex]} text-white border-${avatarStyles[avatarIndex].replace("bg-", "")}`;

        const baseName = (currentUser.displayName || "Warrior").replace(/[^a-zA-Z0-9]/g, "");
        const randomSuffix = Math.floor(1000 + Math.random() * 9000).toString();
        const initialUsername = `${baseName}${randomSuffix}`.toLowerCase();

        const newProfile: UserProfile = {
          uid: currentUser.uid,
          username: initialUsername,
          fighterId: "#" + randomSuffix,
          email: currentUser.email || "",
          photoURL: currentUser.photoURL || "",
          xp: 0,
          rank: getRankFromXP(0),
          streak: 0,
          joinDate: getLocalDateString(new Date()),
          integrityScore: 100,
          onboardingCompleted: false,
          avatarBg,
          genieStage: 1,
          lastActiveDate: getLocalDateString(new Date())
        };

        await setDoc(userRef, {
          ...newProfile,
          userId: currentUser.uid,
          userName: newProfile.username
        });

        // Reserve initial username
        await setDoc(doc(db, "usernames", initialUsername), { uid: currentUser.uid });

        setProfile(newProfile);
        setCachedProfile(newProfile);
        lastWrittenProfileRef.current = JSON.stringify(newProfile);
      }
    } catch (error: any) {
      if (
        error?.code === "auth/popup-closed-by-user" ||
        error?.code === "auth/cancelled-popup-request"
      ) {
        // User intentionally closed or cancelled the sign-in popup; rethrow with a silent flag for UI handling
        const cancelledErr = new Error("POPUP_CLOSED_BY_USER");
        (cancelledErr as any).code = error.code;
        throw cancelledErr;
      }
      console.warn("Google Sign-In issue:", error?.message || error);
      throw error;
    }
  };

  const signOutUser = async () => {
    try {
      await signOut(auth);
      setProfile(null);
      setUser(null);
      setCachedProfile(null);
      localStorage.removeItem("fitgenie_onboarding_completed");
      localStorage.removeItem("fitgenie_user");
      window.location.reload();
    } catch (error) {
      console.error("Error signing out:", error);
      throw error;
    }
  };

  const updateUserXP = async (additionalXP: number) => {
    if (!profile) return;
    
    // Module 2: Check for active Double XP buff (24h Lootbox reward)
    const isDoubleXpActive = profile.doubleXpUntil && Date.now() < profile.doubleXpUntil && additionalXP > 0;
    const effectiveAdditionalXP = isDoubleXpActive ? additionalXP * 2 : additionalXP;

    const newXP = Math.max(0, Number(profile.xp || 0) + Number(effectiveAdditionalXP || 0));
    const newRank = getRankFromXP(newXP);

    const today = getLocalDateString(new Date());
    const thisWeek = getISOWeekString(new Date());
    const thisMonth = getISOMonthString(new Date());

    let dailyXP = profile.dailyXP || 0;
    let weeklyXP = profile.weeklyXP || 0;
    let monthlyXP = profile.monthlyXP || 0;

    if (profile.lastDate !== today) dailyXP = 0;
    if (profile.lastWeek !== thisWeek) weeklyXP = 0;
    if (profile.lastMonth !== thisMonth) monthlyXP = 0;

    await saveProfile({
      ...profile,
      xp: newXP,
      rank: newRank,
      dailyXP: dailyXP + additionalXP,
      weeklyXP: weeklyXP + additionalXP,
      monthlyXP: monthlyXP + additionalXP,
      lastDate: today,
      lastWeek: thisWeek,
      lastMonth: thisMonth
    });
  };

  const updateProfileStats = async (stats: any) => {
    if (!profile) return;

    const updatedProfile = { ...profile };

    if (stats.xpGained) {
      updatedProfile.xp = Number(updatedProfile.xp || 0) + Number(stats.xpGained || 0);
      updatedProfile.rank = getRankFromXP(updatedProfile.xp);

      const today = getLocalDateString(new Date());
      const thisWeek = getISOWeekString(new Date());
      const thisMonth = getISOMonthString(new Date());

      if (updatedProfile.lastDate !== today) updatedProfile.dailyXP = 0;
      if (updatedProfile.lastWeek !== thisWeek) updatedProfile.weeklyXP = 0;
      if (updatedProfile.lastMonth !== thisMonth) updatedProfile.monthlyXP = 0;

      updatedProfile.dailyXP = Number(updatedProfile.dailyXP || 0) + Number(stats.xpGained || 0);
      updatedProfile.weeklyXP = Number(updatedProfile.weeklyXP || 0) + Number(stats.xpGained || 0);
      updatedProfile.monthlyXP = Number(updatedProfile.monthlyXP || 0) + Number(stats.xpGained || 0);

      updatedProfile.lastDate = today;
      updatedProfile.lastWeek = thisWeek;
      updatedProfile.lastMonth = thisMonth;
    }

    if (stats.workoutCompleted) {
      updatedProfile.totalWorkouts = (updatedProfile.totalWorkouts || 0) + 1;
      const today = getLocalDateString(new Date());

      if (updatedProfile.last_workout_date !== today) {
        if (updatedProfile.last_workout_date) {
          const diff = getDaysBetween(updatedProfile.last_workout_date, today);
          if (diff === 1) {
            updatedProfile.streak += 1;
          } else if (diff > 1) {
            updatedProfile.streak = 1;
          }
        } else {
          updatedProfile.streak = 1;
        }
        updatedProfile.last_workout_date = today;
      }
    }

    if (stats.challengeWon) {
      updatedProfile.challengeWins = (updatedProfile.challengeWins || 0) + 1;
    }

    if (stats.integrityScoreChange) {
      updatedProfile.integrityScore = Math.min(100, Math.max(0, (updatedProfile.integrityScore || 100) + stats.integrityScoreChange));
    }

    if (stats.integrityViolationsChange) {
      updatedProfile.integrityViolations = (updatedProfile.integrityViolations || 0) + stats.integrityViolationsChange;
    }

    if (stats.consecutiveHonestDaysChange !== undefined) {
      if (stats.consecutiveHonestDaysChange === 0) {
        updatedProfile.consecutiveHonestDays = 0;
      } else {
        updatedProfile.consecutiveHonestDays = (updatedProfile.consecutiveHonestDays || 0) + stats.consecutiveHonestDaysChange;
      }
    }

    // Module 1: Activity Recency & Genie Evolution Progression
    const todayStr = getLocalDateString(new Date());
    updatedProfile.lastActiveDate = todayStr;
    const evolvedStage = calculateGenieStage(
      updatedProfile.genieStage || 1,
      updatedProfile.streak || 0,
      updatedProfile.integrityScore ?? 100,
      updatedProfile.totalWorkouts || 0
    );
    updatedProfile.genieStage = evolvedStage;

    await saveProfile(updatedProfile);
  };

  const updateUserProfileFields = async (fields: Partial<UserProfile>): Promise<void> => {
    if (!profile) throw new Error("No profile");

    const mergedFields = { ...fields };
    if (fields.stats) {
      mergedFields.stats = { ...(profile.stats || {}), ...fields.stats };
    }

    await saveProfile({ ...profile, ...mergedFields });
  };

  const refreshProfile = async (force = true) => {
    if (user) {
      await revalidateFromCloud(user.uid, force);
    }
  };

  const signUpWithEmail = async () => {};
  const signInWithEmail = async () => {};
  const resetPassword = async () => {};
  const completeProfileSetup = async () => ({} as any);
  const logMoggedExercise = async () => {};
  const toggleFriend = async (_friendUid: string) => {};

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        profileRequired,
        isOnline,
        lastSyncedAt: lastSynced,
        signUpWithEmail,
        signInWithEmail,
        signInWithGoogle,
        resetPassword,
        completeProfileSetup,
        signOutUser,
        refreshProfile,
        updateUserXP,
        updateProfileStats,
        toggleFriend,
        updateUserProfileFields,
        logMoggedExercise
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

export function getRankDetails(xp: number) {
  if (xp >= 10000) return { title: "Ascended", next: "Max", base: 10000, nextXP: 99999, emoji: "✨" };
  if (xp >= 7500) return { title: "Mythic", next: "Ascended", base: 7500, nextXP: 10000, emoji: "🌟" };
  if (xp >= 5000) return { title: "Legend", next: "Mythic", base: 5000, nextXP: 7500, emoji: "👑" };
  if (xp >= 3000) return { title: "Titan", next: "Legend", base: 3000, nextXP: 5000, emoji: "🦁" };
  if (xp >= 2000) return { title: "Champion", next: "Titan", base: 2000, nextXP: 3000, emoji: "🏆" };
  if (xp >= 1000) return { title: "Elite", next: "Champion", base: 1000, nextXP: 2000, emoji: "⚔️" };
  if (xp >= 500) return { title: "Warrior", next: "Elite", base: 500, nextXP: 1000, emoji: "🗡️" };
  return { title: "Beginner", next: "Warrior", base: 0, nextXP: 500, emoji: "🌱" };
}
