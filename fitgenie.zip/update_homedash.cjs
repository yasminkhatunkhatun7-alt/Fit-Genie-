const fs = require('fs');
let code = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf-8');

// Insert calculations before `return (`
const returnRegex = /  return \(/;
const calculations = `
  const dailyCalories = useMemo(() => {
    const sessionsToday = history.filter((s) => s.date.startsWith(todayStr));
    const totalMinutes = sessionsToday.reduce((sum, s) => sum + s.totalDurationMin, 0);
    return Math.round(totalMinutes * 8.5);
  }, [history, todayStr]);
  const dailyCalorieTarget = 500;
  const caloriePercent = Math.min(100, Math.max(0, (dailyCalories / dailyCalorieTarget) * 100));

  const dailyXP = profile?.dailyXP || 0;
  const dailyXPTarget = 200;
  const xpPercent = Math.min(100, Math.max(0, (dailyXP / dailyXPTarget) * 100));

  return (`;

code = code.replace(returnRegex, calculations);

// Replace the avatar block
const avatarRegex = /<div className="w-12 h-12 rounded-full border-2 border-\[#14F1E1\] bg-\[#0D1328\] flex items-center justify-center text-xl shadow-\[0_0_15px_rgba\(20,241,225,0\.3\)\]">\s*\{profile\?\.photoURL \|\| "👤"\}\s*<\/div>/m;

const newAvatar = `          <div className="relative w-16 h-16 flex items-center justify-center mr-1 shrink-0">
            {/* Progress Rings SVG */}
            <svg className="absolute inset-0 w-full h-full -rotate-90">
              {/* Calorie Ring Background */}
              <circle cx="32" cy="32" r="26" stroke="#F59E0B" strokeWidth="2.5" fill="none" opacity="0.15" />
              {/* Calorie Ring Progress */}
              <motion.circle 
                cx="32" cy="32" r="26" stroke="#F59E0B" strokeWidth="2.5" fill="none"
                strokeDasharray="163.36" 
                strokeDashoffset={163.36 - (163.36 * caloriePercent) / 100}
                strokeLinecap="round"
                initial={{ strokeDashoffset: 163.36 }}
                animate={{ strokeDashoffset: 163.36 - (163.36 * caloriePercent) / 100 }}
                transition={{ duration: 1.5, ease: "easeOut" }}
              />
              {/* XP Ring Background */}
              <circle cx="32" cy="32" r="31" stroke="#14F1E1" strokeWidth="2.5" fill="none" opacity="0.15" />
              {/* XP Ring Progress */}
              <motion.circle 
                cx="32" cy="32" r="31" stroke="#14F1E1" strokeWidth="2.5" fill="none"
                strokeDasharray="194.77" 
                strokeDashoffset={194.77 - (194.77 * xpPercent) / 100}
                strokeLinecap="round"
                initial={{ strokeDashoffset: 194.77 }}
                animate={{ strokeDashoffset: 194.77 - (194.77 * xpPercent) / 100 }}
                transition={{ duration: 1.5, ease: "easeOut", delay: 0.2 }}
              />
            </svg>
            <div className="w-10 h-10 rounded-full bg-[#0D1328] flex items-center justify-center text-lg z-10 relative overflow-hidden shadow-[0_0_10px_rgba(20,241,225,0.2)]">
              {profile?.photoURL && profile.photoURL.startsWith("http") ? (
                <img src={profile.photoURL} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                profile?.photoURL || "👤"
              )}
            </div>
            
            {/* Tooltip on hover/tap (optional but good for UX) */}
            <div className="absolute inset-0 z-20 group cursor-pointer">
               <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-max bg-black/90 border border-white/10 rounded-lg p-2 text-[10px] uppercase font-bold tracking-widest text-white opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none flex flex-col gap-1 shadow-xl">
                 <span className="text-[#14F1E1] flex items-center gap-1"><Zap className="w-3 h-3" /> {dailyXP} / {dailyXPTarget} XP</span>
                 <span className="text-[#F59E0B] flex items-center gap-1"><Flame className="w-3 h-3" /> {dailyCalories} / {dailyCalorieTarget} KCAL</span>
               </div>
            </div>
          </div>`;

if (code.match(avatarRegex)) {
  code = code.replace(avatarRegex, newAvatar);
  fs.writeFileSync('src/components/HomeDashboard.tsx', code);
  console.log("Updated HomeDashboard avatar rings!");
} else {
  console.log("Could not find avatar div regex!");
}
