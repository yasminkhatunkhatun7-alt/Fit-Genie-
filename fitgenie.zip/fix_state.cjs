const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');

if (!code.includes('const [showAiCounter')) {
  code = code.replace(
    /const \[view, setView\] = useState.*?;\n/g,
    match => match + '  const [showAiCounter, setShowAiCounter] = useState(false);\n  const [aiExerciseIndex, setAiExerciseIndex] = useState<number>(0);\n'
  );
  fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
  console.log('added state');
}
