const fs = require('fs');

const filesToPatch = [
  'src/components/SpeedChallengeScreen.tsx',
  'src/components/StrengthChallengeScreen.tsx',
  'src/components/WeeklyChallengeScreen.tsx',
  'src/components/CustomChallengeDetailScreen.tsx',
];

for (const file of filesToPatch) {
  let code = fs.readFileSync(file, 'utf8');

  // Imports
  if (!code.includes('useIntegrityEngine')) {
    code = "import { useIntegrityEngine } from '../hooks/useIntegrityEngine';\nimport AntiCheatOverlay from './AntiCheatOverlay';\n" + code;
  }

  // Component Start
  const compNameMatch = code.match(/export default function ([A-Za-z0-9_]+)\(\{ challenge, onUpdate/);
  if (!compNameMatch) continue;
  
  const compStartStr = `export default function ${compNameMatch[1]}({ challenge, onUpdate`;
  const compStartMatch = code.substring(code.indexOf(compStartStr));
  const braceIdx = compStartMatch.indexOf('{') + 1;
  const injectPos = code.indexOf(compStartStr) + braceIdx;

  const hookInjection = `
  const {
    cooldown,
    suspiciousPhase,
    lockEndTime,
    validateAndAddReps,
    proceedFromAlert,
    proceedFromMotivation,
    submitApology,
    resetSessionTime
  } = useIntegrityEngine(challenge.id);
`;
  
  if (!code.includes('useIntegrityEngine(challenge.id)')) {
    code = code.substring(0, injectPos) + hookInjection + code.substring(injectPos);
  }

  // Replace overlay render
  // First, find and remove cheat warning UI
  const overlayRender = `
  if (suspiciousPhase !== 'none') {
    return (
      <AntiCheatOverlay 
        suspiciousPhase={suspiciousPhase}
        lockEndTime={lockEndTime}
        onProceedFromAlert={proceedFromAlert}
        onProceedFromMotivation={proceedFromMotivation}
        onSubmitApology={submitApology}
      />
    );
  }
`;
  if (!code.includes('AntiCheatOverlay')) {
    if (code.includes('if (showCheatWarning) {')) {
       code = code.replace(/  if \(showCheatWarning\) \{[\s\S]*?  \}/, overlayRender);
    } else {
       // Insert it right before the first `return (` of the main view
       const returnViewIdx = code.lastIndexOf('return (');
       code = code.substring(0, returnViewIdx) + overlayRender + code.substring(returnViewIdx);
    }
  }

  fs.writeFileSync(file, code);
}
