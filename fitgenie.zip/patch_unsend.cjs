const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

// 1. Add Trash2 icon
code = code.replace(
  'import { Globe, Send, ShieldAlert, Zap, Loader2 } from "lucide-react";',
  'import { Globe, Send, ShieldAlert, Zap, Loader2, Trash2 } from "lucide-react";'
);

// 2. Add handleUnsend function
const fetchMessagesTarget = `  const fetchMessages = async () => {`;
const handleUnsendFunc = `  const handleUnsend = async (msgId: string) => {
    const currentUserId = user?.id || localStorage.getItem("fitgenie_anon_id");
    try {
      const res = await fetch(\`/api/chat/messages/\${msgId}\`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: currentUserId })
      });
      if (res.ok) {
        setMessages(prev => prev.filter(m => m.id !== msgId));
      }
    } catch (e) {
      console.error("Failed to unsend message", e);
    }
  };

  const fetchMessages = async () => {`;

if (!code.includes('handleUnsend')) {
  code = code.replace(fetchMessagesTarget, handleUnsendFunc);
}

// 3. Add UI button inside the message mapping
const timeSpanTarget = `<span className="text-[8px] font-bold text-neutral-600 mt-1 px-1">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>`;

const timeSpanWithUnsend = `<div className="flex items-center gap-3 mt-1 px-1">
                    <span className="text-[8px] font-bold text-neutral-600">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    {isMe && (
                      <button onClick={() => handleUnsend(msg.id)} className="text-[9px] font-bold uppercase tracking-widest text-red-500/70 hover:text-red-400 flex items-center gap-1 transition-colors">
                        <Trash2 className="w-3 h-3" /> Unsend
                      </button>
                    )}
                  </div>`;

if (!code.includes('handleUnsend(msg.id)')) {
  code = code.replace(timeSpanTarget, timeSpanWithUnsend);
}

fs.writeFileSync('src/components/WorldChat.tsx', code);
console.log("Unsend feature added");
