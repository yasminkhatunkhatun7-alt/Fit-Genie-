const fs = require('fs');
let code = fs.readFileSync('src/components/AiRepCounter.tsx', 'utf-8');

const target = `          {!challengeTarget && (
          <div className="flex bg-white/5 rounded-xl p-1 mb-4">
            <button onClick={() => { setMode("free"); setTestTimeLeft(null); setIsActive(false); }} className={\`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all \${mode === "free" ? "bg-[#14F1E1] text-[#050B1A]" : "text-white hover:text-[#14F1E1]"}\`}>Free Flow</button>
            <button onClick={() => { setMode("test"); setTestTimeLeft(60); setIsActive(false); setReps(0); repStateRef.current.reps = 0; }} className={\`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all \${mode === "test" ? "bg-[#B66DFF] text-white" : "text-white hover:text-[#B66DFF]"}\`}>1-Min Test</button>
          </div>
`;
code = code.replace(target, target + "          )}\n");

fs.writeFileSync('src/components/AiRepCounter.tsx', code);
