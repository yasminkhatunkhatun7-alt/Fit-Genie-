const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

const regex = /  const handleAddReps = \([\s\S]*?const currentReps = updated\.progress\[exercise\]/m;

const replacement = `  const handleAddReps = (exercise: string, amount: number) => {
    if (isMonthComplete) return;

    if (checkCheat(exercise, amount)) {
      return;
    }

    const now = Date.now();
    setLastActionTime(now);
    playSound("click");

    const targets = monthState.mode === 'legendary' ? TARGETS.legendary : TARGETS.normal;
    const maxReps = targets[exercise as keyof typeof targets];

    setMonthState(prev => {
       const updated = { ...prev };
       
       // Handle Daily Log for Cheat Detection (Keep tracking but trust Guardian logic for immediate rejection)
       if (!updated.dailyLog || updated.dailyLog.date !== todayStr) {
         updated.dailyLog = { date: todayStr, reps: {} };
       }
       const currentDailyReps = updated.dailyLog.reps[exercise] || 0;
       updated.dailyLog.reps[exercise] = currentDailyReps + amount;
       
       const currentReps = updated.progress[exercise]`;

content = content.replace(regex, replacement);
fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', content);
