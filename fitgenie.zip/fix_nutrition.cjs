const fs = require('fs');
const file = 'src/components/NutritionLog.tsx';
let code = fs.readFileSync(file, 'utf8');

// Add missing imports
code = code.replace(
  /import \{ Check, TrendingUp, RotateCcw \} from "lucide-react";/,
  'import { Check, TrendingUp, RotateCcw, Target, X, Settings, Apple, Flame, Droplet, Plus } from "lucide-react";'
);

code = code.replace(/confirmResetCurrentDay\(\)/, 'requestResetCurrentDay()');
code = code.replace(/NutritionGoalForm/, 'NutritionGoalModal'); // Wait, NutritionLog might not have NutritionGoalForm.

code = code.replace(/goals\.fatGoal/g, '0');
code = code.replace(/goals\.carbsGoal/g, '0');

fs.writeFileSync(file, code);
