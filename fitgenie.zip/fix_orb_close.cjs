const fs = require('fs');
let file = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

file = file.replace(
    '                    )}\n                  </div>\n                </div>\n              </div>\n            </motion.div>\n          </>\n        )}\n      </AnimatePresence>\n    </>\n  );\n}',
    '                    )}\n                  </div>\n                </div>\n                ) : (\n                  <GenieChat />\n                )}\n              </div>\n            </motion.div>\n          </>\n        )}\n      </AnimatePresence>\n    </>\n  );\n}'
);

fs.writeFileSync('src/components/GuardianOrb.tsx', file);
