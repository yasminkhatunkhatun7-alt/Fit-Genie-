const fs = require('fs');

let code = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');

if (!code.includes('getIntegrityRank')) {
  code = "import { getIntegrityRank } from '../utils/integrityEngine';\n" + code;
}

const statsSectionPattern = /      \{!\*\s*STATS ROW\s*\*!\}\n      <div className="grid grid-cols-2 gap-4">[\s\S]*?      <\/div>/;

const integrityUI = `
      {/* INTEGRITY SCORE */}
      <motion.div className="glass-card p-5 rounded-2xl glow-blue text-center mb-6" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-2">Integrity Score</h3>
        <div className="text-4xl font-black text-white">{profile?.integrityScore ?? 100}</div>
        <div className={\`text-xs font-bold uppercase tracking-widest mt-2 \${getIntegrityRank(profile?.integrityScore ?? 100).color}\`}>
          {getIntegrityRank(profile?.integrityScore ?? 100).badge} {getIntegrityRank(profile?.integrityScore ?? 100).title}
        </div>
      </motion.div>
`;

code = code.replace(/      \{!\*\s*STATS ROW\s*\*!\}/, integrityUI + '\n      {/* STATS ROW */}');

fs.writeFileSync('src/components/ProfileView.tsx', code);
