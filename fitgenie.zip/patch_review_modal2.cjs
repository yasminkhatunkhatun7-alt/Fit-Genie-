const fs = require('fs');

let code = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

const modalComponent = `
const ChallengeReviewModal = ({ monthState, minActiveDays, onContinue }: { monthState: MonthRPGState, minActiveDays: number, onContinue: (passed: boolean) => void }) => {
  const isProgressValid = true; 
  const isActivityValid = !monthState.validationFailed;
  const isConsistencyValid = monthState.activeDaysCount >= minActiveDays;
  
  return (
    <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} className="bg-[#111] border border-white/10 p-8 rounded-3xl w-full max-w-sm">
      <h2 className="text-2xl font-black text-white uppercase tracking-tight mb-6 text-center">Challenge Review</h2>
      <div className="space-y-3 mb-6">
        
        <div className="bg-neutral-900 border border-white/5 p-4 rounded-xl text-left">
           <div className="flex justify-between items-center mb-1">
             <span className="font-bold text-white uppercase text-sm flex items-center gap-2"><Target className="w-4 h-4" /> Progress Valid</span>
             {isProgressValid ? <span className="text-green-400 font-black">✓ PASS</span> : <span className="text-red-500 font-black">✗ FAIL</span>}
           </div>
           <p className="text-xs text-neutral-500 font-bold">100% Reps Completed</p>
        </div>

        <div className={\`bg-neutral-900 border \${isActivityValid ? 'border-white/5' : 'border-red-500/30 bg-red-500/10'} p-4 rounded-xl text-left\`}>
           <div className="flex justify-between items-center mb-1">
             <span className="font-bold text-white uppercase text-sm flex items-center gap-2"><Activity className="w-4 h-4" /> Activity Valid</span>
             {isActivityValid ? <span className="text-green-400 font-black">✓ PASS</span> : <span className="text-red-500 font-black">✗ FAIL</span>}
           </div>
           <p className="text-xs text-neutral-500 font-bold">
             {isActivityValid ? 'No irregular rep submissions detected' : 'Unrealistic submission rate or daily totals exceeded'}
           </p>
        </div>

        <div className={\`bg-neutral-900 border \${isConsistencyValid ? 'border-white/5' : 'border-red-500/30 bg-red-500/10'} p-4 rounded-xl text-left\`}>
           <div className="flex justify-between items-center mb-1">
             <span className="font-bold text-white uppercase text-sm flex items-center gap-2"><CalendarDays className="w-4 h-4" /> Consistency Valid</span>
             {isConsistencyValid ? <span className="text-green-400 font-black">✓ PASS</span> : <span className="text-red-500 font-black">✗ FAIL</span>}
           </div>
           <p className="text-xs text-neutral-500 font-bold">
             {isConsistencyValid ? \`Active \${monthState.activeDaysCount} out of \${minActiveDays} required days\` : \`Only active \${monthState.activeDaysCount} days, requires \${minActiveDays}\`}
           </p>
        </div>
      </div>
      <button 
        onClick={() => onContinue(isActivityValid && isConsistencyValid)}
        className={\`w-full py-4 text-white font-black uppercase tracking-widest rounded-xl transition \${isActivityValid && isConsistencyValid ? 'bg-blue-600 hover:bg-blue-500' : 'bg-red-600 hover:bg-red-500'}\`}
      >
        {isActivityValid && isConsistencyValid ? 'CONTINUE TO REWARDS' : 'ACCEPT FAILURE'}
      </button>
    </motion.div>
  )
}
`;

if (!code.includes('ChallengeReviewModal =')) {
  code = code.replace(/export default function OneMonthChallengeScreen/, modalComponent + '\nexport default function OneMonthChallengeScreen');
}

fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', code);
