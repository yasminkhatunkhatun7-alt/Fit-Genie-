const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf-8');

const faulty = `        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newProfile));
        localStorage.removeItem("fitgenie_onboarding_completed");
      localStorage.removeItem("fitgenie_user");
      window.location.reload();
      }`;

const fixed = `        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newProfile));
        localStorage.removeItem("fitgenie_onboarding_completed");
        localStorage.removeItem("fitgenie_user");
      }`;

code = code.replace(faulty, fixed);
fs.writeFileSync('src/context/AuthContext.tsx', code);
