const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

code = code.replace(/    taskClaimed\?: string;\n    integrityScoreChange\?: number;\n    integrityViolationsChange\?: number;\n    consecutiveHonestDaysChange\?: number;\n  \}\) => \{\n    if \(!user \|\| !profile\) return;/g, 
`    taskClaimed?: string;
    integrityScoreChange?: number;
    integrityViolationsChange?: number;
    consecutiveHonestDaysChange?: number;
  }) => Promise<void>;`);

code = code.replace(/  const updateProfileStats = async \(stats: \{\n    xpGained\?: number;\n    workoutCompleted\?: boolean;\n    challengeWon\?: boolean;\n    streakChange\?: number;\n    completedWorkoutName\?: string;\n    goal\?: string;\n    theme\?: string;\n    taskClaimed\?: string;\n  \}\) => Promise<void>;/, 
`  const updateProfileStats = async (stats: {
    xpGained?: number;
    workoutCompleted?: boolean;
    challengeWon?: boolean;
    streakChange?: number;
    completedWorkoutName?: string;
    goal?: string;
    theme?: string;
    taskClaimed?: string;
    integrityScoreChange?: number;
    integrityViolationsChange?: number;
    consecutiveHonestDaysChange?: number;
  }) => {
    if (!user || !profile) return;`);

fs.writeFileSync('src/context/AuthContext.tsx', code);
