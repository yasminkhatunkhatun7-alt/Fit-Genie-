const fs = require('fs');

function revert(file, regex) {
  if (!fs.existsSync(file)) return;
  const content = fs.readFileSync(file, 'utf8');
  fs.writeFileSync(file, content.replace(regex, ''));
}

revert('src/components/DailyMissions.tsx', /import \{ doc, getDoc, setDoc \} from 'firebase\/firestore';\nimport \{ db \} from '\.\.\/lib\/firebase';\n/);
revert('src/components/ExerciseVideos.tsx', /import \{ collection, onSnapshot \} from 'firebase\/firestore';\nimport \{ db \} from '\.\.\/lib\/firebase';\n/);
revert('src/components/ExercisesLibrary.tsx', /const updateUserProfile = async \(\) => \{\};\nconst updateUserProfileFields = async \(\) => \{\};\nconst updateData = async \(\) => \{\};\n/);
revert('src/components/GlobalCompletionCounter.tsx', /import \{ doc, setDoc, onSnapshot, increment \} from 'firebase\/firestore';\nimport \{ db \} from '\.\.\/lib\/firebase';\n/);
revert('src/components/MartialArts.tsx', /import \{ collection, onSnapshot \} from 'firebase\/firestore';\nimport \{ db \} from '\.\.\/lib\/firebase';\n/);
revert('src/components/ProfileView.tsx', /const updateUserProfileFields = async \(\) => \{\};\nconst updateData = async \(\) => \{\};\n/);
revert('src/utils/DailyMissionEngine.ts', /import \{ doc, getDoc, setDoc \} from 'firebase\/firestore';\nimport \{ db \} from '\.\.\/lib\/firebase';\n/);

console.log("Reverted fake firebase imports");
