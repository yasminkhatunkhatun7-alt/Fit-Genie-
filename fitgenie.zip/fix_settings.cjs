const fs = require('fs');

let settingsScreenContent = fs.readFileSync('src/components/SettingsScreen.tsx', 'utf8');
settingsScreenContent = settingsScreenContent.replace(
  'const [isPrivate, setIsPrivate] = useState(profile?.isPrivate || false);',
  'const [isPrivate, setIsPrivate] = useState((profile as any)?.isPrivate || false);'
);
settingsScreenContent = settingsScreenContent.replace(
  'notifyFriendRequests: profile?.notifyFriendRequests ?? true,',
  'notifyFriendRequests: (profile as any)?.notifyFriendRequests ?? true,'
);
settingsScreenContent = settingsScreenContent.replace(
  'notifyRecordBeaten: profile?.notifyRecordBeaten ?? true,',
  'notifyRecordBeaten: (profile as any)?.notifyRecordBeaten ?? true,'
);
settingsScreenContent = settingsScreenContent.replace(
  'notifyChatMessages: profile?.notifyChatMessages ?? true,',
  'notifyChatMessages: (profile as any)?.notifyChatMessages ?? true,'
);
settingsScreenContent = settingsScreenContent.replace(
  'notifyStreakReminders: profile?.notifyStreakReminders ?? true,',
  'notifyStreakReminders: (profile as any)?.notifyStreakReminders ?? true,'
);
fs.writeFileSync('src/components/SettingsScreen.tsx', settingsScreenContent);
