const fs = require('fs');
let file = fs.readFileSync('src/components/ChatView.tsx', 'utf8');

const searchState = `  const [activeScreen, setActiveScreen] = useState<"list" | "chat">("list");
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);`;

file = file.replace('  const [activeScreen, setActiveScreen] = useState<"list" | "chat">("list");', searchState);

const searchFunc = `  const searchUsers = async (qText: string) => {
    setSearchQuery(qText);
    if (qText.trim().length < 3) {
      setSearchResults([]);
      return;
    }
    setSearching(true);
    try {
      const q = query(collection(db, "users"), orderBy("userName"), limit(10));
      const snap = await getDocs(q);
      const results: any[] = [];
      const lowerQ = qText.toLowerCase();
      snap.forEach(d => {
        const data = d.data();
        if (data.userName && data.userName.toLowerCase().includes(lowerQ) && d.id !== currentUserId) {
          results.push({ id: d.id, userName: data.userName, avatarBg: data.avatarBg });
        }
      });
      setSearchResults(results);
    } catch (e) {
      console.error(e);
    } finally {
      setSearching(false);
    }
  };

  const followUser = async (userId: string) => {
    if (!currentUserId) return;
    try {
      const followId = currentUserId + "_" + userId;
      await setDoc(doc(db, "follows", followId), {
        followerId: currentUserId,
        followingId: userId,
        timestamp: Date.now()
      });
      alert("Follow request sent! If they follow you back, they will appear in your chats.");
      setShowSearch(false);
      setSearchQuery("");
      setSearchResults([]);
    } catch (e) {
      console.error(e);
    }
  };

  const loadMutualFriends = async () => {`;

file = file.replace('  const loadMutualFriends = async () => {', searchFunc);

const searchUI = `              <button onClick={loadMutualFriends} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white transition-colors">
                <RefreshCw className={\`w-4 h-4 \${loadingFriends ? 'animate-spin' : ''}\`} />
              </button>
              <button onClick={() => setShowSearch(true)} className="p-2 ml-2 rounded-lg bg-[#B66DFF]/20 text-[#B66DFF] hover:bg-[#B66DFF]/30 transition-colors">
                <Search className="w-4 h-4" />
              </button>`;

file = file.replace(`              <button onClick={loadMutualFriends} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white transition-colors">
                <RefreshCw className={\`w-4 h-4 \${loadingFriends ? 'animate-spin' : ''}\`} />
              </button>`, searchUI);


const searchModal = `            <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
              {showSearch && (
                <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
                  <div className="bg-[#0A1128] border border-[#1A2642] rounded-2xl w-full max-w-md p-4 flex flex-col max-h-[80vh]">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-lg font-black uppercase tracking-widest text-white">Find Athletes</h2>
                      <button onClick={() => setShowSearch(false)} className="p-2 rounded-lg hover:bg-white/5 text-brand-muted"><X className="w-5 h-5"/></button>
                    </div>
                    <div className="relative mb-4">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-muted" />
                      <input 
                        type="text" 
                        value={searchQuery}
                        onChange={(e) => searchUsers(e.target.value)}
                        placeholder="Search username (min 3 chars)..."
                        className="w-full bg-[#050B1A] border border-[#1A2642] text-white rounded-xl pl-9 pr-4 py-3 text-sm focus:outline-none focus:border-[#B66DFF]/50 transition-colors"
                      />
                    </div>
                    <div className="flex-1 overflow-y-auto custom-scrollbar space-y-2">
                      {searching ? (
                        <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-[#B66DFF] animate-spin" /></div>
                      ) : searchResults.length > 0 ? (
                        searchResults.map(user => (
                          <div key={user.id} className="flex items-center justify-between p-3 bg-[#050B1A] border border-[#1A2642] rounded-xl">
                            <div className="flex items-center gap-3">
                              <div className={\`w-10 h-10 rounded-lg flex items-center justify-center font-black text-white shrink-0 \${user.avatarBg || 'bg-zinc-800'}\`}>
                                {user.userName.charAt(0).toUpperCase()}
                              </div>
                              <h4 className="font-bold text-white text-sm">{user.userName}</h4>
                            </div>
                            <button onClick={() => followUser(user.id)} className="px-3 py-1.5 bg-[#B66DFF] text-white text-[10px] font-black uppercase tracking-widest rounded-lg hover:bg-[#A352FF] transition-colors">
                              Follow
                            </button>
                          </div>
                        ))
                      ) : searchQuery.length >= 3 ? (
                        <div className="text-center py-8 text-brand-muted text-xs uppercase font-bold tracking-widest">No athletes found</div>
                      ) : null}
                    </div>
                  </div>
                </div>
              )}`;

file = file.replace('<div className="flex-1 overflow-y-auto custom-scrollbar p-4">', searchModal);

fs.writeFileSync('src/components/ChatView.tsx', file);
