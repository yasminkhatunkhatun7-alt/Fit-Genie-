const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

code = code.replace(
  'const [activeTab, setActiveTab] = useState<"chat" | "leaderboard" | "network">("chat");',
  `const [activeTab, setActiveTab] = useState<"chat" | "leaderboard" | "network" | "friends">("chat");
  const [friendsList, setFriendsList] = useState<any[]>([]);`
);

fs.writeFileSync('src/components/WorldChat.tsx', code);
