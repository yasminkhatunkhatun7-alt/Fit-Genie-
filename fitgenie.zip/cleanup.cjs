const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

// remove states
content = content.replace(/  const \[verificationData, setVerificationData\] = useState[\s\S]*?;\n/, "");
content = content.replace(/  const \[verifyDuration, setVerifyDuration\] = useState\(""\);\n/, "");
content = content.replace(/  const \[verifyReps, setVerifyReps\] = useState\(""\);\n/, "");
content = content.replace(/  const \[verifyError, setVerifyError\] = useState\(""\);\n/, "");
content = content.replace(/  const \[showCheatWarning, setShowCheatWarning\] = useState\(false\);\n/, "");

// insert penalty modal
const penaltyModal = `  if (suspiciousPhase !== 'none') {
    return (
      <GeniePenaltyModal 
        suspiciousPhase={suspiciousPhase as any}
        lockEndTime={lockEndTime}
        onProceedFromAlert={proceedFromAlert}
        onProceedFromMotivation={proceedFromMotivation}
        onSubmitApology={submitApology}
      />
    );
  }

  return (`;

content = content.replace(/  return \(\n    <div className="max-w-md mx-auto/, penaltyModal + '\n    <div className="max-w-md mx-auto');

// remove verification modal & cheat warning jsx
content = content.replace(/        \{verificationData && \([\s\S]*?\}\n\s*\}\n/m, "");

fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', content);
