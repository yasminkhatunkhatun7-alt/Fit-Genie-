import sys

with open('src/components/CustomChallengeDetailScreen.tsx') as f:
    lines = f.readlines()

stack = []
for i, line in enumerate(lines):
    for j, c in enumerate(line):
        if c == '(':
            stack.append((i+1, j+1))
        elif c == ')':
            if stack:
                stack.pop()
            else:
                print(f"Extra ) at {i+1}:{j+1}")

for i, j in stack:
    print(f"Unclosed ( at {i}:{j}")
