const fs = require('fs');
let code = fs.readFileSync('src/components/WorkoutProgressChart.tsx', 'utf-8');
code = code.replace(/\\\`/g, '`').replace(/\\\$/g, '$');
fs.writeFileSync('src/components/WorkoutProgressChart.tsx', code);
console.log("Fixed");
