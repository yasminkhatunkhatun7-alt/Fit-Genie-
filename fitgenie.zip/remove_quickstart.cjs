const fs = require('fs');

let content = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

const regex = /\{\/\* RECOMMENDED WORKOUT \*\/\}\s*<motion\.div\s*className="glass-card rounded-3xl p-5 relative overflow-hidden group cursor-pointer"\s*initial=\{\{ opacity: 0, y: 20 \}\}.*?onClick=\{.*?onNavigateToGenerator.*?\s*>\s*<div className="absolute inset-0 bg-gradient-to-r from-\[#14F1E1\]\/10 to-\[#4DA8FF\]\/10 opacity-0 group-hover:opacity-100 transition-opacity" \/>\s*<div className="flex justify-between items-center relative z-10">\s*<div>\s*<span className="text-\[#14F1E1\] text-\[10px\] font-bold uppercase tracking-widest mb-1 block">Quick Start<\/span>\s*<h3 className="text-white text-lg font-bold tracking-wide">Generate Custom Routine<\/h3>\s*<p className="text-\[#9CA3AF\] text-xs mt-1">AI matched to your \{profile\?\.mainGoal \|\| "fitness"\} goal<\/p>\s*<\/div>\s*<div className="w-10 h-10 rounded-full bg-\[#14F1E1\] text-\[#050B1A\] flex items-center justify-center group-hover:scale-110 transition-transform shadow-\[0_0_15px_#14F1E1\]">\s*<ChevronRight className="w-6 h-6 stroke-\[3\]" \/>\s*<\/div>\s*<\/div>\s*<\/motion\.div>/ms;

if(regex.test(content)) {
    content = content.replace(regex, '');
    fs.writeFileSync('src/components/HomeDashboard.tsx', content);
    console.log("Removed Quick Start card.");
} else {
    console.log("Could not find the Quick Start card.");
}
