const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace('profile: 18,', 'profile: 18, contact: 19, terms: 20,');

fs.writeFileSync('src/App.tsx', content);
