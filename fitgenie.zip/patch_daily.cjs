const fs = require('fs');

let code = fs.readFileSync('src/components/DailyChallengeDetailScreen.tsx', 'utf8');

code = code.replace(/onComplete: \(xpToAward: number\) => void;/, "onComplete: (xpToAward: number) => Promise<boolean> | boolean | void;");

code = code.replace(/  const handleClaimXP = \(\) => \{[\s\S]*?setShowCompletion\(true\);\n  \};/, `  const handleClaimXP = async () => {
    if (!honorChecked) return;
    playSound("success");
    if (!hasClaimedToday) {
      const result = await onComplete(challenge.xp);
      if (result === false) return; // Validation failed
      localStorage.setItem(claimedKey, todayStr);
      setHasClaimedToday(true);
      setJustClaimed(true);
    }
    setShowHonorValidation(false);
    setShowCompletion(true);
  };`);

fs.writeFileSync('src/components/DailyChallengeDetailScreen.tsx', code);
