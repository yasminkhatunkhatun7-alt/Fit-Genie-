const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

code = code.replace(
  'const [searchResult, setSearchResult] = useState<LeaderboardEntry | null>(null);',
  `const [searchResult, setSearchResult] = useState<LeaderboardEntry & { fighterId?: string } | null>(null);
  const [friendRequests, setFriendRequests] = useState<any[]>([]);
  const [friendStatus, setFriendStatus] = useState<"none" | "pending" | "friends">("none");`
);

fs.writeFileSync('src/components/WorldChat.tsx', code);
