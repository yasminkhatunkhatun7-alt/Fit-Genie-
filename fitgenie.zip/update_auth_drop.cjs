const fs = require('fs');
let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

const regex = /if \(integrityGain > 0\) \{\n         window\.dispatchEvent\(new CustomEvent\('trust_increase', \{ detail: \{ gain: integrityGain \} \}\)\);\n      \}/;

const replacement = `if (integrityGain > 0) {
         window.dispatchEvent(new CustomEvent('trust_increase', { detail: { gain: integrityGain } }));
      }
      
      if (baseIntegrityScore >= 50 && newIntegrityScore < 50) {
         window.dispatchEvent(new CustomEvent('trust_warning', { detail: { score: newIntegrityScore } }));
      }`;

if (content.includes(replacement)) {
    console.log("Already updated.");
} else {
    content = content.replace(regex, replacement);
    fs.writeFileSync('src/context/AuthContext.tsx', content);
    console.log("Updated.");
}
