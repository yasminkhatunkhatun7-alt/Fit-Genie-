const fs = require('fs');

let yh = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');

const tabRegex = /          \{\/\* -----------------------------------------\n             TAB 4: SLEEP SYSTEM[\s\S]*?          \{\/\* -----------------------------------------\n             TAB 7: SOCIAL CHALLENGES/g;
yh = yh.replace(tabRegex, `          {/* -----------------------------------------
             TAB 7: SOCIAL CHALLENGES`);

fs.writeFileSync('src/components/YoddhaHub.tsx', yh);
