import fs from "fs";

const videos = [
  "62sm1cJzivQ", "vCWcYF5PiQg", "0kU-IJQs6Bk", "bmqSJSB0C8E", "ewSCQSE-kEM",
  "IGssbfjjc1Q", "Ou4mFyMmwE4", "tTIV6qVB59Y", "tIyMLHcJ_xQ", "RRQQgW9t--k",
  "fF0IgM71dUM", "B2UXMlFw-Mk", "XglujyVx-SI", "Vorr1jRrb9w", "ruu8XBkLVhg",
  "y-bxF4PCOJo", "MTJxrViWPj4", "Q2ClBRiRzJo", "-9rMGYdJwPE", "TCtuwk35bmk"
];

async function main() {
  const results = [];
  for (const id of videos) {
    try {
      const res = await fetch(`https://www.youtube.com/oembed?url=https://youtube.com/shorts/${id}&format=json`);
      if (res.ok) {
        const json = await res.json();
        console.log(`ID: ${id} -> Title: ${json.title}`);
        results.push({ id, ...json });
      } else {
        console.log(`ID: ${id} -> Failed: ${res.status}`);
      }
    } catch (err: any) {
      console.log(`ID: ${id} -> Error: ${err.message}`);
    }
  }
}

main();
