const fs = require('fs');
let code = fs.readFileSync('src/components/ExercisesLibrary.tsx', 'utf-8');

code = code.replace(
  'className="bg-[#050B1A] border border-neutral-800 rounded-2xl p-4 flex items-center gap-4 hover:border-[#4DA8FF]/30 transition-colors"',
  'className="bg-[#050B1A] border border-neutral-800 rounded-2xl p-4 flex items-center gap-4 transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] hover:border-[#4DA8FF]/40 hover:bg-[#050B1A]/80 cursor-pointer shadow-lg hover:shadow-xl hover:shadow-[#4DA8FF]/10"'
);

fs.writeFileSync('src/components/ExercisesLibrary.tsx', code);
