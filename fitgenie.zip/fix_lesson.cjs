const fs = require('fs');
let code = fs.readFileSync('src/components/ExercisesLibrary.tsx', 'utf-8');

code = code.replace(
  'className={`border transition-all duration-200 rounded-2xl overflow-hidden cursor-pointer select-none group ${',
  'className={`border transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98] rounded-2xl overflow-hidden cursor-pointer select-none group shadow-lg hover:shadow-xl ${'
);

fs.writeFileSync('src/components/ExercisesLibrary.tsx', code);
