import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import rateLimit from "express-rate-limit";
import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore, doc, getDoc, setDoc, updateDoc, increment } from "firebase/firestore";
import firebaseConfig from "./firebase-applet-config.json";

// ============================================================================
// SERVER-SIDE FIRESTORE INITIALIZATION
// ============================================================================
// Uses configured Firestore Database ID for server-side score validation and
// atomic stat increments.
const firebaseApp = getApps().length ? getApp() : initializeApp(firebaseConfig);
const db = firebaseConfig.firestoreDatabaseId 
  ? getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId)
  : getFirestore(firebaseApp);

// ============================================================================
// BIOMECHANICAL MINIMUM REPETITION TIMES (Anti-Cheat Security Dictionary)
// Represents the physical human limit for completing 1 full rep with proper ROM
// ============================================================================
export const EXERCISE_MIN_TIMES: Record<string, number> = {
  'Pushups': 1.0,         // Minimum 1.0s per complete chest-to-deck pushup
  'Squats': 0.8,          // Minimum 0.8s per parallel squat
  'Crunches': 0.7,        // Minimum 0.7s per crunch
  'Burpees': 2.0,         // Minimum 2.0s per full burpee
  'Plank': 1.0,           // 1 second per second held
  'Mountain Climbers': 0.5,
  'Jumping Jacks': 0.5,
  'Calf Raises': 0.8,
  'Dips': 1.0,
  'Pike Pushups': 1.2,
  'Pullups': 1.5,
  'Situps': 0.8,
  'Lunges': 1.0,
  'Russian Twists': 0.5,
  'High Knees': 0.4
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Trust Cloud Run / reverse proxy headers so req.ip resolves accurately
  app.set("trust proxy", 1);

  app.use(express.json({ limit: "50mb" }));

  // ==========================================================================
  // A. API ABUSE & BOT PROTECTION: RATE LIMITING
  // Protects Gemini API tokens and backend endpoints from bot scraping and DDoS.
  // Maximum of 20 requests per 15 minutes per IP address.
  // ==========================================================================
  const geminiRateLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15-minute window
    max: 20,                  // 20 requests allowed per window per IP
    standardHeaders: true,    // Return rate limit info in the `RateLimit-*` headers
    legacyHeaders: false,     // Disable the `X-RateLimit-*` headers
    validate: false,          // Disable strict X-Forwarded-For / Forwarded header ValidationError in Cloud Run proxy
    statusCode: 429,
    handler: (req, res) => {
      console.warn(`[RateLimit 429] IP ${req.ip} exceeded Gemini quota limit.`);
      res.status(429).json({
        status: 429,
        error: "Rate limit exceeded: Too many AI requests. Please wait 15 minutes before requesting more workout insights or AI missions.",
        retryAfter: "15 minutes"
      });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // ==========================================================================
  // GEMINI-POWERED ENDPOINTS (Protected with Rate Limiter)
  // ==========================================================================
  app.post("/api/fitness-insight", geminiRateLimiter, async (req, res) => {
    try {
      const insights = [
        "Consistency is the catalyst for superhuman adaptation. Keep moving forward.",
        "Your muscles adapt to the intensity you demand from them. Demand greatness.",
        "Discipline beats motivation every single day. One rep at a time.",
        "Form precedes volume. Own every millimeter of the movement.",
        "Don't stop when fatigue sets in. Stop when the set is complete."
      ];
      const randomInsight = insights[Math.floor(Math.random() * insights.length)];
      res.json({ insight: randomInsight });
    } catch (error) {
      res.status(500).json({ error: "Failed to generate fitness insight." });
    }
  });

  app.post("/api/missions/generate", geminiRateLimiter, async (req, res) => {
    try {
      res.json({
        easy: { id: 'mission_e1', title: 'Execute 40 Strict Pushups', xp: 50, type: 'REP' },
        medium: { id: 'mission_m1', title: 'Complete 75 Deep Squats', xp: 120, type: 'REP' },
        hard: { id: 'mission_h1', title: 'Survive 1-Minute Ghost Test', xp: 250, type: 'TEST' }
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to generate missions." });
    }
  });

  // ==========================================================================
  // C. SERVER-SIDE ANTI-CHEAT: SCORE & LEADERBOARD SUBMISSION
  // Validates exercise speed on the server against biomechanical thresholds.
  // Updates user stats and leaderboard documents atomically using increment().
  // ==========================================================================
  app.post("/api/submit-score", async (req, res) => {
    try {
      const { userId, exerciseName, reps, timeElapsed, mode } = req.body;

      if (!userId || !exerciseName || reps === undefined || timeElapsed === undefined) {
        return res.status(400).json({ 
          error: "Missing required payload parameters: userId, exerciseName, reps, timeElapsed" 
        });
      }

      const repsNum = Number(reps);
      const timeElapsedSecs = Number(timeElapsed);

      if (isNaN(repsNum) || isNaN(timeElapsedSecs) || repsNum < 0 || timeElapsedSecs < 0) {
        return res.status(400).json({ error: "Invalid numeric parameters for reps or timeElapsed." });
      }

      // Zero reps does not require anti-cheat rejection, but nothing to record
      if (repsNum === 0) {
        return res.json({ success: true, reps: 0, message: "No reps submitted." });
      }

      // Anti-cheat verification formula:
      // Minimum required time = Reps * Minimum Time Per Rep
      const minTimePerRep = EXERCISE_MIN_TIMES[exerciseName] || 0.5;
      const expectedMinTime = repsNum * minTimePerRep;

      if (timeElapsedSecs < expectedMinTime) {
        console.warn(
          `[Anti-Cheat Violation] User: ${userId} | Exercise: ${exerciseName} | Reps: ${repsNum} | Time: ${timeElapsedSecs}s | MinRequired: ${expectedMinTime}s`
        );
        return res.status(403).json({
          error: "Cheat detected: Rep completion speed exceeds human biomechanical limits.",
          details: {
            exerciseName,
            reps: repsNum,
            timeElapsed: timeElapsedSecs,
            minimumRequiredSeconds: expectedMinTime,
            allowedMinTimePerRep: minTimePerRep
          }
        });
      }

      // Biomechanical check passed! Proceed with atomic database updates
      const userDocRef = doc(db, "users", userId);
      const userDocSnap = await getDoc(userDocRef);
      const userData = userDocSnap.exists() ? userDocSnap.data() : {};
      const currentStats = userData.stats || {};

      const isSquat = exerciseName === "Squats";
      const isPushup = exerciseName === "Pushups";

      const updates: Record<string, any> = {};

      if (isSquat) {
        // Atomic increment of all-time squats
        updates.totalSquats = increment(repsNum);
        updates["stats.squats_all"] = increment(repsNum);

        // If 1-minute test, track best score
        if (mode === "test") {
          const currentBest1Min = userData.bestSquat1Min || 0;
          if (repsNum > currentBest1Min) {
            updates.bestSquat1Min = repsNum;
            updates["stats.squats_1min"] = repsNum;
          }
        }
      } else if (isPushup) {
        // Atomic increment of all-time pushups
        updates.totalPushups = increment(repsNum);
        updates["stats.pushups_all"] = increment(repsNum);

        // If 1-minute test, track best score
        if (mode === "test") {
          const currentBest1Min = userData.bestPushup1Min || 0;
          if (repsNum > currentBest1Min) {
            updates.bestPushup1Min = repsNum;
            updates["stats.pushups_1min"] = repsNum;
          }
        }
      }

      // Update the user's verified stats in Firestore
      if (userDocSnap.exists()) {
        await updateDoc(userDocRef, updates);
      } else {
        await setDoc(userDocRef, {
          userId,
          ...updates,
          lastVerifiedWorkout: new Date().toISOString()
        }, { merge: true });
      }

      // Mirror to authoritative server-only leaderboard document
      const leaderboardKey = isSquat 
        ? (mode === "test" ? "squats_1min" : "squats_all")
        : (mode === "test" ? "pushups_1min" : "pushups_all");
      
      const leaderboardDocRef = doc(db, "leaderboards", leaderboardKey);
      await setDoc(leaderboardDocRef, {
        updatedAt: new Date().toISOString(),
        [`entries.${userId}`]: {
          userId,
          userName: userData.userName || userData.username || "Athlete",
          score: repsNum,
          verifiedAt: new Date().toISOString()
        }
      }, { merge: true }).catch(err => {
        console.warn("[Leaderboard Write Note] Leaderboard doc update:", err.message);
      });

      console.log(`[Score Verified] User: ${userId} | ${exerciseName}: ${repsNum} reps in ${timeElapsedSecs}s.`);

      return res.json({
        success: true,
        verified: true,
        exerciseName,
        reps: repsNum,
        timeElapsed: timeElapsedSecs,
        message: "Workout score verified against anti-cheat models and updated safely in database."
      });

    } catch (error: any) {
      console.error("[Anti-Cheat /submit-score Error]:", error);
      return res.status(500).json({ error: "Internal server error validating and recording score." });
    }
  });

  // Vite middleware for development or static serving for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Fit Genie server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
