const fs = require('fs');
let code = fs.readFileSync('src/components/ExercisesLibrary.tsx', 'utf-8');

code = code.replace(
  'className={`p-4 rounded-xl border flex items-center justify-between transition-all ${achieved ? "bg-emerald-500/10 border-emerald-500/30" : "bg-[#141414] border-[#262626]"}`}',
  'className={`p-4 rounded-xl border flex items-center justify-between transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] ${achieved ? "bg-emerald-500/10 border-emerald-500/30 cursor-default" : "bg-[#141414] border-[#262626] hover:border-brand-accent/40 cursor-pointer shadow-lg hover:shadow-brand-accent/10 hover:shadow-xl"}`}'
);

fs.writeFileSync('src/components/ExercisesLibrary.tsx', code);
