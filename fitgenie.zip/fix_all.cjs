const fs = require('fs');

function fixNutrition() {
  const file = 'src/components/NutritionLog.tsx';
  let code = fs.readFileSync(file, 'utf8');

  // Add missing lucide imports
  if (!code.includes('Target')) {
    code = code.replace(/import \{ Check, TrendingUp, RotateCcw \} from "lucide-react";/,
      'import { Check, TrendingUp, RotateCcw, Target, X, Settings, Apple, Flame, Droplet, Plus } from "lucide-react";');
  }

  // Restore variables if they are missing
  if (!code.includes('const [customProteinInput')) {
    const varsToAdd = `
  const [customProteinInput, setCustomProteinInput] = useState("");
  const quickProteinMeals = [
    { name: "Egg Whites", protein: 25, icon: "🥚" },
    { name: "Chicken Breast", protein: 30, icon: "🍗" },
    { name: "Protein Shake", protein: 24, icon: "🥤" },
    { name: "Tofu Block", protein: 20, icon: "🧊" }
  ];
`;
    code = code.replace(/const \[confirmResetState, setConfirmResetState\] = useState<any>\(null\);/, 
      'const [confirmResetState, setConfirmResetState] = useState<any>(null);\n' + varsToAdd);
  }
  
  // Create dummy NutritionGoalModal if it doesn't exist
  if (!code.includes('function NutritionGoalModal')) {
    code += `\nfunction NutritionGoalModal({ goals, onSaveGoals, onClose }: { goals: any, onSaveGoals: any, onClose: any }) { return null; }\n`;
  }
  
  fs.writeFileSync(file, code);
}

function fixSidebar() {
  const file = 'src/components/SidebarSections.tsx';
  let code = fs.readFileSync(file, 'utf8');

  if (!code.includes('Activity')) {
    code = code.replace(/import \{ Copy, Check, Star, Shield, HelpCircle/,
      'import { Copy, Check, Star, Shield, HelpCircle, Activity, TrendingDown, TrendingUp, Calculator, Target, Plus, Bell');
  }
  
  fs.writeFileSync(file, code);
}

function fixMartialArts() {
  const file = 'src/components/MartialArts.tsx';
  let code = fs.readFileSync(file, 'utf8');
  code = code.replace(/disabled=\{isSavingAdmin\}/g, 'disabled={false}');
  fs.writeFileSync(file, code);
}

try {
  fixNutrition();
  fixSidebar();
  fixMartialArts();
  console.log("Fixed all");
} catch(e) {
  console.error(e);
}
