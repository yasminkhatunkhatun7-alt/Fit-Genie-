const fs = require('fs');

let code = fs.readFileSync('server.ts', 'utf-8');

const oldRules = `Rules:
- CRITICAL: Detect the exact location of the human face in the image BEFORE placing any markers.
- DO NOT under any circumstances place markers on the chest, torso, neck, clothing, background, or objects. The markers must be STRICTLY on the face.
- If the image does not contain a clear, well-lit human face, return valid: false.
- Coordinate system: (0,0) is the top-left corner, and (100,100) is the bottom-right corner of the image. 
- x is the horizontal axis (0=left, 100=right). y is the vertical axis (0=top, 100=bottom).
- 'eyes' marker: Place exactly between the two eyes. The 'y' value MUST be smaller (higher up) than the cheekbones.
- 'cheekbones' marker: Place exactly on the cheekbones, specifically below the eyes and above the jaw. NEVER place this on the chest.
- 'jawline' marker: Place directly on the contour of the lower jaw. NEVER place this on the collarbone or shoulders.
- 'chin' marker: Place at the very bottom tip of the chin. The 'y' value MUST be the largest (lowest down) of all markers, but still strictly on the face, NOT on the neck or chest.
- Coordinates (x,y) must be accurate percentages mapping precisely to the facial features.
- Keep results realistic. Never give 10/10 scores. Never give perfect symmetry.
- Ensure the y-coordinates are logically ordered from top to bottom: eyes < cheekbones < jawline <= chin. If they are spread too far apart covering the whole image, it means you falsely detected the body instead of just the face.`;

const newRules = `Rules:
- CRITICAL: First, identify the bounding box of the human face (top, bottom, left, right in percentages).
- ALL landmark markers (eyes, cheekbones, jawline, chin) MUST be placed strictly inside this face bounding box. 
- DO NOT under any circumstances place markers on the chest, torso, neck, clothing, background, or objects. The markers must be STRICTLY on the face.
- If the image does not contain a clear, well-lit human face, return valid: false.
- Coordinate system: (0,0) is the top-left corner, and (100,100) is the bottom-right corner of the image. 
- x is the horizontal axis (0=left, 100=right). y is the vertical axis (0=top, 100=bottom).
- 'eyes' marker: Place exactly between the two eyes. The 'y' value MUST be smaller (higher up) than the cheekbones.
- 'cheekbones' marker: Place exactly on the cheekbones, specifically below the eyes and above the jaw. NEVER place this on the chest.
- 'jawline' marker: Place directly on the contour of the lower jaw. NEVER place this on the collarbone or shoulders.
- 'chin' marker: Place at the very bottom tip of the chin. The 'y' value MUST be the largest (lowest down) of all markers, but still strictly on the face, NOT on the neck or chest.
- Coordinates (x,y) must be accurate percentages mapping precisely to the facial features.
- Keep results realistic. Never give 10/10 scores. Never give perfect symmetry.
- Ensure the y-coordinates are logically ordered from top to bottom: eyes < cheekbones < jawline <= chin. If they are spread too far apart covering the whole image, it means you falsely detected the body instead of just the face.`;

code = code.replace(oldRules, newRules);

const oldJsonExample = `Return JSON format exactly like this (with valid: true):
{
  "valid": true,
  "scores": {
    "symmetry": 7.5,
    "hunterEyes": 6.0,
    "jawline": 8.0,
    "cheekbones": 7.0,
    "faceFat": 6.5
  },
  "overallScore": 72,
  "recommendationMessage": "Boss 😎\\n\\nOverall Mog Score:\\n71/100\\n\\nStrongest:\\nEyes 👀\\n\\nWeakest:\\nJawline 🗿\\n\\nToday's Focus:\\nJawline Builder\\n\\nEstimated Improvement:\\n60-90 Days 🚀",
  "landmarks": {
    "eyes": { "x": 45, "y": 45, "confidence": 90 },
    "cheekbones": { "x": 75, "y": 55, "confidence": 85 },
    "jawline": { "x": 80, "y": 75, "confidence": 95 },
    "chin": { "x": 50, "y": 85, "confidence": 88 }
  }
}`;

const newJsonExample = `Return JSON format exactly like this (with valid: true):
{
  "valid": true,
  "faceBoundingBox": { "top": 20, "bottom": 80, "left": 30, "right": 70 },
  "scores": {
    "symmetry": 7.5,
    "hunterEyes": 6.0,
    "jawline": 8.0,
    "cheekbones": 7.0,
    "faceFat": 6.5
  },
  "overallScore": 72,
  "recommendationMessage": "Boss 😎\\n\\nOverall Mog Score:\\n71/100\\n\\nStrongest:\\nEyes 👀\\n\\nWeakest:\\nJawline 🗿\\n\\nToday's Focus:\\nJawline Builder\\n\\nEstimated Improvement:\\n60-90 Days 🚀",
  "landmarks": {
    "eyes": { "x": 45, "y": 45, "confidence": 90 },
    "cheekbones": { "x": 75, "y": 55, "confidence": 85 },
    "jawline": { "x": 80, "y": 75, "confidence": 95 },
    "chin": { "x": 50, "y": 85, "confidence": 88 }
  }
}`;

code = code.replace(oldJsonExample, newJsonExample);

fs.writeFileSync('server.ts', code);
console.log('done');
