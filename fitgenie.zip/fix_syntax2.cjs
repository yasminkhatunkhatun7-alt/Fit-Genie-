const fs = require('fs');
let c = fs.readFileSync('src/components/CustomChallengeDetailScreen.tsx', 'utf8');
c = c.replace(/if \(\) {[\s]*if \(suspiciousPhase !== 'none'\) {/g, "if (suspiciousPhase !== 'none') {");
fs.writeFileSync('src/components/CustomChallengeDetailScreen.tsx', c);

let w = fs.readFileSync('src/components/WeeklyChallengeScreen.tsx', 'utf8');
w = w.replace(/if \(\) {[\s]*if \(suspiciousPhase !== 'none'\) {/g, "if (suspiciousPhase !== 'none') {");
fs.writeFileSync('src/components/WeeklyChallengeScreen.tsx', w);
