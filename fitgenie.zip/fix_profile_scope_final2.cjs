const fs = require('fs');

let code = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

const oldDecl = `}: HomeDashboardProps) {
  const { triggerEvent } = useGuardianContext();
  
  useEffect(() => {`;

const newDecl = `}: HomeDashboardProps) {
  const { triggerEvent } = useGuardianContext();
  const { profile, signOutUser } = useAuth();
  
  useEffect(() => {`;

code = code.replace(oldDecl, newDecl);

fs.writeFileSync('src/components/HomeDashboard.tsx', code);
