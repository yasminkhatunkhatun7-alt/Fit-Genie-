const fs = require('fs');

let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

const logicRegex = /if \(baseIntegrityScore < 50 \|\| isRecoveringFromZero\) \{[\s\S]*?\} else \{/m;

const newLogic = `if (baseIntegrityScore < 50 || isRecoveringFromZero) {
         if (isCheating) {
             newRecoveryWorkouts = 0;
             if (newIntegrityScore === 0) isRecoveringFromZero = true;
         } else if (isHonestWorkout) {
             newRecoveryWorkouts += 1;
             
             if (isRecoveringFromZero) {
                 if (newRecoveryWorkouts === 3) newIntegrityScore = 15;
                 else if (newRecoveryWorkouts === 7) newIntegrityScore = 30;
                 else if (newRecoveryWorkouts === 14) newIntegrityScore = 50;
                 else if (newRecoveryWorkouts > 14) {
                     isRecoveringFromZero = false;
                     newRecoveryWorkouts = 0;
                 } else {
                     newIntegrityScore = baseIntegrityScore;
                 }
             } else {
                 if (newRecoveryWorkouts === 3) newIntegrityScore += 10;
                 else if (newRecoveryWorkouts === 7) newIntegrityScore += 20;
                 else if (newRecoveryWorkouts === 14) newIntegrityScore += 30;
             }
         }
      } else {`;

content = content.replace(logicRegex, newLogic);
fs.writeFileSync('src/context/AuthContext.tsx', content);
