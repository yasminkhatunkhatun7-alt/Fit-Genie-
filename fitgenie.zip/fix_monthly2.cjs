const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

const insertion1 = `  const [lastActionTime, setLastActionTime] = useState(Date.now());`;
const replacement1 = `  const [lastActionTime, setLastActionTime] = useState(Date.now());
  const [verificationData, setVerificationData] = useState<{ exercise: string, amount: number, isFlagged: boolean } | null>(null);
  const [verifyDuration, setVerifyDuration] = useState("");
  const [verifyReps, setVerifyReps] = useState("");
  const [verifyError, setVerifyError] = useState("");`;

content = content.replace(insertion1, replacement1);

const insertion2 = `  const handleAddReps = (exercise: string, amount: number) => {
    if (isMonthComplete || monthState.validationFailed) return;`;

const replacement2 = `  const handleAddReps = (exercise: string, amount: number, bypassVerification: boolean = false) => {
    if (isMonthComplete) return;

    if (monthState.validationFailed && !bypassVerification) {
        if (profile?.integrityScore && profile.integrityScore >= 50) {
            setVerificationData({ exercise, amount, isFlagged: true });
        } else {
            setShowCheatWarning(true);
        }
        return;
    }`;

content = content.replace(insertion2, replacement2);

const regexSuspicious = /if \(isSuspicious\) \{\s*setShowCheatWarning\(true\);\s*setMonthState\(prev => \{\s*const newFlags = \(prev\.suspiciousFlags \|\| 0\) \+ 1;\s*const updated = \{\s*\.\.\.prev,\s*suspiciousFlags: newFlags,\s*validationFailed: prev\.validationFailed \|\| newFlags >= 2\s*\};\s*localStorage\.setItem\(storageKey, JSON\.stringify\(updated\)\);\s*return updated;\s*\}\);\s*return;\s*\}/m;

const replacementSuspicious = `if (isSuspicious && !bypassVerification) {
      setMonthState(prev => {
        const newFlags = (prev.suspiciousFlags || 0) + 1;
        const updated = {
          ...prev,
          suspiciousFlags: newFlags,
          validationFailed: prev.validationFailed || newFlags >= 3
        };
        localStorage.setItem(storageKey, JSON.stringify(updated));
        return updated;
      });
      setVerificationData({ exercise, amount, isFlagged: false });
      return;
    }`;

content = content.replace(regexSuspicious, replacementSuspicious);

fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', content);
