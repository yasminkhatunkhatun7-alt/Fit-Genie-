const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

// Update Interface
code = code.replace(`interface LeaderboardEntry {
  userId: string;
  userName: string;
  xp: number;
  avatarBg: string;
  lastUpdated: number;
}`, `interface LeaderboardEntry {
  userId: string;
  userName: string;
  xp?: number;
  totalSquats?: number;
  bestSquat1Min?: number;
  totalPushups?: number;
  bestPushup1Min?: number;
  avatarBg: string;
  lastUpdated: number;
}`);

// Add new state variables
const stateMatch = `  const [leaderboardLoading, setLeaderboardLoading] = useState(true);`;
const stateNew = `  const [leaderboardLoading, setLeaderboardLoading] = useState(true);
  const [leaderboardType, setLeaderboardType] = useState<"xp" | "squats_all" | "squats_1min" | "pushups_all" | "pushups_1min">("xp");`;
code = code.replace(stateMatch, stateNew);

// Update fetchLeaderboard logic
const fetchMatch = `const fetchLeaderboard = async () => {
    setLeaderboardLoading(true);
    try {
      const q = query(collection(db, "users"), orderBy("xp", "desc"), limit(50));
      const querySnapshot = await getDocs(q);
      const fetched: LeaderboardEntry[] = [];
      querySnapshot.forEach((doc) => {
        const data = doc.data() as LeaderboardEntry;
        if (!blockedUsers.includes(data.userId || doc.id)) {
          fetched.push({
            userId: data.userId || doc.id,
            userName: data.userName || "Anonymous", // fallback
            xp: data.xp || 0,
            avatarBg: data.avatarBg || "bg-neutral-800",
            lastUpdated: data.lastUpdated || Date.now()
          });
        }
      });
      setLeaderboard(fetched);
    } catch (e) {
      console.error("Failed to fetch leaderboard", e);
    } finally {
      setLeaderboardLoading(false);
    }
  };`;

const fetchNew = `const fetchLeaderboard = async (overrideType?: "xp" | "squats_all" | "squats_1min" | "pushups_all" | "pushups_1min") => {
    const currentType = overrideType || leaderboardType;
    setLeaderboardLoading(true);
    try {
      let orderField = "xp";
      if (currentType === "squats_all") orderField = "totalSquats";
      if (currentType === "squats_1min") orderField = "bestSquat1Min";
      if (currentType === "pushups_all") orderField = "totalPushups";
      if (currentType === "pushups_1min") orderField = "bestPushup1Min";
      
      const q = query(collection(db, "users"), orderBy(orderField, "desc"), limit(50));
      const querySnapshot = await getDocs(q);
      const fetched: LeaderboardEntry[] = [];
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        if (!blockedUsers.includes(data.userId || doc.id)) {
          // ensure the user actually has a score for this field
          if ((data[orderField] || 0) > 0 || orderField === "xp") {
             fetched.push({
               userId: data.userId || doc.id,
               userName: data.userName || data.username || "Anonymous", // fallback
               xp: data.xp || 0,
               totalSquats: data.totalSquats || 0,
               bestSquat1Min: data.bestSquat1Min || 0,
               totalPushups: data.totalPushups || 0,
               bestPushup1Min: data.bestPushup1Min || 0,
               avatarBg: data.avatarBg || "bg-neutral-800",
               lastUpdated: data.lastUpdated || Date.now()
             });
          }
        }
      });
      setLeaderboard(fetched);
    } catch (e) {
      console.error("Failed to fetch leaderboard", e);
    } finally {
      setLeaderboardLoading(false);
    }
  };`;
code = code.replace(fetchMatch, fetchNew);

// UI for activeTab === "leaderboard"
const leaderboardUIMatch = `      {activeTab === "leaderboard" && (
        <div className="flex-1 overflow-y-auto mt-4 space-y-3 pr-1 pb-4 flex flex-col custom-scrollbar">
          <div className="bg-[#B66DFF]/10 border border-[#B66DFF]/30 rounded-xl p-3 flex justify-between items-center shrink-0 mb-2">
            <div className="flex gap-3 items-center">
               <Award className="w-6 h-6 text-[#B66DFF] shrink-0" />
               <p className="text-[9px] uppercase tracking-widest font-black text-[#B66DFF] leading-relaxed">
                 Global Athlete Leaderboard. Ranked by total XP.
               </p>
            </div>
            <button onClick={fetchLeaderboard} className="p-2 bg-neutral-800 rounded-lg text-[#B66DFF] hover:bg-neutral-700">
               <RefreshCw className="w-4 h-4" />
            </button>
          </div>
          
          {leaderboardLoading ? (`;

const leaderboardUINew = `      {activeTab === "leaderboard" && (
        <div className="flex-1 overflow-y-auto mt-4 space-y-3 pr-1 pb-4 flex flex-col custom-scrollbar">
          
          <div className="flex flex-col gap-2 shrink-0 mb-2">
            <div className="flex bg-brand-surface rounded-xl p-1 border border-brand-border">
              <button onClick={() => { setLeaderboardType("xp"); fetchLeaderboard("xp"); }} className={\`flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg \${leaderboardType === "xp" ? "bg-[#B66DFF] text-white" : "text-neutral-500 hover:text-white"}\`}>XP</button>
              <button onClick={() => { setLeaderboardType("squats_all"); fetchLeaderboard("squats_all"); }} className={\`flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg \${leaderboardType.startsWith("squats") ? "bg-[#14F1E1] text-[#050B1A]" : "text-neutral-500 hover:text-white"}\`}>Squats</button>
              <button onClick={() => { setLeaderboardType("pushups_all"); fetchLeaderboard("pushups_all"); }} className={\`flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg \${leaderboardType.startsWith("pushups") ? "bg-[#FF5A5F] text-white" : "text-neutral-500 hover:text-white"}\`}>Pushups</button>
            </div>
            
            {leaderboardType.startsWith("squats") && (
               <div className="flex bg-[#14F1E1]/10 rounded-xl p-1 border border-[#14F1E1]/30">
                  <button onClick={() => { setLeaderboardType("squats_all"); fetchLeaderboard("squats_all"); }} className={\`flex-1 py-1.5 text-[9px] font-bold uppercase tracking-widest rounded-lg \${leaderboardType === "squats_all" ? "bg-[#14F1E1] text-[#050B1A]" : "text-[#14F1E1]/70"}\`}>All-Time Highest</button>
                  <button onClick={() => { setLeaderboardType("squats_1min"); fetchLeaderboard("squats_1min"); }} className={\`flex-1 py-1.5 text-[9px] font-bold uppercase tracking-widest rounded-lg \${leaderboardType === "squats_1min" ? "bg-[#14F1E1] text-[#050B1A]" : "text-[#14F1E1]/70"}\`}>1-Min Best</button>
               </div>
            )}
            {leaderboardType.startsWith("pushups") && (
               <div className="flex bg-[#FF5A5F]/10 rounded-xl p-1 border border-[#FF5A5F]/30">
                  <button onClick={() => { setLeaderboardType("pushups_all"); fetchLeaderboard("pushups_all"); }} className={\`flex-1 py-1.5 text-[9px] font-bold uppercase tracking-widest rounded-lg \${leaderboardType === "pushups_all" ? "bg-[#FF5A5F] text-white" : "text-[#FF5A5F]/70"}\`}>All-Time Highest</button>
                  <button onClick={() => { setLeaderboardType("pushups_1min"); fetchLeaderboard("pushups_1min"); }} className={\`flex-1 py-1.5 text-[9px] font-bold uppercase tracking-widest rounded-lg \${leaderboardType === "pushups_1min" ? "bg-[#FF5A5F] text-white" : "text-[#FF5A5F]/70"}\`}>1-Min Best</button>
               </div>
            )}
          </div>
          
          <div className="bg-[#B66DFF]/10 border border-[#B66DFF]/30 rounded-xl p-3 flex justify-between items-center shrink-0 mb-2">
            <div className="flex gap-3 items-center">
               <Award className="w-6 h-6 text-[#B66DFF] shrink-0" />
               <p className="text-[9px] uppercase tracking-widest font-black text-[#B66DFF] leading-relaxed">
                 {leaderboardType === "xp" ? "Global Athlete Leaderboard. Ranked by total XP." : 
                  leaderboardType === "squats_all" ? "Most lifetime Squats completed." :
                  leaderboardType === "squats_1min" ? "Highest Squat score in 1 Minute Test." :
                  leaderboardType === "pushups_all" ? "Most lifetime Pushups completed." :
                  "Highest Pushup score in 1 Minute Test."}
               </p>
            </div>
            <button onClick={() => fetchLeaderboard()} className="p-2 bg-neutral-800 rounded-lg text-[#B66DFF] hover:bg-neutral-700">
               <RefreshCw className="w-4 h-4" />
            </button>
          </div>
          
          {leaderboardLoading ? (`;
code = code.replace(leaderboardUIMatch, leaderboardUINew);

// Update rendering of XP in leaderboard
const xpMatch = `<p className="text-[10px] uppercase tracking-widest font-bold text-[#B66DFF] mt-0.5">
                        {athlete.xp.toLocaleString()} XP
                      </p>`;
const xpNew = `<p className="text-[10px] uppercase tracking-widest font-bold text-[#B66DFF] mt-0.5">
                        {leaderboardType === "xp" ? \`\${(athlete.xp || 0).toLocaleString()} XP\` :
                         leaderboardType === "squats_all" ? \`\${(athlete.totalSquats || 0).toLocaleString()} Squats\` :
                         leaderboardType === "squats_1min" ? \`\${(athlete.bestSquat1Min || 0).toLocaleString()} Reps (1 Min)\` :
                         leaderboardType === "pushups_all" ? \`\${(athlete.totalPushups || 0).toLocaleString()} Pushups\` :
                         \`\${(athlete.bestPushup1Min || 0).toLocaleString()} Reps (1 Min)\`}
                      </p>`;
code = code.replace(xpMatch, xpNew);

fs.writeFileSync('src/components/WorldChat.tsx', code);
console.log("Patched WorldChat.tsx");
