const fs = require('fs');
let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf-8');

if (!code.includes('useGenieTracker')) {
  code = code.replace(
    'import { useGuardianContext } from "../context/GuardianContext";',
    'import { useGuardianContext } from "../context/GuardianContext";\nimport { useGenieTracker } from "../context/GenieTrackerContext";'
  );
}

const hookTarget = `const { profile } = useAuth();`;
const hookReplace = `const { profile } = useAuth();
  const { history } = useGenieTracker();

  // Reference to avoid overriding timeouts
  const msgTimeoutRef = useRef<any>(null);

  useEffect(() => {
    if (history.length === 0) return;
    const lastEvent = history[history.length - 1];
    
    // Only react to fresh events within 1 second
    if (Date.now() - lastEvent.timestamp < 1000) {
      if (msgTimeoutRef.current) clearTimeout(msgTimeoutRef.current);
      
      let newMsg = "";
      let newEmotion: any = "focused";
      
      if (lastEvent.type === "START_EXERCISE") {
        newEmotion = "suspicious";
        newMsg = \`Genie is watching your \${lastEvent.payload.name} form closely. Don't cheat.\`;
      } else if (lastEvent.type === "COMPLETE_EXERCISE") {
        newEmotion = "happy";
        newMsg = \`Good set of \${lastEvent.payload.name}. I verified it.\`;
      } else if (lastEvent.type === "NAVIGATE") {
        const views: any = {
          "world": "Entering World Chat... Keep it respectful.",
          "dojo": "Welcome to the Dojo. Ready to train?",
          "achievements": "Checking your medals? Go earn more.",
          "exercises": "Pick your poison. I'm watching.",
          "home": "Dashboard loaded. What's our next move?"
        };
        newMsg = views[lastEvent.payload.view] || "Genie follows your every move.";
        newEmotion = "thinking";
      } else if (lastEvent.type === "VIEW_SECTION") {
        newEmotion = "focused";
        newMsg = \`Exploring \${lastEvent.payload.section}? Stay focused.\`;
      }

      if (newMsg) {
        setEmotion(newEmotion);
        setMessage(newMsg);
        msgTimeoutRef.current = setTimeout(() => {
          setMessage("");
        }, 5000);
      }
    }
  }, [history, setEmotion, setMessage]);`;

if (!code.includes('history[history.length - 1]')) {
  code = code.replace(hookTarget, hookReplace);
  fs.writeFileSync('src/components/GuardianOrb.tsx', code);
  console.log("Patched GuardianOrb.tsx");
} else {
  console.log("Already patched GuardianOrb.tsx");
}
