const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

// replace isActivityValid
content = content.replace("  const isActivityValid = !monthState.validationFailed;", "  const isActivityValid = true; // Handled by Genie");

fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', content);
