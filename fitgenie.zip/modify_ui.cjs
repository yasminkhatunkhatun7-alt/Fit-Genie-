const fs = require('fs');

let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

const oldRec = `      {scanResult?.recommendationMessage && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-neutral-900 rounded-2xl p-6 border border-[#14F1E1]/30 shadow-[0_0_20px_rgba(20,241,225,0.1)] relative overflow-hidden mb-6"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#14F1E1]/10 rounded-full blur-3xl -z-10" />
          <h3 className="text-white font-black tracking-widest uppercase text-sm mb-4 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#14F1E1]" />
            AI Recommendation
          </h3>
          <div className="text-neutral-300 text-xs sm:text-sm whitespace-pre-wrap leading-relaxed font-medium">
            {scanResult.recommendationMessage}
          </div>
        </motion.div>
      )}`;

const newRec = `      {scanResult?.recommendationMessage && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-b from-neutral-900 to-black rounded-2xl p-1 border border-[#14F1E1]/40 shadow-[0_0_30px_rgba(20,241,225,0.15)] relative overflow-hidden mb-6 group"
        >
          <div className="bg-neutral-900/80 backdrop-blur-xl rounded-xl p-5 relative overflow-hidden z-10 h-full">
            <div className="absolute top-0 right-0 w-48 h-48 bg-[#14F1E1]/10 rounded-full blur-3xl -z-10 group-hover:bg-[#14F1E1]/20 transition-colors duration-700" />
            <div className="absolute -left-6 -top-6 w-32 h-32 bg-[#B66DFF]/10 rounded-full blur-3xl -z-10 group-hover:bg-[#B66DFF]/20 transition-colors duration-700" />
            
            <h3 className="text-transparent bg-clip-text bg-gradient-to-r from-[#14F1E1] to-[#B66DFF] font-black tracking-widest uppercase text-sm mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#14F1E1]" />
              AI Face Mogging Blueprint
            </h3>
            
            <div className="bg-black/60 rounded-xl p-4 border border-white/5 font-mono shadow-inner">
              <div className="text-neutral-300 text-xs sm:text-sm whitespace-pre-wrap leading-relaxed">
                {scanResult.recommendationMessage}
              </div>
            </div>
          </div>
        </motion.div>
      )}`;

const oldStats = `      {/* Quick Stats Row */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-neutral-900 rounded-xl p-3 border border-neutral-800 flex flex-col items-center justify-center text-center shadow-md">
          <Flame className="w-5 h-5 text-[#B66DFF] mb-2" />
          <span className="text-white font-black text-sm">12 DAYS</span>
          <span className="text-neutral-500 text-[9px] font-bold tracking-widest uppercase mt-0.5">Completed</span>
        </div>
        <div className="bg-neutral-900 rounded-xl p-3 border border-neutral-800 flex flex-col items-center justify-center text-center shadow-md">
          <Dumbbell className="w-5 h-5 text-[#14F1E1] mb-2" />
          <span className="text-white font-black text-sm">48 EXERCISES</span>
          <span className="text-neutral-500 text-[9px] font-bold tracking-widest uppercase mt-0.5">Completed</span>
        </div>
        <div className="bg-neutral-900 rounded-xl p-3 border border-neutral-800 flex flex-col items-center justify-center text-center shadow-md">
          <TrendingUp className="w-5 h-5 text-[#14F1E1] mb-2" />
          <span className="text-white font-black text-sm">+14%</span>
          <span className="text-neutral-500 text-[9px] font-bold tracking-widest uppercase mt-0.5">Improvement</span>
        </div>
      </div>`;

const newStats = `      {/* Quick Stats Row */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="bg-gradient-to-b from-neutral-900 to-black rounded-xl p-3.5 border border-neutral-800 flex flex-col items-center justify-center text-center shadow-lg relative overflow-hidden group hover:border-[#B66DFF]/50 transition-colors cursor-default">
          <div className="absolute inset-0 bg-[#B66DFF]/0 group-hover:bg-[#B66DFF]/5 transition-colors" />
          <Flame className="w-5 h-5 text-[#B66DFF] mb-2 group-hover:scale-110 transition-transform" />
          <span className="text-white font-black text-sm">12 DAYS</span>
          <span className="text-neutral-500 text-[8px] font-bold tracking-widest uppercase mt-1">Mogging Streak</span>
        </div>
        <div className="bg-gradient-to-b from-neutral-900 to-black rounded-xl p-3.5 border border-neutral-800 flex flex-col items-center justify-center text-center shadow-lg relative overflow-hidden group hover:border-[#14F1E1]/50 transition-colors cursor-default">
          <div className="absolute inset-0 bg-[#14F1E1]/0 group-hover:bg-[#14F1E1]/5 transition-colors" />
          <Dumbbell className="w-5 h-5 text-[#14F1E1] mb-2 group-hover:scale-110 transition-transform" />
          <span className="text-white font-black text-sm">48 REPS</span>
          <span className="text-neutral-500 text-[8px] font-bold tracking-widest uppercase mt-1">Total Completed</span>
        </div>
        <div className="bg-gradient-to-b from-neutral-900 to-black rounded-xl p-3.5 border border-neutral-800 flex flex-col items-center justify-center text-center shadow-lg relative overflow-hidden group hover:border-emerald-500/50 transition-colors cursor-default">
          <div className="absolute inset-0 bg-emerald-500/0 group-hover:bg-emerald-500/5 transition-colors" />
          <TrendingUp className="w-5 h-5 text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
          <span className="text-white font-black text-sm">+14%</span>
          <span className="text-neutral-500 text-[8px] font-bold tracking-widest uppercase mt-1">Overall Gain</span>
        </div>
      </div>`;


code = code.replace(oldRec, newRec);
code = code.replace(oldStats, newStats);

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done');
