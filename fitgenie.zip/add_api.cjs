const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

const target = `  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });`;

const replacement = `  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.post("/api/fitness-insight", async (req, res) => {
    try {
      const { goal } = req.body;
      
      if (!process.env.GEMINI_API_KEY) {
        return res.json({ insight: "Keep pushing forward! Consistency is the key to unlocking your true potential." });
      }

      // dynamically import GoogleGenAI to avoid issues if not needed
      const { GoogleGenAI } = await import("@google/genai");
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = \`Provide a very short, personalized, highly motivating daily fitness insight/tip (max 2 sentences) for a user whose primary workout goal is: \${goal || "general fitness"}. Do not use quotes. Keep it actionable and encouraging.\`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });

      res.json({ insight: response.text });
    } catch (error) {
      console.error(error);
      res.json({ insight: "Keep pushing forward! Consistency is the key to unlocking your true potential." });
    }
  });`;

content = content.replace(target, replacement);
fs.writeFileSync('server.ts', content);
