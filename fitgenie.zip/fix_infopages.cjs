const fs = require('fs');

const content = `import React, { useState } from 'react';
import { Shield, Info, Mail, FileText, ChevronLeft, Send, CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { AppView } from '../types';

interface InfoPageProps {
  onNavigateToView?: (view: AppView) => void;
}

export function PrivacyPolicySection({ onNavigateToView }: InfoPageProps) {
  return (
    <div className="flex flex-col h-full bg-[#050B1A]">
      <div className="p-4 flex items-center border-b border-brand-border/30 bg-[#050B1A]/95 backdrop-blur-md sticky top-0 z-10">
        <button onClick={() => onNavigateToView?.("home")} className="p-2 -ml-2 mr-2 rounded-lg hover:bg-white/5 text-white">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-black text-white uppercase tracking-widest flex items-center gap-2">
          <Shield className="w-5 h-5 text-brand-accent" /> Privacy Policy
        </h1>
      </div>
      
      <div className="flex-1 overflow-y-auto p-5 pb-24 space-y-6 custom-scrollbar text-white/90">
        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">1. Information We Collect</h2>
          <p className="text-sm leading-relaxed">
            We collect your Google account name, email, and profile photo when you sign in. We also store fitness data you generate while using the app: workout logs, rep counts, XP, streaks, rank, username, and social data (followers/following).
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">2. Camera & AI Tracking</h2>
          <p className="text-sm leading-relaxed">
            Fit Genie uses on-device AI (MediaPipe) to analyze your movements during workouts. Camera video is processed entirely on your device in real time and is NEVER uploaded, stored, or sent to any server. No video or images from your camera leave your device.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">3. How We Use Your Data</h2>
          <p className="text-sm leading-relaxed">
            Your data is used to power app features: tracking your progress, showing leaderboards, enabling social features (follow, challenges), and detecting unrealistic activity through our Genie Guardian system (which runs on local calculations, not external AI).
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">4. Data Storage</h2>
          <p className="text-sm leading-relaxed">
            Your data is stored securely using Google Firebase, a trusted cloud platform. We do not sell your personal data to third parties.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">5. Your Rights</h2>
          <p className="text-sm leading-relaxed">
            You can request deletion of your account and associated data at any time by contacting us at officialfitgenie@gmail.com.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">6. Children's Privacy</h2>
          <p className="text-sm leading-relaxed">
            Fit Genie is designed to be used with parental awareness for users under 18.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">7. Changes to This Policy</h2>
          <p className="text-sm leading-relaxed">
            We may update this policy from time to time. Continued use of the app means you accept the updated policy.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">8. Contact Us</h2>
          <p className="text-sm leading-relaxed">
            For any privacy questions, email <a href="mailto:officialfitgenie@gmail.com" className="text-brand-accent underline">officialfitgenie@gmail.com</a>
          </p>
        </section>
      </div>
    </div>
  );
}

export function TermsOfServiceSection({ onNavigateToView }: InfoPageProps) {
  return (
    <div className="flex flex-col h-full bg-[#050B1A]">
      <div className="p-4 flex items-center border-b border-brand-border/30 bg-[#050B1A]/95 backdrop-blur-md sticky top-0 z-10">
        <button onClick={() => onNavigateToView?.("home")} className="p-2 -ml-2 mr-2 rounded-lg hover:bg-white/5 text-white">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-black text-white uppercase tracking-widest flex items-center gap-2">
          <FileText className="w-5 h-5 text-brand-accent" /> Terms of Service
        </h1>
      </div>
      
      <div className="flex-1 overflow-y-auto p-5 pb-24 space-y-6 custom-scrollbar text-white/90">
        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">1. Acceptance of Terms</h2>
          <p className="text-sm leading-relaxed">
            By using Fit Genie, you agree to these terms.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">2. Use of the App</h2>
          <p className="text-sm leading-relaxed">
            Fit Genie is provided for personal fitness tracking and motivation. You agree to use the app honestly and not attempt to manipulate, exploit, or cheat the tracking, leaderboard, or Genie Guardian systems.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">3. Account Responsibility</h2>
          <p className="text-sm leading-relaxed">
            You are responsible for maintaining the security of your account (via Google Sign-In). Do not share your account with others.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">4. Fair Play</h2>
          <p className="text-sm leading-relaxed">
            Users found repeatedly submitting fake or manipulated workout data (as detected by Genie Guardian) may have their leaderboard scores reset or account restricted.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">5. No Medical Advice</h2>
          <p className="text-sm leading-relaxed">
            Fit Genie provides fitness tracking and gamification tools only. It does not provide medical advice. Consult a doctor before starting any new exercise program.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">6. Limitation of Liability</h2>
          <p className="text-sm leading-relaxed">
            Fit Genie is provided "as is." We are not liable for injuries resulting from exercises performed while using the app.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">7. Changes to Service</h2>
          <p className="text-sm leading-relaxed">
            Features may be added, changed, or removed over time as the app evolves.
          </p>
        </section>

        <section>
          <h2 className="text-sm font-black uppercase text-brand-accent tracking-widest mb-2">8. Contact</h2>
          <p className="text-sm leading-relaxed">
            Questions about these terms: <a href="mailto:officialfitgenie@gmail.com" className="text-brand-accent underline">officialfitgenie@gmail.com</a>
          </p>
        </section>
      </div>
    </div>
  );
}

export function AboutSection({ onNavigateToView }: InfoPageProps) {
  return (
    <div className="flex flex-col h-full bg-[#050B1A]">
      <div className="p-4 flex items-center border-b border-brand-border/30 bg-[#050B1A]/95 backdrop-blur-md sticky top-0 z-10">
        <button onClick={() => onNavigateToView?.("home")} className="p-2 -ml-2 mr-2 rounded-lg hover:bg-white/5 text-white">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-black text-white uppercase tracking-widest flex items-center gap-2">
          <Info className="w-5 h-5 text-brand-accent" /> About Fit Genie
        </h1>
      </div>
      
      <div className="flex-1 overflow-y-auto p-6 pb-24 custom-scrollbar flex items-center justify-center">
        <div className="bg-brand-surface/50 border border-brand-border rounded-2xl p-6 text-center max-w-sm mx-auto shadow-xl">
          <div className="w-16 h-16 bg-brand-accent/20 border border-brand-accent rounded-2xl flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl">🧞</span>
          </div>
          <p className="text-sm text-white/90 leading-loose">
            Fit Genie is an AI-powered, gamified fitness app built for Indian athletes. Combining real-time AI movement tracking, RPG-style progression (XP, ranks, streaks), a social community, and an honest fair-play system (Genie Guardian), Fit Genie turns everyday workouts into an engaging journey. Whether you're doing squats, push-ups, or working on your form, your AI companion Genie is right there with you — tracking, encouraging, and keeping things fair.
          </p>
          <div className="mt-6 pt-6 border-t border-brand-border">
            <p className="text-xs font-black uppercase text-brand-accent tracking-widest">
              Crafted for Indian Athletes. Built in India. 🇮🇳
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function ContactUsSection({ onNavigateToView }: InfoPageProps) {
  return (
    <div className="flex flex-col h-full bg-[#050B1A]">
      <div className="p-4 flex items-center border-b border-brand-border/30 bg-[#050B1A]/95 backdrop-blur-md sticky top-0 z-10">
        <button onClick={() => onNavigateToView?.("home")} className="p-2 -ml-2 mr-2 rounded-lg hover:bg-white/5 text-white">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-black text-white uppercase tracking-widest flex items-center gap-2">
          <Mail className="w-5 h-5 text-brand-accent" /> Contact Us
        </h1>
      </div>
      
      <div className="flex-1 overflow-y-auto p-6 pb-24 custom-scrollbar">
        <div className="bg-brand-surface border border-brand-border rounded-2xl p-6 shadow-xl max-w-sm mx-auto">
          <div className="w-12 h-12 bg-[#4DA8FF]/20 border border-[#4DA8FF]/50 rounded-full flex items-center justify-center mb-4">
            <Mail className="w-6 h-6 text-[#4DA8FF]" />
          </div>
          <p className="text-sm text-white/90 leading-relaxed mb-6">
            Have a question, found a bug, or want to share feedback? We'd love to hear from you. We try to respond within a few days.
          </p>
          
          <a 
            href="mailto:officialfitgenie@gmail.com" 
            className="flex items-center justify-center gap-2 w-full py-3 bg-[#4DA8FF] text-black rounded-xl text-sm font-black uppercase tracking-widest hover:bg-[#4DA8FF]/90 transition-colors"
          >
            <Send className="w-4 h-4" />
            Email Us
          </a>
          <p className="text-center text-xs text-brand-muted mt-4 font-medium tracking-wide">
            officialfitgenie@gmail.com
          </p>
        </div>
      </div>
    </div>
  );
}

export function SupportFeedbackSection({ onNavigateToView }: InfoPageProps) {
  const [issueType, setIssueType] = useState("Bug Report");
  const [description, setDescription] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;
    
    // Open mailto link with pre-filled content
    const subject = encodeURIComponent(\`Fit Genie: \${issueType}\`);
    const body = encodeURIComponent(\`Issue Type: \${issueType}\\n\\nDescription:\\n\${description}\\n\\n---\\nSent from Fit Genie App\`);
    window.location.href = \`mailto:officialfitgenie@gmail.com?subject=\${subject}&body=\${body}\`;
    
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setDescription("");
      onNavigateToView?.("home");
    }, 3000);
  };

  return (
    <div className="flex flex-col h-full bg-[#050B1A]">
      <div className="p-4 flex items-center border-b border-brand-border/30 bg-[#050B1A]/95 backdrop-blur-md sticky top-0 z-10">
        <button onClick={() => onNavigateToView?.("home")} className="p-2 -ml-2 mr-2 rounded-lg hover:bg-white/5 text-white">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-black text-white uppercase tracking-widest">
          Support & Feedback
        </h1>
      </div>
      
      <div className="flex-1 overflow-y-auto p-5 pb-24 custom-scrollbar">
        <div className="max-w-sm mx-auto space-y-6">
          <p className="text-sm text-white/90 leading-relaxed">
            Facing an issue or have a suggestion to make Fit Genie better? Send us a message and we'll look into it.
          </p>
          
          {submitted ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }} 
              animate={{ opacity: 1, scale: 1 }}
              className="bg-emerald-500/10 border border-emerald-500/50 rounded-2xl p-6 flex flex-col items-center text-center"
            >
              <CheckCircle className="w-12 h-12 text-emerald-500 mb-3" />
              <h3 className="text-lg font-black text-white uppercase tracking-widest mb-1">Thanks!</h3>
              <p className="text-sm text-emerald-200/80">We'll look into it.</p>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-black uppercase text-brand-muted tracking-widest mb-1.5 ml-1">
                  Issue Type
                </label>
                <select 
                  value={issueType}
                  onChange={(e) => setIssueType(e.target.value)}
                  className="w-full bg-brand-surface border border-brand-border rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-accent/50 appearance-none"
                >
                  <option value="Bug Report">Bug Report</option>
                  <option value="Feature Suggestion">Feature Suggestion</option>
                  <option value="Account Issue">Account Issue</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              
              <div>
                <label className="block text-[10px] font-black uppercase text-brand-muted tracking-widest mb-1.5 ml-1">
                  Description
                </label>
                <textarea 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Tell us what happened or what you'd like to see..."
                  rows={6}
                  className="w-full bg-brand-surface border border-brand-border rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-accent/50 resize-none"
                  required
                />
              </div>
              
              <button 
                type="submit"
                disabled={!description.trim()}
                className="w-full py-3.5 bg-brand-accent text-black rounded-xl text-sm font-black uppercase tracking-widest hover:bg-brand-accent/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed mt-2"
              >
                Submit Feedback
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
`

fs.writeFileSync('src/components/InfoPages.tsx', content);
console.log("Updated InfoPages.tsx");
