const fs = require('fs');
let code = fs.readFileSync('src/components/AchievementsScreen.tsx', 'utf8');

// replace local getRankDetails with the imported one
code = code.replace(/import \{ useAuth \} from "\.\.\/context\/AuthContext";/, 'import { useAuth, getRankFromXP } from "../context/AuthContext";');

// remove local getRankDetails
code = code.replace(/function getRankDetails[\s\S]*?\}\n\n  const rank = getRankDetails\(xp\);/, 'const rank = getRankFromXP(xp);');

fs.writeFileSync('src/components/AchievementsScreen.tsx', code);
