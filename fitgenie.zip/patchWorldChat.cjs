const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

const useEfectBlock = `  useEffect(() => {
    if (activeTab === "chat") {
      fetchMessages();
    } else if (activeTab === "leaderboard") {
      fetchLeaderboard();
    } else if (activeTab === "network") {
      fetchFriendRequests();
    }
  }, [activeTab]);

  const fetchFriendRequests = async () => {
    try {
      const q = query(collection(db, "friend_requests"), where("toId", "==", currentUserId), where("status", "==", "pending"));
      const snapshot = await getDocs(q);
      const reqs = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setFriendRequests(reqs);
    } catch (e) {
      console.error("Error fetching friend requests:", e);
    }
  };`;

code = code.replace(
  /useEffect\(\(\) => \{\n\s*if \(activeTab === "chat"\) \{\n\s*fetchMessages\(\);\n\s*\} else if \(activeTab === "leaderboard"\) \{\n\s*fetchLeaderboard\(\);\n\s*\}\n\s*\}, \[activeTab\]\);/g,
  useEfectBlock
);

fs.writeFileSync('src/components/WorldChat.tsx', code);
