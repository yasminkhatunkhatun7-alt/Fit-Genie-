const fs = require('fs');

let code = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

const oldDecl = `  const { triggerEvent } = useGuardianContext();
  useEffect(() => {`;

const newDecl = `  const { triggerEvent } = useGuardianContext();
  const { profile, signOutUser } = useAuth();
  useEffect(() => {`;

code = code.replace(oldDecl, newDecl);
code = code.replace(`  const { profile, signOutUser } = useAuth();\n`, '');

fs.writeFileSync('src/components/HomeDashboard.tsx', code);
