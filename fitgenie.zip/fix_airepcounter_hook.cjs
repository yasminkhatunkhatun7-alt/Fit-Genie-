const fs = require('fs');
let code = fs.readFileSync('src/components/AiRepCounter.tsx', 'utf-8');

code = code.replace('  const { user } = useAuth();', 
  "  const { user, profile, updateUserProfileFields } = useAuth();\n  const { processChallengeResult } = useGhostChallenge(profile);");
code = code.replace('  const { updateUserProfileFields, profile } = useAuth();', '');

fs.writeFileSync('src/components/AiRepCounter.tsx', code);
