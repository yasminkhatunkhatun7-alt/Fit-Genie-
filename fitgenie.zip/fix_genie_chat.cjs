const fs = require('fs');
let file = fs.readFileSync('src/components/GenieChat.tsx', 'utf8');

file = file.replace(
    'className="flex flex-col h-[50vh] min-h-[300px]"',
    'className="flex flex-col h-[50vh] min-h-[350px] max-h-[60vh]"'
);

fs.writeFileSync('src/components/GenieChat.tsx', file);
