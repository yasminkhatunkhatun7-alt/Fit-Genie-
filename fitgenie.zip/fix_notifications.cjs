const fs = require('fs');

let sidebar = fs.readFileSync('src/components/SidebarSections.tsx', 'utf8');

if (!sidebar.includes("You're all caught up!")) {
  sidebar = sidebar.replace(
    '<div className="p-4 bg-[#111111] rounded-xl border border-neutral-900 mt-4 text-center">',
    '<div className="p-4 bg-[#111111] rounded-xl border border-neutral-900 mt-4 text-center">\n          <p className="text-zinc-500 font-bold uppercase tracking-widest text-xs">You\'re all caught up! No new notifications.</p>'
  );
  sidebar = sidebar.replace(
    '<p className="text-zinc-500">No new notifications</p>',
    '<p className="text-zinc-500">You\'re all caught up! No new notifications.</p>'
  );
  sidebar = sidebar.replace(
    'No recent notifications',
    "You're all caught up! No new notifications."
  );
  fs.writeFileSync('src/components/SidebarSections.tsx', sidebar);
}
