const fs = require('fs');
let content = fs.readFileSync('src/components/WeeklyChallengeScreen.tsx', 'utf8');

content = content.replace(/          return next;\n          \}, 1000\);/g, '          return next;\n        });\n      }, 1000);');
fs.writeFileSync('src/components/WeeklyChallengeScreen.tsx', content);
