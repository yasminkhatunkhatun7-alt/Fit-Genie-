const fs = require('fs');

// Fix sounds in OneMonthChallengeScreen
let screenCode = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');
screenCode = screenCode.replace(/playSound\("hit"\)/g, 'playSound("click")');
screenCode = screenCode.replace(/playSound\("levelUp"\)/g, 'playSound("success")');
fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', screenCode);

// Fix ActiveChallenge interface in ChallengesScreen
let challengesCode = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf8');
challengesCode = challengesCode.replace(
  /exercises: \{ name: string; targetReps: number; completedReps: number \}\[\];/g,
  'exercises: { name: string; targetReps: number; completedReps: number }[];\n  desc?: string;'
);
fs.writeFileSync('src/components/ChallengesScreen.tsx', challengesCode);

