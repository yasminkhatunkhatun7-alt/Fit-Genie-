const fs = require('fs');
let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

const cameraState = `  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);
  const [scanResult, setScanResult] = useState<any>(null);
  const [scanError, setScanError] = useState<string | null>(null);
  const [isLegendOpen, setIsLegendOpen] = useState(false);
  const [expandedArea, setExpandedArea] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);
  
  // Camera State
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);`;

code = code.replace(
  /  const \[uploadedImage, setUploadedImage\] = useState<string \| null>\(null\);[^]+?const recognitionRef = useRef<any>\(null\);/,
  cameraState
);

const cameraLogic = `
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setCameraStream(stream);
      setIsCameraActive(true);
      setUploadedImage(null);
      setScanComplete(false);
      setScanResult(null);
      setScanError(null);
    } catch (err) {
      console.error("Error accessing camera:", err);
      alert("Could not access camera. Please check permissions.");
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        setUploadedImage(dataUrl);
        stopCamera();
        processImage(dataUrl);
      }
    }
  };

  const processImage = async (base64: string) => {
    setIsScanning(true);
    setScanComplete(false);
    setScanError(null);
    setScanResult(null);
    try {
      const response = await fetch('/api/face-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: base64 }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Scan failed');
      }
      if (!data.valid) {
        setScanError(data.message || data.reason || 'Face scan failed.');
        setIsScanning(false);
        setScanComplete(false);
      } else {
        setScanResult(data);
        playSound('success');
        setIsScanning(false);
        setScanComplete(true);
      }
    } catch (error) {
      console.error(error);
      setScanError('Failed to analyze image. Please try again.');
      setIsScanning(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      playSound('click');
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64 = event.target?.result as string;
        setUploadedImage(base64);
        stopCamera();
        processImage(base64);
      };
      reader.readAsDataURL(file);
    }
  };
`;

code = code.replace(
  /  const handleImageUpload = async \(e: React.ChangeEvent<HTMLInputElement>\) => {[^]*?reader.readAsDataURL\(file\);\n    }\n  };/,
  cameraLogic
);

// We need to inject the camera view into the UI.
const uiCode = `      <div className="relative rounded-3xl overflow-hidden border border-neutral-800 bg-[#0A0D14] shadow-[0_0_40px_rgba(20,241,225,0.05)] aspect-[3/4] flex flex-col items-center justify-center group">
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleImageUpload} 
          accept="image/*" 
          className="hidden" 
        />
        
        {isCameraActive ? (
          <>
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              muted 
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-4 z-20">
              <button 
                onClick={capturePhoto}
                className="bg-[#14F1E1] text-black rounded-full p-4 shadow-[0_0_20px_rgba(20,241,225,0.5)] hover:scale-105 transition-transform"
              >
                <Camera className="w-8 h-8" />
              </button>
              <button 
                onClick={stopCamera}
                className="bg-black/50 text-white backdrop-blur-md rounded-full p-4 border border-neutral-700 hover:bg-black/80 transition-colors"
              >
                <Ban className="w-8 h-8 text-red-500" />
              </button>
            </div>
          </>
        ) : uploadedImage ? (`;

code = code.replace(
  /<div className="relative rounded-3xl overflow-hidden border border-neutral-800 bg-\[#0A0D14\] shadow-\[0_0_40px_rgba\(20,241,225,0\.05\)\] aspect-\[3\/4\] flex flex-col items-center justify-center group">\s*<input\s*type="file"\s*ref=\{fileInputRef\}\s*onChange=\{handleImageUpload\}\s*accept="image\/\*"\s*className="hidden"\s*\/>\s*\{uploadedImage \? \(/,
  uiCode
);

const uploadButtons = `        ) : (
          <div className="flex flex-col items-center justify-center gap-6 w-full h-full p-8">
            <button 
              onClick={startCamera}
              className="w-full flex items-center justify-center gap-3 bg-[#14F1E1]/10 hover:bg-[#14F1E1]/20 border border-[#14F1E1]/30 rounded-2xl p-4 text-[#14F1E1] transition-all group"
            >
              <div className="w-12 h-12 rounded-full bg-[#14F1E1]/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Camera className="w-6 h-6" />
              </div>
              <div className="text-left">
                <span className="block font-black tracking-widest uppercase text-sm">Live Camera</span>
                <span className="block text-[10px] font-bold text-neutral-400 uppercase tracking-widest">Analyze in real-time</span>
              </div>
            </button>
            
            <div className="flex items-center gap-4 w-full">
              <div className="h-px bg-neutral-800 flex-1" />
              <span className="text-[10px] font-black text-neutral-500 uppercase tracking-widest">OR</span>
              <div className="h-px bg-neutral-800 flex-1" />
            </div>

            <button 
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-3 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-2xl p-4 text-neutral-400 hover:text-white transition-all group"
            >
              <div className="w-12 h-12 rounded-full bg-neutral-800 flex items-center justify-center group-hover:scale-110 transition-transform">
                <ImagePlus className="w-6 h-6" />
              </div>
              <div className="text-left">
                <span className="block font-black tracking-widest uppercase text-sm">Upload Photo</span>
                <span className="block text-[10px] font-bold uppercase tracking-widest">From your gallery</span>
              </div>
            </button>
          </div>
        )}`;

code = code.replace(
  /        \) : \(\s*<button\s*onClick=\{\(\) => fileInputRef.current\?\.click\(\)\}\s*className="flex flex-col items-center justify-center gap-4 text-neutral-500 hover:text-\[#14F1E1\] transition-colors p-8"\s*>\s*<div className="w-20 h-20 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center group-hover:border-\[#14F1E1\]\/50 group-hover:shadow-\[0_0_20px_rgba\(20,241,225,0\.2\)\] transition-all">\s*<ImagePlus className="w-8 h-8" \/>\s*<\/div>\s*<div className="text-center">\s*<span className="text-sm font-black text-white tracking-widest uppercase block mb-1">Upload Photo<\/span>\s*<span className="text-\[10px\] font-bold uppercase tracking-widest">Start AI Face Mogging Scan<\/span>\s*<\/div>\s*<\/button>\s*\)\}/,
  uploadButtons
);

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done');
