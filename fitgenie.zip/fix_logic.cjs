const fs = require('fs');

let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

const profileInterfaceRegex = /recoveryWorkouts\?: number;/;
content = content.replace(profileInterfaceRegex, `recoveryWorkouts?: number;
  recoveringFromZero?: boolean;`);

const logicRegex = /let baseIntegrityScore = profile\.integrityScore \?\? 100;[\s\S]*?const newIntegrityScore = Math\.max\(0, Math\.min\(100, baseIntegrityScore \+ integrityGain\)\);/;

const newLogic = `
      let baseIntegrityScore = profile.integrityScore ?? 100;
      let integrityGain = stats.integrityScoreChange || 0;
      
      const isCheating = (stats.integrityScoreChange || 0) < 0;
      const isHonestWorkout = !isCheating && (stats.workoutCompleted || stats.completedWorkoutName || stats.challengeWon);

      let newRecoveryWorkouts = profile.recoveryWorkouts || 0;
      let isRecoveringFromZero = profile.recoveringFromZero || false;

      if (baseIntegrityScore === 0 && isCheating) {
         // Already 0, cheating again keeps it at 0
      } else if (baseIntegrityScore === 0 && !isRecoveringFromZero && isHonestWorkout) {
         isRecoveringFromZero = true;
      }

      if (isHonestWorkout) {
        integrityGain += 1;

        if (stats.workoutCompletedOnTime) {
          integrityGain += 2;
        }

        if (stats.dailyGoalCompleted) {
          integrityGain += 2;
        }

        if (resolvedStreak === 3 && (profile.streak || 0) === 2) {
          integrityGain += 5;
        } else if (resolvedStreak === 7 && (profile.streak || 0) === 6) {
          integrityGain += 10;
        } else if (resolvedStreak === 14 && (profile.streak || 0) === 13) {
          integrityGain += 15;
        } else if (resolvedStreak === 30 && (profile.streak || 0) === 29) {
          integrityGain += 25;
        }
      }

      let newIntegrityScore = baseIntegrityScore + integrityGain;

      if (baseIntegrityScore < 50 || isRecoveringFromZero) {
         if (isHonestWorkout) {
             newRecoveryWorkouts += 1;
             
             if (isRecoveringFromZero) {
                 integrityGain = 0; // Override normal gains while recovering from 0 for milestone exactness?
                 // Actually, if we just set the newIntegrityScore at milestones:
                 if (newRecoveryWorkouts === 3) newIntegrityScore = 15;
                 else if (newRecoveryWorkouts === 7) newIntegrityScore = 30;
                 else if (newRecoveryWorkouts === 14) newIntegrityScore = 50;
                 else if (newRecoveryWorkouts > 14) {
                     // Done recovering from 0
                     isRecoveringFromZero = false;
                     newRecoveryWorkouts = 0;
                 } else {
                     newIntegrityScore = baseIntegrityScore; // Freeze score until milestone
                 }
             } else {
                 if (newRecoveryWorkouts === 3) newIntegrityScore += 10;
                 else if (newRecoveryWorkouts === 7) newIntegrityScore += 20;
                 else if (newRecoveryWorkouts === 14) newIntegrityScore += 30;
             }
         }
      } else {
         newRecoveryWorkouts = 0;
         isRecoveringFromZero = false;
      }
      
      newIntegrityScore = Math.max(0, Math.min(100, newIntegrityScore));
      integrityGain = newIntegrityScore - baseIntegrityScore;
`;

content = content.replace(logicRegex, newLogic);

const updateDataRegex = /recoveryWorkouts: newRecoveryWorkouts\n      \};/;
const newUpdateData = `recoveryWorkouts: newRecoveryWorkouts,
        recoveringFromZero: isRecoveringFromZero
      };`;
content = content.replace(updateDataRegex, newUpdateData);

fs.writeFileSync('src/context/AuthContext.tsx', content);
