const fs = require('fs');
let code = fs.readFileSync('src/components/BottomNavigation.tsx', 'utf-8');

// Replace achievements with world
code = code.replace(
  '{ view: "achievements" as AppView, label: "Rewards", icon: <Trophy className="w-5 h-5" /> },',
  '{ view: "world" as AppView, label: "World", icon: <Globe className="w-5 h-5" /> },'
);

if (!code.includes('Globe')) {
  code = code.replace(
    'import { Home, Swords, Trophy, User, Flame } from "lucide-react";',
    'import { Home, Swords, Trophy, User, Flame, Globe } from "lucide-react";'
  );
}

fs.writeFileSync('src/components/BottomNavigation.tsx', code);
console.log("Patched BottomNavigation.tsx");
