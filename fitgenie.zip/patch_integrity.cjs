const fs = require('fs');
let content = fs.readFileSync('src/hooks/useIntegrityEngine.ts', 'utf8');

content = `import { useState } from 'react';
export function useIntegrityEngine(challengeId: string) {
  return {
    cooldown: 0,
    suspiciousPhase: 'none',
    lockEndTime: null,
    validateAndAddReps: (name, amount, time, onValid) => onValid(),
    proceedFromAlert: () => {},
    proceedFromMotivation: () => {},
    submitApology: () => {},
    resetSessionTime: () => {}
  };
}
`;

fs.writeFileSync('src/hooks/useIntegrityEngine.ts', content);
