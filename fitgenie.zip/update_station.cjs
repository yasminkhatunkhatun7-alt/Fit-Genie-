const fs = require('fs');

let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

const newExerciseSection = `        <div className="space-y-4">
          {[
            {
              id: 'jawline',
              name: 'JAWLINE',
              exercises: [
                { name: 'Chin Tucks', sets: 3, reps: '15 Reps', duration: '2 MIN', difficulty: 'Beginner', target: 'Jawline', image: '/164646.png' },
                { name: 'Jaw Resistance Press', sets: 3, reps: '12 Reps', duration: '2 MIN', difficulty: 'Intermediate', target: 'Jawline', image: '/164646.png' },
                { name: 'Neck Raises', sets: 3, reps: '15 Reps', duration: '3 MIN', difficulty: 'Beginner', target: 'Neck', image: '/164646.png' },
                { name: 'Tongue Press Hold', sets: 3, reps: '30 Sec', duration: '1.5 MIN', difficulty: 'Advanced', target: 'Under Chin', image: '/164646.png' },
                { name: 'Jaw Clench Hold', sets: 3, reps: '20 Sec', duration: '1 MIN', difficulty: 'Intermediate', target: 'Jaw Muscles', image: '/164646.png' },
              ],
              food: ['High Protein', 'Water', 'Fruits'],
              avoid: ['Excess Salt', 'Mouth Breathing'],
              care: ['Cold Water Splash']
            },
            {
              id: 'cheekbones',
              name: 'CHEEKBONES',
              exercises: [
                { name: 'Fish Face Hold', sets: 3, reps: '20 Sec', duration: '1 MIN', difficulty: 'Beginner', target: 'Cheekbones', image: '/164741.png' },
                { name: 'Cheek Lift Exercise', sets: 3, reps: '15 Reps', duration: '2 MIN', difficulty: 'Intermediate', target: 'Cheek Muscles', image: '/164741.png' },
                { name: 'Smile Resistance Hold', sets: 3, reps: '15 Reps', duration: '2 MIN', difficulty: 'Advanced', target: 'Cheeks', image: '/164741.png' },
                { name: 'Puff Cheek Transfer', sets: 3, reps: '20 Reps', duration: '3 MIN', difficulty: 'Intermediate', target: 'Face Fat', image: '/164741.png' },
                { name: 'Cheek Sculpt Hold', sets: 3, reps: '20 Sec', duration: '1 MIN', difficulty: 'Advanced', target: 'Cheekbones', image: '/164741.png' },
              ],
              food: ['Protein', 'Vegetables'],
              avoid: ['Excess Sugar', 'Junk Food'],
              care: ['Ice Massage']
            },
            {
              id: 'eyes',
              name: 'EYES',
              exercises: [
                { name: 'Eye Tightener', sets: 3, reps: '20 Reps', duration: '2 MIN', difficulty: 'Intermediate', target: 'Eye Area', image: '/164916.png' },
                { name: 'Eye Focus Switching', sets: 3, reps: '20 Reps', duration: '3 MIN', difficulty: 'Beginner', target: 'Eye Muscles', image: '/164916.png' },
                { name: 'Eyebrow Raises', sets: 3, reps: '15 Reps', duration: '1.5 MIN', difficulty: 'Beginner', target: 'Forehead/Eyes', image: '/164916.png' },
                { name: 'Under Eye Lift', sets: 3, reps: '15 Reps', duration: '2 MIN', difficulty: 'Advanced', target: 'Under Eyes', image: '/164916.png' },
                { name: 'Blink Control Exercise', sets: 3, reps: '30 Reps', duration: '2 MIN', difficulty: 'Intermediate', target: 'Eyelids', image: '/164916.png' },
              ],
              food: ['Carrots', 'Eggs', 'Spinach'],
              avoid: ['Poor Sleep', 'Late Night Scrolling'],
              care: ['Cold Compress']
            },
            {
              id: 'lips',
              name: 'LIPS',
              exercises: [
                { name: 'Lip Press Hold', sets: 3, reps: '20 Sec', duration: '1 MIN', difficulty: 'Beginner', target: 'Lips', image: '/164827.png' },
                { name: 'Smile Hold', sets: 3, reps: '20 Sec', duration: '1 MIN', difficulty: 'Intermediate', target: 'Lips', image: '/164827.png' },
                { name: 'Lip Resistance Exercise', sets: 3, reps: '15 Reps', duration: '2 MIN', difficulty: 'Advanced', target: 'Lips', image: '/164827.png' },
                { name: 'O Shape Hold', sets: 3, reps: '20 Sec', duration: '1 MIN', difficulty: 'Beginner', target: 'Lips/Mouth', image: '/164827.png' },
                { name: 'Lip Stretch Exercise', sets: 3, reps: '15 Reps', duration: '2 MIN', difficulty: 'Intermediate', target: 'Lips', image: '/164827.png' },
              ],
              food: ['Water', 'Fruits'],
              avoid: ['Lip Biting', 'Dehydration'],
              care: ['Lip Balm']
            },
            {
              id: 'mouth',
              name: 'MOUTH',
              exercises: [
                { name: 'Tongue Posture Hold', sets: 3, reps: '30 Sec', duration: '1.5 MIN', difficulty: 'Intermediate', target: 'Mouth/Jaw', image: '/164827.png' },
                { name: 'Tongue Roof Press', sets: 3, reps: '20 Reps', duration: '2 MIN', difficulty: 'Advanced', target: 'Palate', image: '/164827.png' },
                { name: 'Mouth Opening Control', sets: 3, reps: '15 Reps', duration: '2 MIN', difficulty: 'Beginner', target: 'Jaw', image: '/164827.png' },
                { name: 'Mewing Hold Practice', sets: 3, reps: '1 Min', duration: '3 MIN', difficulty: 'Advanced', target: 'Face Structure', image: '/164827.png' },
                { name: 'Oral Muscle Activation', sets: 3, reps: '20 Reps', duration: '2 MIN', difficulty: 'Intermediate', target: 'Mouth', image: '/164827.png' },
              ],
              food: ['Water', 'Fruits'],
              avoid: ['Mouth Breathing', 'Junk Food'],
              care: ['Good Posture']
            },
            {
              id: 'glow',
              name: 'FACE GLOW',
              exercises: [
                { name: 'Cold Water Splash', sets: 1, reps: '2 Min', duration: '2 MIN', difficulty: 'Beginner', target: 'Skin', image: '/164429.png' },
                { name: 'Face Massage', sets: 1, reps: '3 Min', duration: '3 MIN', difficulty: 'Beginner', target: 'Blood Flow', image: '/164429.png' },
                { name: 'Facial Blood Flow Exercise', sets: 3, reps: '20 Reps', duration: '3 MIN', difficulty: 'Intermediate', target: 'Face', image: '/164429.png' },
                { name: 'Relaxed Smile Hold', sets: 3, reps: '20 Sec', duration: '1 MIN', difficulty: 'Beginner', target: 'Face Muscles', image: '/164429.png' },
                { name: 'Face Stretch Routine', sets: 3, reps: '15 Reps', duration: '3 MIN', difficulty: 'Advanced', target: 'Overall Face', image: '/164429.png' },
              ],
              food: ['Water', 'Fruits', 'Vegetables', 'Protein'],
              avoid: ['Excess Sugar', 'Junk Food'],
              care: ['Face Wash', 'Moisturizer', 'Sunscreen']
            }
          ].map((area, index) => {
            const isExpanded = expandedArea === area.id;
            return (
              <div key={area.id} className="bg-neutral-900 rounded-2xl border border-neutral-800 overflow-hidden">
                <div 
                  onClick={() => setExpandedArea(isExpanded ? null : area.id)}
                  className="p-4 flex items-center justify-between cursor-pointer hover:bg-neutral-800/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#14F1E1]/10 flex items-center justify-center border border-[#14F1E1]/30">
                      <span className="text-[#14F1E1] font-black text-xs">{index + 1}</span>
                    </div>
                    <h3 className="text-white font-black text-sm tracking-wider">{area.name}</h3>
                  </div>
                  {isExpanded ? <ChevronUp className="w-5 h-5 text-neutral-500" /> : <ChevronDown className="w-5 h-5 text-neutral-500" />}
                </div>
                
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="border-t border-neutral-800"
                    >
                      <div className="p-4 space-y-4">
                        {/* Exercise Cards */}
                        <div className="space-y-3">
                          {area.exercises.map((ex, i) => (
                            <div key={i} className="bg-neutral-800/40 rounded-xl p-3 border border-neutral-700/50 flex gap-3 relative overflow-hidden group cursor-pointer hover:border-[#14F1E1]/50 transition-colors">
                              <div className="absolute top-0 left-0 w-1 h-full bg-[#14F1E1]/50 group-hover:bg-[#14F1E1] transition-colors" />
                              <div className="w-16 h-16 rounded-xl bg-neutral-800 overflow-hidden shrink-0 border border-neutral-700 relative">
                                <img src={ex.image} alt={ex.name} className="w-full h-full object-cover mix-blend-luminosity opacity-70 group-hover:opacity-100 transition-opacity" />
                                <div className="absolute top-1 left-1 bg-black/80 rounded px-1.5 py-0.5 text-[8px] font-black text-[#14F1E1]">{i + 1}</div>
                              </div>
                              <div className="flex-1 min-w-0 flex flex-col justify-center">
                                <div className="flex justify-between items-start mb-1">
                                  <h4 className="text-white font-black text-[13px] uppercase tracking-wider truncate">{ex.name}</h4>
                                  <div className="flex items-center justify-center w-5 h-5 rounded-full bg-neutral-800 group-hover:bg-[#14F1E1]/20 transition-colors border border-neutral-700 group-hover:border-[#14F1E1]/50 shrink-0">
                                    <CheckCircle2 className="w-3.5 h-3.5 text-neutral-500 group-hover:text-[#14F1E1] transition-colors" />
                                  </div>
                                </div>
                                <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                                  <span className="text-[9px] font-mono font-bold text-[#14F1E1] bg-[#14F1E1]/10 px-1.5 py-0.5 rounded">{ex.sets} Sets • {ex.reps}</span>
                                  <span className="text-[9px] font-black tracking-widest text-neutral-400 uppercase flex items-center gap-0.5 border border-neutral-700 px-1.5 py-0.5 rounded">
                                    <Target className="w-2.5 h-2.5" /> {ex.target}
                                  </span>
                                  <span className="text-[9px] font-black tracking-widest text-neutral-400 uppercase flex items-center gap-0.5 border border-neutral-700 px-1.5 py-0.5 rounded">
                                    <Clock className="w-2.5 h-2.5" /> {ex.duration}
                                  </span>
                                </div>
                                {/* Progress Bar visual */}
                                <div className="w-full bg-neutral-800 rounded-full h-1 mt-2.5 overflow-hidden">
                                   <div className="bg-[#14F1E1] h-1 w-0 group-hover:w-full transition-all duration-[2000ms] ease-out" />
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Dietary & Care Info */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <div className="bg-black/40 rounded-xl p-3 border border-neutral-800/50">
                            <div className="flex items-center gap-1.5 mb-2">
                              <Utensils className="w-3.5 h-3.5 text-green-400" />
                              <span className="text-[9px] font-black tracking-widest text-neutral-400 uppercase">Food</span>
                            </div>
                            <ul className="space-y-1.5">
                              {area.food.map((item, i) => (
                                <li key={i} className="text-xs font-bold text-white flex items-start gap-1.5">
                                  <span className="text-green-400 text-[10px] mt-0.5">•</span> {item}
                                </li>
                              ))}
                            </ul>
                          </div>
                          
                          <div className="bg-black/40 rounded-xl p-3 border border-neutral-800/50">
                            <div className="flex items-center gap-1.5 mb-2">
                              <Ban className="w-3.5 h-3.5 text-red-400" />
                              <span className="text-[9px] font-black tracking-widest text-neutral-400 uppercase">Avoid</span>
                            </div>
                            <ul className="space-y-1.5">
                              {area.avoid.map((item, i) => (
                                <li key={i} className="text-xs font-bold text-white flex items-start gap-1.5">
                                  <span className="text-red-400 text-[10px] mt-0.5">•</span> {item}
                                </li>
                              ))}
                            </ul>
                          </div>
                          
                          <div className="bg-black/40 rounded-xl p-3 border border-neutral-800/50">
                            <div className="flex items-center gap-1.5 mb-2">
                              <HeartHandshake className="w-3.5 h-3.5 text-pink-400" />
                              <span className="text-[9px] font-black tracking-widest text-neutral-400 uppercase">Care</span>
                            </div>
                            <ul className="space-y-1.5">
                              {area.care.map((item, i) => (
                                <li key={i} className="text-xs font-bold text-white flex items-start gap-1.5">
                                  <span className="text-pink-400 text-[10px] mt-0.5">•</span> {item}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
`;

// we need to replace <div className="space-y-4"> ... </div>
const startIdx = code.indexOf('<div className="space-y-4">');
if (startIdx !== -1) {
  // find the end of the space-y-4 div
  // wait, earlier it was replaced completely up to the closing tags, we can just regex it or find last index.
  // The outer div for Exercise Section is:
  // <div className="pt-2">
  //   <div className="flex items-center justify-between mb-4">
  // ...
  //   <div className="space-y-4"> ... </div>
  // </div>
  // So we can replace from startIdx up to the end of the file except the last 2 closing tags.
  // Let's just find the closing tag of space-y-4.
  const endMarker = '      </div>\n    </div>\n  );\n}';
  const endIdx = code.lastIndexOf(endMarker);
  
  if (endIdx !== -1) {
    code = code.substring(0, startIdx) + newExerciseSection + endMarker;
  }
}

fs.writeFileSync('src/components/MoggedStation.tsx', code);
