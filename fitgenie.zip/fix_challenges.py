import re

with open('src/components/ChallengesScreen.tsx', 'r') as f:
    content = f.read()

pattern = re.compile(r"  useEffect\(\(\) => \{\n    // If they have an active challenge and are just opening the screen, we stay on list\.\ \n    // They can click \"IN PROGRESS\" to go to 'active'\.\n  \}, \[\]\);", re.MULTILINE)

replacement = """  useEffect(() => {
    // If they have an active challenge and are just opening the screen, we stay on list. 
    // They can click "IN PROGRESS" to go to 'active'.
    if (activeChallenge && activeChallenge.id === 'daily') {
       const today = new Date();
       const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
       const start = new Date(activeChallenge.startTime);
       const startStr = `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, '0')}-${String(start.getDate()).padStart(2, '0')}`;
       if (todayStr !== startStr) {
           setActiveChallenge(null);
           if (view === 'active') setView('list');
       }
    }
  }, [activeChallenge, view]);

  useEffect(() => {
    const handleFocus = () => {
      if (activeChallenge && activeChallenge.id === 'daily') {
         const today = new Date();
         const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
         const start = new Date(activeChallenge.startTime);
         const startStr = `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, '0')}-${String(start.getDate()).padStart(2, '0')}`;
         if (todayStr !== startStr) {
             setActiveChallenge(null);
             if (view === 'active') setView('list');
         }
      }
    };
    
    window.addEventListener('focus', handleFocus);
    window.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') handleFocus();
    });
    
    const interval = setInterval(handleFocus, 60000);
    return () => {
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('visibilitychange', handleFocus);
      clearInterval(interval);
    };
  }, [activeChallenge, view]);
"""

new_content = pattern.sub(replacement, content)
with open('src/components/ChallengesScreen.tsx', 'w') as f:
    f.write(new_content)

