const fs = require('fs');

const file = 'src/components/SidebarSections.tsx';
let code = fs.readFileSync(file, 'utf-8');

const regex = /\/\/ 6\. HEALTH NOTIFICATIONS BOX[\s\S]*?\/\/ 7\. FREQUENTLY ASKED HELP \& FAQ/;

const replacement = `// 6. HEALTH NOTIFICATIONS BOX
// ==========================================
export function NotificationsSection() {
  const { profile } = useAuth();
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [followingMap, setFollowingMap] = useState<Record<string, boolean>>({});
  const [followingLoading, setFollowingLoading] = useState<string | null>(null);

  useEffect(() => {
    const fetchNotifs = async () => {
      if (!profile?.uid) return;
      try {
        // System Notifications
        const q = query(
          collection(db, "notifications"), 
          where("toUserId", "==", profile.uid),
          orderBy("timestamp", "desc"),
          limit(20)
        );
        const snap = await getDocs(q);
        const systemFetched = snap.docs.map(doc => ({ id: doc.id, type: 'system', ...doc.data() }));

        // Follow Notifications
        const followQ = query(collection(db, "follows"), where("followingId", "==", profile.uid));
        const followSnap = await getDocs(followQ);
        
        const myFollowingQ = query(collection(db, "follows"), where("followerId", "==", profile.uid));
        const myFollowingSnap = await getDocs(myFollowingQ);
        
        const fMap: Record<string, boolean> = {};
        myFollowingSnap.forEach(d => { fMap[d.data().followingId] = true; });
        setFollowingMap(fMap);

        const followFetched = [];
        for (const docSnap of followSnap.docs) {
           const d = docSnap.data();
           const followerDoc = await getDoc(doc(db, "users", d.followerId));
           const fName = followerDoc.exists() ? (followerDoc.data().username || "Someone") : "Someone";
           followFetched.push({
             id: docSnap.id,
             type: 'follow',
             followerId: d.followerId,
             text: \`\${fName} started following you.\`,
             timestamp: d.timestamp || Date.now(),
             time: new Date(d.timestamp || Date.now()).toLocaleString(),
             read: true
           });
        }
        
        const combined = [...systemFetched, ...followFetched].sort((a, b) => b.timestamp - a.timestamp).slice(0, 30);
        setNotifications(combined);
      } catch(e) {
        console.error("Failed to fetch notifications", e);
      } finally {
        setLoading(false);
      }
    };
    fetchNotifs();
  }, [profile]);

  const markAsRead = async (notifId: string) => {
    try {
      await updateDoc(doc(db, "notifications", notifId), { read: true });
      setNotifications(prev => prev.map(n => n.id === notifId ? { ...n, read: true } : n));
    } catch (e) {}
  };

  const handleFollowBack = async (userId: string) => {
    if (!profile?.uid) return;
    setFollowingLoading(userId);
    try {
      const followId = profile.uid + "_" + userId;
      await setDoc(doc(db, "follows", followId), {
        followerId: profile.uid,
        followingId: userId,
        timestamp: Date.now()
      });
      setFollowingMap(prev => ({ ...prev, [userId]: true }));
      playSound("success");
    } catch (e) {
      console.error(e);
    } finally {
      setFollowingLoading(null);
    }
  };

  const getTimeAgo = (ms: number) => {
    const diff = Math.floor((Date.now() - ms) / 60000); // minutes
    if (diff < 1) return "Just Now";
    if (diff < 60) return \`\${diff} mins ago\`;
    if (diff < 1440) return \`\${Math.floor(diff/60)} hours ago\`;
    return \`\${Math.floor(diff/1440)} days ago\`;
  };

  return (
    <div className="bg-[#0A0A0A] border border-[#1A1A1A] p-6 rounded-3xl text-left max-w-md mx-auto shadow-2xl relative select-none">
      <div className="absolute top-0 right-0 w-24 h-24 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />

      <div>
        <span className="text-[10px] font-black uppercase text-brand-accent tracking-widest bg-brand-accent/10 px-2.5 py-1 rounded-md border border-brand-accent/20">
          🔔 ACTIVE BULLETIN FEED
        </span>
        <h2 className="text-xl font-black text-white mt-2 flex items-center gap-2">
          <Bell className="w-5 h-5 text-brand-accent animate-swing" />
          NOTIFICATIONS CENTER
        </h2>
        <p className="text-zinc-500 text-[10px] uppercase font-bold font-mono mt-0.5">
          Read relevant achievement logs and exercise notifications
        </p>
      </div>

      <div className="space-y-3 pt-4">
        {loading ? (
           <p className="text-xs text-brand-muted text-center py-4">Loading notifications...</p>
        ) : notifications.length === 0 ? (
           <p className="text-xs text-brand-muted text-center py-4">No notifications yet.</p>
        ) : (
          notifications.map((not) => (
            <div
              key={not.id}
              className={\`p-3 rounded-2xl border transition-all \${
                not.read 
                  ? "bg-brand-surface/40 border-brand-border/60 text-zinc-400" 
                  : "bg-brand-surface border-brand-accent/20 hover:border-brand-accent/35 text-white"
              }\`}
            >
              <div className="flex justify-between items-start gap-2">
                <p className="text-[11px] leading-relaxed font-semibold">
                  {not.text}
                </p>
                {!not.read && (
                  <span className="w-2 h-2 rounded-full bg-brand-accent shrink-0 mt-1 animate-pulse" />
                )}
              </div>
              
              <div className="flex justify-between items-center mt-3">
                <div className="text-[8.5px] text-zinc-500 font-mono uppercase font-bold flex gap-2">
                  <span>{not.type === 'follow' ? 'Social Activity' : 'System achievement'}</span>
                  <span>•</span>
                  <span>{not.timestamp ? getTimeAgo(not.timestamp) : not.time}</span>
                </div>
                
                {not.type === 'follow' && not.followerId && (
                  followingMap[not.followerId] ? (
                    <span className="text-[10px] uppercase font-bold tracking-widest text-zinc-500">
                      Following
                    </span>
                  ) : (
                    <button
                      onClick={() => handleFollowBack(not.followerId)}
                      disabled={followingLoading === not.followerId}
                      className="px-3 py-1 bg-[#14F1E1] text-[#050B1A] hover:bg-[#0DE2D3] transition-colors rounded-lg text-[10px] font-black uppercase tracking-widest flex items-center gap-1"
                    >
                      {followingLoading === not.followerId ? "..." : "Follow Back"}
                    </button>
                  )
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// ==========================================
// 7. FREQUENTLY ASKED HELP & FAQ`;

code = code.replace(regex, replacement);
fs.writeFileSync(file, code);
