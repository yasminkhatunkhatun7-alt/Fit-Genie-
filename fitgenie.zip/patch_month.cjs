const fs = require('fs');

const code = `import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Trophy, Activity, Target, CheckCircle2, ShieldAlert, CalendarDays, Flame, Shield, Skull, Lock } from "lucide-react";
import { playSound } from "../utils/audio";
import { useAuth } from "../context/AuthContext";
import { ActiveChallenge } from "./ChallengesScreen";

interface OneMonthChallengeScreenProps {
  challenge: ActiveChallenge;
  onUpdate: (updated: ActiveChallenge) => void;
  onBack: () => void;
  onComplete: (xpToAward: number) => void;
}

type MonthMode = 'none' | 'normal' | 'legendary';

interface MonthState {
  mode: MonthMode;
  currentDay: number;
  streak: number;
  longestStreak: number;
  lastCompletedDate: string;
  todayProgress: Record<string, number>;
  claimedFinal: boolean;
}

const NORMAL_MONTH_TASKS = [
  { name: "Pushups", target: 20, difficulty: "Easy", xp: 50 },
  { name: "Squats", target: 30, difficulty: "Easy", xp: 50 },
  { name: "Plank (Secs)", target: 30, difficulty: "Easy", xp: 50 },
  { name: "Jumping Jacks", target: 20, difficulty: "Easy", xp: 50 },
  { name: "Mountain Climbers", target: 30, difficulty: "Easy", xp: 50 },
  { name: "Crunches", target: 30, difficulty: "Easy", xp: 50 },
  { name: "Burpees", target: 15, difficulty: "Medium", xp: 75 },
  { name: "Lunges", target: 40, difficulty: "Medium", xp: 75 },
  { name: "Pushups", target: 25, difficulty: "Medium", xp: 75 },
  { name: "Squats", target: 40, difficulty: "Medium", xp: 75 },
  { name: "Plank (Secs)", target: 45, difficulty: "Medium", xp: 75 },
  { name: "Jumping Jacks", target: 40, difficulty: "Medium", xp: 75 },
  { name: "Mountain Climbers", target: 40, difficulty: "Medium", xp: 75 },
  { name: "Crunches", target: 40, difficulty: "Medium", xp: 75 },
  { name: "Burpees", target: 20, difficulty: "Medium", xp: 75 },
  { name: "Lunges", target: 50, difficulty: "Medium", xp: 75 },
  { name: "Pushups", target: 30, difficulty: "Medium", xp: 75 },
  { name: "Squats", target: 50, difficulty: "Medium", xp: 75 },
  { name: "Plank (Secs)", target: 60, difficulty: "Medium", xp: 75 },
  { name: "Jumping Jacks", target: 50, difficulty: "Medium", xp: 75 },
  { name: "Mountain Climbers", target: 50, difficulty: "Hard", xp: 100 },
  { name: "Crunches", target: 50, difficulty: "Hard", xp: 100 },
  { name: "Burpees", target: 25, difficulty: "Hard", xp: 100 },
  { name: "Lunges", target: 60, difficulty: "Hard", xp: 100 },
  { name: "Pushups", target: 40, difficulty: "Hard", xp: 100 },
  { name: "Squats", target: 60, difficulty: "Hard", xp: 100 },
  { name: "Plank (Secs)", target: 90, difficulty: "Hard", xp: 100 },
  { name: "Jumping Jacks", target: 60, difficulty: "Hard", xp: 100 },
  { name: "Mountain Climbers", target: 60, difficulty: "Hard", xp: 100 },
  { name: "Burpees", target: 30, difficulty: "Hard", xp: 100 },
];

const LEGENDARY_DAILY_TASKS = [
  { name: "Pushups", target: 34, difficulty: "Hard", xp: 50 },
  { name: "Squats", target: 50, difficulty: "Hard", xp: 50 },
  { name: "Crunches", target: 34, difficulty: "Hard", xp: 50 },
  { name: "Burpees", target: 10, difficulty: "Hard", xp: 50 },
  { name: "Plank (Secs)", target: 600, difficulty: "Hard", xp: 50 },
  { name: "Mountain Climbers", target: 34, difficulty: "Hard", xp: 50 },
];

const getYesterdayStr = () => {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toISOString().split('T')[0];
};

const getTodayStr = () => {
  return new Date().toISOString().split('T')[0];
};

const getMotivation = (streak: number) => {
  if (streak >= 30) return "You are no longer the same person.";
  if (streak >= 21) return "Discipline is replacing motivation.";
  if (streak >= 14) return "You're becoming dangerous.";
  if (streak >= 7) return "Most people quit before this point.";
  if (streak >= 3) return "You've got momentum. Keep it up.";
  return "Start small. Stay consistent.";
};

export default function OneMonthChallengeScreen({ challenge, onUpdate, onBack, onComplete }: OneMonthChallengeScreenProps) {
  const { profile } = useAuth();
  const storageKey = \`onemonth_v2_state_\${profile?.uid}\`;
  
  const [monthState, setMonthState] = useState<MonthState>(() => {
    const saved = localStorage.getItem(storageKey);
    if (saved) {
       try { return JSON.parse(saved); } catch (e) {}
    }
    return {
      mode: 'none',
      currentDay: 1,
      streak: 0,
      longestStreak: 0,
      lastCompletedDate: "",
      todayProgress: {},
      claimedFinal: false
    };
  });

  const [selectedTaskIdx, setSelectedTaskIdx] = useState(0);
  const [floatingTexts, setFloatingTexts] = useState<{ id: number, text: string, x: number }[]>([]);
  const [textCounter, setTextCounter] = useState(0);
  const [cooldown, setCooldown] = useState(0);
  
  const todayStr = getTodayStr();
  const yesterdayStr = getYesterdayStr();

  // Streak verification on mount
  useEffect(() => {
    if (monthState.mode === 'none') return;
    if (monthState.lastCompletedDate && monthState.lastCompletedDate !== todayStr && monthState.lastCompletedDate !== yesterdayStr) {
      // Streak broken
      setMonthState(prev => {
        const updated = { ...prev, streak: 0 };
        localStorage.setItem(storageKey, JSON.stringify(updated));
        return updated;
      });
    }
  }, []);

  useEffect(() => {
    setSelectedTaskIdx(0);
  }, [monthState.currentDay]);

  useEffect(() => {
    let cdTimer: NodeJS.Timeout;
    if (cooldown > 0) {
      cdTimer = setInterval(() => {
        setCooldown(prev => Math.max(0, prev - 1));
      }, 1000);
    }
    return () => clearInterval(cdTimer);
  }, [cooldown]);

  const selectMode = (mode: MonthMode) => {
    playSound("click");
    setMonthState(prev => {
      const updated = { ...prev, mode };
      localStorage.setItem(storageKey, JSON.stringify(updated));
      return updated;
    });
  };

  if (monthState.mode === 'none') {
    return (
      <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen">
        <div className="flex items-center mb-6">
          <button onClick={onBack} className="w-10 h-10 bg-neutral-900 rounded-full flex items-center justify-center text-white border border-white/5 active:scale-95 transition">
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>
        <div className="text-center mb-8">
          <h2 className="text-3xl font-black text-white uppercase tracking-tight">Choose Your Path</h2>
          <p className="text-neutral-400 text-sm font-bold uppercase tracking-widest mt-2">Commit to the next 30 days</p>
        </div>
        
        <button onClick={() => selectMode('normal')} className="w-full text-left bg-gradient-to-br from-neutral-900 to-neutral-950 border border-neutral-800 hover:border-blue-500/50 p-6 rounded-3xl relative overflow-hidden group transition-all">
           <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
             <Shield className="w-24 h-24 text-blue-500" />
           </div>
           <h3 className="text-xl font-black text-white uppercase tracking-wider flex items-center gap-2">
             <Shield className="w-5 h-5 text-blue-500" /> Normal Monthly
           </h3>
           <p className="text-neutral-400 text-sm mt-2 font-bold max-w-[80%]">30 days consistency challenge. Daily tasks generated automatically.</p>
           <div className="mt-4 flex flex-wrap gap-2">
             <span className="text-[10px] bg-blue-500/20 text-blue-400 px-2 py-1 rounded font-black uppercase">Easy to Moderate</span>
             <span className="text-[10px] bg-white/5 text-neutral-300 px-2 py-1 rounded font-black uppercase">XP Rewards</span>
             <span className="text-[10px] bg-white/5 text-neutral-300 px-2 py-1 rounded font-black uppercase">Badge</span>
           </div>
        </button>

        <button onClick={() => selectMode('legendary')} className="w-full text-left bg-gradient-to-br from-neutral-900 to-[#1a0505] border border-neutral-800 hover:border-red-500/50 p-6 rounded-3xl relative overflow-hidden group transition-all mt-4">
           <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
             <Skull className="w-24 h-24 text-red-500" />
           </div>
           <h3 className="text-xl font-black text-white uppercase tracking-wider flex items-center gap-2">
             <Skull className="w-5 h-5 text-red-500" /> Legendary Monthly
           </h3>
           <p className="text-neutral-400 text-sm mt-2 font-bold max-w-[80%]">Hardcore challenge. Complete massive monthly targets.</p>
           <div className="mt-4 grid grid-cols-3 gap-2 text-[10px] font-black text-red-400/80 uppercase">
             <span>Pushups: 1000</span>
             <span>Squats: 1500</span>
             <span>Crunches: 1000</span>
             <span>Burpees: 300</span>
             <span>Plank: 300 M</span>
             <span>Climbers: 1000</span>
           </div>
           <div className="mt-4 flex flex-wrap gap-2">
             <span className="text-[10px] bg-red-500/20 text-red-400 px-2 py-1 rounded font-black uppercase">Extreme</span>
             <span className="text-[10px] bg-white/5 text-neutral-300 px-2 py-1 rounded font-black uppercase">Legendary Badge</span>
             <span className="text-[10px] bg-white/5 text-neutral-300 px-2 py-1 rounded font-black uppercase">Huge XP</span>
           </div>
        </button>
        <p className="text-center text-xs text-neutral-500 uppercase font-bold tracking-widest mt-6">
          <Lock className="w-3 h-3 inline mr-1 -mt-0.5" /> Choice locks for the entire month
        </p>
      </div>
    );
  }

  const tasks = monthState.mode === 'normal' 
     ? [NORMAL_MONTH_TASKS[Math.min(monthState.currentDay - 1, 29)]]
     : LEGENDARY_DAILY_TASKS;

  const currentTask = tasks[selectedTaskIdx];
  const isTodayCompleted = monthState.lastCompletedDate === todayStr;
  const allTasksDone = tasks.every(t => (monthState.todayProgress[t.name] || 0) >= t.target);
  const isMonthComplete = monthState.currentDay > 30;

  const handleAddReps = (amount: number) => {
    if (isTodayCompleted || cooldown > 0 || isMonthComplete) return;
    
    setCooldown(1);
    playSound("click");
    
    const task = currentTask;
    const currentReps = monthState.todayProgress[task.name] || 0;
    const newReps = Math.min(currentReps + amount, task.target);
    
    setMonthState(prev => {
       const updated = { ...prev };
       updated.todayProgress = { ...updated.todayProgress, [task.name]: newReps };
       localStorage.setItem(storageKey, JSON.stringify(updated));
       return updated;
    });

    const newId = textCounter + 1;
    setTextCounter(newId);
    setFloatingTexts(prev => [...prev, { id: newId, text: \`+\${amount}\`, x: Math.random() * 40 - 20 }]);
    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== newId));
    }, 1000);
  };

  const handleCompleteDay = () => {
    playSound("success");
    
    let newStreak = monthState.streak;
    if (monthState.lastCompletedDate === yesterdayStr) {
       newStreak += 1;
    } else if (monthState.lastCompletedDate !== todayStr) {
       newStreak = 1;
    }
    
    const newLongest = Math.max(monthState.longestStreak, newStreak);
    const totalXP = tasks.reduce((sum, t) => sum + t.xp, 0);
    
    // Award daily XP
    onComplete(totalXP);
    
    setMonthState(prev => {
       const nextDay = prev.currentDay + 1;
       const updated = {
         ...prev,
         currentDay: nextDay,
         streak: newStreak,
         longestStreak: newLongest,
         lastCompletedDate: todayStr,
         todayProgress: {} // reset
       };
       localStorage.setItem(storageKey, JSON.stringify(updated));
       return updated;
    });
  };

  const handleClaimFinalReward = () => {
    playSound("success");
    const bonusXP = monthState.mode === 'legendary' ? 5000 : 1000;
    onComplete(bonusXP);
    setMonthState(prev => {
       const updated = { ...prev, claimedFinal: true };
       localStorage.setItem(storageKey, JSON.stringify(updated));
       return updated;
    });
  };

  // UI Colors
  const accentColor = monthState.mode === 'legendary' ? 'text-red-500' : 'text-blue-500';
  const accentBg = monthState.mode === 'legendary' ? 'bg-red-500' : 'bg-blue-500';
  const accentBorder = monthState.mode === 'legendary' ? 'border-red-500' : 'border-blue-500';
  const strokeColor = monthState.mode === 'legendary' ? '#ef4444' : '#3b82f6';
  const TitleIcon = monthState.mode === 'legendary' ? Skull : Shield;

  const boss = monthState.mode === 'normal' 
    ? { name: "Consistency Guardian", maxHp: 3000, img: <Shield className="w-10 h-10 text-blue-400" />, color: "bg-blue-500", border: "border-blue-500/30", text: "text-blue-400" }
    : { name: "Titan Of Discipline", maxHp: 10000, img: <Skull className="w-10 h-10 text-red-500" />, color: "bg-red-500", border: "border-red-500/30", text: "text-red-500" };

  const progressPercent = Math.min(100, ((Math.min(monthState.currentDay, 30) - 1) / 30) * 100);
  const currentHp = Math.round(boss.maxHp - (progressPercent / 100) * boss.maxHp);
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 pb-24 relative min-h-screen">
      <AnimatePresence>
        {isMonthComplete && !monthState.claimedFinal && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }} 
              animate={{ scale: 1, y: 0 }} 
              className="bg-[#111] border border-white/10 p-8 rounded-3xl w-full max-w-sm text-center shadow-[0_0_50px_rgba(0,0,0,0.5)] relative overflow-hidden"
            >
              <div className={\`absolute top-0 inset-x-0 h-1 \${accentBg}\`} />
              <div className={\`w-24 h-24 \${accentBg}/20 rounded-full flex items-center justify-center mx-auto mb-6\`}>
                <Trophy className={\`w-12 h-12 \${accentColor}\`} />
              </div>
              <h2 className="text-3xl font-black text-white uppercase tracking-tight mb-2">MONTH COMPLETE</h2>
              <p className={\`\${accentColor} font-bold uppercase tracking-widest text-sm mb-6\`}>You stayed consistent for 30 days.</p>
              
              <div className="bg-black/50 rounded-xl p-5 mb-6 border border-white/5 space-y-3 text-left">
                <p className="text-white text-sm font-bold text-center italic">"Discipline beats motivation."</p>
                <div className="h-px bg-white/10 w-full my-2" />
                <ul className="space-y-3">
                  <li className="flex items-center gap-3 text-sm text-neutral-300 font-bold">
                    <CheckCircle2 className={\`w-5 h-5 \${accentColor}\`}/> 
                    <span>30 Day Finisher Badge</span>
                  </li>
                  <li className="flex items-center gap-3 text-sm text-neutral-300 font-bold">
                    <CheckCircle2 className={\`w-5 h-5 \${accentColor}\`}/> 
                    <span>Bonus XP ({monthState.mode === 'legendary' ? '5000' : '1000'})</span>
                  </li>
                  <li className="flex items-center gap-3 text-sm text-neutral-300 font-bold">
                    <CheckCircle2 className={\`w-5 h-5 \${accentColor}\`}/> 
                    <span>{monthState.mode === 'legendary' ? 'Legendary Title' : 'Special Title'}</span>
                  </li>
                </ul>
              </div>

              <button 
                onClick={handleClaimFinalReward}
                className={\`w-full py-4 \${accentBg} hover:opacity-80 text-white font-black uppercase tracking-widest rounded-xl transition shadow-[0_0_20px_rgba(255,255,255,0.1)]\`}
              >
                CLAIM FINAL REWARDS
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* HEADER */}
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="w-10 h-10 bg-neutral-900 rounded-full flex items-center justify-center text-white border border-white/5 active:scale-95 transition">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className={\`flex items-center gap-2 \${accentBg}/10 border \${accentBorder}/30 px-3 py-1.5 rounded-full\`}>
          <TitleIcon className={\`w-4 h-4 \${accentColor}\`} />
          <span className={\`\${accentColor} font-bold text-xs uppercase tracking-widest\`}>{monthState.mode}</span>
        </div>
      </div>

      {/* OVERVIEW RING CARD */}
      <div className="bg-neutral-900 border border-white/5 p-6 rounded-3xl flex items-center justify-between shadow-lg">
         <div className="relative w-28 h-28 flex items-center justify-center shrink-0">
           <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
             <circle cx="50" cy="50" r="45" fill="none" stroke="#1f2937" strokeWidth="8" />
             <circle 
               cx="50" cy="50" r="45" fill="none" 
               stroke={strokeColor} strokeWidth="8" strokeLinecap="round" 
               strokeDasharray={circumference} strokeDashoffset={strokeDashoffset} 
               className="transition-all duration-1000 ease-out"
             />
           </svg>
           <div className="absolute inset-0 flex flex-col items-center justify-center">
             <span className="text-white font-black text-2xl">{Math.min(monthState.currentDay, 30)}<span className="text-sm text-neutral-500">/30</span></span>
           </div>
         </div>
         
         <div className="text-right space-y-3">
           <div>
             <p className="text-[10px] text-neutral-500 uppercase font-black tracking-widest">Progress</p>
             <p className="text-2xl font-black text-white">{Math.round(progressPercent)}%</p>
           </div>
           <div>
             <p className="text-[10px] text-neutral-500 uppercase font-black tracking-widest">Longest Streak</p>
             <p className="text-sm font-black text-neutral-300 flex items-center justify-end gap-1"><Trophy className="w-3.5 h-3.5 text-yellow-500"/> {monthState.longestStreak} Days</p>
           </div>
         </div>
      </div>

      {/* BOSS SYSTEM */}
      <div className={\`bg-gradient-to-br from-neutral-900 to-neutral-950 border \${boss.border} p-5 rounded-3xl relative overflow-hidden\`}>
        <div className="flex items-center gap-4 relative z-10">
          <div className={\`w-16 h-16 rounded-2xl bg-black/50 border \${boss.border} flex items-center justify-center shrink-0 shadow-inner\`}>
            {boss.img}
          </div>
          <div className="flex-1">
            <p className="text-[9px] text-neutral-500 uppercase font-black tracking-widest">Monthly Boss</p>
            <h3 className="text-base font-black text-white uppercase tracking-tight leading-tight">{boss.name}</h3>
            <div className="mt-2.5">
              <div className="flex justify-between text-[10px] font-black uppercase mb-1">
                <span className="text-neutral-400">HP</span>
                <span className={boss.text}>{currentHp} / {boss.maxHp}</span>
              </div>
              <div className="h-1.5 bg-black rounded-full overflow-hidden">
                <motion.div 
                  className={\`h-full \${boss.color}\`}
                  initial={{ width: '100%' }}
                  animate={{ width: \`\${(currentHp / boss.maxHp) * 100}%\` }}
                  transition={{ duration: 1 }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* STREAK & MOTIVATION */}
      <div className="bg-gradient-to-br from-neutral-900 to-neutral-950 border border-neutral-800 p-5 rounded-3xl text-center space-y-4">
        <div className="flex items-center justify-center gap-2">
          <Flame className={\`w-7 h-7 \${monthState.streak > 0 ? 'text-orange-500' : 'text-neutral-600'}\`} />
          <span className="text-4xl font-black text-white">{monthState.streak} <span className="text-sm text-neutral-500 uppercase tracking-widest">Day Streak</span></span>
        </div>
        
        <div className="flex justify-center gap-1.5">
          {[3, 7, 14, 21, 30].map(ms => (
            <div key={ms} className={\`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider \${monthState.streak >= ms ? 'bg-orange-500/20 text-orange-400' : 'bg-white/5 text-neutral-500'}\`}>
              {ms}D
            </div>
          ))}
        </div>
        
        <div className="bg-black/40 border border-white/5 rounded-xl p-3">
          <p className="text-xs text-neutral-300 font-bold italic">"{getMotivation(monthState.streak)}"</p>
        </div>
      </div>

      {/* DAILY TASKS SECTION */}
      {!isMonthComplete && (
        <div className="space-y-4 pt-2">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-sm font-black text-white uppercase tracking-widest">Day {monthState.currentDay} Mission</h3>
            {isTodayCompleted && (
               <span className="text-[10px] bg-green-500/20 text-green-400 px-2.5 py-1 rounded-full font-black uppercase tracking-widest flex items-center gap-1 border border-green-500/20">
                 <CheckCircle2 className="w-3 h-3" /> Completed
               </span>
            )}
          </div>
          
          <div className="space-y-2">
            {tasks.map((task, idx) => {
               const reps = monthState.todayProgress[task.name] || 0;
               const isDone = reps >= task.target;
               const isSelected = selectedTaskIdx === idx;
               const borderColor = isDone ? 'border-green-500/30' : (isSelected ? \`\${accentBorder}\` : 'border-white/5');
               const bgColor = isDone ? 'bg-green-500/5' : (isSelected ? \`\${accentBg}/10\` : 'bg-neutral-900');
               
               return (
                 <button 
                   key={task.name}
                   onClick={() => setSelectedTaskIdx(idx)}
                   className={\`w-full text-left p-4 rounded-2xl border \${borderColor} \${bgColor} transition-all relative overflow-hidden group\`}
                 >
                    {isDone && (
                      <div className="absolute top-0 right-0 bottom-0 w-1 bg-green-500" />
                    )}
                    <div className="flex justify-between items-center relative z-10">
                      <div>
                        <h4 className="text-white font-black uppercase tracking-tight">{task.name}</h4>
                        <div className="flex items-center gap-2 mt-1.5">
                          <span className="text-[9px] text-neutral-400 font-bold uppercase tracking-widest bg-black/50 px-1.5 py-0.5 rounded">{task.difficulty}</span>
                          <span className="text-[9px] text-yellow-500 font-bold uppercase tracking-widest bg-yellow-500/10 px-1.5 py-0.5 rounded">+{task.xp} XP</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={\`text-2xl font-black \${isDone ? 'text-green-400' : 'text-white'}\`}>{reps}</span>
                        <span className="text-neutral-500 text-xs font-black"> / {task.target}</span>
                      </div>
                    </div>
                    {/* Progress Bar inside task */}
                    <div className="h-1.5 bg-black/50 rounded-full mt-3 overflow-hidden">
                       <motion.div 
                         className={\`h-full \${isDone ? 'bg-green-500' : accentBg}\`}
                         initial={{ width: 0 }}
                         animate={{ width: \`\${Math.min(100, (reps / task.target) * 100)}%\` }}
                         transition={{ type: "spring", stiffness: 50 }}
                       />
                    </div>
                 </button>
               )
            })}
          </div>
          
          {/* Controls for currentTask */}
          {!isTodayCompleted && !allTasksDone && currentTask && (
            <div className="bg-neutral-900 p-5 rounded-2xl border border-white/5 space-y-4 mt-4 relative">
               {floatingTexts.map(ft => (
                  <motion.div
                    key={ft.id}
                    initial={{ opacity: 1, y: 0, x: ft.x }}
                    animate={{ opacity: 0, y: -40, x: ft.x }}
                    className={\`absolute left-1/2 top-4 pointer-events-none \${accentColor} font-black text-xl z-50 drop-shadow-[0_0_5px_rgba(255,255,255,0.3)]\`}
                  >
                    {ft.text}
                  </motion.div>
               ))}
               <div className="flex justify-between items-center">
                 <span className="text-xs font-black text-neutral-500 uppercase tracking-widest">Logging: <span className="text-white">{currentTask.name}</span></span>
               </div>
               <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={() => handleAddReps(1)} 
                    className="py-3.5 bg-neutral-800 hover:bg-neutral-700 text-white font-black text-sm rounded-xl active:scale-95 transition"
                  >
                    +1 REP
                  </button>
                  <button 
                    onClick={() => handleAddReps(10)} 
                    className={\`py-3.5 \${accentBg}/20 \${accentColor} hover:\${accentBg}/30 border \${accentBorder}/30 font-black text-sm rounded-xl active:scale-95 transition\`}
                  >
                    +10 REPS
                  </button>
               </div>
               <button 
                 onClick={() => handleAddReps(currentTask.target)} 
                 className="w-full py-3 bg-white/5 hover:bg-white/10 text-neutral-400 text-xs font-black uppercase tracking-widest rounded-xl transition active:scale-95"
               >
                 MARK FULL SET COMPLETE
               </button>
            </div>
          )}
          
          {/* Complete Day Button */}
          {allTasksDone && !isTodayCompleted && (
             <button 
               onClick={handleCompleteDay}
               className="w-full py-4 bg-green-500 hover:bg-green-400 text-black font-black text-sm uppercase tracking-widest rounded-xl transition shadow-[0_0_20px_rgba(34,197,94,0.3)] animate-pulse mt-4 active:scale-95"
             >
               FINISH DAY {Math.min(monthState.currentDay, 30)}
             </button>
          )}
        </div>
      )}
    </div>
  );
}
`;

fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', code);
