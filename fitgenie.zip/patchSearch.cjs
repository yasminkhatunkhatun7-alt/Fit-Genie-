const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

const searchFollowBlock = `
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setSearchResult(null);
    setFriendStatus("none");
    
    try {
      const isFighterId = searchQuery.trim().startsWith("#");
      let q;
      if (isFighterId) {
        q = query(collection(db, "users"), where("fighterId", "==", searchQuery.trim()), limit(1));
      } else {
        q = query(collection(db, "users"), where("userName", "==", searchQuery.trim()), limit(1));
      }
      
      const snapshot = await getDocs(q);
      
      if (!snapshot.empty) {
        const docSnap = snapshot.docs[0];
        const data = docSnap.data();
        const targetId = data.userId || docSnap.id;
        
        setSearchResult({
          userId: targetId,
          userName: data.userName,
          fighterId: data.fighterId,
          xp: data.xp || 0,
          avatarBg: data.avatarBg || "bg-neutral-800",
          lastUpdated: data.lastUpdated || Date.now()
        });
        
        // Check friend status
        if (profile?.friends?.includes(targetId)) {
          setFriendStatus("friends");
        } else {
          // check pending requests sent by current user
          const reqQuery = query(
            collection(db, "friend_requests"),
            where("fromId", "==", currentUserId),
            where("toId", "==", targetId),
            where("status", "==", "pending")
          );
          const reqSnap = await getDocs(reqQuery);
          if (!reqSnap.empty) {
            setFriendStatus("pending");
          } else {
            // check if they sent a request to us
            const incReqQuery = query(
               collection(db, "friend_requests"),
               where("fromId", "==", targetId),
               where("toId", "==", currentUserId),
               where("status", "==", "pending")
            );
            const incReqSnap = await getDocs(incReqQuery);
            if (!incReqSnap.empty) {
               setFriendStatus("pending"); // it's pending (incoming)
            } else {
               setFriendStatus("none");
            }
          }
        }
      } else {
        alert("Athlete not found. Check exact spelling or Fighter ID (e.g., #1234).");
      }
    } catch (e) {
      console.error(e);
      alert("Error searching athlete.");
    }
  };

  const sendFriendRequest = async () => {
    if (!searchResult || friendStatus !== "none") return;
    try {
      await addDoc(collection(db, "friend_requests"), {
        fromId: currentUserId,
        fromName: profile?.username || "Warrior",
        fromFighterId: profile?.fighterId || "",
        toId: searchResult.userId,
        status: "pending",
        timestamp: Date.now()
      });
      setFriendStatus("pending");
      alert("Friend request sent!");
    } catch (e) {
      console.error(e);
      alert("Failed to send request.");
    }
  };

  const acceptRequest = async (request: any) => {
    try {
      // update request status
      await updateDoc(doc(db, "friend_requests", request.id), { status: "accepted" });
      
      // update both users' friend lists
      const userRef = doc(db, "users", currentUserId);
      const senderRef = doc(db, "users", request.fromId);
      
      const currentFriends = profile?.friends || [];
      await updateDoc(userRef, { friends: [...currentFriends, request.fromId] });
      
      const senderSnap = await getDoc(senderRef);
      if (senderSnap.exists()) {
        const senderFriends = senderSnap.data().friends || [];
        await updateDoc(senderRef, { friends: [...senderFriends, currentUserId] });
      }
      
      // refresh local requests
      fetchFriendRequests();
      alert(\`You and \${request.fromName} are now friends!\`);
    } catch (e) {
      console.error(e);
      alert("Failed to accept request.");
    }
  };

  const rejectRequest = async (requestId: string) => {
    try {
      await updateDoc(doc(db, "friend_requests", requestId), { status: "rejected" });
      fetchFriendRequests();
    } catch (e) {
      console.error(e);
    }
  };
`;

code = code.replace(
  /const handleSearch = async \(\s*e: React\.FormEvent\s*\) => \{[\s\S]*?const toggleFollow = async \(\) => \{[\s\S]*?alert\("Failed to update follow status\."\);\n\s*\}\n\s*\};/g,
  searchFollowBlock
);

fs.writeFileSync('src/components/WorldChat.tsx', code);
