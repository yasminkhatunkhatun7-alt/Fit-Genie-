const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

const regex = /       const updated = \{ \.\.\.prev \};\n/;
const replacement = `       const updated = { ...prev };
       if (bypassVerification) {
           updated.validationFailed = false;
           updated.suspiciousFlags = 0;
       }\n`;

content = content.replace(regex, replacement);
fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', content);
