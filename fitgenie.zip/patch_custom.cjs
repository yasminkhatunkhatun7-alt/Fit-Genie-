const fs = require('fs');

let code = fs.readFileSync('src/components/CustomChallengeDetailScreen.tsx', 'utf8');

code = code.replace(/  const \[showCheatWarning, setShowCheatWarning\] = useState\(false\);\n/g, '');
code = code.replace(/  const \[pendingAmount, setPendingAmount\] = useState<{ index: number, amount: number } \| null>\(null\);\n/g, '');

const oldHandle = `  const handleAddReps = (exerciseIndex: number, amount: number) => {
    if (isCompleted || hasClaimed || showCheatWarning) return;
    
    if (amount === 1 && (cooldowns1[exerciseIndex] || 0) > 0) return;
    if (amount === 10 && (cooldowns10[exerciseIndex] || 0) > 0) return;

    const now = Date.now();
    const timeSinceLastAction = now - lastActionTime;
    
    if (amount > 1 && lastActionTime > 0 && timeSinceLastAction < 5000) { 
       setPendingAmount({ index: exerciseIndex, amount });
       playSound("countdown");
       setShowCheatWarning(true);
       return;
    }

    addRepsInternal(exerciseIndex, amount);
  };`;

const newHandle = `  const handleAddReps = (exerciseIndex: number, amount: number) => {
    if (isCompleted || hasClaimed) return;
    
    if (amount === 1 && (cooldowns1[exerciseIndex] || 0) > 0) return;
    if (amount === 10 && (cooldowns10[exerciseIndex] || 0) > 0) return;

    if (checkCheat(challenge.exercises[exerciseIndex].name, amount)) {
      const updated = { ...challenge };
      updated.exercises[exerciseIndex].completedReps = 0;
      onUpdate(updated);
      return;
    }

    addRepsInternal(exerciseIndex, amount);
  };`;

code = code.replace(oldHandle, newHandle);

code = code.replace(/, showCheatWarning/g, '');
code = code.replace(/!showCheatWarning && /g, '');
code = code.replace(/showCheatWarning \|\| /g, '');

const oldRender = `  if (showCheatWarning) {
    return (
      <div className="fixed inset-0 z-[1000] bg-black/90 backdrop-blur-md flex items-center justify-center p-6">
        <div className="bg-[#050B1A] border border-red-500/30 rounded-3xl p-8 max-w-sm w-full text-center relative overflow-hidden shadow-[0_0_50px_rgba(239,68,68,0.2)]">
          <div className="absolute top-0 left-0 right-0 h-1 bg-red-500 animate-pulse" />
          
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 rounded-full bg-red-500/10 flex items-center justify-center border border-red-500/30">
              <AlertTriangle className="w-10 h-10 text-red-500" />
            </div>
          </div>
          
          <h2 className="text-xl font-black text-white uppercase tracking-wider mb-2">Unusual Speed Detected</h2>
          <p className="text-neutral-400 text-sm font-medium mb-8">
            Genie is watching. Doing multiple reps instantly is suspicious. 
          </p>
          
          <div className="space-y-3">
            <button 
              onClick={() => {
                setShowCheatWarning(false);
                if (pendingAmount) {
                  addRepsInternal(pendingAmount.index, pendingAmount.amount);
                  setPendingAmount(null);
                }
              }}
              className="w-full bg-white/10 hover:bg-white/20 text-white font-bold py-4 rounded-xl transition-colors text-sm uppercase tracking-widest border border-white/10"
            >
              Verify & Add Reps
            </button>
            <button 
              onClick={() => {
                setShowCheatWarning(false);
                setPendingAmount(null);
              }}
              className="w-full bg-red-500 hover:bg-red-600 text-white font-black py-4 rounded-xl transition-colors text-sm uppercase tracking-widest"
            >
              Cancel Action
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (suspiciousPhase !== 'none') {`;
const newRender = `  if (suspiciousPhase !== 'none') {`;

code = code.replace(oldRender, newRender);

fs.writeFileSync('src/components/CustomChallengeDetailScreen.tsx', code);
