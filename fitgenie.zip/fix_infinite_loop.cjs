const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf-8');

// The faulty else block:
const faultyElse = `      } else {
        setProfile(null);
        localStorage.removeItem(LOCAL_STORAGE_KEY);
        localStorage.removeItem("fitgenie_onboarding_completed");
      localStorage.removeItem("fitgenie_user");
      window.location.reload();
      }`;

const fixedElse = `      } else {
        setProfile(null);
        localStorage.removeItem(LOCAL_STORAGE_KEY);
        localStorage.removeItem("fitgenie_onboarding_completed");
        localStorage.removeItem("fitgenie_user");
      }`;

code = code.replace(faultyElse, fixedElse);

// Let's also check if signOutUser has reload
if (!code.includes('signOutUser = async () => {\n    try {\n      await signOut(auth);\n      setProfile(null);\n      setUser(null);\n      localStorage.removeItem(LOCAL_STORAGE_KEY);\n      localStorage.removeItem("fitgenie_onboarding_completed");\n      localStorage.removeItem("fitgenie_user");\n      window.location.reload();')) {
  // Fix signOutUser
  const faultySignOut = `  const signOutUser = async () => {
    try {
      await signOut(auth);
      setProfile(null);
      setUser(null);
      localStorage.removeItem(LOCAL_STORAGE_KEY);
      localStorage.removeItem("fitgenie_onboarding_completed");
    } catch (error) {`;
  
  const fixedSignOut = `  const signOutUser = async () => {
    try {
      await signOut(auth);
      setProfile(null);
      setUser(null);
      localStorage.removeItem(LOCAL_STORAGE_KEY);
      localStorage.removeItem("fitgenie_onboarding_completed");
      localStorage.removeItem("fitgenie_user");
      window.location.reload();
    } catch (error) {`;
    
  code = code.replace(faultySignOut, fixedSignOut);
}

fs.writeFileSync('src/context/AuthContext.tsx', code);
