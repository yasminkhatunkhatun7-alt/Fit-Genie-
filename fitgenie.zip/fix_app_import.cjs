const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const importStatement = `import { AboutSection, PrivacyPolicySection, ContactUsSection, TermsOfServiceSection } from "./components/InfoPages";\n`;
content = content.replace('import {', importStatement + 'import {');

content = content.replace('{view === "privacy" && <PrivacySection />}', '{view === "privacy" && <PrivacyPolicySection />}');
content = content.replace('{view === "support" && <HelpSupportSection />}', '{view === "support" && <HelpSupportSection />}\n                {view === "about" && <AboutSection />}\n                {view === "contact" && <ContactUsSection />}\n                {view === "terms" && <TermsOfServiceSection />}');

fs.writeFileSync('src/App.tsx', content);
