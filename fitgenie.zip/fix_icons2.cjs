const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(/import \{([^}]+)\} from "lucide-react";/, (match, p1) => {
    return 'import {' + p1 + ', Info, Mail, FileText} from "lucide-react";';
});

fs.writeFileSync('src/App.tsx', content);
