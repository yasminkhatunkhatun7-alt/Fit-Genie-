const fs = require('fs');

let content = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

content = content.replace(
  '{profile.integrityScore === 0 ? "Becomes 15 Trust" : "+10 Trust"}',
  '{profile.recoveringFromZero ? "Becomes 15 Trust" : "+10 Trust"}'
);
content = content.replace(
  '{profile.integrityScore === 0 ? "Becomes 30 Trust" : "+20 Trust"}',
  '{profile.recoveringFromZero ? "Becomes 30 Trust" : "+20 Trust"}'
);
content = content.replace(
  '{profile.integrityScore === 0 ? "Becomes 50 Trust" : "+30 Trust"}',
  '{profile.recoveringFromZero ? "Becomes 50 Trust" : "+30 Trust"}'
);

fs.writeFileSync('src/components/GuardianOrb.tsx', content);
