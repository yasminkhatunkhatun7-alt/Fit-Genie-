const fs = require('fs');

let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

// Update import
code = code.replace(
  "import React, { useState, useRef } from 'react';",
  "import React, { useState, useRef, useEffect } from 'react';"
);

// Insert state
const stateInjection = `  // Coordinate Mapping State
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerSize, setContainerSize] = useState<{width: number, height: number} | null>(null);
  const [imageSize, setImageSize] = useState<{width: number, height: number} | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      setContainerSize({
        width: entries[0].contentRect.width,
        height: entries[0].contentRect.height
      });
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, [uploadedImage, isCameraActive]);

  const mapCoordinates = (x: number, y: number) => {
    if (!imageSize || !containerSize) return { x, y };
    const { width: iw, height: ih } = imageSize;
    const { width: cw, height: ch } = containerSize;
    const ir = iw / ih;
    const cr = cw / ch;
    let displayWidth = cw;
    let displayHeight = ch;
    let offsetX = 0;
    let offsetY = 0;
    if (ir > cr) {
      displayHeight = ch;
      displayWidth = ch * ir;
      offsetX = (displayWidth - cw) / 2;
    } else {
      displayWidth = cw;
      displayHeight = cw / ir;
      offsetY = (displayHeight - ch) / 2;
    }
    const mappedX = ((displayWidth * (x / 100) - offsetX) / cw) * 100;
    const mappedY = ((displayHeight * (y / 100) - offsetY) / ch) * 100;
    return { x: mappedX, y: mappedY };
  };
`;

code = code.replace(
  "  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);",
  "  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);\n" + stateInjection
);

// Update capturePhoto to set image size
const oldCapturePhoto = `        setUploadedImage(dataUrl);
        stopCamera();
        processImage(dataUrl);`;
const newCapturePhoto = `        setUploadedImage(dataUrl);
        setImageSize({ width: canvas.width, height: canvas.height });
        stopCamera();
        processImage(dataUrl);`;
code = code.replace(oldCapturePhoto, newCapturePhoto);

// Update handleImageUpload to set image size
const oldHandleImageUpload = `        setUploadedImage(base64);
        stopCamera();
        processImage(base64);`;
const newHandleImageUpload = `        setUploadedImage(base64);
        stopCamera();
        const img = new Image();
        img.onload = () => {
          setImageSize({ width: img.width, height: img.height });
        };
        img.src = base64;
        processImage(base64);`;
code = code.replace(oldHandleImageUpload, newHandleImageUpload);

// Attach container ref
code = code.replace(
  '<div className="relative rounded-3xl overflow-hidden border border-neutral-800 bg-[#0A0D14] shadow-[0_0_40px_rgba(20,241,225,0.05)] aspect-[3/4] flex flex-col items-center justify-center group">',
  '<div ref={containerRef} className="relative rounded-3xl overflow-hidden border border-neutral-800 bg-[#0A0D14] shadow-[0_0_40px_rgba(20,241,225,0.05)] aspect-[3/4] flex flex-col items-center justify-center group">'
);

// Replace Face Confidence Ring code
const oldFaceRing = `                    const bbox = scanResult?.faceBoundingBox;
                    if (bbox) {
                      return (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 1, type: "spring" }}
                          className={\`absolute pointer-events-none border-2 border-dashed \${
                            isHighConfidence ? 'border-green-500 shadow-[0_0_30px_rgba(34,197,94,0.3)] animate-pulse' : 'border-amber-500 shadow-[0_0_30px_rgba(245,158,11,0.3)] animate-pulse'
                          }\`}
                          style={{
                            left: \`\${bbox.left}%\`,
                            top: \`\${bbox.top}%\`,
                            width: \`\${bbox.right - bbox.left}%\`,
                            height: \`\${bbox.bottom - bbox.top}%\`,
                            zIndex: 5
                          }}
                        />
                      );
                    }
                    
                    return (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 1, type: "spring" }}
                        className={\`absolute rounded-[40%] pointer-events-none border-2 border-dashed \${
                          isHighConfidence ? 'border-green-500 shadow-[0_0_30px_rgba(34,197,94,0.3)] animate-pulse' : 'border-amber-500 shadow-[0_0_30px_rgba(245,158,11,0.3)] animate-pulse'
                        }\`}
                        style={{
                          left: \`\${centerX}%\`,
                          top: \`\${centerY}%\`,
                          width: '180px',
                          height: '220px',
                          transform: 'translate(-50%, -50%)',
                          zIndex: 5
                        }}
                      />
                    );`;
                    
const newFaceRing = `                    const bbox = scanResult?.faceBoundingBox;
                    if (bbox) {
                      const topLeft = mapCoordinates(bbox.left, bbox.top);
                      const bottomRight = mapCoordinates(bbox.right, bbox.bottom);
                      return (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 1, type: "spring" }}
                          className={\`absolute pointer-events-none border-2 border-dashed \${
                            isHighConfidence ? 'border-green-500 shadow-[0_0_30px_rgba(34,197,94,0.3)] animate-pulse' : 'border-amber-500 shadow-[0_0_30px_rgba(245,158,11,0.3)] animate-pulse'
                          }\`}
                          style={{
                            left: \`\${topLeft.x}%\`,
                            top: \`\${topLeft.y}%\`,
                            width: \`\${bottomRight.x - topLeft.x}%\`,
                            height: \`\${bottomRight.y - topLeft.y}%\`,
                            zIndex: 5
                          }}
                        />
                      );
                    }
                    
                    const mappedCenter = mapCoordinates(centerX, centerY);
                    return (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 1, type: "spring" }}
                        className={\`absolute rounded-[40%] pointer-events-none border-2 border-dashed \${
                          isHighConfidence ? 'border-green-500 shadow-[0_0_30px_rgba(34,197,94,0.3)] animate-pulse' : 'border-amber-500 shadow-[0_0_30px_rgba(245,158,11,0.3)] animate-pulse'
                        }\`}
                        style={{
                          left: \`\${mappedCenter.x}%\`,
                          top: \`\${mappedCenter.y}%\`,
                          width: '180px',
                          height: '220px',
                          transform: 'translate(-50%, -50%)',
                          zIndex: 5
                        }}
                      />
                    );`;
code = code.replace(oldFaceRing, newFaceRing);

// Replace Landmark Dots code
const oldDots = `                      {[
                        { id: 'eyes', title: 'Hunter Eyes', score: scanResult.scores?.hunterEyes, icon: <Eye className="w-3 h-3 text-[#14F1E1]" />, landmark: scanResult.landmarks.eyes },
                        { id: 'cheekbones', title: 'Cheekbones', score: scanResult.scores?.cheekbones, icon: <Diamond className="w-3 h-3 text-[#14F1E1]" />, landmark: scanResult.landmarks.cheekbones },
                        { id: 'faceFat', title: 'Face Fat', score: scanResult.scores?.faceFat, icon: <Activity className="w-3 h-3 text-[#14F1E1]" />, landmark: scanResult.landmarks.chin },
                        { id: 'jawline', title: 'Jawline', score: scanResult.scores?.jawline, icon: <SquareDashedBottom className="w-3 h-3 text-[#14F1E1]" />, landmark: scanResult.landmarks.jawline },
                      ].map((item, index) => {
                        if (!item.landmark) return null;
                        const isHighConf = item.landmark.confidence >= 80;
                        return (
                          <motion.div
                            key={\`dot-\${item.id}\`}
                            initial={{ opacity: 0, scale: 0 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.2 * (index + 1) }}
                            className="absolute pointer-events-none flex flex-col items-center"
                            style={{ left: \`\${item.landmark.x}%\`, top: \`\${item.landmark.y}%\`, transform: 'translate(-50%, -50%)', zIndex: 10 }}
                          >`;
                          
const newDots = `                      {[
                        { id: 'eyes', title: 'Hunter Eyes', score: scanResult.scores?.hunterEyes, icon: <Eye className="w-3 h-3 text-[#14F1E1]" />, landmark: scanResult.landmarks.eyes },
                        { id: 'cheekbones', title: 'Cheekbones', score: scanResult.scores?.cheekbones, icon: <Diamond className="w-3 h-3 text-[#14F1E1]" />, landmark: scanResult.landmarks.cheekbones },
                        { id: 'faceFat', title: 'Face Fat', score: scanResult.scores?.faceFat, icon: <Activity className="w-3 h-3 text-[#14F1E1]" />, landmark: scanResult.landmarks.chin },
                        { id: 'jawline', title: 'Jawline', score: scanResult.scores?.jawline, icon: <SquareDashedBottom className="w-3 h-3 text-[#14F1E1]" />, landmark: scanResult.landmarks.jawline },
                      ].map((item, index) => {
                        if (!item.landmark) return null;
                        const isHighConf = item.landmark.confidence >= 80;
                        const mappedPos = mapCoordinates(item.landmark.x, item.landmark.y);
                        return (
                          <motion.div
                            key={\`dot-\${item.id}\`}
                            initial={{ opacity: 0, scale: 0 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.2 * (index + 1) }}
                            className="absolute pointer-events-none flex flex-col items-center"
                            style={{ left: \`\${mappedPos.x}%\`, top: \`\${mappedPos.y}%\`, transform: 'translate(-50%, -50%)', zIndex: 10 }}
                          >`;
                          
code = code.replace(oldDots, newDots);

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done');
