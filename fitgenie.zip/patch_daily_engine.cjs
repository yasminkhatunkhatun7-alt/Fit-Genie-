const fs = require('fs');
let code = fs.readFileSync('src/components/DailyChallengeDetailScreen.tsx', 'utf8');

if (!code.includes('useIntegrityEngine')) {
  code = "import { useIntegrityEngine } from '../hooks/useIntegrityEngine';\nimport AntiCheatOverlay from './AntiCheatOverlay';\n" + code;
}

// Find component body start
const componentStart = `export default function DailyChallengeDetailScreen({ challenge, onUpdate, onBack, onComplete }: DailyChallengeDetailScreenProps) {
  const { profile } = useAuth();`;

const hookInjection = `
  const {
    cooldown,
    suspiciousPhase,
    lockEndTime,
    validateAndAddReps,
    proceedFromAlert,
    proceedFromMotivation,
    submitApology,
    resetSessionTime
  } = useIntegrityEngine(challenge.id);
`;

code = code.replace(componentStart, componentStart + hookInjection);

// Replace handleAddReps
const handleAddRepsPattern = /  const handleAddReps = \(amount: number\) => \{[\s\S]*?    setCooldown\(5\); \/\/ 5 seconds cooldown\n    \n    const id = Date\.now\(\) \+ "_" \+ Math\.random\(\);\n    setFloatingTexts\(prev => \[\.\.\.prev, \{ id, text: `\+\$\{amount\}`/;

const handleAddRepsReplacement = `  const handleAddReps = (amount: number) => {
    if (isCompleted || hasClaimedToday) return;

    validateAndAddReps(
      exercise.name,
      amount,
      (Date.now() - Date.now()) / 1000, // wait, we need elapsed time!
      // Actually we have elapsedTime from the timer
      elapsedTime,
      () => {
        // Valid callback
        playSound("timer_tick");
        
        const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);
        const id = Date.now() + "_" + Math.random();
        setFloatingTexts(prev => [...prev, { id, text: \`+\${amount}\``;

// Let's do a smarter replace. I'll replace the entire handleAddReps function
const newHandleAddReps = `
  const handleAddReps = (amount: number) => {
    if (isCompleted || hasClaimedToday) return;
    
    validateAndAddReps(
      exercise.name,
      amount,
      elapsedTime,
      () => {
        // Valid
        playSound("timer_tick");
        const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);
        const id = Date.now() + "_" + Math.random();
        setFloatingTexts(prev => [...prev, { id, text: \`+\${amount}\`, x: Math.random() * 40 - 20 }]);
        setTimeout(() => {
          setFloatingTexts(prev => prev.filter(t => t.id !== id));
        }, 1000);

        const updated = { ...challenge };
        updated.exercises[0].completedReps = newCompleted;
        onUpdate(updated);
        saveProgress(newCompleted, elapsedTime, true);
      },
      () => {
        // Reset required
        const updated = { ...challenge };
        updated.exercises[0].completedReps = 0;
        onUpdate(updated);
        setElapsedTime(0);
        setIsStarted(false);
        saveProgress(0, 0, false);
      }
    );
  };
`;

code = code.replace(/  const handleAddReps = \(amount: number\) => \{[\s\S]*?saveProgress\(newCompleted, elapsedTime, true\);\n  \};/, newHandleAddReps);

// Remove old cheat state from component
code = code.replace(/  const \[cooldown, setCooldown\] = useState\(0\);\n/g, "");
code = code.replace(/  const \[warningMsg, setWarningMsg\] = useState\(""\);\n/g, "");
code = code.replace(/  const \[cheatTier, setCheatTier\] = useState\(0\);\n/g, "");
code = code.replace(/  const \[cheatAttempts, setCheatAttempts\] = useState\(0\);\n/g, "");

// Replace old cheat UI rendering with AntiCheatOverlay
const overlayRender = `
  if (suspiciousPhase !== 'none') {
    return (
      <AntiCheatOverlay 
        suspiciousPhase={suspiciousPhase}
        lockEndTime={lockEndTime}
        onProceedFromAlert={proceedFromAlert}
        onProceedFromMotivation={proceedFromMotivation}
        onSubmitApology={submitApology}
      />
    );
  }
`;

code = code.replace(/  if \(cheatTier > 0\) \{[\s\S]*?  \}/, overlayRender);
code = code.replace(/!showHonorValidation && cheatTier === 0/, '!showHonorValidation && suspiciousPhase === "none"');
code = code.replace(/cheatTier, hasClaimedToday/, 'suspiciousPhase, hasClaimedToday');


fs.writeFileSync('src/components/DailyChallengeDetailScreen.tsx', code);
