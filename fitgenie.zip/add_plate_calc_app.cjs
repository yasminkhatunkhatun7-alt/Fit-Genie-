const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

// 1. Add import
if (!code.includes('PlateCalculator')) {
    code = code.replace(
        'import NutritionLog from "./components/NutritionLog";',
        'import NutritionLog from "./components/NutritionLog";\nimport PlateCalculator from "./components/PlateCalculator";'
    );
}

// 2. Add view
if (!code.includes('view === "plate_calc"')) {
    code = code.replace(
        '{view === "calorie_calc" && <CalorieCalculator />}',
        '{view === "calorie_calc" && <CalorieCalculator />}\n                {view === "plate_calc" && <PlateCalculator />}'
    );
}

// 3. Add to menu
if (!code.includes('id: "plate_calc"')) {
    code = code.replace(
        '{ id: "calorie_calc", name: "Calorie Calculator", icon: <Calculator className="w-3.5 h-3.5" /> },',
        '{ id: "calorie_calc", name: "Calorie Calculator", icon: <Calculator className="w-3.5 h-3.5" /> },\n                        { id: "plate_calc", name: "Plate Calculator", icon: <Dumbbell className="w-3.5 h-3.5" /> },'
    );
}

fs.writeFileSync('src/App.tsx', code);
