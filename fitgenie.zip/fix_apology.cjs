const fs = require('fs');

let genieIntelligence = fs.readFileSync('src/hooks/useGenieIntelligence.ts', 'utf8');
genieIntelligence = genieIntelligence.replace(
  '  const submitApology = (msg: string) => {\n    if (msg === "SORRY FIT GENIE") setSuspiciousPhase("motivation");\n  };',
  '  const submitApology = (msg: string) => {\n    if (msg.trim().toLowerCase() === "sorry") setSuspiciousPhase("motivation");\n  };'
);
fs.writeFileSync('src/hooks/useGenieIntelligence.ts', genieIntelligence);

let modal = fs.readFileSync('src/components/GeniePenaltyModal.tsx', 'utf8');

// replace validation
modal = modal.replace(
  '    if (\n      apology.toLowerCase().replace(/[^a-z]/g, "") ===\n      "sorrygenieabsehonestworkoutkarunga"\n    ) {',
  '    if (apology.trim().toLowerCase() === "sorry") {'
);
modal = modal.replace(
  'if (apology.toLowerCase().replace(/[^a-z]/g, "") === "sorrygenieabsehonestworkoutkarunga") {',
  'if (apology.trim().toLowerCase() === "sorry") {'
);

// replace label
modal = modal.replace(
  'Type <strong className="text-white">\n                  Sorry Genie, ab se honest workout karunga.\n                </strong> below to unlock the challenge.',
  'Type <strong className="text-white">sorry</strong> below to unlock the challenge.'
);
modal = modal.replace(
  'Type <strong className="text-white">Sorry Genie, ab se honest workout karunga.</strong> below to unlock the challenge.',
  'Type <strong className="text-white">sorry</strong> below to unlock the challenge.'
);

// replace placeholder
modal = modal.replace(
  'placeholder="Sorry Genie, ab se honest workout karunga."',
  'placeholder="sorry"'
);

// replace motivation message
modal = modal.replace(
  '<p className="text-brand-accent font-medium text-lg">\n                Let\'s get back to real work.\n              </p>',
  '<p className="text-brand-accent font-medium text-lg">\n                Sorry accepted Boss. Next time cheat mat karna 💪\n              </p>'
);
modal = modal.replace(
  "Let's get back to real work.",
  "Sorry accepted Boss. Next time cheat mat karna 💪"
);

fs.writeFileSync('src/components/GeniePenaltyModal.tsx', modal);
