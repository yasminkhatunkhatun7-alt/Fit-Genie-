const fs = require('fs');

let appCode = fs.readFileSync('src/main.tsx', 'utf-8');
if (!appCode.includes('window.onerror')) {
  appCode = appCode.replace('import React from', `window.onerror = function(message, source, lineno, colno, error) {
    console.error("GLOBAL ERROR:", message, error);
  };
  window.addEventListener('unhandledrejection', function(event) {
    console.error("UNHANDLED PROMISE:", event.reason);
  });
  import React from`);
  fs.writeFileSync('src/main.tsx', appCode);
}
