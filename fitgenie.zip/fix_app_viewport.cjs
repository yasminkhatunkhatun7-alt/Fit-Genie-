const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');
content = content.replace(
  '<div className="min-h-screen bg-brand-bg text-white font-sans flex flex-col selection:bg-brand-accent selection:text-brand-bg pb-24" id="app-viewport" className="min-h-screen w-full overflow-x-hidden bg-brand-bg text-white font-sans flex flex-col selection:bg-brand-accent selection:text-brand-bg pb-24">',
  '<div className="min-h-screen w-full overflow-x-hidden bg-brand-bg text-white font-sans flex flex-col selection:bg-brand-accent selection:text-brand-bg pb-24" id="app-viewport">'
);
fs.writeFileSync('src/App.tsx', content);
