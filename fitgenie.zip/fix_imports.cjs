const fs = require('fs');
let profile = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');
if (!profile.includes('Loader2')) {
  profile = profile.replace('} from "lucide-react";', ', Loader2 } from "lucide-react";');
  fs.writeFileSync('src/components/ProfileView.tsx', profile);
}
let history = fs.readFileSync('src/components/WorkoutHistory.tsx', 'utf8');
if (!history.includes('Loader2')) {
  history = history.replace('} from "lucide-react";', ', Loader2 } from "lucide-react";');
  fs.writeFileSync('src/components/WorkoutHistory.tsx', history);
}
