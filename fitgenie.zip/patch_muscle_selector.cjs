const fs = require('fs');

let code = fs.readFileSync('src/components/MuscleSelector.tsx', 'utf8');

// Replace the Model rendering to add the key and AnimatePresence if not present, but actually we just need to add the key to Model.
code = code.replace(
  /<Model\s*type=\{isFront \? "anterior" \: "posterior"\}/,
  `<Model\n            key={isFront ? "front" : "back"}\n            type={isFront ? "anterior" : "posterior"}`
);

fs.writeFileSync('src/components/MuscleSelector.tsx', code);
