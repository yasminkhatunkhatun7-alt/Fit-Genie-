const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const targetSection = `{ id: "privacy", name: "Privacy Policy", icon: <Shield className="w-3.5 h-3.5" /> },
                      ].map((item) => {`;

const newInformationSection = `{ id: "profile", name: "My Athlete Profile", icon: <User className="w-3.5 h-3.5" /> },
                        { id: "history", name: "Workout Logs & Stats", icon: <Award className="w-3.5 h-3.5" /> },
                        { id: "goals", name: "Set Targets & Goals", icon: <Target className="w-3.5 h-3.5" /> },
                        { id: "notifications", name: "System Alerts", icon: <Bell className="w-3.5 h-3.5" /> },
                        { id: "support", name: "Support & Feedback", icon: <HelpCircle className="w-3.5 h-3.5" /> },
                      ].map((item) => {
                        const isActive = view === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => {
                              playSound("click");
                              setShowSidebar(false);
                              setTimeout(() => navigateToView(item.id as AppView), 200);
                            }}
                            className={\`w-full flex items-center justify-between px-3 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all duration-150 cursor-pointer \${
                              isActive
                                ? "bg-brand-accent text-brand-bg font-black font-sans shadow-[0_0_10px_var(--brand-accent-glow-subtle)]"
                                : "text-zinc-400 hover:text-white hover:bg-neutral-900/60"
                            }\`}
                          >
                            <div className="flex items-center gap-2.5">
                              {item.icon}
                              <span>{item.name}</span>
                            </div>
                            {isActive && <div className="w-1.5 h-1.5 rounded-full bg-brand-bg" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Category: Information */}
                  <div className="space-y-1.5">
                    <h4 className="text-[8.5px] font-black text-zinc-500 uppercase tracking-widest px-2.5">
                      Information
                    </h4>
                    <div className="space-y-0.5">
                      {[
                        { id: "about", name: "About Us", icon: <Info className="w-3.5 h-3.5" /> },
                        { id: "privacy", name: "Privacy Policy", icon: <Shield className="w-3.5 h-3.5" /> },
                        { id: "contact", name: "Contact Us", icon: <Mail className="w-3.5 h-3.5" /> },
                        { id: "terms", name: "Terms of Service", icon: <FileText className="w-3.5 h-3.5" /> },
                      ].map((item) => {`;

content = content.replace(/\{ id: "profile", name: "My Athlete Profile"[\s\S]*?\{ id: "privacy", name: "Privacy Policy", icon: <Shield className="w-3\.5 h-3\.5" \/> \},\n\s*\].map\(\(item\) => \{/, newInformationSection);

fs.writeFileSync('src/App.tsx', content);
