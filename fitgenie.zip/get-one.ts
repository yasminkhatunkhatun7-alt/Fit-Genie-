import { GoogleGenAI } from "@google/genai";
import process from "process";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function main() {
  const id = process.argv[2];
  if (!id) {
    console.error("Please provide a video ID");
    process.exit(1);
  }

  const prompt = `Use Google Search to find which specific exercise is demonstrated in the YouTube Shorts video with ID "${id}" (URL: hhttps://youtube.com/shorts/${id} or https://www.youtube.com/watch?v=${id}). The video is uploaded by "Fit_Genie Wale" as part of a "Caleshthenics excersize made by fit Genie" series. Look for page titles, descriptions, playlists, or hashtags. Tell me only the short exercise name (English).`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    console.log("Full response:", JSON.stringify(response, null, 2));
  } catch (err: any) {
    console.error(`Error for ${id}: ${err.message}`);
  }
}

main();
