const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');

// I will remove the whole `{/* Floating AI Camera Button */}` block across the file.
// The block usually starts with `{/* Floating AI Camera Button */}` and ends with `</motion.div>        )}` or `)}`
// Actually, since I know they look like this:
// {/* Floating AI Camera Button */} ... </motion.div> )}
// {/* AI Rep Counter Modal */} ... )}

// I'll just remove all of that inside the Daily, Speed, and Custom blocks.

code = code.replace(/\{\/\* Floating AI Camera Button \*\/\}[\s\S]*?<\/motion\.div>\n        \)\}/g, '');
code = code.replace(/\{\/\* AI Rep Counter Modal \*\/\}[\s\S]*?<\/AiRepCounter>\n        \)\}/g, '');

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
console.log('Fixed Challenges Floating');
