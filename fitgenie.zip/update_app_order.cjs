const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');
content = content.replace('calisthenics: 2.5,', 'calisthenics: 2.5,\n  calisthenics_videos: 2.6,');
fs.writeFileSync('src/App.tsx', content);
