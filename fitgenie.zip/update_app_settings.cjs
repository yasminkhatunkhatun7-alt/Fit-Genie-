const fs = require('fs');
let file = fs.readFileSync('src/App.tsx', 'utf8');

file = file.replace('import ProfileView from "./components/ProfileView";', 'import ProfileView from "./components/ProfileView";\nimport SettingsScreen from "./components/SettingsScreen";');

if (!file.includes('view === "settings"')) {
  file = file.replace(
    '{view === "profile" && <ProfileView',
    '{view === "settings" && <SettingsScreen onBack={() => navigateToView("profile")} onNavigateToView={navigateToView} />}\n                {view === "profile" && <ProfileView'
  );
  fs.writeFileSync('src/App.tsx', file);
}
