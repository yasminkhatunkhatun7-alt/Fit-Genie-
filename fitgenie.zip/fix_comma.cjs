const fs = require('fs');
let history = fs.readFileSync('src/components/WorkoutHistory.tsx', 'utf8');
history = history.replace(', Loader2 } from "lucide-react";', 'Loader2 } from "lucide-react";');
history = history.replace('  , Loader2 } from "lucide-react";', '  Loader2 } from "lucide-react";');
history = history.replace(', Loader2 } from "lucide-react";', 'Loader2 } from "lucide-react";'); // Just in case
fs.writeFileSync('src/components/WorkoutHistory.tsx', history);
