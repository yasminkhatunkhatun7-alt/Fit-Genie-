const fs = require('fs');
let code = fs.readFileSync('src/components/DailyChallengeDetailScreen.tsx', 'utf-8');

code = code.replace(
  `      </AnimatePresence>
      {showAiCounter && (
        <AiRepCounter
          initialExercise={exercise.name.toLowerCase().includes('squat') ? "Squats" : "Pushups"}
          onClose={() => setShowAiCounter(false)}
          onComplete={(reps) => {
            if (reps > 0) {
              handleAddReps(reps, true);
            }
            setShowAiCounter(false);
          }}
        />
      )}
    </div>
  );
}`,
  `      {showAiCounter && (
        <AiRepCounter
          initialExercise={exercise.name.toLowerCase().includes('squat') ? "Squats" : "Pushups"}
          onClose={() => setShowAiCounter(false)}
          onComplete={(reps) => {
            if (reps > 0) {
              handleAddReps(reps, true);
            }
            setShowAiCounter(false);
          }}
        />
      )}
    </div>
  );
}`
);

fs.writeFileSync('src/components/DailyChallengeDetailScreen.tsx', code);
console.log('Fixed syntax in Daily');
