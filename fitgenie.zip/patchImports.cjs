const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');
code = code.replace(
  'import { collection, doc, setDoc, getDocs, getDoc, query, orderBy, limit, deleteDoc, addDoc, where } from "firebase/firestore";',
  'import { collection, doc, setDoc, getDocs, getDoc, query, orderBy, limit, deleteDoc, addDoc, where, updateDoc } from "firebase/firestore";'
);
fs.writeFileSync('src/components/WorldChat.tsx', code);
