const videos = [
"71r_FHZfbGg", "5nQi7LxusNY", "TWHM3b7CmA8", "CEpZYUKyVi4", "Znsw5GoInww",
"16WZ5G7H76Q", "y-0B15s85IU", "sJuLahyPGog", "hYWV2LzJK-s", "N7up-dML2m0",
"FkGwAToLWUg", "_81YybHyZiA", "8BcNd6Pceq0", "iGE2KjaJO9M", "tgLJ-2zE-V0",
"Ip1mo7TcctY", "vzJCNYkMU6k", "gB_iyUl9pvQ", "VC_ss2EftQw", "gJ9oqMTm_jI",
"Kxz7FJQuvUA", "IAMXjYqHBWE", "ERpCXdJsGk8", "MndaZO3u-WI", "aDXJlIFYYZg",
"Ka3tIy4LB1M", "dPglz8tB2ZQ", "3jvcmrU843E", "6MSIkE7e6fE", "R1lhKAsn2WE",
"Sj3yzUhd7CY", "L0Gnmd4fr4U"
];

async function run() {
  const results = [];
  for (const id of videos) {
    try {
      const res = await fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${id}&format=json`);
      if (res.ok) {
        const data = await res.json();
        results.push({
          id,
          title: data.title,
          thumbnail: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
          url: `https://youtu.be/${id}`
        });
      }
    } catch (e) {
      console.error(e);
    }
  }
  const fs = require('fs');
  fs.writeFileSync('src/data/calisthenics_videos.json', JSON.stringify(results, null, 2));
}
run();
