const fs = require('fs');
['src/components/SpeedChallengeScreen.tsx', 'src/components/StrengthChallengeScreen.tsx'].forEach(file => {
  if (!fs.existsSync(file)) return;
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/          return next;\n          \}, 1000\);/g, '          return next;\n        });\n      }, 1000);');
  fs.writeFileSync(file, content);
});
