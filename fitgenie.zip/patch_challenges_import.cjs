const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf8');

code = code.replace(/Activity, CheckCircle2, User \} from "lucide-react";/, "Activity, CheckCircle2, User, ShieldAlert } from 'lucide-react';");

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
