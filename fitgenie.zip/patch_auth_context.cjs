const fs = require('fs');
const file = 'src/context/AuthContext.tsx';
let code = fs.readFileSync(file, 'utf8');

const oldUpdate = `  const updateUserProfileFields = async (fields: Partial<UserProfile>): Promise<void> => {
    if (!profile) throw new Error("No profile");
    saveProfile({ ...profile, ...fields });
  };`;

const newUpdate = `  const updateUserProfileFields = async (fields: Partial<UserProfile>): Promise<void> => {
    if (!profile) throw new Error("No profile");
    
    // Deep merge for stats to prevent overwriting
    const mergedFields = { ...fields };
    if (fields.stats) {
       mergedFields.stats = { ...(profile.stats || {}), ...fields.stats };
    }
    
    saveProfile({ ...profile, ...mergedFields });
  };`;

code = code.replace(oldUpdate, newUpdate);
fs.writeFileSync(file, code);
