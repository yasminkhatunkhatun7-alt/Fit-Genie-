const fs = require('fs');

let sidebar = fs.readFileSync('src/components/SidebarSections.tsx', 'utf8');

// Replace "No notifications yet." with the new text if it exists
sidebar = sidebar.replace(
  'No notifications yet.',
  "You're all caught up! No new notifications."
);
fs.writeFileSync('src/components/SidebarSections.tsx', sidebar);
