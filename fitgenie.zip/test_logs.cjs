const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

code = code.replace(
  '  if (showSplash || loading) {',
  `  console.log("[App.tsx] Rendering AppContent. showSplash:", showSplash, "loading:", loading, "user:", !!user, "isOnboardingDone:", isOnboardingDone, "view:", view);
  if (showSplash || loading) {`
);

fs.writeFileSync('src/App.tsx', code);
