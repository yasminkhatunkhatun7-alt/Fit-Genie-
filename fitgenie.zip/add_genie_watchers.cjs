const fs = require('fs');

let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

const watchers = `
  const prevRankRef = useRef(profile?.rank || "Beginner");
  const prevStreakRef = useRef(profile?.streak || 0);

  useEffect(() => {
    if (profile) {
      if (profile.rank !== prevRankRef.current) {
        setEmotion("celebrating");
        setMessage("Another step forward.");
        prevRankRef.current = profile.rank;
      }
      
      if (profile.streak !== prevStreakRef.current) {
        if (profile.streak === 7) {
          setEmotion("happy");
          setMessage("Momentum is building.");
        } else if (profile.streak === 30) {
          setEmotion("happy");
          setMessage("You're changing.");
        } else if (profile.streak === 90) {
          setEmotion("celebrating");
          setMessage("Legendary consistency.");
        }
        prevStreakRef.current = profile.streak;
      }
    }
  }, [profile?.rank, profile?.streak, setEmotion, setMessage]);
`;

code = code.replace(/const constraintRef = useRef\(null\);/, 'const constraintRef = useRef(null);\n' + watchers);

fs.writeFileSync('src/components/GuardianOrb.tsx', code);
