const fs = require('fs');

let file = fs.readFileSync('src/App.tsx', 'utf8');

file = file.replace('import WorldChat from "./components/WorldChat";', 'import ChatView from "./components/ChatView";');

file = file.replace('{view === "world" && <WorldChat />}', '{view === "chat" && <ChatView />}');
file = file.replace('{view === "chat" && <WorldChat />}', '{view === "chat" && <ChatView />}'); // just in case

fs.writeFileSync('src/App.tsx', file);
