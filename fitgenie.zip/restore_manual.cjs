const fs = require('fs');

function replaceInFile(file, regex, replacement) {
  if (fs.existsSync(file)) {
    let code = fs.readFileSync(file, 'utf-8');
    if (code.match(regex)) {
      code = code.replace(regex, replacement);
      fs.writeFileSync(file, code);
      console.log(`Updated ${file}`);
    } else {
      console.log(`Regex not found in ${file}`);
    }
  }
}

// 1. Daily
replaceInFile('src/components/DailyChallengeDetailScreen.tsx',
  /<div className="bg-white\/5 border border-white\/10 text-neutral-400 font-bold text-sm py-4 rounded-2xl flex justify-center items-center text-center px-4">\s*Manual tracking disabled\. AI Tracker is available for Pushups and Squats\.\s*<\/div>/,
  `<div className="grid grid-cols-2 gap-3 w-full">
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(1)} disabled={isCompleted || hasClaimedToday} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+1</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(5)} disabled={isCompleted || hasClaimedToday} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+5</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(10)} disabled={isCompleted || hasClaimedToday} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+10</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(15)} disabled={isCompleted || hasClaimedToday} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+15</motion.button>
           </div>`
);

// 2. Speed
replaceInFile('src/components/SpeedChallengeScreen.tsx',
  /<div className="bg-white\/5 border border-white\/10 text-neutral-400 font-bold text-sm py-5 rounded-2xl flex justify-center items-center text-center px-4">\s*Manual tracking disabled\. AI Tracker is available for Pushups and Squats\.\s*<\/div>/,
  `<div className="grid grid-cols-2 gap-3 w-full">
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(1)} disabled={isCompleted || timeLeft === 0} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+1</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(5)} disabled={isCompleted || timeLeft === 0} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+5</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(10)} disabled={isCompleted || timeLeft === 0} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+10</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(15)} disabled={isCompleted || timeLeft === 0} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+15</motion.button>
           </div>`
);

// 3. Strength
replaceInFile('src/components/StrengthChallengeScreen.tsx',
  /<div className="bg-white\/5 border border-white\/10 text-neutral-400 font-bold text-sm py-5 rounded-2xl flex justify-center items-center text-center px-4">\s*Manual tracking disabled\. AI Tracker is available for Pushups and Squats\.\s*<\/div>/,
  `<div className="grid grid-cols-2 gap-3 w-full">
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(1)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+1</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(5)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+5</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(10)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+10</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(15)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+15</motion.button>
           </div>`
);

// 4. Weekly
replaceInFile('src/components/WeeklyChallengeScreen.tsx',
  /<div className="bg-white\/5 border border-white\/10 text-neutral-400 font-bold text-sm py-5 rounded-2xl flex justify-center items-center text-center px-4">\s*Manual tracking disabled\. AI Tracker is available for Pushups and Squats\.\s*<\/div>/,
  `<div className="grid grid-cols-2 gap-3 w-full">
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(1)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+1</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(5)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+5</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(10)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+10</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(15)} disabled={isCompleted} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-3 rounded-xl">+15</motion.button>
           </div>`
);

// 5. Custom
replaceInFile('src/components/CustomChallengeDetailScreen.tsx',
  /<div className="flex-1 bg-white\/5 border border-white\/10 text-neutral-400 font-bold text-\[10px\] py-4 rounded-xl flex justify-center items-center text-center px-2 uppercase tracking-widest">\s*Manual Tracking Disabled\s*<\/div>/,
  `<div className="grid grid-cols-4 gap-2 flex-1">
                     <button onClick={() => handleAddReps(index, 1)} disabled={isDone} className="bg-white/10 hover:bg-white/20 text-white font-black text-xs py-3 rounded-lg active:scale-95 transition">+1</button>
                     <button onClick={() => handleAddReps(index, 5)} disabled={isDone} className="bg-white/10 hover:bg-white/20 text-white font-black text-xs py-3 rounded-lg active:scale-95 transition">+5</button>
                     <button onClick={() => handleAddReps(index, 10)} disabled={isDone} className="bg-white/10 hover:bg-white/20 text-white font-black text-xs py-3 rounded-lg active:scale-95 transition">+10</button>
                     <button onClick={() => handleAddReps(index, 15)} disabled={isDone} className="bg-white/10 hover:bg-white/20 text-white font-black text-xs py-3 rounded-lg active:scale-95 transition">+15</button>
                   </div>`
);

// 6. OneMonth
replaceInFile('src/components/OneMonthChallengeScreen.tsx',
  /<div className="flex-1 py-2 bg-white\/5 border border-white\/10 text-neutral-400 font-bold text-\[10px\] uppercase tracking-widest rounded-lg flex items-center justify-center text-center">\s*Manual Tracking Disabled\s*<\/div>/,
  `<>
                   <button onClick={() => handleAddReps(exercise, 1)} className="flex-1 py-2 bg-white/10 hover:bg-white/20 text-white font-black text-xs rounded-lg active:scale-95 transition">+1</button>
                   <button onClick={() => handleAddReps(exercise, 5)} className="flex-1 py-2 bg-white/10 hover:bg-white/20 text-white font-black text-xs rounded-lg active:scale-95 transition">+5</button>
                   <button onClick={() => handleAddReps(exercise, 10)} className="flex-1 py-2 bg-white/10 hover:bg-white/20 text-white font-black text-xs rounded-lg active:scale-95 transition">+10</button>
                   <button onClick={() => handleAddReps(exercise, 15)} className="flex-1 py-2 bg-white/10 hover:bg-white/20 text-white font-black text-xs rounded-lg active:scale-95 transition">+15</button>
                 </>`
);
