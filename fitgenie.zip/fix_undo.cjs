const fs = require('fs');

const files = [
  'src/components/SpeedChallengeScreen.tsx',
  'src/components/StrengthChallengeScreen.tsx',
  'src/components/WeeklyChallengeScreen.tsx',
  'src/components/CustomChallengeDetailScreen.tsx',
  'src/components/DailyChallengeDetailScreen.tsx'
];

files.forEach(file => {
  if (!fs.existsSync(file)) return;
  let content = fs.readFileSync(file, 'utf8');

  // Let's just remove ALL injected `validateAndAddReps` parts that are broken and then we can inject it back properly.
  // Actually, wait, it's easier to just use `git checkout` if I had git...
  // Let me replace `    }, () => {\n      const updated = { ...challenge };\n      updated.exercises[0].completedReps = 0;\n      onUpdate(updated);\n    });\n` with ``
  
  content = content.replace(/    \}, \(\) => \{\n      const updated = \{ \.\.\.challenge \};\n      updated\.exercises\[0\]\.completedReps = 0;\n      onUpdate\(updated\);\n    \}\);\n/g, '');
  
  content = content.replace(/    \}, \(\) => \{\n      const updated = \{ \.\.\.challenge \};\n      updated\.exercises\[exerciseIndex\]\.completedReps = 0;\n      onUpdate\(updated\);\n    \}\);\n/g, '');

  content = content.replace(/validateAndAddReps\(exercise\.name, amount, undefined, \(\) => \{\n/g, '');
  content = content.replace(/validateAndAddReps\(challenge\.exercises\[exerciseIndex\]\.name, amount, undefined, \(\) => \{\n/g, '');

  // What about DailyChallengeDetailScreen?
  content = content.replace(/    \}, \(\) => \{\n      const updated = \{ \.\.\.challenge \};\n      updated\.exercises\[0\]\.completedReps = 0;\n      onUpdate\(updated\);\n    \}\);\n/g, '');

  fs.writeFileSync(file, content);
});
