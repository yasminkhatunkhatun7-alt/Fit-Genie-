const fs = require('fs');
let content = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

const inactiveCode = `
  useEffect(() => {
    if (profile?.last_workout_date) {
      const lastWorkout = new Date(profile.last_workout_date).getTime();
      if (Date.now() - lastWorkout > 24 * 60 * 60 * 1000) {
        setEmotion("inactive");
        setMessage("Your muscles miss you.");
      }
    }
  }, [profile?.last_workout_date]);
`;

content = content.replace(/  const handleDragEnd = /, inactiveCode + '\n  const handleDragEnd = ');
fs.writeFileSync('src/components/GuardianOrb.tsx', content);
