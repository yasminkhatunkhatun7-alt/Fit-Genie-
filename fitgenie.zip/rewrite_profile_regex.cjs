const fs = require('fs');
const file = 'src/components/ProfileView.tsx';
let code = fs.readFileSync(file, 'utf8');

code = code.replace(
  /<div className="flex flex-col h-full bg-\[#050B1A\] relative">/,
  '<div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#B66DFF]/30">'
);

code = code.replace(
  /<div className="p-4 flex items-center justify-between border-b border-brand-border\/30 sticky top-0 bg-\[#050B1A\]\/95 backdrop-blur-md z-10">/,
  '<div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">'
);

code = code.replace(
  /<button onClick=\{\(\) => onNavigateToView\?\.\("settings"\)\} className="p-2 rounded-lg hover:bg-white\/5 text-white">/,
  '<button onClick={() => onNavigateToView?.("settings")} className="p-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 hover:border-[#B66DFF]/30 transition-all group">'
);

code = code.replace(
  /<Settings className="w-6 h-6" \/>/,
  '<Settings className="w-5 h-5 text-neutral-400 group-hover:text-[#B66DFF]" />'
);

code = code.replace(
  /<div className="flex-1 overflow-y-auto custom-scrollbar pb-24">/,
  `<div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#B66DFF]/5 rounded-full blur-[100px] pointer-events-none" />
        <div className="max-w-4xl mx-auto space-y-8 relative z-10 pb-24">`
);

// We must also inject an extra closing div at the end before `{/* FOLLOWERS / FOLLOWING MODAL */}`
code = code.replace(
  /      \{\/\* FOLLOWERS \/ FOLLOWING MODAL \*\/\}/,
  `        </div>\n      </div>\n\n      {/* FOLLOWERS / FOLLOWING MODAL */}`
);

fs.writeFileSync(file, code);
console.log("Rewrote ProfileView wrapper via regex");
