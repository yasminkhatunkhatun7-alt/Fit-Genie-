const fs = require('fs');

let content = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

const insertionPoint = `                    })()}
                  </div>`;

const newCode = `                    })()}
                  </div>
                  
                  {(profile?.integrityScore !== undefined && profile.integrityScore < 50) && (
                     <div className="glass-card p-5 rounded-2xl border border-[rgba(255,100,100,0.2)] bg-[rgba(255,100,100,0.05)]">
                        <div className="flex items-center gap-3 mb-2">
                          <Flame className="w-5 h-5 text-red-400" />
                          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Recovery Missions</h3>
                        </div>
                        <p className="text-xs text-neutral-300 mb-4">Complete honest workouts to earn back Genie's trust.</p>
                        
                        <div className="space-y-3">
                           <div>
                              <div className="flex justify-between text-xs mb-1">
                                 <span className="text-white font-bold">3 Honest Workouts</span>
                                 <span className="text-red-400 font-bold">{profile.integrityScore === 0 ? "Becomes 15 Trust" : "+10 Trust"}</span>
                              </div>
                              <div className="h-2 bg-black/50 rounded-full overflow-hidden border border-neutral-800">
                                 <div className="h-full bg-red-500 transition-all" style={{ width: \`\${Math.min(100, ((profile?.recoveryWorkouts || 0) / 3) * 100)}%\` }} />
                              </div>
                           </div>
                           <div>
                              <div className="flex justify-between text-xs mb-1">
                                 <span className="text-white font-bold">7 Honest Workouts</span>
                                 <span className="text-red-400 font-bold">{profile.integrityScore === 0 ? "Becomes 30 Trust" : "+20 Trust"}</span>
                              </div>
                              <div className="h-2 bg-black/50 rounded-full overflow-hidden border border-neutral-800">
                                 <div className="h-full bg-red-500 transition-all" style={{ width: \`\${Math.min(100, ((profile?.recoveryWorkouts || 0) / 7) * 100)}%\` }} />
                              </div>
                           </div>
                           <div>
                              <div className="flex justify-between text-xs mb-1">
                                 <span className="text-white font-bold">14 Honest Workouts</span>
                                 <span className="text-red-400 font-bold">{profile.integrityScore === 0 ? "Becomes 50 Trust" : "+30 Trust"}</span>
                              </div>
                              <div className="h-2 bg-black/50 rounded-full overflow-hidden border border-neutral-800">
                                 <div className="h-full bg-red-500 transition-all" style={{ width: \`\${Math.min(100, ((profile?.recoveryWorkouts || 0) / 14) * 100)}%\` }} />
                              </div>
                           </div>
                        </div>
                     </div>
                  )}`;

content = content.replace(insertionPoint, newCode);
fs.writeFileSync('src/components/GuardianOrb.tsx', content);
