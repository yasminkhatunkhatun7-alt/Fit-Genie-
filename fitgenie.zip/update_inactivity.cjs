const fs = require('fs');

let code = fs.readFileSync('src/context/GuardianContext.tsx', 'utf8');

// I want to see how inactive is currently triggered, if at all.
