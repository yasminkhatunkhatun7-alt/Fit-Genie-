const fs = require('fs');
const file = 'src/components/ProfileView.tsx';
let code = fs.readFileSync(file, 'utf8');

// I will just use prettier or find the extra div.
code = code.replace(
  /          <\/div>\n        <\/div>\n      <\/div>\n        <\/div>\n      <\/div>\n\n      \{\/\* FOLLOWERS \/ FOLLOWING MODAL \*\/\}/,
  `          </div>\n        </div>\n      </div>\n\n      {/* FOLLOWERS / FOLLOWING MODAL */}`
);
fs.writeFileSync(file, code);
console.log("Fixed");
