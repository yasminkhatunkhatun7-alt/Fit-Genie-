const fs = require('fs');
const file = 'src/components/MuscleSelector.tsx';
let code = fs.readFileSync(file, 'utf-8');

const replacement = `
      <div className="mt-2 text-center h-6">
        <AnimatePresence mode="popLayout">
          {readonly ? null : selectedMuscles.length > 0 ? (
            <motion.p 
              key="selected"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="text-[#14F1E1] text-xs font-bold uppercase tracking-widest drop-shadow-[0_0_8px_rgba(20,241,225,0.5)]"
            >
              {selectedMuscles.length} Muscle{selectedMuscles.length > 1 ? 's' : ''} Locked
            </motion.p>
          ) : (
            <motion.p 
              key="none"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="text-neutral-500 text-xs font-bold uppercase tracking-widest"
            >
              Target System Ready
            </motion.p>
          )}
        </AnimatePresence>
      </div>

      {!readonly && (
        <div className="mt-4 flex flex-wrap justify-center gap-2 px-2">
           {Object.keys(DISPLAY_TO_INTERNAL).map(m => (
             <button
               key={m}
               onClick={() => toggleMuscle(m)}
               className={\`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-colors \${selectedMuscles.includes(m) ? 'bg-[#14F1E1] text-[#050B1A] shadow-[0_0_10px_rgba(20,241,225,0.5)]' : 'bg-white/5 border border-white/10 text-neutral-400 hover:text-white'}\`}
             >
               {m}
             </button>
           ))}
        </div>
      )}
    </div>
  );
`;

code = code.replace(/<div className="mt-2 text-center h-6">[\s\S]*?<\/div>\s*<\/div>\s*\);\s*}/, replacement + "\n}");
fs.writeFileSync(file, code);
