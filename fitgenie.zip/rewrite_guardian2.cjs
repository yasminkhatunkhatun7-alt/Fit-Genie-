const fs = require('fs');
let g = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

g = g.replace(/<div ref=\{constraintRef\} className="fixed inset-0 pointer-events-none z-\[9998\]" \/>[\s\S]*?\{\/\* GUARDIAN PANEL \*\/\}/, 
`      <div ref={constraintRef} className="fixed inset-0 pointer-events-none z-[9998]" />

      {!activeWarning && (
        <motion.div
          drag
          dragConstraints={constraintRef}
          onDragEnd={handleDragEnd}
          initial={position}
          animate={position}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsPanelOpen(true)}
          className="fixed z-[9998] cursor-pointer pointer-events-auto flex flex-col items-center group"
          style={{ width: 70, height: 70 }}
        >
          {/* Bubble */}
          <AnimatePresence>
            {message && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.8 }}
                animate={{ opacity: 1, y: -10, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.8 }}
                className="absolute bottom-[80px] whitespace-nowrap bg-black/80 backdrop-blur-md border border-[rgba(255,255,255,0.1)] px-3 py-1.5 rounded-2xl text-xs font-bold text-white tracking-wider pointer-events-none z-50 shadow-lg"
              >
                {message}
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-black/80 border-b border-r border-[rgba(255,255,255,0.1)] rotate-45" />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Orb */}
          <motion.div 
            className="w-16 h-16 rounded-full relative flex items-center justify-center overflow-hidden"
            animate={{
              boxShadow: [
                \`0 0 15px \${color}, inset 0 0 25px \${color}\`,
                \`0 0 40px \${color}, inset 0 0 50px \${color}\`,
                \`0 0 15px \${color}, inset 0 0 25px \${color}\`
              ]
            }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-black/60 to-transparent z-10" />
            <div className="absolute inset-0 backdrop-blur-sm" />
            
            {/* Core face */}
            <motion.div className="z-20 text-2xl drop-shadow-md"
              animate={{ scale: [1, 1.1, 1], opacity: [0.9, 1, 0.9] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
              {emotion === 'happy' && '😊'}
              {emotion === 'focused' && '🧐'}
              {emotion === 'celebration' && '🎉'}
              {emotion === 'suspicious' && '🤨'}
              {emotion === 'warning' && '😡'}
              {emotion === 'inactive' && '😴'}
            </motion.div>
          </motion.div>
        </motion.div>
      )}

      {/* GUARDIAN PANEL */}`);

fs.writeFileSync('src/components/GuardianOrb.tsx', g);
