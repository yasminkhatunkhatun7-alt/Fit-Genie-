const fs = require('fs');

let code = fs.readFileSync('src/components/WorkoutGenerator.tsx', 'utf8');

if (!code.includes('const FEATURE_CAMERA_TRACKING = false;')) {
  code = code.replace(
    /import \{ AiRepCounter \} from "\.\/AiRepCounter";/,
    `import { AiRepCounter } from "./AiRepCounter";\nconst FEATURE_CAMERA_TRACKING = false;`
  );
}

// Replace button logic
code = code.replace(
  /\{\(ex\.name_en\.toLowerCase\(\)\.includes\("push up"\) \|\| ex\.name_en\.toLowerCase\(\)\.includes\("squat"\)\) && \(/g,
  `{FEATURE_CAMERA_TRACKING && (ex.name_en.toLowerCase().includes("push up") || ex.name_en.toLowerCase().includes("squat")) && (`
);

// Replace Modal logic
code = code.replace(
  /\{showAiTracker && \(/g,
  `{FEATURE_CAMERA_TRACKING && showAiTracker && (`
);

fs.writeFileSync('src/components/WorkoutGenerator.tsx', code);
