const fs = require('fs');
let code = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf-8');

code = code.replace(
  "setShowConfirmMode('none');",
  "setShowConfirmMode('none');\n    resetSessionTime();"
);

fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', code);
console.log('Added resetSessionTime');
