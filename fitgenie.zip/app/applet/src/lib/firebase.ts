import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBxSMiP99eLh5hnaSVARZk5lyxMmSQDL1g",
  authDomain: "synthetic-array-m71nt.firebaseapp.com",
  projectId: "synthetic-array-m71nt",
  storageBucket: "synthetic-array-m71nt.firebasestorage.app",
  messagingSenderId: "763312030640",
  appId: "1:763312030640:web:39ac8ceb84c5eb5efd4c75"
};

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, "ai-studio-fitgenie-26029509-10b5-4f18-8f3b-f9883a286252");
