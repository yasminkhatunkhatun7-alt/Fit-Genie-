const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

if (!code.includes('import WorldChat')) {
  code = code.replace(
    'import AboutPage from "./components/AboutPage";',
    'import AboutPage from "./components/AboutPage";\nimport WorldChat from "./components/WorldChat";'
  );
}

code = code.replace(
  '{view === "achievements" && <AchievementsScreen />}',
  '{view === "world" && <WorldChat />}\n                {view === "achievements" && <AchievementsScreen />}'
);

fs.writeFileSync('src/App.tsx', code);
console.log("Patched App.tsx");
