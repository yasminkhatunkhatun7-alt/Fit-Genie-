const fs = require('fs');

// Add `checkCheat` to destructuring in all files
const files = [
  'src/components/DailyChallengeDetailScreen.tsx',
  'src/components/SpeedChallengeScreen.tsx',
  'src/components/StrengthChallengeScreen.tsx',
  'src/components/WeeklyChallengeScreen.tsx',
  'src/components/CustomChallengeDetailScreen.tsx'
];

files.forEach(file => {
  if (!fs.existsSync(file)) return;
  let content = fs.readFileSync(file, 'utf8');

  content = content.replace(/validateAndAddReps,/g, 'checkCheat,');

  if (file.includes('DailyChallengeDetailScreen')) {
    content = content.replace(
      /const handleAddReps = \(amount: number\) => \{\n    if \(isCompleted \|\| hasClaimedToday \|\| cooldown > 0\) return;\n/g,
      `const handleAddReps = (amount: number) => {\n    if (isCompleted || hasClaimedToday || cooldown > 0) return;\n    if (checkCheat(amount)) {\n      const updated = { ...challenge };\n      updated.exercises[0].completedReps = 0;\n      onUpdate(updated);\n      return;\n    }\n`
    );
  } else if (file.includes('SpeedChallengeScreen')) {
    content = content.replace(
      /const handleAddReps = \(amount: number\) => \{\n    if \(isCompleted \|\| hasClaimedToday \|\| showCheatWarning \|\| showFail\) return;\n    \n    if \(amount === 1 && cooldown1 > 0\) return;\n/g,
      `const handleAddReps = (amount: number) => {\n    if (isCompleted || hasClaimedToday || showCheatWarning || showFail) return;\n    if (amount === 1 && cooldown1 > 0) return;\n    if (checkCheat(amount)) {\n      const updated = { ...challenge };\n      updated.exercises[0].completedReps = 0;\n      onUpdate(updated);\n      return;\n    }\n`
    );
  } else if (file.includes('StrengthChallengeScreen')) {
    content = content.replace(
      /const handleAddReps = \(amount: number\) => \{\n    if \(isCompleted \|\| hasClaimedToday \|\| showCheatWarning\) return;\n    \n    if \(amount === 1 && cooldown1 > 0\) return;\n/g,
      `const handleAddReps = (amount: number) => {\n    if (isCompleted || hasClaimedToday || showCheatWarning) return;\n    if (amount === 1 && cooldown1 > 0) return;\n    if (checkCheat(amount)) {\n      const updated = { ...challenge };\n      updated.exercises[0].completedReps = 0;\n      onUpdate(updated);\n      return;\n    }\n`
    );
  } else if (file.includes('WeeklyChallengeScreen')) {
    content = content.replace(
      /const handleAddReps = \(amount: number\) => \{\n    if \(isCompleted \|\| hasClaimedThisWeek \|\| showCheatWarning\) return;\n    \n    if \(amount === 1 && cooldown1 > 0\) return;\n/g,
      `const handleAddReps = (amount: number) => {\n    if (isCompleted || hasClaimedThisWeek || showCheatWarning) return;\n    if (amount === 1 && cooldown1 > 0) return;\n    if (checkCheat(amount)) {\n      const updated = { ...challenge };\n      updated.exercises[0].completedReps = 0;\n      onUpdate(updated);\n      return;\n    }\n`
    );
  } else if (file.includes('CustomChallengeDetailScreen')) {
    content = content.replace(
      /const handleAddReps = \(exerciseIndex: number, amount: number\) => \{\n    if \(isCompleted \|\| hasClaimed \|\| showCheatWarning\) return;\n    \n    if \(amount === 1 &&/g,
      `const handleAddReps = (exerciseIndex: number, amount: number) => {\n    if (isCompleted || hasClaimed || showCheatWarning) return;\n    if (checkCheat(amount)) {\n      const updated = { ...challenge };\n      updated.exercises[exerciseIndex].completedReps = 0;\n      onUpdate(updated);\n      return;\n    }\n    if (amount === 1 &&`
    );
  }

  fs.writeFileSync(file, content);
});
