const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

const verificationModalJSX = `        {verificationData && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-[#111] border border-brand-accent/50 p-6 rounded-3xl w-full max-w-sm shadow-[0_0_50px_rgba(20,241,225,0.1)]">
              <ShieldAlert className="w-12 h-12 text-brand-accent mx-auto mb-4" />
              <h3 className="text-xl font-black text-white uppercase tracking-wider mb-2 text-center">Activity Verification</h3>
              <p className="text-neutral-400 text-sm mb-6 text-center">
                {verificationData.isFlagged 
                  ? "Your account is flagged. Please verify this activity to continue counting." 
                  : "Unusually fast completion detected. Please verify your activity."}
              </p>
              
              <div className="space-y-4 mb-6">
                <div>
                  <label className="text-xs text-neutral-500 font-bold uppercase mb-1 block">Reps Completed</label>
                  <input 
                    type="number" 
                    value={verifyReps}
                    onChange={(e) => setVerifyReps(e.target.value)}
                    placeholder={verificationData.amount.toString()}
                    className="w-full bg-black border border-white/10 rounded-xl p-3 text-white focus:border-brand-accent outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs text-neutral-500 font-bold uppercase mb-1 block">Time Taken (minutes)</label>
                  <input 
                    type="number" 
                    value={verifyDuration}
                    onChange={(e) => setVerifyDuration(e.target.value)}
                    placeholder="e.g. 15"
                    className="w-full bg-black border border-white/10 rounded-xl p-3 text-white focus:border-brand-accent outline-none"
                  />
                </div>
              </div>

              {verifyError && <p className="text-red-500 text-xs mb-4 text-center">{verifyError}</p>}

              <div className="flex gap-3">
                <button 
                  onClick={() => {
                    setVerificationData(null);
                    setVerifyDuration("");
                    setVerifyReps("");
                    setVerifyError("");
                  }} 
                  className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-white font-bold rounded-xl text-xs uppercase tracking-wider transition"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => {
                    const reps = parseInt(verifyReps) || verificationData.amount;
                    const duration = parseInt(verifyDuration);
                    if (!duration || duration <= 0) {
                      setVerifyError("Please enter a valid duration.");
                      return;
                    }
                    // Simple check: nobody does 100 reps in 1 minute, minimum realistic is ~2-3 secs per rep
                    const secsPerRep = (duration * 60) / reps;
                    if (secsPerRep < 0.5) {
                      setVerifyError("Time entered is still physically impossible.");
                      return;
                    }
                    
                    // Approved
                    setVerificationData(null);
                    setVerifyDuration("");
                    setVerifyReps("");
                    setVerifyError("");
                    
                    // Handle adding reps with bypassVerification = true
                    handleAddReps(verificationData.exercise, reps, true);
                  }} 
                  className="flex-1 py-3 bg-brand-accent hover:bg-brand-accent-hover text-black font-black rounded-xl text-xs uppercase tracking-wider transition"
                >
                  Verify
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
`;

content = content.replace('{showCheatWarning && (', verificationModalJSX + '\n        {showCheatWarning && (');
fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', content);
