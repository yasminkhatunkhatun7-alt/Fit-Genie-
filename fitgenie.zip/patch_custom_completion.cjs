const fs = require('fs');
let code = fs.readFileSync('src/components/CustomChallengeDetailScreen.tsx', 'utf8');

const completionUIRegex = /{justClaimed \? \([\s\S]*?Reward claimed for this challenge.\n                <\/p>\n              <\/div>\n            \)}/g;

const newCompletionUI = `
            <div className="text-center space-y-4 relative z-10">
              <div className="inline-block px-4 py-1.5 bg-[#14F1E1]/20 text-[#14F1E1] rounded-full text-xs font-black uppercase tracking-widest border border-[#14F1E1]/30">
                Goal Completed
              </div>
              <p className="text-neutral-400 font-bold uppercase tracking-widest text-xs leading-relaxed mt-4">
                Personal goal achieved.<br/>No XP awarded for custom challenges.
              </p>
            </div>
`;
code = code.replace(completionUIRegex, newCompletionUI);

// Remove the Mission Reward block completely from the screen
const rewardBlockRegex = /{\/\* MISSION REWARD \*\/}[\s\S]*?<\/div>\n\n      {\/\* OVERALL PROGRESS \*\//g;
code = code.replace(rewardBlockRegex, '{/* OVERALL PROGRESS */');

fs.writeFileSync('src/components/CustomChallengeDetailScreen.tsx', code);
