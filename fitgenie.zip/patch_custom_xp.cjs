const fs = require('fs');
let code = fs.readFileSync('src/components/CustomChallengeDetailScreen.tsx', 'utf8');

// Replace the handleClaimXP function and state logic
const claimXPRegex = /const handleClaimXP = \(\) => \{[\s\S]*?setShowCompletion\(true\);\n  \};/;
const newHandleClaimXP = `
  const handleClaimXP = () => {
    playSound("success");
    if (!hasClaimed) {
      localStorage.setItem(claimedKey, "true");
      onComplete(0);
      setHasClaimed(true);
      setJustClaimed(true);
    }
    setShowHonorValidation(false);
    setShowCompletion(true);
  };
`;
code = code.replace(claimXPRegex, newHandleClaimXP);

// Replace showHonorValidation UI
const honorValidationRegex = /if \(showHonorValidation\) \{[\s\S]*?  \}/;
const newHonorValidationUI = `
  if (showHonorValidation) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/95 flex flex-col items-center justify-center p-6 backdrop-blur-md">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-[#050B1A] border border-[#14F1E1]/30 shadow-[0_0_40px_rgba(20,241,225,0.2)] rounded-3xl p-6 text-center max-w-sm w-full relative"
        >
          <Target className="w-16 h-16 text-[#14F1E1] mx-auto mb-4" />
          <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-4">🎯 Challenge Completed!</h2>
          <div className="text-neutral-300 text-sm mb-6 leading-relaxed space-y-4 text-left">
            <p className="text-center">Great work. You completed your personal goal.</p>
            <p className="text-center text-red-400 font-bold">Custom Challenges do not award XP.</p>
            <div className="bg-white/5 p-4 rounded-xl border border-white/10 mt-4">
              <p className="text-xs font-bold uppercase tracking-widest text-neutral-400 mb-2">Fit Genie XP can only be earned from:</p>
              <ul className="text-xs font-medium space-y-2 text-white">
                <li className="flex items-center gap-2">✅ Daily Challenges</li>
                <li className="flex items-center gap-2">✅ Strength Challenges</li>
                <li className="flex items-center gap-2">✅ Speed Challenges</li>
                <li className="flex items-center gap-2">✅ Weekly Challenges</li>
              </ul>
            </div>
            <p className="text-center text-xs text-neutral-400 italic">Continue training and earn XP through official challenges.</p>
          </div>
          
          <button 
            onClick={handleClaimXP}
            className="w-full py-4 bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-sm uppercase tracking-widest rounded-xl transition-all shadow-[0_0_20px_rgba(20,241,225,0.4)] flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-5 h-5" /> Mark Complete
          </button>
        </motion.div>
      </div>
    );
  }
`;
code = code.replace(honorValidationRegex, newHonorValidationUI);

// Replace imports to include CheckCircle2
if (!code.includes("CheckCircle2")) {
  code = code.replace("Sword, Activity", "Sword, Activity, CheckCircle2");
}

fs.writeFileSync('src/components/CustomChallengeDetailScreen.tsx', code);
