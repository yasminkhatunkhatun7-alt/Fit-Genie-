const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

const tabButtons = `          <button 
            onClick={() => setActiveTab("network")}
            className={\`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all \${activeTab === 'network' ? 'bg-[#4DA8FF] text-white' : 'text-neutral-500 hover:text-white'}\`}
          >
            Add
          </button>
          <button 
            onClick={() => setActiveTab("friends")}
            className={\`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all \${activeTab === 'friends' ? 'bg-emerald-500 text-white' : 'text-neutral-500 hover:text-white'}\`}
          >
            Friends
          </button>`;

code = code.replace(
  /<button \n\s*onClick=\{\(\) => setActiveTab\("network"\)\}\n\s*className=\{`px-4 py-2 rounded-lg text-\[10px\] font-black uppercase tracking-widest transition-all \$\{activeTab === 'network' \? 'bg-\[#4DA8FF\] text-white' : 'text-neutral-500 hover:text-white'\}`\}\n\s*>\n\s*Network\n\s*<\/button>/g,
  tabButtons
);

fs.writeFileSync('src/components/WorldChat.tsx', code);
