const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

const targetHeader = `{/* HEADER */}
      <div className="flex flex-col items-center justify-center pt-2 pb-4 border-b border-brand-border/40 shrink-0">
        <h1 className="text-2xl font-black uppercase text-white tracking-tight flex items-center gap-2 drop-shadow-[0_0_10px_rgba(20,241,225,0.4)]">
          <Globe className="w-6 h-6 text-[#14F1E1]" /> WORLD
        </h1>
        <p className="text-[#9CA3AF] text-[10px] font-bold uppercase tracking-widest mt-1">
          Global Connect • Live
        </p>
      </div>`;

const replaceHeader = `{/* HEADER */}
      <div className="flex flex-col items-center justify-center pt-2 pb-4 border-b border-brand-border/40 shrink-0">
        <h1 className="text-2xl font-black uppercase text-white tracking-tight flex items-center gap-2 drop-shadow-[0_0_10px_rgba(20,241,225,0.4)]">
          <Globe className="w-6 h-6 text-[#14F1E1]" /> WORLD
        </h1>
        
        {/* Tabs */}
        <div className="flex w-full mt-4 bg-brand-surface rounded-xl p-1 border border-brand-border">
          <button 
            onClick={() => { playSound("click"); setActiveTab("chat"); }}
            className={\`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-lg flex items-center justify-center gap-2 transition-all \${activeTab === "chat" ? "bg-brand-accent text-[#050B1A]" : "text-brand-muted hover:text-white"}\`}
          >
            <MessageSquare className="w-4 h-4" /> Live Chat
          </button>
          <button 
            onClick={() => { playSound("click"); setActiveTab("leaderboard"); }}
            className={\`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-lg flex items-center justify-center gap-2 transition-all \${activeTab === "leaderboard" ? "bg-[#B66DFF] text-white" : "text-brand-muted hover:text-white"}\`}
          >
            <Trophy className="w-4 h-4" /> Leaderboard
          </button>
        </div>
      </div>`;

if (code.includes('Global Connect • Live')) {
  code = code.replace(targetHeader, replaceHeader);
}

const targetChatBody = `<div className="mt-2 bg-brand-surface/50 border border-brand-accent/20 rounded-xl p-3 flex gap-3 items-center shrink-0">`;
const targetChatEnd = `      </form>
    </div>
  );
}`;

const parts = code.split(targetChatBody);
if (parts.length === 2) {
  let chatBodyAndEnd = parts[1];
  const endParts = chatBodyAndEnd.split('</form>');
  if (endParts.length === 2) {
    const newChatBody = `{activeTab === "chat" ? (
        <>
          <div className="mt-2 bg-brand-surface/50 border border-brand-accent/20 rounded-xl p-3 flex gap-3 items-center shrink-0">` + endParts[0] + `</form>
        </>
      ) : (
        <div className="flex-1 overflow-y-auto mt-4 space-y-3 pr-1 pb-4 flex flex-col custom-scrollbar">
          <div className="bg-[#B66DFF]/10 border border-[#B66DFF]/30 rounded-xl p-3 flex gap-3 items-center shrink-0 mb-2">
            <Award className="w-6 h-6 text-[#B66DFF] shrink-0" />
            <p className="text-[9px] uppercase tracking-widest font-black text-[#B66DFF] leading-relaxed">
              Global Athlete Leaderboard. Ranked by total XP gained from completed workout sessions.
            </p>
          </div>
          
          {leaderboardLoading ? (
            <div className="flex-1 flex flex-col items-center justify-center text-brand-muted opacity-50">
              <Loader2 className="w-8 h-8 animate-spin mb-4" />
              <p className="text-xs uppercase font-bold tracking-widest">Loading Rankings...</p>
            </div>
          ) : leaderboard.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-brand-muted opacity-50">
              <Trophy className="w-12 h-12 mb-4 opacity-50" />
              <p className="text-xs uppercase font-bold tracking-widest text-center">No athletes ranked yet.</p>
            </div>
          ) : (
            <AnimatePresence initial={false}>
              {leaderboard.map((athlete, index) => {
                const isMe = (user?.id || localStorage.getItem("fitgenie_anon_id")) === athlete.userId;
                return (
                  <motion.div
                    layout
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={athlete.userId}
                    className={\`flex items-center gap-4 p-3 rounded-2xl border \${isMe ? 'bg-[#B66DFF]/20 border-[#B66DFF]/50 shadow-[0_0_15px_rgba(182,109,255,0.2)]' : 'bg-brand-surface border-brand-border'}\`}
                  >
                    <div className="w-8 flex justify-center font-black text-xl text-neutral-500 italic">
                      #{index + 1}
                    </div>
                    <div className={\`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shrink-0 border-2 shadow-lg \${athlete.avatarBg}\`}>
                      {athlete.userName.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-white truncate text-sm">{athlete.userName}</h4>
                        {isMe && <span className="bg-[#B66DFF] text-white text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded-sm">You</span>}
                      </div>
                      <p className="text-[10px] uppercase tracking-widest font-bold text-[#B66DFF] mt-0.5">
                        {athlete.xp.toLocaleString()} XP
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          )}
        </div>
      )}` + endParts[1];
    
    fs.writeFileSync('src/components/WorldChat.tsx', parts[0] + newChatBody);
    console.log("Patched UI");
  }
}

