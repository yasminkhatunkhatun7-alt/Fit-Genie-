const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');

const pushupChallenge = `
    {
      id: "pushup",
      title: "Pushup Challenge",
      desc: "100 Pushups as fast as possible",
      xp: 200,
      difficulty: "Hard",
      icon: <Dumbbell className="w-5 h-5" />,
      gradient: "from-red-500/20 to-[#050B1A]",
      iconBg: "bg-red-500/20 text-red-500",
      exercises: [{ name: "Pushups", targetReps: 100, completedReps: 0 }]
    },`;

code = code.replace(
  'id: "speed",',
  'id: "pushup",' + pushupChallenge.replace('id: "pushup",', 'id: "pushup",') + '\n    {\n      id: "speed",'
);

code = code.replace(
  /if \(activeChallenge.id === 'strength'\) \{/,
  "if (activeChallenge.id === 'strength' || activeChallenge.id === 'pushup') {"
);

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
console.log('Added Pushup Challenge');
