const fs = require('fs');

// 1. WorldChat.tsx - Empty state for Feed and Leaderboard
let worldChat = fs.readFileSync('src/components/WorldChat.tsx', 'utf8');
if (!worldChat.includes("No activity yet")) {
  worldChat = worldChat.replace(
    '{feed.length === 0 && !loading && (',
    '{feed.length === 0 && !loading && (\n                  <div className="py-12 flex flex-col items-center justify-center text-center opacity-50">\n                    <Activity className="w-12 h-12 text-brand-muted mb-3" />\n                    <p className="text-sm font-bold uppercase tracking-widest text-brand-muted">No activity yet — be the first to post!</p>\n                  </div>\n                )}\n                {feed.length === 0 && loading && (' // just in case
  );
  fs.writeFileSync('src/components/WorldChat.tsx', worldChat);
}

// 2. ProfileView.tsx - Empty states
let profileView = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');
if (!profileView.includes("No followers yet")) {
  profileView = profileView.replace(
    '<p className="text-xs font-bold uppercase tracking-widest text-brand-muted">No users found</p>',
    '<p className="text-xs font-bold uppercase tracking-widest text-brand-muted">{activeList === "followers" ? "No followers yet — invite friends to join your journey!" : "You\'re not following anyone yet — find athletes to follow!"}</p>'
  );
  profileView = profileView.replace(
    '<p className="text-xs font-bold uppercase tracking-widest text-brand-muted">No Workouts Yet</p>',
    '<p className="text-xs font-bold uppercase tracking-widest text-brand-muted">No workouts logged yet — start your first session!</p>'
  );
  fs.writeFileSync('src/components/ProfileView.tsx', profileView);
}

// 3. WorkoutHistory.tsx - Empty state
let workoutHistory = fs.readFileSync('src/components/WorkoutHistory.tsx', 'utf8');
if (!workoutHistory.includes("No workouts logged yet")) {
  workoutHistory = workoutHistory.replace(
    '<p className="text-sm font-bold uppercase tracking-widest text-zinc-500">No sessions logged yet.</p>',
    '<p className="text-sm font-bold uppercase tracking-widest text-zinc-500">No workouts logged yet — start your first session!</p>'
  );
  fs.writeFileSync('src/components/WorkoutHistory.tsx', workoutHistory);
}

