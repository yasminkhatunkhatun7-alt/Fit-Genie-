const fs = require('fs');

let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

code = code.replace(/To continue, type exactly:/, 'To continue, type exactly:');

// Let's make sure Genie is the name in the component visually.
// If there are other "Guardian" references, we replace them.
code = code.replace(/>Guardian protects/g, '>Genie protects');
code = code.replace(/Guardian is watching/g, 'Genie is watching');
code = code.replace(/Guardian observes/g, 'Genie observes');

fs.writeFileSync('src/components/GuardianOrb.tsx', code);
