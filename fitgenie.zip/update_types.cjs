const fs = require('fs');
let content = fs.readFileSync('src/types.ts', 'utf8');
content = content.replace('| "calisthenics"', '| "calisthenics"\n  | "calisthenics_videos"');
fs.writeFileSync('src/types.ts', content);
