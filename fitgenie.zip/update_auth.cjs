const fs = require('fs');

let authContent = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

const signatureRegex = /updateProfileStats = async \(stats: \{[\s\S]*?consecutiveHonestDaysChange\?: number;\n  \}\) => \{/;

const newSignature = `updateProfileStats = async (stats: { 
    xpGained?: number; 
    workoutCompleted?: boolean;
    workoutCompletedOnTime?: boolean;
    dailyGoalCompleted?: boolean;
    challengeWon?: boolean; 
    streakChange?: number;
    completedWorkoutName?: string;
    goal?: string;
    theme?: string;
    taskClaimed?: string;
    integrityScoreChange?: number;
    integrityViolationsChange?: number;
    consecutiveHonestDaysChange?: number;
  }) => {`;

authContent = authContent.replace(signatureRegex, newSignature);

const profileInterfaceRegex = /completed_workouts\?: \{ date: string; exerciseName: string \}\[\];/;
authContent = authContent.replace(profileInterfaceRegex, `completed_workouts?: { date: string; exerciseName: string }[];
  recoveryWorkouts?: number;`);

const integrityLogicRegex = /const newIntegrityScore = Math\.max\(0, Math\.min\(100, \(profile\.integrityScore \?\? 100\) \+ \(stats\.integrityScoreChange \|\| 0\)\)\);/;

const newIntegrityLogic = `
      let baseIntegrityScore = profile.integrityScore ?? 100;
      let integrityGain = stats.integrityScoreChange || 0;
      
      const isCheating = (stats.integrityScoreChange || 0) < 0;
      const isHonestWorkout = !isCheating && (stats.workoutCompleted || stats.completedWorkoutName || stats.challengeWon);

      let newRecoveryWorkouts = profile.recoveryWorkouts || 0;
      
      if (isHonestWorkout) {
        integrityGain += 1;

        if (stats.workoutCompletedOnTime) {
          integrityGain += 2;
        }

        if (stats.dailyGoalCompleted) {
          integrityGain += 2;
        }

        if (resolvedStreak === 3 && (profile.streak || 0) === 2) {
          integrityGain += 5;
        } else if (resolvedStreak === 7 && (profile.streak || 0) === 6) {
          integrityGain += 10;
        } else if (resolvedStreak === 14 && (profile.streak || 0) === 13) {
          integrityGain += 15;
        } else if (resolvedStreak === 30 && (profile.streak || 0) === 29) {
          integrityGain += 25;
        }
      }

      if (baseIntegrityScore < 50) {
         if (isHonestWorkout) {
             newRecoveryWorkouts += 1;
             
             if (baseIntegrityScore === 0) {
                 if (newRecoveryWorkouts === 3) integrityGain = 15 - baseIntegrityScore;
                 else if (newRecoveryWorkouts === 7) integrityGain = 30 - baseIntegrityScore;
                 else if (newRecoveryWorkouts === 14) integrityGain = 50 - baseIntegrityScore;
             } else {
                 if (newRecoveryWorkouts === 3) integrityGain += 10;
                 else if (newRecoveryWorkouts === 7) integrityGain += 20;
                 else if (newRecoveryWorkouts === 14) integrityGain += 30;
             }
         }
      } else {
         newRecoveryWorkouts = 0;
      }
      
      const newIntegrityScore = Math.max(0, Math.min(100, baseIntegrityScore + integrityGain));
      
      if (integrityGain > 0) {
         window.dispatchEvent(new CustomEvent('trust_increase', { detail: { gain: integrityGain } }));
      }
`;

authContent = authContent.replace(integrityLogicRegex, newIntegrityLogic);

const updateDataRegex = /consecutiveHonestDays: newHonestDays\n      \};/;
const newUpdateData = `consecutiveHonestDays: newHonestDays,
        recoveryWorkouts: newRecoveryWorkouts
      };`;
authContent = authContent.replace(updateDataRegex, newUpdateData);

fs.writeFileSync('src/context/AuthContext.tsx', authContent);
