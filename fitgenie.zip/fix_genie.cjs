const fs = require('fs');
let code = fs.readFileSync('src/hooks/useGenieIntelligence.ts', 'utf8');
code = code.replace(
  "const { triggerEvent, setEmotion, setMessage, addObservation } = useGuardianContext();",
  "const { triggerEvent, setEmotion, setMessage, addObservation, evaluateRealism } = useGuardianContext();"
);

// We replace the evaluateWorkout function to use evaluateRealism
const evaluateWorkoutRegex = /const evaluateWorkout = \(exerciseName: string, amount: number, timeSpentMs\?: number\): number => \{[\s\S]*?\n  \};\n/m;

const newEvaluateWorkout = `const evaluateWorkout = (exerciseName: string, amount: number, timeSpentMs?: number): number => {
    const elapsedMs = timeSpentMs || (Date.now() - startTimeRef.current);
    const elapsedSeconds = Math.max(elapsedMs / 1000, 1);
    
    // Call the newly requested GuardianContext logic
    const realismScore = evaluateRealism(exerciseName, amount, elapsedSeconds);
    
    addObservation(\`Evaluated \${amount} reps of \${exerciseName} in \${Math.round(elapsedSeconds)}s. Score: \${realismScore}\`);
    
    // Level 4: Impossible
    if (realismScore < 40) {
      setSuspiciousPhase('alert');
      updateProfileStats({ integrityScoreChange: -10, integrityViolationsChange: 1, consecutiveHonestDaysChange: 0 });
      addObservation("Action marked as Impossible. 0 XP.");
      startTimeRef.current = Date.now();
      return 0; 
    } 
    // Level 3: Suspicious
    else if (realismScore < 75) {
      setSuspiciousPhase('alert');
      updateProfileStats({ integrityScoreChange: -5, integrityViolationsChange: 1 });
      addObservation("Action marked as Suspicious. Reduced rewards.");
      startTimeRef.current = Date.now();
      return 0.5;
    } 
    // Level 1-2: Realistic or fast but possible
    else {
      triggerEvent("happy", { message: "Great work bro." });
      updateProfileStats({ integrityScoreChange: 1 });
      addObservation("Action marked as Realistic.");
      startTimeRef.current = Date.now();
      return 1;
    }
  };
`;

code = code.replace(evaluateWorkoutRegex, newEvaluateWorkout);
fs.writeFileSync('src/hooks/useGenieIntelligence.ts', code);
