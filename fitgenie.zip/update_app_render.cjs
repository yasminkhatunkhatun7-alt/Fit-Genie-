const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const importStatement = `import CalisthenicsVideoLibrary from "./components/CalisthenicsVideoLibrary";\n`;
content = content.replace('import ExercisesLibrary', importStatement + 'import ExercisesLibrary');

content = content.replace(
  '{view === "calisthenics" && <ExercisesLibrary forceMode="calisthenics" onSaveSmartSession={handleSaveSmartSession} />}',
  '{view === "calisthenics" && <ExercisesLibrary forceMode="calisthenics" onSaveSmartSession={handleSaveSmartSession} />}\n                {view === "calisthenics_videos" && <CalisthenicsVideoLibrary />}'
);

fs.writeFileSync('src/App.tsx', content);
