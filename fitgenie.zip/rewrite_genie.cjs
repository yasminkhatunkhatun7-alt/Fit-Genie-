const fs = require('fs');

let code = `import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useGuardianContext } from "../context/GuardianContext";
import { useAuth } from "../context/AuthContext";
import { Shield, Target, Flame, Activity, CheckCircle, MessageSquare, X, Zap } from "lucide-react";

export default function GuardianOrb() {
  const { 
    emotion, 
    message, 
    isPanelOpen, 
    setIsPanelOpen, 
    activeWarning, 
    setActiveWarning,
    observations, setEmotion, setMessage 
  } = useGuardianContext();
  
  const { profile } = useAuth();
  const [apology, setApology] = useState("");
  const [apologyError, setApologyError] = useState(false);

  // Position
  const [position, setPosition] = useState({ x: window.innerWidth - 90, y: window.innerHeight - 180 });
  const constraintRef = useRef(null);

  useEffect(() => {
    const saved = localStorage.getItem("fitgenie_orb_position");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed.x === "number" && typeof parsed.y === "number") {
          setPosition({
            x: Math.min(Math.max(0, parsed.x), window.innerWidth - 80),
            y: Math.min(Math.max(0, parsed.y), window.innerHeight - 80),
          });
        }
      } catch (e) {}
    }
  }, []);

  useEffect(() => {
    if (profile?.last_workout_date) {
      const lastWorkout = new Date(profile.last_workout_date).getTime();
      const diff = Date.now() - lastWorkout;
      if (diff > 7 * 24 * 60 * 60 * 1000) {
        setEmotion("sleepy");
        setMessage("Where did you go?");
      } else if (diff > 3 * 24 * 60 * 60 * 1000) {
        setEmotion("sleepy");
        setMessage("Genie is getting bored.");
      } else if (diff > 24 * 60 * 60 * 1000) {
        setEmotion("sleepy");
        setMessage("Your muscles miss you.");
      }
    }
  }, [profile?.last_workout_date, setEmotion, setMessage]);

  const handleDragEnd = (e: any, info: any) => {
    const newPos = { x: position.x + info.offset.x, y: position.y + info.offset.y };
    setPosition(newPos);
    localStorage.setItem("fitgenie_orb_position", JSON.stringify(newPos));
  };

  const emotionColors = {
    sleepy: "rgba(100, 116, 139, 0.8)",
    happy: "rgba(20, 241, 225, 1)",
    focused: "rgba(77, 168, 255, 1)",
    thinking: "rgba(182, 109, 255, 1)",
    suspicious: "rgba(250, 204, 21, 1)",
    angry: "rgba(239, 68, 68, 1)",
    celebrating: "rgba(255, 184, 77, 1)",
  };
  const color = emotionColors[emotion] || emotionColors.focused;

  const handleApology = (e: React.FormEvent) => {
    e.preventDefault();
    if (apology === "SORRY FIT GENIE") {
      setActiveWarning(false);
      setApology("");
      setApologyError(false);
    } else {
      setApologyError(true);
    }
  };

  const renderEyes = () => {
    let leftEye = { scaleY: 1, rotate: 0, y: 0 };
    let rightEye = { scaleY: 1, rotate: 0, y: 0 };
    
    switch(emotion) {
      case 'sleepy': leftEye.scaleY = 0.1; rightEye.scaleY = 0.1; break;
      case 'happy': leftEye.scaleY = 0.6; rightEye.scaleY = 0.6; leftEye.y = -2; rightEye.y = -2; break;
      case 'focused': leftEye.scaleY = 1.2; rightEye.scaleY = 1.2; break;
      case 'thinking': leftEye.scaleY = 1; rightEye.scaleY = 0.4; leftEye.y = -2; break;
      case 'suspicious': leftEye.scaleY = 0.3; rightEye.scaleY = 0.3; leftEye.y = 1; rightEye.y = 1; break;
      case 'angry': leftEye.rotate = 20; rightEye.rotate = -20; leftEye.scaleY = 0.4; rightEye.scaleY = 0.4; break;
      case 'celebrating': leftEye.scaleY = 1.4; rightEye.scaleY = 1.4; leftEye.y = -3; rightEye.y = -3; break;
    }

    return (
      <div className="flex gap-2.5 z-20">
        <motion.div animate={leftEye} transition={{ duration: 0.3 }} className="w-2.5 h-4 bg-white rounded-full shadow-[0_0_10px_white]" />
        <motion.div animate={rightEye} transition={{ duration: 0.3 }} className="w-2.5 h-4 bg-white rounded-full shadow-[0_0_10px_white]" />
      </div>
    );
  };

  return (
    <>
      {activeWarning && (
        <AnimatePresence>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[10000] bg-black/90 backdrop-blur-md flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-[#050B1A] border border-red-500/30 rounded-3xl p-8 max-w-sm w-full text-center relative overflow-hidden shadow-[0_0_50px_rgba(239,68,68,0.2)]"
            >
              <div className="absolute top-0 left-0 right-0 h-1 bg-red-500 animate-pulse" />
              <div className="flex justify-center mb-6">
                <div className="w-24 h-24 rounded-full relative flex items-center justify-center" style={{ boxShadow: \`0 0 30px \${emotionColors.angry}, inset 0 0 40px \${emotionColors.angry}\` }}>
                  <div className="flex gap-3 z-20">
                    <motion.div animate={{ rotate: 25, scaleY: 0.3 }} className="w-3 h-5 bg-white rounded-full shadow-[0_0_15px_white]" />
                    <motion.div animate={{ rotate: -25, scaleY: 0.3 }} className="w-3 h-5 bg-white rounded-full shadow-[0_0_15px_white]" />
                  </div>
                </div>
              </div>
              <h2 className="text-2xl font-black text-red-500 uppercase tracking-wider mb-2">Genie is Angry</h2>
              <p className="text-neutral-300 font-medium mb-6">
                {message}
              </p>
              <div className="space-y-4">
                <p className="text-xs text-neutral-400 font-bold uppercase tracking-widest">Prove Your Honor</p>
                <form onSubmit={handleApology}>
                  <input 
                    type="text" 
                    value={apology}
                    onChange={(e) => setApology(e.target.value)}
                    placeholder="SORRY FIT GENIE"
                    className={\`w-full bg-black/50 border \${apologyError ? "border-red-500" : "border-neutral-800"} rounded-xl px-4 py-4 text-center font-mono text-white uppercase outline-none focus:border-red-500 transition-colors mb-4\`}
                  />
                  <button 
                    type="submit"
                    className="w-full bg-red-500 text-white font-black uppercase tracking-widest py-4 rounded-xl active:scale-95 transition-transform"
                  >
                    Confirm
                  </button>
                </form>
              </div>
            </motion.div>
          </motion.div>
        </AnimatePresence>
      )}

      {/* FLOATING ORB */}
      <div ref={constraintRef} className="fixed inset-0 pointer-events-none z-[9998]" />
      {!activeWarning && (
        <motion.div
          drag
          dragConstraints={constraintRef}
          onDragEnd={handleDragEnd}
          initial={position}
          animate={position}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsPanelOpen(true)}
          className="fixed z-[9998] cursor-pointer pointer-events-auto flex flex-col items-center group"
          style={{ width: 80, height: 80 }}
        >
          {/* Message Bubble */}
          <AnimatePresence>
            {message && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.8 }}
                animate={{ opacity: 1, y: -10, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.8 }}
                className="absolute bottom-[90px] whitespace-nowrap bg-black/80 backdrop-blur-md border border-[rgba(255,255,255,0.1)] px-4 py-2 rounded-2xl text-[11px] font-bold text-white tracking-wider pointer-events-none z-50 shadow-xl"
              >
                {message}
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-black/80 border-b border-r border-[rgba(255,255,255,0.1)] rotate-45" />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Genie Core */}
          <motion.div 
            className="w-20 h-20 rounded-full relative flex items-center justify-center overflow-hidden"
            animate={{
              boxShadow: [
                \`0 0 20px \${color}, inset 0 0 30px \${color}\`,
                \`0 0 50px \${color}, inset 0 0 60px \${color}\`,
                \`0 0 20px \${color}, inset 0 0 30px \${color}\`
              ],
              y: [0, -8, 0] // Floating motion
            }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          >
            {/* Breathing Core */}
            <motion.div 
              className="absolute inset-0 bg-white/20 rounded-full blur-md"
              animate={{ scale: [0.8, 1.1, 0.8], opacity: [0.3, 0.6, 0.3] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
            />
            
            <div className="absolute inset-0 bg-gradient-to-tr from-black/50 to-transparent z-10" />
            <div className="absolute inset-0 backdrop-blur-sm" />
            
            {/* Intelligent Eye Movement Wrapper */}
            <motion.div
              animate={{
                x: [0, 4, -4, 0, 0],
                y: [0, -2, 2, 0, 0]
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                times: [0, 0.2, 0.4, 0.6, 1],
                ease: "easeInOut"
              }}
              className="relative z-20"
            >
              {renderEyes()}
            </motion.div>
          </motion.div>
        </motion.div>
      )}

      {/* GENIE PANEL */}
      <AnimatePresence>
        {isPanelOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              onClick={() => setIsPanelOpen(false)}
              className="fixed inset-0 z-[9999] bg-black/70 backdrop-blur-md"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 z-[10000] bg-[#050B1A] border-t border-[rgba(20,241,225,0.2)] rounded-t-3xl max-h-[85vh] overflow-y-auto"
            >
              <div className="p-6 pb-24 space-y-6 max-w-md mx-auto relative">
                <button 
                  onClick={() => setIsPanelOpen(false)}
                  className="absolute top-6 right-6 w-8 h-8 rounded-full bg-neutral-900/50 flex items-center justify-center border border-neutral-800"
                >
                  <X className="w-4 h-4 text-neutral-400" />
                </button>
                
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full relative flex items-center justify-center" style={{ boxShadow: \`0 0 20px \${color}, inset 0 0 20px \${color}\` }}>
                     {renderEyes()}
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-white uppercase tracking-widest flex items-center gap-2">
                      GENIE
                    </h2>
                    <p className="text-[10px] text-[#14F1E1] font-bold uppercase tracking-widest mt-1">
                      Status: {emotion.toUpperCase()}
                    </p>
                  </div>
                </div>

                <div className="grid gap-4">
                  <div className="glass-card p-5 rounded-2xl border border-[rgba(77,168,255,0.2)] bg-[rgba(77,168,255,0.05)]">
                    <div className="flex items-center gap-3 mb-2">
                      <Shield className="w-5 h-5 text-[#4DA8FF]" />
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider">Trust Score</h3>
                    </div>
                    <div className="flex items-end gap-2">
                      <span className="text-4xl font-black font-mono text-[#4DA8FF]">{profile?.integrityScore || 100}%</span>
                    </div>
                    <p className="text-xs text-neutral-400 mt-2 font-medium">Genie protects the integrity of your gains.</p>
                  </div>

                  <div className="glass-card p-5 rounded-2xl border border-[rgba(20,241,225,0.2)] bg-[rgba(20,241,225,0.05)]">
                    <div className="flex items-center gap-3 mb-4">
                      <Activity className="w-5 h-5 text-[#14F1E1]" />
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider">Fitness Status</h3>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-[10px] text-neutral-400 uppercase tracking-widest font-bold">Level</p>
                        <p className="text-lg font-black text-white">{profile?.rank || "Beginner"}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-neutral-400 uppercase tracking-widest font-bold">XP</p>
                        <p className="text-lg font-black text-[#14F1E1] font-mono">{profile?.xp || 0}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-neutral-400 uppercase tracking-widest font-bold">Streak</p>
                        <p className="text-lg font-black text-[#B66DFF] font-mono">{profile?.streak || 0}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-neutral-400 uppercase tracking-widest font-bold">Workouts</p>
                        <p className="text-lg font-black text-white font-mono">{profile?.totalWorkouts || 0}</p>
                      </div>
                    </div>
                  </div>

                  <div className="glass-card p-5 rounded-2xl border border-[rgba(255,215,0,0.2)] bg-[rgba(255,215,0,0.05)]">
                    <div className="flex items-center gap-3 mb-2">
                      <Target className="w-5 h-5 text-[#FFD700]" />
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider">Current Mission</h3>
                    </div>
                    <p className="text-sm text-neutral-300 font-medium">
                      Keep training and build momentum. Genie is watching.
                    </p>
                  </div>

                  <div className="glass-card p-5 rounded-2xl border border-[rgba(182,109,255,0.2)] bg-[rgba(182,109,255,0.05)]">
                    <div className="flex items-center gap-3 mb-4">
                      <MessageSquare className="w-5 h-5 text-[#B66DFF]" />
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider">Recent Observations</h3>
                    </div>
                    {observations.length > 0 ? (
                      <ul className="space-y-3">
                        {observations.map((obs, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-neutral-300">
                            <Zap className="w-4 h-4 text-[#B66DFF] flex-shrink-0 mt-0.5" />
                            <span className="font-medium">{obs}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-sm text-neutral-500 font-medium">No recent observations.</p>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
`;

fs.writeFileSync('src/components/GuardianOrb.tsx', code);
