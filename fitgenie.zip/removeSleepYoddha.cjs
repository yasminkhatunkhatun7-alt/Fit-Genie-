const fs = require('fs');

let yh = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');

// 1. Remove sleep from subtabs
yh = yh.replace(/\| "sleep" /g, "");

// 2. Remove SleepLog interface and default logs
const sleepLogRegex = /interface SleepLog \{[\s\S]*?const DEFAULT_SLEEP_LOGS: SleepLog\[\] = \[[\s\S]*?\];\n/g;
yh = yh.replace(sleepLogRegex, "");

// 3. Remove state
yh = yh.replace(/  const \[sleepLogs, setSleepLogs\] = useLocalStorageSync<SleepLog\[\]>\("fitgenie_sleep_logs", DEFAULT_SLEEP_LOGS\);\n/g, "");
yh = yh.replace(/  \/\/ Sleep Logger input states\n  const \[sleepInTime, setSleepInTime\] = useState<string>\("22:30"\);\n  const \[sleepOutTime, setSleepOutTime\] = useState<string>\("06:30"\);\n/g, "");

// 4. Remove calculate sleep score logic
const addSleepRegex = /  \/\/ Calculate sleep score and write sleep log\n  const addSleepLogEntry = \(\) => \{[\s\S]*?  \};\n/g;
yh = yh.replace(addSleepRegex, "");

// 5. Remove sleep badge
const sleepBadgeRegex = /        \{\n        id: "b_sleep",[\s\S]*?        req: "Log an 8 hour quality sleep entry"\n      \},\n/g;
yh = yh.replace(sleepBadgeRegex, "");

// 6. Remove sleep tab item
yh = yh.replace(/          \{ id: "sleep", label: "🌙 Sleep Tracker", icon: "💤" \},\n/g, "");

// 7. Remove TAB 4
const tab4Regex = /          \{\/\* -----------------------------------------\n             TAB 4: SLEEP SYSTEM[\s\S]*?          \}\)\n/g;
yh = yh.replace(tab4Regex, "");

// 8. Remove sleep chart
const sleepChartRegex = /              \{\/\* Sleep log bar chart \*\/\}[\s\S]*?                <\/div>\n              <\/div>\n/g;
yh = yh.replace(sleepChartRegex, "");

fs.writeFileSync('src/components/YoddhaHub.tsx', yh);
