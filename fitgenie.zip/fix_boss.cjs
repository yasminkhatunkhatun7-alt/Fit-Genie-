const fs = require('fs');

let code = fs.readFileSync('src/components/DailyChallengeDetailScreen.tsx', 'utf8');

if (!code.includes('triggerEvent("boss_fight")') && !code.includes('triggerEvent("challenge_active")')) {
  if (!code.includes('useGuardianContext')) {
    code = code.replace(/import \{ useAuth \} from "\.\.\/context\/AuthContext";/, 'import { useAuth } from "../context/AuthContext";\nimport { useGuardianContext } from "../context/GuardianContext";');
  }

  code = code.replace(/const \{ profile \} = useAuth\(\);/, 'const { profile } = useAuth();\n  const { triggerEvent } = useGuardianContext();');
  
  const effectBlock = `  useEffect(() => {
    if (challenge.boss) {
      triggerEvent("boss_fight");
    } else {
      triggerEvent("challenge_active");
    }
  }, []);\n`;

  code = code.replace(/const \[hasClaimedToday, setHasClaimedToday\] = useState\(false\);/, 'const [hasClaimedToday, setHasClaimedToday] = useState(false);\n' + effectBlock);

  fs.writeFileSync('src/components/DailyChallengeDetailScreen.tsx', code);
}
