const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

// 1. imports
content = content.replace("import { useChallengeValidation } from '../hooks/useChallengeValidation';", "import { useGenieIntelligence } from '../hooks/useGenieIntelligence';\nimport GeniePenaltyModal from './GeniePenaltyModal';");

// 2. Remove validateReps
content = content.replace(/  const \{ logReps: validateReps \} = useChallengeValidation\(\{[\s\S]*?\}\);\n/, "");

// 3. Add useGenieIntelligence
const hookUsage = `
  const {
    cooldown,
    suspiciousPhase,
    lockEndTime,
    checkCheat,
    proceedFromAlert,
    proceedFromMotivation,
    submitApology,
    resetSessionTime
  } = useGenieIntelligence(challenge.id);
`;
content = content.replace(/  const storageKey = `onemonth_rpg_\$\{profile\?\.uid\}`;/, hookUsage + "\n  const storageKey = `onemonth_rpg_${profile?.uid}`;");

fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', content);
