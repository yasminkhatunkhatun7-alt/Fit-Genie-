const fs = require('fs');
let content = fs.readFileSync('src/components/WorkoutHistory.tsx', 'utf8');

// Replace in interface
content = content.replace(/  onNavigateToGenerator: \(\) => void;/g, '  onNavigateToExercises: () => void;');
// Replace in destructuring
content = content.replace(/  onNavigateToGenerator,/g, '  onNavigateToExercises,');
// Replace in StatsView prop
content = content.replace(/onNavigateToGenerator=\{onNavigateToGenerator\}/g, 'onNavigateToExercises={onNavigateToExercises}');
// Replace in button onClick
content = content.replace(/onClick=\{onNavigateToGenerator\}/g, 'onClick={onNavigateToExercises}');
// Replace button text
content = content.replace(/<span>Build Workout Routine<\/span>/g, '<span>View Exercises</span>');

fs.writeFileSync('src/components/WorkoutHistory.tsx', content);

// Now update App.tsx to pass onNavigateToExercises
let appContent = fs.readFileSync('src/App.tsx', 'utf8');
appContent = appContent.replace(
  /<WorkoutHistory\s+history=\{history\}\s+onDeleteSession=\{handleDeleteSession\}\s+onClearAll=\{handleClearHistory\}\s+onUpdateSession=\{handleUpdateSession\}\s+onSeedMockData=\{handleSeedMockData\}\s*\/>/m,
  `<WorkoutHistory
                    history={history}
                    onDeleteSession={handleDeleteSession}
                    onClearAll={handleClearHistory}
                    onUpdateSession={handleUpdateSession}
                    onSeedMockData={handleSeedMockData}
                    onNavigateToExercises={() => navigateToView("exercises")}
                  />`
);
fs.writeFileSync('src/App.tsx', appContent);
