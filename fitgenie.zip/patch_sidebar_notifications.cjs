const fs = require('fs');
let code = fs.readFileSync('src/components/SidebarSections.tsx', 'utf-8');

// 1. Add Firebase imports
const importsMatch = `import { handleSubscription } from "./PremiumGuard";`;
const importsNew = `import { handleSubscription } from "./PremiumGuard";
import { db } from "../lib/firebase";
import { collection, query, where, getDocs, orderBy, limit, doc, updateDoc } from "firebase/firestore";`;
if (!code.includes('import { db }')) {
  code = code.replace(importsMatch, importsNew);
}

// 2. Rewrite NotificationsSection
const notifMatch = `export function NotificationsSection() {
  const notifications = [
    { id: "n1", text: "New Exercise Videos added to library catalog! Check out custom Abs exercises now. 🍫", time: "Just Now", read: false },
    { id: "n2", text: "Pedometer steps goal check updated. Log steps or jogging to fulfill criteria! 👟", time: "2 hours ago", read: false },
    { id: "n3", text: "AI Coach completed analysis for custom Desi compound diet metrics profile.", time: "1 day ago", read: true },
    { id: "n4", text: "Congratulate your friends! Ranjeet completed deep 25 sets on local garden baithaks.", time: "2 days ago", read: true }
  ];

  return (`;

const notifNew = `export function NotificationsSection() {
  const { profile } = useAuth();
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNotifs = async () => {
      if (!profile?.uid) return;
      try {
        const q = query(
          collection(db, "notifications"), 
          where("toUserId", "==", profile.uid),
          orderBy("timestamp", "desc"),
          limit(20)
        );
        const snap = await getDocs(q);
        const fetched = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setNotifications(fetched);
      } catch(e) {
        console.error("Failed to fetch notifications", e);
      } finally {
        setLoading(false);
      }
    };
    fetchNotifs();
  }, [profile]);

  const markAsRead = async (notifId: string) => {
    try {
      await updateDoc(doc(db, "notifications", notifId), { read: true });
      setNotifications(prev => prev.map(n => n.id === notifId ? { ...n, read: true } : n));
    } catch (e) {}
  };

  const getTimeAgo = (ms: number) => {
    const diff = Math.floor((Date.now() - ms) / 60000); // minutes
    if (diff < 1) return "Just Now";
    if (diff < 60) return \`\${diff} mins ago\`;
    if (diff < 1440) return \`\${Math.floor(diff/60)} hours ago\`;
    return \`\${Math.floor(diff/1440)} days ago\`;
  };

  return (`;

if (!code.includes('setNotifications(fetched)')) {
  code = code.replace(notifMatch, notifNew);
}

// 3. Update the map logic
const mapMatch = `      <div className="space-y-3 pt-4">
        {notifications.map((not) => (
          <div
            key={not.id}
            className={\`p-3 rounded-2xl border transition-all \${
              not.read 
                ? "bg-brand-surface/40 border-brand-border/60 text-zinc-400" 
                : "bg-brand-surface border-brand-accent/20 hover:border-brand-accent/35 text-white"
            }\`}
          >
            <div className="flex justify-between items-start gap-2">
              <p className="text-[11px] leading-relaxed font-semibold">
                {not.text}
              </p>
              {!not.read && (
                <span className="w-2 h-2 rounded-full bg-brand-accent shrink-0 mt-1 animate-pulse" />
              )}
            </div>
            <p className="text-[9px] uppercase tracking-widest font-black text-brand-muted mt-2 opacity-70">
              {not.time}
            </p>
          </div>
        ))}
      </div>`;

const mapNew = `      <div className="space-y-3 pt-4 max-h-[60vh] overflow-y-auto custom-scrollbar pr-2">
        {loading ? (
           <div className="flex justify-center p-4"><span className="text-xs text-brand-muted uppercase font-bold tracking-widest">Loading...</span></div>
        ) : notifications.length === 0 ? (
           <div className="flex justify-center p-4"><span className="text-xs text-brand-muted uppercase font-bold tracking-widest">No notifications yet</span></div>
        ) : notifications.map((not) => (
          <div
            key={not.id}
            onClick={() => !not.read && markAsRead(not.id)}
            className={\`cursor-pointer p-3 rounded-2xl border transition-all \${
              not.read 
                ? "bg-brand-surface/40 border-brand-border/60 text-zinc-400" 
                : "bg-brand-surface border-brand-accent/20 hover:border-brand-accent/35 text-white"
            }\`}
          >
            <div className="flex justify-between items-start gap-2">
              <p className="text-[11px] leading-relaxed font-semibold">
                {not.type === "record_beaten" ? (
                   <span className="text-white font-bold">
                     <span className="text-[#14F1E1]">🔥 RECORD BEATEN!</span><br/>
                     {not.fromUserName} beat your {not.exerciseType} record ({not.oldScore} → {not.newScore})! Reclaim your spot?
                   </span>
                ) : (
                   not.text || not.title
                )}
              </p>
              {!not.read && (
                <span className="w-2 h-2 rounded-full bg-brand-accent shrink-0 mt-1 animate-pulse" />
              )}
            </div>
            <p className="text-[9px] uppercase tracking-widest font-black text-brand-muted mt-2 opacity-70">
              {not.timestamp ? getTimeAgo(not.timestamp) : not.time}
            </p>
          </div>
        ))}
      </div>`;

if (!code.includes('max-h-[60vh] overflow-y-auto custom-scrollbar')) {
  code = code.replace(mapMatch, mapNew);
}

fs.writeFileSync('src/components/SidebarSections.tsx', code);
console.log("Patched SidebarSections.tsx for notifications");
