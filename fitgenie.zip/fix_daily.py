import re

with open('src/components/DailyMissions.tsx', 'r') as f:
    content = f.read()

# Replace the block
pattern = re.compile(r'const todayStr = getLocalDateString\(\);.*?if \(lastDate !== todayStr\) {', re.DOTALL)

replacement = """
  const [todayStr, setTodayStr] = useState(getLocalDateString());

  useEffect(() => {
    const handleFocus = () => {
      const current = getLocalDateString();
      if (current !== todayStr) {
        setTodayStr(current);
      }
    };
    
    window.addEventListener('focus', handleFocus);
    window.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') handleFocus();
    });
    
    const interval = setInterval(handleFocus, 60000);
    return () => {
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('visibilitychange', handleFocus);
      clearInterval(interval);
    };
  }, [todayStr]);

  const [missions, setMissions] = useState<any>(null);
  const [missionState, setMissionState] = useState<Record<string, 'idle' | 'started' | 'completed'>>({});
  const [missionStreak, setMissionStreak] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);
  const [celebrationText, setCelebrationText] = useState("");
  const [loading, setLoading] = useState(true);
  const [rewardClaimed, setRewardClaimed] = useState(false);
  const [showClaimModal, setShowClaimModal] = useState(false);

  useEffect(() => {
    async function loadMissions() {
      if (!user) {
        const localHistory = JSON.parse(localStorage.getItem('fitgenie_mission_history') || '[]');
        const todaysMissions = await fetchOrGenerateMissions(todayStr, localHistory);
        setMissions(todaysMissions);

        let streak = Number(localStorage.getItem('fitgenie_mission_streak') || '0');
        const lastDate = localStorage.getItem('lastMissionResetDate') || '';

        if (lastDate && lastDate !== todayStr) {
          const prevState = JSON.parse(localStorage.getItem(`fitgenie_mission_state_${lastDate}`) || '{}');
          const prevCompleted = Object.values(prevState).filter(s => s === 'completed').length;
          
          const [y1, m1, d1] = todayStr.split('-').map(Number);
          const [y2, m2, d2] = lastDate.split('-').map(Number);
          const diff = Math.floor((Date.UTC(y1, m1 - 1, d1) - Date.UTC(y2, m2 - 1, d2)) / (1000 * 60 * 60 * 24));
          
          if (diff > 1 || prevCompleted === 0) {
            streak = 0;
            localStorage.setItem('fitgenie_mission_streak', '0');
          }
        }

        if (lastDate !== todayStr) {
          localStorage.setItem('lastMissionResetDate', todayStr);
        }

        const localState = JSON.parse(localStorage.getItem(`fitgenie_mission_state_${todayStr}`) || '{}');
        setMissionState(localState);
        setMissionStreak(streak);
        setRewardClaimed(localStorage.getItem(`fitgenie_mission_reward_claimed_${todayStr}`) === 'true');
        setLoading(false);
        return;
      }
      try {
        const ref = doc(db, 'users', user.uid, 'mission_data', 'status');
        const snap = await getDoc(ref);
        
        let history: string[] = [];
        let state: any = {};
        let streak = 0;
        let lastDate = "";
        let claimed = false;
        
        if (snap.exists()) {
          const data = snap.data();
          history = data.history || [];
          streak = data.streak || 0;
          lastDate = data.lastDate || "";
          
          if (lastDate === todayStr) {
            state = data.state || {};
            claimed = data.rewardClaimed || false;
          } else if (lastDate) {
            const prevState = data.state || {};
            const prevCompleted = Object.values(prevState).filter(s => s === 'completed').length;
            
            const [y1, m1, d1] = todayStr.split('-').map(Number);
            const [y2, m2, d2] = lastDate.split('-').map(Number);
            const diff = Math.floor((Date.UTC(y1, m1 - 1, d1) - Date.UTC(y2, m2 - 1, d2)) / (1000 * 60 * 60 * 24));
            
            if (diff > 1 || prevCompleted === 0) {
              streak = 0;
            }
          }
        }
        
        const todaysMissions = await fetchOrGenerateMissions(todayStr, history, user.uid);
        setMissions(todaysMissions);
        setMissionState(state);
        setMissionStreak(streak);
        setRewardClaimed(claimed);
        
        if (lastDate !== todayStr) {"""

new_content = pattern.sub(replacement, content)
with open('src/components/DailyMissions.tsx', 'w') as f:
    f.write(new_content)

