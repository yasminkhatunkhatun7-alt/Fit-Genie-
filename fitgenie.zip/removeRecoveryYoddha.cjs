const fs = require('fs');

let yh = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');

// 1. Remove recovery from subtabs array
yh = yh.replace(/\| "recovery" /g, "");

// 2. Remove recovery tab menu item
yh = yh.replace(/          \{ id: "recovery", label: "🧘 Recovery Center", icon: "🤸" \},\n/g, "");

// 3. Remove TAB 5 code
const tab5Regex = /          \{\/\* -----------------------------------------\n             TAB 5: RECOVERY CENTER[\s\S]*?          \}\)\n/g;
yh = yh.replace(tab5Regex, "");

fs.writeFileSync('src/components/YoddhaHub.tsx', yh);
