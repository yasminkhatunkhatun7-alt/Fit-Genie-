const fs = require('fs');
let code = fs.readFileSync('src/components/AiRepCounter.tsx', 'utf-8');

const oldOverlay = /{.*?REP COUNTER OVERLAY.*?\}[\s\S]*?<\/motion\.div>[\s\S]*?<\/div>/;
const newOverlay = `{/* REP COUNTER OVERLAY */}\n              <RepOverlay reps={reps} />`;

code = code.replace(oldOverlay, newOverlay);

fs.writeFileSync('src/components/AiRepCounter.tsx', code);
console.log('Replaced');
