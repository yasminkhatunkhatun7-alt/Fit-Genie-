const fs = require('fs');
let appCode = fs.readFileSync('src/App.tsx', 'utf8');

appCode = appCode.replace('  const { triggerEvent } = useGuardianContext();\n  const [showWelcome, setShowWelcome] = useState(false);', '  const [showWelcome, setShowWelcome] = useState(false);');

fs.writeFileSync('src/App.tsx', appCode);
