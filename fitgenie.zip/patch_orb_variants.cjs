const fs = require('fs');

let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

const variantsStr = `
const orbVariants = {
  focused: {
    y: [0, -6, 0],
    scale: 1,
    rotate: 0,
    transition: { duration: 4, repeat: Infinity, ease: "easeInOut" }
  },
  happy: {
    y: [0, -12, 0],
    scale: [1, 1.05, 1],
    rotate: 0,
    transition: { duration: 2, repeat: Infinity, ease: "easeInOut" }
  },
  thinking: {
    y: [0, -4, 0],
    scale: 1,
    rotate: [0, 5, -5, 0],
    transition: { duration: 2.5, repeat: Infinity, ease: "easeInOut" }
  },
  suspicious: {
    y: [0, 5, 0],
    scaleX: 1.05,
    scaleY: 0.95,
    rotate: 0,
    transition: { duration: 3, repeat: Infinity, ease: "easeInOut" }
  },
  angry: {
    x: [-3, 3, -3, 3, 0],
    y: 0,
    scale: 1.1,
    rotate: 0,
    transition: { duration: 0.2, repeat: Infinity, ease: "linear" }
  },
  sleepy: {
    y: [10, 15, 10],
    scale: 0.9,
    rotate: 0,
    transition: { duration: 6, repeat: Infinity, ease: "easeInOut" }
  },
  celebrating: {
    y: [0, -20, 0],
    scale: [1, 1.1, 1],
    rotate: [0, 10, -10, 0],
    transition: { duration: 1.2, repeat: Infinity, ease: "easeInOut" }
  }
};
`;

if (!code.includes('const orbVariants')) {
  code = code.replace('export default function GuardianOrb() {', variantsStr + '\nexport default function GuardianOrb() {');
}

const oldCore = `<motion.div 
            className="w-24 h-24 relative flex items-center justify-center"
            animate={{
              y: [0, -10, 0]
            }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          >`;

const newCore = `<motion.div 
            className="w-24 h-24 relative flex items-center justify-center origin-center"
            variants={orbVariants}
            animate={emotion}
          >`;

code = code.replace(oldCore, newCore);

fs.writeFileSync('src/components/GuardianOrb.tsx', code);
