const fs = require('fs');

let content = fs.readFileSync('src/components/DailyMissions.tsx', 'utf8');

// We need to import updateProfileStats
content = content.replace(
  'const { user, updateUserXP } = useAuth();',
  'const { user, updateProfileStats, updateUserXP } = useAuth();'
);

content = content.replace(
  'await updateUserXP(50);',
  'if (updateProfileStats) await updateProfileStats({ xpGained: 50, dailyGoalCompleted: true });\n        else await updateUserXP(50);'
);

fs.writeFileSync('src/components/DailyMissions.tsx', content);
