const fs = require('fs');
let content = fs.readFileSync('src/components/StatsView.tsx', 'utf8');

content = content.replace(/  onNavigateToGenerator: \(\) => void;/g, '  onNavigateToExercises: () => void;');
content = content.replace(/  onNavigateToGenerator,/g, '  onNavigateToExercises,');
content = content.replace(/onClick=\{onNavigateToGenerator\}/g, 'onClick={onNavigateToExercises}');
content = content.replace(/<span>Build Workout Routine<\/span>/g, '<span>View Exercises</span>');

fs.writeFileSync('src/components/StatsView.tsx', content);
