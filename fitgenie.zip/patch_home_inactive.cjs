const fs = require('fs');
let code = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

const oldEffect = `  useEffect(() => {
    triggerEvent("home_greet");
  }, []);`;

const newEffect = `  useEffect(() => {
    let daysInactive = 0;
    if (profile?.last_workout_date) {
      const lastWorkout = new Date(profile.last_workout_date);
      const today = new Date();
      // Compare by date only
      lastWorkout.setHours(0, 0, 0, 0);
      today.setHours(0, 0, 0, 0);
      daysInactive = Math.floor((today.getTime() - lastWorkout.getTime()) / (1000 * 60 * 60 * 24));
    }
    
    if (daysInactive >= 7) {
      triggerEvent("inactive_7");
    } else if (daysInactive >= 3) {
      triggerEvent("inactive_3");
    } else if (daysInactive >= 1) {
      triggerEvent("inactive_1");
    } else {
      triggerEvent("home_greet");
    }
  }, [profile?.last_workout_date]);`;

code = code.replace(oldEffect, newEffect);
fs.writeFileSync('src/components/HomeDashboard.tsx', code);
