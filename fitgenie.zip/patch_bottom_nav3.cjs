const fs = require('fs');
let content = fs.readFileSync('src/components/BottomNavigation.tsx', 'utf8');

const navItemsStr = `  const navItems = [
    {
      view: "home" as AppView,
      label: "Home",
      icon: <Home className="w-5 h-5" />,
    },
    {
      view: "dojo" as AppView,
      label: "Challenges",
      icon: <Swords className="w-5 h-5" />,
    },
    {
      view: "achievements" as AppView,
      label: "Trophies",
      icon: <Trophy className="w-5 h-5" />,
    },
    {
      view: "brocoach" as AppView,
      label: "Coach",
      icon: <MessageSquare className="w-5 h-5" />,
    },
    {
      view: "profile" as AppView,
      label: "Profile",
      icon: <User className="w-5 h-5" />,
    },
  ];`;

content = content.replace(/  const navItems = \[[\s\S]*?\];/, navItemsStr);
fs.writeFileSync('src/components/BottomNavigation.tsx', content);
