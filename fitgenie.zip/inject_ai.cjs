const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');

const tracker = `
        {/* Floating AI Camera Button */}
        {activeChallenge.exercises.some(e => e.name.toLowerCase().includes('pushup') || e.name.toLowerCase().includes('squat')) && !showAiCounter && (
          <motion.div
             initial={{ opacity: 0, scale: 0.8 }}
             animate={{ opacity: 1, scale: 1 }}
             className="fixed bottom-32 right-6 z-50 flex flex-col items-end gap-3"
          >
            {activeChallenge.exercises.map((ex, i) => {
              const exNameLower = ex.name.toLowerCase();
              if (exNameLower.includes('pushup') || exNameLower.includes('squat')) {
                return (
                  <button
                    key={i}
                    onClick={() => {
                      setAiExerciseIndex(i);
                      setShowAiCounter(true);
                    }}
                    className="bg-brand-accent text-brand-dark px-4 py-3 rounded-full font-black uppercase tracking-widest text-[10px] shadow-[0_0_20px_rgba(20,241,225,0.4)] flex items-center gap-2"
                  >
                    <Camera className="w-4 h-4" /> 
                    AI {ex.name} Tracker
                  </button>
                );
              }
              return null;
            })}
          </motion.div>
        )}

        {/* AI Rep Counter Modal */}
        {showAiCounter && (
          <AiRepCounter
             initialExercise={activeChallenge.exercises[aiExerciseIndex]?.name.toLowerCase().includes('squat') ? "Squats" : "Pushups"}
             onClose={() => setShowAiCounter(false)}
             onComplete={(reps) => {
               const updated = { ...activeChallenge };
               if (updated.exercises[aiExerciseIndex]) {
                 updated.exercises[aiExerciseIndex].completedReps += reps;
                 setActiveChallenge(updated);
               }
               setShowAiCounter(false);
             }}
          />
        )}
`;

const screens = [
  'DailyChallengeDetailScreen',
  'SpeedChallengeScreen',
  'WeeklyChallengeScreen',
  'OneMonthChallengeScreen',
  'StrengthChallengeScreen',
  'CustomChallengeDetailScreen'
];

screens.forEach(s => {
  const matchStr = '<' + s + '[\\s\\S]*?\\/>\\s*\\);';
  const regex = new RegExp(matchStr);
  const match = code.match(regex);
  if (match) {
    const original = match[0];
    const withoutClosing = original.substring(0, original.lastIndexOf(');'));
    const replaced = '<>\\n        ' + withoutClosing + '\\n' + tracker + '\\n      </>\\n      );';
    code = code.replace(original, replaced.replace(/\\n/g, '\n'));
  }
});

// also inject state if it's missing
if (!code.includes('showAiCounter')) {
  code = code.replace(
    'const [view, setView] = useState<"list" | "active" | "builder">("list");',
    'const [view, setView] = useState<"list" | "active" | "builder">("list");\n  const [showAiCounter, setShowAiCounter] = useState(false);\n  const [aiExerciseIndex, setAiExerciseIndex] = useState<number>(0);'
  );
}

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
console.log('injected properly');
