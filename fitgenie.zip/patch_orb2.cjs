const fs = require('fs');
let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf-8');

const target = `} else if (lastEvent.type === "VIEW_SECTION") {`;
const replace = `} else if (lastEvent.type === "CHALLENGE_COMPLETE") {
        newEmotion = "celebrating";
        newMsg = \`Challenge destroyed! Genie is proud of your consistency.\`;
      } else if (lastEvent.type === "VIEW_SECTION") {`;

if (code.includes(target)) {
  code = code.replace(target, replace);
  fs.writeFileSync('src/components/GuardianOrb.tsx', code);
  console.log("Patched GuardianOrb.tsx with CHALLENGE_COMPLETE");
}
