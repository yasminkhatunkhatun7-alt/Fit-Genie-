const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

code = code.replace(
  '  if (!user) {\n    return null;\n  }\n\n  \n\n  if (!isOnboardingDone) {\n    return <Onboarding onComplete={handleOnboardingComplete} />;\n  }',
  '  if (!user || !isOnboardingDone) {\n    return <Onboarding onComplete={handleOnboardingComplete} />;\n  }'
);

fs.writeFileSync('src/App.tsx', code);
