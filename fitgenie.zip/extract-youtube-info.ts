import fs from "fs";

const videos = [
  "62sm1cJzivQ", "vCWcYF5PiQg", "0kU-IJQs6Bk", "bmqSJSB0C8E", "ewSCQSE-kEM",
  "IGssbfjjc1Q", "Ou4mFyMmwE4", "tTIV6qVB59Y", "tIyMLHcJ_xQ", "RRQQgW9t--k",
  "fF0IgM71dUM", "B2UXMlFw-Mk", "XglujyVx-SI", "Vorr1jRrb9w", "ruu8XBkLVhg",
  "y-bxF4PCOJo", "MTJxrViWPj4", "Q2ClBRiRzJo", "-9rMGYdJwPE", "TCtuwk35bmk"
];

async function extractInfo(id: string) {
  const url = `https://www.youtube.com/watch?v=${id}`;
  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9"
      }
    });
    const html = await res.text();
    
    // Look for shortDescription
    const descMatch = html.match(/"shortDescription":"(.*?)"/);
    const desc = descMatch ? JSON.parse(`"${descMatch[1]}"`) : "";
    
    // Look for dynamic title
    const titleMatch = html.match(/"title":"(.*?)"/);
    const title = titleMatch ? JSON.parse(`"${titleMatch[1]}"`) : "";

    // Look for keywords
    const keywordsMatch = html.match(/"keywords":\s*\[(.*?)\]/);
    let keywords = "";
    if (keywordsMatch) {
      keywords = keywordsMatch[1];
    }

    return { id, title: title || "None", desc: desc || "None", keywords };
  } catch (err: any) {
    return { id, error: err.message };
  }
}

async function main() {
  const results = [];
  for (const id of videos) {
    console.log(`Processing ${id}...`);
    const info = await extractInfo(id);
    console.log(`Title: ${info.title}`);
    console.log(`Desc: ${info.desc.substring(0, 100)}...`);
    results.push(info);
    await new Promise(r => setTimeout(r, 500));
  }
  fs.writeFileSync("./real_youtube_metadata.json", JSON.stringify(results, null, 2));
  console.log("Completed!");
}

main();
