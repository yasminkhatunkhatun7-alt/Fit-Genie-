const fs = require('fs');

let code = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

const oldDecl = `  const { triggerEvent } = useGuardianContext();
  useEffect(() => {
    let daysInactive = 0;
    if (profile?.last_workout_date) {
      const lastWorkout = new Date(profile.last_workout_date);`;

const newDecl = `  const { triggerEvent } = useGuardianContext();
  const { profile, signOutUser } = useAuth();
  
  useEffect(() => {
    let daysInactive = 0;
    if (profile?.last_workout_date) {
      const lastWorkout = new Date(profile.last_workout_date);`;

code = code.replace(oldDecl, newDecl);
code = code.replace(`  const { profile, signOutUser } = useAuth();\n`, ''); // Remove duplicate if it's further down

fs.writeFileSync('src/components/HomeDashboard.tsx', code);
