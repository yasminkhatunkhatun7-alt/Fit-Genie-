const fs = require('fs');

let hd = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

const regex = /  \/\/ Muscle Group Recovery based on last 48 hours of logged workouts\n  const muscleRecoveryStates = useMemo\(\(\) => \{[\s\S]*?  \}, \[history\]\);\n/g;
hd = hd.replace(regex, "");

fs.writeFileSync('src/components/HomeDashboard.tsx', hd);
