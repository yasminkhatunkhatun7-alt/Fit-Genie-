const fs = require('fs');

const getRankDetails = `export function getRankDetails(xp: number) {
  if (xp >= 10000) return { title: "Ascended", next: "Max", base: 10000, nextXP: 99999, emoji: "✨" };
  if (xp >= 7500) return { title: "Mythic", next: "Ascended", base: 7500, nextXP: 10000, emoji: "🌟" };
  if (xp >= 5000) return { title: "Legend", next: "Mythic", base: 5000, nextXP: 7500, emoji: "👑" };
  if (xp >= 3000) return { title: "Titan", next: "Legend", base: 3000, nextXP: 5000, emoji: "🦁" };
  if (xp >= 2000) return { title: "Champion", next: "Titan", base: 2000, nextXP: 3000, emoji: "🏆" };
  if (xp >= 1000) return { title: "Elite", next: "Champion", base: 1000, nextXP: 2000, emoji: "⚔️" };
  if (xp >= 500) return { title: "Warrior", next: "Elite", base: 500, nextXP: 1000, emoji: "🗡️" };
  return { title: "Beginner", next: "Warrior", base: 0, nextXP: 500, emoji: "🌱" };
}`;

// Fix AuthContext.ts
let auth = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');
if (!auth.includes('getRankDetails')) {
  auth = auth + '\n' + getRankDetails + '\n';
  fs.writeFileSync('src/context/AuthContext.tsx', auth);
}

// Fix HomeDashboard.tsx
let home = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');
home = home.replace(/function getRankDetails[\s\S]*?return \{ title: "Beginner", next: "Warrior", base: 0, nextXP: 100, emoji: "🌱" \};\n  \}/, 
`import { getRankDetails } from "../context/AuthContext";`);
// But wait, it's inside the component probably? Let's just use regex carefully.
