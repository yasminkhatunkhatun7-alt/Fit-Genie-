const fs = require('fs');
let file = fs.readFileSync('src/components/GenieChat.tsx', 'utf8');

file = file.replace(
    'keywords: ["leaderboard", "rank", "streak", "xp"],',
    'keywords: ["leaderboard", "rank", "streak", "xp", "how does"],'
);

fs.writeFileSync('src/components/GenieChat.tsx', file);
