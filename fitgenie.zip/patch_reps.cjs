const fs = require('fs');
const files = [
  'src/components/DailyChallengeDetailScreen.tsx',
  'src/components/SpeedChallengeScreen.tsx',
  'src/components/StrengthChallengeScreen.tsx',
  'src/components/WeeklyChallengeScreen.tsx'
];

files.forEach(file => {
  if (!fs.existsSync(file)) return;
  let content = fs.readFileSync(file, 'utf8');
  
  if (content.includes('validateAndAddReps(exercise.name')) return;
  
  content = content.replace(
    /const handleAddReps = \(amount: number\) => \{\s*if \([\s\S]*?\) return;\s*/,
    match => match + 'validateAndAddReps(exercise.name, amount, undefined, () => {\n    '
  );
  
  content = content.replace(
    /(const submitManualReps = \(\) => \{)/,
    '});\n  };\n\n  $1'
  );

  fs.writeFileSync(file, content);
});

// CustomChallengeDetailScreen.tsx
const customFile = 'src/components/CustomChallengeDetailScreen.tsx';
if (fs.existsSync(customFile)) {
  let content = fs.readFileSync(customFile, 'utf8');
  if (!content.includes('validateAndAddReps(')) {
    content = content.replace(
      /const handleAddReps = \(exerciseIndex: number, amount: number\) => \{\s*if \(isCompleted\) return;\s*/,
      match => match + 'validateAndAddReps(challenge.exercises[exerciseIndex].name, amount, undefined, () => {\n    '
    );
    
    content = content.replace(
      /(const submitManualReps = \(\) => \{)/,
      '});\n  };\n\n  $1'
    );
    fs.writeFileSync(customFile, content);
  }
}
