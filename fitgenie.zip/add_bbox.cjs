const fs = require('fs');

let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

const faceRingCode = `                  {/* Face Confidence Ring */}
                  {(() => {
                    const lms = scanResult?.landmarks ? Object.values(scanResult.landmarks) as any[] : [];
                    if (lms.length === 0) return null;
                    const avgConfidence = lms.reduce((acc, curr) => acc + (curr?.confidence || 0), 0) / lms.length;
                    const centerX = lms.reduce((acc, curr) => acc + (curr?.x || 50), 0) / lms.length;
                    const centerY = lms.reduce((acc, curr) => acc + (curr?.y || 50), 0) / lms.length;
                    const isHighConfidence = avgConfidence >= 80;
                    
                    const bbox = scanResult?.faceBoundingBox;
                    if (bbox) {
                      return (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 1, type: "spring" }}
                          className={\`absolute pointer-events-none border-2 border-dashed \${
                            isHighConfidence ? 'border-green-500 shadow-[0_0_30px_rgba(34,197,94,0.3)] animate-pulse' : 'border-amber-500 shadow-[0_0_30px_rgba(245,158,11,0.3)] animate-pulse'
                          }\`}
                          style={{
                            left: \`\${bbox.left}%\`,
                            top: \`\${bbox.top}%\`,
                            width: \`\${bbox.right - bbox.left}%\`,
                            height: \`\${bbox.bottom - bbox.top}%\`,
                            zIndex: 5
                          }}
                        />
                      );
                    }
                    
                    return (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 1, type: "spring" }}
                        className={\`absolute rounded-[40%] pointer-events-none border-2 border-dashed \${
                          isHighConfidence ? 'border-green-500 shadow-[0_0_30px_rgba(34,197,94,0.3)] animate-pulse' : 'border-amber-500 shadow-[0_0_30px_rgba(245,158,11,0.3)] animate-pulse'
                        }\`}
                        style={{
                          left: \`\${centerX}%\`,
                          top: \`\${centerY}%\`,
                          width: '180px',
                          height: '220px',
                          transform: 'translate(-50%, -50%)',
                          zIndex: 5
                        }}
                      />
                    );
                  })()}`;

// Replace the face confidence ring
const oldFaceRingRegex = /\{\/\* Face Confidence Ring \*\/\}[^]+?return \([^]+?\}\)\(\)\}/m;

const startIdx = code.indexOf('{/* Face Confidence Ring */}');
if (startIdx !== -1) {
  const endMarker = '})()}';
  const endIdx = code.indexOf(endMarker, startIdx);
  if (endIdx !== -1) {
    code = code.substring(0, startIdx) + faceRingCode + code.substring(endIdx + endMarker.length);
  }
}

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done');
