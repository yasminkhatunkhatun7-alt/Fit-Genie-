const fs = require('fs');
let file = fs.readFileSync('src/types.ts', 'utf8');
if (!file.includes('"settings"')) {
  file = file.replace('"support"', '"support"\n  | "settings"');
  fs.writeFileSync('src/types.ts', file);
}
