const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

const newUseEffect = `    useEffect(() => {
    if (activeTab === "chat") {
      fetchMessages();
    } else if (activeTab === "leaderboard") {
      fetchLeaderboard();
    } else if (activeTab === "network") {
      // nothing for network
    } else if (activeTab === "friends") {
      fetchFriendRequests();
      fetchFriends();
    }
  }, [activeTab]);

  const fetchFriends = async () => {
    if (!profile?.friends || profile.friends.length === 0) {
      setFriendsList([]);
      return;
    }
    try {
      // Fetch details for all friends in chunks of 10 if needed, but since we are simple, we can do a simple in query or loop
      const friendsData: any[] = [];
      // Firestore 'in' query supports up to 10. To be safe, let's just fetch them individually or use a query if under 10.
      for (const friendId of profile.friends) {
        const friendSnap = await getDoc(doc(db, "users", friendId));
        if (friendSnap.exists()) {
          friendsData.push({ userId: friendSnap.id, ...friendSnap.data() });
        }
      }
      setFriendsList(friendsData);
    } catch (e) {
      console.error("Error fetching friends:", e);
    }
  };`;

code = code.replace(
  /    useEffect\(\(\) => \{\n\s*if \(activeTab === "chat"\) \{\n\s*fetchMessages\(\);\n\s*\} else if \(activeTab === "leaderboard"\) \{\n\s*fetchLeaderboard\(\);\n\s*\} else if \(activeTab === "network"\) \{\n\s*fetchFriendRequests\(\);\n\s*\}\n\s*\}, \[activeTab\]\);/g,
  newUseEffect
);

fs.writeFileSync('src/components/WorldChat.tsx', code);
