const fs = require('fs');
let content = fs.readFileSync('src/components/WorkoutHistory.tsx', 'utf8');

// Remove onNavigateToGenerator from interface
content = content.replace(/  onNavigateToGenerator: \(\) => void;\n/, '');

// Remove from destructuring
content = content.replace(/  onNavigateToGenerator,\n/, '');

// Find where it's used and replace with a different behavior or remove the button if not strictly needed.
// Or just rename the prop to onNavigateToHome and pass that from App.tsx.
