const fs = require('fs');
let code = fs.readFileSync('src/components/AiRepCounter.tsx', 'utf-8');

// We need to inject new state and UI.
// Let's do string replacement for the state variables.
const stateMatch = '  const [isActive, setIsActive] = useState(false);';
const stateNew = `  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<"free" | "test">("free");
  const [testTimeLeft, setTestTimeLeft] = useState<number | null>(null);
  const { updateUserProfileFields, profile } = useAuth();
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (mode === "test" && isActive && testTimeLeft !== null && testTimeLeft > 0) {
      timerRef.current = window.setInterval(() => {
        setTestTimeLeft(prev => {
          if (prev && prev <= 1) {
             setIsActive(false);
             // playSound("success");
             return 0;
          }
          return prev ? prev - 1 : 0;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isActive, mode, testTimeLeft]);
`;

if (!code.includes('const [mode, setMode] = useState')) {
  code = code.replace(stateMatch, stateNew);
}

// Update start button logic
const startBtnMatch = `onClick={() => setIsActive(!isActive)}`;
const startBtnNew = `onClick={() => {
                  if (!isActive && mode === "test") {
                    setTestTimeLeft(60);
                    setReps(0);
                    repStateRef.current.reps = 0;
                  }
                  setIsActive(!isActive);
                }}`;
code = code.replace(startBtnMatch, startBtnNew);


// Update handleSaveToLog
const saveMatch = `  const handleSaveToLog = async () => {
    if (reps === 0) return;
    if (onComplete) {
      onComplete(reps);
    }
  };`;
const saveNew = `  const handleSaveToLog = async () => {
    if (reps === 0) return;

    if (updateUserProfileFields && profile) {
      const updates: any = {};
      if (exercise === "Squats") {
        updates.totalSquats = (profile.totalSquats || 0) + reps;
        if (mode === "test" && reps > (profile.bestSquat1Min || 0)) {
          updates.bestSquat1Min = reps;
        }
      } else {
        updates.totalPushups = (profile.totalPushups || 0) + reps;
        if (mode === "test" && reps > (profile.bestPushup1Min || 0)) {
          updates.bestPushup1Min = reps;
        }
      }
      await updateUserProfileFields(updates).catch(console.error);
    }

    if (onComplete) {
      onComplete(reps);
    }
  };`;
code = code.replace(saveMatch, saveNew);

// Add mode toggle UI right above the Controls section:
const toggleMatch = `<div className="flex items-center gap-4 mb-6">
            <select`;
const toggleNew = `<div className="flex bg-white/5 rounded-xl p-1 mb-4">
            <button onClick={() => { setMode("free"); setTestTimeLeft(null); setIsActive(false); }} className={\`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all \${mode === "free" ? "bg-[#14F1E1] text-[#050B1A]" : "text-white hover:text-[#14F1E1]"}\`}>Free Flow</button>
            <button onClick={() => { setMode("test"); setTestTimeLeft(60); setIsActive(false); setReps(0); repStateRef.current.reps = 0; }} className={\`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all \${mode === "test" ? "bg-[#B66DFF] text-white" : "text-white hover:text-[#B66DFF]"}\`}>1-Min Test</button>
          </div>
          <div className="flex items-center gap-4 mb-6">
            <select`;
code = code.replace(toggleMatch, toggleNew);

// Add Timer Overlay UI
const repOverlayMatch = `{/* REP COUNTER OVERLAY */}
              <RepOverlay reps={reps} />`;
const repOverlayNew = `{/* REP COUNTER OVERLAY */}
              <RepOverlay reps={reps} />
              
              {mode === "test" && testTimeLeft !== null && (
                <div className="absolute top-8 left-1/2 -translate-x-1/2 bg-black/80 px-6 py-2 rounded-full border border-[#B66DFF]/50 shadow-[0_0_20px_rgba(182,109,255,0.4)] z-10 flex flex-col items-center">
                  <span className="text-[10px] text-[#B66DFF] font-black uppercase tracking-widest">Time Left</span>
                  <span className={\`text-3xl font-black \${testTimeLeft <= 10 ? "text-red-500 animate-pulse" : "text-white"}\`}>
                    00:{testTimeLeft.toString().padStart(2, '0')}
                  </span>
                </div>
              )}`;
code = code.replace(repOverlayMatch, repOverlayNew);

// Adjust test finished state text
const readyTextMatch = `<p className="text-white font-bold text-lg">Ready to track {exercise}</p>`;
const readyTextNew = `{mode === "test" && testTimeLeft === 0 ? (
                <>
                  <p className="text-white font-black text-2xl mb-2 text-[#B66DFF]">TEST COMPLETE</p>
                  <p className="text-white font-bold text-lg">You scored {reps} {exercise}!</p>
                </>
              ) : (
                <p className="text-white font-bold text-lg">Ready to track {exercise}</p>
              )}`;
code = code.replace(readyTextMatch, readyTextNew);

fs.writeFileSync('src/components/AiRepCounter.tsx', code);
console.log("Patched AiRepCounter.tsx");
