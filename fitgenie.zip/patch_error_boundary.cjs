const fs = require('fs');

let code = fs.readFileSync('src/components/ErrorBoundary.tsx', 'utf8');

code = code.replace(/FIT GENIE GUARDIAN SHIELD ACTIVE/, 'FIT GENIE SHIELD ACTIVE');

fs.writeFileSync('src/components/ErrorBoundary.tsx', code);
