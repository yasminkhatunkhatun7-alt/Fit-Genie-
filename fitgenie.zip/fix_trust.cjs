const fs = require('fs');

let authContent = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');
authContent = authContent.replace(
  /export function getTrustGrade[\s\S]*?\}\n/m,
  `export function getIntegrityData(score: number) {
  if (score >= 90) return { status: "Athlete 🏆", mood: "Proud", message: "Perfect discipline Boss." };
  if (score >= 80) return { status: "Something Feels Off 🤨", mood: "Watching", message: "Boss, kuch to gadbad lag rahi hai. Stay honest." };
  if (score >= 70) return { status: "Under Observation 👀", mood: "Suspicious", message: "Genie is monitoring your progress. Trust is unstable." };
  if (score >= 60) return { status: "Questionable Activity ⚠️", mood: "Concerned", message: "Boss, your behavior is becoming suspicious. Trust needs improvement." };
  if (score >= 50) return { status: "Red Flag User 🚩", mood: "Disappointed", message: "Too many unusual actions detected." };
  if (score >= 40) return { status: "Cheat Suspect 🚨", mood: "Annoyed", message: "Genie is losing confidence." };
  if (score >= 30) return { status: "Cheat Monster 👹", mood: "Angry", message: "Boss, this is getting serious." };
  if (score >= 20) return { status: "Fitness Criminal 😤", mood: "Very Angry", message: "Trust is critically damaged." };
  if (score >= 10) return { status: "Public Enemy 😈", mood: "Furious", message: "Genie no longer believes workout claims." };
  if (score >= 1) return { status: "Disowned By Genie 💔", mood: "Maximum Anger", message: "Boss... what happened to you?" };
  return { status: "Banned By Genie 💀", mood: "Nuclear", message: "Genie has completely lost trust." };
}

export function getTrustGrade(score: number): string {
  return getIntegrityData(score).status;
}
`
);

fs.writeFileSync('src/context/AuthContext.tsx', authContent);
