const fs = require('fs');
let code = fs.readFileSync('src/components/AiRepCounter.tsx', 'utf-8');

// Remove tasks-vision import
code = code.replace('import { FilesetResolver, PoseLandmarker, DrawingUtils } from "@mediapipe/tasks-vision";', '');

// Replace setup logic to use window.Pose and window.Camera
const setupRegex = /  \/\/ Load Model\s*useEffect\(\(\) => \{[\s\S]*?const detectPose = \(\) => \{/m;

const newSetup = `
  // Refs for mediapipe
  const poseRef = useRef<any>(null);
  const cameraRef = useRef<any>(null);

  // Setup MediaPipe Pose
  useEffect(() => {
    let isMounted = true;
    
    const setupMediaPipe = async () => {
      try {
        if (!(window as any).Pose) {
          console.error("MediaPipe Pose script not loaded from CDN.");
          return;
        }
        
        const pose = new (window as any).Pose({
          locateFile: (file: string) => {
            return \`https://cdn.jsdelivr.net/npm/@mediapipe/pose/\${file}\`;
          }
        });
        
        pose.setOptions({
          modelComplexity: 1,
          smoothLandmarks: true,
          enableSegmentation: false,
          smoothSegmentation: false,
          minDetectionConfidence: 0.5,
          minTrackingConfidence: 0.5
        });
        
        pose.onResults((results: any) => {
          if (!isMounted) return;
          processResults(results);
        });
        
        poseRef.current = pose;
        setModelLoading(false);
      } catch (err) {
        console.error("Error setting up MediaPipe:", err);
      }
    };
    
    setupMediaPipe();
    
    return () => {
      isMounted = false;
      if (poseRef.current) {
        poseRef.current.close();
      }
    };
  }, []);

  // Setup Camera
  useEffect(() => {
    if (!isActive || !poseRef.current || !videoRef.current) return;
    
    if (!(window as any).Camera) {
      console.error("MediaPipe Camera script not loaded from CDN.");
      return;
    }
    
    const camera = new (window as any).Camera(videoRef.current, {
      onFrame: async () => {
        if (poseRef.current && videoRef.current) {
          await poseRef.current.send({ image: videoRef.current });
        }
      },
      width: 640,
      height: 480,
      facingMode: facingMode
    });
    
    camera.start().then(() => {
      setCameraAccess(true);
    }).catch((err: any) => {
      console.warn("Camera access denied:", err);
      setCameraAccess(false);
      setIsActive(false);
    });
    
    cameraRef.current = camera;
    
    return () => {
      if (cameraRef.current) {
        cameraRef.current.stop();
      }
    };
  }, [isActive, facingMode]);

  const calculateAngle = (a: any, b: any, c: any) => {
    const radians = Math.atan2(c.y - b.y, c.x - b.x) - Math.atan2(a.y - b.y, a.x - b.x);
    let angle = Math.abs((radians * 180.0) / Math.PI);
    if (angle > 180.0) {
      angle = 360.0 - angle;
    }
    return angle;
  };

  const processResults = (results: any) => {
    if (!canvasRef.current || !videoRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set dimensions
    if (canvas.width !== videoRef.current.videoWidth) {
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
    }

    ctx.save();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw drawing_utils if available
    if (results.poseLandmarks && (window as any).drawConnectors && (window as any).drawLandmarks && (window as any).POSE_CONNECTIONS) {
       (window as any).drawConnectors(ctx, results.poseLandmarks, (window as any).POSE_CONNECTIONS, { color: '#14F1E1', lineWidth: 4 });
       (window as any).drawLandmarks(ctx, results.poseLandmarks, { color: '#B66DFF', lineWidth: 2, radius: 3 });
    }

    if (results.poseLandmarks) {
      const landmarks = results.poseLandmarks;
      if (exercise === "Pushups") {
        const leftShoulder = landmarks[11];
        const leftElbow = landmarks[13];
        const leftWrist = landmarks[15];
        if (leftShoulder && leftElbow && leftWrist && leftShoulder.visibility > 0.5 && leftElbow.visibility > 0.5 && leftWrist.visibility > 0.5) {
          setLowConfidence(false);
          const angle = calculateAngle(leftShoulder, leftElbow, leftWrist);
          updatePushupState(angle);
        } else {
          setLowConfidence(true);
        }
      } else if (exercise === "Squats") {
        const rightHip = landmarks[24];
        const rightKnee = landmarks[26];
        const rightAnkle = landmarks[28];
        if (rightHip && rightKnee && rightAnkle && rightHip.visibility > 0.5 && rightKnee.visibility > 0.5 && rightAnkle.visibility > 0.5) {
          setLowConfidence(false);
          const angle = calculateAngle(rightHip, rightKnee, rightAnkle);
          updateSquatState(angle);
        } else {
          setLowConfidence(true);
        }
      }
    } else {
      setLowConfidence(true);
    }
    ctx.restore();
  };

  // Dummy detectPose just to keep reference happy if needed
  const detectPose = () => {
`;

if (code.match(setupRegex)) {
  code = code.replace(setupRegex, newSetup);
  fs.writeFileSync('src/components/AiRepCounter.tsx', code);
  console.log("Updated AiRepCounter setup!");
} else {
  console.log("Could not find regex match!");
}
