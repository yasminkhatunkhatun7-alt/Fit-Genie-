const fs = require('fs');
let content = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');
content = content.replace(/\\`/g, '`');
content = content.replace(/\\\$/g, '$');
content = content.replace(/\.\.\/firebase/g, '../lib/firebase');
fs.writeFileSync('src/components/ProfileView.tsx', content);
