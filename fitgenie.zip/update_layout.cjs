const fs = require('fs');

let content = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

// Update delays
content = content.replace(/transition={{ delay: 0\.45 }}/, 'transition={{ delay: 0.35 }}');
content = content.replace(/transition={{ delay: 0\.5 }}/, 'transition={{ delay: 0.45 }}');
content = content.replace(/transition={{ delay: 0\.6 }}/, 'transition={{ delay: 0.55 }}');

// Update graph height
content = content.replace(/<div className="h-32 w-full">/, '<div className="h-48 w-full">');

fs.writeFileSync('src/components/HomeDashboard.tsx', content);
