const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

const newUI = `      {activeTab === "network" && (
        <div className="flex-1 overflow-y-auto mt-4 space-y-4 pr-1 pb-4 flex flex-col custom-scrollbar">
           <div className="bg-[#4DA8FF]/10 border border-[#4DA8FF]/30 rounded-xl p-3 flex gap-3 items-center shrink-0 mb-2">
             <UserPlus className="w-6 h-6 text-[#4DA8FF] shrink-0" />
             <p className="text-[9px] uppercase tracking-widest font-black text-[#4DA8FF] leading-relaxed">
               Search by exact Username or Fighter ID (e.g. #9021) to add friends.
             </p>
           </div>
           
           <form onSubmit={handleSearch} className="flex gap-2">
             <input
               type="text"
               value={searchQuery}
               onChange={(e) => setSearchQuery(e.target.value)}
               placeholder="Username or #1234..."
               className="flex-1 bg-brand-surface border border-brand-border rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-[#4DA8FF]"
             />
             <button type="submit" className="bg-[#4DA8FF] text-black px-4 py-2 rounded-xl font-bold uppercase text-xs flex items-center justify-center cursor-pointer hover:bg-blue-400">
               <Search className="w-4 h-4" />
             </button>
           </form>
           
           {searchResult && (
             <div className="bg-brand-surface border border-[#4DA8FF]/50 p-4 rounded-xl flex flex-col gap-4 mt-4">
               <div className="flex items-center justify-between">
                 <div className="flex items-center gap-3">
                   <div className={\`w-12 h-12 rounded-xl flex items-center justify-center font-black text-lg border-2 \${searchResult.avatarBg}\`}>
                      {searchResult.userName.charAt(0).toUpperCase()}
                   </div>
                   <div>
                     <h4 className="font-bold text-white flex items-center gap-2">
                        {searchResult.userName} 
                        {searchResult.fighterId && <span className="text-neutral-500 font-mono text-xs">{searchResult.fighterId}</span>}
                     </h4>
                     <p className="text-[10px] uppercase font-black text-brand-accent">{searchResult.xp} XP</p>
                   </div>
                 </div>
                 
                 {searchResult.userId !== currentUserId && (
                   <button
                     onClick={friendStatus === "none" ? sendFriendRequest : undefined}
                     disabled={friendStatus !== "none"}
                     className={\`px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider flex items-center gap-1 \${
                       friendStatus === 'friends' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50' :
                       friendStatus === 'pending' ? 'bg-neutral-800 text-neutral-400 border border-neutral-700' : 
                       'bg-[#4DA8FF] text-black hover:bg-blue-400'
                     }\`}
                   >
                     {friendStatus === 'friends' ? <><UserCheck className="w-4 h-4"/> Friends</> : 
                      friendStatus === 'pending' ? 'Pending...' : 
                      <><UserPlus className="w-4 h-4"/> Add</>}
                   </button>
                 )}
               </div>
             </div>
           )}
           
           {/* Incoming Requests Section */}
           {friendRequests.length > 0 && (
             <div className="mt-6">
               <h3 className="text-xs font-black uppercase tracking-widest text-neutral-500 mb-3 flex items-center gap-2">
                 <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                 Pending Requests ({friendRequests.length})
               </h3>
               <div className="space-y-2">
                 {friendRequests.map(req => (
                   <div key={req.id} className="bg-brand-surface border border-neutral-800 p-3 rounded-xl flex items-center justify-between">
                     <div>
                       <p className="font-bold text-sm text-white">
                         {req.fromName} <span className="text-neutral-500 text-xs font-mono ml-1">{req.fromFighterId}</span>
                       </p>
                       <p className="text-[10px] text-neutral-500 uppercase tracking-widest mt-0.5">Wants to be friends</p>
                     </div>
                     <div className="flex items-center gap-2">
                       <button onClick={() => acceptRequest(req)} className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center hover:bg-emerald-500/30">
                         <UserCheck className="w-4 h-4" />
                       </button>
                       <button onClick={() => rejectRequest(req.id)} className="w-8 h-8 rounded-lg bg-red-500/10 text-red-400 flex items-center justify-center hover:bg-red-500/20">
                         <span className="text-lg font-bold leading-none mb-1">×</span>
                       </button>
                     </div>
                   </div>
                 ))}
               </div>
             </div>
           )}
        </div>
      )}`;

code = code.replace(
  /\{activeTab === "network" && \([\s\S]*?\}\s*<\/div>\s*\)\}/g,
  newUI
);

fs.writeFileSync('src/components/WorldChat.tsx', code);
