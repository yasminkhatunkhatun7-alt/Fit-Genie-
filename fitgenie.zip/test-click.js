import puppeteer from 'puppeteer';

(async () => {
  try {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    page.on('console', msg => {
        if (msg.type() === 'error') console.log('ERROR:', msg.text());
    });
    page.on('pageerror', err => console.log('PAGE ERROR:', err.toString()));
    await page.goto('http://localhost:3000', { waitUntil: 'networkidle2' });
    
    // find the Library button
    const buttons = await page.$$('button');
    for (const btn of buttons) {
        const text = await page.evaluate(el => el.textContent, btn);
        if (text && text.includes('Library')) {
            console.log("Clicking Library");
            await btn.click();
            await new Promise(r => setTimeout(r, 1000));
        }
    }
    await browser.close();
  } catch (e) {
    console.error(e);
  }
})();
