const fs = require('fs');
const files = [
  'src/components/StrengthChallengeScreen.tsx',
  'src/components/DailyChallengeDetailScreen.tsx'
];

for (const file of files) {
  let code = fs.readFileSync(file, 'utf8');
  if (!code.includes('desc?: string;')) {
    code = code.replace(
      /exercises: \{ name: string; targetReps: number; completedReps: number \}\[\];/,
      'exercises: { name: string; targetReps: number; completedReps: number }[];\n  desc?: string;'
    );
    fs.writeFileSync(file, code);
  }
}
