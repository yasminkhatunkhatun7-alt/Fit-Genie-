const fs = require('fs');
const file = 'src/components/NutritionLog.tsx';
const originalCode = fs.readFileSync(file, 'utf8');

// We will find the return statement of NutritionLog (around line 200-300 probably)
const returnMatch = originalCode.match(/(\/\/\s*)?return \(\n\s*<div className="max-w-xl/);

if (!returnMatch) {
  console.log("Could not find return block, I will replace the wrapper styles manually.");
}
