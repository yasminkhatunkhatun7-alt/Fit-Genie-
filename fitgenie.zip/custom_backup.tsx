import MuscleSelector from "./MuscleSelector";
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Trophy, Target, ShieldAlert, Timer, Play, AlertTriangle, Crosshair, Sword, Activity } from "lucide-react";
import { playSound } from "../utils/audio";
import { useAuth } from "../context/AuthContext";
import { ActiveChallenge } from "./StrengthChallengeScreen";

interface CustomChallengeDetailScreenProps {
  challenge: ActiveChallenge;
  onUpdate: (updated: ActiveChallenge) => void;
  onBack: () => void;
  onComplete: (xpToAward: number) => void;
}

const BOSS_MAP: Record<string, string> = {
  "Chest": "IRON TITAN",
  "Back": "SHADOW BEAST",
  "Lats": "SHADOW BEAST",
  "Traps": "SHADOW BEAST",
  "Rear Delts": "SHADOW BEAST",
  "Biceps": "ARM REAPER",
  "Triceps": "ARM REAPER",
  "Forearms": "ARM REAPER",
  "Shoulders": "MOUNTAIN KING",
  "Abs": "CORE DESTROYER",
  "Lower Back": "CORE DESTROYER",
  "Quads": "LEG TITAN",
  "Hamstrings": "LEG TITAN",
  "Calves": "LEG TITAN",
  "Glutes": "LEG TITAN"
};

export default function CustomChallengeDetailScreen({ challenge, onUpdate, onBack, onComplete }: CustomChallengeDetailScreenProps) {
  const { profile } = useAuth();
  
  const [showCompletion, setShowCompletion] = useState(false);
  const [showHonorValidation, setShowHonorValidation] = useState(false);
  const [honorChecked, setHonorChecked] = useState(false);
  const [floatingTexts, setFloatingTexts] = useState<{ id: string, text: string, x: number }[]>([]);

  const progressKey = `custom_challenge_progress_${profile?.uid}_${challenge.id}`;
  const claimedKey = `custom_challenge_claimed_${profile?.uid}_${challenge.id}`;

  const [hasClaimed, setHasClaimed] = useState(() => {
    return localStorage.getItem(claimedKey) === "true";
  });
  const [justClaimed, setJustClaimed] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(progressKey);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.exercises) {
          const updated = { ...challenge };
          updated.exercises = parsed.exercises;
          onUpdate(updated);
        }
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const totalTargetReps = challenge.exercises.reduce((sum, ex) => sum + ex.targetReps, 0);
  const totalCompletedReps = challenge.exercises.reduce((sum, ex) => sum + ex.completedReps, 0);
  
  const progressPercent = Math.min(100, (totalCompletedReps / totalTargetReps) * 100);
  const isCompleted = progressPercent >= 100;

  const bossMaxHP = totalTargetReps;
  const bossCurrentHP = Math.max(0, bossMaxHP - totalCompletedReps);

  const primaryMuscle = challenge.muscles?.[0] || "Unknown";
  const bossName = BOSS_MAP[primaryMuscle] || "UNKNOWN BOSS";

  useEffect(() => {
    if (isCompleted && !showCompletion && !showHonorValidation && !hasClaimed) {
      const timer = setTimeout(() => setShowHonorValidation(true), 500);
      return () => clearTimeout(timer);
    }
  }, [isCompleted, showCompletion, showHonorValidation, hasClaimed]);

  const saveProgress = (exercises: any[]) => {
    localStorage.setItem(progressKey, JSON.stringify({ exercises }));
  };

  const addRepsInternal = (exerciseIndex: number, amount: number) => {
    playSound("timer_tick");
    
    const id = Date.now() + "_" + Math.random();
    setFloatingTexts(prev => [...prev, { id, text: `+${amount}`, x: Math.random() * 40 - 20 }]);
    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== id));
    }, 1000);

    const updated = { ...challenge };
    const ex = updated.exercises[exerciseIndex];
    ex.completedReps = Math.min(ex.targetReps, ex.completedReps + amount);
    onUpdate(updated);
    saveProgress(updated.exercises);
  };

  const handleClaimXP = () => {
    if (!honorChecked) return;
    playSound("success");
    if (!hasClaimed) {
      localStorage.setItem(claimedKey, "true");
      onComplete(challenge.xp);
      setHasClaimed(true);
      setJustClaimed(true);
    }
    setShowHonorValidation(false);
    setShowCompletion(true);
  };

  if (showHonorValidation) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/95 flex flex-col items-center justify-center p-6 backdrop-blur-md">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-[#050B1A] border border-[#14F1E1]/30 shadow-[0_0_40px_rgba(20,241,225,0.2)] rounded-3xl p-6 text-center max-w-sm w-full relative"
        >
          <Trophy className="w-16 h-16 text-[#14F1E1] mx-auto mb-4" />
          <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-4">🏆 MISSION COMPLETE!</h2>
          <p className="text-neutral-300 text-sm mb-6 leading-relaxed">
            Target exercises completed?<br/><br/>
            Please confirm that you completed this challenge honestly.<br/>
          </p>
          
          <label className="flex items-center gap-3 p-4 bg-white/5 border border-white/10 rounded-xl cursor-pointer mb-6 text-left hover:bg-white/10 transition-colors">
            <input 
              type="checkbox" 
              checked={honorChecked}
              onChange={(e) => setHonorChecked(e.target.checked)}
              className="w-5 h-5 accent-[#14F1E1] rounded border-white/20 bg-white/10"
            />
            <span className="text-sm font-bold text-white leading-tight">Yes, I honestly completed this challenge.</span>
          </label>

          <button 
            onClick={handleClaimXP}
            disabled={!honorChecked}
            className={`w-full py-4 font-black text-sm uppercase tracking-widest rounded-xl transition-all ${honorChecked ? 'bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] shadow-[0_0_20px_rgba(20,241,225,0.4)]' : 'bg-white/10 text-neutral-500 cursor-not-allowed'}`}
          >
            🎁 CLAIM XP
          </button>
          
          <p className="text-neutral-500 text-[10px] uppercase tracking-widest font-bold mt-6">
            Fit Genie trust system par kaam karta hai.<br/>Real effort = Real progress.
          </p>
        </motion.div>
      </div>
    );
  }

  if (showCompletion || hasClaimed) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }} 
        animate={{ opacity: 1, scale: 1 }} 
        className="fixed inset-0 z-50 bg-[#050B1A] flex flex-col items-center justify-center p-6"
      >
        {justClaimed && Array.from({ length: 40 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ x: Math.random() * window.innerWidth, y: -20, opacity: 1, rotate: 0 }}
            animate={{ y: window.innerHeight + 20, rotate: 360, opacity: 0 }}
            transition={{ duration: 2 + Math.random() * 2, ease: "linear", repeat: Infinity }}
            className="absolute w-2 h-4 rounded-sm"
            style={{ backgroundColor: ['#14F1E1', '#B66DFF', '#F97316', '#FFFFFF'][Math.floor(Math.random() * 4)], left: `${Math.random() * 100}vw` }}
          />
        ))}

        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center space-y-6 max-w-sm w-full relative z-10"
        >
          <div className="w-32 h-32 mx-auto bg-[#14F1E1]/20 rounded-full flex items-center justify-center relative">
            <div className="absolute inset-0 bg-[#14F1E1] rounded-full blur-xl opacity-40 animate-pulse" />
            <Crosshair className="w-16 h-16 text-[#14F1E1] relative z-10" />
          </div>
          
          <div>
            <h1 className="text-4xl font-black uppercase text-white tracking-tight leading-tight">🏆 MISSION COMPLETE</h1>
            <p className="text-[#14F1E1] text-lg font-bold mt-2 uppercase tracking-widest">{bossName} DEFEATED!</p>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#14F1E1]/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
            {justClaimed ? (
              <>
                <div className="flex justify-between items-center mb-4 border-b border-white/10 pb-4">
                  <span className="text-neutral-400 font-bold uppercase tracking-widest text-xs">Reward Claimed</span>
                  <span className="text-[#14F1E1] font-black text-xl">+{challenge.xp} XP</span>
                </div>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-neutral-400 font-bold uppercase tracking-widest text-xs">Badge Unlocked</span>
                  <span className="text-yellow-400 font-black text-sm flex items-center gap-1">
                    <Trophy className="w-4 h-4" /> {primaryMuscle} Warrior Badge
                  </span>
                </div>
                <div className="text-sm font-medium text-neutral-300 leading-relaxed text-left space-y-4 border-t border-white/10 pt-4">
                  <p>🔥 Amazing work warrior.</p>
                  <p>Tumne {primaryMuscle} strength mission complete kar diya.</p>
                </div>
              </>
            ) : (
              <div className="text-center space-y-4">
                 <div className="inline-block px-4 py-1.5 bg-[#14F1E1]/20 text-[#14F1E1] rounded-full text-xs font-black uppercase tracking-widest border border-[#14F1E1]/30">
                   Already Claimed
                 </div>
                <p className="text-neutral-400 font-bold uppercase tracking-widest text-xs leading-relaxed mt-4">
                  Reward claimed for this challenge.
                </p>
              </div>
            )}
          </div>

          <div className="pt-4 space-y-4">
            <button
              onClick={() => {
                playSound("click");
                onBack();
              }}
              className="w-full py-4 bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-sm uppercase tracking-widest rounded-xl transition-all shadow-[0_0_20px_rgba(20,241,225,0.4)]"
            >
              Return To Challenges
            </button>
          </div>
        </motion.div>
      </motion.div>
    );
  }

  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen relative">
      {/* TOP HEADER */}
      <div className="flex items-center justify-between mb-2">
        <button onClick={() => { playSound("click"); onBack(); }} className="flex items-center gap-2 text-[#14F1E1] hover:text-white transition-colors">
          <ChevronLeft className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs">Back</span>
        </button>
        <div className="flex flex-col items-end">
          <span className="text-[#14F1E1] font-black tracking-widest uppercase text-xs flex items-center gap-1">
            <Target className="w-3 h-3" /> TARGET: {primaryMuscle.toUpperCase()}
          </span>
          <span className="text-neutral-500 font-bold text-[10px] uppercase tracking-widest">{challenge.difficulty || "Mission"} Status: Active</span>
        </div>
      </div>

      
      {/* MUSCLE VISUALIZATION */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col items-center justify-center relative overflow-hidden shadow-[0_0_30px_rgba(20,241,225,0.05)]">
        <h3 className="text-white font-black text-xs uppercase tracking-widest mb-4">Target Anatomy</h3>
        <div className="w-full max-w-[200px] scale-[0.8] origin-top h-[300px]">
          <MuscleSelector 
            selectedMuscles={challenge.muscles || []} 
            toggleMuscle={() => {}} readonly 
          />
        </div>
      </div>

      {/* BOSS BATTLE BANNER */}
      <div className="bg-[#14F1E1]/10 border border-[#14F1E1]/30 rounded-2xl p-6 flex flex-col items-center text-center relative overflow-hidden shadow-[0_0_30px_rgba(20,241,225,0.1)]">
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/20 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-[#14F1E1]/20 rounded-full blur-3xl -ml-10 -mb-10 pointer-events-none" />
        
        <Sword className="w-10 h-10 text-red-500 mb-3 relative z-10" />
        <h2 className="text-2xl font-black uppercase tracking-tight text-white relative z-10 drop-shadow-lg">BOSS: {bossName}</h2>
        <p className="text-neutral-400 text-xs italic mt-2 relative z-10">
          "{bossName} tumhari {primaryMuscle} strength ko challenge kar raha hai. Mission complete karke ise harao."
        </p>

        <div className="w-full mt-6 relative z-10">
           <div className="flex justify-between text-xs font-black uppercase tracking-widest mb-2">
             <span className="text-red-400">Boss HP</span>
             <span className="text-white">{bossCurrentHP} / {bossMaxHP}</span>
           </div>
           <div className="h-4 w-full bg-[#050B1A] rounded-full overflow-hidden relative border border-white/10 shadow-inner">
             <motion.div 
               className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-red-600 to-red-400" 
               initial={{ width: '100%' }}
               animate={{ width: `${(bossCurrentHP / bossMaxHP) * 100}%` }}
               transition={{ duration: 0.3 }}
             />
             <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iMTAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTAgMGwxMCAxME0xMCAwaC0xME0wIDEwaDEwIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4xKSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIi8+PC9zdmc+')] opacity-30" />
           </div>
        </div>
      </div>

      {/* MISSION REWARD */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex items-center justify-between">
         <div className="flex flex-col">
           <span className="text-neutral-400 text-[10px] font-bold uppercase tracking-widest mb-1">Mission Reward</span>
           <span className="text-yellow-400 font-bold text-xs flex items-center gap-1"><Trophy className="w-3 h-3" /> {primaryMuscle} Warrior Badge</span>
         </div>
         <span className="text-[#14F1E1] font-black text-xl">+{challenge.xp} XP</span>
      </div>

      {/* OVERALL PROGRESS */}
      <div className="flex items-center gap-4 bg-white/5 border border-white/10 rounded-2xl p-4">
         <div className="relative w-20 h-20 flex-shrink-0">
           <svg className="w-full h-full transform -rotate-90" viewBox="0 0 160 160">
             <circle
               cx="80"
               cy="80"
               r={radius}
               stroke="currentColor"
               strokeWidth="12"
               fill="transparent"
               className="text-white/10"
             />
             <motion.circle
               cx="80"
               cy="80"
               r={radius}
               stroke="currentColor"
               strokeWidth="12"
               fill="transparent"
               strokeDasharray={circumference}
               animate={{ strokeDashoffset }}
               className="text-[#14F1E1] drop-shadow-[0_0_10px_rgba(20,241,225,0.5)]"
               strokeLinecap="round"
             />
           </svg>
           <div className="absolute inset-0 flex items-center justify-center flex-col">
             <span className="text-[#14F1E1] font-black text-lg leading-none">{Math.round(progressPercent)}%</span>
           </div>
         </div>
         <div>
            <h3 className="text-white font-black uppercase tracking-widest text-sm mb-1">Mission Progress</h3>
            <p className="text-neutral-400 text-xs font-medium">
              {totalCompletedReps} / {totalTargetReps} Reps Completed
            </p>
         </div>
      </div>

      {/* EXERCISES */}
      <div className="space-y-4 mt-6">
        <h3 className="text-white font-black text-sm uppercase tracking-widest border-b border-white/10 pb-2">Exercise Breakdown</h3>
        {challenge.exercises.map((ex, index) => {
          const isDone = ex.completedReps >= ex.targetReps;
          const progress = Math.min(100, (ex.completedReps / ex.targetReps) * 100);
          
          return (
            <div key={index} className={`bg-[#050B1A] border rounded-2xl p-5 relative overflow-hidden transition-all ${isDone ? 'border-[#14F1E1]/50 shadow-[0_0_15px_rgba(20,241,225,0.2)]' : 'border-white/10'}`}>
              <div 
                className="absolute left-0 top-0 bottom-0 bg-[#14F1E1]/10 transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
              />
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="font-black text-white text-lg uppercase tracking-tight">{ex.name}</h3>
                    <p className="text-neutral-400 font-bold text-xs mt-1">{ex.completedReps} / {ex.targetReps} Reps</p>
                  </div>
                  {isDone && (
                    <div className="bg-[#14F1E1] text-[#050B1A] text-[10px] font-black px-2 py-1 rounded uppercase tracking-widest">
                      Done
                    </div>
                  )}
                </div>
                
                {!isDone && (
                  <div className="flex gap-2">
                    <button 
                      onClick={() => addRepsInternal(index, 1)}
                      className="flex-1 bg-white/5 hover:bg-white/10 border border-white/10 text-white text-sm font-black py-3 rounded-xl transition-colors uppercase tracking-widest"
                    >
                      +1 REP
                    </button>
                    <button 
                      onClick={() => addRepsInternal(index, 10)}
                      className="flex-1 bg-[#14F1E1]/10 hover:bg-[#14F1E1]/20 border border-[#14F1E1]/30 text-[#14F1E1] text-sm font-black py-3 rounded-xl transition-colors uppercase tracking-widest"
                    >
                      +10 REPS
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
}
