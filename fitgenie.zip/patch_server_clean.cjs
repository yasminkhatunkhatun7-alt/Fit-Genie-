const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const regex = /interface ChatMessage \{[\s\S]*?\}\n\s*interface LeaderboardEntry \{[\s\S]*?\}\n\s*const worldMessages: ChatMessage\[\] = \[\];\n\s*const userLastMessageTime: Record<string, number> = \{\};\n\s*const leaderboard = new Map<string, LeaderboardEntry>\(\);\n\s*app\.post\("\/api\/leaderboard"[\s\S]*?app\.post\("\/api\/chat\/messages"[\s\S]*?\}\);/g;

// Instead of complex regex, let's just do targeted string replaces for the endpoints.

let newCode = code;

const blocksToRemove = [
  // /api/leaderboard POST
  /\s*app\.post\("\/api\/leaderboard", \(req, res\) => \{[\s\S]*?\}\);/,
  // /api/leaderboard GET
  /\s*app\.get\("\/api\/leaderboard", \(req, res\) => \{[\s\S]*?\}\);/,
  // /api/chat/messages GET
  /\s*app\.get\("\/api\/chat\/messages", \(req, res\) => \{[\s\S]*?\}\);/,
  // /api/chat/messages DELETE
  /\s*app\.delete\("\/api\/chat\/messages\/:id", \(req, res\) => \{[\s\S]*?\}\);/,
  // /api/chat/messages POST
  /\s*app\.post\("\/api\/chat\/messages", \(req, res\) => \{[\s\S]*?\}\);/,
];

blocksToRemove.forEach(r => {
  newCode = newCode.replace(r, '');
});

fs.writeFileSync('server.ts', newCode);
console.log("Patched server.ts");
