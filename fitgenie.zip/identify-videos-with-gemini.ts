import { GoogleGenAI } from "@google/genai";
import fs from "fs";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const videos = [
  "62sm1cJzivQ", "vCWcYF5PiQg", "0kU-IJQs6Bk", "bmqSJSB0C8E", "ewSCQSE-kEM",
  "IGssbfjjc1Q", "Ou4mFyMmwE4", "tTIV6qVB59Y", "tIyMLHcJ_xQ", "RRQQgW9t--k",
  "fF0IgM71dUM", "B2UXMlFw-Mk", "XglujyVx-SI", "Vorr1jRrb9w", "ruu8XBkLVhg",
  "y-bxF4PCOJo", "MTJxrViWPj4", "Q2ClBRiRzJo", "-9rMGYdJwPE", "TCtuwk35bmk"
];

// Helper to delay execution
const delay = (ms: number) => new Promise(r => setTimeout(r, ms));

async function identifyWithRetry(id: string, attempt = 1): Promise<any> {
  try {
    const prompt = `Use Google Search to find out which specific exercise is shown/demonstrated in the YouTube Shorts video with ID or URL path "${id}" (full URL: https://youtube.com/shorts/${id} or https://www.youtube.com/watch?v=${id}). The video was uploaded by "Fit_Genie Wale" as a "Caleshthenics excersize made by fit Genie" video. Look for description keywords, titles, or cached details on pages that index this video. Return a clean JSON block like: { "id": "${id}", "exercise_name": "Exercise Name" } without any markdown packaging or prefix.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text?.trim() || "";
    console.log(`[SUCCESS] ID: ${id} -> ${text}`);
    return { id, response: text };
  } catch (err: any) {
    const errText = err.message || JSON.stringify(err);
    if (errText.includes("429") || errText.includes("RESOURCE_EXHAUSTED") || errText.includes("quota") || errText.includes("503")) {
      console.log(`[RATE LIMIT / OVERLOAD] Got error for ${id}. Retrying after 25 seconds... (Attempt ${attempt})`);
      await delay(25000);
      return identifyWithRetry(id, attempt + 1);
    }
    console.error(`[FATAL ERROR] ID: ${id}:`, errText);
    return { id, error: errText };
  }
}

async function main() {
  const results = [];
  for (const id of videos) {
    const res = await identifyWithRetry(id);
    results.push(res);
    // Cool down for 12 seconds between successful queries to stay below the 5-per-minute threshold
    await delay(12000);
  }
  fs.writeFileSync("./identified_videos.json", JSON.stringify(results, null, 2));
  console.log("ALL VIDEOS IDENTIFIED!");
}

main();
