const fs = require('fs');
let code = fs.readFileSync('src/components/AiRepCounter.tsx', 'utf-8');

const interfaceOld = `interface AiRepCounterProps {
  initialExercise?: "Pushups" | "Squats";
  onClose: () => void;
}`;
const interfaceNew = `interface AiRepCounterProps {
  initialExercise?: "Pushups" | "Squats";
  onClose: () => void;
  onComplete?: (reps: number) => void;
}`;
code = code.replace(interfaceOld, interfaceNew);

const declOld = `export function AiRepCounter({ initialExercise = "Pushups", onClose }: AiRepCounterProps) {`;
const declNew = `export function AiRepCounter({ initialExercise = "Pushups", onClose, onComplete }: AiRepCounterProps) {`;
code = code.replace(declOld, declNew);

const saveOld = `const handleSaveToLog = async () => {
    if (!user || reps === 0) return;
    
  };`;
const saveNew = `const handleSaveToLog = async () => {
    if (reps === 0) return;
    if (onComplete) {
      onComplete(reps);
    }
  };`;
code = code.replace(saveOld, saveNew);

fs.writeFileSync('src/components/AiRepCounter.tsx', code);
console.log('done updating AiRepCounter');
