const fs = require('fs');

let weekly = fs.readFileSync('src/components/WeeklyChallengeScreen.tsx', 'utf8');
weekly = weekly.replace(/  const handleAddReps = \(amount: number\) => {[\s\S]*?addRepsInternal\(amount\);\n  };/, `  const handleAddReps = (amount: number) => {
    if (isCompleted || hasClaimedThisWeek) return;
        
    if (amount === 1 && cooldown1 > 0) return;
    if (amount === 10 && cooldown10 > 0) return;

    if (checkCheat(exercise.name, amount)) {
      const updated = { ...challenge };
      updated.exercises[0].completedReps = 0;
      onUpdate(updated);
      return;
    }

    addRepsInternal(amount);
  };`);
fs.writeFileSync('src/components/WeeklyChallengeScreen.tsx', weekly);


let custom = fs.readFileSync('src/components/CustomChallengeDetailScreen.tsx', 'utf8');
custom = custom.replace(/  const handleAddReps = \(exerciseIndex: number, amount: number\) => {[\s\S]*?addRepsInternal\(exerciseIndex, amount\);\n  };/, `  const handleAddReps = (exerciseIndex: number, amount: number) => {
    if (isCompleted || hasClaimed) return;
        
    if (amount === 1 && (cooldowns1[exerciseIndex] || 0) > 0) return;
    if (amount === 10 && (cooldowns10[exerciseIndex] || 0) > 0) return;

    if (checkCheat(challenge.exercises[exerciseIndex].name, amount)) {
      const updated = { ...challenge };
      updated.exercises[exerciseIndex].completedReps = 0;
      onUpdate(updated);
      return;
    }

    addRepsInternal(exerciseIndex, amount);
  };`);
fs.writeFileSync('src/components/CustomChallengeDetailScreen.tsx', custom);
