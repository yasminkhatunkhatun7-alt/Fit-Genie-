const fs = require('fs');
let code = fs.readFileSync('src/components/MartialArts.tsx', 'utf-8');

const target = 'const [activeVideoLesson, setActiveVideoLesson] = useState<MartialLesson | null>(null);';
const replacement = `const [activeVideoLesson, setActiveVideoLesson] = useState<MartialLesson | null>(null);
  const [restTimerLeft, setRestTimerLeft] = useState<number | null>(null);

  useEffect(() => {
    if (restTimerLeft === null) return;
    if (restTimerLeft <= 0) {
      playSound("rest_chime");
      setRestTimerLeft(null);
      return;
    }
    const timerId = setInterval(() => {
      setRestTimerLeft(prev => (prev ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timerId);
  }, [restTimerLeft]);`;

code = code.replace(target, replacement);
fs.writeFileSync('src/components/MartialArts.tsx', code);
