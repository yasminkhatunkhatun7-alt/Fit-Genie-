const fs = require('fs');

let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf-8');

code = code.replace(
  'const toggleFriend = async (friendUid: string) => {};',
  `
  const signUpWithEmail = async () => {};
  const signInWithEmail = async () => {};
  const resetPassword = async () => {};
  const completeProfileSetup = async () => { return {} as any; };
  const refreshProfile = async () => {};
  const logMoggedExercise = async () => {};

  const toggleFriend = async (friendUid: string) => {};
`
);

fs.writeFileSync('src/context/AuthContext.tsx', code);
