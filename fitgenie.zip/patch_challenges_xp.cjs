const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf8');

// Hide XP pill for custom challenges in active state
code = code.replace(
  /<span className="bg-\[#14F1E1\]\/10 text-\[#14F1E1\] border border-\[#14F1E1\]\/30 px-3 py-1 rounded-full text-\[10px\] font-black tracking-widest uppercase">\s*\+\{activeChallenge.xp\} XP Reward\s*<\/span>/,
  `{!activeChallenge.id.startsWith("custom") && (
               <span className="bg-[#14F1E1]/10 text-[#14F1E1] border border-[#14F1E1]/30 px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase">
                 +{activeChallenge.xp} XP Reward
               </span>
             )}`
);

// Hide XP pill in challenges list for custom challenge
code = code.replace(
  /<span className="bg-\[#050B1A\] border border-\[#14F1E1\]\/30 text-\[#14F1E1\] text-\[10px\] px-2 py-0\.5 rounded font-black tracking-widest uppercase">\s*\+\{isActive && challenge.id === "custom" \? activeChallenge.xp : challenge.xp\} XP\s*<\/span>/,
  `{challenge.id !== "custom" && (
                        <span className="bg-[#050B1A] border border-[#14F1E1]/30 text-[#14F1E1] text-[10px] px-2 py-0.5 rounded font-black tracking-widest uppercase">
                          +{isActive && challenge.id === "custom" ? activeChallenge.xp : challenge.xp} XP
                        </span>
                      )}`
);

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
