const fs = require('fs');

let chatCode = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

chatCode = chatCode.replace(
  /const res = await fetch\("\/api\/chat\/messages"\);\s*if \(res.ok\) {\s*const data = await res.json\(\);\s*setMessages\(data\);\s*}/m,
  `const res = await fetch("/api/chat/messages");
      if (res.ok) {
        const contentType = res.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
          const data = await res.json();
          setMessages(data);
        }
      }`
);

chatCode = chatCode.replace(
  /const data = await res.json\(\);\s*if \(!res.ok\) {/m,
  `const contentType = res.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        throw new Error("Invalid server response (not JSON). Session may have expired.");
      }
      
      const data = await res.json();
      if (!res.ok) {`
);

fs.writeFileSync('src/components/WorldChat.tsx', chatCode);
console.log("Fixed json parsing");
