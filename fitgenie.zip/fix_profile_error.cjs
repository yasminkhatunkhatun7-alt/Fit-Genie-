const fs = require('fs');

let profile = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');

if (!profile.includes("Something went wrong")) {
  profile = profile.replace(
    'const [loadingProfile, setLoadingProfile] = useState(true);',
    'const [loadingProfile, setLoadingProfile] = useState(true);\n  const [error, setError] = useState<string | null>(null);'
  );
  
  // Add catch error handling in fetch functions
  profile = profile.replace(
    'console.error("Failed to fetch profile", e);',
    'console.error("Failed to fetch profile", e);\n      setError("Something went wrong");'
  );
  
  // Inject UI
  profile = profile.replace(
    'if (loadingProfile) return (',
    'if (error) return (\n    <div className="flex-1 flex flex-col items-center justify-center text-center p-8">\n      <p className="text-sm font-bold text-red-400 mb-3">Something went wrong. Please try again.</p>\n      <button onClick={() => { setError(null); fetchTargetProfile(); fetchWorkouts(); }} className="px-4 py-2 bg-red-500/20 text-red-300 rounded-lg text-xs font-black uppercase tracking-widest hover:bg-red-500/30">Retry</button>\n    </div>\n  );\n\n  if (loadingProfile) return ('
  );
  fs.writeFileSync('src/components/ProfileView.tsx', profile);
}
