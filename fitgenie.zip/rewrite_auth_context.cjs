const fs = require('fs');

let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf-8');

const regex = /export function AuthProvider\(\{\s*children\s*\}\:\s*\{\s*children\:\s*ReactNode\s*\}\)\s*\{[\s\S]*?(?=\s*const toggleFriend)/;

const newCode = `export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [profileRequired, setProfileRequired] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userRef = doc(db, 'users', currentUser.uid);
          const userSnap = await getDoc(userRef);
          if (userSnap.exists()) {
            const p = userSnap.data() as UserProfile;
            if (p.last_workout_date) {
              const todayStr = getLocalDateString(new Date());
              const diffDays = getDaysBetween(p.last_workout_date, todayStr);
              if (diffDays > 1) {
                p.streak = 0;
                await setDoc(userRef, { streak: 0 }, { merge: true });
              }
            }
            setProfile(p);
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(p));
          } else {
            setProfile(null);
          }
        } catch (e) {
          console.error("Error fetching user profile:", e);
        }
      } else {
        setProfile(null);
        localStorage.removeItem(LOCAL_STORAGE_KEY);
        localStorage.removeItem("fitgenie_onboarding_completed");
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const currentUser = result.user;
      const userRef = doc(db, 'users', currentUser.uid);
      const userSnap = await getDoc(userRef);
      if (userSnap.exists()) {
        const p = userSnap.data() as UserProfile;
        setProfile(p);
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(p));
        localStorage.setItem("fitgenie_onboarding_completed", "true");
      } else {
        const avatarStyles = ["bg-blue-500", "bg-pink-500", "bg-purple-500", "bg-emerald-500", "bg-orange-500", "bg-indigo-500"];
        const avatarIndex = currentUser.uid.length % avatarStyles.length;
        const avatarBg = \`\${avatarStyles[avatarIndex]} text-white border-\${avatarStyles[avatarIndex].replace('bg-', '')}\`;
        
        const newProfile: UserProfile = {
          uid: currentUser.uid,
          username: currentUser.displayName || 'Warrior',
          email: currentUser.email || '',
          photoURL: currentUser.photoURL || '',
          xp: 0,
          rank: getRankFromXP(0),
          streak: 0,
          joinDate: getLocalDateString(new Date()),
          integrityScore: 100,
          onboardingCompleted: false,
          avatarBg
        };
        await setDoc(userRef, {
          ...newProfile,
          userId: currentUser.uid,
          userName: newProfile.username
        });
        setProfile(newProfile);
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newProfile));
        localStorage.removeItem("fitgenie_onboarding_completed");
      }
    } catch (error) {
      console.error("Error signing in with Google", error);
      throw error;
    }
  };

  const signOutUser = async () => {
    try {
      await signOut(auth);
      setProfile(null);
      setUser(null);
      localStorage.removeItem(LOCAL_STORAGE_KEY);
      localStorage.removeItem("fitgenie_onboarding_completed");
    } catch (error) {
      console.error("Error signing out", error);
      throw error;
    }
  };

  const saveProfile = async (updatedProfile: UserProfile) => {
    setProfile(updatedProfile);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedProfile));
    try {
      if (updatedProfile.uid && updatedProfile.uid !== 'local_user') {
        const avatarStyles = ["bg-blue-500", "bg-pink-500", "bg-purple-500", "bg-emerald-500", "bg-orange-500", "bg-indigo-500"];
        const avatarIndex = updatedProfile.uid.length % avatarStyles.length;
        const avatarBg = updatedProfile.avatarBg || \`\${avatarStyles[avatarIndex]} text-white border-\${avatarStyles[avatarIndex].replace('bg-', '')}\`;
        
        const userRef = doc(db, 'users', updatedProfile.uid);
        await setDoc(userRef, {
          ...updatedProfile,
          userId: updatedProfile.uid,
          userName: updatedProfile.username || 'Anonymous Genin',
          xp: updatedProfile.xp || 0,
          avatarBg: avatarBg,
        }, { merge: true });
      }
    } catch (e) {
      console.error('Failed to sync profile to Firebase', e);
    }
  };

  const updateUserXP = async (additionalXP: number) => {
    if (!profile) return;
    const newXP = profile.xp + additionalXP;
    const newRank = getRankFromXP(newXP);
    
    // Check if daily/weekly reset needed
    const today = getLocalDateString(new Date());
    const thisWeek = getISOWeekString(new Date());
    const thisMonth = getISOMonthString(new Date());
    
    let dailyXP = profile.dailyXP || 0;
    let weeklyXP = profile.weeklyXP || 0;
    let monthlyXP = profile.monthlyXP || 0;
    
    if (profile.lastDate !== today) dailyXP = 0;
    if (profile.lastWeek !== thisWeek) weeklyXP = 0;
    if (profile.lastMonth !== thisMonth) monthlyXP = 0;
    
    await saveProfile({
      ...profile,
      xp: newXP,
      rank: newRank,
      dailyXP: dailyXP + additionalXP,
      weeklyXP: weeklyXP + additionalXP,
      monthlyXP: monthlyXP + additionalXP,
      lastDate: today,
      lastWeek: thisWeek,
      lastMonth: thisMonth
    });
  };

  const updateProfileStats = async (stats: any) => {
    if (!profile) return;
    
    let updatedProfile = { ...profile };
    
    if (stats.xpGained) {
      updatedProfile.xp += stats.xpGained;
      updatedProfile.rank = getRankFromXP(updatedProfile.xp);
      
      const today = getLocalDateString(new Date());
      const thisWeek = getISOWeekString(new Date());
      const thisMonth = getISOMonthString(new Date());
      
      if (updatedProfile.lastDate !== today) updatedProfile.dailyXP = 0;
      if (updatedProfile.lastWeek !== thisWeek) updatedProfile.weeklyXP = 0;
      if (updatedProfile.lastMonth !== thisMonth) updatedProfile.monthlyXP = 0;
      
      updatedProfile.dailyXP = (updatedProfile.dailyXP || 0) + stats.xpGained;
      updatedProfile.weeklyXP = (updatedProfile.weeklyXP || 0) + stats.xpGained;
      updatedProfile.monthlyXP = (updatedProfile.monthlyXP || 0) + stats.xpGained;
      
      updatedProfile.lastDate = today;
      updatedProfile.lastWeek = thisWeek;
      updatedProfile.lastMonth = thisMonth;
    }
    
    if (stats.workoutCompleted) {
      updatedProfile.totalWorkouts = (updatedProfile.totalWorkouts || 0) + 1;
      const today = getLocalDateString(new Date());
      
      if (updatedProfile.last_workout_date !== today) {
         if (updatedProfile.last_workout_date) {
            const diff = getDaysBetween(updatedProfile.last_workout_date, today);
            if (diff === 1) {
              updatedProfile.streak += 1;
            } else if (diff > 1) {
              updatedProfile.streak = 1;
            }
         } else {
            updatedProfile.streak = 1;
         }
         updatedProfile.last_workout_date = today;
      }
    }
    
    if (stats.challengeWon) {
      updatedProfile.challengeWins = (updatedProfile.challengeWins || 0) + 1;
    }
    
    if (stats.integrityScoreChange) {
      updatedProfile.integrityScore = Math.min(100, Math.max(0, (updatedProfile.integrityScore || 100) + stats.integrityScoreChange));
    }
    
    if (stats.integrityViolationsChange) {
       updatedProfile.integrityViolations = (updatedProfile.integrityViolations || 0) + stats.integrityViolationsChange;
    }
    
    if (stats.consecutiveHonestDaysChange !== undefined) {
       if (stats.consecutiveHonestDaysChange === 0) {
         updatedProfile.consecutiveHonestDays = 0;
       } else {
         updatedProfile.consecutiveHonestDays = (updatedProfile.consecutiveHonestDays || 0) + stats.consecutiveHonestDaysChange;
       }
    }
    
    await saveProfile(updatedProfile);
  };
`;

if (code.match(regex)) {
  code = code.replace(regex, newCode);
  fs.writeFileSync('src/context/AuthContext.tsx', code);
  console.log('AuthContext updated successfully.');
} else {
  console.error('Regex match failed');
}
