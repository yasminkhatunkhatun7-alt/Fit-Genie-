const fs = require('fs');
let code = fs.readFileSync('src/components/SmartWorkoutTracker.tsx', 'utf-8');

// 1. Add recharts import
const importTarget = `import { Camera } from "lucide-react";`;
const importReplace = `import { Camera, TrendingUp } from "lucide-react";\nimport { LineChart, Line, ResponsiveContainer, YAxis, Tooltip, XAxis } from "recharts";`;
if (!code.includes('recharts')) {
  code = code.replace(importTarget, importReplace);
}

// 2. Add repHistory state and effect
const stateTarget = `const [completedRepsInput, setCompletedRepsInput] = useState<string>("");`;
const stateReplace = `const [completedRepsInput, setCompletedRepsInput] = useState<string>("");
  const [repHistory, setRepHistory] = useState<{ date: string; reps: number }[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem(\`fitgenie_reps_\${exercise.id}\`);
    if (stored) {
      try {
        setRepHistory(JSON.parse(stored));
      } catch(e){}
    }
  }, [exercise.id]);`;
if (!code.includes('repHistory')) {
  code = code.replace(stateTarget, stateReplace);
}

// 3. Save to local storage on handleSave
const handleSaveTarget = `    onSave(session);
    onClose();`;
const handleSaveReplace = `    const newHistory = [...repHistory, { date: new Date().toISOString(), reps: finalCompleted }];
    localStorage.setItem(\`fitgenie_reps_\${exercise.id}\`, JSON.stringify(newHistory));
    
    onSave(session);
    onClose();`;
if (!code.includes('fitgenie_reps_')) {
  code = code.replace(handleSaveTarget, handleSaveReplace);
}

// 4. Render chart in Completion
const completionTarget = `<div className="space-y-2 mb-6">
           <label className="text-xs uppercase font-bold text-neutral-500 flex items-center gap-1.5"><MessageSquare className="w-3.5 h-3.5" /> Notes (Optional)</label>`;
const completionReplace = `        {/* TREND CHART */}
        <div className="bg-neutral-900 border border-brand-border/40 p-4 rounded-2xl mb-6">
           <div className="flex items-center gap-2 mb-3 text-neutral-400">
             <TrendingUp className="w-4 h-4 text-[#B66DFF]" />
             <span className="text-xs font-bold uppercase tracking-widest text-[#B66DFF]">Historical Trend</span>
           </div>
           <div className="h-28 w-full">
             <ResponsiveContainer width="100%" height="100%">
               <LineChart data={[...repHistory.map((h, i) => ({ name: \`S\${i+1}\`, reps: h.reps })), { name: "Now", reps: isNaN(finalCompleted) ? 0 : finalCompleted }]}>
                 <Tooltip 
                   contentStyle={{ backgroundColor: '#111', border: '1px solid #333', borderRadius: '8px' }}
                   itemStyle={{ color: '#14F1E1', fontWeight: 'bold' }}
                   labelStyle={{ display: 'none' }}
                   formatter={(value: number) => [\`\${value} reps\`, ""]}
                 />
                 <Line 
                   type="monotone" 
                   dataKey="reps" 
                   stroke="#14F1E1" 
                   strokeWidth={3} 
                   dot={{ fill: '#B66DFF', r: 4, strokeWidth: 0 }} 
                   activeDot={{ r: 6, fill: '#14F1E1' }} 
                   isAnimationActive={true}
                 />
               </LineChart>
             </ResponsiveContainer>
           </div>
           {repHistory.length === 0 && (
             <p className="text-center text-[10px] text-neutral-500 uppercase font-bold mt-2">First time tracking this exercise.</p>
           )}
        </div>

        <div className="space-y-2 mb-6">
           <label className="text-xs uppercase font-bold text-neutral-500 flex items-center gap-1.5"><MessageSquare className="w-3.5 h-3.5" /> Notes (Optional)</label>`;
if (!code.includes('TREND CHART')) {
  code = code.replace(completionTarget, completionReplace);
}

fs.writeFileSync('src/components/SmartWorkoutTracker.tsx', code);
console.log("Patched SmartWorkoutTracker for Trend Chart");
