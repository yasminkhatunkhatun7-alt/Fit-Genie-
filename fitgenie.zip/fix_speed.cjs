const fs = require('fs');
let code = fs.readFileSync('src/components/SpeedChallengeScreen.tsx', 'utf-8');

const regex = /<div className="grid grid-cols-2 gap-4 relative">[\s\S]*?<\/motion\.button>/;

const replacement = `{(exercise.name.toLowerCase().includes('pushup') || exercise.name.toLowerCase().includes('squat')) ? (
           <motion.button 
             whileTap={{ scale: 0.95 }}
             onClick={() => setShowAiCounter(true)}
             disabled={isCompleted || timeLeft === 0}
             className="w-full py-4 rounded-xl bg-[#14F1E1] text-[#050B1A] font-black uppercase tracking-widest flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(20,241,225,0.4)] hover:bg-white transition-all disabled:opacity-50 disabled:shadow-none"
           >
             <Camera className="w-6 h-6" /> START AI TRACKER
           </motion.button>
         ) : (
           <div className="grid grid-cols-2 gap-3 w-full">
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(1)} disabled={isCompleted || timeLeft === 0} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-4 rounded-2xl relative overflow-hidden">+1</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(5)} disabled={isCompleted || timeLeft === 0} className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black text-lg py-4 rounded-2xl relative overflow-hidden">+5</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(10)} disabled={isCompleted || timeLeft === 0} className="bg-[#14F1E1]/10 hover:bg-[#14F1E1]/20 border border-[#14F1E1]/30 text-[#14F1E1] font-black text-lg py-4 rounded-2xl relative overflow-hidden">+10</motion.button>
             <motion.button whileTap={{ scale: 0.95 }} onClick={() => handleAddReps(15)} disabled={isCompleted || timeLeft === 0} className="bg-[#14F1E1]/10 hover:bg-[#14F1E1]/20 border border-[#14F1E1]/30 text-[#14F1E1] font-black text-lg py-4 rounded-2xl relative overflow-hidden">+15</motion.button>
           </div>
         )}`;

if (code.match(regex)) {
  code = code.replace(regex, replacement);
  fs.writeFileSync('src/components/SpeedChallengeScreen.tsx', code);
  console.log('Fixed Speed');
} else {
  console.log('Failed Speed');
}
