const fs = require('fs');
let file = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');
let lines = file.split('\n');

const startIndex = lines.findIndex(l => l.includes('TAB 6: MUSIC HUB ("music")')) - 1;
const endIndex = lines.findIndex(l => l.includes('TAB 7: SOCIAL CHALLENGES ("challenges")')) - 1;

if (startIndex > 0 && endIndex > startIndex) {
  lines.splice(startIndex, endIndex - startIndex);
}

// Ensure the tab is gone
file = lines.join('\n');
file = file.replace(/\{ id: "music", label: "🎵 Workout Music", icon: "🎧" \},\n/g, "");

fs.writeFileSync('src/components/YoddhaHub.tsx', file);
