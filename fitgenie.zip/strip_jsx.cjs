const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

const regexModal = /                \{verificationData && \([\s\S]*?\}\n\s*\}\n/m;
content = content.replace(regexModal, "");

const regexCheat = /        \{showCheatWarning && \([\s\S]*?\}\n\s*\}\n/m;
content = content.replace(regexCheat, "");

fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', content);
