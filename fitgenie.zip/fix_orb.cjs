const fs = require('fs');
let file = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

if (!file.includes('GenieChat')) {
    file = file.replace('import { Shield,', 'import GenieChat from "./GenieChat";\nimport { Shield,');
    
    file = file.replace(
        'const { profile } = useAuth();',
        'const { profile } = useAuth();\n  const [activeTab, setActiveTab] = useState<"guardian" | "chat">("guardian");'
    );
    
    // Add the tab switcher just below the title
    file = file.replace(
        '<p className="text-[10px] text-[#14F1E1] font-bold uppercase tracking-widest mt-1">\n                      Status: {emotion.toUpperCase()}\n                    </p>\n                  </div>\n                </div>\n\n                <div className="grid gap-4">',
        `<p className="text-[10px] text-[#14F1E1] font-bold uppercase tracking-widest mt-1">
                      Status: {emotion.toUpperCase()}
                    </p>
                  </div>
                </div>

                <div className="flex gap-2 p-1 bg-white/5 rounded-xl">
                  <button 
                    onClick={() => setActiveTab("guardian")}
                    className={\`flex-1 py-2 text-xs font-black uppercase tracking-widest rounded-lg transition-colors \${activeTab === "guardian" ? "bg-[#14F1E1] text-[#050B1A]" : "text-neutral-400 hover:text-white"}\`}
                  >
                    Status
                  </button>
                  <button 
                    onClick={() => setActiveTab("chat")}
                    className={\`flex-1 py-2 text-xs font-black uppercase tracking-widest rounded-lg transition-colors \${activeTab === "chat" ? "bg-[#14F1E1] text-[#050B1A]" : "text-neutral-400 hover:text-white"}\`}
                  >
                    Chat
                  </button>
                </div>

                {activeTab === "guardian" ? (
                  <div className="grid gap-4">`
    );
    
    // Close the ternary and add Chat component
    file = file.replace(
        '                    </p>\n                  </div>\n                </div>\n              </div>\n            </motion.div>\n          </>\n        )}\n      </AnimatePresence>',
        '                    </p>\n                  </div>\n                </div>\n                ) : (\n                  <GenieChat />\n                )}\n              </div>\n            </motion.div>\n          </>\n        )}\n      </AnimatePresence>'
    );

    fs.writeFileSync('src/components/GuardianOrb.tsx', file);
}
