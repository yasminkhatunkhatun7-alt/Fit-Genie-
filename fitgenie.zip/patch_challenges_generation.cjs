const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf8');

const regex = /const exercises: any\[\] = \[\];[\s\S]*?const map = new Map\(\);/m;

const replacement = `
    let allPool: {name: string, targetReps: number}[] = [];
    
    const MUSCLE_EXERCISES: Record<string, {name: string, targetReps: number}[]> = {
      "Chest": [
        { name: "Push Ups", targetReps: 50 },
        { name: "Wide Push Ups", targetReps: 40 },
        { name: "Diamond Push Ups", targetReps: 30 }
      ],
      "Back": [
        { name: "Superman Hold (Secs)", targetReps: 60 },
        { name: "Reverse Snow Angels", targetReps: 30 },
        { name: "Prone Back Extensions", targetReps: 40 }
      ],
      "Shoulders": [
        { name: "Pike Push Ups", targetReps: 30 },
        { name: "Arm Circles (Secs)", targetReps: 60 },
        { name: "Shoulder Taps", targetReps: 50 }
      ],
      "Biceps": [
        { name: "Towel Curls", targetReps: 40 },
        { name: "Isometric Bicep Hold (Secs)", targetReps: 60 },
        { name: "Backpack Curls", targetReps: 30 }
      ],
      "Triceps": [
        { name: "Bench Dips", targetReps: 40 },
        { name: "Diamond Push Ups", targetReps: 30 },
        { name: "Backpack Tricep Ext", targetReps: 30 }
      ],
      "Forearms": [
        { name: "Wrist Curls", targetReps: 50 },
        { name: "Reverse Wrist Curls", targetReps: 50 },
        { name: "Farmer Hold (Secs)", targetReps: 60 }
      ],
      "Abs": [
        { name: "Crunches", targetReps: 50 },
        { name: "Leg Raises", targetReps: 40 },
        { name: "Plank (Secs)", targetReps: 60 }
      ],
      "Obliques": [
        { name: "Russian Twists", targetReps: 50 },
        { name: "Side Plank (Secs)", targetReps: 45 },
        { name: "Bicycle Crunches", targetReps: 40 }
      ],
      "Quads": [
        { name: "Squats", targetReps: 50 },
        { name: "Jump Squats", targetReps: 30 },
        { name: "Wall Sit (Secs)", targetReps: 60 }
      ],
      "Hamstrings": [
        { name: "Glute Bridge", targetReps: 40 },
        { name: "Single Leg Bridge", targetReps: 30 },
        { name: "Nordic Curl Prog", targetReps: 20 }
      ],
      "Glutes": [
        { name: "Hip Thrust", targetReps: 40 },
        { name: "Glute Bridge", targetReps: 40 },
        { name: "Donkey Kicks", targetReps: 50 }
      ],
      "Calves": [
        { name: "Calf Raises", targetReps: 60 },
        { name: "Single Leg Calf Raises", targetReps: 30 },
        { name: "Jump Rope Sim (Secs)", targetReps: 60 }
      ],
      "Neck": [
        { name: "Neck Flexion", targetReps: 30 },
        { name: "Neck Extension", targetReps: 30 },
        { name: "Neck Isometric (Secs)", targetReps: 40 }
      ],
      "Traps": [
        { name: "Shoulder Shrugs", targetReps: 50 },
        { name: "Backpack Shrugs", targetReps: 40 },
        { name: "Isometric Trap Hold (Secs)", targetReps: 45 }
      ]
    };
    
    selectedMuscles.forEach(m => {
       if (MUSCLE_EXERCISES[m]) {
         allPool.push(...MUSCLE_EXERCISES[m]);
       }
    });
    
    // Shuffle pool
    for (let i = allPool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [allPool[i], allPool[j]] = [allPool[j], allPool[i]];
    }
    
    const exercises = allPool.slice(0, Math.min(3, Math.max(2, allPool.length))).map(ex => ({
       ...ex, completedReps: 0
    }));

    if (exercises.length === 0) {
        exercises.push({ name: "Burpees", targetReps: 30, completedReps: 0 });
        exercises.push({ name: "Jumping Jacks", targetReps: 50, completedReps: 0 });
    }
    
    // Deduplicate
    const uniqueExercises: any[] = [];
    const map = new Map();`;

code = code.replace(regex, replacement);

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
