const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const targetStr = `  app.post("/api/chat/messages", (req, res) => {`;
const replaceStr = `  app.delete("/api/chat/messages/:id", (req, res) => {
    const { id } = req.params;
    const { userId } = req.body;
    
    const messageIndex = worldMessages.findIndex(m => m.id === id);
    if (messageIndex === -1) {
      return res.status(404).json({ error: "Message not found" });
    }
    
    if (worldMessages[messageIndex].userId !== userId) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    worldMessages.splice(messageIndex, 1);
    res.json({ success: true });
  });

  app.post("/api/chat/messages", (req, res) => {`;

if (!code.includes('app.delete("/api/chat/messages/:id"')) {
  code = code.replace(targetStr, replaceStr);
  fs.writeFileSync('server.ts', code);
  console.log("Added DELETE endpoint");
} else {
  console.log("DELETE endpoint already exists");
}
