import fs from "fs";

const videoIds = [
  "62sm1cJzivQ", "vCWcYF5PiQg", "0kU-IJQs6Bk", "bmqSJSB0C8E", "ewSCQSE-kEM",
  "IGssbfjjc1Q", "Ou4mFyMmwE4", "tTIV6qVB59Y", "tIyMLHcJ_xQ", "RRQQgW9t--k",
  "fF0IgM71dUM", "B2UXMlFw-Mk", "XglujyVx-SI", "Vorr1jRrb9w", "ruu8XBkLVhg",
  "y-bxF4PCOJo", "MTJxrViWPj4", "Q2ClBRiRzJo", "-9rMGYdJwPE", "TCtuwk35bmk"
];

async function getMetadata(id: string) {
  try {
    const url = `https://www.youtube.com/watch?v=${id}`;
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    });
    const html = await res.text();
    
    // Search for title in the HTML
    let title = "";
    const titleMatch = html.match(/<title>(.*?)<\/title>/);
    if (titleMatch) {
      title = titleMatch[1];
    }
    
    // Also parse forytplayer or specific json data
    const descMatch = html.match(/"shortDescription":"(.*?)"/);
    let desc = "";
    if (descMatch) {
      desc = descMatch[1];
    }

    console.log(`ID: ${id}`);
    console.log(`Title: ${title}`);
    console.log(`Desc: ${desc}`);
    console.log("-----------------------------------------");
    return { id, title, desc };
  } catch (err: any) {
    console.error(`Error for ${id}:`, err.message);
    return { id, title: "Error", desc: "" };
  }
}

async function main() {
  const results = [];
  for (const id of videoIds) {
    const result = await getMetadata(id);
    results.push(result);
    // Pause briefly to respect YouTube's rate limits
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  fs.writeFileSync("./video-metadata.json", JSON.stringify(results, null, 2));
}

main();
