const fs = require('fs');

let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

// Add renderHighlightedText function after fileInputRef
const renderHighlightedText = `
  const renderHighlightedText = (text: string, query: string) => {
    if (!query) return text;
    const lowerText = text.toLowerCase();
    const lowerQuery = query.toLowerCase();
    const index = lowerText.indexOf(lowerQuery);
    if (index === -1) return text;
    
    return (
      <>
        {text.substring(0, index)}
        <span className="text-[#14F1E1] bg-[#14F1E1]/10 px-0.5 rounded">{text.substring(index, index + query.length)}</span>
        {text.substring(index + query.length)}
      </>
    );
  };
`;

code = code.replace(
  "const fileInputRef = useRef<HTMLInputElement>(null);",
  "const fileInputRef = useRef<HTMLInputElement>(null);\n" + renderHighlightedText
);

// Replace area.name with renderHighlightedText(area.name, searchQuery)
code = code.replace(
  '<h3 className="text-white font-black text-sm tracking-wider">{area.name}</h3>',
  '<h3 className="text-white font-black text-sm tracking-wider">{renderHighlightedText(area.name, searchQuery)}</h3>'
);

// Replace ex.name with renderHighlightedText(ex.name, searchQuery)
code = code.replace(
  '<h4 className="text-white font-black text-[13px] uppercase tracking-wider truncate">{ex.name}</h4>',
  '<h4 className="text-white font-black text-[13px] uppercase tracking-wider truncate">{renderHighlightedText(ex.name, searchQuery)}</h4>'
);

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done');
