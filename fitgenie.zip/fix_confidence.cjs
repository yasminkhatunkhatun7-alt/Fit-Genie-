const fs = require('fs');
let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

// Replace bounding box condition
const bboxOld = `{/* Face Bounding Box or Ring */}
                        {lms.length > 0 && (`;
const bboxNew = `{/* Face Bounding Box or Ring */}
                        {lms.length > 0 && isHighConfidence && (`;

code = code.replace(bboxOld, bboxNew);

// Replace marker condition
const markerOld = `if (!item.landmark) return null;
                          const isHighConf = item.landmark.confidence >= 80;`;
const markerNew = `if (!item.landmark || item.landmark.confidence < 80) return null;
                          const isHighConf = true; // Kept for compatibility with existing styling`;

code = code.replace(markerOld, markerNew);

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done confidence update');
