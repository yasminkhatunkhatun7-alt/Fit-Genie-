const fs = require('fs');
let appStr = fs.readFileSync('src/App.tsx', 'utf8');

// replace await import("./firebase") with updateUserProfileFields
appStr = appStr.replace(
  'const { updateUserProfile } = await import("./firebase");',
  '// Use local AuthContext directly'
);
appStr = appStr.replace(
  'await updateUserProfile(user.uid, {',
  'await updateUserProfileFields({'
);
fs.writeFileSync('src/App.tsx', appStr);
