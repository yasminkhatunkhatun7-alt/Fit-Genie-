const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Add import
const importStr = 'import AchievementsScreen from "./components/AchievementsScreen";';
if (!content.includes(importStr)) {
  content = content.replace(/import ProfileView from "\.\/components\/ProfileView";/, 'import ProfileView from "./components/ProfileView";\n' + importStr);
}

// Add view render
const renderStr = '{view === "achievements" && <AchievementsScreen />}';
if (!content.includes(renderStr)) {
  content = content.replace(/\{view === "dojo" && \([\s\S]*?\}\)/, match => match + '\n                ' + renderStr);
}

// Also VIEW_ORDER might need updating. Let's see if VIEW_ORDER exists.
