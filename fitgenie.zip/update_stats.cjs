const fs = require('fs');
let code = fs.readFileSync('src/components/StatsView.tsx', 'utf-8');

const replacement = `
            const dailyDuration = sessionsOnDay.reduce((sum, s) => sum + s.totalDurationMin, 0);
            
            // Calculate daily volume (sets * reps * weight) and max weight
            let dailyVolume = 0;
            let dailyMaxWeight = 0;
            sessionsOnDay.forEach(s => {
                s.exercises.forEach(ex => {
                    const weight = ex.weight || 20; // default to 20 to show bodyweight equivalent volume
                    dailyVolume += (ex.sets * ex.reps * weight);
                    if (weight > dailyMaxWeight) dailyMaxWeight = weight;
                });
            });

            data.push({
                date: dateStr,
                label: shortLabel,
                count: sessionsOnDay.length,
                duration: dailyDuration,
                calories: Math.round(dailyDuration * 8.5),
                exercises: sessionsOnDay.reduce((sum, s) => sum + s.exercisesCount, 0),
                volume: dailyVolume,
                maxWeight: dailyMaxWeight,
`;

code = code.replace(
    /const dailyDuration = sessionsOnDay.reduce[\s\S]*?maxWeight: dailyMaxWeight,/m,
    replacement.trim()
);

fs.writeFileSync('src/components/StatsView.tsx', code);
