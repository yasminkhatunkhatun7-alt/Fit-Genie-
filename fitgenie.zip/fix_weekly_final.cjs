const fs = require('fs');
let code = fs.readFileSync('src/components/WeeklyChallengeScreen.tsx', 'utf-8');

const controlsRegex = /<div className="grid grid-cols-2 gap-4 relative">[\s\S]*?<\/AnimatePresence>\n          <\/div>/;

const controlsReplacement = `<div className="grid grid-cols-1 gap-4 relative">
            {(exercise.name.toLowerCase().includes('pushup') || exercise.name.toLowerCase().includes('squat')) ? (
               <motion.button 
                 whileTap={{ scale: 0.95 }}
                 onClick={() => setShowAiCounter(true)}
                 disabled={isCompleted}
                 className="bg-[#B66DFF] hover:bg-[#a552f5] text-white font-black text-lg py-5 rounded-2xl flex justify-center items-center gap-2 shadow-[0_0_20px_rgba(182,109,255,0.4)] transition-all disabled:opacity-50"
               >
                 <Camera className="w-6 h-6" />
                 START AI TRACKER
               </motion.button>
             ) : (
               <div className="bg-white/5 border border-white/10 text-neutral-400 font-bold text-sm py-5 rounded-2xl flex justify-center items-center text-center px-4">
                 Manual tracking disabled. AI Tracker is available for Pushups and Squats.
               </div>
             )}
            
            {/* FLOATING TEXTS */}
            <AnimatePresence>
              {floatingTexts.map((ft) => (
                <motion.div
                  key={ft.id}
                  initial={{ opacity: 1, y: 0, x: ft.x, scale: 1 }}
                  animate={{ opacity: 0, y: -60, scale: 1.5 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                  className="absolute pointer-events-none left-1/2 -translate-x-1/2 -top-10 text-white font-black text-3xl z-20 drop-shadow-md"
                >
                  {ft.text}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>`;

if (code.match(controlsRegex)) {
  code = code.replace(controlsRegex, controlsReplacement);
  fs.writeFileSync('src/components/WeeklyChallengeScreen.tsx', code);
  console.log('Fixed Weekly');
} else {
  console.log('Failed to fix Weekly');
}
