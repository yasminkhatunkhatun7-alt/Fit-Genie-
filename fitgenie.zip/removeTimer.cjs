const fs = require('fs');
let file = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');

const regex = /  \/\/ Music countdown timer effect[\s\S]*?\}, \[musicTimerRun, musicTimerLeft\]\);\n/g;
file = file.replace(regex, "");

fs.writeFileSync('src/components/YoddhaHub.tsx', file);
