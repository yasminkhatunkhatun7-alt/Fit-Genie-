const fs = require('fs');
let content = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

const target = '      {/* WEEKLY PROGRESS */}';
const newCard = `      {/* DAILY FITNESS INSIGHT CARD */}
      <motion.div 
        className="glass-card rounded-3xl p-5 relative overflow-hidden border border-[#14F1E1]/20 glow-cyan"
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-[#14F1E1]/5 to-transparent opacity-100" />
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-3">
            <Zap className="w-5 h-5 text-[#14F1E1]" />
            <h3 className="text-white text-sm font-bold uppercase tracking-wider">Daily Fitness Insight</h3>
          </div>
          {loadingInsight ? (
            <div className="animate-pulse flex space-x-4">
              <div className="flex-1 space-y-3 py-1">
                <div className="h-3 bg-white/10 rounded w-3/4"></div>
                <div className="h-3 bg-white/10 rounded w-5/6"></div>
              </div>
            </div>
          ) : (
            <p className="text-[#9CA3AF] text-sm leading-relaxed italic">
              "{dailyInsight || "Keep pushing forward! Consistency is the key to unlocking your true potential."}"
            </p>
          )}
        </div>
      </motion.div>

      {/* WEEKLY PROGRESS */}`;

content = content.replace(target, newCard);
fs.writeFileSync('src/components/HomeDashboard.tsx', content);
