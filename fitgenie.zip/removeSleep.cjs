const fs = require('fs');

let hd = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

// Remove sleep logs state block
const sleepLogsRegex = /  \/\/ Synchronized Sleep Logs\n  interface SleepLog \{[\s\S]*?  \}, \[sleepLogs\]\);\n/g;
hd = hd.replace(sleepLogsRegex, "");

// Remove widget block
const widgetRegex = /      \{\/\* SLEEP TRACKER HOME SCREEN WIDGET \*\/\}[\s\S]*?      \{\/\* LEADERBOARD HOME WIDGET \*\/\}/g;
hd = hd.replace(widgetRegex, "      {/* LEADERBOARD HOME WIDGET */}");

// Remove sleep from subtabs
hd = hd.replace(/\| "sleep" /g, "");

fs.writeFileSync('src/components/HomeDashboard.tsx', hd);

let yh = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');
yh = yh.replace(/\| "sleep" /g, "");

fs.writeFileSync('src/components/YoddhaHub.tsx', yh);
