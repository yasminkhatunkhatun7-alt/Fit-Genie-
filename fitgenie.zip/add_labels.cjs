const fs = require('fs');
let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

const dotCode = `                          <motion.div
                            key={\`dot-\${item.id}\`}
                            initial={{ opacity: 0, scale: 0 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.2 * (index + 1) }}
                            className="absolute pointer-events-none flex flex-col items-center"
                            style={{ left: \`\${item.landmark.x}%\`, top: \`\${item.landmark.y}%\`, transform: 'translate(-50%, -50%)', zIndex: 10 }}
                          >
                            <div className={\`w-2 h-2 rounded-full shadow-[0_0_8px_currentColor] shrink-0 \${isHighConf ? 'bg-[#14F1E1] text-[#14F1E1]' : 'bg-red-500 text-red-500'}\`} />
                            <div className="mt-1 bg-black/80 backdrop-blur-sm px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider text-white border border-white/10 whitespace-nowrap">
                              {item.title}
                            </div>
                          </motion.div>`;

code = code.replace(
  /<motion\.div\s*key=\{`dot-\$\{item\.id\}`\}\s*initial=\{\{ opacity: 0, scale: 0 \}\}\s*animate=\{\{ opacity: 1, scale: 1 \}\}\s*transition=\{\{ delay: 0\.2 \* \(index \+ 1\) \}\}\s*className="absolute pointer-events-none"\s*style=\{\{ left: `\$\{item\.landmark\.x\}%`, top: `\$\{item\.landmark\.y\}%`, transform: 'translate\(-50%, -50%\)', zIndex: 10 \}\}\s*>\s*<div className=\{`w-2 h-2 rounded-full shadow-\[0_0_8px_currentColor\] shrink-0 \$\{isHighConf \? 'bg-\[#14F1E1\] text-\[#14F1E1\]' : 'bg-red-500 text-red-500'\}`\} \/>\s*<\/motion\.div>/,
  dotCode
);

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done');
