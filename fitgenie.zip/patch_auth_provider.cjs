const fs = require('fs');

let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf-8');

const newProviderLogic = `
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [profileRequired, setProfileRequired] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userRef = doc(db, 'users', currentUser.uid);
          const userSnap = await getDoc(userRef);
          if (userSnap.exists()) {
            const p = userSnap.data() as UserProfile;
            
            // Handle streak check
            if (p.last_workout_date) {
              const todayStr = getLocalDateString(new Date());
              const diffDays = getDaysBetween(p.last_workout_date, todayStr);
              if (diffDays > 1) {
                p.streak = 0;
                await setDoc(userRef, { streak: 0 }, { merge: true });
              }
            }
            
            setProfile(p);
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(p));
          } else {
            // Profile doesn't exist yet, it should be created in signInWithGoogle.
            // But just in case, we can set profile to null to trigger onboarding.
            setProfile(null);
          }
        } catch (e) {
          console.error("Error fetching user profile:", e);
        }
      } else {
        setProfile(null);
        localStorage.removeItem(LOCAL_STORAGE_KEY);
        localStorage.removeItem("fitgenie_onboarding_completed");
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);
      
      if (userSnap.exists()) {
        const p = userSnap.data() as UserProfile;
        setProfile(p);
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(p));
        localStorage.setItem("fitgenie_onboarding_completed", "true");
      } else {
        const avatarStyles = ["bg-blue-500", "bg-pink-500", "bg-purple-500", "bg-emerald-500", "bg-orange-500", "bg-indigo-500"];
        const avatarIndex = user.uid.length % avatarStyles.length;
        const avatarBg = \`\${avatarStyles[avatarIndex]} text-white border-\${avatarStyles[avatarIndex].replace('bg-', '')}\`;
        
        const newProfile: UserProfile = {
          uid: user.uid,
          username: user.displayName || 'Warrior',
          email: user.email || '',
          photoURL: user.photoURL || '',
          xp: 0,
          rank: getRankFromXP(0),
          streak: 0,
          joinDate: getLocalDateString(new Date()),
          integrityScore: 100,
          onboardingCompleted: false,
          avatarBg
        };
        
        // Also save required fields for WorldChat Leaderboard
        await setDoc(userRef, {
          ...newProfile,
          userId: user.uid,
          userName: newProfile.username
        });
        
        setProfile(newProfile);
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newProfile));
        localStorage.removeItem("fitgenie_onboarding_completed");
      }
    } catch (error) {
      console.error("Error signing in with Google", error);
      throw error;
    }
  };

  const saveProfile = async (updatedProfile: UserProfile) => {
    setProfile(updatedProfile);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedProfile));
    
    // Sync to Firestore
    try {
      if (updatedProfile.uid && updatedProfile.uid !== 'local_user') {
        const avatarStyles = ["bg-blue-500", "bg-pink-500", "bg-purple-500", "bg-emerald-500", "bg-orange-500", "bg-indigo-500"];
        const avatarIndex = updatedProfile.uid.length % avatarStyles.length;
        const avatarBg = updatedProfile.avatarBg || \`\${avatarStyles[avatarIndex]} text-white border-\${avatarStyles[avatarIndex].replace('bg-', '')}\`;
        
        const userRef = doc(db, 'users', updatedProfile.uid);
        await setDoc(userRef, {
          ...updatedProfile,
          userId: updatedProfile.uid,
          userName: updatedProfile.username || 'Anonymous Genin',
          xp: updatedProfile.xp || 0,
          avatarBg: avatarBg,
        }, { merge: true });
      }
    } catch (e) {
      console.error('Failed to sync profile to Firebase', e);
    }
  };
`;

const oldProviderMatch = code.match(/export function AuthProvider.*?(?=\s*const saveProfile =)/s);
if (oldProviderMatch) {
  code = code.replace(oldProviderMatch[0] + "  const saveProfile = (updatedProfile: UserProfile) => {", newProviderLogic.trim().replace("const saveProfile = async (updatedProfile: UserProfile) => {", ""));
  // But wait, it's easier to just use regex to replace everything from export function AuthProvider up to the end of saveProfile
}
fs.writeFileSync('patch_temp.cjs', code);
