const fs = require('fs');

let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

code = code.replace(
  'import { useAuth } from "../context/AuthContext";',
  'import { useAuth, getTrustGrade } from "../context/AuthContext";'
);

code = code.replace(
  '<span className="text-4xl font-black font-mono text-[#4DA8FF]">{profile?.integrityScore || 100}%</span>',
  '<span className="text-4xl font-black font-mono text-[#4DA8FF]">{profile?.integrityScore || 100}% <span className="text-xl ml-2 text-white/50">({getTrustGrade(profile?.integrityScore || 100)})</span></span>'
);

fs.writeFileSync('src/components/GuardianOrb.tsx', code);
