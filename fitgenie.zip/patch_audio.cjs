const fs = require('fs');
let content = fs.readFileSync('src/utils/audio.ts', 'utf8');

content = content.replace(
  /synth\(1046\.50, now \+ 0\.35, 0\.45\); \/\/ C6 Premium wrap-up chime\n        break;\n      }/g,
  `synth(1046.50, now + 0.35, 0.45); // C6 Premium wrap-up chime
        break;
      }
      case "error": {
        // A harsh discordant double beep
        const playBeep = (start: number) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.type = "sawtooth";
          osc.frequency.setValueAtTime(150, start);
          osc.frequency.exponentialRampToValueAtTime(100, start + 0.1);
          gain.gain.setValueAtTime(0.1, start);
          gain.gain.exponentialRampToValueAtTime(0.001, start + 0.15);
          osc.start(start);
          osc.stop(start + 0.2);
        };
        playBeep(now);
        playBeep(now + 0.15);
        break;
      }`
);

fs.writeFileSync('src/utils/audio.ts', content);
