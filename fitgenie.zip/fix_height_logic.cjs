const fs = require('fs');

const file = 'src/components/HeightIncrease.tsx';
let code = fs.readFileSync(file, 'utf-8');

// 1. Add missing imports
code = code.replace('} from "lucide-react";', '  Heart, Trophy, BookOpen, Settings\n} from "lucide-react";');

// 2. Add favorites and rest timer state right before return
const stateInjection = `
  const [favorites, setFavorites] = useState<string[]>([]);
  const [restTimerLeft, setRestTimerLeft] = useState<number | null>(null);
  
  useEffect(() => {
    if (restTimerLeft === null || restTimerLeft <= 0) return;
    const timerId = setInterval(() => {
      setRestTimerLeft(prev => prev ? prev - 1 : 0);
    }, 1000);
    return () => clearInterval(timerId);
  }, [restTimerLeft]);

  // `;

code = code.replace('  return (\n    <div className="py-6', stateInjection + 'return (\n    <div className="py-6');

fs.writeFileSync(file, code);
console.log("Logic injected!");
