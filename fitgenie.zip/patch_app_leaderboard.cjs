const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(/leaderboard: 4,/g, '');
content = content.replace(/onNavigateToLeaderboard=\{\(\) => navigateToView\("leaderboard"\)\}/g, '');
content = content.replace(/\{ id: "leaderboard", name: "Gym Rankings", icon: <Crown className="w-3.5 h-3.5" \/> \},/g, '');

fs.writeFileSync('src/App.tsx', content);
