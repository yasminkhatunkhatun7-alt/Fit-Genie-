const fs = require('fs');
let content = fs.readFileSync('src/components/MartialArts.tsx', 'utf8');

// Remove firebase imports
content = content.replace(/import { db, OperationType, handleFirestoreError } from "\.\.\/firebase";/g, '');
content = content.replace(/import { collection, doc, setDoc, onSnapshot } from "firebase\/firestore";/g, '');

// Replace useEffect for onSnapshot
content = content.replace(
  /const unsub = onSnapshot\(collection\(db, "martial_arts_videos"\), \(snapshot\) => \{[\s\S]*?\}\);[\s\S]*?return \(\) => unsub\(\);/m,
  `const storedVideos = localStorage.getItem("fitgenie_martial_arts_videos");
    if (storedVideos) {
      setVideoUrls(JSON.parse(storedVideos));
    }`
);

// Replace setDoc
content = content.replace(
  /await setDoc\(doc\(db, "martial_arts_videos", adminLessonId\), \{[\s\S]*?\}\);/m,
  `const newUrls = { ...videoUrls, [adminLessonId]: adminVideoUrl };
      setVideoUrls(newUrls);
      localStorage.setItem("fitgenie_martial_arts_videos", JSON.stringify(newUrls));`
);

fs.writeFileSync('src/components/MartialArts.tsx', content);
