const fs = require('fs');
let appContent = fs.readFileSync('src/App.tsx', 'utf8');
appContent = appContent.replace(
  'type AppView = "home" | "dojo" | "exercises" | "calisthenics" | "calisthenics_videos" | "mogged" | "achievements" | "chat" | "history" | "about" | "exercise_videos" | "privacy" | "terms";',
  'type AppView = "home" | "dojo" | "exercises" | "calisthenics" | "calisthenics_videos" | "mogged" | "achievements" | "chat" | "history" | "about" | "exercise_videos" | "privacy" | "terms" | "settings";'
);
appContent = appContent.replace(
  '{ home: 0, dojo: 1, exercises: 2, calisthenics: 3, calisthenics_videos: 4, mogged: 5, achievements: 6, chat: 7, history: 8, about: 9, exercise_videos: 10, privacy: 11, terms: 12 }',
  '{ home: 0, dojo: 1, exercises: 2, calisthenics: 3, calisthenics_videos: 4, mogged: 5, achievements: 6, chat: 7, history: 8, about: 9, exercise_videos: 10, privacy: 11, terms: 12, settings: 13 }'
);
fs.writeFileSync('src/App.tsx', appContent);

let leaderboardContent = fs.readFileSync('src/components/Leaderboards.tsx', 'utf8');
leaderboardContent = leaderboardContent.replace('const data = docSnap.data();', 'const data = docSnap.data() as any;');
leaderboardContent = leaderboardContent.replace('import { Trophy, Ghost, ChevronLeft, Loader2 } from "lucide-react";', 'import { Trophy, Ghost, ChevronLeft, Loader2, RefreshCw } from "lucide-react";');
fs.writeFileSync('src/components/Leaderboards.tsx', leaderboardContent);

let profileViewContent = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');
profileViewContent = profileViewContent.replace(
  'const [savingBio, setSavingBio] = useState(false);',
  'const [savingBio, setSavingBio] = useState(false);\n  const [error, setError] = useState("");'
);
fs.writeFileSync('src/components/ProfileView.tsx', profileViewContent);

let settingsScreenContent = fs.readFileSync('src/components/SettingsScreen.tsx', 'utf8');
settingsScreenContent = settingsScreenContent.replace(
  'checked={localSettings.isPrivate}',
  'checked={(localSettings as any).isPrivate || false}'
);
settingsScreenContent = settingsScreenContent.replace(
  'checked={localSettings.notifyFriendRequests}',
  'checked={(localSettings as any).notifyFriendRequests || false}'
);
settingsScreenContent = settingsScreenContent.replace(
  'checked={localSettings.notifyRecordBeaten}',
  'checked={(localSettings as any).notifyRecordBeaten || false}'
);
settingsScreenContent = settingsScreenContent.replace(
  'checked={localSettings.notifyChatMessages}',
  'checked={(localSettings as any).notifyChatMessages || false}'
);
settingsScreenContent = settingsScreenContent.replace(
  'checked={localSettings.notifyStreakReminders}',
  'checked={(localSettings as any).notifyStreakReminders || false}'
);
fs.writeFileSync('src/components/SettingsScreen.tsx', settingsScreenContent);
