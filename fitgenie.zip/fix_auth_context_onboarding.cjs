const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf-8');

const targetStr = `            setProfile(p);
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(p));
          } else {`;

const replacementStr = `            setProfile(p);
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(p));
            if (p.onboardingCompleted) {
              localStorage.setItem("fitgenie_onboarding_completed", "true");
            }
          } else {`;

code = code.replace(targetStr, replacementStr);

fs.writeFileSync('src/context/AuthContext.tsx', code);
