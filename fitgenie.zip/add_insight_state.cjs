const fs = require('fs');
let content = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

const insertionPoint = '  const [selectedVoice, setSelectedVoice] = useState<string | null>(null);';
const newState = `  const [selectedVoice, setSelectedVoice] = useState<string | null>(null);
  const [dailyInsight, setDailyInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);

  useEffect(() => {
    const fetchInsight = async () => {
      const lastFetchDate = localStorage.getItem("daily_insight_date");
      const savedInsight = localStorage.getItem("daily_insight_text");
      
      if (lastFetchDate === todayStr && savedInsight) {
        setDailyInsight(savedInsight);
        return;
      }

      setLoadingInsight(true);
      try {
        const res = await fetch("/api/fitness-insight", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ goal: profile?.mainGoal || "general fitness" })
        });
        const data = await res.json();
        if (data.insight) {
          setDailyInsight(data.insight);
          localStorage.setItem("daily_insight_date", todayStr);
          localStorage.setItem("daily_insight_text", data.insight);
        }
      } catch (e) {
        console.error("Failed to fetch insight", e);
      } finally {
        setLoadingInsight(false);
      }
    };
    fetchInsight();
  }, [profile?.mainGoal, todayStr]);`;

content = content.replace(insertionPoint, newState);
fs.writeFileSync('src/components/HomeDashboard.tsx', content);
