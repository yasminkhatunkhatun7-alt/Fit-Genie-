const fs = require('fs');
const glob = require('glob');

// Use glob to find all tsx files
glob('src/**/*.tsx', (err, files) => {
  if (err) throw err;
  files.forEach(file => {
    let content = fs.readFileSync(file, 'utf8');
    let changed = false;

    // 1. WeeklyChallengeScreen / StrengthChallengeScreen / CustomChallengeDetailScreen
    // "BOSS: LEG DESTROYER"
    if (content.includes("text-3xl font-black uppercase tracking-tight text-white relative z-10 drop-shadow-lg")) {
      content = content.replace(
        "text-3xl font-black uppercase tracking-tight text-white relative z-10 drop-shadow-lg",
        "text-2xl md:text-3xl font-black uppercase tracking-tight text-white relative z-10 drop-shadow-lg break-words"
      );
      changed = true;
    }
    if (content.includes("text-2xl font-black uppercase tracking-tight text-white relative z-10")) {
      content = content.replace(
        "text-2xl font-black uppercase tracking-tight text-white relative z-10",
        "text-xl md:text-2xl font-black uppercase tracking-tight text-white relative z-10 break-words"
      );
      changed = true;
    }
    
    // 2. Placeholder text "Search stretches, bone groups or muscle tags..."
    if (content.includes('placeholder="Search stretches, bone groups or muscle tags..."')) {
      content = content.replace(
        'placeholder="Search stretches, bone groups or muscle tags..."',
        'placeholder="Search stretches, muscles..."'
      );
      changed = true;
    }

    // 3. Remove aggressive truncate classes that cut off text
    if (content.includes("truncate")) {
       // Only replace where it's causing issues. Actually let's just replace `truncate max-w-[150px]` with `line-clamp-2` or similar where applicable, or remove max-w.
       content = content.replace(/truncate max-w-\[\d+px\]/g, 'line-clamp-2 break-words');
       content = content.replace(/truncate max-w-xs/g, 'line-clamp-2 break-words');
       content = content.replace(/truncate max-w-sm/g, 'line-clamp-2 break-words');
       changed = true;
    }

    if (changed) {
      fs.writeFileSync(file, content);
      console.log('Fixed truncation in:', file);
    }
  });
});
