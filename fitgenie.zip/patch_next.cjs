const fs = require('fs');
let code = fs.readFileSync('src/components/DailyChallengeDetailScreen.tsx', 'utf-8');

code = code.replace(
  `if (currentExerciseIndex < challenge.exercises.length - 1) {
          setCurrentExerciseIndex(prev => prev + 1);
       }`,
  `const nextIncomplete = updated.exercises.findIndex(e => e.completedReps < e.targetReps);
       if (nextIncomplete !== -1) {
          setCurrentExerciseIndex(nextIncomplete);
       }`
);

fs.writeFileSync('src/components/DailyChallengeDetailScreen.tsx', code);
console.log("Patched auto-advance");
