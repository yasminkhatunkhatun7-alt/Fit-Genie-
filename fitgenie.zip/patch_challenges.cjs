const fs = require('fs');
const file = 'src/components/ChallengesScreen.tsx';
let code = fs.readFileSync(file, 'utf8');

code = code.replace(
  '  const { updateProfileStats } = useAuth();',
  '  const { updateProfileStats, profile, updateUserProfileFields } = useAuth();'
);

const oldCompleteChallenge = `    if (updateProfileStats && xpToAward > 0) {
      await updateProfileStats({ 
        xpGained: xpToAward,
        challengeWon: true
      });
    }`;
    
const newCompleteChallenge = `    if (updateProfileStats && xpToAward > 0) {
      await updateProfileStats({ 
        xpGained: xpToAward,
        challengeWon: true
      });
    }

    // Leaderboard Stats Update for Speed Challenge
    if (activeChallenge.id === 'speed' && profile && updateUserProfileFields) {
      const exerciseName = activeChallenge.exercises[0].name.toLowerCase();
      const completedReps = activeChallenge.exercises[0].completedReps || 0;
      const currentStats = profile.stats || {};
      
      let updatedStats = { ...currentStats };
      let shouldUpdate = false;
      
      if (exerciseName.includes('squat')) {
         if (completedReps > (currentStats.squats_1min || 0)) {
            updatedStats.squats_1min = completedReps;
            shouldUpdate = true;
         }
      } else if (exerciseName.includes('push')) {
         if (completedReps > (currentStats.pushups_1min || 0)) {
            updatedStats.pushups_1min = completedReps;
            shouldUpdate = true;
         }
      }
      
      if (shouldUpdate) {
         try {
            await updateUserProfileFields({ stats: updatedStats });
            console.log("Leaderboard stats updated!", updatedStats);
         } catch(e) {
            console.error("Failed to update leaderboard stats:", e);
         }
      }
    }`;

code = code.replace(oldCompleteChallenge, newCompleteChallenge);
fs.writeFileSync(file, code);
