const fs = require('fs');
let app = fs.readFileSync('src/App.tsx', 'utf8');

if (!app.includes('mode="wait"')) {
  app = app.replace(
    '{renderContent()}',
    '<AnimatePresence mode="wait">\n            <motion.div\n              key={activeTab}\n              initial={{ opacity: 0, y: 10 }}\n              animate={{ opacity: 1, y: 0 }}\n              exit={{ opacity: 0, y: -10 }}\n              transition={{ duration: 0.2, ease: "easeInOut" }}\n              className="flex-1 flex flex-col min-h-0"\n            >\n              {renderContent()}\n            </motion.div>\n          </AnimatePresence>'
  );
  fs.writeFileSync('src/App.tsx', app);
}
