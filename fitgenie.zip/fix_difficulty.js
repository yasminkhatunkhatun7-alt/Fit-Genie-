const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');
code = code.replace(
  'startTime: Date.now()',
  `startTime: Date.now(),
      difficulty: uniqueExercises.length >= 6 ? "Elite" : uniqueExercises.length >= 4 ? "Advanced" : uniqueExercises.length >= 2 ? "Intermediate" : "Beginner"`
);
fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
