const fs = require('fs');

let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

content = content.replace(
  'if (newIntegrityScore === 0) isRecoveringFromZero = true;',
  'if (newIntegrityScore <= 0) isRecoveringFromZero = true;'
);

fs.writeFileSync('src/context/AuthContext.tsx', content);
