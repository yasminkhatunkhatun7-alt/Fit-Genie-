import { initializeApp } from "firebase/app";
import { initializeFirestore, collection, getDocs } from "firebase/firestore";
import fs from "fs";

async function run() {
  const firebaseConfig = JSON.parse(fs.readFileSync("./firebase-applet-config.json", "utf-8"));
  const app = initializeApp(firebaseConfig);
  // Default database ID is '(default)'
  const db = initializeFirestore(app, {
    experimentalForceLongPolling: true,
  });

  console.log("Starting Firebase query on DEFAULT database...");
  const timer = setTimeout(() => {
    console.error("Query timed out!");
    process.exit(1);
  }, 10000);

  try {
    const querySnapshot = await getDocs(collection(db, "exercises"));
    const data: any[] = [];
    querySnapshot.forEach((doc) => {
      data.push({ id: doc.id, ...doc.data() });
    });
    clearTimeout(timer);
    console.log(`Success! Read ${data.length} exercises from default database`);
    process.exit(0);
  } catch (err: any) {
    console.error("Failed to query on default database:", err.message);
    process.exit(1);
  }
}

run();
