const fs = require('fs');

let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

// Add Mic import
code = code.replace("import { Search, ", "import { Search, Mic, MicOff, ");

// Add state for speech
code = code.replace(
  "const [searchQuery, setSearchQuery] = useState('');\n  const fileInputRef = useRef<HTMLInputElement>(null);",
  "const [searchQuery, setSearchQuery] = useState('');\n  const fileInputRef = useRef<HTMLInputElement>(null);\n  const [isListening, setIsListening] = useState(false);\n  const recognitionRef = useRef<any>(null);\n\n  const toggleListen = () => {\n    if (isListening) {\n      recognitionRef.current?.stop();\n      setIsListening(false);\n    } else {\n      const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;\n      if (SpeechRecognition) {\n        recognitionRef.current = new SpeechRecognition();\n        recognitionRef.current.continuous = false;\n        recognitionRef.current.interimResults = false;\n        \n        recognitionRef.current.onstart = () => {\n          setIsListening(true);\n        };\n        \n        recognitionRef.current.onresult = (event: any) => {\n          const transcript = event.results[0][0].transcript;\n          setSearchQuery(transcript);\n        };\n        \n        recognitionRef.current.onerror = (event: any) => {\n          console.error(\"Speech recognition error\", event.error);\n          setIsListening(false);\n        };\n        \n        recognitionRef.current.onend = () => {\n          setIsListening(false);\n        };\n        \n        recognitionRef.current.start();\n      } else {\n        alert(\"Speech recognition is not supported in this browser.\");\n      }\n    }\n  };\n"
);

// Add Mic button to search bar
const newSearchInput = `            <input
              type="text"
              placeholder="Search categories or exercises..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="block w-full pl-10 pr-10 py-2 border border-neutral-800 rounded-xl leading-5 bg-neutral-900/50 text-neutral-300 placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-[#14F1E1]/50 focus:border-[#14F1E1]/50 sm:text-sm transition-colors"
            />
            <button
              onClick={toggleListen}
              className={\`absolute inset-y-0 right-0 pr-3 flex items-center transition-colors \${isListening ? 'text-red-500 animate-pulse' : 'text-neutral-500 hover:text-[#14F1E1]'}\`}
            >
              {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </button>`;

code = code.replace(
  /<input\s+type="text"\s+placeholder="Search categories or exercises..."\s+value=\{searchQuery\}\s+onChange=\{\(e\) => setSearchQuery\(e.target.value\)\}\s+className="block w-full pl-10 pr-3 py-2 border border-neutral-800 rounded-xl leading-5 bg-neutral-900\/50 text-neutral-300 placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring\[#14F1E1\]\/50 focus:border-\[#14F1E1\]\/50 sm:text-sm transition-colors"\s+\/>/,
  newSearchInput
);

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done');
