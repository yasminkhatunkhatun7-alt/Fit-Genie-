const fs = require('fs');
let code = fs.readFileSync('src/components/WorkoutHistory.tsx', 'utf-8');

// Add the editingExercise state
if (!code.includes('const [editingExercise')) {
    code = code.replace(
        'const [viewMode, setViewMode] = useState<"detailed" | "compact">("detailed");',
        'const [viewMode, setViewMode] = useState<"detailed" | "compact">("detailed");\n  const [editingExercise, setEditingExercise] = useState<{ sessionId: string, exIdx: number, weight: number, reps: number } | null>(null);\n\n  const handleSaveExercise = (sessionId: string, exIdx: number, weight: number, reps: number) => {\n    const session = history.find(s => s.id === sessionId);\n    if (!session) return;\n    const updated = { ...session, exercises: [...session.exercises] };\n    updated.exercises[exIdx] = { ...updated.exercises[exIdx], weight, reps };\n    onUpdateSession(updated);\n    setEditingExercise(null);\n  };\n'
    );
}

// Update the map rendering
const mapRegex = /<div\s+key=\{ex\.id \|\| exIdx\}\s+className="p-2\.5 bg-\[#121212\] border border-brand-border\/60 rounded-xl flex items-center justify-between text-xs"\s*>([\s\S]*?)<\/div>\s*\)\)\}/m;

const replacement = `
                                  <div
                                    key={ex.id || exIdx}
                                    className="p-2.5 bg-[#121212] border border-brand-border/60 rounded-xl flex flex-col justify-between text-xs cursor-pointer hover:border-brand-accent/30 transition-colors"
                                    onClick={() => {
                                      if (editingExercise?.sessionId !== session.id || editingExercise?.exIdx !== exIdx) {
                                        setEditingExercise({ sessionId: session.id, exIdx, weight: ex.weight || 0, reps: ex.reps });
                                      }
                                    }}
                                  >
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2">
                                        <span className="w-4 h-4 bg-brand-accent/10 rounded-full border border-brand-accent/20 flex items-center justify-center text-[9px] text-brand-accent font-black">
                                          {exIdx + 1}
                                        </span>
                                        <div>
                                          <p className="font-bold text-white">{ex.name_en}</p>
                                          <p className="text-[10px] text-brand-muted">{ex.name_hi}</p>
                                        </div>
                                      </div>
                                      {!(editingExercise?.sessionId === session.id && editingExercise?.exIdx === exIdx) && (
                                        <div className="text-right">
                                          <span className="text-[11px] font-mono font-black text-brand-accent uppercase bg-brand-accent/10 border border-brand-accent/20 px-2 py-0.5 rounded-md">
                                            {ex.sets}s × {ex.reps}r {ex.weight ? \`@ \${ex.weight}kg\` : ''}
                                          </span>
                                        </div>
                                      )}
                                    </div>
                                    
                                    {(editingExercise?.sessionId === session.id && editingExercise?.exIdx === exIdx) && (
                                      <div className="mt-3 pt-3 border-t border-brand-border/40 flex items-end gap-2" onClick={e => e.stopPropagation()}>
                                        <div className="flex-1">
                                          <label className="text-[9px] text-brand-muted uppercase font-bold tracking-widest block mb-1">Reps per set</label>
                                          <input 
                                            type="number" 
                                            className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg px-2 py-2 text-white font-mono focus:border-brand-accent outline-none"
                                            value={editingExercise.reps}
                                            onChange={e => setEditingExercise(prev => prev ? {...prev, reps: Number(e.target.value)} : null)}
                                          />
                                        </div>
                                        <div className="flex-1">
                                          <label className="text-[9px] text-brand-muted uppercase font-bold tracking-widest block mb-1">Weight (kg)</label>
                                          <input 
                                            type="number" 
                                            className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg px-2 py-2 text-white font-mono focus:border-brand-accent outline-none"
                                            value={editingExercise.weight}
                                            onChange={e => setEditingExercise(prev => prev ? {...prev, weight: Number(e.target.value)} : null)}
                                          />
                                        </div>
                                        <div className="flex gap-2 ml-2 pb-0.5">
                                          <button 
                                            onClick={(e) => { e.stopPropagation(); setEditingExercise(null); }}
                                            className="px-3 py-2 rounded-lg bg-[#222] text-white hover:bg-[#333] transition-colors font-bold uppercase tracking-widest text-[10px]"
                                          >
                                            Cancel
                                          </button>
                                          <button 
                                            onClick={(e) => { e.stopPropagation(); handleSaveExercise(session.id, exIdx, editingExercise.weight, editingExercise.reps); }}
                                            className="px-3 py-2 rounded-lg bg-brand-accent text-brand-bg hover:bg-white transition-colors font-bold uppercase tracking-widest text-[10px]"
                                          >
                                            Save
                                          </button>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                ))}
`;

if (code.match(mapRegex)) {
    code = code.replace(mapRegex, replacement.trim());
    fs.writeFileSync('src/components/WorkoutHistory.tsx', code);
    console.log("Updated WorkoutHistory.tsx");
} else {
    console.log("Could not find the map block to replace.");
}
