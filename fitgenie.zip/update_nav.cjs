const fs = require('fs');

let file = fs.readFileSync('src/components/BottomNavigation.tsx', 'utf8');

file = file.replace('Globe', 'Globe, MessageCircle');
file = file.replace('view: "world" as AppView,', 'view: "chat" as AppView,');
file = file.replace('label: "World",', 'label: "Chat",');
file = file.replace('<Globe className="w-5 h-5" />', '<MessageCircle className="w-5 h-5" />');

fs.writeFileSync('src/components/BottomNavigation.tsx', file);
