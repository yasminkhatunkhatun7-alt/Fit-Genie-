const fs = require('fs');

let code = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

if (!code.includes('useGuardianContext')) {
    code = code.replace(/import \{ useAuth, getRankDetails \} from "\.\.\/context\/AuthContext";/, 'import { useAuth, getRankDetails } from "../context/AuthContext";\nimport { useGuardianContext } from "../context/GuardianContext";');
    
    const insertPoint = code.indexOf('const { profile, signOutUser } = useAuth();');
    
    code = code.slice(0, insertPoint) + `const { triggerEvent } = useGuardianContext();\n  useEffect(() => {\n    triggerEvent("home_greet");\n  }, []);\n  ` + code.slice(insertPoint);
    
    fs.writeFileSync('src/components/HomeDashboard.tsx', code);
}
