const fs = require('fs');
let code = fs.readFileSync('src/components/AiRepCounter.tsx', 'utf-8');

// Remove detectPose completely
const detectPoseRegex = /  const detectPose = \(\) => \{[\s\S]*?  const updatePushupState/m;
code = code.replace(detectPoseRegex, '  const updatePushupState');

// Remove detectPose call from useEffect
const useEffectRegex = /  useEffect\(\(\) => \{\s*if \(isActive\) \{\s*detectPose\(\);\s*\}\s*return \(\) => \{\s*if \(animationRef\.current\) cancelAnimationFrame\(animationRef\.current\);\s*\};\s*\}, \[isActive, exercise\]\);/m;
code = code.replace(useEffectRegex, '');

fs.writeFileSync('src/components/AiRepCounter.tsx', code);
console.log("Cleaned up detectPose");
