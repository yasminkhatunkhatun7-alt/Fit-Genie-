import fetch from "node-fetch"; // or builtin fetch if node version allows

async function main() {
  const ids = ["62sm1cJzivQ", "vCWcYF5PiQg", "0kU-IJQs6Bk"];
  for (const id of ids) {
    const url = `https://www.youtube.com/watch?v=${id}`;
    try {
      const res = await fetch(url, {
        headers: {
          "User-Agent": "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_hosted_html.php)"
        }
      });
      const html = await res.text();
      console.log(`=== ID: ${id} ===`);
      const metaTags = html.match(/<meta\s+[^>]*>/gi) || [];
      for (const tag of metaTags) {
        if (tag.includes("og:title") || tag.includes("title") || tag.includes("description") || tag.includes("keywords") || tag.includes("name=\"title\"")) {
          console.log(tag);
        }
      }
      console.log("\n");
    } catch (err: any) {
      console.error(err);
    }
  }
}

main();
