const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');

code = code.replace(
  /id: "pushup",[\s\S]*?\{[\s\S]*?id: "pushup",/,
  '{ id: "pushup",'
);

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
