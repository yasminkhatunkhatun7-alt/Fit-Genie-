const fs = require('fs');

let appCode = fs.readFileSync('src/App.tsx', 'utf8');

// Add triggerEvent
const searchHook = "  const [view, setView] = useState<AppView>(\"home\");";
if (appCode.includes(searchHook) && !appCode.includes('const { triggerEvent } = useGuardianContext();')) {
  appCode = appCode.replace(searchHook, searchHook + "\n  const { triggerEvent } = useGuardianContext();");
}

// Fix navigateToView types
const oldNav = `  const navigateToView = (newView: AppView, params?: any) => {
    const now = Date.now();
    if (now - lastNavTime < 120) return; // Guard against rapid multi-clicking
    setLastNavTime(now);
    if (newView !== view) {
      if (newView === 'home') triggerEvent("nav_home");
      else if (newView === 'challenges') triggerEvent("nav_challenge");
      else if (newView === 'generator' || newView === 'daily') triggerEvent("nav_workout");
      else if (newView === 'profile') triggerEvent("nav_profile");
      else triggerEvent("focused");
      setPrevView(view);
      setView(newView);`;
      
const newNav = `  const navigateToView = (newView: AppView, params?: any) => {
    const now = Date.now();
    if (now - lastNavTime < 120) return; // Guard against rapid multi-clicking
    setLastNavTime(now);
    if (newView !== view) {
      if (newView === 'home') triggerEvent("nav_home");
      else if (newView === 'dojo') triggerEvent("nav_challenge");
      else if (newView === 'generator' || newView === 'exercises' || newView === 'calisthenics') triggerEvent("nav_workout");
      else if (newView === 'profile') triggerEvent("nav_profile");
      else triggerEvent("focused");
      setPrevView(view);
      setView(newView);`;

appCode = appCode.replace(oldNav, newNav);

fs.writeFileSync('src/App.tsx', appCode);

