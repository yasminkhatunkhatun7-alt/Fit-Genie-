const fs = require('fs');

let profile = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');

if (!profile.includes("retryCount")) {
  profile = profile.replace(
    'const [error, setError] = useState<string | null>(null);',
    'const [error, setError] = useState<string | null>(null);\n  const [retryCount, setRetryCount] = useState(0);'
  );
  
  profile = profile.replace(
    'setRefreshKey(k => k + 1)',
    'setRetryCount(c => c + 1)'
  );
  
  // Find useEffect and add retryCount
  profile = profile.replace(
    ']}, [profile, targetId]);',
    ']}, [profile, targetId, retryCount]);'
  );

  fs.writeFileSync('src/components/ProfileView.tsx', profile);
}
