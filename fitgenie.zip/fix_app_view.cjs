const fs = require('fs');

let content = fs.readFileSync('src/App.tsx', 'utf8');
content = content.replace(/  generator: 1,\n/, '');
content = content.replace(/newView === 'generator' \|\| /, '');
fs.writeFileSync('src/App.tsx', content);

let typesContent = fs.readFileSync('src/types.ts', 'utf8');
typesContent = typesContent.replace(/  \| "generator"\s*\n/, '');
fs.writeFileSync('src/types.ts', typesContent);
