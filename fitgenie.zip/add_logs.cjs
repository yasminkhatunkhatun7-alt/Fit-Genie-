const fs = require('fs');

// Update App.tsx
let appCode = fs.readFileSync('src/App.tsx', 'utf-8');
appCode = appCode.replace(
  'const isOnboardingDone = profile ? !!profile.onboardingCompleted : (!!userPayload?.user?.onboardingDone || onboardingDone);',
  `// ADDED LOGGING FOR INVESTIGATION
  console.log("[App.tsx] Auth State Check:", {
    hasUser: !!user,
    userId: user?.uid,
    hasProfile: !!profile,
    profileOnboardingFlag: profile?.onboardingCompleted,
    localPayloadFlag: userPayload?.user?.onboardingDone,
    localStateFlag: onboardingDone
  });

  const isOnboardingDone = profile ? !!profile.onboardingCompleted : (!!userPayload?.user?.onboardingDone || onboardingDone);`
);
fs.writeFileSync('src/App.tsx', appCode);

// Update AuthContext.tsx
let authCode = fs.readFileSync('src/context/AuthContext.tsx', 'utf-8');
authCode = authCode.replace(
  'setUser(currentUser);',
  `setUser(currentUser);
      console.log("[AuthContext] onAuthStateChanged triggered. currentUser:", currentUser?.uid);`
);

authCode = authCode.replace(
  '            setProfile(p);',
  `            console.log("[AuthContext] Profile fetched for user:", p.uid, "Onboarding Completed:", p.onboardingCompleted);
            setProfile(p);`
);

fs.writeFileSync('src/context/AuthContext.tsx', authCode);
