const fs = require('fs');

const code = `import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Trophy, Activity, Target, CheckCircle2, ShieldAlert, CalendarDays, Flame, Shield, Skull, Lock, Zap, Clock, Star, Crown, Sword } from "lucide-react";
import { playSound } from "../utils/audio";
import { useAuth } from "../context/AuthContext";
import { ActiveChallenge } from "./ChallengesScreen";

interface OneMonthChallengeScreenProps {
  challenge: ActiveChallenge;
  onUpdate: (updated: ActiveChallenge) => void;
  onBack: () => void;
  onComplete: (xpToAward: number) => void;
}

type MonthMode = 'none' | 'normal' | 'legendary';

interface MonthRPGState {
  mode: MonthMode;
  startDate: string;
  progress: Record<string, number>;
  streak: number;
  longestStreak: number;
  lastActiveDate: string;
  activeDaysCount: number;
  recoveryTokens: number;
  validationFailed: boolean;
  suspiciousFlags: number;
  weeklyBossesDefeated: number[];
  claimedFinal: boolean;
  completedDays: string[];
}

const TARGETS = {
  normal: { Pushups: 1000, Squats: 1500, Crunches: 600, Burpees: 300 },
  legendary: { Pushups: 5000, Squats: 5000, Crunches: 2500, Burpees: 2500 }
};

const BOSSES = {
  normal: { name: "Consistency Guardian", maxHp: 3400, icon: Shield, color: "text-blue-400", bg: "bg-blue-500", border: "border-blue-500" },
  legendary: { name: "Titan Of Discipline", maxHp: 15000, icon: Skull, color: "text-red-500", bg: "bg-red-500", border: "border-red-500" }
};

const WEEKLY_BOSSES = [
  { id: 1, name: "Sloth Demon", hpThreshold: 0.25, reward: "Bronze Chest" },
  { id: 2, name: "Doubt Phantom", hpThreshold: 0.50, reward: "Silver Chest" },
  { id: 3, name: "Fatigue Brute", hpThreshold: 0.75, reward: "Gold Chest" },
  { id: 4, name: "Month Boss", hpThreshold: 1.00, reward: "Legendary Chest" }
];

const getTodayStr = () => new Date().toISOString().split('T')[0];

const getMotivation = (day: number) => {
  if (day >= 90) return "You didn't quit.";
  if (day >= 81) return "Finish line ahead.";
  if (day >= 61) return "You're becoming unstoppable.";
  if (day >= 41) return "Most people never reach this point.";
  if (day >= 21) return "Discipline is becoming habit.";
  if (day >= 8) return "You're building discipline.";
  return "Start small. Stay consistent.";
};

export default function OneMonthChallengeScreen({ challenge, onUpdate, onBack, onComplete }: OneMonthChallengeScreenProps) {
  const { profile } = useAuth();
  const storageKey = \`onemonth_rpg_\${profile?.uid}\`;
  const rankKey = \`onemonth_rank_\${profile?.uid}\`;
  
  const [monthState, setMonthState] = useState<MonthRPGState>(() => {
    const saved = localStorage.getItem(storageKey);
    if (saved) {
       try { 
         const parsed = JSON.parse(saved); 
         if (parsed && parsed.mode) return parsed;
       } catch (e) {}
    }
    return {
      mode: 'none',
      startDate: '',
      progress: { Pushups: 0, Squats: 0, Crunches: 0, Burpees: 0 },
      streak: 0,
      longestStreak: 0,
      lastActiveDate: "",
      activeDaysCount: 0,
      recoveryTokens: 0,
      validationFailed: false,
      suspiciousFlags: 0,
      weeklyBossesDefeated: [],
      claimedFinal: false,
      completedDays: []
    };
  });

  const [showCheatWarning, setShowCheatWarning] = useState(false);
  const [showRecoveryModal, setShowRecoveryModal] = useState(false);
  const [showConfirmMode, setShowConfirmMode] = useState<MonthMode>('none');
  const [validationState, setValidationState] = useState<'idle' | 'validating' | 'result' | 'celebration'>('idle');
  const [floatingTexts, setFloatingTexts] = useState<{ id: number, text: string, x: number }[]>([]);
  const [textCounter, setTextCounter] = useState(0);

  const [sessionStartTime] = useState(Date.now());
  const [lastActionTime, setLastActionTime] = useState(Date.now());

  const todayStr = getTodayStr();

  const getDaysDiff = (start: string, end: string) => {
    const d1 = new Date(start); d1.setHours(0,0,0,0);
    const d2 = new Date(end); d2.setHours(0,0,0,0);
    return Math.floor((d2.getTime() - d1.getTime()) / (1000 * 3600 * 24));
  };

  const currentDay = monthState.startDate ? getDaysDiff(monthState.startDate, todayStr) + 1 : 1;
  const isMonthComplete = currentDay > 30;

  // Streak & Recovery Check
  useEffect(() => {
    if (monthState.mode === 'none' || !monthState.lastActiveDate) return;
    const diff = getDaysDiff(monthState.lastActiveDate, todayStr);
    
    if (diff > 1) {
      if (monthState.recoveryTokens > 0 && !monthState.completedDays.includes(todayStr)) {
         setShowRecoveryModal(true);
      } else {
         // Streak broken
         if (monthState.streak > 0) {
            setMonthState(prev => {
              const updated = { ...prev, streak: 0 };
              localStorage.setItem(storageKey, JSON.stringify(updated));
              return updated;
            });
         }
      }
    }
  }, [monthState.mode, monthState.lastActiveDate, todayStr]);

  // Completion Trigger
  useEffect(() => {
    if (isMonthComplete && !monthState.claimedFinal && validationState === 'idle') {
      setValidationState('validating');
      const timer = setTimeout(() => setValidationState('result'), 2500);
      return () => clearTimeout(timer);
    }
  }, [isMonthComplete, monthState.claimedFinal, validationState]);

  const selectMode = (mode: MonthMode) => {
    playSound("click");
    setShowConfirmMode(mode);
  };

  const confirmMode = () => {
    playSound("success");
    const mode = showConfirmMode;
    const tokens = mode === 'legendary' ? 1 : 2;
    setMonthState(prev => {
      const updated = { ...prev, mode, startDate: todayStr, recoveryTokens: tokens, progress: { Pushups: 0, Squats: 0, Crunches: 0, Burpees: 0 } };
      localStorage.setItem(storageKey, JSON.stringify(updated));
      return updated;
    });
    setShowConfirmMode('none');
  };

  const handleUseRecovery = () => {
    playSound("success");
    setMonthState(prev => {
      const updated = { ...prev, streak: prev.streak, recoveryTokens: prev.recoveryTokens - 1, lastActiveDate: getYesterdayStr() };
      localStorage.setItem(storageKey, JSON.stringify(updated));
      return updated;
    });
    setShowRecoveryModal(false);
  };

  const getYesterdayStr = () => {
    const d = new Date(); d.setDate(d.getDate() - 1);
    return d.toISOString().split('T')[0];
  };

  const handleAddReps = (exercise: string, amount: number) => {
    if (isMonthComplete || monthState.validationFailed) return;
    
    const now = Date.now();
    const elapsedSecsFromLast = (now - lastActionTime) / 1000;
    
    let isSuspicious = false;
    
    if (amount >= 50 && elapsedSecsFromLast < 2) {
      isSuspicious = true; // Massive rep spam
    }
    if (amount >= 100 && elapsedSecsFromLast < 5) {
      isSuspicious = true; // Impossible completion speed
    }
    
    if (isSuspicious) {
      setShowCheatWarning(true);
      setMonthState(prev => {
        const newFlags = (prev.suspiciousFlags || 0) + 1;
        const updated = {
          ...prev,
          suspiciousFlags: newFlags,
          validationFailed: prev.validationFailed || newFlags >= 2
        };
        localStorage.setItem(storageKey, JSON.stringify(updated));
        return updated;
      });
      return;
    }

    setLastActionTime(now);
    playSound("click");
    
    const targets = monthState.mode === 'legendary' ? TARGETS.legendary : TARGETS.normal;
    const maxReps = targets[exercise as keyof typeof targets];
    
    setMonthState(prev => {
       const updated = { ...prev };
       const currentReps = updated.progress[exercise] || 0;
       const newReps = Math.min(currentReps + amount, maxReps);
       updated.progress = { ...updated.progress, [exercise]: newReps };
       
       // Update streak & active days
       if (prev.lastActiveDate !== todayStr) {
         updated.activeDaysCount += 1;
         if (getDaysDiff(prev.lastActiveDate, todayStr) === 1 || prev.lastActiveDate === "") {
           updated.streak += 1;
         } else {
           updated.streak = 1;
         }
         updated.longestStreak = Math.max(updated.longestStreak, updated.streak);
         updated.lastActiveDate = todayStr;
         if (!updated.completedDays.includes(todayStr)) {
           updated.completedDays.push(todayStr);
         }
       }

       // Weekly Boss Check
       const totalGoal = Object.values(targets).reduce((a,b)=>a+b, 0);
       const totalCurrent = Object.values(updated.progress).reduce((a,b)=>a+b, 0);
       const progressPercent = totalCurrent / totalGoal;
       
       WEEKLY_BOSSES.forEach(wb => {
         if (progressPercent >= wb.hpThreshold && !updated.weeklyBossesDefeated.includes(wb.id)) {
           updated.weeklyBossesDefeated.push(wb.id);
           playSound("success"); // boss defeated
         }
       });

       localStorage.setItem(storageKey, JSON.stringify(updated));
       return updated;
    });

    const newId = textCounter + 1;
    setTextCounter(newId);
    setFloatingTexts(prev => [...prev, { id: newId, text: \`+\${amount}\`, x: Math.random() * 40 - 20 }]);
    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== newId));
    }, 1000);
  };

  const finishChallenge = () => {
    playSound("success");
    const isLegendary = monthState.mode === 'legendary';
    const xpReward = isLegendary ? 1000 : 500;
    const rankPoints = isLegendary ? 150 : 50;
    
    onComplete(xpReward);
    
    // Save to Hall of Legends & Rank Points
    const rankData = localStorage.getItem(rankKey);
    let rp = 0;
    let legends = [];
    if (rankData) {
      try {
        const parsed = JSON.parse(rankData);
        rp = parsed.rp || 0;
        legends = parsed.legends || [];
      } catch(e) {}
    }
    
    rp += rankPoints;
    legends.push({
       mode: monthState.mode,
       date: todayStr,
       xp: xpReward,
       streak: monthState.streak
    });
    
    localStorage.setItem(rankKey, JSON.stringify({ rp, legends }));
    
    setMonthState(prev => {
      const updated = { ...prev, claimedFinal: true };
      localStorage.setItem(storageKey, JSON.stringify(updated));
      return updated;
    });
  };

  const resetChallenge = () => {
    playSound("click");
    localStorage.removeItem(storageKey);
    setMonthState({
      mode: 'none',
      startDate: '',
      progress: { Pushups: 0, Squats: 0, Crunches: 0, Burpees: 0 },
      streak: 0,
      longestStreak: 0,
      lastActiveDate: "",
      activeDaysCount: 0,
      recoveryTokens: 0,
      validationFailed: false,
      suspiciousFlags: 0,
      weeklyBossesDefeated: [],
      claimedFinal: false,
      completedDays: []
    });
    setValidationState('idle');
  };

  if (monthState.mode === 'none') {
    return (
      <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen">
        <AnimatePresence>
          {showConfirmMode !== 'none' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
              <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-neutral-900 border border-white/10 p-6 rounded-3xl w-full max-w-sm text-center">
                <Lock className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                <h3 className="text-xl font-black text-white uppercase tracking-tight mb-2">Mode Lock System</h3>
                <p className="text-neutral-400 text-sm mb-6">You will be locked into the <span className="text-white font-bold">{showConfirmMode}</span> Monthly Challenge for the next 30 days. You cannot switch modes.</p>
                <div className="grid grid-cols-2 gap-3">
                  <button onClick={() => setShowConfirmMode('none')} className="py-3 bg-white/5 hover:bg-white/10 text-white font-black rounded-xl text-sm uppercase tracking-wider transition">Cancel</button>
                  <button onClick={confirmMode} className="py-3 bg-blue-500 hover:bg-blue-600 text-white font-black rounded-xl text-sm uppercase tracking-wider transition">Confirm</button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-center mb-6">
          <button onClick={onBack} className="w-10 h-10 bg-neutral-900 rounded-full flex items-center justify-center text-white border border-white/5 active:scale-95 transition">
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>
        <div className="text-center mb-8">
          <h2 className="text-3xl font-black text-white uppercase tracking-tight">Monthly Challenge</h2>
          <p className="text-neutral-400 text-sm font-bold uppercase tracking-widest mt-2">Select your path</p>
        </div>
        
        <button onClick={() => selectMode('normal')} className="w-full text-left bg-gradient-to-br from-neutral-900 to-neutral-950 border border-neutral-800 hover:border-blue-500/50 p-6 rounded-3xl relative overflow-hidden group transition-all">
           <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
             <Shield className="w-24 h-24 text-blue-500" />
           </div>
           <h3 className="text-xl font-black text-white uppercase tracking-wider flex items-center gap-2">
             <Shield className="w-5 h-5 text-blue-500" /> Normal Monthly
           </h3>
           <div className="mt-4 grid grid-cols-2 gap-2 text-xs font-black text-neutral-400 uppercase">
             <span>Pushups: 1000</span>
             <span>Squats: 1500</span>
             <span>Crunches: 600</span>
             <span>Burpees: 300</span>
           </div>
           <div className="mt-4 flex flex-wrap gap-2">
             <span className="text-[10px] bg-blue-500/20 text-blue-400 px-2 py-1 rounded font-black uppercase">Difficulty: Normal</span>
             <span className="text-[10px] bg-white/5 text-neutral-300 px-2 py-1 rounded font-black uppercase">+500 XP</span>
             <span className="text-[10px] bg-white/5 text-neutral-300 px-2 py-1 rounded font-black uppercase">Monthly Warrior Badge</span>
           </div>
        </button>

        <button onClick={() => selectMode('legendary')} className="w-full text-left bg-gradient-to-br from-neutral-900 to-[#1a0505] border border-neutral-800 hover:border-red-500/50 p-6 rounded-3xl relative overflow-hidden group transition-all mt-4">
           <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
             <Skull className="w-24 h-24 text-red-500" />
           </div>
           <h3 className="text-xl font-black text-white uppercase tracking-wider flex items-center gap-2">
             <Skull className="w-5 h-5 text-red-500" /> Legendary Monthly
           </h3>
           <div className="mt-4 grid grid-cols-2 gap-2 text-xs font-black text-red-400/80 uppercase">
             <span>Pushups: 5000</span>
             <span>Squats: 5000</span>
             <span>Crunches: 2500</span>
             <span>Burpees: 2500</span>
           </div>
           <div className="mt-4 flex flex-wrap gap-2">
             <span className="text-[10px] bg-red-500/20 text-red-400 px-2 py-1 rounded font-black uppercase">Difficulty: Legendary</span>
             <span className="text-[10px] bg-white/5 text-neutral-300 px-2 py-1 rounded font-black uppercase">+1000 XP</span>
             <span className="text-[10px] bg-white/5 text-neutral-300 px-2 py-1 rounded font-black uppercase">Legendary Title</span>
           </div>
        </button>
      </div>
    );
  }

  const targets = monthState.mode === 'legendary' ? TARGETS.legendary : TARGETS.normal;
  const boss = monthState.mode === 'legendary' ? BOSSES.legendary : BOSSES.normal;
  const totalGoal = Object.values(targets).reduce((a,b)=>a+b, 0);
  const totalCurrent = Object.values(monthState.progress).reduce((a,b)=>a+b, 0);
  const progressPercent = Math.min(100, (totalCurrent / totalGoal) * 100);
  const currentHp = Math.round(boss.maxHp - (progressPercent / 100) * boss.maxHp);
  const daysRemaining = Math.max(0, 30 - currentDay);
  const minActiveDays = monthState.mode === 'legendary' ? 20 : 15;

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 pb-24 relative min-h-screen">
      <AnimatePresence>
        {showCheatWarning && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-[#111] border border-red-500/50 p-6 rounded-3xl w-full max-w-sm text-center shadow-[0_0_50px_rgba(239,68,68,0.2)]">
              <ShieldAlert className="w-12 h-12 text-red-500 mx-auto mb-4" />
              <h3 className="text-xl font-black text-white uppercase tracking-wider mb-2">Suspicious Activity Detected</h3>
              <p className="text-neutral-400 text-sm mb-4">Fit Genie rewards real effort. Validation Failed.</p>
              <button onClick={() => setShowCheatWarning(false)} className="w-full py-3 bg-red-500 hover:bg-red-600 text-white font-black rounded-xl text-sm uppercase tracking-wider transition">Understood</button>
            </motion.div>
          </motion.div>
        )}
        
        {showRecoveryModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-[#111] border border-blue-500/50 p-6 rounded-3xl w-full max-w-sm text-center">
              <Zap className="w-12 h-12 text-blue-500 mx-auto mb-4" />
              <h3 className="text-xl font-black text-white uppercase tracking-wider mb-2">Use Recovery Token?</h3>
              <p className="text-neutral-400 text-sm mb-4">You missed a day! Use 1 of your {monthState.recoveryTokens} tokens to restore your streak?</p>
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => setShowRecoveryModal(false)} className="py-3 bg-white/5 hover:bg-white/10 text-white font-black rounded-xl text-sm uppercase tracking-wider transition">No</button>
                <button onClick={handleUseRecovery} className="py-3 bg-blue-500 hover:bg-blue-600 text-white font-black rounded-xl text-sm uppercase tracking-wider transition">Yes</button>
              </div>
            </motion.div>
          </motion.div>
        )}

        {isMonthComplete && !monthState.claimedFinal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
            {validationState === 'validating' && (
              <div className="text-center">
                <Activity className="w-12 h-12 text-blue-500 mx-auto mb-4 animate-spin" />
                <h2 className="text-xl font-black text-white uppercase tracking-widest animate-pulse">Running Validation...</h2>
                <p className="text-neutral-500 text-sm uppercase mt-2 font-bold tracking-widest">Checking Activity Logs</p>
              </div>
            )}
            
            {validationState === 'result' && (
               <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} className="bg-[#111] border border-white/10 p-8 rounded-3xl w-full max-w-sm text-center">
                 <h2 className="text-3xl font-black text-white uppercase tracking-tight mb-6">Challenge Review</h2>
                 <div className="space-y-4 mb-6">
                   <div className="flex justify-between text-sm">
                     <span className="font-bold text-neutral-400">Activity Valid</span>
                     {!monthState.validationFailed ? <span className="text-green-400 font-black">✓</span> : <span className="text-red-500 font-black">✗</span>}
                   </div>
                   <div className="flex justify-between text-sm">
                     <span className="font-bold text-neutral-400">Consistency ({monthState.activeDaysCount}/{minActiveDays})</span>
                     {monthState.activeDaysCount >= minActiveDays ? <span className="text-green-400 font-black">✓</span> : <span className="text-red-500 font-black">✗</span>}
                   </div>
                 </div>
                 <button 
                   onClick={() => {
                     if (!monthState.validationFailed && monthState.activeDaysCount >= minActiveDays) {
                       setValidationState('celebration');
                     } else {
                       setMonthState(prev => {
                         const updated = { ...prev, claimedFinal: true };
                         localStorage.setItem(storageKey, JSON.stringify(updated));
                         return updated;
                       });
                     }
                   }}
                   className="w-full py-4 bg-neutral-800 text-white hover:bg-neutral-700 font-black uppercase tracking-widest rounded-xl transition"
                 >
                   CONTINUE
                 </button>
               </motion.div>
            )}
            
            {validationState === 'celebration' && (
               <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} className="bg-[#111] border border-white/10 p-8 rounded-3xl w-full max-w-sm text-center overflow-hidden relative">
                 {/* Confetti simulation using framer motion */}
                 <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 10, ease: "linear" }} className="absolute -top-20 -right-20 w-40 h-40 bg-yellow-500/20 blur-3xl rounded-full pointer-events-none" />
                 <motion.div animate={{ rotate: -360 }} transition={{ repeat: Infinity, duration: 15, ease: "linear" }} className="absolute -bottom-20 -left-20 w-40 h-40 bg-blue-500/20 blur-3xl rounded-full pointer-events-none" />
                 
                 <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
                 <h2 className="text-3xl font-black text-white uppercase tracking-tight mb-2">Month Complete</h2>
                 <p className="text-neutral-400 font-bold uppercase tracking-widest text-sm mb-6">Challenge Completed</p>
                 
                 <div className="bg-black/50 rounded-xl p-5 mb-6 border border-white/5 space-y-3 text-left relative z-10">
                   <div className="flex justify-between items-center text-sm">
                     <span className="text-neutral-400 font-bold uppercase">XP Earned</span>
                     <span className="text-blue-400 font-black">+{monthState.mode === 'legendary' ? 1000 : 500}</span>
                   </div>
                   <div className="flex justify-between items-center text-sm">
                     <span className="text-neutral-400 font-bold uppercase">Rank Points</span>
                     <span className="text-yellow-400 font-black">+{monthState.mode === 'legendary' ? 150 : 50}</span>
                   </div>
                   <div className="h-px bg-white/10 w-full my-2" />
                   <div className="flex items-center gap-3 text-sm text-neutral-300 font-bold">
                     <CheckCircle2 className="w-4 h-4 text-green-500"/> 
                     <span>{monthState.mode === 'legendary' ? 'Legendary Warrior Badge' : 'Monthly Warrior Badge'}</span>
                   </div>
                   {monthState.mode === 'legendary' && (
                     <div className="flex items-center gap-3 text-sm text-neutral-300 font-bold">
                       <CheckCircle2 className="w-4 h-4 text-green-500"/> 
                       <span>Legendary Warrior Title</span>
                     </div>
                   )}
                 </div>
                 
                 <p className="text-xs text-neutral-500 font-bold uppercase mb-6 tracking-widest">{todayStr}</p>

                 <button onClick={finishChallenge} className="w-full py-4 bg-yellow-500 hover:bg-yellow-400 text-black font-black uppercase tracking-widest rounded-xl transition relative z-10">
                   CLAIM REWARDS
                 </button>
               </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* HEADER */}
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="w-10 h-10 bg-neutral-900 rounded-full flex items-center justify-center text-white border border-white/5 active:scale-95 transition">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex gap-2">
          {monthState.recoveryTokens > 0 && (
             <div className="flex items-center gap-1 bg-white/5 border border-white/10 px-3 py-1.5 rounded-full">
               <Zap className="w-3.5 h-3.5 text-blue-400" />
               <span className="text-neutral-300 font-bold text-xs">{monthState.recoveryTokens}</span>
             </div>
          )}
          <div className={\`flex items-center gap-2 \${boss.bg}/10 border \${boss.border}/30 px-3 py-1.5 rounded-full\`}>
            <boss.icon className={\`w-4 h-4 \${boss.color}\`} />
            <span className={\`\${boss.color} font-bold text-xs uppercase tracking-widest\`}>{monthState.mode}</span>
          </div>
        </div>
      </div>

      {/* DASHBOARD */}
      <div className="bg-neutral-900 border border-white/5 p-6 rounded-3xl flex items-center justify-between shadow-lg relative overflow-hidden">
         <div className="absolute top-0 left-0 w-full h-1 bg-white/5">
           <motion.div className={\`h-full \${boss.bg}\`} initial={{ width: 0 }} animate={{ width: \`\${progressPercent}%\` }} />
         </div>
         <div className="relative w-28 h-28 flex items-center justify-center shrink-0">
           <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
             <circle cx="50" cy="50" r="45" fill="none" stroke="#1f2937" strokeWidth="8" />
             <circle 
               cx="50" cy="50" r="45" fill="none" 
               stroke={monthState.mode === 'legendary' ? '#ef4444' : '#3b82f6'} strokeWidth="8" strokeLinecap="round" 
               strokeDasharray={2 * Math.PI * 45} strokeDashoffset={(2 * Math.PI * 45) - (progressPercent / 100) * (2 * Math.PI * 45)} 
               className="transition-all duration-1000 ease-out"
             />
           </svg>
           <div className="absolute inset-0 flex flex-col items-center justify-center">
             <span className="text-white font-black text-2xl">{currentDay}<span className="text-sm text-neutral-500">/30</span></span>
           </div>
         </div>
         
         <div className="text-right space-y-3 relative z-10">
           <div>
             <p className="text-[10px] text-neutral-500 uppercase font-black tracking-widest">Completion</p>
             <p className="text-2xl font-black text-white">{Math.floor(progressPercent)}%</p>
           </div>
           <div>
             <p className="text-[10px] text-neutral-500 uppercase font-black tracking-widest">Days Remaining</p>
             <p className="text-sm font-black text-neutral-300">{daysRemaining}</p>
           </div>
         </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-neutral-900 border border-white/5 p-4 rounded-2xl">
          <p className="text-[10px] text-neutral-500 uppercase font-black tracking-widest flex items-center gap-1"><Flame className="w-3 h-3"/> Current Streak</p>
          <p className="text-2xl font-black text-white mt-1">{monthState.streak}</p>
        </div>
        <div className="bg-neutral-900 border border-white/5 p-4 rounded-2xl">
          <p className="text-[10px] text-neutral-500 uppercase font-black tracking-widest flex items-center gap-1"><Trophy className="w-3 h-3 text-yellow-500"/> Longest Streak</p>
          <p className="text-2xl font-black text-white mt-1">{monthState.longestStreak}</p>
        </div>
      </div>

      <div className="text-center italic text-xs font-bold text-neutral-400">
        "{getMotivation(currentDay)}"
      </div>

      {/* MONTHLY BOSS */}
      <div className={\`bg-gradient-to-br from-neutral-900 to-neutral-950 border border-white/10 p-5 rounded-3xl relative overflow-hidden\`}>
        <div className="flex items-center gap-4 relative z-10">
          <div className={\`w-16 h-16 rounded-2xl bg-black/50 border \${boss.border}/50 flex items-center justify-center shrink-0 shadow-inner\`}>
            <boss.icon className={\`w-10 h-10 \${boss.color}\`} />
          </div>
          <div className="flex-1">
            <p className="text-[9px] text-neutral-500 uppercase font-black tracking-widest">Monthly Boss</p>
            <h3 className="text-base font-black text-white uppercase tracking-tight leading-tight">{boss.name}</h3>
            <div className="mt-2.5">
              <div className="flex justify-between text-[10px] font-black uppercase mb-1">
                <span className="text-neutral-400">HP</span>
                <span className={boss.color}>{Math.max(0, currentHp)} / {boss.maxHp}</span>
              </div>
              <div className="h-1.5 bg-black rounded-full overflow-hidden">
                <motion.div 
                  className={\`h-full \${boss.bg}\`}
                  initial={{ width: '100%' }}
                  animate={{ width: \`\${(currentHp / boss.maxHp) * 100}%\` }}
                  transition={{ duration: 1 }}
                />
              </div>
            </div>
          </div>
        </div>
        <p className="text-[10px] text-neutral-500 uppercase font-black tracking-widest text-center mt-4">
          Defeat the boss by reaching 100% completion
        </p>
      </div>

      {/* WEEKLY MINI BOSSES */}
      <div className="grid grid-cols-4 gap-2">
        {WEEKLY_BOSSES.map((wb, i) => {
          const isDefeated = monthState.weeklyBossesDefeated.includes(wb.id);
          return (
            <div key={wb.id} className={\`p-2 rounded-xl border text-center relative overflow-hidden \${isDefeated ? 'bg-green-500/10 border-green-500/30' : 'bg-neutral-900 border-white/5'}\`}>
              <div className="flex justify-center mb-1">
                {isDefeated ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <Sword className="w-4 h-4 text-neutral-600" />}
              </div>
              <p className="text-[8px] font-black uppercase text-neutral-500 truncate">W{i+1} Boss</p>
            </div>
          )
        })}
      </div>

      {/* TRACKING PROGRESS */}
      <div className="space-y-3">
        <h3 className="text-sm font-black text-white uppercase tracking-widest px-1">Log Reps</h3>
        {Object.entries(targets).map(([exercise, maxReps]) => {
          const current = monthState.progress[exercise] || 0;
          const isDone = current >= maxReps;
          
          return (
            <div key={exercise} className="bg-neutral-900 border border-white/5 p-4 rounded-2xl relative overflow-hidden">
               {floatingTexts.map(ft => (
                  <motion.div
                    key={ft.id}
                    initial={{ opacity: 1, y: 0, x: ft.x }}
                    animate={{ opacity: 0, y: -40, x: ft.x }}
                    className={\`absolute left-1/2 top-4 pointer-events-none \${boss.color} font-black text-xl z-50 drop-shadow-[0_0_5px_rgba(255,255,255,0.3)]\`}
                  >
                    {ft.text}
                  </motion.div>
               ))}
               <div className="flex justify-between items-center mb-2">
                 <h4 className="text-white font-black uppercase tracking-tight">{exercise}</h4>
                 <div className="text-right">
                   <span className={\`text-xl font-black \${isDone ? 'text-green-400' : 'text-white'}\`}>{current}</span>
                   <span className="text-neutral-500 text-xs font-black"> / {maxReps}</span>
                 </div>
               </div>
               
               <div className="h-1.5 bg-black/50 rounded-full mb-4 overflow-hidden">
                  <motion.div 
                    className={\`h-full \${isDone ? 'bg-green-500' : boss.bg}\`}
                    initial={{ width: 0 }}
                    animate={{ width: \`\${Math.min(100, (current / maxReps) * 100)}%\` }}
                  />
               </div>

               {!isDone && (
                 <div className="flex gap-2">
                   <button onClick={() => handleAddReps(exercise, 10)} className="flex-1 py-2 bg-neutral-800 hover:bg-neutral-700 text-white font-black text-xs rounded-lg active:scale-95 transition">+10</button>
                   <button onClick={() => handleAddReps(exercise, 25)} className="flex-1 py-2 bg-neutral-800 hover:bg-neutral-700 text-white font-black text-xs rounded-lg active:scale-95 transition">+25</button>
                   <button onClick={() => handleAddReps(exercise, 50)} className={\`flex-1 py-2 \${boss.bg}/20 \${boss.color} border \${boss.border}/30 hover:\${boss.bg}/30 font-black text-xs rounded-lg active:scale-95 transition\`}>+50</button>
                 </div>
               )}
            </div>
          );
        })}
      </div>

      {isMonthComplete && monthState.claimedFinal && (
        <button onClick={resetChallenge} className="w-full py-4 mt-6 bg-white/5 hover:bg-white/10 text-white font-black uppercase tracking-widest rounded-xl transition">
          Start Next Month
        </button>
      )}

    </div>
  );
}
`;

fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', code);
