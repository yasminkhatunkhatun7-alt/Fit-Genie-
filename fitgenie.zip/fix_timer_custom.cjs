const fs = require('fs');
let content = fs.readFileSync('src/components/CustomChallengeDetailScreen.tsx', 'utf8');

content = content.replace(/          return next;\n          \}, 1000\);/g, '          return next;\n        });\n      }, 1000);');

fs.writeFileSync('src/components/CustomChallengeDetailScreen.tsx', content);
