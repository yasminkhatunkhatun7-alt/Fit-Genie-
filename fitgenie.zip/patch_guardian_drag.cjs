const fs = require('fs');

let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

const oldDragEnd = `  const handleDragEnd = (e: any, info: any) => {
    const newPos = { x: position.x + info.offset.x, y: position.y + info.offset.y };
    setPosition(newPos);
    localStorage.setItem("fitgenie_orb_position", JSON.stringify(newPos));
  };`;

const newDragEnd = `  const handleDragEnd = (e: any, info: any) => {
    const dragDistance = Math.sqrt(info.offset.x * info.offset.x + info.offset.y * info.offset.y);
    
    // Always update position temporarily to where they dragged it
    const newPos = { x: position.x + info.offset.x, y: position.y + info.offset.y };
    setPosition(newPos);
    
    if (dragDistance > 30) {
      const msg = [
        "Arey bro maine kya kiya? 😭",
        "Main to help kar raha tha.",
        "Mujhe kyu bhaga rahe ho?",
        "Bro dosti khatam? 😢",
        "Main kahin nahi ja raha 😏"
      ];
      setEmotion("angry");
      setMessage(msg[Math.floor(Math.random() * msg.length)]);
      
      setTimeout(() => {
        const resetPos = { x: window.innerWidth - 100, y: window.innerHeight - 100 };
        setPosition(resetPos);
        localStorage.setItem("fitgenie_orb_position", JSON.stringify(resetPos));
        setEmotion("happy");
        setMessage("Back on duty.");
      }, 3000);
    } else {
      localStorage.setItem("fitgenie_orb_position", JSON.stringify(newPos));
    }
  };`;

code = code.replace(oldDragEnd, newDragEnd);
fs.writeFileSync('src/components/GuardianOrb.tsx', code);
