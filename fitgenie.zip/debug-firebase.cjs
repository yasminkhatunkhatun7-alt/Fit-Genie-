const fs = require('fs');
let code = fs.readFileSync('src/lib/firebase.ts', 'utf-8');
code += `\nconsole.log("DB IN FIREBASE.TS:", db);`;
fs.writeFileSync('src/lib/firebase.ts', code);
