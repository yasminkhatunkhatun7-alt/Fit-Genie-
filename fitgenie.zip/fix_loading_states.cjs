const fs = require('fs');
const glob = require('glob');

// For WorldChat, inject a generic Loader where `feed.length === 0 && loading`
let worldChat = fs.readFileSync('src/components/WorldChat.tsx', 'utf8');

// Replace standard loaders if missing
if (!worldChat.includes('<Loader2 className="w-8 h-8 text-[#B66DFF] animate-spin" />')) {
  worldChat = worldChat.replace(
    '{feed.length === 0 && loading && (',
    '{feed.length === 0 && loading && (\n                  <div className="py-12 flex items-center justify-center">\n                    <Loader2 className="w-8 h-8 text-brand-accent animate-spin" />\n                  </div>\n                )}'
  );
  worldChat = worldChat.replace(
    '{leaderboard.length === 0 && loading && (',
    '{leaderboard.length === 0 && loading && (\n                  <div className="py-12 flex items-center justify-center">\n                    <Loader2 className="w-8 h-8 text-brand-accent animate-spin" />\n                  </div>\n                )}'
  );
  // Also add to leaderboard if not there
  if (!worldChat.includes('{leaderboard.length === 0 && loading && (')) {
     worldChat = worldChat.replace(
        '              <div className="space-y-3">',
        '              <div className="space-y-3">\n                {leaderboard.length === 0 && loading && (\n                  <div className="py-12 flex items-center justify-center">\n                    <Loader2 className="w-8 h-8 text-brand-accent animate-spin" />\n                  </div>\n                )}\n                {leaderboard.length === 0 && !loading && (\n                  <div className="py-12 flex flex-col items-center justify-center text-center opacity-50">\n                    <Trophy className="w-12 h-12 text-brand-muted mb-3" />\n                    <p className="text-sm font-bold uppercase tracking-widest text-brand-muted">No athletes found on this leaderboard.</p>\n                  </div>\n                )}'
     );
  }
}
fs.writeFileSync('src/components/WorldChat.tsx', worldChat);

// Handle ProfileView loading for workouts
let profileView = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');
if (!profileView.includes('loadingWorkouts && workouts.length === 0')) {
  profileView = profileView.replace(
    'workouts.length === 0 ? (',
    'loadingWorkouts && workouts.length === 0 ? (\n              <div className="py-10 flex justify-center">\n                <Loader2 className="w-8 h-8 text-brand-accent animate-spin" />\n              </div>\n            ) : workouts.length === 0 ? ('
  );
  fs.writeFileSync('src/components/ProfileView.tsx', profileView);
}
