const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(/if \(profileRequired\) \{\s*return <ProfileSetupScreen \/>;\s*\}/g, '');

fs.writeFileSync('src/App.tsx', content);
