const fs = require('fs');
let content = fs.readFileSync('src/context/GuardianContext.tsx', 'utf8');

const eventLogic = `
  useEffect(() => {
    const handleTrustIncrease = (e: Event) => {
      const customEvent = e as CustomEvent;
      const gain = customEvent.detail?.gain || 0;
      if (gain > 0) {
        if (gain >= 25) {
           setEmotion("celebrating");
           setMessage(Math.random() > 0.5 ? "Excellent recovery Boss." : "Trust is returning rapidly.");
        } else if (gain >= 10) {
           setEmotion("happy");
           setMessage(Math.random() > 0.5 ? "Trust restored." : "Genie is noticing improvement.");
        } else if (gain >= 1) {
           setEmotion("focused");
           setMessage(Math.random() > 0.5 ? "Good job Boss." : "Keep going.");
        }
      }
    };
    window.addEventListener('trust_increase', handleTrustIncrease);
    return () => window.removeEventListener('trust_increase', handleTrustIncrease);
  }, []);
`;

content = content.replace(/useEffect\(\(\) => \{\n    const saved = localStorage\.getItem\("fitgenie_guardian_observations"\);/, eventLogic + '\n  useEffect(() => {\n    const saved = localStorage.getItem("fitgenie_guardian_observations");');

fs.writeFileSync('src/context/GuardianContext.tsx', content);
