const fs = require('fs');

let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

const oldState = `  // Coordinate Mapping State
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerSize, setContainerSize] = useState<{width: number, height: number} | null>(null);
  const [imageSize, setImageSize] = useState<{width: number, height: number} | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      setContainerSize({
        width: entries[0].contentRect.width,
        height: entries[0].contentRect.height
      });
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, [uploadedImage, isCameraActive]);

  const mapCoordinates = (x: number, y: number) => {
    if (!imageSize || !containerSize) return { x, y };
    const { width: iw, height: ih } = imageSize;
    const { width: cw, height: ch } = containerSize;
    const ir = iw / ih;
    const cr = cw / ch;
    let displayWidth = cw;
    let displayHeight = ch;
    let offsetX = 0;
    let offsetY = 0;
    if (ir > cr) {
      displayHeight = ch;
      displayWidth = ch * ir;
      offsetX = (displayWidth - cw) / 2;
    } else {
      displayWidth = cw;
      displayHeight = cw / ir;
      offsetY = (displayHeight - ch) / 2;
    }
    const mappedX = ((displayWidth * (x / 100) - offsetX) / cw) * 100;
    const mappedY = ((displayHeight * (y / 100) - offsetY) / ch) * 100;
    return { x: mappedX, y: mappedY };
  };`;

const newState = `  const [imageSize, setImageSize] = useState<{width: number, height: number} | null>(null);`;

code = code.replace(oldState, newState);

const oldDiv = `<div ref={containerRef} className="relative rounded-3xl overflow-hidden border border-neutral-800 bg-[#0A0D14] shadow-[0_0_40px_rgba(20,241,225,0.05)] aspect-[3/4] flex flex-col items-center justify-center group">`;
const newDiv = `<div className="relative rounded-3xl overflow-hidden border border-neutral-800 bg-[#0A0D14] shadow-[0_0_40px_rgba(20,241,225,0.05)] aspect-[3/4] flex flex-col items-center justify-center group">`;

code = code.replace(oldDiv, newDiv);

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done state');
