const fs = require('fs');

const speedFile = 'src/components/SpeedChallengeScreen.tsx';
if (fs.existsSync(speedFile)) {
  let content = fs.readFileSync(speedFile, 'utf8');
  content = content.replace(/          return prev - 1;\n            setElapsedTime\(prev => prev \+ 1\);\n      \}, 1000\);/g, 
  '          return prev - 1;\n        });\n        setElapsedTime(prev => prev + 1);\n      }, 1000);');
  fs.writeFileSync(speedFile, content);
}

const strengthFile = 'src/components/StrengthChallengeScreen.tsx';
if (fs.existsSync(strengthFile)) {
  let content = fs.readFileSync(strengthFile, 'utf8');
  // Strength is a regular timer that just increments elapsedTime probably
  content = content.replace(/          return next;\n        \}\);\n      \}, 1000\);/g, 
  '          return next;\n        });\n      }, 1000);');
  
  // Actually wait, earlier I replaced it with `return next; }); }, 1000);`
  // Let's check strength.
}
