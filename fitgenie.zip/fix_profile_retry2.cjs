const fs = require('fs');

let profile = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');

if (profile.includes("retryCount")) {
  profile = profile.replace(
    ']}, [viewUserId, isOwnProfile, profile]);',
    ']}, [viewUserId, isOwnProfile, profile, retryCount]);'
  );
  fs.writeFileSync('src/components/ProfileView.tsx', profile);
}
