const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');

// 1. Remove all `<React.Fragment>` and `</React.Fragment>` lines
code = code.split('\n').filter(line => !line.includes('<React.Fragment>') && !line.includes('</React.Fragment>')).join('\n');

// 2. Remove the AI Tracker blocks. They start with `{/* Floating AI Camera Button */}`
// and end with `/>\n        )}\n` (the end of AiRepCounter block).
// Because there are multiple, let's use a regex.
const trackerRegex = /[ \t]*\{\/\* Floating AI Camera Button \*\/\}[\s\S]*?\{\/\* AI Rep Counter Modal \*\/\}[\s\S]*?\/>[ \t]*\n[ \t]*\)\}/g;
code = code.replace(trackerRegex, '');

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
console.log("cleaned");
