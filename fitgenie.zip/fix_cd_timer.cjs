const fs = require('fs');
let content = fs.readFileSync('src/components/CustomChallengeDetailScreen.tsx', 'utf8');

content = content.replace(/        return changed \? next : prev;\n        setCooldowns10\(prev => \{/g, '        return changed ? next : prev;\n      });\n      setCooldowns10(prev => {');

content = content.replace(/        return changed \? next : prev;\n      \}, 1000\);/g, '        return changed ? next : prev;\n      });\n    }, 1000);');

fs.writeFileSync('src/components/CustomChallengeDetailScreen.tsx', content);
