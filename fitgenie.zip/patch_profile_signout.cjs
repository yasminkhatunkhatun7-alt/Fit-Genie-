const fs = require('fs');

let code = fs.readFileSync('src/components/ProfileView.tsx', 'utf-8');

// Add signOutUser from useAuth
code = code.replace(
  'const { user, profile, refreshProfile } = useAuth();',
  'const { user, profile, refreshProfile, signOutUser } = useAuth();'
);

// Add Sign Out button
const signOutButton = `
        <div className="pt-4 border-t border-[rgba(255,255,255,0.05)] mt-4">
          <button
            onClick={async () => {
              if (confirm("Are you sure you want to sign out?")) {
                await signOutUser();
              }
            }}
            className="w-full p-3 bg-red-500/10 border border-red-500/30 hover:bg-red-500/20 text-red-500 rounded-xl font-bold uppercase tracking-wider text-xs transition-all flex items-center justify-center gap-2"
          >
            Sign Out
          </button>
        </div>
`;

code = code.replace(
  '        <div className="pt-4 border-t border-[rgba(255,255,255,0.05)] text-center">',
  signOutButton + '\n        <div className="pt-4 border-t border-[rgba(255,255,255,0.05)] text-center">'
);

fs.writeFileSync('src/components/ProfileView.tsx', code);
