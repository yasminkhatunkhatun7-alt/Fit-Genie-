const fs = require('fs');

let yh = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');

// I need to find `activeSubTab === "sleep"` and remove it.
const tabRegex = /          \{\/\* -----------------------------------------\n             TAB 4: SLEEP SYSTEM[\s\S]*?          \{\/\* -----------------------------------------\n             TAB 7: SOCIAL CHALLENGES/g;
yh = yh.replace(tabRegex, `          {/* -----------------------------------------
             TAB 7: SOCIAL CHALLENGES`);

// Also look for just `activeSubTab === "sleep"` block
const sleepBlockRegex = /          \{activeSubTab === "sleep" && \([\s\S]*?          \}\)\n/g;
yh = yh.replace(sleepBlockRegex, "");

fs.writeFileSync('src/components/YoddhaHub.tsx', yh);
