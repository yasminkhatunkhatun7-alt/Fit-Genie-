const fs = require('fs');

let code = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');

const rankSnippet = `
      {/* MONTHLY RPG RANK & HALL OF LEGENDS */}
      <motion.div className="glass-card p-5 rounded-2xl space-y-4" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
        <div className="flex justify-between items-center">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2"><Sparkles className="w-4 h-4 text-yellow-500" /> Monthly RPG Rank</h3>
          <span className="text-xs font-black text-yellow-500">{monthlyRP} RP</span>
        </div>
        <div className="flex items-center gap-4 bg-black/30 p-3 rounded-xl border border-yellow-500/20">
           <div className="text-4xl">{monthlyRank.icon}</div>
           <div>
             <div className="text-sm font-black text-white uppercase">{monthlyRank.name}</div>
             <div className="text-[10px] text-neutral-400 font-bold uppercase">{monthlyRP} Rank Points</div>
           </div>
        </div>
        
        {hallOfLegends.length > 0 && (
          <div className="mt-4 border-t border-white/10 pt-4">
             <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Hall Of Legends</h4>
             <div className="space-y-2">
               {hallOfLegends.map((leg: any, i: number) => (
                 <div key={i} className={\`p-3 rounded-xl border \${leg.mode === 'legendary' ? 'bg-red-500/10 border-red-500/30' : 'bg-blue-500/10 border-blue-500/30'} flex justify-between items-center\`}>
                   <div>
                     <div className={\`text-[10px] font-black uppercase \${leg.mode === 'legendary' ? 'text-red-400' : 'text-blue-400'}\`}>{leg.mode} Warrior</div>
                     <div className="text-[9px] text-neutral-400 font-bold">{leg.date}</div>
                   </div>
                   <div className="text-right">
                     <div className="text-[10px] font-black text-yellow-500">+{leg.xp} XP</div>
                     <div className="text-[9px] font-bold text-neutral-300">Streak: {leg.streak}</div>
                   </div>
                 </div>
               ))}
             </div>
          </div>
        )}
      </motion.div>
`;

// Insert after LEVEL PROGRESS
code = code.replace(/{ \/\* BADGES \/ ACHIEVEMENTS \*\//, rankSnippet + '\n      {/* BADGES / ACHIEVEMENTS */');

const topSnippet = `
  const userXP = profile?.xp || 0;
  
  // Read Monthly RPG Rank from local storage
  const rankKey = \`onemonth_rank_\${profile?.uid}\`;
  const [monthlyRP, setMonthlyRP] = useState(0);
  const [hallOfLegends, setHallOfLegends] = useState([]);
  
  React.useEffect(() => {
    const data = localStorage.getItem(rankKey);
    if (data) {
      try {
        const parsed = JSON.parse(data);
        setMonthlyRP(parsed.rp || 0);
        setHallOfLegends(parsed.legends || []);
      } catch (e) {}
    }
  }, [rankKey]);
  
  const getMonthlyRank = (rp: number) => {
    if (rp >= 1000) return { name: "Legend Warrior", icon: "👑" };
    if (rp >= 600) return { name: "Diamond Warrior", icon: "💎" };
    if (rp >= 300) return { name: "Gold Warrior", icon: "🏆" };
    if (rp >= 100) return { name: "Silver Warrior", icon: "⚔️" };
    return { name: "Bronze Warrior", icon: "🛡️" };
  };
  
  const monthlyRank = getMonthlyRank(monthlyRP);
`;

code = code.replace(/const userXP = profile\?\.xp \|\| 0;/, topSnippet);

fs.writeFileSync('src/components/ProfileView.tsx', code);
