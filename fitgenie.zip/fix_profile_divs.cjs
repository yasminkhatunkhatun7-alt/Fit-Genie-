const fs = require('fs');
const file = 'src/components/ProfileView.tsx';
const code = fs.readFileSync(file, 'utf8');

const lines = code.split('\n');
const startLine = 495;
const endLine = 505;

for (let i = startLine - 1; i < endLine; i++) {
  console.log(`${i + 1}: ${lines[i]}`);
}
