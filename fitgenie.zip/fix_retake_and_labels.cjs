const fs = require('fs');

let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

// Update Retake button behavior
const oldRetakeBtn = `<button 
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/50 hover:bg-black/80 backdrop-blur-md border border-neutral-700 rounded-full px-4 py-2 text-[10px] font-bold text-white uppercase tracking-widest transition-colors z-20 pointer-events-auto"
                  >
                    Retake Scan
                  </button>`;

const newRetakeBtn = `<button 
                    onClick={() => {
                      setUploadedImage(null);
                      setScanResult(null);
                      setScanComplete(false);
                      setScanError(null);
                      setIsCameraActive(false);
                    }}
                    className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/50 hover:bg-black/80 backdrop-blur-md border border-neutral-700 rounded-full px-4 py-2 text-[10px] font-bold text-white uppercase tracking-widest transition-colors z-20 pointer-events-auto shadow-[0_0_15px_rgba(20,241,225,0.2)]"
                  >
                    Retake Scan
                  </button>`;

code = code.replace(oldRetakeBtn, newRetakeBtn);

// Update landmark labels
const oldLabels = `<motion.div
                            key={\`dot-\${item.id}\`}
                            initial={{ opacity: 0, scale: 0 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.2 * (index + 1) }}
                            className="absolute pointer-events-none flex flex-col items-center"
                            style={{ left: \`\${item.landmark.x}%\`, top: \`\${item.landmark.y}%\`, transform: 'translate(-50%, -50%)', zIndex: 10 }}
                          >
                            <div className={\`w-2 h-2 rounded-full shadow-[0_0_8px_currentColor] shrink-0 \${isHighConf ? 'bg-[#14F1E1] text-[#14F1E1]' : 'bg-red-500 text-red-500'}\`} />
                            <div className="mt-1 bg-black/80 backdrop-blur-sm px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider text-white border border-white/10 whitespace-nowrap">
                              {item.title}
                            </div>
                          </motion.div>`;

const newLabels = `<motion.div
                            key={\`dot-\${item.id}\`}
                            initial={{ opacity: 0, scale: 0 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.2 * (index + 1) }}
                            className="absolute pointer-events-none flex flex-col items-center"
                            style={{ left: \`\${item.landmark.x}%\`, top: \`\${item.landmark.y}%\`, transform: 'translate(-50%, -50%)', zIndex: 10 }}
                          >
                            <div className={\`w-4 h-4 rounded-full border-2 shadow-[0_0_10px_currentColor] shrink-0 bg-transparent flex items-center justify-center \${isHighConf ? 'border-green-500 text-green-500' : 'border-red-500 text-red-500'}\`}>
                               <div className="w-1.5 h-1.5 rounded-full bg-current" />
                            </div>
                            <div className={\`mt-1 bg-black/80 backdrop-blur-sm px-2 py-1 rounded text-[9px] font-black uppercase tracking-widest border whitespace-nowrap shadow-lg flex items-center gap-1 \${isHighConf ? 'text-green-400 border-green-500/30' : 'text-red-400 border-red-500/30'}\`}>
                              <span>{item.title}</span>
                              {item.score && <span className="bg-white/10 px-1 py-0.5 rounded">{item.score}/10</span>}
                            </div>
                          </motion.div>`;

code = code.replace(oldLabels, newLabels);

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done');
