import { initializeApp } from "firebase/app";
import { initializeFirestore, collection, getDocs } from "firebase/firestore";
import fs from "fs";

const firebaseConfig = JSON.parse(fs.readFileSync("./firebase-applet-config.json", "utf-8"));

const app = initializeApp(firebaseConfig);
const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
}, firebaseConfig.firestoreDatabaseId);

async function main() {
  console.log("Querying firestore 'exercises' collection...");
  try {
    const querySnapshot = await getDocs(collection(db, "exercises"));
    const list: any[] = [];
    querySnapshot.forEach((doc) => {
      list.push({ id: doc.id, ...doc.data() });
    });
    console.log("Found exercises:", list.length);
    console.log(JSON.stringify(list, null, 2));
  } catch (err) {
    console.error("Error querying 'exercises':", err);
  }
}

main();
