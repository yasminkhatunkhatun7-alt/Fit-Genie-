const fs = require('fs');

let code = fs.readFileSync('src/components/SpeedChallengeScreen.tsx', 'utf8');
const handleAddRepsNew = `
  const handleAddReps = (amount: number) => {
    if (isCompleted || timeLeft === 0) return;
    
    validateAndAddReps(
      exercise.name,
      amount,
      elapsedTime,
      () => {
        playSound("timer_tick");
        const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);
        const id = Date.now() + "_" + Math.random();
        setFloatingTexts(prev => [...prev, { id, text: \`+\${amount}\`, x: Math.random() * 40 - 20 }]);
        setTimeout(() => setFloatingTexts(prev => prev.filter(t => t.id !== id)), 1000);

        const updated = { ...challenge };
        updated.exercises[0].completedReps = newCompleted;
        onUpdate(updated);
        saveProgress(newCompleted, elapsedTime, true);
      },
      () => {
        // Validation Failed Reset
        const updated = { ...challenge };
        updated.exercises[0].completedReps = 0;
        onUpdate(updated);
        setElapsedTime(0);
        setTimeLeft(60);
        setIsStarted(false);
        saveProgress(0, 0, false);
      }
    );
  };
`;
code = code.replace(/  const handleAddReps = \(amount: number\) => \{[\s\S]*?saveProgress\(newCompleted, elapsedTime, true\);\n  \};/, handleAddRepsNew);
code = code.replace(/cooldown1 > 0/g, 'cooldown > 0');
code = code.replace(/cooldown10 > 0/g, 'cooldown > 0');
fs.writeFileSync('src/components/SpeedChallengeScreen.tsx', code);

code = fs.readFileSync('src/components/StrengthChallengeScreen.tsx', 'utf8');
const handleAddRepsStr = `
  const handleAddReps = (amount: number) => {
    if (isCompleted || hasClaimedToday) return;
    
    validateAndAddReps(
      exercise.name,
      amount,
      elapsedTime,
      () => {
        playSound("timer_tick");
        const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);
        const id = Date.now() + "_" + Math.random();
        setFloatingTexts(prev => [...prev, { id, text: \`+\${amount}\`, x: Math.random() * 40 - 20 }]);
        setTimeout(() => setFloatingTexts(prev => prev.filter(t => t.id !== id)), 1000);

        const updated = { ...challenge };
        updated.exercises[0].completedReps = newCompleted;
        onUpdate(updated);
        saveProgress(newCompleted, elapsedTime, true);
      },
      () => {
        const updated = { ...challenge };
        updated.exercises[0].completedReps = 0;
        onUpdate(updated);
        setElapsedTime(0);
        setIsStarted(false);
        saveProgress(0, 0, false);
      }
    );
  };
`;
code = code.replace(/  const handleAddReps = \(amount: number\) => \{[\s\S]*?saveProgress\(newCompleted, elapsedTime, true\);\n  \};/, handleAddRepsStr);
code = code.replace(/cooldown1 > 0/g, 'cooldown > 0');
code = code.replace(/cooldown10 > 0/g, 'cooldown > 0');
fs.writeFileSync('src/components/StrengthChallengeScreen.tsx', code);
