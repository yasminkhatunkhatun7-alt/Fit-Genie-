import { initializeApp } from "firebase/app";
import { initializeFirestore, doc, setDoc } from "firebase/firestore";
import fs from "fs";

async function run() {
  const firebaseConfig = JSON.parse(fs.readFileSync("./firebase-applet-config.json", "utf-8"));
  const app = initializeApp(firebaseConfig);
  const db = initializeFirestore(app, {
    experimentalForceLongPolling: true,
  }, firebaseConfig.firestoreDatabaseId);

  console.log("Starting Firebase write...");
  const timer = setTimeout(() => {
    console.error("Write timed out!");
    process.exit(1);
  }, 10000);

  try {
    await setDoc(doc(db, "exercises", "test_01"), {
      name_en: "Surya Namaskar",
      youtube_url: ""
    });
    clearTimeout(timer);
    console.log("Success! Wrote document to exercises/test_01");
    process.exit(0);
  } catch (err: any) {
    console.error("Failed to write:", err.message);
    process.exit(1);
  }
}

run();
