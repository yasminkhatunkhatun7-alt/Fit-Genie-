const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');
content = content.replace(
  '{ id: "calisthenics", name: "Calisthenics Library", icon: <Award className="w-3.5 h-3.5" /> },',
  '{ id: "calisthenics", name: "Calisthenics Library", icon: <Award className="w-3.5 h-3.5" /> },\n                        { id: "calisthenics_videos", name: "Calisthenics Video Library", icon: <Video className="w-3.5 h-3.5" /> },'
);
fs.writeFileSync('src/App.tsx', content);
