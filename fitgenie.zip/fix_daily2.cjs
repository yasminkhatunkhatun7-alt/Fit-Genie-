const fs = require('fs');
let code = fs.readFileSync('src/components/DailyChallengeDetailScreen.tsx', 'utf-8');

// Update handleAddReps
code = code.replace(
  'const handleAddReps = (amount: number) => {',
  'const handleAddReps = (amount: number, fromAI: boolean = false) => {'
);
code = code.replace(
  'if (checkCheat(exercise.name, amount)) {',
  'if (!fromAI && checkCheat(exercise.name, amount)) {'
);

// Add state & component imports
if (!code.includes('showAiCounter')) {
  code = code.replace(
    'const [showManualInput, setShowManualInput] = useState(false);',
    'const [showManualInput, setShowManualInput] = useState(false);\n  const [showAiCounter, setShowAiCounter] = useState(false);'
  );
}
if (!code.includes('AiRepCounter')) {
  code = code.replace(
    'import { getTodayDateString } from "../utils/dailyChallenge";',
    'import { getTodayDateString } from "../utils/dailyChallenge";\nimport { AiRepCounter } from "./AiRepCounter";\nimport { Camera } from "lucide-react";'
  );
}

// Replace the controls directly by slicing
const startStr = '<div className="grid grid-cols-2 gap-3 relative">';
const endStr = '      {/* LIVE XP TRACKER */}';

const startIndex = code.indexOf(startStr);
const endIndex = code.indexOf(endStr);

if (startIndex !== -1 && endIndex !== -1) {
  const replacement = `<div className="grid grid-cols-1 gap-3 relative">
          {(exercise.name.toLowerCase().includes('pushup') || exercise.name.toLowerCase().includes('squat')) ? (
             <motion.button 
               whileTap={{ scale: 0.95 }}
               onClick={() => setShowAiCounter(true)}
               disabled={isCompleted || hasClaimedToday}
               className="bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-lg py-4 rounded-2xl flex justify-center items-center gap-2 shadow-[0_0_20px_rgba(20,241,225,0.4)] transition-all disabled:opacity-50"
             >
               <Camera className="w-6 h-6" />
               START AI TRACKER
             </motion.button>
           ) : (
             <div className="bg-white/5 border border-white/10 text-neutral-400 font-bold text-sm py-4 rounded-2xl flex justify-center items-center text-center px-4">
               Manual tracking disabled. AI Tracker is available for Pushups and Squats.
             </div>
           )}
          
          {/* FLOATING TEXTS */}
          <AnimatePresence>
            {floatingTexts.map((ft) => (
              <motion.div
                key={ft.id}
                initial={{ opacity: 1, y: 0, x: ft.x, scale: 1 }}
                animate={{ opacity: 0, y: -50, scale: 1.5 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="absolute pointer-events-none left-1/2 -translate-x-1/2 -top-10 text-[#14F1E1] font-black text-xl z-20"
              >
                {ft.text}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
`;
  code = code.substring(0, startIndex) + replacement + code.substring(endIndex);
}

const manualModalRegex = /\{showManualInput && \([\s\S]*?<\/AnimatePresence>/;
const aiCounterModal = `
      </AnimatePresence>
      {showAiCounter && (
        <AiRepCounter
          initialExercise={exercise.name.toLowerCase().includes('squat') ? "Squats" : "Pushups"}
          onClose={() => setShowAiCounter(false)}
          onComplete={(reps) => {
            if (reps > 0) {
              handleAddReps(reps, true);
            }
            setShowAiCounter(false);
          }}
        />
      )}`;

if (code.match(manualModalRegex)) {
  code = code.replace(manualModalRegex, aiCounterModal);
} else {
  // if not found, just append right before last div
  const lastDiv = '    </div>\n  );\n}';
  code = code.replace(lastDiv, aiCounterModal + '\n    </div>\n  );\n}');
}

fs.writeFileSync('src/components/DailyChallengeDetailScreen.tsx', code);
console.log('Fixed Daily part 2');
