const fs = require('fs');

const files = [
  'src/components/DailyChallengeDetailScreen.tsx',
  'src/components/SpeedChallengeScreen.tsx',
  'src/components/StrengthChallengeScreen.tsx',
  'src/components/WeeklyChallengeScreen.tsx',
  'src/components/CustomChallengeDetailScreen.tsx'
];

files.forEach(file => {
  let code = fs.readFileSync(file, 'utf8');
  
  if (code.includes('MISSION COMPLETE')) {
    code = code.replace(/<h1 className="text-4xl font-black uppercase text-\[#14F1E1\] tracking-tight">MISSION COMPLETE<\/h1>/, 
      '<h1 className="text-4xl font-black uppercase text-[#14F1E1] tracking-tight text-center">✅ Validation Passed</h1>');
      
    code = code.replace(/<p className="text-white text-lg font-bold mt-2">.*?<\/p>/,
      '<p className="text-white text-lg font-bold mt-2 text-center">Challenge completed successfully.<br/>XP awarded.</p>');
  }

  // Also replace some other texts that might differ
  code = code.replace(/<h1 className="text-3xl font-black uppercase text-\[#B66DFF\] tracking-tight">LEGENDARY WEEK<\/h1>/,
      '<h1 className="text-3xl font-black uppercase text-[#B66DFF] tracking-tight text-center">✅ Validation Passed</h1>');
  
  // Try a generic replacement for standard MISSION COMPLETE
  code = code.replace(/<h1 className="[^"]*">MISSION COMPLETE<\/h1>/, 
      '<h1 className="text-3xl font-black uppercase text-green-400 tracking-tight text-center">✅ Validation Passed</h1>');

  fs.writeFileSync(file, code);
});
