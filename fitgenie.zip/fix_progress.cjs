const fs = require('fs');

let auth = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

auth = auth.replace(/const LOCAL_STORAGE_KEY = 'fitgenie_local_profile';/, "const LOCAL_STORAGE_KEY = 'fitgenie_user_progress';");

// Check the ranks
auth = auth.replace(/if \(xp > 5000\) return "Maha Sher";\s*if \(xp > 3000\) return "Sher";\s*if \(xp > 1500\) return "Iron Yoddha";\s*if \(xp > 500\) return "Akhara Fighter";\s*return "Beginner Pehelwan";/g, 
`if (xp > 10000) return "Ascended";
  if (xp > 7500) return "Mythic";
  if (xp > 5000) return "Legend";
  if (xp > 3000) return "Titan";
  if (xp > 2000) return "Champion";
  if (xp > 1000) return "Elite";
  if (xp > 500) return "Warrior";
  return "Beginner";`);

fs.writeFileSync('src/context/AuthContext.tsx', auth);
console.log("Updated AuthContext.tsx");
