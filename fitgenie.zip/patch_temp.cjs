import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { db } from "../lib/firebase";
import { doc, setDoc, getDoc } from "firebase/firestore";
import { auth } from "../lib/firebase";
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, User } from "firebase/auth";

// Date time-frame helpers for Weekly/Monthly tracking
function getISOWeekString(date: Date): string {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

function getISOMonthString(date: Date): string {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

// YYYY-MM-DD local format helper
function getLocalDateString(d: Date): string {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

// Computes the number of calendar days of difference between two local dates YYYY-MM-DD
function getDaysBetween(dateStr1: string, dateStr2: string): number {
  if (!dateStr1 || !dateStr2 || dateStr1 === "" || dateStr2 === "") return 999;
  try {
    const d1 = new Date(dateStr1 + "T12:00:00");
    const d2 = new Date(dateStr2 + "T12:00:00");
    const diffTime = Math.abs(d2.getTime() - d1.getTime());
    return Math.round(diffTime / (1000 * 60 * 60 * 24));
  } catch (err) {
    console.error("Error parsing date strings in getDaysBetween:", err);
    return 999;
  }
}


export function getIntegrityData(score: number) {
  if (score >= 90) return { status: "Athlete 🏆", mood: "Proud", message: "Perfect discipline Boss." };
  if (score >= 80) return { status: "Something Feels Off 🤨", mood: "Watching", message: "Boss, kuch to gadbad lag rahi hai. Stay honest." };
  if (score >= 70) return { status: "Under Observation 👀", mood: "Suspicious", message: "Genie is monitoring your progress. Trust is unstable." };
  if (score >= 60) return { status: "Questionable Activity ⚠️", mood: "Concerned", message: "Boss, your behavior is becoming suspicious. Trust needs improvement." };
  if (score >= 50) return { status: "Red Flag User 🚩", mood: "Disappointed", message: "Too many unusual actions detected." };
  if (score >= 40) return { status: "Cheat Suspect 🚨", mood: "Annoyed", message: "Genie is losing confidence." };
  if (score >= 30) return { status: "Cheat Monster 👹", mood: "Angry", message: "Boss, this is getting serious." };
  if (score >= 20) return { status: "Fitness Criminal 😤", mood: "Very Angry", message: "Trust is critically damaged." };
  if (score >= 10) return { status: "Public Enemy 😈", mood: "Furious", message: "Genie no longer believes workout claims." };
  if (score >= 1) return { status: "Disowned By Genie 💔", mood: "Maximum Anger", message: "Boss... what happened to you?" };
  return { status: "Banned By Genie 💀", mood: "Nuclear", message: "Genie has completely lost trust." };
}

export function getTrustGrade(score: number): string {
  return getIntegrityData(score).status;
}

export interface UserProfile {
  uid: string;
  username: string;
  email?: string;
  photoURL: string;
  xp: number;
  rank: string;
  streak: number;
  joinDate: string;
  totalWorkouts?: number;
  challengeWins?: number;
  fitnessScore?: number;
  dailyXP?: number;
  weeklyXP?: number;
  monthlyXP?: number;
  lastDate?: string;
  lastWeek?: string;
  lastMonth?: string;
  avatarBg?: string;
  friends?: string[];
  achievedCalisthenics?: string[];
  last_workout_date?: string;
  goal?: string;
  completed_workouts?: { date: string; exerciseName: string }[];
  mogged_exercises?: { date: string; exerciseName: string }[];
  recoveryWorkouts?: number;
  recoveringFromZero?: boolean;
  isPremium?: boolean;
  subscriptionStatus?: string;
  expiry_date?: string;
  theme?: string;
  age?: number;
  gender?: string;
  level?: string;
  onboardingDone?: boolean;
  performance_metrics?: { exerciseId: string, durationSecs: number, timestamp: number }[];
  claimedTasks?: string[];
  integrityScore?: number;
  integrityViolations?: number;
  consecutiveHonestDays?: number;
  totalSquats?: number;
  bestSquat1Min?: number;
  totalPushups?: number;
  bestPushup1Min?: number;
  
  // Detailed Onboarding Fields
  name?: string;
  dateOfBirth?: string;
  height?: number;
  weight?: number;
  targetWeight?: number;
  bodyType?: string;
  activityLevel?: string;
  mainGoal?: string;
  progressPace?: string;
  bmi?: number;
  bmr?: number;
  dailyCalorieTarget?: number;
  waterIntakeGoal?: number;
  onboardingCompleted?: boolean;
}

export function getRankFromXP(xp: number): string {
  if (xp >= 10000) return "Ascended";
  if (xp >= 7500) return "Mythic";
  if (xp >= 5000) return "Legend";
  if (xp >= 3000) return "Titan";
  if (xp >= 2000) return "Champion";
  if (xp >= 1000) return "Elite";
  if (xp >= 500) return "Warrior";
  return "Beginner";
}

interface AuthContextType {
  user: any | null;
  profile: UserProfile | null;
  loading: boolean;
  profileRequired: boolean;
  signUpWithEmail: (email: string, password: string) => Promise<any>;
  signInWithEmail: (email: string, password: string) => Promise<any>;
  signInWithGoogle: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  completeProfileSetup: (username: string, photoURL: string) => Promise<UserProfile>;
  signOutUser: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  updateUserXP: (additionalXP: number) => Promise<void>;
  updateProfileStats: (stats: { 
    xpGained?: number; 
    workoutCompleted?: boolean; 
    workoutCompletedOnTime?: boolean;
    dailyGoalCompleted?: boolean;
    challengeWon?: boolean; 
    streakChange?: number;
    completedWorkoutName?: string;
    completedMoggedExerciseName?: string;
    goal?: string;
    theme?: string;
    taskClaimed?: string;
    integrityScoreChange?: number;
    integrityViolationsChange?: number;
    consecutiveHonestDaysChange?: number;
  }) => Promise<void>;
  toggleFriend: (friendUid: string) => Promise<void>;
  updateUserProfileFields: (fields: Partial<UserProfile>) => Promise<void>;
  logMoggedExercise: (exerciseName: string, xp?: number) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'fitgenie_user_progress';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<any | null>({ uid: 'local_user' });
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [profileRequired, setProfileRequired] = useState(false);

  useEffect(() => {
    const storedProfile = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (storedProfile) {
      const parsedProfile = JSON.parse(storedProfile);
      if (parsedProfile.last_workout_date) {
        const todayStr = getLocalDateString(new Date());
        const diffDays = getDaysBetween(parsedProfile.last_workout_date, todayStr);
        if (diffDays > 1) {
          parsedProfile.streak = 0;
          localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(parsedProfile));
        }
      }
      setProfile(parsedProfile);
    } else {
      const newProfile: UserProfile = {
        uid: 'local_user',
        username: 'Warrior',
        photoURL: '',
        xp: 0,
        rank: getRankFromXP(0),
        streak: 0,
        joinDate: getLocalDateString(new Date()),
        integrityScore: 100,
        onboardingCompleted: true,
      };
      setProfile(newProfile);
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newProfile));
    }
    setLoading(false);
  }, []);

  const saveProfile = (updatedProfile: UserProfile) => {
    setProfile(updatedProfile);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedProfile));
    
    // Sync to Firestore
    try {
      if (updatedProfile.uid) {
        const avatarStyles = ["bg-blue-500", "bg-pink-500", "bg-purple-500", "bg-emerald-500", "bg-orange-500", "bg-indigo-500"];
        const avatarIndex = updatedProfile.uid.length % avatarStyles.length;
        const avatarBg = `${avatarStyles[avatarIndex]} text-white border-${avatarStyles[avatarIndex].replace('bg-', '')}`;
        
        const userRef = doc(db, 'users', updatedProfile.uid);
        setDoc(userRef, {
          userId: updatedProfile.uid,
          userName: updatedProfile.username || 'Anonymous Genin',
          xp: updatedProfile.xp || 0,
          rank: updatedProfile.rank || 'Beginner',
          streak: updatedProfile.streak || 0,
          avatarBg: avatarBg,
          totalSquats: updatedProfile.totalSquats || 0,
          bestSquat1Min: updatedProfile.bestSquat1Min || 0,
          totalPushups: updatedProfile.totalPushups || 0,
          bestPushup1Min: updatedProfile.bestPushup1Min || 0,
          lastUpdated: Date.now()
        }, { merge: true }).catch(console.error);
      }
    } catch (e) {
      console.error('Failed to sync profile to Firebase', e);
    }
  };

  const signUpWithEmail = async (email: string, pass: string) => { return {} as any; };
  const signInWithEmail = async (email: string, pass: string) => { return {} as any; };
  const resetPassword = async (email: string) => {};
  const completeProfileSetup = async (name: string, photo: string) => { return profile! as any; };
  const signOutUser = async () => {};
  const refreshProfile = async () => {};

  const updateProfileStats = async (stats: { 
    xpGained?: number; 
    workoutCompleted?: boolean;
    workoutCompletedOnTime?: boolean;
    dailyGoalCompleted?: boolean;
    challengeWon?: boolean; 
    streakChange?: number;
    completedWorkoutName?: string;
    completedMoggedExerciseName?: string;
    goal?: string;
    theme?: string;
    taskClaimed?: string;
    integrityScoreChange?: number;
    integrityViolationsChange?: number;
    consecutiveHonestDaysChange?: number;
  }) => {
    if (!profile) return;
    
    try {
      const now = new Date();
      const currentWeek = getISOWeekString(now);
      const currentMonth = getISOMonthString(now);
      const todayStr = getLocalDateString(now);

      const resolvedDay = profile.lastDate === todayStr ? (profile.dailyXP || 0) : 0;
      const resolvedWeek = profile.lastWeek === currentWeek ? (profile.weeklyXP || 0) : 0;
      const resolvedMonth = profile.lastMonth === currentMonth ? (profile.monthlyXP || 0) : 0;

      let newClaimedTasks = Array.isArray(profile.claimedTasks) ? [...profile.claimedTasks] : [];
      if (stats.taskClaimed) {
        if (newClaimedTasks.includes(stats.taskClaimed)) {
          console.warn("Task is already claimed:", stats.taskClaimed);
          throw new Error("Task already claimed!");
        }
        newClaimedTasks.push(stats.taskClaimed);
      }

      const deltaXP = stats.xpGained || 0;
      const newXP = Math.max(0, profile.xp + deltaXP);
      const newDailyXP = Math.max(0, resolvedDay + deltaXP);
      const newWeeklyXP = Math.max(0, resolvedWeek + deltaXP);
      const newMonthlyXP = Math.max(0, resolvedMonth + deltaXP);
      const newRank = getRankFromXP(newXP);

      let resolvedStreak = profile.streak || 0;
      let newLastWorkoutDate = profile.last_workout_date || "";

      if (stats.workoutCompleted || stats.completedWorkoutName || stats.completedMoggedExerciseName) {
        const oldLastWorkoutDate = profile.last_workout_date;
        newLastWorkoutDate = todayStr;

        if (!oldLastWorkoutDate || oldLastWorkoutDate === "") {
          resolvedStreak = 1;
        } else {
          const diffDays = getDaysBetween(oldLastWorkoutDate, todayStr);
          if (diffDays === 1) {
            resolvedStreak = (profile.streak || 0) + 1;
          } else if (diffDays === 0) {
            resolvedStreak = profile.streak || 0;
          } else {
            resolvedStreak = 1;
          }
        }
      } else if (stats.streakChange !== undefined) {
        resolvedStreak = stats.streakChange;
      }

      let newCompletedWorkouts = Array.isArray(profile.completed_workouts) ? [...profile.completed_workouts] : [];
      if (stats.completedWorkoutName) {
        newCompletedWorkouts.push({
          date: todayStr,
          exerciseName: stats.completedWorkoutName
        });
      }

      let newMoggedExercises = Array.isArray(profile.mogged_exercises) ? [...profile.mogged_exercises] : [];
      if (stats.completedMoggedExerciseName) {
        newMoggedExercises.push({
          date: todayStr,
          exerciseName: stats.completedMoggedExerciseName
        });
      }

      const additionalWorkouts = (stats.workoutCompleted || stats.completedWorkoutName || stats.completedMoggedExerciseName) ? 1 : 0;
      const newTotalWorkouts = (profile.totalWorkouts || 0) + additionalWorkouts;
      const additionalWins = stats.challengeWon ? 1 : 0;
      const newChallengeWins = (profile.challengeWins || 0) + additionalWins;

      const newFitnessScore = (resolvedStreak * 15) + (newTotalWorkouts * 25) + (newChallengeWins * 50) + Math.floor(newXP * 0.1);
      
      
      
      let baseIntegrityScore = profile.integrityScore ?? 100;
      let integrityGain = stats.integrityScoreChange || 0;
      
      const isCheating = (stats.integrityScoreChange || 0) < 0;
      const isHonestWorkout = !isCheating && (stats.workoutCompleted || stats.completedWorkoutName || stats.completedMoggedExerciseName || stats.challengeWon);

      let newRecoveryWorkouts = profile.recoveryWorkouts || 0;
      let isRecoveringFromZero = profile.recoveringFromZero || false;

      if (baseIntegrityScore === 0 && isCheating) {
         // Already 0, cheating again keeps it at 0
      } else if (baseIntegrityScore === 0 && !isRecoveringFromZero && isHonestWorkout) {
         isRecoveringFromZero = true;
      }

      if (isHonestWorkout) {
        integrityGain += 1;

        if (stats.workoutCompletedOnTime) {
          integrityGain += 2;
        }

        if (stats.dailyGoalCompleted) {
          integrityGain += 2;
        }

        if (resolvedStreak === 3 && (profile.streak || 0) === 2) {
          integrityGain += 5;
        } else if (resolvedStreak === 7 && (profile.streak || 0) === 6) {
          integrityGain += 10;
        } else if (resolvedStreak === 14 && (profile.streak || 0) === 13) {
          integrityGain += 15;
        } else if (resolvedStreak === 30 && (profile.streak || 0) === 29) {
          integrityGain += 25;
        }
      }

      let newIntegrityScore = baseIntegrityScore + integrityGain;

      if (baseIntegrityScore < 50 || isRecoveringFromZero) {
         if (isCheating) {
             newRecoveryWorkouts = 0;
             if (newIntegrityScore <= 0) isRecoveringFromZero = true;
         } else if (isHonestWorkout) {
             newRecoveryWorkouts += 1;
             
             if (isRecoveringFromZero) {
                 if (newRecoveryWorkouts === 3) newIntegrityScore = 15;
                 else if (newRecoveryWorkouts === 7) newIntegrityScore = 30;
                 else if (newRecoveryWorkouts === 14) newIntegrityScore = 50;
                 else if (newRecoveryWorkouts > 14) {
                     isRecoveringFromZero = false;
                     newRecoveryWorkouts = 0;
                 } else {
                     newIntegrityScore = baseIntegrityScore;
                 }
             } else {
                 if (newRecoveryWorkouts === 3) newIntegrityScore += 10;
                 else if (newRecoveryWorkouts === 7) newIntegrityScore += 20;
                 else if (newRecoveryWorkouts === 14) newIntegrityScore += 30;
             }
         }
      } else {
         newRecoveryWorkouts = 0;
         isRecoveringFromZero = false;
      }
      
      newIntegrityScore = Math.max(0, Math.min(100, newIntegrityScore));
      integrityGain = newIntegrityScore - baseIntegrityScore;

      
      if (integrityGain > 0) {
         window.dispatchEvent(new CustomEvent('trust_increase', { detail: { gain: integrityGain } }));
      }
      
      if (baseIntegrityScore >= 50 && newIntegrityScore < 50) {
         window.dispatchEvent(new CustomEvent('trust_warning', { detail: { score: newIntegrityScore } }));
      }

      const newIntegrityViolations = Math.max(0, (profile.integrityViolations || 0) + (stats.integrityViolationsChange || 0));
      const newHonestDays = stats.consecutiveHonestDaysChange !== undefined ? 
        ((stats.consecutiveHonestDaysChange === 0) ? 0 : Math.max(0, (profile.consecutiveHonestDays || 0) + stats.consecutiveHonestDaysChange)) : 
        (profile.consecutiveHonestDays || 0);

      const updateData: Partial<UserProfile> = {
        xp: newXP,
        dailyXP: newDailyXP,
        weeklyXP: newWeeklyXP,
        monthlyXP: newMonthlyXP,
        lastDate: todayStr,
        lastWeek: currentWeek,
        lastMonth: currentMonth,
        rank: newRank,
        streak: resolvedStreak,
        totalWorkouts: newTotalWorkouts,
        challengeWins: newChallengeWins,
        fitnessScore: newFitnessScore,
        last_workout_date: newLastWorkoutDate,
        completed_workouts: newCompletedWorkouts,
        mogged_exercises: newMoggedExercises,
        integrityScore: newIntegrityScore,
        integrityViolations: newIntegrityViolations,
        consecutiveHonestDays: newHonestDays,
        recoveryWorkouts: newRecoveryWorkouts,
        recoveringFromZero: isRecoveringFromZero
      };

      if (stats.taskClaimed) {
        updateData.claimedTasks = newClaimedTasks;
      }
      if (stats.goal !== undefined) {
        updateData.goal = stats.goal;
      }
      if (stats.theme !== undefined) {
        updateData.theme = stats.theme;
      }

      saveProfile({ ...profile, ...updateData });

    } catch (err) {
      console.error("Failed to update profile stats:", err);
    }
  };

  const updateUserXP = async (additionalXP: number) => {
    await updateProfileStats({ xpGained: additionalXP });
  };

  const logMoggedExercise = async (exerciseName: string, xp: number = 25) => {
    await updateProfileStats({
      completedMoggedExerciseName: exerciseName,
      xpGained: xp
    });
  };

  const toggleFriend = async (friendUid: string) => {};

  const updateUserProfileFields = async (fields: Partial<UserProfile>): Promise<void> => {
    if (!profile) throw new Error("No profile");
    saveProfile({ ...profile, ...fields });
  };

  return (
    <AuthContext.Provider value={{
      user,
      profile,
      loading,
      profileRequired,
      signUpWithEmail,
      signInWithEmail,
      resetPassword,
      completeProfileSetup,
      signOutUser,
      refreshProfile,
      updateUserXP,
      updateProfileStats,
      toggleFriend,
      updateUserProfileFields,
      logMoggedExercise
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

export function getRankDetails(xp: number) {
  if (xp >= 10000) return { title: "Ascended", next: "Max", base: 10000, nextXP: 99999, emoji: "✨" };
  if (xp >= 7500) return { title: "Mythic", next: "Ascended", base: 7500, nextXP: 10000, emoji: "🌟" };
  if (xp >= 5000) return { title: "Legend", next: "Mythic", base: 5000, nextXP: 7500, emoji: "👑" };
  if (xp >= 3000) return { title: "Titan", next: "Legend", base: 3000, nextXP: 5000, emoji: "🦁" };
  if (xp >= 2000) return { title: "Champion", next: "Titan", base: 2000, nextXP: 3000, emoji: "🏆" };
  if (xp >= 1000) return { title: "Elite", next: "Champion", base: 1000, nextXP: 2000, emoji: "⚔️" };
  if (xp >= 500) return { title: "Warrior", next: "Elite", base: 500, nextXP: 1000, emoji: "🗡️" };
  return { title: "Beginner", next: "Warrior", base: 0, nextXP: 500, emoji: "🌱" };
}
