const fs = require('fs');

let code = fs.readFileSync('src/components/WeeklyChallengeScreen.tsx', 'utf8');

code = code.replace(/  const \[showCheatWarning, setShowCheatWarning\] = useState\(false\);\n/g, '');
code = code.replace(/  const \[pendingAmount, setPendingAmount\] = useState<number \| null>\(null\);\n/g, '');

const oldHandle = `  const handleAddReps = (amount: number) => {
    if (isCompleted || hasClaimedThisWeek || showCheatWarning) return;
    
    if (amount === 1 && cooldown1 > 0) return;
    if (amount === 10 && cooldown10 > 0) return;

    const now = Date.now();
    const timeSinceLastAction = now - lastActionTime;
    
    // Warning logic: if they somehow manage to bypass cooldown or script it
    // But since we have strict 1s and 10s cooldowns, we can just check if they are clicking TOO fast
    // Example: if they added 10 reps and 1 rep right after each other very quickly
    if (lastActionTime > 0 && timeSinceLastAction < 500 && amount > 1) { 
       setPendingAmount(amount);
       triggerCheatWarning();
       return;
    }

    addRepsInternal(amount);
  };`;

const newHandle = `  const handleAddReps = (amount: number) => {
    if (isCompleted || hasClaimedThisWeek) return;
    
    if (amount === 1 && cooldown1 > 0) return;
    if (amount === 10 && cooldown10 > 0) return;

    if (checkCheat(exercise.name, amount)) {
      const updated = { ...challenge };
      updated.exercises[0].completedReps = 0;
      onUpdate(updated);
      return;
    }

    addRepsInternal(amount);
  };`;

code = code.replace(oldHandle, newHandle);

code = code.replace(/  const triggerCheatWarning = \(\) => {[\s\S]*?setShowCheatWarning\(true\);\n  };\n/g, '');

code = code.replace(/, showCheatWarning/g, '');
code = code.replace(/!showCheatWarning && /g, '');
code = code.replace(/showCheatWarning \|\| /g, '');

const oldRender = `  if (showCheatWarning) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/90 flex flex-col items-center justify-center p-6 backdrop-blur-sm">
        <div className="bg-[#050B1A] border border-[#B66DFF]/30 rounded-3xl p-8 max-w-sm w-full text-center relative overflow-hidden shadow-[0_0_50px_rgba(182,109,255,0.2)]">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 rounded-full bg-[#B66DFF]/10 flex items-center justify-center border border-[#B66DFF]/30">
              <Zap className="w-10 h-10 text-[#B66DFF]" />
            </div>
          </div>
          
          <h2 className="text-xl font-black text-white uppercase tracking-wider mb-2">Slow Down</h2>
          <p className="text-neutral-400 text-sm font-medium mb-8">
            Genie noticed impossible speed. Are you really doing the reps?
          </p>
          
          <div className="space-y-3">
            <button 
              onClick={() => {
                setShowCheatWarning(false);
                if (pendingAmount) {
                  addRepsInternal(pendingAmount);
                  setPendingAmount(null);
                }
              }}
              className="w-full bg-white/10 hover:bg-white/20 text-white font-bold py-4 rounded-xl transition-colors text-sm uppercase tracking-widest border border-white/10"
            >
              Verify & Add Reps
            </button>
            <button 
              onClick={() => {
                setShowCheatWarning(false);
                setPendingAmount(null);
              }}
              className="w-full bg-[#B66DFF] hover:bg-[#a050f0] text-white font-black py-4 rounded-xl transition-colors text-sm uppercase tracking-widest"
            >
              Cancel Action
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (suspiciousPhase !== 'none') {`;
const newRender = `  if (suspiciousPhase !== 'none') {`;
code = code.replace(oldRender, newRender);

fs.writeFileSync('src/components/WeeklyChallengeScreen.tsx', code);
