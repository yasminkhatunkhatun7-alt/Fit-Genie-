import { GoogleGenAI } from "@google/genai";
import fs from "fs";

async function main() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.log("No GEMINI_API_KEY in environment!");
    return;
  }
  console.log("GEMINI_API_KEY is available!");
  
  const ai = new GoogleGenAI({ apiKey });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: "Say hello",
    });
    console.log("Response:", response.text);
  } catch (err: any) {
    console.error("Error:", err.message);
  }
}

main();
