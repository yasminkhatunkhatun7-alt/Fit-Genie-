const fs = require('fs');
let code = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf-8');

// 1. Add imports
code = code.replace(
  'import { ActiveChallenge } from "./ChallengesScreen";',
  'import { ActiveChallenge } from "./ChallengesScreen";\nimport { AiRepCounter } from "./AiRepCounter";\nimport { Camera } from "lucide-react";'
);

// 2. Add state
code = code.replace(
  'const [textCounter, setTextCounter] = useState(0);',
  'const [textCounter, setTextCounter] = useState(0);\n  const [showAiCounter, setShowAiCounter] = useState(false);\n  const [aiExercise, setAiExercise] = useState<"Pushups" | "Squats">("Pushups");'
);

// 3. Update handleAddReps to accept fromAI
code = code.replace(
  'const handleAddReps = (exercise: string, amount: number) => {',
  'const handleAddReps = (exercise: string, amount: number, fromAI: boolean = false) => {'
);
code = code.replace(
  'if (checkCheat(exercise, amount)) {',
  'if (!fromAI && checkCheat(exercise, amount)) {'
);

// 4. Add the AI button and modal
const exerciseBlockMatch = /<h4 className="text-white font-black uppercase tracking-tight">\{exercise\}<\/h4>/;
const exerciseBlockReplacement = `<h4 className="text-white font-black uppercase tracking-tight flex items-center gap-2">
                   {exercise}
                   {(exercise === 'Pushups' || exercise === 'Squats') && !isDone && (
                     <button
                       onClick={() => {
                         setAiExercise(exercise);
                         setShowAiCounter(true);
                       }}
                       className="bg-[#14F1E1] text-[#050B1A] px-2 py-1 rounded font-black uppercase tracking-widest text-[8px] flex items-center gap-1 shadow-[0_0_10px_rgba(20,241,225,0.4)] hover:bg-white"
                     >
                       <Camera className="w-3 h-3" /> AI Track
                     </button>
                   )}
                 </h4>`;
code = code.replace(exerciseBlockMatch, exerciseBlockReplacement);

// 5. Add the AI Modal at the end
const endDivMatch = /<\/div>\n  \);\n}/;
const endDivReplacement = `
      {showAiCounter && (
        <AiRepCounter
          initialExercise={aiExercise}
          onClose={() => setShowAiCounter(false)}
          onComplete={(reps) => {
            if (reps > 0) {
              handleAddReps(aiExercise, reps, true);
            }
            setShowAiCounter(false);
          }}
        />
      )}
    </div>
  );
}`;
code = code.replace(endDivMatch, endDivReplacement);

fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', code);
console.log('Fixed OneMonthChallengeScreen');
