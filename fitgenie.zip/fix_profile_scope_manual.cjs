const fs = require('fs');

let code = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

// The file has multiple identical matches or regex issues. We'll find it manually.
const oldString = `}: HomeDashboardProps) {
  const { triggerEvent } = useGuardianContext();
  useEffect(() => {
    let daysInactive = 0;
    if (profile?.last_workout_date) {`;

const newString = `}: HomeDashboardProps) {
  const { triggerEvent } = useGuardianContext();
  const { profile, signOutUser } = useAuth();
  
  useEffect(() => {
    let daysInactive = 0;
    if (profile?.last_workout_date) {`;

code = code.replace(oldString, newString);

// now remove the duplicate lower down
code = code.replace(`  const { profile, signOutUser } = useAuth();\n  const [notification, setNotification] = useState<string | null>(null);`, `  const [notification, setNotification] = useState<string | null>(null);`);


fs.writeFileSync('src/components/HomeDashboard.tsx', code);
