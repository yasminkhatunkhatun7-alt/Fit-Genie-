const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');

// The returns are formatted like:
// return (
//   <DailyChallengeDetailScreen
//
// We want to add <React.Fragment> right after `return (`.
// Let's replace `return (\n        <Daily` with `return (\n      <React.Fragment>\n        <Daily`
// And similarly for others.
const screens = [
  'DailyChallengeDetailScreen',
  'SpeedChallengeScreen',
  'WeeklyChallengeScreen',
  'OneMonthChallengeScreen',
  'StrengthChallengeScreen',
  'CustomChallengeDetailScreen'
];

screens.forEach(s => {
  const regex = new RegExp(`return \\([\\s\\n]*<${s}`, 'g');
  code = code.replace(regex, `return (\n      <React.Fragment>\n        <${s}`);
});

// Also the generic div one:
// return (\n      <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen">
const genericRegex = /return \([\s\n]*<div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen">/g;
code = code.replace(genericRegex, `return (\n      <React.Fragment>\n      <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen">`);

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
