const fs = require('fs');

const fileContent = `
import React, { useState, useRef, useEffect } from "react";
import { Send } from "lucide-react";
import { EXERCISES_DATA } from "../data/exercises";

interface Message {
  id: string;
  sender: "user" | "genie";
  text: string;
}

const TITLES = ["warrior", "boss", "champion", "beast", "legend", "bro", "sher"];
const EMOJIS = ["🔥", "💪", "🏆", "✅", "😤", "👍", "🙌", "💯", "🧘", "😎", "👋", "🤔", "😅", "🚀", "⚡", "🎯"];

type Language = "en" | "hi";

interface ResponseCategory {
  en: string[];
  hi: string[];
}

const genieResponses: Record<string, ResponseCategory> = {
  greetings: {
    en: [
      "Hey {title}! {emoji} Ready to grind?",
      "Yo {title}! {emoji} What's up?",
      "Genie's here! {emoji} Let's talk.",
      "Welcome back {title}! {emoji}",
      "Ready for gains {title}? {emoji}",
      "Genie listening, what's up {title}? {emoji}",
      "Hi {title}! {emoji} Focus is back.",
      "Let's go {title}! {emoji}",
      "Hey there {title}, start the workout? {emoji}",
      "What's the plan today {title}? {emoji}"
    ],
    hi: [
      "Kaisa hai {title}? {emoji}",
      "Sup {title}? {emoji} Start karein?",
      "Batao {title}, kya plan hai? {emoji}",
      "Genie listening, bol {title}. {emoji}",
      "Aagaya mera {title}! {emoji}",
      "Aaj phodenge {title}! {emoji}",
      "Hi {title}! {emoji} Focus la wapas.",
      "Aur {title}, workout karega? {emoji}",
      "Kaise ho {title}? {emoji}",
      "Let's go {title}! {emoji}"
    ]
  },
  motivation: {
    en: [
      "Get up {title}, 10 mins is enough! {emoji}",
      "Rest is fine, quitting is not. {emoji}",
      "Just do one set. {emoji}",
      "Tired? Push harder {title}! {emoji}",
      "Pain is temporary {title}. {emoji}",
      "No excuses {title}, start now! {emoji}",
      "Don't be lazy {title}! {emoji}",
      "Your future self will thank you. {emoji}",
      "Don't give up {title}! {emoji}",
      "Mind over matter {title}. {emoji}",
      "Wake up {title}, time for gains! {emoji}",
      "The grind never stops. {emoji}",
      "Be a {title}, not a quitter! {emoji}",
      "Push through the pain {title}. {emoji}",
      "Sweat is fat crying {title}. {emoji}"
    ],
    hi: [
      "Get up {title}, 10 mins is enough! {emoji}",
      "Rest is fine, quitting is not. {emoji}",
      "Ek set kar le bas. {emoji}",
      "Thak gaya? Push harder {title}! {emoji}",
      "Pain is temporary {title}. {emoji}",
      "No excuses {title}, start kar! {emoji}",
      "Aalsi mat ban {title}! {emoji}",
      "Your future self will thank you. {emoji}",
      "Haar mat maan {title}! {emoji}",
      "Mind over matter {title}. {emoji}",
      "Uth ja {title}, time for gains! {emoji}",
      "Grind rukna nahi chahiye. {emoji}",
      "Be a {title}, not a quitter! {emoji}",
      "Push through the pain {title}. {emoji}",
      "Sweat is fat crying {title}. {emoji}"
    ]
  },
  guardianHelp: {
    en: [
      "Guardian checks your form in real-time! {emoji}",
      "Trust score = proof of fair-play. {emoji}",
      "I watch your form via AI {title}. {emoji}",
      "Cheating drops your trust score! {emoji}",
      "Honest reps = 100% Trust. {emoji}",
      "Guardian is always watching {title}. {emoji}",
      "Proper form restores trust. {emoji}",
      "Genie will catch fake reps. {emoji}",
      "Stay honest {title}, trust me. {emoji}",
      "Trust dropped? Do clean reps! {emoji}",
      "I analyze your form carefully. {emoji}",
      "No cheating under my watch! {emoji}",
      "Guardian ensures you train right. {emoji}",
      "Your AI coach is tracking. {emoji}",
      "Be honest with your reps {title}. {emoji}"
    ],
    hi: [
      "Guardian tera form real-time check karta hai! {emoji}",
      "Trust score = fair-play ka proof. {emoji}",
      "Main AI se form dekhta hu {title}. {emoji}",
      "Cheat kiya toh trust score girega! {emoji}",
      "Honest reps = 100% Trust. {emoji}",
      "Guardian is always watching {title}. {emoji}",
      "Proper form se trust wapas aayega. {emoji}",
      "Genie fake reps pakad lega. {emoji}",
      "Stay honest {title}, trust me. {emoji}",
      "Trust gir gaya? Clean reps maar! {emoji}",
      "Main form analyze karta hu. {emoji}",
      "No cheating under my watch! {emoji}",
      "Guardian ensures you train right. {emoji}",
      "Your AI coach is tracking. {emoji}",
      "Be honest with your reps {title}. {emoji}"
    ]
  },
  leaderboardHelp: {
    en: [
      "Be consistent, you'll reach the top! {emoji}",
      "Earn XP, your rank will increase. {emoji}",
      "Get your name on the leaderboard {title}! {emoji}",
      "More workouts = higher rank. {emoji}",
      "Grind and increase your XP. {emoji}",
      "Beat the competition {title}. {emoji}",
      "Max out your squats and pushups. {emoji}",
      "Work hard to level up! {emoji}",
      "Leaderboard shows who the real boss is. {emoji}",
      "Daily grind increases XP. {emoji}",
      "Aim for top 10 {title}! {emoji}",
      "Show the world your rank. {emoji}",
      "Consistency is key to leveling up. {emoji}",
      "Want XP? Start a workout! {emoji}",
      "Your rank reflects your effort. {emoji}"
    ],
    hi: [
      "Consistent raho, top pe pahunch jaega! {emoji}",
      "XP kama, rank apne aap badhega. {emoji}",
      "Leaderboard pe naam la {title}! {emoji}",
      "More workouts = higher rank. {emoji}",
      "Grind kar aur XP badha. {emoji}",
      "Beat the competition {title}. {emoji}",
      "Squats aur pushups max kar. {emoji}",
      "Level up hone ke liye mehnat kar! {emoji}",
      "Leaderboard dikhata hai kon asli boss hai. {emoji}",
      "Daily grind se XP badhti hai. {emoji}",
      "Top 10 me aana hai {title}! {emoji}",
      "Show the world your rank. {emoji}",
      "Consistency is key to leveling up. {emoji}",
      "XP chahiye? Workout start kar! {emoji}",
      "Your rank reflects your effort. {emoji}"
    ]
  },
  streakHelp: {
    en: [
      "Don't break your streak, workout daily! {emoji}",
      "Streak = ultimate proof of discipline. {emoji}",
      "Skip a day and streak is zero. {emoji}",
      "Maintain the fire {title}! {emoji}",
      "Keep the consistency {title}. {emoji}",
      "Even 10 daily mins count. {emoji}",
      "Don't break the chain {title}! {emoji}",
      "Keeping the streak alive is crucial. {emoji}",
      "Show me your discipline. {emoji}",
      "Grind a little every day. {emoji}",
      "Do whatever it takes to save your streak! {emoji}",
      "Zero streak looks bad {title}. {emoji}",
      "Keep the momentum going! {emoji}",
      "Daily workout, daily gains. {emoji}",
      "Increase streak, be a boss! {emoji}"
    ],
    hi: [
      "Streak todna mat, daily ek workout kar! {emoji}",
      "Streak = discipline ka asli proof. {emoji}",
      "Ek din skip kiya toh streak zero. {emoji}",
      "Maintain the fire {title}! {emoji}",
      "Consistency maintain kar {title}. {emoji}",
      "Daily 10 mins bhi count hote hain. {emoji}",
      "Don't break the chain {title}! {emoji}",
      "Streak alive rakhna zaroori hai. {emoji}",
      "Show me your discipline. {emoji}",
      "Har din thoda grind kar. {emoji}",
      "Streak bachane ke liye kuch bhi kar! {emoji}",
      "Zero streak achhi nahi lagti {title}. {emoji}",
      "Keep the momentum going! {emoji}",
      "Daily workout, daily gains. {emoji}",
      "Streak badha, boss ban! {emoji}"
    ]
  },
  postWorkoutEncouragement: {
    en: [
      "Solid work {title}! {emoji}",
      "Awesome, come back tomorrow! {emoji}",
      "Proud of you {title}. {emoji}",
      "Rest now, you earned it. {emoji}",
      "Great session {title}! {emoji}",
      "Take protein and rest now. {emoji}",
      "Gains locked in {title}! {emoji}",
      "Keep this up every day. {emoji}",
      "Genie is impressed {title}. {emoji}",
      "Good job {title}, see you tomorrow. {emoji}",
      "That's how it's done {title}! {emoji}",
      "Hard work pays off! {emoji}",
      "We'll do better tomorrow {title}. {emoji}",
      "Awesome effort today! {emoji}",
      "Now hydrate and recover {title}. {emoji}"
    ],
    hi: [
      "Solid work {title}! {emoji}",
      "Ekdum mast, kal bhi aana! {emoji}",
      "Proud of you {title}. {emoji}",
      "Rest kar ab, you earned it. {emoji}",
      "Great session {title}! {emoji}",
      "Ab protein le aur rest kar. {emoji}",
      "Gains locked in {title}! {emoji}",
      "Aise hi roz karna hai. {emoji}",
      "Genie is impressed {title}. {emoji}",
      "Good job {title}, kal milte hain. {emoji}",
      "That's how it's done {title}! {emoji}",
      "Hard work pays off! {emoji}",
      "Kal aur better karenge {title}. {emoji}",
      "Awesome effort today! {emoji}",
      "Now hydrate and recover {title}. {emoji}"
    ]
  },
  smallTalk: {
    en: [
      "I'm good boss, ready when you are! {emoji}",
      "Genie is always pumped up {title}! {emoji}",
      "I'm your AI fitness companion {title}! {emoji}",
      "My name is Genie, here to train you. {emoji}",
      "I was built by the AI studio team! {emoji}",
      "Anytime {title}, that's my job! {emoji}",
      "You're welcome {title}! {emoji}",
      "Okay {title}, let's crush it! {emoji}",
      "Bye {title}, come back stronger! {emoji}",
      "Cool stuff, right? {emoji}",
      "Haha, exactly {title}! {emoji}",
      "Glad you liked it {title}! {emoji}"
    ],
    hi: [
      "Main badhiya hu boss, tu bata! {emoji}",
      "Genie hamesha full power me hai {title}! {emoji}",
      "Tera AI fitness companion hu main {title}! {emoji}",
      "Mera naam Genie hai, fitness AI. {emoji}",
      "AI studio walo ne banaya hai mujhe! {emoji}",
      "Arre koi na {title}, duty hai apni! {emoji}",
      "Welcome {title}, aag lagate raho! {emoji}",
      "Acha {title}, theek hai! {emoji}",
      "Alvida {title}, kal milte hain! {emoji}",
      "Mast hai na? {emoji}",
      "Haha, sahi baat hai {title}! {emoji}",
      "Ekdum kadak {title}! {emoji}"
    ]
  },
  defaultFallback: {
    en: [
      "Bro, be a bit clearer! {emoji}",
      "I didn't get that, try 'motivate me' {title}. {emoji}",
      "What are you saying {title}? {emoji}",
      "Genie didn't understand, again? {emoji}",
      "Ask about workouts or stats! {emoji}",
      "Let's talk fitness bro. {emoji}",
      "Try 'squat tips' {title}! {emoji}",
      "Say that again {title}, I missed it. {emoji}",
      "Ask me how to plank! {emoji}",
      "Hmm... try asking for motivation. {emoji}",
      "I didn't understand that {title}. {emoji}",
      "Tell me how I can help? {emoji}",
      "Type 'how to pushup' {title}. {emoji}",
      "Ask a fitness related doubt {title}. {emoji}",
      "Ask something else {title}. {emoji}"
    ],
    hi: [
      "Bro thoda clear bata! {emoji}",
      "Samjha nahi, try 'motivate me' {title}. {emoji}",
      "Kya bol raha hai {title}? {emoji}",
      "Genie samajh nahi paya, again? {emoji}",
      "Ask about workouts or stats! {emoji}",
      "Bhai fitness ki baat kar. {emoji}",
      "Try 'squat tips' {title}! {emoji}",
      "Wapas bol {title}, I missed that. {emoji}",
      "Ask me how to plank! {emoji}",
      "Hmm... try asking for motivation. {emoji}",
      "Mujhe nahi samjha {title}. {emoji}",
      "Bol bhai kya madad chahiye? {emoji}",
      "Type 'how to pushup' {title}. {emoji}",
      "Fitness related doubt puch {title}. {emoji}",
      "Kuch aur puch {title}. {emoji}"
    ]
  }
};

// Generate exercise specific tips
EXERCISES_DATA.forEach(exercise => {
  const catId = \`exercise_\${exercise.id}\`;
  const enTip = exercise.instruction_en;
  const hiTip = exercise.instruction_hi;
  
  genieResponses[catId] = {
    en: [
      \`\${enTip} {emoji}\`,
      \`Remember, \${enTip.toLowerCase()} {title}! {emoji}\`,
      \`Focus on form: \${enTip.toLowerCase()} {emoji}\`,
      \`For \${exercise.name_en}, \${enTip.toLowerCase()} {emoji}\`,
      \`Target the \${exercise.muscles.join(', ')} {title}. {emoji}\`,
      \`Keep it controlled. \${enTip} {emoji}\`,
      \`Don't rush {title}. \${enTip} {emoji}\`,
      \`Form over speed: \${enTip} {emoji}\`,
      \`Perfect form {title}: \${enTip} {emoji}\`,
      \`Mind the muscle connection. \${enTip} {emoji}\`,
      \`Breath is key. \${enTip} {emoji}\`,
      \`Nail the form. \${enTip} {emoji}\`
    ],
    hi: [
      \`\${hiTip} {emoji}\`,
      \`Sahi se kar {title}: \${hiTip} {emoji}\`,
      \`Dhyan rakh: \${hiTip} {emoji}\`,
      \`\${exercise.name_en} ke liye, \${hiTip} {emoji}\`,
      \`\${exercise.muscles.join(', ')} pe focus kar {title}. {emoji}\`,
      \`Aaram se kar. \${hiTip} {emoji}\`,
      \`Jaldi mat kar {title}. \${hiTip} {emoji}\`,
      \`Sahi form zaroori hai: \${hiTip} {emoji}\`,
      \`Perfect form {title}: \${hiTip} {emoji}\`,
      \`Muscle feel kar boss. \${hiTip} {emoji}\`,
      \`Saans le. \${hiTip} {emoji}\`,
      \`Form mat bigaadna. \${hiTip} {emoji}\`
    ]
  }
});

const hinglishWords = [
  "bhai", "kya", "kaise", "hai", "mera", "tera", "kar", "acha", "nahi", "haan",
  "kyu", "kab", "kaha", "chahiye", "karna", "wala", "bata", "bolo", "kro",
  "mujhe", "tujhe", "kitna", "kaisa", "theek", "sahi", "galat", "bohot",
  "bahut", "thoda", "abhi", "aaj", "kal", "hu", "hoon", "hi", "to", "toh"
];

const detectLanguage = (text: string): Language => {
  if (/[\u0900-\u097F]/.test(text)) {
    return "hi";
  }
  const lowerText = text.toLowerCase();
  const words = lowerText.split(/\\W+/);
  if (words.some(word => hinglishWords.includes(word))) {
    return "hi";
  }
  return "en";
};

const appHelpTriggers = [
  { id: "guardianHelp", keys: ["guardian", "trust score", "trust"] },
  { id: "leaderboardHelp", keys: ["leaderboard", "rank", "xp"] },
  { id: "streakHelp", keys: ["streak"] },
];

const motivationTriggers = ["motivate", "tired", "lazy", "give up", "can't", "don't feel like", "quit", "hard"];
const postWorkoutTriggers = ["done", "finished", "completed", "did it", "khatam"];
const greetingsTriggers = ["hi", "hello", "hey", "yo", "namaste", "pranam"];
const smallTalkTriggers = [
  "how are you", "kaise ho", "what's your name", "naam kya hai", 
  "who are you", "tu kaun hai", "who made you", "tujhe kisne banaya", 
  "thank you", "thanks", "shukriya", "ok", "acha", "bye", "alvida", 
  "nice", "cool", "mast", "lol", "haha"
];

const tipKeywords = ["how", "tip", "form", "kaise", "tarika", "tips"];

const generateGenieMessage = (categoryId: string, lang: Language) => {
  const arr = genieResponses[categoryId]?.[lang] || genieResponses.defaultFallback[lang];
  let text = arr[Math.floor(Math.random() * arr.length)];
  const title = TITLES[Math.floor(Math.random() * TITLES.length)];
  const emoji = EMOJIS[Math.floor(Math.random() * EMOJIS.length)];
  return text.replace(/{title}/g, title).replace(/{emoji}/g, emoji);
};

export default function GenieChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const isFirstMount = useRef(true);

  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      const greetingMsg = {
        id: Date.now().toString(),
        sender: "genie" as const,
        text: generateGenieMessage("greetings", "hi")
      };
      setMessages([greetingMsg]);
    }
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg = input.trim();
    const newUserMsg: Message = { id: Date.now().toString(), sender: "user", text: userMsg };
    
    setMessages(prev => [...prev, newUserMsg]);
    setInput("");

    setTimeout(() => {
      const lowerInput = userMsg.toLowerCase();
      const detectedLang = detectLanguage(lowerInput);
      let matchedCategoryId: string | null = null;
      let isDetailCategory = false;

      // 1. Exercise-specific tips
      const hasTipKeyword = tipKeywords.some(tk => lowerInput.includes(tk));
      if (hasTipKeyword) {
        for (const exercise of EXERCISES_DATA) {
          const enName = exercise.name_en.toLowerCase();
          const hiName = exercise.name_hi?.toLowerCase() || "";
          
          if (lowerInput.includes(enName) || (hiName && lowerInput.includes(hiName))) {
            matchedCategoryId = \`exercise_\${exercise.id}\`;
            isDetailCategory = true;
            break;
          }
          // fall back to splitting name (e.g. "push up" vs "pushup")
          const parts = enName.split(' ');
          if (parts.length > 0 && parts[0].length >= 4 && lowerInput.includes(parts[0])) {
            matchedCategoryId = \`exercise_\${exercise.id}\`;
            isDetailCategory = true;
            break;
          }
        }
      }

      // 2. App Help
      if (!matchedCategoryId) {
        for (const category of appHelpTriggers) {
          if (category.keys.some(k => lowerInput.includes(k))) {
            matchedCategoryId = category.id;
            isDetailCategory = true;
            break;
          }
        }
      }

      // 3. Motivation
      if (!matchedCategoryId && motivationTriggers.some(k => lowerInput.includes(k))) {
        matchedCategoryId = "motivation";
      }

      // 4. Post-workout
      if (!matchedCategoryId && postWorkoutTriggers.some(k => lowerInput.includes(k))) {
        matchedCategoryId = "postWorkoutEncouragement";
      }

      // 5. Greetings
      if (!matchedCategoryId && greetingsTriggers.some(k => lowerInput.includes(k))) {
        matchedCategoryId = "greetings";
      }

      // 6. General/small-talk
      if (!matchedCategoryId && smallTalkTriggers.some(k => lowerInput.includes(k))) {
        matchedCategoryId = "smallTalk";
      }

      // 7. Default fallback
      if (!matchedCategoryId) {
        matchedCategoryId = "defaultFallback";
      }

      const primaryText = generateGenieMessage(matchedCategoryId, detectedLang);
      const newGenieMsg: Message = { id: (Date.now() + 1).toString(), sender: "genie", text: primaryText };
      
      setMessages(prev => [...prev, newGenieMsg]);

      if (isDetailCategory && Math.random() < 0.4) {
        setTimeout(() => {
          let secondaryText = generateGenieMessage(matchedCategoryId!, detectedLang);
          if (secondaryText === primaryText) {
            secondaryText = generateGenieMessage(matchedCategoryId!, detectedLang);
          }
          const secondaryMsg: Message = { id: (Date.now() + 2).toString(), sender: "genie", text: secondaryText };
          setMessages(prev => [...prev, secondaryMsg]);
        }, 800);
      }
    }, 500); 
  };

  return (
    <div className="flex flex-col h-[50vh] min-h-[350px] max-h-[60vh]">
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2 custom-scrollbar">
        {messages.map((m) => (
          <div key={m.id} className={\`flex \${m.sender === "user" ? "justify-end" : "justify-start"}\`}>
            {m.sender === "genie" && (
              <div className="w-6 h-6 rounded-full bg-[#14F1E1]/20 flex items-center justify-center mr-2 flex-shrink-0 mt-1">
                 <div className="w-3 h-3 bg-[#14F1E1] rounded-full shadow-[0_0_8px_#14F1E1]" />
              </div>
            )}
            <div className={\`px-4 py-2 rounded-2xl max-w-[80%] text-sm \${
              m.sender === "user" 
                ? "bg-[#14F1E1] text-[#050B1A] font-bold rounded-tr-sm" 
                : "bg-white/10 text-white rounded-tl-sm border border-white/5"
            }\`}>
              {m.text}
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>

      <form onSubmit={handleSend} className="flex gap-2">
        <input 
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Ask Genie..."
          className="flex-1 bg-black/50 border border-neutral-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#14F1E1] transition-colors"
        />
        <button 
          type="submit" 
          disabled={!input.trim()}
          className="bg-[#14F1E1] text-[#050B1A] p-3 rounded-xl disabled:opacity-50 hover:bg-[#0DE2D3] transition-colors flex items-center justify-center"
        >
          <Send className="w-5 h-5" />
        </button>
      </form>
    </div>
  );
}
`;

fs.writeFileSync('src/components/GenieChat.tsx', fileContent);
