const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

code = code.replace(
  /      \}\)\s*\}        <\/div>\s*\}\)\s*<\/div>\s*\)\}\s*<\/div>\s*\);\s*\}/g,
  `      })}
        </div>
      )}
    </div>
  );
}`
);

fs.writeFileSync('src/components/WorldChat.tsx', code);
