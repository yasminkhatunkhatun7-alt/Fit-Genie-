const fs = require('fs');
const file = 'src/context/AuthContext.tsx';
let code = fs.readFileSync(file, 'utf8');

code = code.replace(
  'import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, User } from "firebase/auth";',
  'import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, User, browserPopupRedirectResolver } from "firebase/auth";'
);

code = code.replace(
  'const result = await signInWithPopup(auth, provider);',
  'const result = await signInWithPopup(auth, provider, browserPopupRedirectResolver);'
);

fs.writeFileSync(file, code);
