const fs = require('fs');

let appContent = fs.readFileSync('src/App.tsx', 'utf8');
appContent = appContent.replace(
  'terms: 9,',
  'terms: 9,\n  settings: 10,'
);
fs.writeFileSync('src/App.tsx', appContent);
