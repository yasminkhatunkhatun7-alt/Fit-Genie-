const fs = require('fs');
const file = 'src/lib/firebase.ts';
const content = `import { initializeApp, getApps, getApp } from 'firebase/app';
import { initializeAuth, browserLocalPersistence, browserSessionPersistence, indexedDBLocalPersistence, getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

// Initialize Firestore
export const db = firebaseConfig.firestoreDatabaseId 
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Initialize Auth with persistence fallback (fixes "Database is closing/hidden" when IndexedDB is blocked)
let authInstance;
try {
  authInstance = getAuth(app); // Will not throw if already initialized
} catch (e) {
  // Ignored
}

if (!authInstance) {
  authInstance = initializeAuth(app, {
    persistence: [indexedDBLocalPersistence, browserLocalPersistence, browserSessionPersistence]
  });
}

export const auth = authInstance;
`;
fs.writeFileSync(file, content);
