const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');

// 1. Add imports
const importOld = `import { getTodayChallenge } from "../utils/dailyChallenge";`;
const importNew = `import { getTodayChallenge } from "../utils/dailyChallenge";
import { AiRepCounter } from "./AiRepCounter";
import { Camera } from "lucide-react";`;
if (code.includes(importOld) && !code.includes('AiRepCounter')) {
  code = code.replace(importOld, importNew);
}

// 2. Add state
const stateOld = `  const [view, setView] = useState<"list" | "active" | "builder">("list");`;
const stateNew = `  const [view, setView] = useState<"list" | "active" | "builder">("list");
  const [showAiCounter, setShowAiCounter] = useState(false);
  const [aiExerciseIndex, setAiExerciseIndex] = useState<number>(0);`;
if (code.includes(stateOld) && !code.includes('showAiCounter')) {
  code = code.replace(stateOld, stateNew);
}

// 3. Inject the floating AI tracker logic
const renderAiTracker = `
        {/* Floating AI Camera Button */}
        {activeChallenge.exercises.some(e => e.name.toLowerCase().includes('pushup') || e.name.toLowerCase().includes('squat')) && !showAiCounter && (
          <motion.div
             initial={{ opacity: 0, scale: 0.8 }}
             animate={{ opacity: 1, scale: 1 }}
             className="fixed bottom-32 right-6 z-50 flex flex-col items-end gap-3"
          >
            {activeChallenge.exercises.map((ex, i) => {
              const exNameLower = ex.name.toLowerCase();
              if (exNameLower.includes('pushup') || exNameLower.includes('squat')) {
                return (
                  <button
                    key={i}
                    onClick={() => {
                      setAiExerciseIndex(i);
                      setShowAiCounter(true);
                    }}
                    className="bg-[#14F1E1] text-[#050B1A] px-4 py-3 rounded-full font-black uppercase tracking-widest text-[10px] shadow-[0_0_20px_rgba(20,241,225,0.4)] flex items-center gap-2"
                  >
                    <Camera className="w-4 h-4" /> 
                    AI {ex.name} Tracker
                  </button>
                );
              }
              return null;
            })}
          </motion.div>
        )}

        {/* AI Rep Counter Modal */}
        {showAiCounter && (
          <AiRepCounter
             initialExercise={activeChallenge.exercises[aiExerciseIndex]?.name.toLowerCase().includes('squat') ? "Squats" : "Pushups"}
             onClose={() => setShowAiCounter(false)}
             onComplete={(reps) => {
               const updated = { ...activeChallenge };
               if (updated.exercises[aiExerciseIndex]) {
                 updated.exercises[aiExerciseIndex].completedReps += reps;
                 setActiveChallenge(updated);
               }
               setShowAiCounter(false);
             }}
          />
        )}
`;

const targets = [
  'DailyChallengeDetailScreen',
  'SpeedChallengeScreen',
  'WeeklyChallengeScreen',
  'OneMonthChallengeScreen',
  'StrengthChallengeScreen',
  'CustomChallengeDetailScreen'
];

targets.forEach(compName => {
  const regexStr = 'return \\([\\s\\S]*?<' + compName + '[\\s\\S]*?\\/>[\\s\\S]*?\\);';
  const regex = new RegExp(regexStr);
  const match = code.match(regex);
  if (match) {
    const originalReturn = match[0];
    const withoutClosing = originalReturn.slice(0, originalReturn.lastIndexOf(');'));
    const wrappedReturn = withoutClosing.replace(/return \(/, 'return (\\n      <React.Fragment>') + renderAiTracker + '\\n      </React.Fragment>\\n    );';
    code = code.replace(originalReturn, wrappedReturn);
  }
});

const genericRegex = /return \([\s\S]*?<div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen">[\s\S]*?\{\/\* TOAST NOTIFICATION \*\/\}[\s\S]*?<\/AnimatePresence>[\s\S]*?<\/div>[\s\S]*?<\/div>[\s\S]*?\);/;
const genMatch = code.match(genericRegex);
if (genMatch) {
    const originalReturn = genMatch[0];
    const withoutClosing = originalReturn.slice(0, originalReturn.lastIndexOf(');'));
    const wrappedReturn = withoutClosing.replace(/return \(/, 'return (\\n      <React.Fragment>') + renderAiTracker + '\\n      </React.Fragment>\\n    );';
    code = code.replace(originalReturn, wrappedReturn);
}

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
console.log('done wrapping active challenges');
