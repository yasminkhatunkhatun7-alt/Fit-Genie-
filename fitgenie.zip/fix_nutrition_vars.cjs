const fs = require('fs');
const file = 'src/components/NutritionLog.tsx';
let code = fs.readFileSync(file, 'utf8');

const varsToAdd = `
  const [customProteinInput, setCustomProteinInput] = useState("");
  const quickProteinMeals = [
    { name: "Egg Whites", protein: 25, icon: "🥚" },
    { name: "Chicken Breast", protein: 30, icon: "🍗" },
    { name: "Protein Shake", protein: 24, icon: "🥤" },
    { name: "Tofu Block", protein: 20, icon: "🧊" }
  ];
`;

code = code.replace(/const \[confirmResetState, setConfirmResetState\] = useState<any>\(null\);/, 
  'const [confirmResetState, setConfirmResetState] = useState<any>(null);\n' + varsToAdd);

code = code.replace(/<NutritionGoalModal goals=\{goals\} onUpdateGoals=\{handleUpdateGoals\} \/>/, 
  '<NutritionGoalModal goals={goals} onSaveGoals={handleSaveGoals} onClose={() => setIsEditingGoals(false)} />');

fs.writeFileSync(file, code);
