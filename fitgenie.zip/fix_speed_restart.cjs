const fs = require('fs');

const file = 'src/components/SpeedChallengeScreen.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(/    onUpdate\(updated\);\n    \}\);\n  \};\n/g, '    onUpdate(updated);\n  };\n');

fs.writeFileSync(file, content);
