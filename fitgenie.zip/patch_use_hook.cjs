const fs = require('fs');

let code = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

// Add import
if (!code.includes('useChallengeValidation')) {
  code = code.replace(/import React, \{ useState, useEffect, useMemo \} from 'react';/, "import React, { useState, useEffect, useMemo } from 'react';\nimport { useChallengeValidation } from '../hooks/useChallengeValidation';");
}

const hookCall = `  const { logReps: validateReps } = useChallengeValidation({ 
    Pushups: 2000, 
    Squats: 2000, 
    Crunches: 1000, 
    Burpees: 1000,
    Pullups: 500
  });`;

if (!code.includes('useChallengeValidation(')) {
  code = code.replace(/  const \[monthState, setMonthState\] = useState<MonthRPGState>/, hookCall + '\n  const [monthState, setMonthState] = useState<MonthRPGState>');
}

const handleAddRepsReplacement = `  const handleAddReps = (exercise: string, amount: number) => {
    if (isMonthComplete || monthState.validationFailed) return;
    
    const now = Date.now();
    const elapsedSecsFromLast = (now - lastActionTime) / 1000;
    
    let isSuspicious = false;
    
    if (amount >= 50 && elapsedSecsFromLast < 2) {
      isSuspicious = true; // Massive rep spam
    }
    if (amount >= 100 && elapsedSecsFromLast < 5) {
      isSuspicious = true; // Impossible completion speed
    }
    
    // Call our new hook
    const hookFailed = validateReps(exercise, amount);
    if (hookFailed) {
      isSuspicious = true;
    }
    
    if (isSuspicious) {
      setShowCheatWarning(true);
      setMonthState(prev => {
        const newFlags = (prev.suspiciousFlags || 0) + 1;
        const updated = {
          ...prev,
          suspiciousFlags: newFlags,
          validationFailed: prev.validationFailed || newFlags >= 2
        };
        localStorage.setItem(storageKey, JSON.stringify(updated));
        return updated;
      });
      return;
    }

    setLastActionTime(now);
    playSound("click");
    
    const targets = monthState.mode === 'legendary' ? TARGETS.legendary : TARGETS.normal;
    const maxReps = targets[exercise as keyof typeof targets];
    
    setMonthState(prev => {
       const updated = { ...prev };
       
       // Handle Daily Log for Cheat Detection
       if (!updated.dailyLog || updated.dailyLog.date !== todayStr) {
         updated.dailyLog = { date: todayStr, reps: {} };
       }
       const currentDailyReps = updated.dailyLog.reps[exercise] || 0;
       updated.dailyLog.reps[exercise] = currentDailyReps + amount;
       
       // Unrealistic threshold check (e.g., 2500 reps of one exercise in a single day is impossible)
       if (updated.dailyLog.reps[exercise] > 2500) {
         updated.validationFailed = true;
         setShowCheatWarning(true);
       }
       
       const totalDailyAll = Object.values(updated.dailyLog.reps).reduce((a, b) => a + b, 0);
       // Unrealistic total daily activity threshold (e.g., 5000+ total reps in one day)
       if (totalDailyAll > 5000) {
         updated.validationFailed = true;
         setShowCheatWarning(true);
       }

       const currentReps = updated.progress[exercise] || 0;
       const newReps = Math.min(currentReps + amount, maxReps);
       updated.progress = { ...updated.progress, [exercise]: newReps };
       
       // Update streak & active days
       if (prev.lastActiveDate !== todayStr) {
         updated.activeDaysCount += 1;
         if (getDaysDiff(prev.lastActiveDate, todayStr) === 1 || prev.lastActiveDate === "") {
           updated.streak += 1;
         } else {
           updated.streak = 1;
         }
         updated.longestStreak = Math.max(updated.longestStreak, updated.streak);
         updated.lastActiveDate = todayStr;
         if (!updated.completedDays.includes(todayStr)) {
           updated.completedDays.push(todayStr);
         }
       }

       // Weekly Boss Check
       const totalGoal = Object.values(targets).reduce((a,b)=>a+b, 0);
       const totalCurrent = Object.values(updated.progress).reduce((a,b)=>a+b, 0);
       const progressPercent = totalCurrent / totalGoal;
       
       WEEKLY_BOSSES.forEach(wb => {
         if (progressPercent >= wb.hpThreshold && !updated.weeklyBossesDefeated.includes(wb.id)) {
           updated.weeklyBossesDefeated.push(wb.id);
           playSound("success"); // boss defeated
         }
       });

       localStorage.setItem(storageKey, JSON.stringify(updated));
       return updated;
    });

    const newId = textCounter + 1;
    setTextCounter(newId);
    setFloatingTexts(prev => [...prev, { id: newId, text: \`+\${amount}\`, x: Math.random() * 40 - 20 }]);
    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== newId));
    }, 1000);
  };`;

code = code.replace(/  const handleAddReps = \([\s\S]*?\}, 1000\);\n  \};\n/, handleAddRepsReplacement + '\n');

fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', code);
