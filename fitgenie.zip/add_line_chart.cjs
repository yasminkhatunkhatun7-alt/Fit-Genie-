const fs = require('fs');
let code = fs.readFileSync('src/components/StatsView.tsx', 'utf-8');

const lineChartSection = `
      {/* Volume & Weight Progression Line Chart */}
      <div className="bg-brand-surface border border-brand-border p-5 md:p-6 rounded-3xl space-y-5 shadow-2xl relative overflow-hidden" id="stats-volume-progression-card">
        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-brand-border/40 pb-4">
          <div className="space-y-0.5 text-left">
            <h3 className="text-xs uppercase font-extrabold tracking-widest text-[#4DA8FF] flex items-center gap-1.5 font-sans">
              <TrendingUp className="w-4 h-4 text-[#4DA8FF]" />
              <span>Progress & Volume Over Time</span>
            </h3>
            <p className="text-[10px] text-brand-muted uppercase mt-0.5">
              Total volume (Sets × Reps × Weight) and max weight lifted
            </p>
          </div>
        </div>

        <div className="h-64 w-full relative z-10 pt-4">
          <SafeResponsiveContainer width="100%" height="100%">
            <LineChart data={statsData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
              <XAxis 
                dataKey="label" 
                stroke="#666" 
                fontSize={10} 
                tickLine={false}
                axisLine={false}
                tickMargin={10}
              />
              <YAxis 
                yAxisId="left"
                stroke="#666" 
                fontSize={10} 
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => val >= 1000 ? \`\${(val/1000).toFixed(1)}k\` : val}
              />
              <YAxis 
                yAxisId="right"
                orientation="right"
                stroke="#666" 
                fontSize={10} 
                tickLine={false}
                axisLine={false}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: "#0F0F0F", 
                  borderColor: "#222222", 
                  borderRadius: "12px", 
                  color: "#FFFFFF",
                  fontFamily: "sans-serif",
                  fontSize: "12px"
                }} 
                labelClassName="text-brand-muted uppercase font-black tracking-widest text-[9px] mb-1"
              />
              <Legend wrapperStyle={{ fontSize: '10px', textTransform: 'uppercase', fontWeight: 900, letterSpacing: '1px' }} />
              <Line 
                yAxisId="left"
                type="monotone" 
                dataKey="volume" 
                name="Total Volume (kg)"
                stroke="#4DA8FF" 
                strokeWidth={3}
                dot={{ r: 2, fill: "#4DA8FF", strokeWidth: 0 }}
                activeDot={{ r: 5, strokeWidth: 0 }}
              />
              <Line 
                yAxisId="right"
                type="monotone" 
                dataKey="maxWeight" 
                name="Max Weight (kg)"
                stroke="#B66DFF" 
                strokeWidth={3}
                dot={{ r: 2, fill: "#B66DFF", strokeWidth: 0 }}
                activeDot={{ r: 5, strokeWidth: 0 }}
              />
            </LineChart>
          </SafeResponsiveContainer>
        </div>
      </div>
`;

code = code.replace(
  '{/* INTENSITY DISTRIBUTION PIE CHART */}',
  lineChartSection + '\n      {/* INTENSITY DISTRIBUTION PIE CHART */}'
);

fs.writeFileSync('src/components/StatsView.tsx', code);
