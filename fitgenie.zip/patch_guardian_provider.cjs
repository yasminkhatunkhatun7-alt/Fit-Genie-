const fs = require('fs');

let mainCode = fs.readFileSync('src/main.tsx', 'utf8');
if (!mainCode.includes('GuardianProvider')) {
  mainCode = mainCode.replace("import App from './App.tsx';", "import App from './App.tsx';\nimport { GuardianProvider } from './context/GuardianContext';");
  mainCode = mainCode.replace("<App />", "<GuardianProvider>\n        <App />\n      </GuardianProvider>");
  fs.writeFileSync('src/main.tsx', mainCode);
}

let appCode = fs.readFileSync('src/App.tsx', 'utf8');
appCode = appCode.replace(/<GuardianProvider>/g, '');
appCode = appCode.replace(/<\/GuardianProvider>/g, '');
appCode = appCode.replace('import { GuardianProvider } from "./context/GuardianContext";', 'import { useGuardianContext } from "./context/GuardianContext";');

// Add hook
const searchHook = "  const [showWelcome, setShowWelcome] = useState(false);";
if (appCode.includes(searchHook) && !appCode.includes('const { triggerEvent } = useGuardianContext();')) {
  appCode = appCode.replace(searchHook, "  const { triggerEvent } = useGuardianContext();\n" + searchHook);
}

// Inject in navigateToView
const oldNav = `  const navigateToView = (newView: AppView, params?: any) => {
    const now = Date.now();
    if (now - lastNavTime < 120) return; // Guard against rapid multi-clicking
    setLastNavTime(now);
    if (newView !== view) {
      setPrevView(view);
      setView(newView);`;
      
const newNav = `  const navigateToView = (newView: AppView, params?: any) => {
    const now = Date.now();
    if (now - lastNavTime < 120) return; // Guard against rapid multi-clicking
    setLastNavTime(now);
    if (newView !== view) {
      if (newView === 'home') triggerEvent("nav_home");
      else if (newView === 'challenges') triggerEvent("nav_challenge");
      else if (newView === 'generator' || newView === 'daily') triggerEvent("nav_workout");
      else if (newView === 'profile') triggerEvent("nav_profile");
      else triggerEvent("focused");
      setPrevView(view);
      setView(newView);`;

appCode = appCode.replace(oldNav, newNav);

fs.writeFileSync('src/App.tsx', appCode);

