const fs = require('fs');
let content = fs.readFileSync('index.html', 'utf8');

if (!content.includes('manifest.json')) {
  content = content.replace(
    '<title>FitSelect — Smart Workout Generator</title>',
    '<title>Fit Genie</title>\n    <link rel="manifest" href="/manifest.json">\n    <link rel="icon" type="image/svg+xml" href="/icon-192.svg">\n    <meta name="theme-color" content="#2dd4bf">'
  );
  fs.writeFileSync('index.html', content);
  console.log('Updated index.html');
}
