const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Remove import
content = content.replace(/import WorkoutGenerator from "\.\/components\/WorkoutGenerator";\n/, '');

// Remove route
content = content.replace(/                \{view === "generator" && \(\s*<WorkoutGenerator\s*onAddSession=\{handleAddSession\}\s*onNavigateToHistory=\{\(\) => navigateToView\("history"\)\}\s*\/>\s*\)\}\n/, '');

// Remove menu item
content = content.replace(/\s*\{ id: "generator", name: "Workout Generator", icon: <Dumbbell className="w-3\.5 h-3\.5" \/> \},/, '');

fs.writeFileSync('src/App.tsx', content);
