const fs = require('fs');

let code = fs.readFileSync('src/components/Onboarding.tsx', 'utf-8');

// Add import
code = code.replace(
  'import { playSound } from "../utils/audio";',
  'import { playSound } from "../utils/audio";\nimport { useAuth } from "../context/AuthContext";'
);

// Add auth hook
code = code.replace(
  'const [step, setStep] = useState(1);',
  'const { user, signInWithGoogle } = useAuth();\n  const [step, setStep] = useState(0);'
);

// Add step 0 render logic
const step0 = `
  const handleGoogleSignIn = async () => {
    try {
      await signInWithGoogle();
      // On success, AuthContext will handle user state
      // The component will re-render and move to step 1 automatically if we add a useEffect, or we can just let App.tsx re-render.
      // Actually, if App.tsx re-renders and profile.onboardingCompleted is true, Onboarding unmounts.
      // If it's false, Onboarding stays, we should setStep(1).
      setStep(1);
    } catch (err) {
      console.error(err);
      alert("Sign-in cancelled, try again");
    }
  };

  useEffect(() => {
    if (user && step === 0) {
      setStep(1);
    }
  }, [user, step]);

  if (step === 0) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] text-white flex flex-col items-center justify-center p-6 relative overflow-hidden font-mono">
        <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
          <div className="absolute top-[20%] left-[20%] w-64 h-64 bg-[#B66DFF] rounded-full blur-[100px]" />
          <div className="absolute bottom-[20%] right-[20%] w-64 h-64 bg-[#00E5FF] rounded-full blur-[100px]" />
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="z-10 w-full max-w-md flex flex-col items-center text-center space-y-8"
        >
          <div className="w-20 h-20 bg-neutral-900 rounded-3xl border border-neutral-800 flex items-center justify-center shadow-[0_0_30px_rgba(182,109,255,0.2)]">
            <Zap className="w-10 h-10 text-[#00E5FF]" />
          </div>
          
          <div className="space-y-3">
            <h1 className="text-3xl font-black tracking-tight">FITGENIE</h1>
            <p className="text-neutral-400 font-bold uppercase tracking-widest text-xs">AI-Powered Fitness Agent</p>
          </div>
          
          <div className="w-full pt-8">
            <button
              onClick={handleGoogleSignIn}
              className="w-full flex items-center justify-center gap-4 bg-white text-black py-4 rounded-xl font-bold transition-all hover:bg-neutral-200 active:scale-95"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                <path d="M1 1h22v22H1z" fill="none"/>
              </svg>
              Continue with Google
            </button>
          </div>
        </motion.div>
      </div>
    );
  }
`;

code = code.replace(
  '  return (',
  step0 + '\n\n  return ('
);

fs.writeFileSync('src/components/Onboarding.tsx', code);
