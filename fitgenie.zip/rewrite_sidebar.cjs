const fs = require('fs');
const file = 'src/components/SidebarSections.tsx';
let code = fs.readFileSync(file, 'utf8');

// The original file is quite long and we only need to rewrite specific sections: CalorieCalculator, GoalsSection, NotificationsSection.
// We'll replace the entire CalorieCalculator component block.
const calCalcRegex = /export function CalorieCalculator.*?\}\n\n\/\//s;
let newCode = code;

const newCalCalc = `export function CalorieCalculator() {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("male");
  const [activity, setActivity] = useState("1.2");
  const [results, setResults] = useState<{ maint: number; cut: number; bulk: number } | null>(null);

  const calculateCal = () => {
    playSound("click");
    if (!weight || !height || !age) return;
    const w = parseFloat(weight);
    const h = parseFloat(height);
    const a = parseFloat(age);
    
    let bmr = 0;
    if (gender === "male") {
      bmr = 10 * w + 6.25 * h - 5 * a + 5;
    } else {
      bmr = 10 * w + 6.25 * h - 5 * a - 161;
    }
    
    const maint = Math.round(bmr * parseFloat(activity));
    setResults({
      maint,
      cut: maint - 500,
      bulk: maint + 300,
    });
  };

  return (
    <div className="bg-[#050B1A] border border-[#14F1E1]/20 p-6 md:p-8 rounded-[2rem] text-left max-w-2xl mx-auto shadow-[0_0_40px_rgba(20,241,225,0.05)] relative select-none">
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#14F1E1]/5 rounded-full blur-[80px] pointer-events-none" />
      
      <div className="relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#14F1E1]/10 border border-[#14F1E1]/30 rounded-full mb-3">
          <Calculator className="w-3.5 h-3.5 text-[#14F1E1]" />
          <span className="text-[9px] font-black uppercase tracking-[0.2em] text-[#14F1E1]">Nutritional Algorithms</span>
        </div>
        
        <h2 className="text-2xl font-black text-white uppercase tracking-tight flex items-center gap-2">
          Macro <span className="text-[#14F1E1]">Calculator</span>
        </h2>
        <p className="text-neutral-400 text-xs font-medium mt-1 mb-6">
          Precision metabolic targeting based on advanced biometric telemetry.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase text-neutral-400 tracking-widest ml-1">Gender Profiling</label>
            <select 
              value={gender} 
              onChange={(e) => setGender(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-sm font-bold text-white focus:outline-none focus:border-[#14F1E1]/50 appearance-none focus:ring-1 focus:ring-[#14F1E1]/50"
            >
              <option value="male">Male Physiology</option>
              <option value="female">Female Physiology</option>
            </select>
          </div>
          
          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase text-neutral-400 tracking-widest ml-1">Kinetic Load</label>
            <select 
              value={activity} 
              onChange={(e) => setActivity(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-sm font-bold text-white focus:outline-none focus:border-[#14F1E1]/50 appearance-none focus:ring-1 focus:ring-[#14F1E1]/50"
            >
              <option value="1.2">Sedentary (No Training)</option>
              <option value="1.375">Light (1-3 days/wk)</option>
              <option value="1.55">Moderate (3-5 days/wk)</option>
              <option value="1.725">Active (6-7 days/wk)</option>
              <option value="1.9">Elite (2x Daily)</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase text-neutral-400 tracking-widest ml-1">Mass (KG)</label>
            <input 
              type="number" placeholder="0.0" 
              value={weight} onChange={(e) => setWeight(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-sm font-bold text-white placeholder:text-neutral-600 focus:outline-none focus:border-[#14F1E1]/50 focus:ring-1 focus:ring-[#14F1E1]/50" 
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase text-neutral-400 tracking-widest ml-1">Vertical (CM)</label>
            <input 
              type="number" placeholder="0.0" 
              value={height} onChange={(e) => setHeight(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-sm font-bold text-white placeholder:text-neutral-600 focus:outline-none focus:border-[#14F1E1]/50 focus:ring-1 focus:ring-[#14F1E1]/50" 
            />
          </div>
          <div className="space-y-1.5 md:col-span-2">
            <label className="text-[10px] font-black uppercase text-neutral-400 tracking-widest ml-1">Chronology (Years)</label>
            <input 
              type="number" placeholder="Age" 
              value={age} onChange={(e) => setAge(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-sm font-bold text-white placeholder:text-neutral-600 focus:outline-none focus:border-[#14F1E1]/50 focus:ring-1 focus:ring-[#14F1E1]/50" 
            />
          </div>
        </div>

        <button 
          onClick={calculateCal}
          className="w-full py-4 mt-6 bg-gradient-to-r from-[#14F1E1] to-[#1DE9B6] text-black rounded-xl text-sm font-black uppercase tracking-[0.2em] hover:scale-[1.02] active:scale-95 transition-all shadow-[0_0_20px_rgba(20,241,225,0.4)] flex items-center justify-center gap-2"
        >
          <Activity className="w-5 h-5" /> Calculate Telemetry
        </button>

        {results && (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 text-center flex flex-col items-center justify-center shadow-inner relative overflow-hidden group">
              <div className="absolute inset-0 bg-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              <TrendingDown className="w-6 h-6 text-blue-400 mb-2 relative z-10" />
              <span className="text-[10px] font-black text-neutral-400 uppercase tracking-widest mb-1 relative z-10">Cutting Protocol</span>
              <span className="text-2xl font-black text-blue-400 relative z-10">{results.cut} <span className="text-[10px] text-blue-400/50">KCAL</span></span>
            </div>
            
            <div className="bg-[#14F1E1]/10 border border-[#14F1E1]/30 rounded-2xl p-5 text-center flex flex-col items-center justify-center shadow-[0_0_15px_rgba(20,241,225,0.1)] relative overflow-hidden transform md:scale-105 z-10">
              <div className="absolute top-0 right-0 w-16 h-16 bg-[#14F1E1]/20 rounded-full blur-xl -mr-8 -mt-8" />
              <Activity className="w-6 h-6 text-[#14F1E1] mb-2 relative z-10" />
              <span className="text-[10px] font-black text-[#14F1E1] uppercase tracking-widest mb-1 relative z-10">Maintenance</span>
              <span className="text-3xl font-black text-white relative z-10">{results.maint} <span className="text-[10px] text-[#14F1E1]/50">KCAL</span></span>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 text-center flex flex-col items-center justify-center shadow-inner relative overflow-hidden group">
              <div className="absolute inset-0 bg-rose-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              <TrendingUp className="w-6 h-6 text-rose-400 mb-2 relative z-10" />
              <span className="text-[10px] font-black text-neutral-400 uppercase tracking-widest mb-1 relative z-10">Bulking Protocol</span>
              <span className="text-2xl font-black text-rose-400 relative z-10">{results.bulk} <span className="text-[10px] text-rose-400/50">KCAL</span></span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

//`;

newCode = newCode.replace(calCalcRegex, newCalCalc);

const goalsRegex = /export function GoalsSection.*?\}\n\n\/\//s;
const newGoals = `export function GoalsSection() {
  const [goals, setGoals] = useState([
    { id: 1, title: "100 Push-ups continuous", completed: false },
    { id: 2, title: "Sub 20-min 5K Run", completed: true },
    { id: 3, title: "Deadlift 2x Bodyweight", completed: false },
  ]);
  const [newGoal, setNewGoal] = useState("");

  const addGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoal.trim()) return;
    playSound("click");
    setGoals([{ id: Date.now(), title: newGoal, completed: false }, ...goals]);
    setNewGoal("");
  };

  const toggleGoal = (id: number) => {
    playSound("toggle");
    setGoals(goals.map(g => g.id === id ? { ...g, completed: !g.completed } : g));
  };

  return (
    <div className="bg-[#050B1A] border border-[#B66DFF]/20 p-6 md:p-8 rounded-[2rem] text-left max-w-2xl mx-auto shadow-[0_0_40px_rgba(182,109,255,0.05)] relative select-none">
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#B66DFF]/5 rounded-full blur-[80px] pointer-events-none" />
      
      <div className="relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#B66DFF]/10 border border-[#B66DFF]/30 rounded-full mb-3">
          <Target className="w-3.5 h-3.5 text-[#B66DFF]" />
          <span className="text-[9px] font-black uppercase tracking-[0.2em] text-[#B66DFF]">Strategic Objectives</span>
        </div>
        
        <h2 className="text-2xl font-black text-white uppercase tracking-tight flex items-center gap-2">
          Set <span className="text-[#B66DFF]">Targets & Goals</span>
        </h2>
        <p className="text-neutral-400 text-xs font-medium mt-1 mb-8">
          Define your ultimate athletic milestones. Lock them in and execute.
        </p>

        <form onSubmit={addGoal} className="relative mb-8">
          <input
            type="text"
            value={newGoal}
            onChange={(e) => setNewGoal(e.target.value)}
            placeholder="Define a new operational objective..."
            className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-5 pr-14 text-sm font-medium text-white placeholder:text-neutral-600 focus:outline-none focus:border-[#B66DFF]/50 focus:ring-1 focus:ring-[#B66DFF]/50 transition-all"
          />
          <button 
            type="submit"
            disabled={!newGoal.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-[#B66DFF] text-black rounded-xl hover:bg-[#C285FF] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Plus className="w-5 h-5" />
          </button>
        </form>

        <div className="space-y-3">
          {goals.map((goal) => (
            <div 
              key={goal.id}
              onClick={() => toggleGoal(goal.id)}
              className={\`group flex items-center gap-4 p-4 rounded-2xl border cursor-pointer transition-all \${
                goal.completed 
                  ? "bg-emerald-500/10 border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]" 
                  : "bg-white/5 border-white/10 hover:border-[#B66DFF]/40 hover:bg-white/10"
              }\`}
            >
              <div className={\`w-6 h-6 shrink-0 rounded-lg flex items-center justify-center transition-all \${
                goal.completed ? "bg-emerald-500 text-black shadow-[0_0_10px_rgba(16,185,129,0.5)]" : "bg-black/50 border border-white/20 text-transparent"
              }\`}>
                <Check className="w-4 h-4 stroke-[3]" />
              </div>
              <span className={\`text-sm font-bold tracking-wide transition-all \${goal.completed ? "text-emerald-400 line-through opacity-70" : "text-white group-hover:text-[#B66DFF]"}\`}>
                {goal.title}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

//`;

newCode = newCode.replace(goalsRegex, newGoals);

const alertsRegex = /export function NotificationsSection.*?\}\n\n\/\//s;
const newAlerts = `export function NotificationsSection() {
  const [alerts, setAlerts] = useState({
    workoutReminders: true,
    streakWarnings: true,
    socialUpdates: false,
    promotions: false
  });

  const toggle = (key: keyof typeof alerts) => {
    playSound("toggle");
    setAlerts(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="bg-[#050B1A] border border-[#14F1E1]/20 p-6 md:p-8 rounded-[2rem] text-left max-w-2xl mx-auto shadow-[0_0_40px_rgba(20,241,225,0.05)] relative select-none">
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#14F1E1]/5 rounded-full blur-[80px] pointer-events-none" />
      
      <div className="relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#14F1E1]/10 border border-[#14F1E1]/30 rounded-full mb-3">
          <Bell className="w-3.5 h-3.5 text-[#14F1E1]" />
          <span className="text-[9px] font-black uppercase tracking-[0.2em] text-[#14F1E1]">Comms Hub</span>
        </div>
        
        <h2 className="text-2xl font-black text-white uppercase tracking-tight flex items-center gap-2">
          System <span className="text-[#14F1E1]">Alerts</span>
        </h2>
        <p className="text-neutral-400 text-xs font-medium mt-1 mb-8">
          Configure operational telemetry and push notifications.
        </p>

        <div className="space-y-4">
          <AlertToggle 
            title="Training Directives" 
            desc="Daily notifications reminding you of scheduled masterclasses."
            active={alerts.workoutReminders}
            onClick={() => toggle('workoutReminders')}
          />
          <AlertToggle 
            title="Streak Diagnostics" 
            desc="Critical alerts when your training consistency is at risk of resetting."
            active={alerts.streakWarnings}
            onClick={() => toggle('streakWarnings')}
          />
          <AlertToggle 
            title="Squad Telemetry" 
            desc="Updates when squad members achieve new PRs or challenge you."
            active={alerts.socialUpdates}
            onClick={() => toggle('socialUpdates')}
          />
          <AlertToggle 
            title="System Intel" 
            desc="News on upcoming app updates, new AI features, and events."
            active={alerts.promotions}
            onClick={() => toggle('promotions')}
          />
        </div>
      </div>
    </div>
  );
}

function AlertToggle({ title, desc, active, onClick }: { title: string, desc: string, active: boolean, onClick: () => void }) {
  return (
    <div 
      onClick={onClick}
      className="flex items-center justify-between p-5 bg-white/5 border border-white/10 rounded-2xl cursor-pointer hover:bg-white/10 transition-all group"
    >
      <div className="pr-4">
        <h3 className="text-sm font-bold text-white mb-1 tracking-wide">{title}</h3>
        <p className="text-xs text-neutral-500 font-medium leading-relaxed">{desc}</p>
      </div>
      <div className={\`w-12 h-6 shrink-0 rounded-full relative transition-all duration-300 \${active ? "bg-[#14F1E1] shadow-[0_0_15px_rgba(20,241,225,0.4)]" : "bg-black/50 border border-white/20"}\`}>
        <div className={\`absolute top-1 left-1 w-4 h-4 rounded-full transition-all duration-300 \${active ? "translate-x-6 bg-black" : "bg-neutral-500"}\`} />
      </div>
    </div>
  );
}

//`;

newCode = newCode.replace(alertsRegex, newAlerts);

fs.writeFileSync(file, newCode);
console.log("Rewrote components in SidebarSections.tsx");
