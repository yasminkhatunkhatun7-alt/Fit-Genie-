const fs = require('fs');
let code = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

if (!code.includes('import { useChallengeValidation }')) {
  code = "import { useChallengeValidation } from '../hooks/useChallengeValidation';\n" + code;
  fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', code);
}
