const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

const oldDailyThresholds = `       // Unrealistic threshold check (e.g., 2500 reps of one exercise in a single day is impossible)
       if (updated.dailyLog.reps[exercise] > 2500) {
         updated.validationFailed = true;
         setShowCheatWarning(true);
       }
       
       const totalDailyAll = Object.values(updated.dailyLog.reps).reduce((a, b) => a + b, 0);
       // Unrealistic total daily activity threshold (e.g., 5000+ total reps in one day)
       if (totalDailyAll > 5000) {
         updated.validationFailed = true;
         setShowCheatWarning(true);
       }`;

const newDailyThresholds = `       // Unrealistic threshold check
       if (updated.dailyLog.reps[exercise] > 2500 || Object.values(updated.dailyLog.reps).reduce((a, b) => a + b, 0) > 5000) {
           updated.validationFailed = true;
           // We will handle the warning outside the state updater if needed,
           // but since bypassVerification handles legit users, we just mark it.
       }`;

content = content.replace(oldDailyThresholds, newDailyThresholds);
fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', content);
