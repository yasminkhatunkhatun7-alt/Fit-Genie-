const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');
code = code.replace(/\{\n\s*\{\s*id: "pushup"/, '{\n      id: "pushup"');
fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
