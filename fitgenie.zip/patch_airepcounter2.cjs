const fs = require('fs');
let content = fs.readFileSync('src/components/AiRepCounter.tsx', 'utf8');
content = content.replace(/await addDoc\(collection\(db, "workoutLogs"\), \{[\s\S]*?\}\);/g, '/* Local logic only */');
content = content.replace(/import { addDoc, collection } from "firebase\/firestore";/g, '');
content = content.replace(/import { db } from "\.\.\/firebase";/g, '');
fs.writeFileSync('src/components/AiRepCounter.tsx', content);
