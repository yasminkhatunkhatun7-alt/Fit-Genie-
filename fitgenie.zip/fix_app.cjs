const fs = require('fs');

let content = fs.readFileSync('src/App.tsx', 'utf-8');

// Update InfoPages imports
content = content.replace(
  /import \{ AboutSection, PrivacyPolicySection, ContactUsSection, TermsOfServiceSection \} from "\.\/components\/InfoPages";/,
  'import { AboutSection, PrivacyPolicySection, ContactUsSection, TermsOfServiceSection, SupportFeedbackSection } from "./components/InfoPages";'
);

// Remove HelpSupportSection import from SidebarSections
content = content.replace(
  /HelpSupportSection,\s*/g,
  ''
);

// Update rendering section
content = content.replace(
  /\{view === "support" && <HelpSupportSection \/>\}/,
  '{view === "support" && <SupportFeedbackSection onNavigateToView={navigateToView} />}'
);
content = content.replace(
  /\{view === "about" && <AboutSection \/>\}/,
  '{view === "about" && <AboutSection onNavigateToView={navigateToView} />}'
);
content = content.replace(
  /\{view === "contact" && <ContactUsSection \/>\}/,
  '{view === "contact" && <ContactUsSection onNavigateToView={navigateToView} />}'
);
content = content.replace(
  /\{view === "terms" && <TermsOfServiceSection \/>\}/,
  '{view === "terms" && <TermsOfServiceSection onNavigateToView={navigateToView} />}'
);
content = content.replace(
  /\{view === "privacy" && <PrivacyPolicySection \/>\}/,
  '{view === "privacy" && <PrivacyPolicySection onNavigateToView={navigateToView} />}'
);

fs.writeFileSync('src/App.tsx', content);
console.log("Updated App.tsx");
