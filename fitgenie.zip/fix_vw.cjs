const fs = require('fs');

function replaceVw(filePath) {
  let content = fs.readFileSync(filePath, 'utf8');
  content = content.replace(/Math\.random\(\) \* 100\}vw/g, 'Math.random() * 95}%');
  fs.writeFileSync(filePath, content);
}

replaceVw('src/components/CustomChallengeDetailScreen.tsx');
replaceVw('src/components/SpeedChallengeScreen.tsx');
replaceVw('src/components/StrengthChallengeScreen.tsx');
replaceVw('src/components/WeeklyChallengeScreen.tsx');
replaceVw('src/components/DailyChallengeDetailScreen.tsx');
