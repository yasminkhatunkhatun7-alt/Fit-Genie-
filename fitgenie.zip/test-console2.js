import puppeteer from 'puppeteer';

(async () => {
  try {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    page.on('response', response => {
      if (!response.ok()) {
        console.log('404 URL:', response.url());
      }
    });
    await page.goto('http://localhost:3000', { waitUntil: 'networkidle2' });
    await browser.close();
  } catch (e) {
    console.error(e);
  }
})();
