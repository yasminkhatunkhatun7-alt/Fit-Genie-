const fs = require('fs');

function fix(file) {
  let code = fs.readFileSync(file, 'utf8');
  const lucideRegex = /import\s+\{([^}]+)\}\s+from\s+"lucide-react";/g;
  
  let match;
  let allImports = new Set();
  
  while ((match = lucideRegex.exec(code)) !== null) {
    const names = match[1].split(',').map(n => n.trim()).filter(n => n);
    names.forEach(n => allImports.add(n));
  }
  
  // replace all lucide imports with empty strings
  code = code.replace(lucideRegex, '');
  
  const uniqueImports = Array.from(allImports).join(', ');
  code = `import { ${uniqueImports} } from "lucide-react";\n` + code;
  
  fs.writeFileSync(file, code);
}

fix('src/components/NutritionLog.tsx');
fix('src/components/SidebarSections.tsx');
console.log("Fixed dupes");
