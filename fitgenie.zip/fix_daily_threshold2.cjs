const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

const regex = /       \/\/ Unrealistic threshold check\n       if \(updated\.dailyLog\.reps\[exercise\] > 2500 \|\| Object\.values\(updated\.dailyLog\.reps\)\.reduce\(\(a, b\) => a \+ b, 0\) > 5000\) \{\n           updated\.validationFailed = true;\n           \/\/ We will handle the warning outside the state updater if needed,\n           \/\/ but since bypassVerification handles legit users, we just mark it\.\n       \}/;

const replacement = `       // Unrealistic threshold check
       if (!bypassVerification && (updated.dailyLog.reps[exercise] > 2500 || Object.values(updated.dailyLog.reps).reduce((a, b) => a + b, 0) > 5000)) {
           updated.validationFailed = true;
       }`;

content = content.replace(regex, replacement);
fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', content);
