const fs = require('fs');
let code = fs.readFileSync('src/components/AiRepCounter.tsx', 'utf-8');

// 1. Add firebase imports
const importsMatch = `import { useAuth } from "../context/AuthContext";`;
const importsNew = `import { useAuth } from "../context/AuthContext";
import { db } from "../lib/firebase";
import { collection, addDoc } from "firebase/firestore";`;
if (!code.includes('import { db }')) {
  code = code.replace(importsMatch, importsNew);
}

// 2. Add challengeTarget to Props
const propsMatch = `  initialExercise?: "Pushups" | "Squats";
  onClose: () => void;
  onComplete?: (reps: number) => void;
}`;
const propsNew = `  initialExercise?: "Pushups" | "Squats";
  onClose: () => void;
  onComplete?: (reps: number) => void;
  challengeTarget?: { userId: string; userName: string; score: number };
}`;
if (!code.includes('challengeTarget?: {')) {
  code = code.replace(propsMatch, propsNew);
}

// 3. Update component signature & state
const sigMatch = `export function AiRepCounter({ initialExercise = "Pushups", onClose, onComplete }: AiRepCounterProps) {`;
const sigNew = `export function AiRepCounter({ initialExercise = "Pushups", onClose, onComplete, challengeTarget }: AiRepCounterProps) {`;
if (!code.includes('challengeTarget }: AiRepCounterProps')) {
  code = code.replace(sigMatch, sigNew);
}

const stateMatch = `  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<"free" | "test">("free");`;
const stateNew = `  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<"free" | "test">(challengeTarget ? "test" : "free");`;
code = code.replace(stateMatch, stateNew);

// 4. Disable toggle if challengeTarget
const toggleMatch = `<div className="flex bg-white/5 rounded-xl p-1 mb-4">
            <button onClick={() => { setMode("free");`;
const toggleNew = `{!challengeTarget && (
          <div className="flex bg-white/5 rounded-xl p-1 mb-4">
            <button onClick={() => { setMode("free"); setTestTimeLeft(null); setIsActive(false); }} className={\`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all \${mode === "free" ? "bg-[#14F1E1] text-[#050B1A]" : "text-white hover:text-[#14F1E1]"}\`}>Free Flow</button>
            <button onClick={() => { setMode("test"); setTestTimeLeft(60); setIsActive(false); setReps(0); repStateRef.current.reps = 0; }} className={\`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all \${mode === "test" ? "bg-[#B66DFF] text-white" : "text-white hover:text-[#B66DFF]"}\`}>1-Min Test</button>
          </div>
          )}`;
if (!code.includes('{!challengeTarget && (')) {
  code = code.replace(toggleMatch, toggleNew);
}

// 5. Update UI text when ready or finished
const textMatch = `{mode === "test" && testTimeLeft === 0 ? (
                <>
                  <p className="text-white font-black text-2xl mb-2 text-[#B66DFF]">TEST COMPLETE</p>
                  <p className="text-white font-bold text-lg">You scored {reps} {exercise}!</p>
                </>
              ) : (
                <p className="text-white font-bold text-lg">Ready to track {exercise}</p>
              )}`;
              
const textNew = `{mode === "test" && testTimeLeft === 0 ? (
                <>
                  {challengeTarget ? (
                     reps > challengeTarget.score ? (
                        <>
                           <p className="text-white font-black text-2xl mb-2 text-[#14F1E1] animate-bounce">🔥 RECORD BEATEN! 🔥</p>
                           <p className="text-white font-bold text-lg">You scored {reps}, beating {challengeTarget.userName}'s {challengeTarget.score}!</p>
                        </>
                     ) : (
                        <>
                           <p className="text-white font-black text-2xl mb-2 text-[#FF5A5F]">SO CLOSE!</p>
                           <p className="text-white font-bold text-lg">{challengeTarget.userName} scored {challengeTarget.score}, you got {reps}. Try again?</p>
                        </>
                     )
                  ) : (
                     <>
                        <p className="text-white font-black text-2xl mb-2 text-[#B66DFF]">TEST COMPLETE</p>
                        <p className="text-white font-bold text-lg">You scored {reps} {exercise}!</p>
                     </>
                  )}
                </>
              ) : (
                <>
                  {challengeTarget && mode === "test" && testTimeLeft === null ? (
                    <div className="mb-4">
                      <p className="text-[#14F1E1] font-black text-2xl mb-1 uppercase tracking-widest">GHOST CHALLENGE</p>
                      <p className="text-white font-bold text-md bg-[#14F1E1]/20 px-4 py-2 rounded-xl border border-[#14F1E1]/30">Beat {challengeTarget.userName}'s {challengeTarget.score} {exercise}!</p>
                    </div>
                  ) : (
                    <p className="text-white font-bold text-lg">Ready to track {exercise}</p>
                  )}
                </>
              )}`;
code = code.replace(textMatch, textNew);


// 6. Update handleSaveToLog to write to notifications and activityFeed
const saveMatch = `    if (updateUserProfileFields && profile) {
      const updates: any = {};`;

const saveNew = `    if (updateUserProfileFields && profile) {
      const updates: any = {};
      
      if (challengeTarget && mode === "test" && reps > challengeTarget.score) {
         try {
           // Notify beaten user
           await addDoc(collection(db, "notifications"), {
             toUserId: challengeTarget.userId,
             fromUserId: profile.uid || 'local_user',
             fromUserName: profile.username || 'Someone',
             type: "record_beaten",
             exerciseType: exercise.toLowerCase(),
             oldScore: challengeTarget.score,
             newScore: reps,
             timestamp: Date.now()
           });
           // Activity feed
           await addDoc(collection(db, "activityFeed"), {
             userId: profile.uid || 'local_user',
             userName: profile.username || 'Someone',
             userAvatar: profile.photoURL || '',
             userAvatarBg: profile.avatarBg || 'bg-blue-500',
             type: 'challenge_win',
             title: \`Beat \${challengeTarget.userName}'s \${exercise} record!\`,
             description: \`Scored \${reps} reps (vs \${challengeTarget.score}) in the 1-Min Test.\`,
             timestamp: Date.now(),
             likes: 0
           });
         } catch (e) {
           console.error("Failed to post notifications/feed", e);
         }
      }
      `;
if (!code.includes('await addDoc(collection(db, "notifications")')) {
  code = code.replace(saveMatch, saveNew);
}


fs.writeFileSync('src/components/AiRepCounter.tsx', code);
console.log("Patched AiRepCounter for Challenge Ghost Mode");
