const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf-8');

// 1. Add fields to UserProfile interface
const userProfileEndMatch = "  consecutiveHonestDays?: number;";
const userProfileNew = `  consecutiveHonestDays?: number;
  totalSquats?: number;
  bestSquat1Min?: number;
  totalPushups?: number;
  bestPushup1Min?: number;`;

if (!code.includes('totalSquats?: number;')) {
  code = code.replace(userProfileEndMatch, userProfileNew);
}

// 2. Update saveProfile to sync the new fields
const saveProfileSyncMatch = "avatarBg: avatarBg,";
const saveProfileSyncNew = `avatarBg: avatarBg,
          totalSquats: updatedProfile.totalSquats || 0,
          bestSquat1Min: updatedProfile.bestSquat1Min || 0,
          totalPushups: updatedProfile.totalPushups || 0,
          bestPushup1Min: updatedProfile.bestPushup1Min || 0,`;

if (!code.includes('totalSquats: updatedProfile.totalSquats || 0,')) {
  code = code.replace(saveProfileSyncMatch, saveProfileSyncNew);
}

fs.writeFileSync('src/context/AuthContext.tsx', code);
console.log("Patched AuthContext.tsx for stats");
