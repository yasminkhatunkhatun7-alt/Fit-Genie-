const fs = require('fs');

const file = 'src/components/MartialArts.tsx';
let code = fs.readFileSync(file, 'utf-8');

const returnIndex = code.indexOf('  return (\n    <div className="py-6');
if (returnIndex === -1) {
  console.log("Could not find return statement");
  process.exit(1);
}

const beforeReturn = code.substring(0, returnIndex);

const newRender = `  return (
    <div className="py-8 px-4 md:px-8 max-w-[1400px] mx-auto space-y-10 select-none text-white font-sans" id="martial-arts-module">
      
      {/* 1) HERO SECTION - Elite Dojo Banner */}
      <div className="relative rounded-3xl bg-gradient-to-br from-[#050B1A] to-[#0A1020] border border-[#14F1E1]/20 p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-8 overflow-hidden shadow-[0_0_40px_rgba(20,241,225,0.05)]">
        {/* Abstract Glow Effects */}
        <div className="absolute -top-20 -left-20 w-64 h-64 bg-[#14F1E1]/10 rounded-full blur-[80px] pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-[#B66DFF]/10 rounded-full blur-[80px] pointer-events-none" />

        <div className="space-y-5 text-center md:text-left relative z-10 flex-1">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#14F1E1]/10 border border-[#14F1E1]/30 rounded-full">
            <Swords className="w-4 h-4 text-[#14F1E1]" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#14F1E1]">Elite Training Ground</span>
          </div>
          
          <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter text-white leading-none drop-shadow-md">
            Martial <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#14F1E1] to-[#4DA8FF]">Arts</span>
          </h2>
          
          <p className="text-sm md:text-base text-neutral-400 font-medium leading-relaxed max-w-2xl">
            Welcome to the Fit Genie Dojo. Master traditional styles, standup sparring strikes, and heavy grappling leverage. Each lesson is stacked with safety tips and dynamic video coaching.
          </p>

          {/* Quick Stats Grid */}
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 pt-2">
            <div className="bg-white/5 border border-white/10 rounded-2xl px-5 py-3 backdrop-blur-sm shadow-inner flex items-center gap-4">
              <div className="p-2 bg-[#14F1E1]/20 rounded-xl">
                <Target className="w-5 h-5 text-[#14F1E1]" />
              </div>
              <div className="text-left">
                <span className="block text-[9px] font-bold text-neutral-500 uppercase tracking-widest">Completed</span>
                <span className="text-lg font-black text-white">{completedCount} / {totalCount}</span>
              </div>
            </div>
            
            <div className="bg-white/5 border border-white/10 rounded-2xl px-5 py-3 backdrop-blur-sm shadow-inner flex items-center gap-4">
              <div className="p-2 bg-orange-500/20 rounded-xl relative">
                <Flame className="w-5 h-5 text-orange-500 animate-pulse" />
              </div>
              <div className="text-left">
                <span className="block text-[9px] font-bold text-neutral-500 uppercase tracking-widest">Active Streak</span>
                <span className="text-lg font-black text-white">{progress.streak} Days</span>
              </div>
            </div>
          </div>
        </div>

        {/* Big Visual Progress Dial Gauge */}
        <div className="relative w-40 h-40 shrink-0 flex items-center justify-center bg-black/40 border border-white/10 rounded-full backdrop-blur-md shadow-[0_0_30px_rgba(20,241,225,0.15)] z-10" id="martial-arts-gauge">
          <div className="absolute inset-2.5 rounded-full border border-white/5 bg-[#050B1A] shadow-inner flex flex-col items-center justify-center">
            <span className="text-[9px] font-black text-neutral-500 uppercase tracking-widest">Dojo Path</span>
            <span className="text-3xl font-black text-white tracking-tighter mt-1">{finalPercent}%</span>
          </div>

          <svg className="absolute inset-0 w-full h-full transform -rotate-90 drop-shadow-[0_0_10px_rgba(20,241,225,0.5)]">
            <circle cx="80" cy="80" r="74" stroke="rgba(255,255,255,0.05)" strokeWidth="6" fill="transparent" />
            <circle
              cx="80" cy="80" r="74"
              stroke="#14F1E1" strokeWidth="6" fill="transparent"
              strokeDasharray={465}
              strokeDashoffset={465 - (465 * finalPercent) / 100}
              strokeLinecap="round"
              className="transition-all duration-1000 ease-out"
            />
          </svg>
        </div>
      </div>

      {/* Grid: Left - Lessons Library, Right - Stats and Badges */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* LEFT COLUMN: LESSONS LIBRARY (SPAN 2) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Glassmorphic Filters & Search Row */}
          <div className="bg-white/5 border border-white/10 rounded-3xl p-5 backdrop-blur-xl shadow-xl space-y-5">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-grow">
                <input
                  type="text"
                  placeholder="Search techniques, muscles or tips..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-2xl pl-11 pr-4 py-3.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-[#14F1E1]/50 transition-all focus:ring-1 focus:ring-[#14F1E1]/50 font-medium"
                />
                <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>

              <div className="flex gap-2 shrink-0 bg-black/40 p-1.5 border border-white/10 rounded-2xl">
                {["All", "Beginner", "Intermediate", "Advanced"].map((lv) => (
                  <button
                    key={lv}
                    onClick={() => { playSound("click"); setSelectedLevel(lv); }}
                    className={\`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all \${
                      selectedLevel === lv
                        ? "bg-[#14F1E1] text-[#050B1A] shadow-[0_0_15px_rgba(20,241,225,0.4)]"
                        : "text-neutral-400 hover:text-white hover:bg-white/5"
                    }\`}
                  >
                    {lv}
                  </button>
                ))}
              </div>
            </div>

            {/* Premium Category Tabs */}
            <div className="space-y-2">
              <span className="block text-[9px] font-black text-neutral-500 uppercase tracking-[0.2em] ml-1">
                Combat Disciplines
              </span>
              <div className="flex gap-3 overflow-x-auto pb-3 scrollbar-none snap-x" id="combat-style-scroller">
                {categoriesList.map((cat) => {
                  const comp = getCompletedCountForCat(cat);
                  const tot = getTotalCountForCat(cat);
                  const isSelected = selectedCategory === cat;
                  
                  return (
                    <button
                      key={cat}
                      onClick={() => { playSound("click"); setSelectedCategory(cat); }}
                      className={\`snap-start shrink-0 px-5 py-3 rounded-2xl border transition-all flex items-center gap-2 \${
                        isSelected
                          ? "bg-[#14F1E1]/10 border-[#14F1E1]/50 text-[#14F1E1] shadow-[0_0_20px_rgba(20,241,225,0.1)]"
                          : "bg-black/20 border-white/5 text-neutral-400 hover:bg-white/5 hover:text-white hover:border-white/10"
                      }\`}
                    >
                      <Sparkles className={\`w-3.5 h-3.5 \${isSelected ? 'text-[#14F1E1]' : 'opacity-50'}\`} />
                      <span className="text-[11px] font-black uppercase tracking-widest">{cat}</span>
                      {cat !== "All" && (
                        <span className={\`ml-2 text-[9px] px-2 py-0.5 rounded-lg font-bold \${isSelected ? 'bg-[#14F1E1]/20 text-[#14F1E1]' : 'bg-white/10 text-neutral-300'}\`}>
                          {comp}/{tot}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Video Lesson Cards Stack */}
          <div className="flex flex-col gap-5">
            <h3 className="text-[11px] font-black uppercase text-neutral-400 tracking-[0.2em] flex items-center gap-2 ml-1">
              <BookOpen className="w-4 h-4 text-[#14F1E1]" /> Training Library <span className="text-neutral-600">({filteredLessons.length} Modules)</span>
            </h3>

            <AnimatePresence mode="popLayout">
              {filteredLessons.length === 0 ? (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-16 text-center border border-white/5 rounded-3xl bg-white/5 backdrop-blur-sm">
                  <Trophy className="w-12 h-12 text-neutral-600 mx-auto mb-4" />
                  <p className="text-sm text-neutral-300 font-bold mb-1">No techniques found</p>
                  <p className="text-xs text-neutral-500">Try adjusting your filters or search terms.</p>
                </motion.div>
              ) : (
                filteredLessons.map((lesson) => {
                  const isCompleted = progress.completed[lesson.id];
                  const customVideoUrl = videoUrls[lesson.id] || DEFAULT_MARTIAL_VIDEO_URLS[lesson.id] || "";
                  const finalVideoId = getYouTubeId(customVideoUrl);
                  const thumbnailUrl = finalVideoId ? \`https://img.youtube.com/vi/\${finalVideoId}/maxresdefault.jpg\` : null;

                  return (
                    <motion.div
                      key={lesson.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.4, type: "spring", bounce: 0.3 }}
                      className={\`relative overflow-hidden rounded-3xl cursor-pointer group transition-all duration-300 \${
                        isCompleted
                          ? "bg-gradient-to-r from-emerald-900/20 to-[#050B1A] border border-emerald-500/20 shadow-[0_0_20px_rgba(16,185,129,0.05)]"
                          : "bg-gradient-to-r from-[#0A1020] to-[#050B1A] border border-white/10 hover:border-[#14F1E1]/40 hover:shadow-[0_0_30px_rgba(20,241,225,0.1)]"
                      }\`}
                      onClick={() => { playSound("click"); setActiveVideoLesson(lesson); }}
                    >
                      {/* Inner Layout */}
                      <div className="flex flex-col sm:flex-row p-4 gap-5 items-center">
                        
                        {/* Thumbnail */}
                        <div className="relative w-full sm:w-40 aspect-video shrink-0 rounded-2xl overflow-hidden bg-black/50 border border-white/10 group-hover:border-[#14F1E1]/30 transition-colors">
                          {thumbnailUrl ? (
                            <>
                              <img src={thumbnailUrl} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500" alt={lesson.name} referrerPolicy="no-referrer" />
                              <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-all" />
                            </>
                          ) : (
                            <div className="absolute inset-0 flex items-center justify-center text-3xl opacity-50">🥋</div>
                          )}
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-10 h-10 rounded-full bg-black/60 backdrop-blur-md border border-white/20 flex items-center justify-center group-hover:bg-[#14F1E1] group-hover:text-black group-hover:border-transparent transition-all shadow-lg transform group-hover:scale-110">
                              <Play className="w-4 h-4 ml-0.5 fill-current" />
                            </div>
                          </div>
                          {isCompleted && (
                            <div className="absolute top-2 left-2 bg-emerald-500 text-black px-2 py-0.5 rounded-md text-[8px] font-black uppercase tracking-widest shadow-md">
                              Completed
                            </div>
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex-grow space-y-3 w-full">
                          {/* Tags */}
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-[9px] font-black uppercase tracking-widest text-neutral-300">
                              {lesson.category}
                            </span>
                            <span className={\`px-2.5 py-1 rounded-lg border text-[9px] font-black uppercase tracking-widest flex items-center gap-1 \${
                              lesson.level === "Beginner" ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/20" :
                              lesson.level === "Intermediate" ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" :
                              "bg-red-500/10 text-red-400 border-red-500/20"
                            }\`}>
                              {lesson.level === "Beginner" ? "🔰 Novice" : lesson.level === "Intermediate" ? "⚔️ Warrior" : "🔥 Elite"}
                            </span>
                            <span className="ml-auto text-[10px] font-black text-[#14F1E1] bg-[#14F1E1]/10 px-2.5 py-1 rounded-lg border border-[#14F1E1]/20">
                              +{lesson.xpReward} XP
                            </span>
                          </div>

                          {/* Titles */}
                          <div>
                            <h4 className="text-lg font-black text-white leading-tight group-hover:text-[#14F1E1] transition-colors">{lesson.name}</h4>
                            <p className="text-xs text-neutral-400 mt-1 line-clamp-2 leading-relaxed">{lesson.description}</p>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="hidden sm:flex shrink-0 px-2">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              playSound("click");
                              setFavorites(prev => prev.includes(lesson.id) ? prev.filter(id => id !== lesson.id) : [...prev, lesson.id]);
                            }}
                            className={\`p-3 rounded-full border transition-all \${
                              favorites.includes(lesson.id) 
                                ? 'bg-rose-500/10 border-rose-500/30 text-rose-500' 
                                : 'bg-white/5 border-white/10 text-neutral-400 hover:text-white hover:bg-white/10'
                            }\`}
                          >
                            <Heart className={\`w-5 h-5 \${favorites.includes(lesson.id) ? 'fill-current' : ''}\`} />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  );
                })
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* RIGHT COLUMN: STATS, BADGES, ADMIN */}
        <div className="space-y-6">
          
          {/* STATS MODULE */}
          <div className="bg-gradient-to-b from-white/5 to-transparent border border-white/10 rounded-3xl p-6 backdrop-blur-md">
            <h3 className="text-[11px] font-black uppercase text-white tracking-[0.2em] flex items-center gap-2 pb-4 border-b border-white/10 mb-5">
              <Trophy className="w-4 h-4 text-[#B66DFF]" /> Dojo Achievements
            </h3>

            <div className="space-y-4">
              {ACHIEVEMENTS.map((ach) => (
                <div 
                  key={ach.id}
                  className={\`relative p-4 rounded-2xl border transition-all overflow-hidden \${
                    ach.unlocked 
                      ? "bg-[#B66DFF]/10 border-[#B66DFF]/30 shadow-[0_0_15px_rgba(182,109,255,0.05)]" 
                      : "bg-black/20 border-white/5 opacity-70"
                  }\`}
                >
                  {ach.unlocked && <div className="absolute top-0 right-0 w-16 h-16 bg-[#B66DFF]/20 rounded-full blur-xl -mr-8 -mt-8" />}
                  
                  <div className="flex items-start gap-4 relative z-10">
                    <div className={\`w-12 h-12 shrink-0 rounded-xl flex items-center justify-center text-2xl border \${
                      ach.unlocked ? "bg-[#B66DFF]/20 border-[#B66DFF]/40 text-[#B66DFF]" : "bg-white/5 border-white/10 text-neutral-600 grayscale"
                    }\`}>
                      {ach.icon}
                    </div>

                    <div className="flex-1 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className={\`text-xs font-black uppercase tracking-widest \${ach.unlocked ? 'text-white' : 'text-neutral-400'}\`}>{ach.title}</span>
                      </div>
                      <p className="text-[10px] text-neutral-400 leading-snug">{ach.desc}</p>
                      
                      <div className="pt-2 space-y-1.5">
                        <div className="h-1.5 w-full bg-black/50 rounded-full overflow-hidden">
                          <div 
                            className={\`h-full rounded-full transition-all duration-1000 \${ach.unlocked ? 'bg-gradient-to-r from-[#B66DFF] to-[#14F1E1]' : 'bg-neutral-600'}\`}
                            style={{ width: \`\${ach.progress}%\` }}
                          />
                        </div>
                        <div className="flex justify-end">
                          <span className="text-[8px] font-black uppercase text-neutral-500 tracking-widest">{ach.text}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ADMIN CONFIG PANEL */}
          <div className="bg-gradient-to-b from-[#050B1A] to-transparent border border-white/10 rounded-3xl p-6 backdrop-blur-md">
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
              <h3 className="text-[11px] font-black uppercase text-white tracking-[0.2em] flex items-center gap-2">
                <Settings className="w-4 h-4 text-[#14F1E1] animate-spin-slow" /> Dojo Admin Panel
              </h3>
              <button
                onClick={() => { playSound("click"); setIsAdminPanelOpen(!isAdminPanelOpen); }}
                className="px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-[9px] font-black uppercase tracking-widest text-[#14F1E1] transition-all"
              >
                {isAdminPanelOpen ? "Close" : "Open"}
              </button>
            </div>

            <AnimatePresence>
              {isAdminPanelOpen && (
                <motion.form 
                  initial={{ opacity: 0, height: 0 }} 
                  animate={{ opacity: 1, height: 'auto' }} 
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-5 overflow-hidden"
                  onSubmit={handleAdminSubmitUrl}
                >
                  <div className="p-4 bg-[#14F1E1]/5 border border-[#14F1E1]/20 rounded-2xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-16 h-16 bg-amber-500/10 rounded-full blur-xl" />
                    <span className="text-[9px] font-black text-amber-400 uppercase tracking-[0.2em] flex items-center gap-1 mb-1">
                      <ShieldCheck className="w-3 h-3 text-[#14F1E1]" /> Cloud Sync Active
                    </span>
                    <p className="text-[10px] text-neutral-400 leading-relaxed font-medium">Link or replace video URLs in real-time. Changes go live instantly for all trainees.</p>
                  </div>

                  <div className="space-y-2 text-left">
                    <label className="text-[9px] font-black text-neutral-500 uppercase tracking-widest">Select Target Lesson</label>
                    <select
                      value={adminLessonId}
                      onChange={(e) => setAdminLessonId(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-[#14F1E1] font-medium"
                    >
                      <option value="">-- Choose Lesson --</option>
                      {MARTIAL_LESSONS.map((l) => (
                        <option key={l.id} value={l.id}>[{l.category}] - {l.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2 text-left">
                    <label className="text-[9px] font-black text-neutral-500 uppercase tracking-widest">YouTube Video URL</label>
                    <input
                      type="text"
                      placeholder="https://youtu.be/..."
                      value={adminVideoUrl}
                      onChange={(e) => setAdminVideoUrl(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#14F1E1] font-mono"
                    />
                  </div>

                  {adminStatus && (
                    <div className={\`p-3 rounded-xl text-[10px] font-black uppercase tracking-widest text-center \${adminStatus.includes('Error') ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'}\`}>
                      {adminStatus}
                    </div>
                  )}

                  <button type="submit" disabled={isSavingAdmin} className="w-full py-3.5 bg-gradient-to-r from-[#14F1E1] to-[#4DA8FF] text-[#050B1A] rounded-xl text-[11px] font-black uppercase tracking-widest shadow-[0_0_15px_rgba(20,241,225,0.3)] hover:shadow-[0_0_25px_rgba(20,241,225,0.5)] transition-all flex items-center justify-center gap-2">
                    <Save className="w-4 h-4" /> {isSavingAdmin ? "Deploying..." : "Update Dojo Cloud"}
                  </button>
                </motion.form>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* THEATER MODE: Active Video Modal */}
      <AnimatePresence>
        {activeVideoLesson && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex flex-col items-center justify-center p-4 sm:p-6 md:p-8"
          >
            {/* Cinematic Background Blur */}
            <div className="absolute inset-0 bg-black/80 backdrop-blur-2xl" onClick={() => setActiveVideoLesson(null)} />
            
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="relative w-full max-w-6xl bg-[#050B1A] border border-[#14F1E1]/20 rounded-[2rem] shadow-[0_0_80px_rgba(20,241,225,0.15)] overflow-hidden flex flex-col max-h-[95vh]"
            >
              {/* Modal Header */}
              <div className="flex items-center justify-between p-6 border-b border-white/10 bg-white/5 relative z-10">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-[#14F1E1]/10 rounded-2xl border border-[#14F1E1]/20 hidden sm:block">
                    <Swords className="w-6 h-6 text-[#14F1E1]" />
                  </div>
                  <div>
                    <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-tight">{activeVideoLesson.name}</h2>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] bg-white/10 text-neutral-300 px-2 py-0.5 rounded uppercase tracking-widest font-black">{activeVideoLesson.category}</span>
                      <span className="text-[10px] text-[#14F1E1] uppercase tracking-widest font-bold">Level: {activeVideoLesson.level}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      playSound("click");
                      setFavorites(prev => favorites.includes(activeVideoLesson.id) ? prev.filter(id => id !== activeVideoLesson.id) : [...prev, activeVideoLesson.id]);
                    }}
                    className={\`p-3 rounded-full border transition-all \${
                      favorites.includes(activeVideoLesson.id) 
                        ? 'bg-rose-500/20 border-rose-500/50 text-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.3)]' 
                        : 'bg-black/40 border-white/10 text-neutral-400 hover:text-white hover:bg-white/10'
                    }\`}
                  >
                    <Heart className={\`w-5 h-5 \${favorites.includes(activeVideoLesson.id) ? 'fill-current' : ''}\`} />
                  </button>
                  <button
                    onClick={() => { playSound("click"); setActiveVideoLesson(null); }}
                    className="p-3 bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-400 hover:text-white rounded-full transition-all"
                  >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Modal Body */}
              <div className="flex-1 overflow-y-auto overflow-x-hidden p-6 md:p-8 scrollbar-none relative">
                <div className="absolute top-0 right-0 w-96 h-96 bg-[#14F1E1]/5 rounded-full blur-[100px] pointer-events-none" />
                
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  {/* Left Column: Video & Info */}
                  <div className="lg:col-span-8 space-y-8">
                    
                    {/* The Video Player */}
                    <div className="relative aspect-video rounded-3xl overflow-hidden border border-white/10 bg-black shadow-2xl group ring-1 ring-white/5">
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none z-10" />
                      {(() => {
                        const finalUrl = videoUrls[activeVideoLesson.id] || DEFAULT_MARTIAL_VIDEO_URLS[activeVideoLesson.id] || "";
                        const youtubeId = getYouTubeId(finalUrl);
                        if (youtubeId) {
                          return (
                            <iframe
                              src={\`https://www.youtube.com/embed/\${youtubeId}?autoplay=1&rel=0&modestbranding=1\`}
                              title={activeVideoLesson.name}
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                              allowFullScreen
                              className="absolute inset-0 w-full h-full border-0 relative z-0"
                            />
                          );
                        } else {
                          return (
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-neutral-900 z-0">
                              <Video className="w-16 h-16 text-[#14F1E1] animate-pulse mb-4" />
                              <h4 className="text-xl font-black uppercase tracking-widest text-white mb-2">Video Coming Soon</h4>
                              <p className="text-sm text-neutral-400 font-medium max-w-sm">Admins are uploading the masterclass materials.</p>
                            </div>
                          );
                        }
                      })()}
                    </div>

                    {/* Lesson Details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <span className="text-[10px] font-black text-[#14F1E1] uppercase tracking-[0.2em] flex items-center gap-2">
                            <BookOpen className="w-3 h-3" /> Synopsis
                          </span>
                          <p className="text-sm text-neutral-300 leading-relaxed">{activeVideoLesson.description}</p>
                        </div>
                        <div className="space-y-2">
                          <span className="text-[10px] font-black text-[#14F1E1] uppercase tracking-[0.2em] flex items-center gap-2">
                            <Target className="w-3 h-3" /> Core Values
                          </span>
                          <p className="text-sm text-neutral-300 leading-relaxed">{activeVideoLesson.benefits}</p>
                        </div>
                      </div>

                      <div className="p-5 bg-[#14F1E1]/5 border border-[#14F1E1]/20 rounded-3xl space-y-4">
                        <span className="text-[10px] font-black text-[#14F1E1] uppercase tracking-[0.2em] flex items-center gap-2">
                          <Sparkles className="w-4 h-4" /> Sensei Coaching Tips
                        </span>
                        <p className="text-[13px] text-white font-medium leading-relaxed italic border-l-2 border-[#14F1E1] pl-4 py-1">
                          "{activeVideoLesson.tips}"
                        </p>
                        
                        {/* Muscle Tags */}
                        <div className="pt-4 border-t border-[#14F1E1]/20">
                          <span className="block text-[9px] font-bold text-neutral-400 uppercase tracking-widest mb-2">Target Recruits</span>
                          <div className="flex flex-wrap gap-2">
                            {(MARTIAL_LESSONS_MUSCLES[activeVideoLesson.id] || []).map((muscle) => (
                              <span key={muscle} className="text-[9px] font-black uppercase bg-[#14F1E1]/10 border border-[#14F1E1]/30 text-[#14F1E1] px-2.5 py-1 rounded-lg">
                                {muscle}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Interactive Anatomy & Actions */}
                  <div className="lg:col-span-4 flex flex-col gap-6">
                    {/* Anatomy Scanner */}
                    <div className="bg-black/40 border border-white/10 rounded-3xl p-6 backdrop-blur-md flex-1 flex flex-col relative z-10">
                      <div className="mb-4">
                        <span className="text-[10px] font-black text-neutral-400 uppercase tracking-[0.2em] block mb-1">Live Telemetry</span>
                        <h4 className="text-sm font-bold text-white">Anatomical Recruits</h4>
                      </div>
                      
                      <div className="flex-1 bg-black/50 border border-white/5 rounded-2xl p-4 flex items-center justify-center min-h-[300px] relative overflow-hidden">
                        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(20,241,225,0.1),transparent_70%)] pointer-events-none" />
                        <InteractiveBody
                          selectedMuscles={MARTIAL_LESSONS_MUSCLES[activeVideoLesson.id] || ["core"]}
                          onToggleMuscle={() => {}}
                        />
                      </div>
                      
                      {/* Specs */}
                      <div className="grid grid-cols-2 gap-3 mt-4">
                        <div className="bg-white/5 border border-white/10 p-3 rounded-xl text-center">
                          <span className="text-neutral-500 block text-[9px] font-black uppercase tracking-widest mb-1">Reps</span>
                          <span className="text-white font-black text-sm">10-12</span>
                        </div>
                        <button 
                          onClick={() => {
                            if (restTimerLeft !== null) {
                              playSound("timer_pause"); setRestTimerLeft(null);
                            } else {
                              playSound("timer_start"); setRestTimerLeft(45);
                            }
                          }}
                          className={\`p-3 rounded-xl text-center border transition-all \${restTimerLeft !== null ? 'bg-[#14F1E1]/20 border-[#14F1E1]/50 text-[#14F1E1]' : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'}\`}
                        >
                          <span className="text-neutral-500 flex justify-center items-center gap-1 text-[9px] font-black uppercase tracking-widest mb-1">
                            Rest {restTimerLeft === null && <Play className="w-2.5 h-2.5" />}
                          </span>
                          <span className={\`font-black text-sm \${restTimerLeft !== null ? 'text-[#14F1E1]' : 'text-white'}\`}>
                            {restTimerLeft !== null ? \`\${restTimerLeft}s\` : '45s'}
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* Completion Card */}
                    <div className="bg-gradient-to-br from-[#14F1E1]/10 to-transparent border border-[#14F1E1]/30 rounded-3xl p-6 relative z-10 text-center flex flex-col justify-center gap-4">
                      <div className="space-y-1">
                        <span className="text-[10px] font-black text-neutral-400 uppercase tracking-widest">Completion Reward</span>
                        <h3 className="text-3xl font-black text-[#14F1E1] tracking-tighter">+{activeVideoLesson.xpReward} XP</h3>
                      </div>
                      
                      {progress.completed[activeVideoLesson.id] ? (
                        <div className="space-y-3">
                          <div className="w-full py-3.5 bg-[#14F1E1]/20 border border-[#14F1E1] text-[#14F1E1] rounded-xl text-[11px] font-black uppercase tracking-widest flex items-center justify-center gap-2">
                            <CheckCircle2 className="w-5 h-5" /> Mastered
                          </div>
                          <button
                            onClick={() => {
                              playSound("click");
                              const updated = { ...progress.completed };
                              delete updated[activeVideoLesson.id];
                              setProgress({ ...progress, completed: updated });
                            }}
                            className="text-[9px] font-black uppercase text-neutral-500 hover:text-white transition-colors underline underline-offset-4"
                          >
                            Reset Progress
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleMarkComplete(activeVideoLesson)}
                          className="w-full py-4 bg-[#14F1E1] hover:bg-[#1DE9B6] text-[#050B1A] rounded-xl text-xs font-black uppercase tracking-widest transition-all hover:scale-[1.02] active:scale-95 shadow-[0_0_20px_rgba(20,241,225,0.4)] hover:shadow-[0_0_30px_rgba(20,241,225,0.6)] flex items-center justify-center gap-2"
                        >
                          <CheckCircle2 className="w-5 h-5" /> Complete Lesson
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
`;

const finalContent = beforeReturn + newRender + "\n}\n";

fs.writeFileSync(file, finalContent);
console.log("Rewrite successful!");
