const fs = require('fs');

let hd = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

// Remove home-recovery-status-widget
const widget1Regex = /      \{\/\* RECOVERY STATUS CENTER HOME WIDGET \*\/\}[\s\S]*?      \{\/\* LEADERBOARD HOME WIDGET \*\/\}/g;
hd = hd.replace(widget1Regex, "      {/* LEADERBOARD HOME WIDGET */}");

// Remove MUSCLE RECOVERY STATUS widget
const widget2Regex = /      \{\/\* SECTION 4.6 — MUSCLE RECOVERY STATUS \(LAST 48 HOURS\) \*\/\}[\s\S]*?      \{\/\* SECTION 4.8 — BARBELL PLATE CALCULATOR \(NEW UTILITY\) \*\/\}/g;
hd = hd.replace(widget2Regex, "      {/* SECTION 4.8 — BARBELL PLATE CALCULATOR (NEW UTILITY) */}");

fs.writeFileSync('src/components/HomeDashboard.tsx', hd);

let yh = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');

// Remove recovery from subtabs
yh = yh.replace(/\| "recovery" /g, "");

// Remove recovery tab definition
yh = yh.replace(/          \{ id: "recovery", label: "🧘 Recovery Center", icon: "🤸" \},\n/g, "");

// Remove TAB 5: RECOVERY CENTER
const tab5Regex = /          \{\/\* -----------------------------------------\n             TAB 5: RECOVERY CENTER[\s\S]*?          \}\)\n/g;
yh = yh.replace(tab5Regex, "");

fs.writeFileSync('src/components/YoddhaHub.tsx', yh);
