const fs = require('fs');
let code = fs.readFileSync('src/components/WeeklyChallengeScreen.tsx', 'utf8');
code = code.replace(
  "const [hasClaimedThisWeek, setHasClaimedThisWeek] = useState(false);",
  "const [hasClaimedThisWeek, setHasClaimedThisWeek] = useState(() => localStorage.getItem(`weekly_challenge_claimed_${profile?.uid}_${getWeekId()}`) === getWeekId());"
);
fs.writeFileSync('src/components/WeeklyChallengeScreen.tsx', code);
