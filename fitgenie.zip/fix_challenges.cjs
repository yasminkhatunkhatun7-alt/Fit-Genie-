const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');

// I'll just remove the whole floating button from the OneMonthChallengeScreen block.
// The easiest way is to find `if (activeChallenge.id === '1month') {` and replace everything until `if (activeChallenge.id === 'strength') {`

const regex = /if \(activeChallenge\.id === '1month'\) \{[\s\S]*?if \(activeChallenge\.id === 'strength'\) \{/;

code = code.replace(regex, `if (activeChallenge.id === '1month') {
      return (
        <OneMonthChallengeScreen
          challenge={activeChallenge as any}
          onUpdate={setActiveChallenge as any}
          onBack={() => setView('list')}
          onComplete={completeChallenge}
        />
      );
    }
    if (activeChallenge.id === 'strength') {`);

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
console.log('Fixed ChallengesScreen');
