const fs = require('fs');

let code = fs.readFileSync('src/components/SpeedChallengeScreen.tsx', 'utf8');

code = code.replace(/  const \[showCheatWarning, setShowCheatWarning\] = useState\(false\);\n/g, '');

const oldHandle = `  const handleAddReps = (amount: number) => {
    if (isCompleted || showCheatWarning || showFail || timeLeft === 0) return;
    
    if (amount === 1 && cooldown > 0) return;
    if (amount === 10 && cooldown > 0) return;

    const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);

    // Human speed limits check:
    // Burpees are slow. ~1 burpee per 2 seconds max sustained. 
    // If adding 10, should have taken at least 15-20 seconds. 
    // If 50 in 5 seconds -> impossible.
    // Let's set a hard limit: 1 burpee per 1.5 seconds max average
    const reqMinElapsedForNewReps = newCompleted * 1.0; // 1 second per burpee minimum
    
    if (amount === 10 && elapsedTime < 10) {
      triggerCheatWarning();
      return;
    }
    if (newCompleted >= 50 && elapsedTime < 40) { // 50 burpees in 40 seconds is insane
      triggerCheatWarning();
      return;
    }
    if (elapsedTime > 0 && elapsedTime < reqMinElapsedForNewReps && newCompleted > 5) {
      triggerCheatWarning();
      return;
    }`;

const newHandle = `  const handleAddReps = (amount: number) => {
    if (isCompleted || showFail || timeLeft === 0) return;
    
    if (amount === 1 && cooldown > 0) return;
    if (amount === 10 && cooldown > 0) return;

    if (checkCheat(exercise.name, amount)) {
      const updated = { ...challenge };
      updated.exercises[0].completedReps = 0;
      onUpdate(updated);
      return;
    }

    const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);`;

code = code.replace(oldHandle, newHandle);

code = code.replace(/  const triggerCheatWarning = \(\) => {[\s\S]*?setShowCheatWarning\(true\);\n  };\n/g, '');

code = code.replace(/, showCheatWarning/g, '');
code = code.replace(/!showCheatWarning && /g, '');
code = code.replace(/showCheatWarning \|\| /g, '');

const oldRender = `  if (showCheatWarning) {
    
  if (suspiciousPhase !== 'none') {`;
const newRender = `  if (suspiciousPhase !== 'none') {`;
code = code.replace(oldRender, newRender);

fs.writeFileSync('src/components/SpeedChallengeScreen.tsx', code);
