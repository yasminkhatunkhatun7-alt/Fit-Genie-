const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(
  '                        { id: "calisthenics", name: "Calisthenics Library", icon: <Award className="w-3.5 h-3.5" /> },\n',
  ''
);

fs.writeFileSync('src/App.tsx', content);
