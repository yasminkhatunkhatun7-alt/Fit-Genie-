const fs = require('fs');
let code = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');

if (!code.includes('import { useAuth, getRankDetails } from "../context/AuthContext"')) {
    code = code.replace(/import \{ useAuth \} from "\.\.\/context\/AuthContext";/, 'import { useAuth, getRankDetails } from "../context/AuthContext";');
}
fs.writeFileSync('src/components/ProfileView.tsx', code);
