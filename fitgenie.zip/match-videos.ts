import fs from "fs";

const videos = [
  "62sm1cJzivQ", "vCWcYF5PiQg", "0kU-IJQs6Bk", "bmqSJSB0C8E", "ewSCQSE-kEM",
  "IGssbfjjc1Q", "Ou4mFyMmwE4", "tTIV6qVB59Y", "tIyMLHcJ_xQ", "RRQQgW9t--k",
  "fF0IgM71dUM", "B2UXMlFw-Mk", "XglujyVx-SI", "Vorr1jRrb9w", "ruu8XBkLVhg",
  "y-bxF4PCOJo", "MTJxrViWPj4", "Q2ClBRiRzJo", "-9rMGYdJwPE", "TCtuwk35bmk"
];

const exercises = [
  "Wall Push Up", "Knee Push Up", "Dead Hang", "Assisted Squat", "Plank",
  "Negative Pull Up", "Hollow Body", "Diamond Push", "L-Sit", "Bar Dips",
  "Pike Push Up", "Chest to Bar", "Pistol Squat", "Dragon Flag", "Handstand Push",
  "Muscle Up", "Front Lever", "Back Lever", "Human Flag", "Planche", "One Arm"
];

async function matchAll() {
  const finalMatches: any[] = [];
  
  for (const id of videos) {
    try {
      const url = `https://www.youtube.com/watch?v=${id}`;
      const res = await fetch(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          "Accept-Language": "en-US,en;q=0.9"
        }
      });
      const html = await res.text();
      const lowerHtml = html.toLowerCase();
      
      const matched: string[] = [];
      for (const ex of exercises) {
        if (lowerHtml.includes(ex.toLowerCase())) {
          matched.push(ex);
        }
      }
      
      const titleMatch = html.match(/<title>(.*?)<\/title>/);
      const title = titleMatch ? titleMatch[1] : "";
      
      console.log(`ID: ${id}`);
      console.log(`Matches found: ${matched.join(", ")}`);
      console.log(`Page title: ${title}`);
      console.log("-----------------------------------------");
      finalMatches.push({ id, matched, title });
    } catch (err: any) {
      console.error(`Error for ${id}:`, err.message);
    }
    await new Promise(r => setTimeout(r, 500));
  }
}

matchAll();
