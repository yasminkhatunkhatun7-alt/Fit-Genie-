const fs = require('fs');
let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');
if (!content.includes('setLoading(false)')) {
  content = content.replace(
    'const refreshProfile = async () => {};',
    `const refreshProfile = async () => {};\n\n  useEffect(() => {\n    setLoading(false);\n  }, []);`
  );
  fs.writeFileSync('src/context/AuthContext.tsx', content);
}
