const fs = require('fs');
let content = fs.readFileSync('src/components/BottomNavigation.tsx', 'utf8');

content = content.replace(
/    \{\s*view: "leaderboard" as AppView,\s*label: "Rank",\s*icon: <Trophy className="w-5 h-5" \/>,\s*\},/g,
''
);

fs.writeFileSync('src/components/BottomNavigation.tsx', content);
