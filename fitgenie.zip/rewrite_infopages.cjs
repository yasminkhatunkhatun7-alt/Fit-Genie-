const fs = require('fs');

const file = 'src/components/InfoPages.tsx';
const newCode = `import React, { useState } from "react";
import { ChevronLeft, Shield, FileText, Info, Mail, Send, CheckCircle, ExternalLink, Sparkles, AlertTriangle, Scale, Lock, Users, Server, BadgeCheck } from "lucide-react";
import { motion } from "motion/react";
import { AppView } from "../types";

// This file contains all informational pages: Privacy Policy, Terms of Service, About Us, Contact Us, Support & Feedback.
// Redesigned with premium Elite Masterclass / glassmorphic aesthetic.

interface InfoPageProps {
  onNavigateToView?: (view: AppView | "home") => void;
}

export function PrivacyPolicySection({ onNavigateToView }: InfoPageProps) {
  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#14F1E1]/30">
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <button onClick={() => onNavigateToView?.("home")} className="p-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 hover:border-[#14F1E1]/30 transition-all group">
            <ChevronLeft className="w-5 h-5 text-neutral-400 group-hover:text-[#14F1E1]" />
          </button>
          <div>
            <h1 className="text-sm md:text-base font-black text-white uppercase tracking-widest flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#14F1E1]" /> Privacy Protocol
            </h1>
            <p className="text-[10px] text-neutral-500 font-bold tracking-widest uppercase mt-0.5">Data & Security Standards</p>
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#14F1E1]/5 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-3xl mx-auto space-y-8 relative z-10 pb-20">
          <div className="bg-gradient-to-br from-[#14F1E1]/10 to-transparent border border-[#14F1E1]/20 rounded-3xl p-6 md:p-8 backdrop-blur-sm">
            <div className="w-14 h-14 bg-[#14F1E1]/20 rounded-2xl flex items-center justify-center border border-[#14F1E1]/30 mb-5">
              <Lock className="w-7 h-7 text-[#14F1E1]" />
            </div>
            <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-2">Data Integrity & Privacy</h2>
            <p className="text-sm text-neutral-400 leading-relaxed font-medium">
              We respect your digital footprint. Our data collection is minimal, localized where possible, and exclusively geared towards optimizing your athletic progression.
            </p>
          </div>

          <div className="space-y-6">
            <PolicyCard 
              icon={<Users />}
              title="Identity & Authentication"
              content="We collect your Google account name, email, and profile photo strictly for authentication and social identification. Your credentials are handled securely via OAuth protocols."
            />
            <PolicyCard 
              icon={<Server />}
              title="Telemetry & Fitness Data"
              content="We store fitness telemetry generated during sessions: workout logs, rep counts, XP, streaks, rank, and social graph data (followers/following). This powers your progress dashboards and leaderboards."
            />
            <PolicyCard 
              icon={<Shield />}
              title="No Third-Party Brokers"
              content="We do not sell, rent, or trade your personal fitness telemetry or identity data to third-party data brokers or marketing agencies. Period."
            />
            <PolicyCard 
              icon={<BadgeCheck />}
              title="Camera & Processing"
              content="The AI Rep Counter utilizes your device's camera. All skeletal tracking and pose estimation run LOCALLY on your device using TensorFlow.js. We do not transmit, stream, or save your camera video feed."
            />
          </div>

          <div className="p-5 bg-white/5 border border-white/10 rounded-2xl flex items-start gap-4 mt-8">
            <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <p className="text-xs text-neutral-400 leading-relaxed font-medium">
              If you have inquiries regarding data residency or wish to request full account deletion, please contact our support team. We comply with standard data protection guidelines.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function TermsOfServiceSection({ onNavigateToView }: InfoPageProps) {
  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#B66DFF]/30">
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <button onClick={() => onNavigateToView?.("home")} className="p-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 hover:border-[#B66DFF]/30 transition-all group">
            <ChevronLeft className="w-5 h-5 text-neutral-400 group-hover:text-[#B66DFF]" />
          </button>
          <div>
            <h1 className="text-sm md:text-base font-black text-white uppercase tracking-widest flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#B66DFF]" /> Terms of Service
            </h1>
            <p className="text-[10px] text-neutral-500 font-bold tracking-widest uppercase mt-0.5">Platform Rules & Guidelines</p>
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#B66DFF]/5 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-3xl mx-auto space-y-8 relative z-10 pb-20">
          <div className="bg-gradient-to-br from-[#B66DFF]/10 to-transparent border border-[#B66DFF]/20 rounded-3xl p-6 md:p-8 backdrop-blur-sm">
            <div className="w-14 h-14 bg-[#B66DFF]/20 rounded-2xl flex items-center justify-center border border-[#B66DFF]/30 mb-5">
              <Scale className="w-7 h-7 text-[#B66DFF]" />
            </div>
            <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-2">Terms of Service</h2>
            <p className="text-sm text-neutral-400 leading-relaxed font-medium">
              By utilizing the Fit Genie platform, you agree to abide by these operational directives and fair-play standards.
            </p>
          </div>

          <div className="space-y-4">
            <TermsBlock number="01" title="Acceptance of Terms" text="By creating an account or using the Fit Genie app, you agree to be bound by these Terms. If you do not agree, do not use the app." />
            <TermsBlock number="02" title="User Responsibilities" text="You must be at least 13 years old. You are responsible for safeguarding your account credentials and for all activities that occur under your profile." />
            <TermsBlock number="03" title="Health & Safety Disclaimer" text="Fit Genie provides fitness information and AI tracking. It is NOT a substitute for professional medical advice. Always consult a physician before beginning any new exercise regimen. You assume all risks associated with physical activity." />
            <TermsBlock number="04" title="Fair Play & Anti-Cheat (Genie Guardian)" text="We enforce strict anti-cheat measures. Falsifying reps, spoofing motion data, or exploiting mechanics will result in account penalties, loss of XP, or permanent bans via the Genie Guardian system." />
            <TermsBlock number="05" title="Premium Subscriptions" text="Subscriptions auto-renew unless canceled at least 24 hours before the end of the current period. Refunds are handled in accordance with Google Play Store policies." />
            <TermsBlock number="06" title="Account Termination" text="We reserve the right to suspend or terminate accounts that violate these terms, engage in abusive behavior, or attempt to compromise platform integrity." />
          </div>
        </div>
      </div>
    </div>
  );
}

export function AboutSection({ onNavigateToView }: InfoPageProps) {
  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#4DA8FF]/30">
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <button onClick={() => onNavigateToView?.("home")} className="p-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 hover:border-[#4DA8FF]/30 transition-all group">
            <ChevronLeft className="w-5 h-5 text-neutral-400 group-hover:text-[#4DA8FF]" />
          </button>
          <div>
            <h1 className="text-sm md:text-base font-black text-white uppercase tracking-widest flex items-center gap-2">
              <Info className="w-4 h-4 text-[#4DA8FF]" /> About Fit Genie
            </h1>
            <p className="text-[10px] text-neutral-500 font-bold tracking-widest uppercase mt-0.5">The Origin Story</p>
          </div>
        </div>
      </div>
            
      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative flex flex-col items-center justify-center min-h-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#4DA8FF]/10 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="w-full max-w-xl mx-auto relative z-10 space-y-6">
          <div className="bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-[2rem] p-8 md:p-12 text-center backdrop-blur-md shadow-[0_0_50px_rgba(77,168,255,0.05)]">
            <div className="w-24 h-24 bg-gradient-to-br from-[#4DA8FF] to-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-[0_0_30px_rgba(77,168,255,0.3)] border border-white/20 transform -rotate-3">
              <span className="text-5xl drop-shadow-md">🧞</span>
            </div>
            
            <h2 className="text-3xl md:text-4xl font-black uppercase tracking-tighter text-white mb-6">
              Evolution <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#4DA8FF] to-blue-500">Unleashed</span>
            </h2>
            
            <p className="text-sm md:text-base text-neutral-300 leading-relaxed font-medium mb-8">
              Fit Genie is an AI-powered, gamified fitness ecosystem built for modern athletes. Combining real-time AI movement tracking, RPG-style progression (XP, ranks, streaks), and an honest fair-play system (Genie Guardian), we turn everyday workouts into an engaging, high-stakes journey. 
            </p>

            <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#4DA8FF]/10 border border-[#4DA8FF]/30 rounded-full">
              <Sparkles className="w-4 h-4 text-[#4DA8FF]" />
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#4DA8FF]">Crafted for Athletes. Built in India 🇮🇳</span>
            </div>
          </div>
          
          <div className="flex items-center justify-center gap-4 text-[10px] font-black uppercase text-neutral-500 tracking-widest">
            <span>Version 2.0.0</span>
            <span className="w-1 h-1 rounded-full bg-neutral-600" />
            <span>AI Core Active</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export function ContactUsSection({ onNavigateToView }: InfoPageProps) {
  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-rose-500/30">
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <button onClick={() => onNavigateToView?.("home")} className="p-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 hover:border-rose-500/30 transition-all group">
            <ChevronLeft className="w-5 h-5 text-neutral-400 group-hover:text-rose-500" />
          </button>
          <div>
            <h1 className="text-sm md:text-base font-black text-white uppercase tracking-widest flex items-center gap-2">
              <Mail className="w-4 h-4 text-rose-500" /> Contact HQ
            </h1>
            <p className="text-[10px] text-neutral-500 font-bold tracking-widest uppercase mt-0.5">Direct Communications</p>
          </div>
        </div>
      </div>
            
      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative flex items-center justify-center min-h-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-rose-500/10 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="w-full max-w-md mx-auto relative z-10">
          <div className="bg-white/5 border border-white/10 rounded-[2rem] p-8 md:p-10 backdrop-blur-xl shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/20 rounded-full blur-[50px] -mr-10 -mt-10 transition-all group-hover:bg-rose-500/30" />
            
            <div className="w-16 h-16 bg-gradient-to-br from-rose-500 to-rose-700 rounded-2xl flex items-center justify-center mb-8 shadow-[0_0_30px_rgba(244,63,94,0.3)] border border-white/20 relative z-10">
              <Mail className="w-8 h-8 text-white" />
            </div>
            
            <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-4 relative z-10">Get in Touch</h2>
            
            <p className="text-sm text-neutral-400 leading-relaxed font-medium mb-8 relative z-10">
              Have a question, discovered a glitch, or want to propose a partnership? Transmission lines are open. We typically respond within 24-48 hours.
            </p>
                    
            <a 
              href="mailto:officialfitgenie@gmail.com" 
              className="flex items-center justify-center gap-3 w-full py-4 bg-rose-500 text-white rounded-xl text-sm font-black uppercase tracking-widest hover:bg-rose-600 transition-all hover:scale-[1.02] active:scale-95 shadow-[0_0_20px_rgba(244,63,94,0.3)] relative z-10"
            >
              <Send className="w-4 h-4" />
              Dispatch Email
            </a>
            
            <div className="mt-6 flex items-center justify-center gap-2 relative z-10">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <p className="text-center text-[10px] text-neutral-500 font-bold tracking-widest uppercase">
                officialfitgenie@gmail.com
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function SupportFeedbackSection({ onNavigateToView }: InfoPageProps) {
  const [issueType, setIssueType] = useState("Bug Report");
  const [description, setDescription] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;
    
    const subject = encodeURIComponent(\`Fit Genie: \${issueType}\`);
    const body = encodeURIComponent(\`Issue Type: \${issueType}\n\nDescription:\n\${description}\n\n---\nSent from Fit Genie App\`);
    window.location.href = \`mailto:officialfitgenie@gmail.com?subject=\${subject}&body=\${body}\`;
    
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setDescription("");
      onNavigateToView?.("home");
    }, 3000);
  };

  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-amber-500/30">
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <button onClick={() => onNavigateToView?.("home")} className="p-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 hover:border-amber-500/30 transition-all group">
            <ChevronLeft className="w-5 h-5 text-neutral-400 group-hover:text-amber-500" />
          </button>
          <div>
            <h1 className="text-sm md:text-base font-black text-white uppercase tracking-widest flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" /> Support Desk
            </h1>
            <p className="text-[10px] text-neutral-500 font-bold tracking-widest uppercase mt-0.5">Submit Feedback or Bugs</p>
          </div>
        </div>
      </div>
            
      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-2xl mx-auto relative z-10 pb-20">
          <div className="bg-gradient-to-br from-amber-500/10 to-transparent border border-amber-500/20 rounded-3xl p-6 md:p-8 backdrop-blur-sm mb-8">
            <h2 className="text-xl font-black uppercase tracking-tight text-white mb-2">Help Us Improve</h2>
            <p className="text-sm text-neutral-400 leading-relaxed font-medium">
              Encountered an anomaly or have an idea to evolve the platform? Lodge a ticket directly with the engineering team below.
            </p>
          </div>

          {submitted ? (
            <motion.div 
              initial={{ opacity: 0, y: 20 }} 
              animate={{ opacity: 1, y: 0 }}
              className="bg-emerald-500/10 border border-emerald-500/30 rounded-3xl p-10 flex flex-col items-center text-center backdrop-blur-md shadow-[0_0_40px_rgba(16,185,129,0.1)]"
            >
              <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center mb-6 border border-emerald-500/40">
                <CheckCircle className="w-10 h-10 text-emerald-400" />
              </div>
              <h3 className="text-2xl font-black text-white uppercase tracking-widest mb-2">Transmission Sent</h3>
              <p className="text-sm text-emerald-200/70 font-medium max-w-xs">Your report has been logged successfully. The team is on it.</p>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6 bg-white/5 border border-white/10 rounded-[2rem] p-6 md:p-8 backdrop-blur-md">
              <div>
                <label className="block text-[10px] font-black uppercase text-amber-500 tracking-[0.2em] mb-3 ml-2 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" /> Category
                </label>
                <div className="relative">
                  <select 
                    value={issueType}
                    onChange={(e) => setIssueType(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-2xl px-5 py-4 text-sm font-medium text-white focus:outline-none focus:border-amber-500/50 appearance-none focus:ring-1 focus:ring-amber-500/50 transition-all cursor-pointer"
                  >
                    <option value="Bug Report">🐛 Bug Report</option>
                    <option value="Feature Suggestion">💡 Feature Suggestion</option>
                    <option value="Account Issue">🔐 Account Issue</option>
                    <option value="Other">📝 Other</option>
                  </select>
                  <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-neutral-500">
                    <ChevronLeft className="w-4 h-4 -rotate-90" />
                  </div>
                </div>
              </div>
              
              <div>
                <label className="block text-[10px] font-black uppercase text-amber-500 tracking-[0.2em] mb-3 ml-2 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" /> Detailed Intel
                </label>
                <textarea 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide explicit details regarding the issue or suggestion..."
                  rows={6}
                  className="w-full bg-black/40 border border-white/10 rounded-2xl px-5 py-4 text-sm font-medium text-white focus:outline-none focus:border-amber-500/50 resize-none focus:ring-1 focus:ring-amber-500/50 transition-all placeholder:text-neutral-600"
                  required
                />
              </div>
              
              <button 
                type="submit"
                disabled={!description.trim()}
                className="w-full py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-black rounded-xl text-sm font-black uppercase tracking-widest hover:brightness-110 transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:brightness-100 shadow-[0_0_20px_rgba(245,158,11,0.2)] flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                Submit Report
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

// Sub-components
function PolicyCard({ icon, title, content }: { icon: React.ReactNode, title: string, content: string }) {
  return (
    <div className="flex items-start gap-4 p-5 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-colors">
      <div className="w-10 h-10 shrink-0 bg-[#14F1E1]/10 border border-[#14F1E1]/20 rounded-xl flex items-center justify-center text-[#14F1E1]">
        {icon}
      </div>
      <div>
        <h3 className="text-sm font-bold text-white mb-1">{title}</h3>
        <p className="text-xs text-neutral-400 leading-relaxed">{content}</p>
      </div>
    </div>
  );
}

function TermsBlock({ number, title, text }: { number: string, title: string, text: string }) {
  return (
    <div className="p-5 bg-white/5 border border-white/10 rounded-2xl flex gap-4">
      <div className="text-2xl font-black text-white/10 shrink-0">{number}</div>
      <div className="mt-1">
        <h3 className="text-sm font-bold text-white mb-2">{title}</h3>
        <p className="text-xs text-neutral-400 leading-relaxed">{text}</p>
      </div>
    </div>
  );
}
`
fs.writeFileSync(file, newCode);
console.log("Rewrote InfoPages.tsx");
