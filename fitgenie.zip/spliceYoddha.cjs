const fs = require('fs');
let yh = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');
const lines = yh.split('\n');

lines.splice(273, 311 - 273 + 1);

yh = lines.join('\n');
fs.writeFileSync('src/components/YoddhaHub.tsx', yh);
