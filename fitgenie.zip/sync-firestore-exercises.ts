import { initializeApp } from "firebase/app";
import { initializeFirestore, doc, setDoc } from "firebase/firestore";
import fs from "fs";
import path from "path";

// 1. YouTube video ID mappings back to our exercise IDs (from real_youtube_metadata.json)
const YOUTUBE_TO_EXERCISE: Record<string, string> = {};

// 2. Secondary static mappings for standard exercises
const BASE_BUILTIN_VIDEOS: Record<string, string> = {};

// Calisthenics exercises defined in CALISTHENICS_LEVELS
const CALISTHENICS_LEVELS_EXERCISES = [
  // Level 1
  { id: "cal_1_1", name_en: "Wall Push Up", name_hi: "दीवार पुश-अप", difficulty: "beginner", muscles: ["chest", "triceps", "shoulders"], equipment: ["none"] },
  { id: "cal_1_2", name_en: "Knee Push Up", name_hi: "घुटने टेक कर पुश-अप", difficulty: "beginner", muscles: ["chest", "triceps", "shoulders"], equipment: ["none"] },
  { id: "cal_1_3", name_en: "Dead Hang (10 sec)", name_hi: "डैड हैंग (10 सेकंड)", difficulty: "beginner", muscles: ["forearms", "back"], equipment: ["none"] },
  { id: "cal_1_4", name_en: "Assisted Squat", name_hi: "सहारा लेकर बैठक", difficulty: "beginner", muscles: ["legs", "glutes"], equipment: ["none"] },
  { id: "cal_1_5", name_en: "Plank (10 sec)", name_hi: "प्लैंक (10 सेकंड)", difficulty: "beginner", muscles: ["core"], equipment: ["none"] },
  { id: "cal_1_6", name_en: "Surya Namaskar", name_hi: "सूर्य नमस्कार", difficulty: "beginner", muscles: ["shoulders", "chest", "back", "legs", "core"], equipment: ["none"] },
  // Level 2
  { id: "cal_2_1", name_en: "Full Push Up / दंड", name_hi: "दंड", difficulty: "beginner", muscles: ["chest", "triceps", "shoulders"], equipment: ["none"] },
  { id: "cal_2_2", name_en: "Negative Pull Up", name_hi: "नेगेटिव पुल-अप", difficulty: "beginner", muscles: ["back", "biceps"], equipment: ["none"] },
  { id: "cal_2_3", name_en: "Bodyweight Squat / बैठक", name_hi: "बैठक", difficulty: "beginner", muscles: ["legs", "glutes"], equipment: ["none"] },
  { id: "cal_2_4", name_en: "Plank (30 sec)", name_hi: "प्लैंक (30 सेकंड)", difficulty: "beginner", muscles: ["core"], equipment: ["none"] },
  { id: "cal_2_5", name_en: "Hollow Body Hold", name_hi: "हॉलो बॉडी होल्ड", difficulty: "beginner", muscles: ["core"], equipment: ["none"] },
  // Level 3
  { id: "cal_3_1", name_en: "Diamond Push Up", name_hi: "डायमंड पुश-अप", difficulty: "intermediate", muscles: ["triceps", "chest"], equipment: ["none"] },
  { id: "cal_3_2", name_en: "Full Pull Up", name_hi: "चौखट पुल-अप", difficulty: "intermediate", muscles: ["back", "biceps"], equipment: ["none"] },
  { id: "cal_3_3", name_en: "Jump Squat", name_hi: "जम्प बैठक", difficulty: "intermediate", muscles: ["legs", "glutes"], equipment: ["none"] },
  { id: "cal_3_4", name_en: "L-Sit (5 sec)", name_hi: "एल-सिट (5 सेकंड)", difficulty: "intermediate", muscles: ["core", "shoulders"], equipment: ["none"] },
  { id: "cal_3_5", name_en: "Parallel Bar Dips", name_hi: "पैरेलल बार डिप्स", difficulty: "intermediate", muscles: ["triceps", "chest", "shoulders"], equipment: ["none"] },
  // Level 4
  { id: "cal_4_1", name_en: "Pike Push Up", name_hi: "पाइक पुश-अप", difficulty: "advanced", muscles: ["shoulders", "triceps"], equipment: ["none"] },
  { id: "cal_4_2", name_en: "Chest to Bar Pull Up", name_hi: "चेस्ट टू बार पुल-अप", difficulty: "advanced", muscles: ["back", "biceps"], equipment: ["none"] },
  { id: "cal_4_3", name_en: "Pistol Squat (assisted)", name_hi: "असिस्टेड पिस्टल स्क्वाट", difficulty: "advanced", muscles: ["legs", "glutes"], equipment: ["none"] },
  { id: "cal_4_4", name_en: "L-Sit (15 sec)", name_hi: "एल-सिट (15 सेकंड)", difficulty: "advanced", muscles: ["core", "shoulders"], equipment: ["none"] },
  { id: "cal_4_5", name_en: "Dragon Flag (negative)", name_hi: "ड्रैगन फ्लैग (नेगेटिव)", difficulty: "advanced", muscles: ["core"], equipment: ["none"] },
  // Level 5
  { id: "cal_5_1", name_en: "Handstand Push Up (wall)", name_hi: "हैंडस्टैंड पुश-अप (दीवार सहारे)", difficulty: "expert", muscles: ["shoulders", "triceps"], equipment: ["none"] },
  { id: "cal_5_2", name_en: "Muscle Up", name_hi: "मसल अप", difficulty: "expert", muscles: ["back", "biceps", "triceps", "chest"], equipment: ["none"] },
  { id: "cal_5_3", name_en: "Full Pistol Squat", name_hi: "पूर्ण पिस्टल स्क्वाट", difficulty: "expert", muscles: ["legs", "glutes"], equipment: ["none"] },
  { id: "cal_5_4", name_en: "Front Lever (tuck)", name_hi: "फ्रंट लीवर (टक)", difficulty: "expert", muscles: ["back", "core"], equipment: ["none"] },
  { id: "cal_5_5", name_en: "Back Lever (tuck)", name_hi: "बैक लीवर (टक)", difficulty: "expert", muscles: ["shoulders", "back", "core"], equipment: ["none"] },
  // Level 6
  { id: "cal_6_1", name_en: "Free Handstand Push Up", name_hi: "फ्री हैंडस्टैंड पुश-अप", difficulty: "elite", muscles: ["shoulders", "triceps", "core"], equipment: ["none"] },
  { id: "cal_6_2", name_en: "One Arm Pull Up", name_hi: "एक हाथ से पुल-अप", difficulty: "elite", muscles: ["back", "biceps"], equipment: ["none"] },
  { id: "cal_6_3", name_en: "Front Lever (full)", name_hi: "फ्रंट लीवर (पूर्ण)", difficulty: "elite", muscles: ["back", "core"], equipment: ["none"] },
  { id: "cal_6_4", name_en: "Human Flag", name_hi: "ह्यूमन फ्लैग", difficulty: "elite", muscles: ["back", "shoulders", "core"], equipment: ["none"] },
  { id: "cal_6_5", name_en: "Planche (tuck)", name_hi: "प्लेंच (टक)", difficulty: "elite", muscles: ["shoulders", "core", "wrists"], equipment: ["none"] },
  // Level 7
  { id: "cal_7_1", name_en: "One Arm Push Up", name_hi: "एक हाथ से पुश-अप", difficulty: "legend", muscles: ["chest", "triceps", "core"], equipment: ["none"] },
  { id: "cal_7_2", name_en: "Full Planche", name_hi: "पूर्ण प्लैंच", difficulty: "legend", muscles: ["shoulders", "shoulders", "core"], equipment: ["none"] },
  { id: "cal_7_3", name_en: "Iron Cross", name_hi: "आयरन क्रॉस", difficulty: "legend", muscles: ["shoulders", "chest", "back"], equipment: ["none"] },
  { id: "cal_7_4", name_en: "Manna", name_hi: "मन्ना", difficulty: "legend", muscles: ["core", "shoulders", "hamstrings"], equipment: ["none"] }
];

async function syncToDatabase(firebaseConfig: any, databaseId: string | undefined, dbName: string) {
  console.log(`\nInitializing Firestore Database [${dbName}] id: ${databaseId || "(default)"}...`);
  const app = initializeApp(firebaseConfig);
  const db = initializeFirestore(app, {
    experimentalForceLongPolling: true,
  }, databaseId);

  // 1. Read real_youtube_metadata.json to log we're integrating it
  let youtubeMetadata: any[] = [];
  try {
    const raw = fs.readFileSync("./real_youtube_metadata.json", "utf-8");
    youtubeMetadata = JSON.parse(raw);
    console.log(`Loaded ${youtubeMetadata.length} items from real_youtube_metadata.json`);
  } catch (err: any) {
    console.warn(`Could not read real_youtube_metadata.json: ${err.message}. Using built-in mappings.`);
  }

  // Build a map of exercise IDs with their attributed video URLs from mapping & real_youtube_metadata
  const exerciseVideoUrls: Record<string, string> = { ...BASE_BUILTIN_VIDEOS };

  // Attribute the 20 real YouTube clips accurately using YOUTUBE_TO_EXERCISE map
  for (const item of youtubeMetadata) {
    const vId = item.id;
    const exId = YOUTUBE_TO_EXERCISE[vId];
    if (exId) {
      exerciseVideoUrls[exId] = `https://youtube.com/shorts/${vId}`;
      console.log(`Attributed: ${exId} -> https://youtube.com/shorts/${vId}`);
    }
  }

  // Load all base exercises from exercises.json
  let baseExercises: any[] = [];
  try {
    const rawBase = fs.readFileSync("./src/data/exercises.json", "utf-8");
    baseExercises = JSON.parse(rawBase);
    console.log(`Loaded ${baseExercises.length} base exercises from exercises.json`);
  } catch (err: any) {
    console.error(`Error loading bases exercises.json: ${err.message}`);
    process.exit(1);
  }

  // Compile full set of exercises
  const allExercisesToSync: any[] = [];

  // Add base exercises
  for (const ex of baseExercises) {
    const sId = String(ex.id);
    const yUrl = exerciseVideoUrls[sId] || "";
    allExercisesToSync.push({
      id: sId,
      name_en: ex.name_en,
      name_hi: ex.name_hi,
      youtube_url: yUrl,
      difficulty: ex.difficulty || "beginner",
      muscles: ex.muscles || [],
      equipment: ex.equipment || ["none"],
      sets: ex.sets || 3,
      reps: ex.reps || 12,
      instruction_en: ex.instruction_en || "",
      instruction_hi: ex.instruction_hi || "",
      duration_minutes: ex.duration_minutes || 4
    });
  }

  // Add calisthenics level specific exercises (if not already added or overrides)
  for (const ex of CALISTHENICS_LEVELS_EXERCISES) {
    const yUrl = exerciseVideoUrls[ex.id] || "";
    allExercisesToSync.push({
      id: ex.id,
      name_en: ex.name_en,
      name_hi: ex.name_hi,
      youtube_url: yUrl,
      difficulty: ex.difficulty,
      muscles: ex.muscles,
      equipment: ex.equipment,
      sets: 3,
      reps: 10,
      instruction_en: `Keep strict form for doing ${ex.name_en}. Practice with consistency to master.`,
      instruction_hi: `${ex.name_hi} को सही ढंग से करने के लिए सख्त फॉर्म बनाए रखें। अभ्यास करें।`,
      duration_minutes: 5
    });
  }

  console.log(`Prepared ${allExercisesToSync.length} total exercises to sync to Firestore...`);

  const writePromises = allExercisesToSync.map(async (exercise) => {
    const docRef = doc(db, "exercises", exercise.id);
    try {
      await setDoc(docRef, exercise);
      return true;
    } catch (err: any) {
      console.error(`Failed to write exercise ${exercise.id} (${exercise.name_en}):`, err.message);
      return false;
    }
  });

  const results = await Promise.all(writePromises);
  const successCount = results.filter(Boolean).length;

  console.log(`Successfully completed synchronization! Wrote ${successCount} / ${allExercisesToSync.length} documents.`);
}

async function main() {
  const firebaseConfig = JSON.parse(fs.readFileSync("./firebase-applet-config.json", "utf-8"));

  // Only sync to the configured custom database ID
  await syncToDatabase(firebaseConfig, firebaseConfig.firestoreDatabaseId, "Target Configured DB");

  console.log("\nAll synchronization goals met successfully!");
  process.exit(0);
}

main();
