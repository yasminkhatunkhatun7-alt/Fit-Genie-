const fs = require('fs');
let code = fs.readFileSync('src/components/SmartWorkoutTracker.tsx', 'utf-8');

// Add import for AiRepCounter
const importTarget = `import { useGenieTracker } from "../context/GenieTrackerContext";`;
const importReplace = `import { useGenieTracker } from "../context/GenieTrackerContext";\nimport { AiRepCounter } from "./AiRepCounter";\nimport { Camera } from "lucide-react";`;
if (!code.includes('AiRepCounter')) {
  code = code.replace(importTarget, importReplace);
}

// Add state for showAiTracker
const stateTarget = `const [completedRepsInput, setCompletedRepsInput] = useState<string>("");`;
const stateReplace = `const [completedRepsInput, setCompletedRepsInput] = useState<string>("");\n  const [showAiTracker, setShowAiTracker] = useState(false);`;
if (!code.includes('showAiTracker')) {
  code = code.replace(stateTarget, stateReplace);
}

// Add UI for AI Tracker button in active state
const activeUI = `<div className="w-full flex-1 flex flex-col items-center justify-center">`;
const activeUIReplace = `<div className="w-full flex-1 flex flex-col items-center justify-center">
        {!isPaused && (
          <button 
            onClick={() => { playSound("click"); setShowAiTracker(true); }}
            className="mb-8 px-5 py-3 bg-[#14F1E1]/10 text-[#14F1E1] border border-[#14F1E1]/30 rounded-2xl flex items-center justify-center gap-2 font-black uppercase tracking-widest hover:bg-[#14F1E1]/20 transition-all hover:scale-105 shadow-[0_0_15px_rgba(20,241,225,0.15)]"
          >
            <Camera className="w-5 h-5" />
            AI Auto-Track Reps
          </button>
        )}`;
if (!code.includes('AI Auto-Track Reps')) {
  code = code.replace(activeUI, activeUIReplace);
}

// Add AiRepCounter component rendering
const returnTarget = `return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md">`;
const returnReplace = `return (
    <>
    {showAiTracker && (
      <AiRepCounter
        initialExercise={exercise.name_en.toLowerCase().includes("squat") ? "Squats" : "Pushups"}
        onClose={() => setShowAiTracker(false)}
        onComplete={(reps) => {
          setShowAiTracker(false);
          setCompletedRepsInput(reps.toString());
          setState("completion");
          playSound("success");
        }}
      />
    )}
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md">`;
const returnEnd = `</div>
    </div>
  );`;
const returnEndReplace = `</div>
    </div>
    </>
  );`;

if (!code.includes('showAiTracker && (')) {
  code = code.replace(returnTarget, returnReplace);
  code = code.replace(returnEnd, returnEndReplace);
}

fs.writeFileSync('src/components/SmartWorkoutTracker.tsx', code);
console.log("Patched SmartWorkoutTracker.tsx");
