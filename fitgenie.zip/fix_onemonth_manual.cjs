const fs = require('fs');
let code = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf-8');

const regex = /\{!isDone && \([\s\S]*?<\/div>\n               \)}/;
const replacement = `{!isDone && (
                 <div className="flex gap-2">
                   {exercise === 'Pushups' || exercise === 'Squats' ? (
                     <div className="flex-1 py-2 bg-white/5 border border-white/10 text-neutral-400 font-bold text-[10px] uppercase tracking-widest rounded-lg flex items-center justify-center text-center">
                       Use AI Tracker
                     </div>
                   ) : (
                     <div className="flex-1 py-2 bg-white/5 border border-white/10 text-neutral-400 font-bold text-[10px] uppercase tracking-widest rounded-lg flex items-center justify-center text-center">
                       Manual Tracking Disabled
                     </div>
                   )}
                 </div>
               )}`;

if (code.match(regex)) {
  code = code.replace(regex, replacement);
  fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', code);
  console.log('Fixed OneMonth');
} else {
  console.log('Failed to fix OneMonth');
}
