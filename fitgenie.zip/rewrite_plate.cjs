const fs = require('fs');

const file = 'src/components/PlateCalculator.tsx';

const newCode = `import { useState } from "react";
import { Dumbbell, Plus, Minus, Scale } from "lucide-react";

export default function PlateCalculator() {
  const [targetWeight, setTargetWeight] = useState<number>(100);
  const [barbellWeight, setBarbellWeight] = useState<number>(20);
  
  // Available plates (kg)
  const AVAILABLE_PLATES = [25, 20, 15, 10, 5, 2.5, 1.25];

  const calculatePlates = () => {
    let remainingWeight = targetWeight - barbellWeight;
    if (remainingWeight <= 0) return [];
    
    let weightPerSide = remainingWeight / 2;
    const plates = [];
    
    for (const plate of AVAILABLE_PLATES) {
      while (weightPerSide >= plate) {
        plates.push(plate);
        weightPerSide -= plate;
        weightPerSide = Math.round(weightPerSide * 100) / 100;
      }
    }
    return plates;
  };

  const getPlateColor = (weight: number) => {
    switch (weight) {
      case 25: return "border-rose-500 text-rose-500 bg-rose-500/10 shadow-[0_0_15px_rgba(244,63,94,0.3)]";
      case 20: return "border-blue-500 text-blue-500 bg-blue-500/10 shadow-[0_0_15px_rgba(59,130,246,0.3)]";
      case 15: return "border-amber-500 text-amber-500 bg-amber-500/10 shadow-[0_0_15px_rgba(245,158,11,0.3)]";
      case 10: return "border-emerald-500 text-emerald-500 bg-emerald-500/10 shadow-[0_0_15px_rgba(16,185,129,0.3)]";
      case 5: return "border-white/80 text-white bg-white/10 shadow-[0_0_15px_rgba(255,255,255,0.1)]";
      case 2.5: return "border-neutral-500 text-neutral-400 bg-neutral-800 shadow-md";
      case 1.25: return "border-neutral-600 text-neutral-400 bg-neutral-800/50 shadow-md";
      default: return "border-[#333] text-white bg-[#222]";
    }
  };

  const platesNeeded = calculatePlates();
  const actualWeight = barbellWeight + (platesNeeded.reduce((a, b) => a + b, 0) * 2);

  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#4DA8FF]/30">
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-white/5 border border-white/10 rounded-xl group">
            <Scale className="w-5 h-5 text-[#4DA8FF]" />
          </div>
          <div>
            <h1 className="text-sm md:text-base font-black text-white uppercase tracking-widest">Plate Calculator</h1>
            <p className="text-[10px] text-neutral-500 font-bold tracking-widest uppercase mt-0.5">Barbell Load Optimization</p>
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#4DA8FF]/5 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-2xl mx-auto space-y-8 relative z-10 pb-24">
          
          {/* Main Controls Card */}
          <div className="bg-gradient-to-br from-[#050B1A] to-[#0A1020] border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute -top-20 -right-20 w-48 h-48 bg-[#4DA8FF]/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
              
              {/* Target Weight Input */}
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#4DA8FF] block ml-1 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#4DA8FF]" /> Target Load
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={targetWeight || ''}
                    onChange={(e) => setTargetWeight(Number(e.target.value))}
                    className="w-full bg-black/40 border border-white/10 rounded-2xl py-5 px-6 text-3xl font-black text-white focus:outline-none focus:border-[#4DA8FF]/50 transition-all focus:ring-1 focus:ring-[#4DA8FF]/50 tracking-tighter"
                  />
                  <span className="absolute right-6 top-1/2 -translate-y-1/2 text-neutral-500 font-black uppercase text-sm tracking-widest">KG</span>
                </div>
                
                {/* Quick Add/Sub */}
                <div className="flex gap-2">
                  <button onClick={() => setTargetWeight(prev => Math.max(barbellWeight, prev - 5))} className="flex-1 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl flex items-center justify-center text-neutral-400 hover:text-white transition-colors">
                    <Minus className="w-4 h-4" /> 5
                  </button>
                  <button onClick={() => setTargetWeight(prev => prev + 5)} className="flex-1 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl flex items-center justify-center text-neutral-400 hover:text-white transition-colors">
                    <Plus className="w-4 h-4" /> 5
                  </button>
                  <button onClick={() => setTargetWeight(prev => prev + 10)} className="flex-1 py-2 bg-[#4DA8FF]/10 hover:bg-[#4DA8FF]/20 border border-[#4DA8FF]/30 rounded-xl flex items-center justify-center text-[#4DA8FF] font-bold transition-colors">
                    <Plus className="w-4 h-4" /> 10
                  </button>
                </div>
              </div>

              {/* Barbell Selection */}
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-neutral-400 block ml-1 flex items-center gap-2">
                  <Dumbbell className="w-3.5 h-3.5 text-neutral-500" /> Equipment Spec
                </label>
                <div className="space-y-2">
                  {[
                    { w: 20, label: "20kg Standard Olympic" },
                    { w: 15, label: "15kg Women's Olympic" },
                    { w: 10, label: "10kg Technique Bar" }
                  ].map((bar) => (
                    <button
                      key={bar.w}
                      onClick={() => setBarbellWeight(bar.w)}
                      className={\`w-full flex items-center justify-between p-4 rounded-xl border transition-all \${
                        barbellWeight === bar.w
                          ? "bg-[#4DA8FF]/10 border-[#4DA8FF]/40 shadow-[0_0_15px_rgba(77,168,255,0.1)]"
                          : "bg-black/40 border-white/5 hover:border-white/20"
                      }\`}
                    >
                      <span className={\`text-xs font-bold uppercase tracking-wide \${barbellWeight === bar.w ? 'text-white' : 'text-neutral-400'}\`}>{bar.label}</span>
                      <div className={\`w-4 h-4 rounded-full border-2 flex items-center justify-center \${barbellWeight === bar.w ? 'border-[#4DA8FF]' : 'border-neutral-600'}\`}>
                        {barbellWeight === bar.w && <div className="w-2 h-2 rounded-full bg-[#4DA8FF]" />}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Visualization Card */}
          <div className="bg-[#4DA8FF]/5 border border-[#4DA8FF]/30 rounded-3xl p-8 relative overflow-hidden text-center shadow-[0_0_40px_rgba(77,168,255,0.05)]">
            <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(ellipse_at_center,rgba(77,168,255,0.15)_0%,transparent_70%)] pointer-events-none" />
            
            <div className="relative z-10 space-y-2 mb-8">
              <p className="text-[10px] font-black uppercase tracking-[0.3em] text-[#4DA8FF]">Final Operational Load</p>
              <h2 className="text-7xl font-black text-white tracking-tighter drop-shadow-lg">
                {actualWeight}<span className="text-3xl text-neutral-500 tracking-normal ml-2">KG</span>
              </h2>
              {actualWeight !== targetWeight && targetWeight > barbellWeight && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-full text-[9px] font-black uppercase tracking-widest mt-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
                  Closest match to {targetWeight}kg
                </div>
              )}
            </div>

            {targetWeight <= barbellWeight ? (
              <div className="relative z-10 py-10 border border-dashed border-white/10 rounded-2xl bg-black/20">
                <p className="text-neutral-500 font-bold uppercase tracking-[0.2em] text-xs">Bar is empty (No plates required)</p>
              </div>
            ) : (
              <div className="relative z-10 space-y-6">
                <p className="text-[10px] font-black uppercase tracking-widest text-neutral-400 text-center mb-4">Required Plates (Per Side)</p>
                
                <div className="flex flex-wrap justify-center gap-3">
                  {platesNeeded.length > 0 ? (
                    platesNeeded.map((plate, idx) => (
                      <div 
                        key={idx} 
                        className={\`w-16 h-16 rounded-full border-[3px] flex flex-col items-center justify-center transform transition-transform hover:scale-110 \${getPlateColor(plate)}\`}
                      >
                        <span className="font-black text-xl leading-none">{plate}</span>
                        <span className="text-[8px] font-bold uppercase tracking-widest opacity-80 leading-none mt-1">KG</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-neutral-500 font-bold uppercase text-xs">No plates needed</div>
                  )}
                </div>
                
                {platesNeeded.length > 0 && (
                  <div className="mt-8 border-t border-[#4DA8FF]/20 pt-6">
                    <p className="text-center text-[10px] font-black uppercase tracking-[0.2em] text-[#4DA8FF] bg-[#4DA8FF]/10 inline-block px-4 py-1.5 rounded-lg border border-[#4DA8FF]/20">
                      Load sequence: {platesNeeded.join('kg → ')}kg
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
          
        </div>
      </div>
    </div>
  );
}
`
fs.writeFileSync(file, newCode);
console.log("Rewrote PlateCalculator.tsx");
