const fs = require('fs');
const files = [
  'src/components/ExerciseVideos.tsx',
  'src/components/HomeDashboard.tsx',
  'src/components/ProfileView.tsx',
  'src/components/DailyMissions.tsx',
  'src/components/GlobalCompletionCounter.tsx',
  'src/components/ExercisesLibrary.tsx',
  'src/utils/DailyMissionEngine.ts'
];

for (const file of files) {
  try {
    let content = fs.readFileSync(file, 'utf8');
    
    // Remove imports
    content = content.replace(/import \{.*\} from "firebase\/.*";\n/g, '');
    content = content.replace(/import \{.*\} from "\.\.\/firebase";\n/g, '');
    content = content.replace(/import \{.*\} from "\.\/firebase";\n/g, '');
    
    if (file.includes('ExerciseVideos.tsx') || file.includes('HomeDashboard.tsx')) {
      content = content.replace(
        /const unsub = onSnapshot\(collection\(db,.*?\), \(snapshot\) => \{[\s\S]*?\}\);[\s\S]*?return \(\) => unsub\(\);/gm,
        `// Firebase removed, local only`
      );
    }
    
    if (file.includes('ProfileView.tsx') || file.includes('ExercisesLibrary.tsx')) {
      content = content.replace(/await updateUserProfile\([\s\S]*?\);/g, `await updateUserProfileFields(updateData);`);
    }

    if (file.includes('DailyMissions.tsx')) {
       // DailyMissions has some doc/setDoc usage
       content = content.replace(/await setDoc\(doc\(db, "daily_missions".*?\);/g, `// Local missions`);
       content = content.replace(/const docRef = doc\(db, "daily_missions".*?\);/g, `// local missions`);
       content = content.replace(/const docSnap = await getDoc\(docRef\);/g, `const docSnap = { exists: () => false };`);
    }
    
    if (file.includes('GlobalCompletionCounter.tsx')) {
        content = content.replace(/const docRef = doc\(db, "global_stats".*?\);/g, ``);
        content = content.replace(/const docSnap = await getDoc\(docRef\);/g, ``);
        content = content.replace(/if \(!docSnap.exists\(\)\).*?setDoc.*?\);/g, ``);
        content = content.replace(/await updateDoc\(.*? increment.*?\}\);/g, ``);
        content = content.replace(/export const incrementCompletionCount = async \(\) => \{[\s\S]*?\};/g, `export const incrementCompletionCount = async () => {};`);
        content = content.replace(/useEffect\(\(\) => \{[\s\S]*?onSnapshot[\s\S]*?\}\, \[\]\);/g, `useEffect(() => { setTotalCount(0); }, []);`);
    }

    if (file.includes('DailyMissionEngine.ts')) {
        content = content.replace(/const \{ doc, getDoc, setDoc \} = await import\('firebase\/firestore'\);/g, '');
        content = content.replace(/const \{ db \} = await import\('\.\.\/firebase'\);/g, '');
        content = content.replace(/const docRef = doc\(db, "daily_missions".*?\);/g, ``);
        content = content.replace(/const docSnap = await getDoc\(docRef\);/g, `const docSnap = { exists: () => false };`);
        content = content.replace(/await setDoc\(doc\(db, "daily_missions".*?\);/g, ``);
        content = content.replace(/const \{ doc, setDoc \} = await import\('firebase\/firestore'\);/g, '');
        content = content.replace(/const \{ db \} = await import\('\.\.\/firebase'\);/g, '');
    }
    
    fs.writeFileSync(file, content);
  } catch (err) {
    console.log("Error patching " + file, err);
  }
}
