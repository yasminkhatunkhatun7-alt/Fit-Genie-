const fs = require('fs');

const getRankDetails = `export function getRankDetails(xp: number) {
  if (xp >= 10000) return { title: "Ascended", next: "Max", base: 10000, nextXP: 99999, emoji: "✨" };
  if (xp >= 7500) return { title: "Mythic", next: "Ascended", base: 7500, nextXP: 10000, emoji: "🌟" };
  if (xp >= 5000) return { title: "Legend", next: "Mythic", base: 5000, nextXP: 7500, emoji: "👑" };
  if (xp >= 3000) return { title: "Titan", next: "Legend", base: 3000, nextXP: 5000, emoji: "🦁" };
  if (xp >= 2000) return { title: "Champion", next: "Titan", base: 2000, nextXP: 3000, emoji: "🏆" };
  if (xp >= 1000) return { title: "Elite", next: "Champion", base: 1000, nextXP: 2000, emoji: "⚔️" };
  if (xp >= 500) return { title: "Warrior", next: "Elite", base: 500, nextXP: 1000, emoji: "🗡️" };
  return { title: "Beginner", next: "Warrior", base: 0, nextXP: 500, emoji: "🌱" };
}`;

// Fix AuthContext.ts
let auth = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

auth = auth.replace(/export function getRankFromXP[\s\S]*?return "Beginner";\n\}/, 
`export function getRankFromXP(xp: number): string {
  if (xp >= 10000) return "Ascended";
  if (xp >= 7500) return "Mythic";
  if (xp >= 5000) return "Legend";
  if (xp >= 3000) return "Titan";
  if (xp >= 2000) return "Champion";
  if (xp >= 1000) return "Elite";
  if (xp >= 500) return "Warrior";
  return "Beginner";
}`);
fs.writeFileSync('src/context/AuthContext.tsx', auth);


let home = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');
home = home.replace(/function getRankDetails[\s\S]*?return \{ title: "Beginner", next: "Warrior", base: 0, nextXP: 100, emoji: "🌱" \};\n  \}/, 
``);

if (!home.includes('import { getRankDetails }')) {
  home = home.replace(/import \{ useAuth \} from "\.\.\/context\/AuthContext";/, 'import { useAuth, getRankDetails } from "../context/AuthContext";');
}
fs.writeFileSync('src/components/HomeDashboard.tsx', home);

console.log("Updated rank logic in Auth and Home");
