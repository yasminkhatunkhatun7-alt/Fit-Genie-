const fs = require('fs');
let file = 'src/components/DailyChallengeDetailScreen.tsx';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/suspiciousPhase=\{suspiciousPhase\}/, 'suspiciousPhase={suspiciousPhase as any}');
fs.writeFileSync(file, content);
console.log("Patched DailyChallengeDetailScreen.tsx");
