const fs = require('fs');
console.log("Creating temp structure to check types...");
