const fs = require('fs');
const lines = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8').split('\n');
const fixedLines = [];
let i = 0;
while (i < lines.length) {
  if (lines[i].includes('border-[rgba(77,168,255,0.2)] bg-[rgba(77,168,255,0.05)]')) {
    fixedLines.push(lines[i]);
    i++;
    while (!lines[i].includes('border-[rgba(20,241,225,0.2)] bg-[rgba(20,241,225,0.05)]')) {
      i++;
    }
    // We skipped everything between Trust Score card and Fitness Status card.
    // Insert new content
    const newCard = `                    <div className="flex items-center gap-3 mb-2">
                      <Shield className="w-5 h-5 text-[#4DA8FF]" />
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider">Trust Score</h3>
                    </div>
                    <div className="flex items-end gap-2 mb-2">
                      <span className="text-4xl font-black font-mono text-[#4DA8FF]">{profile?.integrityScore || 100}%</span>
                    </div>
                    {(() => {
                      const data = getIntegrityData(profile?.integrityScore || 100);
                      return (
                        <>
                          <p className="text-sm font-bold text-white mb-1">{data.status}</p>
                          <p className="text-xs text-neutral-300 font-medium mb-1">Mood: {data.mood}</p>
                          <p className="text-xs text-[#4DA8FF] font-medium italic">"{data.message}"</p>
                        </>
                      );
                    })()}
                  </div>`;
    fixedLines.push(...newCard.split('\n'));
    fixedLines.push(lines[i]);
  } else {
    fixedLines.push(lines[i]);
  }
  i++;
}

fs.writeFileSync('src/components/GuardianOrb.tsx', fixedLines.join('\n'));
