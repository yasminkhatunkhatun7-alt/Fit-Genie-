const fs = require('fs');

let file = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');

if (!file.includes('showLeaderboards')) {
  // Add state
  file = file.replace(
    'const [toggleFollowLoading, setToggleFollowLoading] = useState(false);',
    'const [toggleFollowLoading, setToggleFollowLoading] = useState(false);\n  const [showLeaderboards, setShowLeaderboards] = useState(false);'
  );
  
  // Add import
  file = file.replace(
    'import { CompletedSession } from "../types";',
    'import { CompletedSession } from "../types";\nimport Leaderboards from "./Leaderboards";'
  );
  
  // Add render Leaderboards
  file = file.replace(
    '<div className="flex-1 overflow-y-auto custom-scrollbar relative">',
    '<div className="flex-1 overflow-y-auto custom-scrollbar relative">\n        <AnimatePresence>\n          {showLeaderboards && <Leaderboards onClose={() => setShowLeaderboards(false)} />}\n        </AnimatePresence>'
  );

  // Add Button
  const buttonCode = `        {/* LEADERBOARDS BUTTON */}
        <div className="px-4 mt-4">
          <button 
            onClick={() => setShowLeaderboards(true)}
            className="w-full bg-[#1A2642] border border-[#B66DFF]/30 hover:border-[#B66DFF] rounded-xl p-4 flex items-center justify-between transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#B66DFF]/20 flex items-center justify-center">
                <Trophy className="w-5 h-5 text-[#B66DFF]" />
              </div>
              <div className="text-left">
                <h3 className="text-sm font-black uppercase text-white group-hover:text-[#B66DFF] transition-colors">Global Leaderboards</h3>
                <p className="text-[10px] font-bold uppercase tracking-widest text-brand-muted">See where you rank worldwide</p>
              </div>
            </div>
            <ChevronLeft className="w-5 h-5 text-brand-muted rotate-180 group-hover:text-[#B66DFF] group-hover:translate-x-1 transition-all" />
          </button>
        </div>
`;
  file = file.replace(
    '{/* HISTORY LIST */}',
    buttonCode + '\n        {/* HISTORY LIST */}'
  );
  
  fs.writeFileSync('src/components/ProfileView.tsx', file);
}
