const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

// We need to insert states for verification
const stateInsertionPoint = "const [lastActionTime, setLastActionTime] = useState(Date.now());";
const newStates = `const [lastActionTime, setLastActionTime] = useState(Date.now());
  const [verificationData, setVerificationData] = useState<{ exercise: string, amount: number, isFlagged: boolean } | null>(null);
  const [verifyDuration, setVerifyDuration] = useState("");
  const [verifyReps, setVerifyReps] = useState("");
  const [verifyError, setVerifyError] = useState("");`;
content = content.replace(stateInsertionPoint, newStates);

// Replace handleAddReps early return
const handleAddRepsRegex = /const handleAddReps = \(exercise: string, amount: number\) => \{\s*if \(isMonthComplete \|\| monthState\.validationFailed\) return;/;
const newHandleAddRepsStart = `const handleAddReps = (exercise: string, amount: number, bypassVerification: boolean = false) => {
    if (isMonthComplete) return;

    if (monthState.validationFailed && !bypassVerification) {
        // High trust users can still verify
        if (profile?.integrityScore && profile.integrityScore >= 50) {
            setVerificationData({ exercise, amount, isFlagged: true });
        } else {
            setShowCheatWarning(true);
        }
        return;
    }`;
content = content.replace(handleAddRepsRegex, newHandleAddRepsStart);

// Replace the isSuspicious block
const isSuspiciousRegex = /if \(isSuspicious\) \{\s*setShowCheatWarning\(true\);\s*setMonthState\(prev => \{\s*const newFlags = \(prev\.suspiciousFlags \|\| 0\) \+ 1;\s*const updated = \{\s*\.\.\.prev,\s*suspiciousFlags: newFlags,\s*validationFailed: prev\.validationFailed \|\| newFlags >= 2\s*\};\s*localStorage\.setItem\(storageKey, JSON\.stringify\(updated\)\);\s*return updated;\s*\}\);\s*return;\s*\}/;

const newIsSuspiciousBlock = `if (isSuspicious && !bypassVerification) {
      setMonthState(prev => {
        const newFlags = (prev.suspiciousFlags || 0) + 1;
        const updated = {
          ...prev,
          suspiciousFlags: newFlags,
          validationFailed: prev.validationFailed || newFlags >= 3 // Increased threshold
        };
        localStorage.setItem(storageKey, JSON.stringify(updated));
        return updated;
      });
      setVerificationData({ exercise, amount, isFlagged: false });
      return;
    }`;
content = content.replace(isSuspiciousRegex, newIsSuspiciousBlock);

// Replace the daily threshold checks
const dailyThresholdRegex = /\/\/ Unrealistic threshold check \[\s\S]*?if \(totalDailyAll > 5000\) \{\s*updated\.validationFailed = true;\s*setShowCheatWarning\(true\);\s*\}/;
const newDailyThresholdBlock = `// Unrealistic threshold check
       if (updated.dailyLog.reps[exercise] > 2500) {
         updated.validationFailed = true;
         setShowCheatWarning(true);
       }
       
       const totalDailyAll = Object.values(updated.dailyLog.reps).reduce((a, b) => a + b, 0);
       if (totalDailyAll > 5000) {
         updated.validationFailed = true;
         setShowCheatWarning(true);
       }`;
// Wait, actually I shouldn't replace it if I'm not sure the regex matches perfectly. Let's just do a specific string replace.
