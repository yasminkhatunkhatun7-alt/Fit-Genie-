const fs = require('fs');
let content = fs.readFileSync('src/components/BottomNavigation.tsx', 'utf8');

content = content.replace('min-w-[70px]', 'min-w-[60px] flex-1');

fs.writeFileSync('src/components/BottomNavigation.tsx', content);
