const fs = require('fs');
let code = fs.readFileSync('src/components/ChallengesScreen.tsx', 'utf-8');

// Replace the literal string "\n      <React.Fragment>\n    );" with proper syntax
code = code.replace(/\\n      <React\.Fragment>\\n    \);/g, '\n      </React.Fragment>\n    );');
code = code.replace(/\\n      <\/React\.Fragment>\\n    \);/g, '\n      </React.Fragment>\n    );');

// The replacement was:
// withoutClosing.replace(/return \(/, 'return (\\n      <React.Fragment>') + renderAiTracker + '\\n      </React.Fragment>\\n    );';
// This resulted in literal '\n'. Let's clean it all up.
code = code.replace(/return \(\\n      <React\.Fragment>/g, 'return (\n      <React.Fragment>');
code = code.replace(/\\n      <\/React\.Fragment>\\n    \);/g, '\n      </React.Fragment>\n    );');

fs.writeFileSync('src/components/ChallengesScreen.tsx', code);
