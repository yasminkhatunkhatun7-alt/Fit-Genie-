const fs = require('fs');
let content = fs.readFileSync('src/types.ts', 'utf8');
content = content.replace(/ \| "dojo"/, ' | "dojo"\n  | "achievements"');
fs.writeFileSync('src/types.ts', content);
