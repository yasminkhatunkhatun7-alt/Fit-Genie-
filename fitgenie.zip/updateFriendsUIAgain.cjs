const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

// The file currently ends with:
//         </div>
//       )}
//     </div>
//   );
// }

// First let's remove the Incoming Requests Section from the network tab since it's currently still there!
code = code.replace(
  /\s*\{\/\* Incoming Requests Section \*\/\}[\s\S]*?Wants to be friends[\s\S]*?\}\)\}\s*<\/div>\s*<\/div>\s*\)\}/,
  ''
);

const friendsTabUI = `
      {activeTab === "friends" && (
        <div className="flex-1 overflow-y-auto mt-4 space-y-4 pr-1 pb-4 flex flex-col custom-scrollbar">
          
           {/* Incoming Requests Section */}
           {friendRequests.length > 0 && (
             <div className="mb-4">
               <h3 className="text-xs font-black uppercase tracking-widest text-neutral-500 mb-3 flex items-center gap-2">
                 <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                 Pending Requests ({friendRequests.length})
               </h3>
               <div className="space-y-2">
                 {friendRequests.map(req => (
                   <div key={req.id} className="bg-brand-surface border border-neutral-800 p-3 rounded-xl flex items-center justify-between">
                     <div>
                       <p className="font-bold text-sm text-white">
                         {req.fromName} <span className="text-neutral-500 text-xs font-mono ml-1">{req.fromFighterId}</span>
                       </p>
                       <p className="text-[10px] text-neutral-500 uppercase tracking-widest mt-0.5">Wants to be friends</p>
                     </div>
                     <div className="flex items-center gap-2">
                       <button onClick={() => acceptRequest(req)} className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center hover:bg-emerald-500/30">
                         <UserCheck className="w-4 h-4" />
                       </button>
                       <button onClick={() => rejectRequest(req.id)} className="w-8 h-8 rounded-lg bg-red-500/10 text-red-400 flex items-center justify-center hover:bg-red-500/20">
                         <span className="text-lg font-bold leading-none mb-1">×</span>
                       </button>                     
                     </div>
                   </div>
                 ))}
               </div>
             </div>
           )}

           {/* Friends List */}
           <div>
             <h3 className="text-xs font-black uppercase tracking-widest text-neutral-500 mb-3 flex items-center gap-2">
               <UserCheck className="w-4 h-4" />
               My Friends ({friendsList.length})
             </h3>
             
             {friendsList.length === 0 ? (
               <div className="bg-brand-surface border border-brand-border p-6 rounded-xl flex flex-col items-center justify-center text-center opacity-70">
                 <UserPlus className="w-10 h-10 text-brand-muted mb-3 opacity-50" />
                 <p className="text-xs uppercase font-bold tracking-widest text-brand-muted">No friends yet.</p>
                 <p className="text-[10px] text-brand-muted mt-2">Go to the Add tab to find athletes.</p>
               </div>
             ) : (
               <div className="space-y-2">
                 {friendsList.map(friend => (
                   <div key={friend.userId} className="bg-brand-surface border border-brand-border p-3 rounded-xl flex items-center justify-between">
                     <div className="flex items-center gap-3">
                       <div className={\`w-10 h-10 rounded-lg flex items-center justify-center font-black text-sm border-2 \${friend.avatarBg || 'bg-neutral-800 border-neutral-700'}\`}>
                          {friend.userName?.charAt(0).toUpperCase()}
                       </div>
                       <div>
                         <p className="font-bold text-sm text-white flex items-center gap-2">
                           {friend.userName} 
                           {friend.fighterId && <span className="text-neutral-500 text-xs font-mono">{friend.fighterId}</span>}
                         </p>
                         <p className="text-[10px] text-brand-accent uppercase tracking-widest mt-0.5">{friend.xp || 0} XP</p>
                       </div>
                     </div>
                   </div>
                 ))}
               </div>
             )}
           </div>

        </div>
      )}
`;

code = code.replace(
  /        <\/div>\s*\)\}\s*<\/div>\s*\);\s*\}/,
  `        </div>
      )}
${friendsTabUI}
    </div>
  );
}`
);

fs.writeFileSync('src/components/WorldChat.tsx', code);
