const fs = require('fs');
let content = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');

content = content.replace(/\{ id: "leaderboard", label: "🏆 Leaderboard", icon: "🏅" \},/g, '');
content = content.replace(/\{\s*activeSubTab === "leaderboard" && \([\s\S]*?\)\s*\}/g, '');

fs.writeFileSync('src/components/YoddhaHub.tsx', content);
