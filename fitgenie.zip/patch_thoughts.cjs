const fs = require('fs');

let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

const thoughtsHook = `
  useEffect(() => {
    let timeoutId;
    const triggerThought = () => {
      const nextThought = Math.random() * 20000 + 20000; // 20-40s
      timeoutId = setTimeout(() => {
        if (!activeWarning && !isPanelOpen && Math.random() > 0.5) {
          const thoughts = [
            "Bro improve kar raha hai.",
            "Ye challenge genuine lag raha hai.",
            "Ye speed unusual hai.",
            "Consistency improve ho rahi hai.",
            "Aaj ka session focus wala lag raha hai.",
            "Form is everything bro."
          ];
          const randomThought = thoughts[Math.floor(Math.random() * thoughts.length)];
          setEmotion("thinking");
          setMessage(randomThought);
          setTimeout(() => {
            setEmotion("focused");
            setMessage("");
          }, 4000);
        }
        triggerThought();
      }, nextThought);
    };
    triggerThought();
    return () => clearTimeout(timeoutId);
  }, [activeWarning, isPanelOpen]);
`;

code = code.replace(
  'const { profile } = useAuth();',
  'const { profile } = useAuth();\n' + thoughtsHook
);

fs.writeFileSync('src/components/GuardianOrb.tsx', code);
