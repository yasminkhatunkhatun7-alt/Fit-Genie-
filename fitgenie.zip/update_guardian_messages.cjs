const fs = require('fs');

let ctx = fs.readFileSync('src/context/GuardianContext.tsx', 'utf8');
ctx = ctx.replace(/const triggerEvent = \(type: string, data\?: any\) => \{[\s\S]*?break;\n    \}\n  \};/, 
`const triggerEvent = (type: string, data?: any) => {
    switch (type) {
      case "challenge_complete":
        setEmotion("celebration");
        const msg = ["Nice work.", "Discipline detected.", "Respect.", "Keep going warrior."][Math.floor(Math.random() * 4)];
        setMessage(msg);
        addObservation("Challenge completed.");
        setTimeout(() => {
          setEmotion("happy");
          setMessage("Keep going.");
        }, 5000);
        break;
      case "suspicious":
        setEmotion("suspicious");
        const susp = ["100 pushups in 3 seconds?", "Interesting.", "Either you're Superman...", "...or you're pressing buttons."][Math.floor(Math.random() * 4)];
        setMessage(susp);
        addObservation("Suspicious activity observed.");
        break;
      case "focused":
        setEmotion("focused");
        setMessage("Tracking your progress.");
        break;
      case "inactive":
        setEmotion("inactive");
        setMessage("Bro... even Avengers take rest.");
        break;
      case "happy":
        setEmotion("happy");
        setMessage(data?.message || "Nice work.");
        break;
      case "cheating":
        setEmotion("warning");
        setMessage("Bro... what body banega tera?");
        break;
    }
  };`);
fs.writeFileSync('src/context/GuardianContext.tsx', ctx);
