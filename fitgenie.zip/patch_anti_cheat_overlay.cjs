const fs = require('fs');

let code = fs.readFileSync('src/components/AntiCheatOverlay.tsx', 'utf8');

code = code.replace(/SORRY FIT GENIE/g, "Sorry Genie, ab se honest workout karunga.");
code = code.replace(/if \(apology === "Sorry Genie, ab se honest workout karunga\."\)/, 'if (apology.toLowerCase().replace(/[^a-z]/g, "") === "sorrygenieabsehonestworkoutkarunga")');

fs.writeFileSync('src/components/AntiCheatOverlay.tsx', code);
