const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

code = code.replace(
  '                    animate={{ opacity: 1, y: 0 }}',
  '                    animate={{ opacity: 1, y: 0 }}\n                    transition={{ delay: index * 0.05, duration: 0.3, ease: "easeOut" }}'
);

fs.writeFileSync('src/components/WorldChat.tsx', code);
