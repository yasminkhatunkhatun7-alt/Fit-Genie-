const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

code = code.replace(
  '  console.log("[App.tsx] Rendering AppContent. showSplash:", showSplash, "loading:", loading, "user:", !!user, "isOnboardingDone:", isOnboardingDone, "view:", view);\n',
  ''
);

code = code.replace(
  '      {/* Debug: check if view is empty */}\n      {view === undefined && <div className="p-10 text-red-500">View is undefined!</div>}',
  ''
);

fs.writeFileSync('src/App.tsx', code);
