const fs = require('fs');
let code = fs.readFileSync('src/components/CustomChallengeDetailScreen.tsx', 'utf-8');

code = code.replace(
  'if (checkCheat(ex.name, amount)) {',
  'if (!fromAI && checkCheat(ex.name, amount)) {'
);

fs.writeFileSync('src/components/CustomChallengeDetailScreen.tsx', code);
