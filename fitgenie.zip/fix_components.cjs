const fs = require('fs');

const files = [
  'src/components/SpeedChallengeScreen.tsx',
  'src/components/StrengthChallengeScreen.tsx',
  'src/components/WeeklyChallengeScreen.tsx',
  'src/components/CustomChallengeDetailScreen.tsx',
];

for (const file of files) {
  let code = fs.readFileSync(file, 'utf8');
  
  // Find where it got messed up:
  const brokenStartMatch = code.match(/export default function ([A-Za-z0-9_]+)\(\{\s*const \{\s*cooldown/);
  if (brokenStartMatch) {
     // Wait, let's just use replace to fix it.
     code = code.replace(/export default function ([A-Za-z0-9_]+)\(\{\s*const \{[\s\S]*?useIntegrityEngine\(challenge\.id\);\s*challenge, onUpdate([^)]*)\) \{/g, 
        `export default function $1({ challenge, onUpdate$2) {
  const {
    cooldown,
    suspiciousPhase,
    lockEndTime,
    validateAndAddReps,
    proceedFromAlert,
    proceedFromMotivation,
    submitApology,
    resetSessionTime
  } = useIntegrityEngine(challenge.id);`);
     fs.writeFileSync(file, code);
  } else {
     console.log("Not broken or different in " + file);
     // maybe challenge is any
     code = code.replace(/export default function ([A-Za-z0-9_]+)\(\{\s*const \{[\s\S]*?useIntegrityEngine\(challenge\.id\);\s*challenge, onUpdate/g, 
        `export default function $1({ challenge, onUpdate`);
     fs.writeFileSync(file, code);
  }
}
