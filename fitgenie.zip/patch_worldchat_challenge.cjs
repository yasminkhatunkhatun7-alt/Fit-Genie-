const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

// 1. Add AiRepCounter import and swords icon
const importsMatch = `import { Globe, Send, ShieldAlert, Zap, Loader2, Trash2, Trophy, Award, Search, UserPlus, UserCheck, Ban, Flag, RefreshCw } from "lucide-react";`;
const importsNew = `import { Globe, Send, ShieldAlert, Zap, Loader2, Trash2, Trophy, Award, Search, UserPlus, UserCheck, Ban, Flag, RefreshCw, Swords } from "lucide-react";
import { AiRepCounter } from "./AiRepCounter";`;
if (!code.includes('import { AiRepCounter }')) {
  code = code.replace(importsMatch, importsNew);
}

// 2. Add state
const stateMatch = `  const [searchQuery, setSearchQuery] = useState("");
  const [searchResult, setSearchResult] = useState<LeaderboardEntry | null>(null);`;
const stateNew = `  const [searchQuery, setSearchQuery] = useState("");
  const [searchResult, setSearchResult] = useState<LeaderboardEntry | null>(null);
  const [showAiCounter, setShowAiCounter] = useState(false);
  const [challengeTarget, setChallengeTarget] = useState<{userId: string, userName: string, score: number, exercise: "Squats"|"Pushups"} | null>(null);`;
if (!code.includes('const [challengeTarget, setChallengeTarget]')) {
  code = code.replace(stateMatch, stateNew);
}

// 3. Render AiRepCounter
const renderMatch = `  return (
    <div className="flex flex-col h-full bg-[#050B1A] p-4 font-sans max-h-screen">`;
const renderNew = `  return (
    <div className="flex flex-col h-full bg-[#050B1A] p-4 font-sans max-h-screen">
      {showAiCounter && (
        <AiRepCounter
          initialExercise={challengeTarget ? challengeTarget.exercise : "Squats"}
          challengeTarget={challengeTarget || undefined}
          onClose={() => {
            setShowAiCounter(false);
            setChallengeTarget(null);
            fetchLeaderboard(); // refresh in case they won
          }}
          onComplete={() => {
            setShowAiCounter(false);
            setChallengeTarget(null);
            fetchLeaderboard();
          }}
        />
      )}`;
if (!code.includes('<AiRepCounter')) {
  code = code.replace(renderMatch, renderNew);
}

// 4. Add "Beat This Score" button to the leaderboard list
const buttonMatch = `                    {!isMe && (
                      <div className="flex flex-col gap-1 items-end">
                        <button onClick={() => blockUser(athlete.userId)} className="text-[8px] uppercase font-bold text-red-400 hover:text-red-300">Block</button>
                        <button onClick={() => reportUser(athlete.userId)} className="text-[8px] uppercase font-bold text-orange-400 hover:text-orange-300">Report</button>
                      </div>
                    )}`;
const buttonNew = `                    {!isMe && (
                      <div className="flex gap-2 items-center">
                        {leaderboardType.endsWith('_1min') && (
                           <button 
                             onClick={() => {
                               const score = leaderboardType === "squats_1min" ? (athlete.bestSquat1Min || 0) : (athlete.bestPushup1Min || 0);
                               const exercise = leaderboardType === "squats_1min" ? "Squats" : "Pushups";
                               setChallengeTarget({ userId: athlete.userId, userName: athlete.userName, score, exercise });
                               setShowAiCounter(true);
                             }}
                             className="flex items-center gap-1 bg-[#14F1E1]/20 border border-[#14F1E1]/50 text-[#14F1E1] hover:bg-[#14F1E1]/30 px-2 py-1.5 rounded-lg transition-all"
                           >
                             <Swords className="w-3 h-3" />
                             <span className="text-[9px] font-black uppercase tracking-widest">Beat</span>
                           </button>
                        )}
                        <div className="flex flex-col gap-1 items-end ml-1">
                          <button onClick={() => blockUser(athlete.userId)} className="text-[8px] uppercase font-bold text-red-400 hover:text-red-300">Block</button>
                          <button onClick={() => reportUser(athlete.userId)} className="text-[8px] uppercase font-bold text-orange-400 hover:text-orange-300">Report</button>
                        </div>
                      </div>
                    )}`;
if (!code.includes('className="flex items-center gap-1 bg-[#14F1E1]/20 border border-[#14F1E1]/50 text-[#14F1E1] hover:bg-[#14F1E1]/30 px-2 py-1.5 rounded-lg transition-all"')) {
  code = code.replace(buttonMatch, buttonNew);
}

fs.writeFileSync('src/components/WorldChat.tsx', code);
console.log("Patched WorldChat.tsx for Ghost Challenges");
