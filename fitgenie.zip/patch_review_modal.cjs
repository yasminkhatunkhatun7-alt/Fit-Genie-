const fs = require('fs');

let code = fs.readFileSync('src/components/DailyChallengeDetailScreen.tsx', 'utf8');

if (!code.includes('ChallengeReviewModal')) {
  code = "import ChallengeReviewModal from './ChallengeReviewModal';\n" + code;
}

// Replace handleClaimXP
code = code.replace(/  const handleClaimXP = async \(\) => \{[\s\S]*?    setShowCompletion\(true\);\n  \};/, 
`  const [showReviewModal, setShowReviewModal] = useState(false);

  const handleClaimXP = async () => {
    if (!honorChecked) return;
    setShowHonorValidation(false);
    setShowReviewModal(true);
  };

  const finalizeClaimXP = async () => {
    setShowReviewModal(false);
    playSound("success");
    if (!hasClaimed) {
      const result = await onComplete(challenge.xpReward);
      if (result === false) return; // Validation failed
      localStorage.setItem(claimedKey, "true");
      setHasClaimed(true);
      setJustClaimed(true);
    }
    setShowCompletion(true);
  };
`);

// Add the modal to the render
const renderTarget = '  if (showHonorValidation) {';
const modalUI = `
  if (showReviewModal) {
    return (
      <ChallengeReviewModal
        progressValid={true} // Passed real-time checks
        activityValid={true}
        consistencyValid={true}
        onProceed={finalizeClaimXP}
        onCancel={() => setShowReviewModal(false)}
      />
    );
  }
`;

if (!code.includes('if (showReviewModal) {')) {
  code = code.replace(renderTarget, modalUI + '\n' + renderTarget);
}

fs.writeFileSync('src/components/DailyChallengeDetailScreen.tsx', code);
