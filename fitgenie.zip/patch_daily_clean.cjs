const fs = require('fs');

let code = fs.readFileSync('src/components/DailyChallengeDetailScreen.tsx', 'utf8');

// The replacement I previously made was:
// code = code.replace(/  if \(cheatTier > 0\) \{[\s\S]*?  \}/, overlayRender);
// Because I matched `  }`, it probably stopped at the first brace.

// Find the block starting at "else if (cheatTier === 2)" up to "if (showManualInput)"
code = code.replace(/ else if \(cheatTier === 2\) \{[\s\S]*?if \(showManualInput\)/, "  if (showManualInput)");

fs.writeFileSync('src/components/DailyChallengeDetailScreen.tsx', code);
