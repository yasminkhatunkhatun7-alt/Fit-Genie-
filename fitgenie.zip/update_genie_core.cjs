const fs = require('fs');

let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

const oldCore = `          {/* Genie Core */}
          <motion.div 
            className="w-20 h-20 rounded-full relative flex items-center justify-center overflow-hidden"
            animate={{
              boxShadow: [
                \`0 0 20px \${color}, inset 0 0 30px \${color}\`,
                \`0 0 50px \${color}, inset 0 0 60px \${color}\`,
                \`0 0 20px \${color}, inset 0 0 30px \${color}\`
              ],
              y: [0, -8, 0] // Floating motion
            }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          >
            {/* Breathing Core */}
            <motion.div 
              className="absolute inset-0 bg-white/20 rounded-full blur-md"
              animate={{ scale: [0.8, 1.1, 0.8], opacity: [0.3, 0.6, 0.3] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
            />
            
            <div className="absolute inset-0 bg-gradient-to-tr from-black/50 to-transparent z-10" />
            <div className="absolute inset-0 backdrop-blur-sm" />
            
            {/* Intelligent Eye Movement Wrapper */}
            <motion.div
              animate={{
                x: [0, 4, -4, 0, 0],
                y: [0, -2, 2, 0, 0]
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                times: [0, 0.2, 0.4, 0.6, 1],
                ease: "easeInOut"
              }}
              className="relative z-20"
            >
              {renderEyes()}
            </motion.div>
          </motion.div>`;

const newCore = `          {/* 3D High-Fidelity Genie Core */}
          <motion.div 
            className="w-24 h-24 relative flex items-center justify-center"
            animate={{
              y: [0, -10, 0]
            }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          >
             <svg width="100%" height="100%" viewBox="0 0 100 100" className="absolute inset-0 z-0 overflow-visible">
               <defs>
                 <radialGradient id="coreGlow" cx="50%" cy="50%" r="50%">
                   <stop offset="0%" stopColor={color} stopOpacity="1" />
                   <stop offset="40%" stopColor={color} stopOpacity="0.8" />
                   <stop offset="100%" stopColor={color} stopOpacity="0" />
                 </radialGradient>
                 <radialGradient id="innerGlow" cx="35%" cy="35%" r="65%">
                    <stop offset="0%" stopColor="#ffffff" stopOpacity="0.9" />
                    <stop offset="100%" stopColor={color} stopOpacity="0.3" />
                 </radialGradient>
                 <filter id="blurCore" x="-20%" y="-20%" width="140%" height="140%">
                   <feGaussianBlur stdDeviation="3" />
                 </filter>
                 <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="6" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                 </filter>
               </defs>

               {/* Outer pulsating aura */}
               <motion.circle 
                 cx="50" cy="50" r="45" 
                 fill="url(#coreGlow)" 
                 filter="url(#glow)"
                 animate={{ scale: [0.9, 1.15, 0.9], opacity: [0.6, 0.9, 0.6] }}
                 transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
                 style={{ transformOrigin: "50px 50px" }}
               />

               {/* Inner solid energy ball */}
               <motion.circle 
                 cx="50" cy="50" r="32" 
                 fill="url(#innerGlow)"
                 filter="url(#blurCore)"
                 animate={{ scale: [0.95, 1.05, 0.95] }}
                 transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                 style={{ transformOrigin: "50px 50px" }}
               />

               {/* Rotating energy bands */}
               <motion.ellipse
                  cx="50" cy="50" rx="42" ry="12"
                  fill="none"
                  stroke={color}
                  strokeWidth="2.5"
                  strokeOpacity="0.9"
                  filter="url(#glow)"
                  animate={{ rotate: 360, scale: [1, 0.8, 1] }}
                  transition={{ 
                    rotate: { duration: 6, repeat: Infinity, ease: "linear" }, 
                    scale: { duration: 3, repeat: Infinity, ease: "easeInOut" } 
                  }}
                  style={{ transformOrigin: "50px 50px" }}
               />
               <motion.ellipse
                  cx="50" cy="50" rx="15" ry="40"
                  fill="none"
                  stroke="#ffffff"
                  strokeWidth="1.5"
                  strokeOpacity="0.7"
                  filter="url(#blurCore)"
                  animate={{ rotate: -360, scale: [1, 0.9, 1] }}
                  transition={{ 
                    rotate: { duration: 10, repeat: Infinity, ease: "linear" }, 
                    scale: { duration: 5, repeat: Infinity, ease: "easeInOut" } 
                  }}
                  style={{ transformOrigin: "50px 50px" }}
               />
             </svg>

             {/* Dark Overlay for Depth */}
             <div className="absolute inset-0 bg-gradient-to-tr from-black/50 to-transparent rounded-full z-10" style={{ width: '64%', height: '64%', margin: '18%' }} />
             
             {/* Glass/Blur Layer */}
             <div className="absolute inset-0 backdrop-blur-[1px] rounded-full z-10" style={{ width: '64%', height: '64%', margin: '18%' }} />

            {/* Intelligent Eye Movement Wrapper */}
            <motion.div
              animate={{
                x: [0, 5, -5, 0, 0],
                y: [0, -3, 3, 0, 0]
              }}
              transition={{
                duration: 7,
                repeat: Infinity,
                times: [0, 0.25, 0.5, 0.75, 1],
                ease: "easeInOut"
              }}
              className="relative z-20"
            >
              {renderEyes()}
            </motion.div>
          </motion.div>`;

code = code.replace(oldCore, newCore);

fs.writeFileSync('src/components/GuardianOrb.tsx', code);
