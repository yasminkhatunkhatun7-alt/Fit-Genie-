const fs = require('fs');
let code = fs.readFileSync('src/components/MartialArts.tsx', 'utf-8');

// Add restTimerLeft state
if (!code.includes("const [restTimerLeft, setRestTimerLeft] = useState<number | null>(null);")) {
  code = code.replace(
    'const [showConfirmModal, setShowConfirmModal] = useState<{ isOpen: boolean } | null>(null);',
    'const [showConfirmModal, setShowConfirmModal] = useState<{ isOpen: boolean } | null>(null);\n  const [restTimerLeft, setRestTimerLeft] = useState<number | null>(null);\n\n  useEffect(() => {\n    if (restTimerLeft === null) return;\n    if (restTimerLeft <= 0) {\n      playSound("rest_chime");\n      setRestTimerLeft(null);\n      return;\n    }\n    const timerId = setInterval(() => {\n      setRestTimerLeft(prev => (prev ? prev - 1 : 0));\n    }, 1000);\n    return () => clearInterval(timerId);\n  }, [restTimerLeft]);'
  );
}

// Replace the UI
const restRegex = /<div className="bg-\[#004D40\] border border-\[#1DE9B6\]\/20 p-2\.5 rounded-xl text-center">\s*<span className="text-teal-300\/70 block text-\[8px\] font-bold">Resting Timer<\/span>\s*<span className="text-\[#1DE9B6\] font-extrabold text-xs">45 Secs<\/span>\s*<\/div>/;

const newRestTimerUI = `<button 
                      onClick={() => {
                        if (restTimerLeft !== null) {
                          playSound("timer_pause");
                          setRestTimerLeft(null);
                        } else {
                          playSound("timer_start");
                          setRestTimerLeft(45);
                        }
                      }}
                      className={\`p-2.5 rounded-xl text-center border transition-colors duration-300 \${restTimerLeft !== null ? 'bg-[#1DE9B6]/20 border-[#1DE9B6]' : 'bg-[#004D40] border-[#1DE9B6]/20 hover:bg-[#004D40]/80'}\`}
                    >
                      <span className="text-teal-300/70 block text-[8px] font-bold flex justify-center items-center gap-1">
                        Resting Timer
                        {restTimerLeft === null && <Play className="w-2 h-2" />}
                      </span>
                      <span className="text-[#1DE9B6] font-extrabold text-xs">
                        {restTimerLeft !== null ? \`\${restTimerLeft} Secs\` : '45 Secs'}
                      </span>
                    </button>`;

if (code.match(restRegex)) {
  code = code.replace(restRegex, newRestTimerUI);
  fs.writeFileSync('src/components/MartialArts.tsx', code);
  console.log("Patched MartialArts");
} else {
  console.log("Could not find regex in MartialArts");
}
