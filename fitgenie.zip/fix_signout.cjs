const fs = require('fs');
let file = fs.readFileSync('src/components/SettingsScreen.tsx', 'utf8');

file = file.replace(/logout/g, 'signOutUser');

fs.writeFileSync('src/components/SettingsScreen.tsx', file);
