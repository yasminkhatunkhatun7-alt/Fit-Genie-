console.log("Animation successfully added");
