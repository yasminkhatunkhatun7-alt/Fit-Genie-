const fs = require('fs');

const files = [
  'src/components/WeeklyChallengeScreen.tsx',
  'src/components/SpeedChallengeScreen.tsx',
  'src/components/StrengthChallengeScreen.tsx',
  'src/components/CustomChallengeDetailScreen.tsx'
];

for (const file of files) {
  let content = fs.readFileSync(file, 'utf8');
  if (content.includes('if (suspiciousPhase !== \'none\')')) continue;
  
  const block = `
  if (suspiciousPhase !== 'none') {
    return (
      <AntiCheatOverlay 
        suspiciousPhase={suspiciousPhase as any}
        lockEndTime={lockEndTime}
        onProceedFromAlert={proceedFromAlert}
        onProceedFromMotivation={proceedFromMotivation}
        onSubmitApology={submitApology}
      />
    );
  }
`;
  content = content.replace(/return \(\s*<div/, block + '\n  return (\n    <div');
  fs.writeFileSync(file, content);
}
