const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');
code = code.replace(
  'const q = query(collection(db, "activityFeed"), orderBy("timestamp", "asc"), limit(100));',
  'console.log("DB is:", db);\n      const q = query(collection(db, "activityFeed"), orderBy("timestamp", "asc"), limit(100));'
);
fs.writeFileSync('src/components/WorldChat.tsx', code);
