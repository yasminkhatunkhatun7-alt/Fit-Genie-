const fs = require('fs');
let code = fs.readFileSync('src/types.ts', 'utf-8');
code = code.replace(/\\n/g, '\n');
code = code.replace(/\| "achievements"\n  \| "world"\n  \| "achievements"\n  \| "world"/g, '| "achievements"\n  | "world"');
fs.writeFileSync('src/types.ts', code);
console.log("Fixed types.ts");
