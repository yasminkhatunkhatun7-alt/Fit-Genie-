const fs = require('fs');
let code = fs.readFileSync('src/components/CustomChallengeDetailScreen.tsx', 'utf-8');

// Update handleAddReps
code = code.replace(
  'const handleAddReps = (index: number, amount: number) => {',
  'const handleAddReps = (index: number, amount: number, fromAI: boolean = false) => {'
);
code = code.replace(
  'if (checkCheat(ex.name, amount)) {',
  'if (!fromAI && checkCheat(ex.name, amount)) {'
);

// Add AI State & Component
if (!code.includes('showAiCounter')) {
  code = code.replace(
    'const [justClaimed, setJustClaimed] = useState(false);',
    'const [justClaimed, setJustClaimed] = useState(false);\n  const [showAiCounter, setShowAiCounter] = useState(false);\n  const [aiExerciseIndex, setAiExerciseIndex] = useState(0);'
  );
}
if (!code.includes('AiRepCounter')) {
  code = code.replace(
    'import { playSound } from "../utils/audio";',
    'import { playSound } from "../utils/audio";\nimport { AiRepCounter } from "./AiRepCounter";\nimport { Camera } from "lucide-react";'
  );
}

// Replace controls
// Find: <div className="flex gap-3 relative">
// Replace it until the end of the AnimatePresence or the end of the block

const controlsRegex = /<div className="flex gap-3 relative">[\s\S]*?<\/div>\n                \)}/g;

code = code.replace(controlsRegex, `<div className="flex gap-3 relative">
                    {(ex.name.toLowerCase().includes('pushup') || ex.name.toLowerCase().includes('squat')) ? (
                       <motion.button 
                         whileTap={{ scale: 0.95 }}
                         onClick={() => {
                           setAiExerciseIndex(index);
                           setShowAiCounter(true);
                         }}
                         className="flex-1 bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-xs py-4 rounded-xl flex justify-center items-center gap-2 shadow-[0_0_20px_rgba(20,241,225,0.4)] transition-all uppercase tracking-widest"
                       >
                         <Camera className="w-4 h-4" />
                         AI TRACKER
                       </motion.button>
                     ) : (
                       <div className="flex-1 bg-white/5 border border-white/10 text-neutral-400 font-bold text-[10px] py-4 rounded-xl flex justify-center items-center text-center px-2 uppercase tracking-widest">
                         Manual Tracking Disabled
                       </div>
                     )}
                  </div>
                )}`);

const aiCounterModal = `
      {showAiCounter && (
        <AiRepCounter
          initialExercise={challenge.exercises[aiExerciseIndex]?.name.toLowerCase().includes('squat') ? "Squats" : "Pushups"}
          onClose={() => setShowAiCounter(false)}
          onComplete={(reps) => {
            if (reps > 0) {
              handleAddReps(aiExerciseIndex, reps, true);
            }
            setShowAiCounter(false);
          }}
        />
      )}`;

const lastDiv = '    </div>\n  );\n}';
if (code.includes(lastDiv) && !code.includes('AiRepCounter initialExercise=')) {
  code = code.replace(lastDiv, aiCounterModal + '\n    </div>\n  );\n}');
}

fs.writeFileSync('src/components/CustomChallengeDetailScreen.tsx', code);
console.log('Fixed Custom');
