const fs = require('fs');
let content = fs.readFileSync('src/components/ProfileView.tsx', 'utf8');

content = content.replace(/<button onClick=\{\(\) => \{ playSound\("click"\); setIsEditing\(!isEditing\); \}\} className="w-10 h-10.*?<\/button>/, '');
content = content.replace(/\{isEditing \? \([\s\S]*?\) : \(/, '(');
content = content.replace(/<\/div>\n\s*\}\)\n\s*<\/motion.div>/, '</div>\n      </motion.div>');
// Fix parenthesis from ternary
content = content.replace(/<\/div>\n\s*\)\}\n\s*<\/motion.div>/, '</div>\n      </motion.div>');

fs.writeFileSync('src/components/ProfileView.tsx', content);
