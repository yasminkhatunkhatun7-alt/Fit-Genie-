const fs = require('fs');
let code = fs.readFileSync('src/components/WorkoutHistory.tsx', 'utf-8');

// Add import
if (!code.includes('import WorkoutProgressChart')) {
  code = code.replace(
    'import { CompletedSession } from "../types";',
    'import { CompletedSession } from "../types";\nimport WorkoutProgressChart from "./WorkoutProgressChart";'
  );
}

// Inject D3 component above history-analytics-block
const target = '{/* Interactive Chart Component and Quick Insights */}';
if (code.includes(target) && !code.includes('<WorkoutProgressChart')) {
  code = code.replace(
    target,
    `{/* 30-Day D3 Line Chart */}\n          <WorkoutProgressChart history={history} />\n\n          ${target}`
  );
}

fs.writeFileSync('src/components/WorkoutHistory.tsx', code);
console.log("Patched WorkoutHistory.tsx");
