const fs = require('fs');

let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

code = code.replace(
  "const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;",
  "const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;"
);

fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done');
