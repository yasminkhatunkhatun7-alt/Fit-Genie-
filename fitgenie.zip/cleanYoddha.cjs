const fs = require('fs');
let yh = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');

const toRemove = [
  /  \/\/ Advanced Recovery Mode States\n  const \[recoveryDaysCompleted, setRecoveryDaysCompleted\] = useLocalStorageSync<number>\("fitgenie_rec_days_completed", 5\);\n  const \[stretchingSessions, setStretchingSessions\] = useLocalStorageSync<number>\("fitgenie_stretch_sessions", 3\);\n  const \[mobilitySessions, setMobilitySessions\] = useLocalStorageSync<number>\("fitgenie_mobility_sessions", 2\);\n  const \[restDayStreak, setRestDayStreak\] = useLocalStorageSync<number>\("fitgenie_rest_streak", 1\);\n  const \[activeRecoveryRoutine, setActiveRecoveryRoutine\] = useState<\{ pose: string; min: string; category: string; cal: number; seconds: number \} \| null>\(null\);\n  const \[routineTimer, setRoutineTimer\] = useState<number>\(0\);\n  const \[timerIsRunning, setTimerIsRunning\] = useState<boolean>\(false\);\n/g,
  /  \/\/ Simulated Recovery Logs\n  interface RecoveryDayLog \{\n    id: string;\n    date: string;\n    score: number;\n    sorenessAvg: number;\n    fatigue: number;\n    energy: number;\n    routineDone\?: string;\n  \}\n  const \[recoveryLogs, setRecoveryLogs\] = useLocalStorageSync<RecoveryDayLog\[\]>\("fitgenie_recovery_logs", \[\n    \{ id: "rec_1", date: "2026-06-11", score: 85, sorenessAvg: 1.2, fatigue: 25, energy: 80, routineDone: "Desi Active Jog-Walk Loop" \},\n    \{ id: "rec_2", date: "2026-06-12", score: 72, sorenessAvg: 2.8, fatigue: 55, energy: 60, routineDone: "Deep Squat Hold Flow" \},\n    \{ id: "rec_3", date: "2026-06-13", score: 91, sorenessAvg: 0.8, fatigue: 15, energy: 95, routineDone: "Rest Day" \},\n    \{ id: "rec_4", date: "2026-06-14", score: 62, sorenessAvg: 3.5, fatigue: 70, energy: 40 \},\n    \{ id: "rec_5", date: "2026-06-15", score: 88, sorenessAvg: 1.0, fatigue: 20, energy: 85, routineDone: "Warrior Pose Stretch" \}\n  \]\);\n/g,
  /  \/\/ Routine countdown timer effect\n  useEffect\(\(\) => \{[\s\S]*?  \}, \[timerIsRunning, routineTimer, activeRecoveryRoutine\]\);\n/g,
  /  \/\/ Combined Recovery Calculations\n  const calculatedRecoveryScore = useMemo\(\(\) => \{[\s\S]*?  \}, \[calculatedRecoveryScore\]\);\n/g,
  /  const broCoachRecoveryTip = useMemo\(\(\) => \{[\s\S]*?  \}, \[calculatedRecoveryScore, sorenessSurvey\]\);\n/g
];

toRemove.forEach(regex => {
  yh = yh.replace(regex, "");
});

fs.writeFileSync('src/components/YoddhaHub.tsx', yh);
