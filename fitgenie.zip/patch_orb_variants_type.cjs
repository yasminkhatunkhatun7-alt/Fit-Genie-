const fs = require('fs');
let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

code = code.replace('const orbVariants = {', 'const orbVariants: any = {');

fs.writeFileSync('src/components/GuardianOrb.tsx', code);
