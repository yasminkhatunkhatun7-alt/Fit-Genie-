const fs = require('fs');

let code = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

const regex = /\s*\{\/\* DAILY MISSIONS \*\/\}\s*<motion\.div initial=\{\{ opacity: 0, y: 20 \}\} animate=\{\{ opacity: 1, y: 0 \}\} transition=\{\{ delay: 0\.3 \}\}>\s*<DailyMissions.*?\/>\s*<\/motion\.div>/;

code = code.replace(regex, '');

fs.writeFileSync('src/components/HomeDashboard.tsx', code);
