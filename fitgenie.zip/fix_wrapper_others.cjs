const fs = require('fs');

const speedFile = 'src/components/SpeedChallengeScreen.tsx';
let speedContent = fs.readFileSync(speedFile, 'utf8');
speedContent = speedContent.replace(
  /const handleAddReps = \(amount: number\) => \{\n    if \(isCompleted \|\| hasClaimedToday \|\| showCheatWarning \|\| showFail\) return;\n    \n    if \(amount === 1 && cooldown1 > 0\) return;/g,
  `const handleAddReps = (amount: number) => {\n    if (isCompleted || hasClaimedToday || showCheatWarning || showFail) return;\n    \n    if (amount === 1 && cooldown1 > 0) return;\n    validateAndAddReps(exercise.name, amount, undefined, () => {`
);
speedContent = speedContent.replace(
  /    onUpdate\(updated\);\n  \};\n/g,
  `    onUpdate(updated);\n    }, () => {\n      const updated = { ...challenge };\n      updated.exercises[0].completedReps = 0;\n      onUpdate(updated);\n    });\n  };\n`
);
fs.writeFileSync(speedFile, speedContent);

const strengthFile = 'src/components/StrengthChallengeScreen.tsx';
let strengthContent = fs.readFileSync(strengthFile, 'utf8');
strengthContent = strengthContent.replace(
  /const handleAddReps = \(amount: number\) => \{\n    if \(isCompleted \|\| hasClaimedToday \|\| showCheatWarning\) return;\n    \n    if \(amount === 1 && cooldown1 > 0\) return;/g,
  `const handleAddReps = (amount: number) => {\n    if (isCompleted || hasClaimedToday || showCheatWarning) return;\n    \n    if (amount === 1 && cooldown1 > 0) return;\n    validateAndAddReps(exercise.name, amount, undefined, () => {`
);
strengthContent = strengthContent.replace(
  /    onUpdate\(updated\);\n  \};\n/g,
  `    onUpdate(updated);\n    }, () => {\n      const updated = { ...challenge };\n      updated.exercises[0].completedReps = 0;\n      onUpdate(updated);\n    });\n  };\n`
);
fs.writeFileSync(strengthFile, strengthContent);

const weeklyFile = 'src/components/WeeklyChallengeScreen.tsx';
let weeklyContent = fs.readFileSync(weeklyFile, 'utf8');
weeklyContent = weeklyContent.replace(
  /const handleAddReps = \(amount: number\) => \{\n    if \(isCompleted \|\| hasClaimedThisWeek \|\| showCheatWarning\) return;\n    \n    if \(amount === 1 && cooldown1 > 0\) return;/g,
  `const handleAddReps = (amount: number) => {\n    if (isCompleted || hasClaimedThisWeek || showCheatWarning) return;\n    \n    if (amount === 1 && cooldown1 > 0) return;\n    validateAndAddReps(exercise.name, amount, undefined, () => {`
);
weeklyContent = weeklyContent.replace(
  /    addRepsInternal\(amount\);\n  \};\n/g,
  `    addRepsInternal(amount);\n    }, () => {\n      const updated = { ...challenge };\n      updated.exercises[0].completedReps = 0;\n      onUpdate(updated);\n    });\n  };\n`
);
fs.writeFileSync(weeklyFile, weeklyContent);

const customFile = 'src/components/CustomChallengeDetailScreen.tsx';
let customContent = fs.readFileSync(customFile, 'utf8');
customContent = customContent.replace(
  /const handleAddReps = \(exerciseIndex: number, amount: number\) => \{\n    if \(isCompleted \|\| hasClaimed \|\| showCheatWarning\) return;\n    \n    if \(amount === 1 &&/g,
  `const handleAddReps = (exerciseIndex: number, amount: number) => {\n    if (isCompleted || hasClaimed || showCheatWarning) return;\n    \n    if (amount === 1 &&`
);
// In custom, we have multiple exercises. Let's just wrap `addRepsInternal` call.
customContent = customContent.replace(
  /    addRepsInternal\(exerciseIndex, amount\);\n  \};\n/g,
  `    validateAndAddReps(challenge.exercises[exerciseIndex].name, amount, undefined, () => {\n      addRepsInternal(exerciseIndex, amount);\n    }, () => {\n      const updated = { ...challenge };\n      updated.exercises[exerciseIndex].completedReps = 0;\n      onUpdate(updated);\n    });\n  };\n`
);
fs.writeFileSync(customFile, customContent);
