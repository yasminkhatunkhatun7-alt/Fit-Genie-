const fs = require('fs');

let ctx = fs.readFileSync('src/context/GuardianContext.tsx', 'utf8');

const oldSwitch = `  const triggerEvent = (type: string, data?: any) => {
    switch (type) {
      case "challenge_complete":
        setEmotion("celebrating");
        setMessage("Excellent work.");
        addObservation("Challenge completed.");
        setTimeout(() => {
          setEmotion("happy");
          setMessage("Keep going.");
        }, 5000);
        break;
      case "boss_fight":
        setEmotion("focused");
        setMessage("Attack the boss.");
        break;
      case "level_up":
        setEmotion("celebrating");
        setMessage("Another step forward.");
        addObservation("Leveled up.");
        break;
      case "suspicious":
        setEmotion("suspicious");
        const susp = ["100 pushups in 3 seconds?", "Hmm.", "Interesting.", "Genie has questions.", "Physics disagrees.", "Nice try 😏", "Genie is not convinced."][Math.floor(Math.random() * 7)];
        setMessage(susp);
        addObservation("Suspicious activity observed.");
        break;
      case "focused":
      case "challenge_active":
        setEmotion("focused");
        setMessage("I'm watching.");
        break;
      case "home_greet":
        setEmotion("happy");
        const greets = ["Ready for today's mission?", "Boss still has HP left.", "Let's continue."];
        setMessage(greets[Math.floor(Math.random() * greets.length)]);
        break;
      case "inactive":
      case "sleepy":
        setEmotion("sleepy");
        setMessage("Your muscles miss you.");
        break;
      case "happy":
        setEmotion("happy");
        setMessage(data?.message || "Nice work.");
        break;
      case "cheating":
      case "angry":
        setEmotion("angry");
        const ang = ["Bro... even superheroes need time.", "You're training buttons."];
        setMessage(ang[Math.floor(Math.random() * ang.length)]);
        break;
      case "streak_7":
        setEmotion("happy");
        setMessage("Momentum is building.");
        addObservation("7-day streak achieved.");
        break;
      case "streak_30":
        setEmotion("happy");
        setMessage("You're changing.");
        addObservation("30-day streak achieved.");
        break;
      case "streak_90":
        setEmotion("celebrating");
        setMessage("Legendary consistency.");
        addObservation("90-day streak achieved.");
        break;
      case "thinking":
        setEmotion("thinking");
        setMessage(data?.message || "Thinking...");
        break;
    }
  };`;

const newSwitch = `  const triggerEvent = (type: string, data?: any) => {
    switch (type) {
      case "challenge_complete":
        setEmotion("celebrating");
        setMessage("Ohooo level up! 🔥");
        addObservation("Challenge completed.");
        setTimeout(() => {
          setEmotion("happy");
          setMessage("Ab baat ban rahi hai.");
        }, 5000);
        break;
      case "boss_fight":
        setEmotion("focused");
        const bossMsgs = ["Maar bro!", "Boss ka HP gir raha hai.", "Ye attack heavy tha.", "Titan dar raha hai.", "Aaj usko rula dete hain."];
        setMessage(data?.message || bossMsgs[Math.floor(Math.random() * bossMsgs.length)]);
        break;
      case "level_up":
        setEmotion("celebrating");
        setMessage("Ohooo level up! 🔥 Warrior stronger ho gaya.");
        addObservation("Leveled up.");
        break;
      case "suspicious":
        setEmotion("suspicious");
        const susp = [
          "50 pushups 3 second me? 😏",
          "Bro sach sach bata.",
          "Itni speed se to loading screen bhi nahi khulti.",
          "Bro tu workout kar raha hai ya speedrun?",
          "Physics disagree kar rahi hai."
        ];
        setMessage(susp[Math.floor(Math.random() * susp.length)]);
        addObservation("Suspicious activity observed.");
        break;
      case "focused":
      case "challenge_active":
        setEmotion("focused");
        const activeMsg = ["Main dekh raha hu bro.", "Form bhi sahi rakhna.", "Let's go warrior."];
        setMessage(data?.message || activeMsg[Math.floor(Math.random() * activeMsg.length)]);
        break;
      case "motivation":
        setEmotion("happy");
        const motiv = ["Bas ek set aur.", "Future wala tu thank karega.", "Consistency > Motivation.", "Give up mat kar bro."];
        setMessage(data?.message || motiv[Math.floor(Math.random() * motiv.length)]);
        break;
      case "home_greet":
        setEmotion("happy");
        const greets = ["Ready ho warrior?", "Chal bro aaj ka mission karte hain.", "Aaj boss ko damage dena hai.", "Bas shuru kar."];
        setMessage(greets[Math.floor(Math.random() * greets.length)]);
        break;
      case "inactive_1":
        setEmotion("sleepy");
        setMessage("Aaj miss kar diya bro?");
        break;
      case "inactive_3":
        setEmotion("sleepy");
        setMessage("Gym se breakup ho gaya kya?");
        break;
      case "inactive_7":
        setEmotion("sleepy");
        setMessage("Main wait kar raha hu 😭");
        break;
      case "inactive":
      case "sleepy":
        setEmotion("sleepy");
        setMessage("Main wait kar raha hu 😭");
        break;
      case "happy":
        setEmotion("happy");
        setMessage(data?.message || "Badhiya bro.");
        break;
      case "cheating":
      case "angry":
        setEmotion("angry");
        const ang = ["Genie ko bewakoof banana mushkil hai.", "Ye app humans ke liye hai 😏", "Kya body banega bro agar numbers hi increase karoge?"];
        setMessage(ang[Math.floor(Math.random() * ang.length)]);
        break;
      case "streak_7":
        setEmotion("happy");
        setMessage("Momentum ban raha hai bro.");
        addObservation("7-day streak achieved.");
        break;
      case "streak_30":
        setEmotion("happy");
        setMessage("Ab aadat ban rahi hai.");
        addObservation("30-day streak achieved.");
        break;
      case "streak_90":
        setEmotion("celebrating");
        setMessage("Legendary discipline detected.");
        addObservation("90-day streak achieved.");
        break;
      case "thinking":
        setEmotion("thinking");
        setMessage(data?.message || "Hmm...");
        break;
      case "nav_home":
        setEmotion("happy");
        setMessage("Back to base.");
        break;
      case "nav_challenge":
        setEmotion("happy");
        setMessage("Chal bro challenge dekhte hain.");
        break;
      case "nav_workout":
        setEmotion("focused");
        setMessage("Ab kaam ki baat.");
        break;
      case "nav_profile":
        setEmotion("thinking");
        setMessage("Progress check karte hain.");
        break;
    }
  };`;

ctx = ctx.replace(oldSwitch, newSwitch);
fs.writeFileSync('src/context/GuardianContext.tsx', ctx);
