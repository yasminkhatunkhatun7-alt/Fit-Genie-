const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');
code = code.replace(
  'console.log("DB is:", db);',
  'if (!db) { console.error("DB IS UNDEFINED!"); } else { console.log("DB keys:", Object.keys(db)); }'
);
fs.writeFileSync('src/components/WorldChat.tsx', code);
