const fs = require('fs');
let file = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');

// 1. Remove "music" from the YoddhaHub interface
file = file.replace(/\| "music" /g, "");

// 2. Remove states
file = file.replace(/  const \[musicFavorites, setMusicFavorites\] = useLocalStorageSync[^\n]+;\n/g, "");
file = file.replace(/  const \[recentlyPlayed, setRecentlyPlayed\] = useLocalStorageSync[^\n]+;\n/g, "");
file = file.replace(/  const \[totalListeningSecs, setTotalListeningSecs\] = useLocalStorageSync[^\n]+;\n/g, "");
file = file.replace(/  const \[musicSessionCount, setMusicSessionCount\] = useLocalStorageSync[^\n]+;\n/g, "");
file = file.replace(/  const \[activeMusicTrack, setActiveMusicTrack\] = useLocalStorageSync[^\n]+;\n/g, "");
file = file.replace(/  const \[musicTimerRun, setMusicTimerRun\] = useState<boolean>\(false\);\n/g, "");
file = file.replace(/  const \[musicTimerTotal, setMusicTimerTotal\] = useState<number>\(600\);[^\n]+\n/g, "");
file = file.replace(/  const \[musicTimerLeft, setMusicTimerLeft\] = useState<number>\(600\);\n/g, "");

// 3. Remove music timer effect (it has multiple lines)
const timerEffectRegex = /  \/\/ Music timer\n  useEffect\(\(\) => \{[\s\S]*?  \}, \[musicTimerRun, musicTimerLeft\]\);\n/g;
file = file.replace(timerEffectRegex, "");

// 4. Remove music Playlists array (huge)
const musicPlaylistsRegex = /  const musicPlaylists = \[[\s\S]*?\];\n/g;
file = file.replace(musicPlaylistsRegex, "");

// 5. Remove musicCategories array
const musicCatRegex = /  const musicCategories = musicPlaylists;\n/g;
file = file.replace(musicCatRegex, "");

// 6. Remove music tab from the list
file = file.replace(/          \{ id: "music", label: "🎵 Workout Music", icon: "🎧" \},\n/g, "");

// 7. Remove the entire TAB 6 section
const tab6Regex = /          \{\/\* -----------------------------------------\n             TAB 6: MUSIC HUB \("music"\)\n             ----------------------------------------- \*\/\}\n          \{activeSubTab === "music" && \([\s\S]*?          \}\)\n/g;
file = file.replace(tab6Regex, "");

fs.writeFileSync('src/components/YoddhaHub.tsx', file);
