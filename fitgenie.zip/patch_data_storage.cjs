const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');
const searchStr = `                    <div className="text-left space-y-1">
                      <span className="block text-[8.5px] font-mono font-bold text-zinc-500 uppercase font-mono">EDITION ID</span>`;

const newStr = `                    <div className="text-left space-y-1">
                      <span className="block text-[10px] font-mono font-bold text-brand-accent uppercase mt-2">Data Storage: Local Device</span>
                      <p className="text-[9px] text-zinc-400 font-medium leading-normal">
                        Your progress is stored only on this device.
                        If app data is cleared or the device is reset, progress may be lost.
                      </p>
                    </div>
                    <div className="text-left space-y-1 mt-3">
                      <span className="block text-[8.5px] font-mono font-bold text-zinc-500 uppercase font-mono">EDITION ID</span>`;

content = content.replace(searchStr, newStr);
fs.writeFileSync('src/App.tsx', content);
