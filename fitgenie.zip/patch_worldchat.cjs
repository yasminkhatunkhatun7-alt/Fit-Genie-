const fs = require('fs');
let code = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');

// 1. Add Trophy, MessageSquare to imports if not there
if (!code.includes('Trophy')) {
  code = code.replace(
    'import { Globe, Send, ShieldAlert, Zap, Loader2, Trash2 } from "lucide-react";',
    'import { Globe, Send, ShieldAlert, Zap, Loader2, Trash2, Trophy, MessageSquare, Award } from "lucide-react";'
  );
}

// 2. Add interface LeaderboardEntry
if (!code.includes('interface LeaderboardEntry')) {
  code = code.replace(
    'export default function WorldChat() {',
    `interface LeaderboardEntry {
  userId: string;
  userName: string;
  xp: number;
  avatarBg: string;
  lastUpdated: number;
}

export default function WorldChat() {`
  );
}

// 3. Add state for activeTab and leaderboard
const stateTarget = `  const [error, setError] = useState<string | null>(null);`;
const stateReplace = `  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"chat" | "leaderboard">("chat");
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [leaderboardLoading, setLeaderboardLoading] = useState(true);`;
if (!code.includes('activeTab')) {
  code = code.replace(stateTarget, stateReplace);
}

// 4. Update XP to server on mount and load leaderboard
const fetchMessagesTarget = `  // Poll for messages every 2 seconds to simulate live chat
  useEffect(() => {
    fetchMessages();
    const interval = setInterval(fetchMessages, 2000);
    return () => clearInterval(interval);
  }, []);`;

const newEffects = `  // Poll for messages every 2 seconds to simulate live chat
  useEffect(() => {
    if (activeTab === "chat") {
      fetchMessages();
      const interval = setInterval(fetchMessages, 2000);
      return () => clearInterval(interval);
    }
  }, [activeTab]);

  // Fetch leaderboard when switching to it, and post user XP
  useEffect(() => {
    if (activeTab === "leaderboard") {
      fetchLeaderboard();
      const interval = setInterval(fetchLeaderboard, 10000);
      return () => clearInterval(interval);
    }
  }, [activeTab]);

  useEffect(() => {
    const postUserXP = async () => {
      const currentUserId = user?.id || localStorage.getItem("fitgenie_anon_id");
      if (!currentUserId || !profile) return;
      
      const avatarStyles = ["bg-blue-500", "bg-pink-500", "bg-purple-500", "bg-emerald-500", "bg-orange-500", "bg-indigo-500"];
      const avatarIndex = currentUserId.length % avatarStyles.length;
      const avatarBg = \`\${avatarStyles[avatarIndex]} text-white border-\${avatarStyles[avatarIndex].replace('bg-', '')}\`;

      try {
        await fetch("/api/leaderboard", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            userId: currentUserId,
            userName: profile.username || "Anonymous Genin",
            xp: profile.xp,
            avatarBg
          })
        });
      } catch (e) {
        console.error("Failed to post XP", e);
      }
    };
    postUserXP();
  }, [profile, user]);

  const fetchLeaderboard = async () => {
    try {
      const res = await fetch("/api/leaderboard");
      if (res.ok) {
        const data = await res.json();
        setLeaderboard(data);
      }
    } catch (e) {
      console.error("Failed to fetch leaderboard", e);
    } finally {
      setLeaderboardLoading(false);
    }
  };`;

if (!code.includes('fetchLeaderboard')) {
  code = code.replace(fetchMessagesTarget, newEffects);
}

fs.writeFileSync('src/components/WorldChat.tsx', code);
console.log("Patched WorldChat logic");
