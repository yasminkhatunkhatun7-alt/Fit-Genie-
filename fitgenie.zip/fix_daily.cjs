const fs = require('fs');
let code = fs.readFileSync('src/components/DailyChallengeDetailScreen.tsx', 'utf-8');

// 1. Update handleAddReps
code = code.replace(
  'const handleAddReps = (amount: number) => {',
  'const handleAddReps = (amount: number, fromAI: boolean = false) => {'
);
code = code.replace(
  'if (checkCheat(exercise.name, amount)) {',
  'if (!fromAI && checkCheat(exercise.name, amount)) {'
);

// 2. Add showAiCounter state and AiRepCounter import (if missing)
if (!code.includes('showAiCounter')) {
  code = code.replace(
    'const [showManualInput, setShowManualInput] = useState(false);',
    'const [showManualInput, setShowManualInput] = useState(false);\n  const [showAiCounter, setShowAiCounter] = useState(false);'
  );
}
if (!code.includes('AiRepCounter')) {
  code = code.replace(
    'import { getTodayDateString } from "../utils/dailyChallenge";',
    'import { getTodayDateString } from "../utils/dailyChallenge";\nimport { AiRepCounter } from "./AiRepCounter";\nimport { Camera } from "lucide-react";'
  );
}

// 3. Replace controls
const controlsRegex = /<div className="grid grid-cols-2 gap-3 relative">[\s\S]*?\{showManualInput && \(/;
const controlsReplacement = `<div className="grid grid-cols-1 gap-3 relative">
          {(exercise.name.toLowerCase().includes('pushup') || exercise.name.toLowerCase().includes('squat')) ? (
             <motion.button 
               whileTap={{ scale: 0.95 }}
               onClick={() => setShowAiCounter(true)}
               disabled={isCompleted || hasClaimedToday}
               className="bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-lg py-4 rounded-2xl flex justify-center items-center gap-2 shadow-[0_0_20px_rgba(20,241,225,0.4)] transition-all disabled:opacity-50"
             >
               <Camera className="w-6 h-6" />
               START AI TRACKER
             </motion.button>
           ) : (
             <div className="bg-white/5 border border-white/10 text-neutral-400 font-bold text-sm py-4 rounded-2xl flex justify-center items-center text-center px-4">
               Manual tracking is disabled. AI Tracker is only available for Pushups and Squats.
             </div>
           )}
          
          {/* FLOATING TEXTS */}
          <AnimatePresence>
            {floatingTexts.map((ft) => (
              <motion.div
                key={ft.id}
                initial={{ opacity: 1, y: 0, x: ft.x, scale: 1 }}
                animate={{ opacity: 0, y: -50, scale: 1.5 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="absolute left-1/2 top-0 pointer-events-none text-[#14F1E1] font-black text-4xl z-50 drop-shadow-[0_0_15px_rgba(20,241,225,0.8)]"
              >
                {ft.text}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {showManualInput && (`;

code = code.replace(controlsRegex, controlsReplacement);

// 4. Also remove the manual input modal
const manualModalRegex = /\{showManualInput && \([\s\S]*?<\/AnimatePresence>/;
const aiCounterModal = `
      </AnimatePresence>
      {showAiCounter && (
        <AiRepCounter
          initialExercise={exercise.name.toLowerCase().includes('squat') ? "Squats" : "Pushups"}
          onClose={() => setShowAiCounter(false)}
          onComplete={(reps) => {
            if (reps > 0) {
              handleAddReps(reps, true);
            }
            setShowAiCounter(false);
          }}
        />
      )}`;

code = code.replace(manualModalRegex, aiCounterModal);

fs.writeFileSync('src/components/DailyChallengeDetailScreen.tsx', code);
console.log('Fixed Daily');
