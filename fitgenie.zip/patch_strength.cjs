const fs = require('fs');

let code = fs.readFileSync('src/components/StrengthChallengeScreen.tsx', 'utf8');

// 1. Remove showCheatWarning state
code = code.replace(/  const \[showCheatWarning, setShowCheatWarning\] = useState\(false\);\n/g, '');

// 2. Replace handleAddReps
const oldHandle = `  const handleAddReps = (amount: number) => {
    if (isCompleted || hasClaimedToday || showCheatWarning) return;
    
    if (amount === 1 && cooldown > 0) return;
    if (amount === 10 && cooldown > 0) return;

    const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);

    // Human speed limits check: 
    // - 50 squats in 5 seconds (rate: 10 reps/sec) -> impossible
    // - 100 squats in 10 seconds (rate: 10 reps/sec) -> impossible
    // Let's set max rate roughly to 1 rep per second, maybe 2 reps per second
    const averageRate = newCompleted / (elapsedTime || 1);
    
    if (newCompleted >= 50 && elapsedTime < 25) {
      triggerCheatWarning();
      return;
    }`;

const newHandle = `  const handleAddReps = (amount: number) => {
    if (isCompleted || hasClaimedToday) return;
    
    if (amount === 1 && cooldown > 0) return;
    if (amount === 10 && cooldown > 0) return;

    if (checkCheat(exercise.name, amount)) {
      const updated = { ...challenge };
      updated.exercises[0].completedReps = 0;
      onUpdate(updated);
      return;
    }

    const newCompleted = Math.min(exercise.targetReps, exercise.completedReps + amount);`;

code = code.replace(oldHandle, newHandle);

// 3. Remove triggerCheatWarning
code = code.replace(/  const triggerCheatWarning = \(\) => {[\s\S]*?setShowCheatWarning\(true\);\n  };\n/g, '');

// 4. Fix dependencies in useEffect
code = code.replace(/, showCheatWarning/g, '');
code = code.replace(/!showCheatWarning && /g, '');

// 5. Fix the render error 
const oldRender = `  if (showCheatWarning) {
    
  if (suspiciousPhase !== 'none') {`;
const newRender = `  if (suspiciousPhase !== 'none') {`;
code = code.replace(oldRender, newRender);

fs.writeFileSync('src/components/StrengthChallengeScreen.tsx', code);
