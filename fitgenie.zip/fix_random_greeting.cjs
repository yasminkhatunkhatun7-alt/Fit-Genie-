const fs = require('fs');
let file = fs.readFileSync('src/components/GenieChat.tsx', 'utf8');

file = file.replace(
    'const [messages, setMessages] = useState<Message[]>([\n    {\n      id: "1",\n      sender: "genie",\n      text: "Hey warrior, what\'s on your mind?"\n    }\n  ]);',
    'const initialGreetings = [\n    "Hey warrior, what\'s on your mind?",\n    "Ready to train, boss?",\n    "Genie\'s listening..."\n  ];\n  const [messages, setMessages] = useState<Message[]>([\n    {\n      id: "1",\n      sender: "genie",\n      text: initialGreetings[Math.floor(Math.random() * initialGreetings.length)]\n    }\n  ]);'
);

fs.writeFileSync('src/components/GenieChat.tsx', file);
