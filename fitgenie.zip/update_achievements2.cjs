const fs = require('fs');
let code = fs.readFileSync('src/components/AchievementsScreen.tsx', 'utf8');

code = code.replace(/import \{ useAuth, getRankFromXP \} from "\.\.\/context\/AuthContext";/, 'import { useAuth, getRankDetails } from "../context/AuthContext";');
code = code.replace(/const rank = getRankFromXP\(xp\);/, 'const rank = getRankDetails(xp);');

fs.writeFileSync('src/components/AchievementsScreen.tsx', code);
