const fs = require('fs');
let lines = fs.readFileSync('src/components/SpeedChallengeScreen.tsx', 'utf8').split('\n');
let open = 0, close = 0;
for (let i = 0; i < lines.length; i++) {
  let line = lines[i];
  open += (line.match(/{/g) || []).length;
  close += (line.match(/}/g) || []).length;
  if (close > open) {
    console.log('Close exceeded open at line', i + 1);
    process.exit(1);
  }
}
console.log('Open:', open, 'Close:', close);
