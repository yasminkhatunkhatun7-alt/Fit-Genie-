const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

code = code.replace(
  'setExerciseSearchQuery(params.searchQuery);',
  'setExerciseSearchQuery(params.searchQuery);\n      } else if (newView === "profile" && params?.userId) {\n        setProfileTargetId(params.userId);\n      } else if (newView === "profile") {\n        setProfileTargetId(undefined);'
);

code = code.replace(
  '<ProfileView history={history} streakCount={streakCount} onNavigateToView={navigateToView} />',
  '<ProfileView history={history} streakCount={streakCount} onNavigateToView={navigateToView} targetUserId={profileTargetId} />'
);

fs.writeFileSync('src/App.tsx', code);
