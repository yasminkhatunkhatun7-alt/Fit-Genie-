const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const target1 = "const { triggerEvent } = useGuardianContext();";
const repl1 = `const { triggerEvent, setIsPanelOpen } = useGuardianContext();
  const [trustWarningToast, setTrustWarningToast] = useState<{ visible: boolean, score: number }>({ visible: false, score: 0 });

  useEffect(() => {
    const handleTrustWarning = (e: Event) => {
        const customEvent = e as CustomEvent;
        setTrustWarningToast({ visible: true, score: customEvent.detail?.score || 0 });
        setTimeout(() => {
            setTrustWarningToast(prev => ({ ...prev, visible: false }));
        }, 8000);
    };
    window.addEventListener('trust_warning', handleTrustWarning);
    return () => window.removeEventListener('trust_warning', handleTrustWarning);
  }, []);`;

content = content.replace(target1, repl1);

const target2 = "{/* Offline Alert Banner */}";
const repl2 = `{/* Trust Warning Toast */}
      <AnimatePresence>
        {trustWarningToast.visible && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -50, scale: 0.95 }}
            className="fixed top-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-[9999] bg-zinc-950 border border-red-500/30 rounded-2xl p-4 shadow-2xl overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-red-500/20">
              <motion.div 
                initial={{ width: "100%" }}
                animate={{ width: "0%" }}
                transition={{ duration: 8, ease: "linear" }}
                className="h-full bg-red-500"
              />
            </div>
            <div className="flex items-start gap-4">
              <div className="p-3 bg-red-500/10 rounded-xl text-red-500 shrink-0">
                <Flame className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-white font-bold text-sm mb-1 uppercase tracking-wider">Critical Trust Alert</h4>
                <p className="text-zinc-400 text-xs mb-3 leading-relaxed">
                  Your Trust Score has dropped to <span className="text-red-400 font-bold">{trustWarningToast.score}%</span>. Complete recovery missions to restore access to features.
                </p>
                <div className="flex gap-2">
                  <button 
                    onClick={() => {
                      setTrustWarningToast(prev => ({ ...prev, visible: false }));
                      setIsPanelOpen(true);
                    }}
                    className="flex-1 bg-red-500 hover:bg-red-600 text-white text-xs font-bold uppercase tracking-wider py-2 rounded-lg transition-colors cursor-pointer"
                  >
                    View Recovery Missions
                  </button>
                  <button 
                    onClick={() => setTrustWarningToast(prev => ({ ...prev, visible: false }))}
                    className="px-3 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-lg transition-colors flex items-center justify-center cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Offline Alert Banner */}`;

content = content.replace(target2, repl2);

fs.writeFileSync('src/App.tsx', content);
