const fs = require('fs');

const code = `import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, Trophy, Target, Play, AlertTriangle, Crosshair, Sword, Activity, CheckCircle2, Edit2, Trash2, Calendar, Clock, Flame, ShieldAlert } from "lucide-react";
import { playSound } from "../utils/audio";
import { useAuth } from "../context/AuthContext";
import { ActiveChallenge } from "./StrengthChallengeScreen";
import MuscleSelector from "./MuscleSelector";

interface Props {
  challenge: ActiveChallenge;
  onUpdate: (updated: ActiveChallenge) => void;
  onBack: () => void;
  onComplete: (xpToAward: number) => void;
}

const BOSS_MAP: Record<string, string> = {
  "Chest": "Iron Titan",
  "Back": "Shadow Beast",
  "Shoulders": "Deltoid Destroyer",
  "Biceps": "Peak Brawler",
  "Triceps": "Tricep Terror",
  "Forearms": "Grip Master",
  "Abs": "Core King",
  "Legs": "Leg Destroyer",
  "Quads": "Leg Destroyer",
  "Hamstrings": "Hamstring Hammer",
  "Calves": "Calf Crusher",
  "Glutes": "Glute Giant",
  "Lats": "Shadow Beast",
  "Traps": "Shadow Beast",
  "Rear Delts": "Shadow Beast",
  "Lower Back": "Core King"
};

export default function CustomChallengeDetailScreen({ challenge, onUpdate, onBack, onComplete }: Props) {
  const { profile } = useAuth();
  
  const [showCompletion, setShowCompletion] = useState(false);
  const [showHonorValidation, setShowHonorValidation] = useState(false);
  const [honorChecked, setHonorChecked] = useState(false);
  const [floatingTexts, setFloatingTexts] = useState<{ id: string, text: string, x: number }[]>([]);

  const progressKey = \`custom_challenge_progress_\${profile?.uid}_\${challenge.id}\`;
  const claimedKey = \`custom_challenge_claimed_\${profile?.uid}_\${challenge.id}\`;

  const [cooldowns1, setCooldowns1] = useState<Record<number, number>>({});
  const [cooldowns10, setCooldowns10] = useState<Record<number, number>>({});
  const [showCheatWarning, setShowCheatWarning] = useState(false);
  const [pendingAmount, setPendingAmount] = useState({ index: 0, amount: 0 });
  const [lastActionTime, setLastActionTime] = useState(0);

  useEffect(() => {
    const cdTimer = setInterval(() => {
      setCooldowns1(prev => {
        const next = { ...prev };
        let changed = false;
        for (const k in next) {
          if (next[k] > 0) {
            next[k] -= 1;
            changed = true;
          }
        }
        return changed ? next : prev;
      });
      setCooldowns10(prev => {
        const next = { ...prev };
        let changed = false;
        for (const k in next) {
          if (next[k] > 0) {
            next[k] -= 1;
            changed = true;
          }
        }
        return changed ? next : prev;
      });
    }, 1000);
    return () => clearInterval(cdTimer);
  }, []);

  const [hasClaimed, setHasClaimed] = useState(() => {
    return localStorage.getItem(claimedKey) === "true";
  });
  const [justClaimed, setJustClaimed] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(progressKey);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.exercises) {
          const updated = { ...challenge };
          let changed = false;
          updated.exercises = updated.exercises.map((ex, i) => {
            if (parsed.exercises[i] !== undefined && parsed.exercises[i].completedReps !== undefined) {
              if (ex.completedReps !== parsed.exercises[i].completedReps) changed = true;
              return { ...ex, completedReps: parsed.exercises[i].completedReps };
            }
            return ex;
          });
          if (changed) {
            onUpdate(updated);
          }
        }
      } catch (e) {
        console.error("Failed to restore progress", e);
      }
    }
  }, []);

  const totalTargetReps = challenge.exercises.reduce((sum, ex) => sum + ex.targetReps, 0);
  const totalCompletedReps = challenge.exercises.reduce((sum, ex) => sum + ex.completedReps, 0);
  const remainingReps = Math.max(0, totalTargetReps - totalCompletedReps);
  
  const progressPercent = Math.min(100, (totalCompletedReps / totalTargetReps) * 100);
  const isCompleted = progressPercent >= 100;
  
  const bossMaxHP = totalTargetReps;
  const bossCurrentHP = Math.max(0, bossMaxHP - totalCompletedReps);
  const primaryMuscle = challenge.muscles?.[0] || "Unknown";
  const bossName = BOSS_MAP[primaryMuscle] || "Unknown Titan";
  const bossDesc = \`Build your \${primaryMuscle.toLowerCase()} strength and defeat the \${bossName}.\`;

  useEffect(() => {
    if (isCompleted && !showCompletion && !showHonorValidation && !showCheatWarning && !hasClaimed) {
      const timer = setTimeout(() => setShowHonorValidation(true), 500);
      return () => clearTimeout(timer);
    }
  }, [isCompleted, showCompletion, showHonorValidation, showCheatWarning, hasClaimed]);

  const saveProgress = (exercises: any[]) => {
    localStorage.setItem(progressKey, JSON.stringify({ exercises }));
  };

  const addRepsInternal = (exerciseIndex: number, amount: number) => {
    if (amount === 1) {
      setCooldowns1(prev => ({ ...prev, [exerciseIndex]: 1 }));
    } else if (amount === 10) {
      setCooldowns10(prev => ({ ...prev, [exerciseIndex]: 10 }));
    }

    playSound("timer_tick");
    
    const id = Date.now() + "_" + Math.random();
    setFloatingTexts(prev => [...prev, { id, text: \`+\${amount}\`, x: Math.random() * 40 - 20 }]);
    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== id));
    }, 1000);

    const updated = { ...challenge };
    const ex = updated.exercises[exerciseIndex];
    ex.completedReps = Math.min(ex.targetReps, ex.completedReps + amount);
    onUpdate(updated);
    saveProgress(updated.exercises);
    setLastActionTime(Date.now());
  };

  const handleAddReps = (exerciseIndex: number, amount: number) => {
    if (isCompleted || hasClaimed || showCheatWarning) return;
    
    if (amount === 1 && (cooldowns1[exerciseIndex] || 0) > 0) return;
    if (amount === 10 && (cooldowns10[exerciseIndex] || 0) > 0) return;

    const now = Date.now();
    const timeSinceLastAction = now - lastActionTime;
    
    if (lastActionTime > 0 && timeSinceLastAction < 200 && amount > 1) {
       setPendingAmount({ index: exerciseIndex, amount });
       playSound("countdown");
       setShowCheatWarning(true);
       return;
    }

    addRepsInternal(exerciseIndex, amount);
  };

  const handleClaimXP = () => {
    if (!honorChecked) return;
    playSound("success");
    if (!hasClaimed) {
      localStorage.setItem(claimedKey, "true");
      onComplete(0); // 0 XP for custom challenges
      setHasClaimed(true);
      setJustClaimed(true);
    }
    setShowHonorValidation(false);
    setShowCompletion(true);
  };

  if (showCheatWarning) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/95 flex flex-col items-center justify-center p-6 backdrop-blur-md">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-[#050B1A] border border-red-500/50 shadow-[0_0_40px_rgba(249,115,22,0.2)] rounded-3xl p-6 text-center max-w-sm w-full relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
          <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4 relative z-10" />
          <div className="relative z-10">
            <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-4">⚠️ Suspicious Activity Detected</h2>
            <p className="text-neutral-300 text-sm leading-relaxed font-medium mb-4">
              You are adding reps faster than humanly possible.<br/><br/>
              Fit Genie rewards real effort.<br/>
              <span className="text-[#14F1E1] font-bold">Real effort = Real progress.</span>
            </p>
          </div>
          <div className="relative z-10 mt-6 grid grid-cols-1 gap-3">
            <button 
              onClick={() => { 
                playSound("click"); 
                setShowCheatWarning(false);
                addRepsInternal(pendingAmount.index, pendingAmount.amount);
              }} 
              className="py-4 w-full bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black rounded-xl text-xs uppercase tracking-widest transition-colors shadow-[0_0_20px_rgba(20,241,225,0.4)]"
            >
              I am doing them properly
            </button>
            <button 
              onClick={() => { 
                playSound("click"); 
                setShowCheatWarning(false); 
              }} 
              className="py-4 w-full bg-white/5 hover:bg-white/10 text-white font-bold rounded-xl text-xs uppercase tracking-widest border border-white/10 transition-colors"
            >
              Cancel
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  if (showHonorValidation) {
    return (
      <div className="fixed inset-0 z-50 bg-[#050B1A]/95 flex flex-col items-center justify-center p-6 backdrop-blur-md">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          className="bg-[#050B1A] border border-[#14F1E1]/30 shadow-[0_0_40px_rgba(20,241,225,0.2)] rounded-3xl p-6 text-center max-w-sm w-full relative"
        >
          <Target className="w-16 h-16 text-[#14F1E1] mx-auto mb-4" />
          <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-4">🎯 CHALLENGE COMPLETED</h2>
          
          <label className="flex items-center gap-3 p-4 bg-white/5 border border-white/10 rounded-xl cursor-pointer mb-6 text-left hover:bg-white/10 transition-colors">
            <input 
              type="checkbox" 
              checked={honorChecked}
              onChange={(e) => setHonorChecked(e.target.checked)}
              className="w-5 h-5 accent-[#14F1E1] rounded border-white/20 bg-white/10 flex-shrink-0"
            />
            <span className="text-sm font-bold text-white leading-tight">Yes, I completed this challenge honestly.</span>
          </label>

          <button 
            onClick={handleClaimXP}
            disabled={!honorChecked}
            className={\`w-full py-4 font-black text-sm uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 \${honorChecked ? 'bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] shadow-[0_0_20px_rgba(20,241,225,0.4)]' : 'bg-white/10 text-neutral-500 cursor-not-allowed'}\`}
          >
            <CheckCircle2 className="w-5 h-5" /> COMPLETE CHALLENGE
          </button>
          
          <p className="text-neutral-500 text-[10px] uppercase tracking-widest font-bold mt-6">
            Fit Genie trust system works on honesty.<br/>Real effort = Real progress.
          </p>
        </motion.div>
      </div>
    );
  }

  if (showCompletion || hasClaimed) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }} 
        animate={{ opacity: 1, scale: 1 }} 
        className="fixed inset-0 z-50 bg-[#050B1A] flex flex-col items-center justify-center p-6"
      >
        {justClaimed && Array.from({ length: 40 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ x: Math.random() * window.innerWidth, y: -20, opacity: 1, rotate: 0 }}
            animate={{ y: window.innerHeight + 20, rotate: 360, opacity: 0 }}
            transition={{ duration: 2 + Math.random() * 2, ease: "linear", repeat: Infinity }}
            className="absolute w-2 h-4 rounded-sm"
            style={{ backgroundColor: ['#14F1E1', '#B66DFF', '#F97316', '#FFFFFF'][Math.floor(Math.random() * 4)], left: \`\${Math.random() * 100}vw\` }}
          />
        ))}

        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center space-y-6 max-w-sm w-full relative z-10"
        >
          <div className="w-32 h-32 mx-auto bg-[#14F1E1]/20 rounded-full flex items-center justify-center relative">
            <div className="absolute inset-0 bg-[#14F1E1] rounded-full blur-xl opacity-40 animate-pulse" />
            <Crosshair className="w-16 h-16 text-[#14F1E1] relative z-10" />
          </div>
          
          <div>
            <h1 className="text-4xl font-black uppercase text-white tracking-tight leading-tight">🏆 MISSION COMPLETE</h1>
            <p className="text-[#14F1E1] text-lg font-bold mt-2 uppercase tracking-widest">{bossName} DEFEATED!</p>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#14F1E1]/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
            <div className="text-center space-y-4 relative z-10">
              <div className="inline-block px-4 py-1.5 bg-[#14F1E1]/20 text-[#14F1E1] rounded-full text-xs font-black uppercase tracking-widest border border-[#14F1E1]/30">
                Personal Goal Achieved
              </div>
              <div className="space-y-3 mt-4 text-left border-t border-white/10 pt-4">
                 <div className="flex items-center gap-3 bg-white/5 p-3 rounded-xl border border-white/10">
                   <Trophy className="w-5 h-5 text-yellow-400" />
                   <div>
                     <p className="text-white text-sm font-black uppercase">Completion Certificate</p>
                     <p className="text-neutral-400 text-[10px] font-bold uppercase tracking-widest">{primaryMuscle} Warrior</p>
                   </div>
                 </div>
                 <div className="flex items-center gap-3 bg-white/5 p-3 rounded-xl border border-white/10">
                   <Activity className="w-5 h-5 text-[#14F1E1]" />
                   <div>
                     <p className="text-white text-sm font-black uppercase">Consistency Badge</p>
                     <p className="text-neutral-400 text-[10px] font-bold uppercase tracking-widest">Target Reached</p>
                   </div>
                 </div>
              </div>
            </div>
          </div>

          <div className="pt-4 space-y-4">
            <button
              onClick={() => {
                playSound("click");
                onBack();
              }}
              className="w-full py-4 bg-[#14F1E1] hover:bg-[#0fd1c3] text-[#050B1A] font-black text-sm uppercase tracking-widest rounded-xl transition-all shadow-[0_0_20px_rgba(20,241,225,0.4)]"
            >
              Return To Challenges
            </button>
          </div>
        </motion.div>
      </motion.div>
    );
  }

  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 pb-24 min-h-screen relative font-sans">
      <AnimatePresence>
        {floatingTexts.map(ft => (
          <motion.div
            key={ft.id}
            initial={{ opacity: 1, y: 0, x: ft.x }}
            animate={{ opacity: 0, y: -50, x: ft.x + (Math.random() * 20 - 10) }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            className="fixed top-1/2 left-1/2 text-[#14F1E1] font-black text-4xl pointer-events-none z-50 drop-shadow-[0_0_10px_rgba(20,241,225,0.8)]"
            style={{ transform: 'translate(-50%, -50%)' }}
          >
            {ft.text}
          </motion.div>
        ))}
      </AnimatePresence>

      {/* TOP HEADER */}
      <div className="flex items-center justify-between mb-2">
        <button onClick={() => { playSound("click"); onBack(); }} className="flex items-center gap-2 text-[#14F1E1] hover:text-white transition-colors bg-white/5 px-3 py-2 rounded-xl border border-white/10">
          <ChevronLeft className="w-5 h-5" />
          <span className="font-bold uppercase tracking-widest text-xs">Back</span>
        </button>
        <div className="flex items-center gap-2">
          <button className="bg-white/5 p-2 rounded-xl border border-white/10 text-white hover:bg-white/10 transition-colors">
            <Edit2 className="w-4 h-4" />
          </button>
          <button className="bg-red-500/10 p-2 rounded-xl border border-red-500/20 text-red-400 hover:bg-red-500/20 transition-colors">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* MISSION OVERVIEW CARD */}
      <div className="bg-gradient-to-br from-[#050B1A] to-white/5 border border-white/10 rounded-2xl p-6 relative overflow-hidden shadow-[0_0_30px_rgba(0,0,0,0.5)]">
         <div className="absolute top-0 right-0 w-32 h-32 bg-[#14F1E1]/5 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
         <h2 className="text-2xl font-black text-white uppercase tracking-tight leading-tight">{challenge.title}</h2>
         
         <div className="flex flex-wrap gap-2 mt-3">
           <span className="bg-[#14F1E1]/20 text-[#14F1E1] px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest border border-[#14F1E1]/30">
             {challenge.difficulty || "Mission"}
           </span>
           <span className="bg-white/10 text-neutral-300 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest border border-white/10 flex items-center gap-1">
             <Activity className="w-3 h-3" /> Personal Goal
           </span>
         </div>
         
         <div className="grid grid-cols-2 gap-4 mt-5 pt-5 border-t border-white/10 relative z-10">
           <div className="flex flex-col gap-1">
             <div className="flex items-center gap-1 text-neutral-500 text-[10px] uppercase font-bold tracking-widest">
               <Calendar className="w-3 h-3" /> Start Date
             </div>
             <p className="text-white text-xs font-bold">{new Date(challenge.startTime).toLocaleDateString()}</p>
           </div>
           <div className="flex flex-col gap-1">
             <div className="flex items-center gap-1 text-neutral-500 text-[10px] uppercase font-bold tracking-widest">
               <Clock className="w-3 h-3" /> Deadline
             </div>
             <p className="text-white text-xs font-bold">No Time Limit</p>
           </div>
         </div>
      </div>
      
      {/* TARGET MUSCLE SECTION */}
      <div className="bg-gradient-to-b from-[#050B1A] to-white/5 border border-white/10 rounded-2xl p-6 flex flex-col items-center justify-center relative overflow-hidden shadow-[0_0_30px_rgba(20,241,225,0.05)]">
        <div className="w-full flex items-center justify-between mb-4 relative z-10">
          <h3 className="text-[#14F1E1] font-black text-xs uppercase tracking-widest flex items-center gap-2">
            <Target className="w-4 h-4" /> TARGET MUSCLE: {primaryMuscle.toUpperCase()}
          </h3>
        </div>
        
        <p className="text-neutral-300 text-sm italic text-center mb-6 relative z-10">
          "{bossDesc}"
        </p>

        <div className="w-full h-[350px] relative z-10 flex justify-center scale-110 mt-4 mb-4 drop-shadow-[0_0_15px_rgba(20,241,225,0.3)]">
          <MuscleSelector 
             selectedMuscles={challenge.muscles || []} 
             toggleMuscle={() => {}} readonly 
           />
        </div>
      </div>

      {/* BOSS BATTLE BANNER */}
      <div className="bg-gradient-to-r from-red-950/40 to-black/40 border border-red-500/30 rounded-2xl p-6 flex flex-col items-center text-center relative overflow-hidden shadow-[0_0_40px_rgba(220,38,38,0.15)]">
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/20 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-orange-500/10 rounded-full blur-3xl -ml-10 -mb-10 pointer-events-none" />
        
        <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mb-3 relative z-10 border border-red-500/40 shadow-[0_0_20px_rgba(220,38,38,0.4)]">
          <Sword className="w-8 h-8 text-red-500" />
        </div>
        
        <h2 className="text-2xl font-black uppercase tracking-tight text-white relative z-10 drop-shadow-lg flex items-center gap-2">
          BOSS: {bossName}
        </h2>
        
        <div className="w-full mt-6 relative z-10 bg-black/40 p-4 rounded-xl border border-red-500/20">
           <div className="flex justify-between items-end mb-2">
             <span className="text-red-400 text-xs font-black uppercase tracking-widest flex items-center gap-1">
               <Flame className="w-3 h-3" /> Boss HP
             </span>
             <span className="text-white font-black text-lg leading-none">{bossCurrentHP} <span className="text-neutral-500 text-xs">/ {bossMaxHP}</span></span>
           </div>
           <div className="h-4 w-full bg-[#050B1A] rounded-full overflow-hidden relative border border-white/10 shadow-inner">
             <motion.div 
               className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-red-700 via-red-500 to-orange-500"
               initial={{ width: '100%' }}
               animate={{ width: \`\${(bossCurrentHP / bossMaxHP) * 100}%\` }}
               transition={{ duration: 0.5, type: "spring" }}
             />
             <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iMTAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTAgMGwxMCAxME0xMCAwaC0xME0wIDEwaDEwIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4xKSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIi8+PC9zdmc+')] opacity-30" />
           </div>
        </div>
      </div>

      {/* TOTAL PROGRESS CARD */}
      <div className="flex items-center gap-6 bg-white/5 border border-white/10 rounded-2xl p-6 shadow-lg">
         <div className="relative w-24 h-24 flex-shrink-0">
           <svg className="w-full h-full transform -rotate-90" viewBox="0 0 160 160">
             <circle
               cx="80"
               cy="80"
               r={radius}
               stroke="currentColor"
               strokeWidth="12"
               fill="transparent"
               className="text-white/5"
             />
             <motion.circle
               cx="80"
               cy="80"
               r={radius}
               stroke="currentColor"
               strokeWidth="12"
               fill="transparent"
               strokeDasharray={circumference}
               animate={{ strokeDashoffset }}
               transition={{ duration: 1, type: "spring" }}
               className="text-[#14F1E1] drop-shadow-[0_0_12px_rgba(20,241,225,0.6)]"
               strokeLinecap="round"
             />
           </svg>
           <div className="absolute inset-0 flex items-center justify-center flex-col">
             <span className="text-[#14F1E1] font-black text-2xl leading-none">{Math.round(progressPercent)}%</span>
           </div>
         </div>
         <div className="flex-1 space-y-3">
            <div>
              <h3 className="text-white font-black uppercase tracking-widest text-sm">Total Progress</h3>
              <p className="text-[#14F1E1] text-xs font-bold uppercase tracking-widest mt-1">
                {totalCompletedReps} / {totalTargetReps} Reps
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 text-left">
               <div className="bg-black/30 rounded p-2 border border-white/5">
                 <p className="text-neutral-500 text-[9px] uppercase font-bold tracking-widest mb-1">Remaining</p>
                 <p className="text-white text-xs font-black">{remainingReps}</p>
               </div>
               <div className="bg-black/30 rounded p-2 border border-white/5">
                 <p className="text-neutral-500 text-[9px] uppercase font-bold tracking-widest mb-1">Time Left</p>
                 <p className="text-white text-xs font-black">Unlimited</p>
               </div>
            </div>
         </div>
      </div>

      {/* EXERCISES */}
      <div className="space-y-4 mt-8">
        <h3 className="text-white font-black text-sm uppercase tracking-widest border-b border-white/10 pb-3 flex items-center gap-2">
          <Activity className="w-4 h-4 text-[#14F1E1]" /> Exercise Breakdown
        </h3>
        {challenge.exercises.map((ex, index) => {
          const isDone = ex.completedReps >= ex.targetReps;
          const progress = Math.min(100, (ex.completedReps / ex.targetReps) * 100);
          
          return (
            <div key={index} className={\`bg-[#050B1A] border rounded-2xl p-5 relative overflow-hidden transition-all shadow-lg \${isDone ? 'border-[#14F1E1]/50 shadow-[0_0_20px_rgba(20,241,225,0.15)]' : 'border-white/10'}\`}>
              <div 
                className="absolute left-0 top-0 bottom-0 bg-[#14F1E1]/10 transition-all duration-700 ease-out"
                style={{ width: \`\${progress}%\` }}
              />
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center flex-shrink-0">
                      <Target className="w-5 h-5 text-[#14F1E1]" />
                    </div>
                    <div>
                      <h3 className="font-black text-white text-base uppercase tracking-tight leading-tight">{ex.name}</h3>
                      <p className="text-neutral-400 font-bold text-xs mt-1 tracking-widest uppercase">{ex.completedReps} / {ex.targetReps} Reps</p>
                    </div>
                  </div>
                  {isDone && (
                    <div className="bg-[#14F1E1]/20 border border-[#14F1E1]/40 text-[#14F1E1] text-[10px] font-black px-2 py-1 rounded uppercase tracking-widest flex items-center gap-1 shadow-[0_0_10px_rgba(20,241,225,0.3)]">
                      <CheckCircle2 className="w-3 h-3" /> Done
                    </div>
                  )}
                </div>
                
                <div className="w-full h-1.5 bg-black/50 rounded-full mb-5 overflow-hidden">
                  <motion.div 
                    className="h-full bg-[#14F1E1]"
                    initial={{ width: 0 }}
                    animate={{ width: \`\${progress}%\` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
                
                {!isDone && (
                  <div className="flex gap-3 relative">
                    <motion.button 
                      whileTap={(cooldowns1[index] || 0) > 0 ? {} : { scale: 0.95 }}
                      onClick={() => handleAddReps(index, 1)}
                      disabled={isDone || (cooldowns1[index] || 0) > 0}
                      className={\`flex-1 relative overflow-hidden text-sm font-black py-4 rounded-xl transition-all uppercase tracking-widest \${(cooldowns1[index] || 0) > 0 ? 'bg-white/5 border border-white/10 text-white/30' : 'bg-white/10 hover:bg-white/20 border border-white/20 text-white shadow-md'}\`}
                    >
                      +1 REP
                      {(cooldowns1[index] || 0) > 0 && (
                        <div className="absolute inset-0 bg-black/80 flex items-center justify-center text-xs text-white font-mono tracking-widest backdrop-blur-sm">
                          <Clock className="w-3 h-3 mr-1" /> 00:0{(cooldowns1[index] || 0)}
                        </div>
                      )}
                    </motion.button>
                    <motion.button 
                      whileTap={(cooldowns10[index] || 0) > 0 ? {} : { scale: 0.95 }}
                      onClick={() => handleAddReps(index, 10)}
                      disabled={isDone || (cooldowns10[index] || 0) > 0}
                      className={\`flex-1 relative overflow-hidden text-sm font-black py-4 rounded-xl transition-all uppercase tracking-widest \${(cooldowns10[index] || 0) > 0 ? 'bg-[#14F1E1]/5 border border-[#14F1E1]/10 text-[#14F1E1]/30' : 'bg-[#14F1E1]/15 hover:bg-[#14F1E1]/25 border border-[#14F1E1]/40 text-[#14F1E1] shadow-[0_0_15px_rgba(20,241,225,0.2)]'}\`}
                    >
                      +10 REPS
                      {(cooldowns10[index] || 0) > 0 && (
                        <div className="absolute inset-0 bg-black/80 flex items-center justify-center text-xs text-[#14F1E1] font-mono tracking-widest backdrop-blur-sm">
                          <Clock className="w-3 h-3 mr-1" /> 00:{(cooldowns10[index] || 0).toString().padStart(2, '0')}
                        </div>
                      )}
                    </motion.button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
`
fs.writeFileSync('src/components/CustomChallengeDetailScreen.tsx', code);
