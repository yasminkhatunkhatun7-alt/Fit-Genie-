const fs = require('fs');
const metadata = JSON.parse(fs.readFileSync('metadata.json', 'utf-8'));
metadata.requestFramePermissions = ["camera"];
fs.writeFileSync('metadata.json', JSON.stringify(metadata, null, 2));
