const fs = require('fs');

let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

const oldApologyHandler = `  const handleApology = (e: React.FormEvent) => {
    e.preventDefault();
    if (apology === "SORRY FIT GENIE") {
      setActiveWarning(false);
      setApology("");
      setApologyError(false);
    } else {
      setApologyError(true);
    }
  };`;

const newApologyHandler = `  const handleApology = (e: React.FormEvent) => {
    e.preventDefault();
    const normalizedInput = apology.toLowerCase().replace(/[^a-z]/g, "");
    const target = "sorrygenieabsehonestworkoutkarunga";
    if (normalizedInput === target) {
      setActiveWarning(false);
      setApology("");
      setApologyError(false);
      setEmotion("focused");
      setMessage("I am watching.");
    } else {
      setApologyError(true);
      setTimeout(() => setApologyError(false), 2000);
    }
  };`;

code = code.replace(oldApologyHandler, newApologyHandler);

// Also need to update the placeholder in the input to tell them what to type
code = code.replace(/placeholder="TYPE: SORRY FIT GENIE"/, 'placeholder="Type: Sorry Genie, ab se honest workout karunga."');
code = code.replace(/To continue, you must apologize to the Guardian./, 'To continue, type exactly: "Sorry Genie, ab se honest workout karunga."');

fs.writeFileSync('src/components/GuardianOrb.tsx', code);
