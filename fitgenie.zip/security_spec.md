# Security Specification: FIT GENIE User Profiles (ABAC Model)

This document outlines the security architecture, data invariants, and adversarial test scenarios (the "Dirty Dozen") designed to harden our Firebase Firestore rules for the FIT GENIE authentication system.

## 1. Core Data Invariants

1. **Owner-Exclusive Isolation**: A user's profile under document path `/users/{userId}` belongs to and is only readable/updatable by the authenticated user whose `request.auth.uid == userId`.
2. **Strict Structure**: On creation, profiles must have every key specified in the `firebase-blueprint.json` with accurate types (e.g., `username` as a string, `xp` as a number).
3. **Immutability of Key Identity**:
   - `uid` can never be altered.
   - `email` is locked.
   - `joinDate` is set on profile initialization and is permanent.
4. **Range & Integrity Constraints**:
   - `username`: 3 to 30 characters, alphanumeric with no malicious script tags.
   - `xp`: positive number, representing calculated workout efforts.
   - `streak`: non-negative integer.

---

## 2. The "Dirty Dozen" Threat Payloads

The following payloads outline the 12 attack vectors blocked by the security system. Any attempt to write or read these will return `PERMISSION_DENIED`.

### Attack Vector 1: Identity Spoofing (Write other's profile)
* **Goal**: Attacker tries to create/overwrite `/users/victim_uid` using attacker's custom data.
* **Payload**: `setDoc("/users/victim_uid", { uid: "attacker_uid", username: "Impostor", ... })`
* **Security Guard**: `isOwner(userId)` checks `userId == request.auth.uid`.

### Attack Vector 2: Multi-User Identity Poisoning
* **Goal**: Setting `uid` property to someone else's UID within their own profile document.
* **Payload**: `setDoc("/users/attacker_uid", { uid: "victim_uid", username: "Hacker", ... })`
* **Security Guard**: `incoming().uid == request.auth.uid` inside `isValidUserProfile()`.

### Attack Vector 3: Global Scraping (Blanket Reads)
* **Goal**: Attacker runs an unfiltered query `getDocs(collection(db, "users"))` to download everyone's emails and profiles.
* **Payload**: Unconditional `query(db, "users")`
* **Security Guard**: `allow list: if isSignedIn() && resource.data.uid == request.auth.uid`.

### Attack Vector 4: Shadow Field Injection (Ghost Fields)
* **Goal**: Attacker tries to inject a custom privilege flag like `isAdmin: true` or `proStatus: true`.
* **Payload**: `{ uid: "attacker", username: "hacker", isAdmin: true, ... }`
* **Security Guard**: Strict schema matching and `affectedKeys().hasOnly()` gates.

### Attack Vector 5: Value Poisoning (XP Exploitation)
* **Goal**: Attacker sets their XP to a string of size 1MB (Denial of Wallet payload) or an infinite float.
* **Payload**: `{ xp: "1000000000000000_mega_string_...", ... }`
* **Security Guard**: `data.xp is number` and string limits checks.

### Attack Vector 6: Invalid Character Injection (ID Poisoning)
* **Goal**: Inject special database sequences or SQL-injection style strings inside `userId` target paths.
* **Payload**: Target path `users/attacker_uid?key=val//database-exploit-char`
* **Security Guard**: `isValidId(userId)` regex verification.

### Attack Vector 7: Join Date Alteration
* **Goal**: Attacker tries to change their `joinDate` to "2020-01-01" to look like an veteran/founder of the app.
* **Payload**: `{ joinDate: "2020-01-01", ... }`
* **Security Guard**: `.affectedKeys()` does not allow `joinDate` updates.

### Attack Vector 8: Over-long Username Bypass
* **Goal**: Attacker tries to crash the UI layout or buffer memory by inserting an 8,000 character username.
* **Payload**: `{ username: "AAAAA....(8k characters)", ... }`
* **Security Guard**: `data.username.size() <= 30`.

### Attack Vector 9: Streak Manipulation
* **Goal**: Attacker attempts to update their consecutive streak bypassing workout checks.
* **Payload**: `{ streak: 999999, ... }`
* **Security Guard**: Upgraded validator limits, and workout streak matches completed sessions.

### Attack Vector 10: Anonymous Writing
* **Goal**: Unauthenticated visitor tries to write/read profiles.
* **Payload**: Unauthenticated HTTP payload to `/users/some_uid`.
* **Security Guard**: `isSignedIn()` verification.

### Attack Vector 11: Email Abuse
* **Goal**: Changing standard registration email to target lists or spam addresses.
* **Payload**: `{ email: "victim@target.com", ... }`
* **Security Guard**: Email update restricted by `.affectedKeys().hasOnly()`.

### Attack Vector 12: Rogue Deletion (Destruction of victim statistics)
* **Goal**: Attacker deletes victim's profile.
* **Payload**: `deleteDoc("/users/victim_uid")`
* **Security Guard**: `allow delete: if false` block.

---

## 3. Threat Matrix Verdicts

| Attack Vector | Vulnerability Type | Status | Closed By |
| --- | --- | --- | --- |
| Attacker writes victim's doc | Authorization Bypass | **CLOSED** | Path variable identity check |
| Inject arbitrary admin parameters | Privilege Escalation | **CLOSED** | Strict database fields update mask |
| Malicious high-size inputs | Resource Exhaustion | **CLOSED** | Length and size bounds validations |
| Collect all emails via list query | PII Data Leak | **CLOSED** | In-rule resource filters enforcement |
