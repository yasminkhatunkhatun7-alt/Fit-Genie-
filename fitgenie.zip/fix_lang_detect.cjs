const fs = require('fs');
let content = fs.readFileSync('src/components/GenieChat.tsx', 'utf8');

const newLangLogic = `const englishWords = ["how", "what", "where", "when", "why", "who", "is", "are", "am", "do", "does", "did", "can", "could", "will", "would", "the", "a", "an", "this", "that", "it", "he", "she", "they", "we", "you", "my", "your", "good", "bad", "yes", "no", "ok", "please", "thanks", "hello", "hi", "hey"];

const detectLanguage = (text: string): Language => {
  if (/[\\u0900-\\u097F]/.test(text)) {
    return "hi";
  }
  const lowerText = text.toLowerCase();
  const words = lowerText.split(/\\W+/).filter(w => w.length > 0);
  
  if (words.some(word => hinglishWords.includes(word))) {
    return "hi";
  }
  
  if (words.some(word => englishWords.includes(word))) {
    return "en";
  }
  
  return "hi"; // Default to Hinglish if unclear/mixed
};`;

content = content.replace(/const detectLanguage = [\s\S]*?return "en";\n};/, newLangLogic);
fs.writeFileSync('src/components/GenieChat.tsx', content);
