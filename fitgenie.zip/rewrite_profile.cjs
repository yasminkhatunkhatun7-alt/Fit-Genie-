const fs = require('fs');
const file = 'src/components/ProfileView.tsx';
let code = fs.readFileSync(file, 'utf8');

const targetStr = `  return (
    <div className="flex flex-col h-full bg-[#050B1A] relative">
      {/* HEADER */}
      <div className="p-4 flex items-center justify-between border-b border-brand-border/30 sticky top-0 bg-[#050B1A]/95 backdrop-blur-md z-10">`;

const replacementStr = `  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#B66DFF]/30">
      {/* HEADER */}
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">`;

const targetHeaderClose = `        </div>
        {isOwnProfile && (
          <button onClick={() => onNavigateToView?.("settings")} className="p-2 rounded-lg hover:bg-white/5 text-white">
            <Settings className="w-6 h-6" />
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto pb-24 custom-scrollbar">`;

const replacementHeaderClose = `        </div>
        {isOwnProfile && (
          <button onClick={() => onNavigateToView?.("settings")} className="p-2.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 hover:border-[#B66DFF]/30 transition-all group">
            <Settings className="w-5 h-5 text-neutral-400 group-hover:text-[#B66DFF]" />
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#B66DFF]/5 rounded-full blur-[100px] pointer-events-none" />
        <div className="max-w-4xl mx-auto space-y-8 relative z-10 pb-24">`;

if (code.indexOf(targetStr) !== -1 && code.indexOf(targetHeaderClose) !== -1) {
  code = code.replace(targetStr, replacementStr);
  code = code.replace(targetHeaderClose, replacementHeaderClose);
  fs.writeFileSync(file, code);
  console.log("Rewrote ProfileView wrapper part 1");
} else {
  console.log("Could not find exact strings.");
}
