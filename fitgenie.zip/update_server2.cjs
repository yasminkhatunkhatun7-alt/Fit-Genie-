const fs = require('fs');

let code = fs.readFileSync('server.ts', 'utf-8');

const oldRules = `Rules:
- CRITICAL: Locate the human face FIRST. Do NOT place markers on the chest, neck, torso, clothing, or background.
- If a clear face is not visible, return valid: false.
- The coordinate system is (0,0) at top-left and (100,100) at bottom-right of the image.
- Coordinates (x,y) must be accurate percentages.
- Eye 'y' coordinate MUST be smaller (higher up) than cheekbones.
- Cheekbones 'y' coordinate MUST be smaller than jawline and chin.
- Chin should be the lowest point on the face (highest 'y' value among landmarks).
- Keep results realistic.
- Never give 10/10 scores.
- Never give perfect symmetry.`;

const newRules = `Rules:
- CRITICAL: Detect the exact location of the human face in the image BEFORE placing any markers. DO NOT place markers on the neck, chest, torso, clothing, or background under any circumstances.
- If the image does not contain a clear, well-lit human face, return valid: false.
- Coordinate system: (0,0) is the top-left corner, and (100,100) is the bottom-right corner of the image. 
- x is the horizontal axis (0=left, 100=right). y is the vertical axis (0=top, 100=bottom).
- 'eyes' marker: Place exactly between the two eyes. The 'y' value MUST be smaller (higher up) than the cheekbones.
- 'cheekbones' marker: Place in the center of the cheekbone area. The 'y' value MUST be between the eyes and the jawline.
- 'jawline' marker: Place on the edge of the lower jaw.
- 'chin' marker: Place at the very bottom tip of the chin. The 'y' value MUST be the largest (lowest down) of all markers.
- Coordinates (x,y) must be accurate percentages mapping precisely to the facial features.
- Keep results realistic. Never give 10/10 scores. Never give perfect symmetry.`;

code = code.replace(oldRules, newRules);

fs.writeFileSync('server.ts', code);
console.log('done');
