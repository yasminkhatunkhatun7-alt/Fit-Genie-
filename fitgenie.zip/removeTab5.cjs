const fs = require('fs');
let yh = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');

const lines = yh.split('\n');
const start = lines.findIndex(l => l.includes('TAB 5: RECOVERY MODE ("recovery")')) - 1;
const end = lines.findIndex(l => l.includes('TAB 7: SOCIAL CHALLENGES ("challenges")')) - 1;

if (start > 0 && end > start) {
  lines.splice(start, end - start);
}

yh = lines.join('\n');
fs.writeFileSync('src/components/YoddhaHub.tsx', yh);

let hd = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');
hd = hd.replace(/\| "recovery" /g, "");
fs.writeFileSync('src/components/HomeDashboard.tsx', hd);
