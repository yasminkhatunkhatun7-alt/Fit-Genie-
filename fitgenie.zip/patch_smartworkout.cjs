const fs = require('fs');
let code = fs.readFileSync('src/components/SmartWorkoutTracker.tsx', 'utf-8');

// Add restTimerLeft state
if (!code.includes("const [restTimeLeft, setRestTimeLeft] = useState<number | null>(null);")) {
  code = code.replace(
    'const [isPaused, setIsPaused] = useState(false);',
    'const [isPaused, setIsPaused] = useState(false);\n  const [restTimeLeft, setRestTimeLeft] = useState<number | null>(null);\n\n  useEffect(() => {\n    if (restTimeLeft === null) return;\n    if (restTimeLeft <= 0) {\n      playSound("rest_chime");\n      setRestTimeLeft(null);\n      return;\n    }\n    const tid = setInterval(() => setRestTimeLeft(p => p ? p - 1 : 0), 1000);\n    return () => clearInterval(tid);\n  }, [restTimeLeft]);'
  );
}

// Modify the Pause button to trigger the rest timer
code = code.replace(
  'onClick={() => { playSound("click"); setIsPaused(!isPaused); }}',
  'onClick={() => { playSound("click"); if (!isPaused) { setRestTimeLeft(60); } else { setRestTimeLeft(null); } setIsPaused(!isPaused); }}'
);

// Modify the view inside Render Active
const timeRenderRegex = /<div className="w-full flex-1 flex flex-col items-center justify-center">\s*<div className="text-\[5rem\] font-black font-mono text-white tabular-nums tracking-tighter leading-none mb-2">\s*\{formatTime\(timeActiveMs\)\}\s*<\/div>\s*<p className="text-neutral-500 font-mono text-sm uppercase tracking-widest">Active Workout Time<\/p>\s*<\/div>/m;

const newTimeRender = `<div className="w-full flex-1 flex flex-col items-center justify-center">
        {!isPaused ? (
          <>
            <div className="text-[5rem] font-black font-mono text-white tabular-nums tracking-tighter leading-none mb-2">
              {formatTime(timeActiveMs)}
            </div>
            <p className="text-neutral-500 font-mono text-sm uppercase tracking-widest">Active Workout Time</p>
          </>
        ) : (
          <>
            <div className="text-[5rem] font-black font-mono text-brand-accent tabular-nums tracking-tighter leading-none mb-2 relative">
              {restTimeLeft !== null ? \`\${Math.floor(restTimeLeft / 60).toString().padStart(2, '0')}:\${(restTimeLeft % 60).toString().padStart(2, '0')}\` : formatTime(timeActiveMs)}
            </div>
            <p className="text-brand-accent font-mono text-sm uppercase tracking-widest">Resting Timer</p>
            {restTimeLeft !== null && (
              <div className="flex gap-4 mt-6">
                 <button onClick={() => setRestTimeLeft(p => (p || 0) + 30)} className="px-4 py-2 bg-neutral-800 text-white rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-neutral-700 active:scale-95 transition-all">+30s</button>
                 <button onClick={() => setRestTimeLeft(60)} className="px-4 py-2 bg-neutral-800 text-white rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-neutral-700 active:scale-95 transition-all">Reset</button>
              </div>
            )}
          </>
        )}
      </div>`;

if (code.match(timeRenderRegex)) {
  code = code.replace(timeRenderRegex, newTimeRender);
  fs.writeFileSync('src/components/SmartWorkoutTracker.tsx', code);
  console.log("Patched SmartWorkoutTracker");
} else {
  console.log("Could not find time render regex");
}
