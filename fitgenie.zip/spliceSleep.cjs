const fs = require('fs');

let yh = fs.readFileSync('src/components/YoddhaHub.tsx', 'utf8');
const lines = yh.split('\n');

const start = lines.findIndex(l => l.includes('TAB 4: SLEEP SYSTEM ("sleep")')) - 1;
const end = lines.findIndex(l => l.includes('TAB 7: SOCIAL CHALLENGES ("challenges")')) - 1;

if (start > 0 && end > start) {
  lines.splice(start, end - start);
}

fs.writeFileSync('src/components/YoddhaHub.tsx', lines.join('\n'));
