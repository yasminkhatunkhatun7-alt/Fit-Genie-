const fs = require('fs');
const file = 'src/components/WorkoutHistory.tsx';
let code = fs.readFileSync(file, 'utf8');

const targetStr = `  return (
    <div className="max-w-4xl mx-auto px-4 py-6 md:py-10 space-y-8" id="workout-history-page">`;

const replacementStr = `  return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#4DA8FF]/30">
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
         <div className="flex items-center gap-3">
             <div className="p-2.5 bg-white/5 border border-white/10 rounded-xl">
                 <LayoutList className="w-5 h-5 text-[#4DA8FF]" />
             </div>
             <div>
                 <h1 className="text-sm md:text-base font-black text-white uppercase tracking-widest">Workout Logs & Stats</h1>
                 <p className="text-[10px] text-neutral-500 font-bold tracking-widest uppercase mt-0.5">Performance Telemetry</p>
             </div>
         </div>
      </div>
      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative" id="workout-history-page">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#4DA8FF]/5 rounded-full blur-[100px] pointer-events-none" />
          <div className="max-w-4xl mx-auto space-y-8 relative z-10 pb-24">`;

if (code.indexOf(targetStr) === -1) {
  console.log("Could not find the target string exactly. Try using a regex.");
} else {
  code = code.replace(targetStr, replacementStr);
  
  // Now replace the last closing div.
  // The original component ends with:
  //     </div>
  //   );
  // }
  
  const endStr = `    </div>
  );
}`;
  const endReplacementStr = `          </div>
      </div>
    </div>
  );
}`;
  
  if (code.endsWith(endStr)) {
    code = code.substring(0, code.length - endStr.length) + endReplacementStr;
    fs.writeFileSync(file, code);
    console.log("Rewrote WorkoutHistory wrapper");
  } else {
    // try to find it using regex
    code = code.replace(/    <\/div>\n  \);\n}\n?$/, endReplacementStr + "\n");
    fs.writeFileSync(file, code);
    console.log("Rewrote WorkoutHistory wrapper (regex fallback)");
  }
}
