const fs = require('fs');

let appCode = fs.readFileSync('src/App.tsx', 'utf-8');
appCode = appCode.replace('achievements: 4,', 'achievements: 4,\n  world: 4.5,');
fs.writeFileSync('src/App.tsx', appCode);

let chatCode = fs.readFileSync('src/components/WorldChat.tsx', 'utf-8');
chatCode = chatCode.replace('profile?.displayName', 'profile?.username');
fs.writeFileSync('src/components/WorldChat.tsx', chatCode);

console.log("Fixed errors");
