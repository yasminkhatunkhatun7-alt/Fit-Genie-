const fs = require('fs');
let code = fs.readFileSync('src/components/AiRepCounter.tsx', 'utf-8');

const importsMatch = `import { useAuth } from "../context/AuthContext";
import { db } from "../lib/firebase";
import { collection, addDoc } from "firebase/firestore";`;
const importsNew = `import { useAuth } from "../context/AuthContext";
import { useGhostChallenge } from "../hooks/useGhostChallenge";`;

code = code.replace(importsMatch, importsNew);

const stateMatch = `  const { user, profile, updateUserProfileFields } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);`;
const stateNew = `  const { user, profile, updateUserProfileFields } = useAuth();
  const { processChallengeResult } = useGhostChallenge(profile);
  const videoRef = useRef<HTMLVideoElement>(null);`;
  
code = code.replace(stateMatch, stateNew);

const saveMatch = `      if (challengeTarget && mode === "test" && reps > challengeTarget.score) {
         try {
           // Notify beaten user
           await addDoc(collection(db, "notifications"), {
             toUserId: challengeTarget.userId,
             fromUserId: profile.uid || 'local_user',
             fromUserName: profile.username || 'Someone',
             type: "record_beaten",
             exerciseType: exercise.toLowerCase(),
             oldScore: challengeTarget.score,
             newScore: reps,
             timestamp: Date.now()
           });
           // Activity feed
           await addDoc(collection(db, "activityFeed"), {
             userId: profile.uid || 'local_user',
             userName: profile.username || 'Someone',
             userAvatar: profile.photoURL || '',
             userAvatarBg: profile.avatarBg || 'bg-blue-500',
             type: 'challenge_win',
             title: \`Beat \${challengeTarget.userName}'s \${exercise} record!\`,
             description: \`Scored \${reps} reps (vs \${challengeTarget.score}) in the 1-Min Test.\`,
             timestamp: Date.now(),
             likes: 0
           });
         } catch (e) {
           console.error("Failed to post notifications/feed", e);
         }
      }`;

const saveNew = `      if (challengeTarget && mode === "test") {
         await processChallengeResult(challengeTarget as any, reps);
      }`;
code = code.replace(saveMatch, saveNew);

fs.writeFileSync('src/components/AiRepCounter.tsx', code);
console.log("Patched AiRepCounter.tsx with new hook");
