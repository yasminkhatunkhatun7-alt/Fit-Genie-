const fs = require('fs');
let sidebar = fs.readFileSync('src/components/SidebarSections.tsx', 'utf8');

// I'll replace any generic empty state in NotificationsSection with the required one.
if (sidebar.includes('No notifications yet')) {
  sidebar = sidebar.replace(
    'No notifications yet',
    "You're all caught up! No new notifications"
  );
} else if (sidebar.includes('No notifications.')) {
  sidebar = sidebar.replace(
    'No notifications.',
    "You're all caught up! No new notifications."
  );
} else if (sidebar.includes('No new notifications')) {
  // Already has it? Wait, let's just forcefully replace the empty state block.
  // Actually, I'll just check if there's any loading state.
}

if (!sidebar.includes('className="w-8 h-8 text-brand-accent animate-spin"')) {
   sidebar = sidebar.replace(
     'loading ? (',
     'loading ? (\n        <div className="py-12 flex justify-center">\n          <Loader2 className="w-8 h-8 text-brand-accent animate-spin" />\n        </div>\n      ) : '
   )
}
fs.writeFileSync('src/components/SidebarSections.tsx', sidebar);
