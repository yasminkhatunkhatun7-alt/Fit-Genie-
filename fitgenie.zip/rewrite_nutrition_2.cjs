const fs = require('fs');
const file = 'src/components/NutritionLog.tsx';
let code = fs.readFileSync(file, 'utf8');

const returnIndex = code.indexOf('return (\n    <div className="bg-brand-surface border border-brand-border rounded-3xl p-5 md:p-6 space-y-6 relative overflow-hidden" id="nutrition-log-container">');

if (returnIndex === -1) {
  console.log("Not found.");
  process.exit(1);
}

const beforeReturn = code.substring(0, returnIndex);

const newRender = `return (
    <div className="flex flex-col h-full bg-[#050B1A] text-white font-sans selection:bg-[#14F1E1]/30">
      <div className="p-4 md:p-6 flex items-center justify-between border-b border-white/10 bg-[#050B1A]/80 backdrop-blur-xl sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-white/5 border border-white/10 rounded-xl group">
            <Apple className="w-5 h-5 text-[#14F1E1]" />
          </div>
          <div>
            <h1 className="text-sm md:text-base font-black text-white uppercase tracking-widest">Nutrition & Diet</h1>
            <p className="text-[10px] text-neutral-500 font-bold tracking-widest uppercase mt-0.5">Biometric Fuel Management</p>
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#14F1E1]/5 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-4xl mx-auto space-y-8 relative z-10 pb-24" id="nutrition-log-container">
          <ConfirmModal
            isOpen={!!confirmResetState?.isOpen}
            message="Purge active telemetry? All logged fuel for this date will be wiped."
            onCancel={() => setConfirmResetState(null)}
            onConfirm={() => {
              if (confirmResetState) {
                confirmResetCurrentDay();
                setConfirmResetState(null);
              }
            }}
          />

          {/* Goals Dashboard Card */}
          <div className="bg-gradient-to-br from-[#050B1A] to-[#0A1020] border border-[#14F1E1]/20 rounded-3xl p-6 md:p-8 shadow-[0_0_40px_rgba(20,241,225,0.05)] relative overflow-hidden">
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#14F1E1]/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="flex items-center justify-between mb-6 relative z-10">
              <h2 className="text-xl font-black uppercase tracking-tight text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-[#14F1E1]" /> Target Telemetry
              </h2>
              <button
                onClick={() => setIsEditingGoals(!isEditingGoals)}
                className="text-[10px] font-black uppercase bg-white/5 hover:bg-white/10 border border-white/10 px-4 py-2 rounded-lg text-neutral-400 hover:text-white transition-all flex items-center gap-2"
              >
                {isEditingGoals ? <X className="w-3.5 h-3.5" /> : <Settings className="w-3.5 h-3.5" />}
                {isEditingGoals ? "Close Settings" : "Configure Targets"}
              </button>
            </div>

            <AnimatePresence>
              {isEditingGoals && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden relative z-10"
                >
                  <div className="p-5 bg-black/40 border border-white/10 rounded-2xl mb-6">
                    <NutritionGoalForm goals={goals} onUpdateGoals={handleUpdateGoals} />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 relative z-10">
              <div className="bg-white/5 border border-white/10 p-5 rounded-2xl text-center shadow-inner group hover:bg-[#14F1E1]/5 hover:border-[#14F1E1]/30 transition-all">
                <div className="text-[10px] font-black uppercase text-neutral-400 tracking-widest mb-1 group-hover:text-[#14F1E1]">Protein</div>
                <div className="text-2xl font-black text-white">{goals.proteinGoal}<span className="text-xs text-neutral-500 ml-1">g</span></div>
              </div>
              <div className="bg-white/5 border border-white/10 p-5 rounded-2xl text-center shadow-inner group hover:bg-[#B66DFF]/5 hover:border-[#B66DFF]/30 transition-all">
                <div className="text-[10px] font-black uppercase text-neutral-400 tracking-widest mb-1 group-hover:text-[#B66DFF]">Water</div>
                <div className="text-2xl font-black text-white">{(goals.waterGoal / 1000).toFixed(1)}<span className="text-xs text-neutral-500 ml-1">L</span></div>
              </div>
              <div className="bg-white/5 border border-white/10 p-5 rounded-2xl text-center shadow-inner group hover:bg-amber-500/5 hover:border-amber-500/30 transition-all">
                <div className="text-[10px] font-black uppercase text-neutral-400 tracking-widest mb-1 group-hover:text-amber-500">Fat</div>
                <div className="text-2xl font-black text-white">{goals.fatGoal}<span className="text-xs text-neutral-500 ml-1">g</span></div>
              </div>
              <div className="bg-white/5 border border-white/10 p-5 rounded-2xl text-center shadow-inner group hover:bg-blue-500/5 hover:border-blue-500/30 transition-all">
                <div className="text-[10px] font-black uppercase text-neutral-400 tracking-widest mb-1 group-hover:text-blue-500">Carbs</div>
                <div className="text-2xl font-black text-white">{goals.carbsGoal}<span className="text-xs text-neutral-500 ml-1">g</span></div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* FUEL LOGGING */}
            <div className="bg-[#050B1A] border border-[#B66DFF]/20 rounded-3xl p-6 md:p-8 shadow-[0_0_40px_rgba(182,109,255,0.05)] relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#B66DFF]/10 rounded-full blur-[50px] pointer-events-none" />
              
              <div className="flex items-center justify-between mb-6 relative z-10">
                <h3 className="text-lg font-black uppercase tracking-tight text-white flex items-center gap-2">
                  <Flame className="w-5 h-5 text-[#B66DFF]" /> Fuel Logging
                </h3>
              </div>
              
              <div className="space-y-6 relative z-10">
                <div className="space-y-2">
                  <div className="flex justify-between items-end">
                    <div>
                      <span className="text-[10px] font-black uppercase text-neutral-500 tracking-[0.2em] block mb-1">Current Intake</span>
                      <div className="text-3xl font-black text-[#B66DFF] tracking-tighter">
                        {currentDateLog.protein} / {goals.proteinGoal} <span className="text-sm text-neutral-500">g</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="w-full h-3 bg-black/50 border border-white/10 rounded-full overflow-hidden relative">
                    <motion.div
                      className="h-full bg-gradient-to-r from-[#B66DFF] to-purple-400"
                      initial={{ width: 0 }}
                      animate={{ width: \`\${proteinPercent}%\` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                  
                  <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-widest text-neutral-500 pt-1">
                    <span>0%</span>
                    {currentDateLog.protein >= goals.proteinGoal ? (
                      <span className="text-[#B66DFF] animate-pulse">Optimal Levels Reached!</span>
                    ) : (
                      <span>Req: {Math.max(0, goals.proteinGoal - currentDateLog.protein)}g</span>
                    )}
                    <span>100%</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-[10px] font-black uppercase text-neutral-400 tracking-[0.2em] mb-4">Quick Deploy Macros</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {quickProteinMeals.map((meal) => (
                      <button
                        key={meal.name}
                        onClick={() => handleUpdateIntake(meal.protein, 0)}
                        className="bg-white/5 border border-white/10 hover:border-[#B66DFF]/40 hover:bg-[#B66DFF]/5 rounded-xl p-3 flex flex-col items-center justify-center text-center transition-all group active:scale-95"
                      >
                        <span className="text-lg mb-1">{meal.icon}</span>
                        <span className="text-[9px] font-bold text-neutral-300 uppercase tracking-widest group-hover:text-white mb-0.5">{meal.name}</span>
                        <span className="text-[10px] font-black text-[#B66DFF]">+{meal.protein}g</span>
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-[10px] font-black uppercase text-neutral-400 tracking-[0.2em] mb-4">Manual Input Override</h4>
                  <div className="flex gap-2 bg-black/40 border border-white/10 p-2 rounded-2xl">
                    <button onClick={() => handleUpdateIntake(-10, 0)} className="w-10 h-10 shrink-0 bg-white/5 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 border border-white/5 font-black text-sm">-10</button>
                    <input 
                      type="number" 
                      placeholder="Custom g"
                      value={customProteinInput}
                      onChange={(e) => setCustomProteinInput(e.target.value)}
                      className="flex-1 min-w-0 bg-transparent text-center text-sm font-bold text-white focus:outline-none placeholder:text-neutral-600"
                    />
                    <button 
                      onClick={() => {
                        const val = parseInt(customProteinInput);
                        if (!isNaN(val) && val > 0) {
                          handleUpdateIntake(val, 0);
                          setCustomProteinInput("");
                        }
                      }}
                      className="w-10 h-10 shrink-0 bg-[#B66DFF]/20 text-[#B66DFF] rounded-xl hover:bg-[#B66DFF] hover:text-black border border-[#B66DFF]/30 font-black text-sm transition-colors"
                    >
                      <Plus className="w-4 h-4 mx-auto" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* HYDRATION */}
            <div className="bg-[#050B1A] border border-[#14F1E1]/20 rounded-3xl p-6 md:p-8 shadow-[0_0_40px_rgba(20,241,225,0.05)] relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#14F1E1]/10 rounded-full blur-[50px] pointer-events-none" />
              
              <div className="flex items-center justify-between mb-6 relative z-10">
                <h3 className="text-lg font-black uppercase tracking-tight text-white flex items-center gap-2">
                  <Droplet className="w-5 h-5 text-[#14F1E1]" /> Hydration Metrics
                </h3>
              </div>
              
              <div className="space-y-6 relative z-10">
                <div className="space-y-2">
                  <div className="flex justify-between items-end">
                    <div>
                      <span className="text-[10px] font-black uppercase text-neutral-500 tracking-[0.2em] block mb-1">Fluid Intake</span>
                      <div className="text-3xl font-black text-[#14F1E1] tracking-tighter">
                        {(currentDateLog.water / 1000).toFixed(2)} / {(goals.waterGoal / 1000).toFixed(1)} <span className="text-sm text-neutral-500">L</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="w-full h-3 bg-black/50 border border-white/10 rounded-full overflow-hidden relative">
                    <motion.div
                      className="h-full bg-gradient-to-r from-[#14F1E1] to-cyan-400"
                      initial={{ width: 0 }}
                      animate={{ width: \`\${waterPercent}%\` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                  
                  <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-widest text-neutral-500 pt-1">
                    <span>0%</span>
                    {currentDateLog.water >= goals.waterGoal ? (
                      <span className="text-[#14F1E1] animate-pulse">Hydration Target Secure!</span>
                    ) : (
                      <span>Req: {Math.max(0, goals.waterGoal - currentDateLog.water)} ml</span>
                    )}
                    <span>100%</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-[10px] font-black uppercase text-neutral-400 tracking-[0.2em] mb-4">Quick Deploy Fluids</h4>
                  <div className="grid grid-cols-3 gap-2">
                    {quickWaterUnits.map((unit) => (
                      <button
                        key={unit.label}
                        onClick={() => handleUpdateIntake(0, unit.amount)}
                        className="bg-white/5 border border-white/10 hover:border-[#14F1E1]/40 hover:bg-[#14F1E1]/5 rounded-xl py-3 px-2 flex flex-col items-center justify-center text-center transition-all group active:scale-95"
                      >
                        <span className="text-[10px] font-bold text-neutral-300 uppercase tracking-widest group-hover:text-white mb-1 line-clamp-1 truncate w-full">{unit.label.split(" (")[0]}</span>
                        <span className="text-xs font-black text-[#14F1E1]">+{unit.amount}ml</span>
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-[10px] font-black uppercase text-neutral-400 tracking-[0.2em] mb-4">Manual Input Override</h4>
                  <div className="flex gap-2">
                    <button onClick={() => handleUpdateIntake(0, -100)} className="flex-1 py-3 bg-white/5 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 border border-white/5 font-black text-sm uppercase tracking-widest">-100 ML</button>
                    <button onClick={() => handleUpdateIntake(0, 100)} className="flex-1 py-3 bg-[#14F1E1]/10 text-[#14F1E1] border border-[#14F1E1]/30 rounded-xl hover:bg-[#14F1E1]/20 font-black text-sm uppercase tracking-widest transition-colors">+100 ML</button>
                    <button onClick={() => handleUpdateIntake(0, 250)} className="flex-1 py-3 bg-[#14F1E1]/10 text-[#14F1E1] border border-[#14F1E1]/30 rounded-xl hover:bg-[#14F1E1]/20 font-black text-sm uppercase tracking-widest transition-colors">+250 ML</button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 7-Day History Chart */}
          <div className="bg-[#050B1A] border border-white/10 rounded-3xl p-6 md:p-8 shadow-[0_0_40px_rgba(255,255,255,0.02)] relative overflow-hidden">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-sm font-black uppercase tracking-[0.2em] text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" /> Consistency Graph
              </h3>
              <button
                onClick={requestResetCurrentDay}
                className="text-[9px] font-black uppercase text-rose-500 hover:text-rose-400 transition-colors flex items-center gap-1 bg-rose-500/10 px-3 py-1.5 rounded-lg border border-rose-500/20"
              >
                <RotateCcw className="w-3 h-3" /> Purge Day
              </button>
            </div>
            
            <div className="grid grid-cols-7 gap-2 md:gap-4">
              {pastSevenDays.map((day) => {
                const isSelected = day.dateStr === selectedDate;
                const metProtein = day.protein >= goals.proteinGoal;
                const metWater = day.water >= goals.waterGoal;
                
                return (
                  <div
                    key={day.dateStr}
                    onClick={() => { playSound("click"); setSelectedDate(day.dateStr); }}
                    className={\`p-3 rounded-2xl text-center cursor-pointer transition-all border flex flex-col items-center justify-between min-h-[90px] \${
                      isSelected
                        ? "bg-[#14F1E1]/10 border-[#14F1E1]/50 shadow-[0_0_15px_rgba(20,241,225,0.15)] transform scale-105"
                        : "bg-black/40 border-white/5 hover:bg-white/5 hover:border-white/20"
                    }\`}
                  >
                    <div className={\`text-[9px] font-black uppercase tracking-widest \${isSelected ? "text-white" : "text-neutral-500"}\`}>
                      {day.label}
                    </div>
                    
                    <div className="flex gap-1.5 mt-2">
                      <div className={\`w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-black \${
                        metProtein ? "bg-[#B66DFF] text-black shadow-[0_0_10px_rgba(182,109,255,0.4)]" : day.protein > 0 ? "bg-[#B66DFF]/20 text-[#B66DFF] border border-[#B66DFF]/30" : "bg-white/5 border border-white/10 text-neutral-600"
                      }\`}>P</div>
                      <div className={\`w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-black \${
                        metWater ? "bg-[#14F1E1] text-black shadow-[0_0_10px_rgba(20,241,225,0.4)]" : day.water > 0 ? "bg-[#14F1E1]/20 text-[#14F1E1] border border-[#14F1E1]/30" : "bg-white/5 border border-white/10 text-neutral-600"
                      }\`}>W</div>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="flex items-center justify-center gap-6 mt-6 pt-4 border-t border-white/10">
              <div className="flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-neutral-400">
                <span className="w-2 h-2 rounded-full bg-[#B66DFF]" /> Fuel Validated
              </div>
              <div className="flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-neutral-400">
                <span className="w-2 h-2 rounded-full bg-[#14F1E1]" /> Hydration Validated
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}`;

const finalCode = beforeReturn + newRender + "\n}\n";
fs.writeFileSync(file, finalCode);
console.log("Rewrote NutritionLog.tsx");
