const fs = require('fs');

let code = fs.readFileSync('src/components/MoggedStation.tsx', 'utf-8');

const regex = /\{\/\* Face Confidence Ring \*\/\}[\s\S]*?\{\/\* Stacked Result Badges \*\/\}/;

const newOverlayCode = `                  {/* SVG Overlay for Landmarks and Bounding Box */}
                  {(() => {
                    const iw = imageSize?.width || 100;
                    const ih = imageSize?.height || 100;
                    const imageAspect = iw / ih;
                    const vbWidth = 1000;
                    const vbHeight = vbWidth / imageAspect;
                    
                    const lms = scanResult?.landmarks ? Object.values(scanResult.landmarks) as any[] : [];
                    const avgConfidence = lms.length > 0 ? lms.reduce((acc, curr) => acc + (curr?.confidence || 0), 0) / lms.length : 0;
                    const isHighConfidence = avgConfidence >= 80;
                    const centerX = lms.length > 0 ? lms.reduce((acc, curr) => acc + (curr?.x || 50), 0) / lms.length : 50;
                    const centerY = lms.length > 0 ? lms.reduce((acc, curr) => acc + (curr?.y || 50), 0) / lms.length : 50;
                    
                    const bbox = scanResult?.faceBoundingBox;
                    let bx = 0, by = 0, bw = 0, bh = 0;
                    if (bbox) {
                      bx = (bbox.left / 100) * vbWidth;
                      by = (bbox.top / 100) * vbHeight;
                      bw = ((bbox.right - bbox.left) / 100) * vbWidth;
                      bh = ((bbox.bottom - bbox.top) / 100) * vbHeight;
                    }

                    return (
                      <svg 
                        viewBox={\`0 0 \${vbWidth} \${vbHeight}\`}
                        preserveAspectRatio="xMidYMid slice"
                        className="absolute inset-0 w-full h-full pointer-events-none z-10"
                      >
                        {/* Face Bounding Box or Ring */}
                        {lms.length > 0 && (
                          bbox ? (
                            <motion.rect
                              x={bx}
                              y={by}
                              width={bw}
                              height={bh}
                              fill="none"
                              stroke={isHighConfidence ? "#22c55e" : "#f59e0b"}
                              strokeWidth={6}
                              strokeDasharray="20,20"
                              rx={30}
                              initial={{ opacity: 0, scale: 0.9 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ duration: 1, type: "spring" }}
                              style={{ transformOrigin: \`\${bx + bw/2}px \${by + bh/2}px\` }}
                            />
                          ) : (
                            <motion.ellipse
                              cx={(centerX / 100) * vbWidth}
                              cy={(centerY / 100) * vbHeight}
                              rx={200}
                              ry={280}
                              fill="none"
                              stroke={isHighConfidence ? "#22c55e" : "#f59e0b"}
                              strokeWidth={6}
                              strokeDasharray="20,20"
                              initial={{ opacity: 0, scale: 0.9 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ duration: 1, type: "spring" }}
                              style={{ transformOrigin: \`\${(centerX / 100) * vbWidth}px \${(centerY / 100) * vbHeight}px\` }}
                            />
                          )
                        )}

                        {/* Landmark Dots and Labels */}
                        {scanResult?.landmarks && [
                          { id: 'eyes', title: 'Hunter Eyes', score: scanResult.scores?.hunterEyes, landmark: scanResult.landmarks.eyes },
                          { id: 'cheekbones', title: 'Cheekbones', score: scanResult.scores?.cheekbones, landmark: scanResult.landmarks.cheekbones },
                          { id: 'faceFat', title: 'Face Fat', score: scanResult.scores?.faceFat, landmark: scanResult.landmarks.chin },
                          { id: 'jawline', title: 'Jawline', score: scanResult.scores?.jawline, landmark: scanResult.landmarks.jawline },
                        ].map((item, index) => {
                          if (!item.landmark) return null;
                          const isHighConf = item.landmark.confidence >= 80;
                          const lx = (item.landmark.x / 100) * vbWidth;
                          const ly = (item.landmark.y / 100) * vbHeight;

                          return (
                            <motion.g
                              key={\`dot-\${item.id}\`}
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              transition={{ delay: 0.2 * (index + 1) }}
                            >
                              <circle
                                cx={lx}
                                cy={ly}
                                r={16}
                                fill="transparent"
                                stroke={isHighConf ? "#4ade80" : "#f87171"}
                                strokeWidth={5}
                              />
                              <circle
                                cx={lx}
                                cy={ly}
                                r={6}
                                fill={isHighConf ? "#4ade80" : "#f87171"}
                              />
                              <foreignObject
                                x={lx - 250}
                                y={ly + 30}
                                width={500}
                                height={200}
                                className="overflow-visible"
                              >
                                <div className="flex flex-col items-center justify-start w-full h-full pt-4">
                                  <div className={\`inline-flex items-center gap-3 bg-black/80 backdrop-blur-sm px-6 py-3 rounded-xl text-[22px] font-black uppercase tracking-widest border shadow-lg \${isHighConf ? 'text-green-400 border-green-500/30' : 'text-red-400 border-red-500/30'}\`}>
                                    <span className="whitespace-nowrap">{item.title}</span>
                                    {item.score && <span className="bg-white/10 px-3 py-1.5 rounded-md whitespace-nowrap">{item.score}/10</span>}
                                  </div>
                                </div>
                              </foreignObject>
                            </motion.g>
                          );
                        })}
                      </svg>
                    );
                  })()}

                  {scanResult?.landmarks && (
                    <>
                      {/* Stacked Result Badges */}`;

code = code.replace(regex, newOverlayCode);
fs.writeFileSync('src/components/MoggedStation.tsx', code);
console.log('done svg');
