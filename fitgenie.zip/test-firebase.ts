import { initializeApp } from "firebase/app";
import { initializeFirestore, collection, getDocs } from "firebase/firestore";
import fs from "fs";

async function run() {
  const firebaseConfig = JSON.parse(fs.readFileSync("./firebase-applet-config.json", "utf-8"));
  const app = initializeApp(firebaseConfig);
  const db = initializeFirestore(app, {
    experimentalForceLongPolling: true,
  }, firebaseConfig.firestoreDatabaseId);

  console.log("Starting Firebase query...");
  const timer = setTimeout(() => {
    console.error("Query timed out!");
    process.exit(1);
  }, 10000);

  try {
    const querySnapshot = await getDocs(collection(db, "exercises"));
    const data: any[] = [];
    querySnapshot.forEach((doc) => {
      data.push({ id: doc.id, ...doc.data() });
    });
    clearTimeout(timer);
    fs.writeFileSync("./exercises-db.json", JSON.stringify(data, null, 2));
    console.log(`Success! Written ${data.length} exercises to exercises-db.json`);
    process.exit(0);
  } catch (err: any) {
    console.error("Failed to query:", err.message);
    process.exit(1);
  }
}

run();
