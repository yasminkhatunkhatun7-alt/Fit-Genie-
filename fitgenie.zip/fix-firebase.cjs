const fs = require('fs');
let code = fs.readFileSync('src/lib/firebase.ts', 'utf-8');
code = code.replace(
  "const app = initializeApp(firebaseConfig);",
  "import { getApps, getApp } from 'firebase/app';\nconst app = getApps().length ? getApp() : initializeApp(firebaseConfig);"
);
fs.writeFileSync('src/lib/firebase.ts', code);
