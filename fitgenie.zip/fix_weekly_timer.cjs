const fs = require('fs');

const file = 'src/components/WeeklyChallengeScreen.tsx';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/          return next;\n          \}, 1000\);/g, '          return next;\n        });\n      }, 1000);');
content = content.replace(/          return next;\n            setElapsedTime\(prev => prev \+ 1\);\n      \}, 1000\);/g, '          return next;\n        });\n        setElapsedTime(prev => prev + 1);\n      }, 1000);');
fs.writeFileSync(file, content);
