const fs = require('fs');
let content = fs.readFileSync('src/components/OneMonthChallengeScreen.tsx', 'utf8');

const regex = /<p className="text-neutral-400 text-sm mb-4">Fit Genie rewards real effort\. Validation Failed\.<\/p>/;
const replacement = `<p className="text-neutral-400 text-sm mb-4">
                {profile?.integrityScore && profile.integrityScore < 50 
                  ? "Your progress is permanently blocked due to a history of invalid submissions. Please rebuild trust through regular workouts."
                  : "Fit Genie rewards real effort. Activity validation failed."}
              </p>`;

content = content.replace(regex, replacement);
fs.writeFileSync('src/components/OneMonthChallengeScreen.tsx', content);
