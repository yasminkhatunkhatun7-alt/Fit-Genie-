const fs = require('fs');

let worldChat = fs.readFileSync('src/components/WorldChat.tsx', 'utf8');

if (!worldChat.includes("Something went wrong")) {
  worldChat = worldChat.replace(
    '<div className="flex-1 overflow-y-auto custom-scrollbar relative">',
    '<div className="flex-1 overflow-y-auto custom-scrollbar relative">\n        {error && (\n          <div className="m-4 p-4 bg-red-500/10 border border-red-500/50 rounded-xl flex flex-col items-center text-center">\n            <p className="text-sm font-bold text-red-400 mb-3">Something went wrong. Please try again.</p>\n            <button onClick={() => { setError(null); fetchMessages(); fetchLeaderboard(leaderboardType); }} className="px-4 py-2 bg-red-500/20 text-red-300 rounded-lg text-xs font-black uppercase tracking-widest hover:bg-red-500/30">Retry</button>\n          </div>\n        )}'
  );
  fs.writeFileSync('src/components/WorldChat.tsx', worldChat);
}

