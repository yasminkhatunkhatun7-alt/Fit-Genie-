const fs = require('fs');
let hd = fs.readFileSync('src/components/HomeDashboard.tsx', 'utf8');

const regex1 = /  \/\/ Sync Recovery related state for the Home Dashboard widget\n  const homeCalculatedRecoveryScore = useMemo\(\(\) => \{[\s\S]*?  \}, \[isRestDay, homeCalculatedRecoveryScore, homeRecommendedMuscle\]\);\n/g;
hd = hd.replace(regex1, "");

fs.writeFileSync('src/components/HomeDashboard.tsx', hd);
