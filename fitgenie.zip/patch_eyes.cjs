const fs = require('fs');

let code = fs.readFileSync('src/components/GuardianOrb.tsx', 'utf8');

const oldLineX = `const dx = cursorPos.x - (inPanel ? window.innerWidth / 2 : position.x + 40);`;
const oldLineY = `const dy = cursorPos.y - (inPanel ? window.innerHeight / 2 : position.y + 40);`;

const newLineX = `const dx = cursorPos.x - (inPanel ? window.innerWidth / 2 : window.innerWidth - 60);`;
const newLineY = `const dy = cursorPos.y - (inPanel ? window.innerHeight / 2 : window.innerHeight - 80);`;

code = code.replace(oldLineX, newLineX);
code = code.replace(oldLineY, newLineY);

fs.writeFileSync('src/components/GuardianOrb.tsx', code);
