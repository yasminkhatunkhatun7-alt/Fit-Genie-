const fs = require('fs');

const path = 'src/components/DailyChallengeDetailScreen.tsx';
let code = fs.readFileSync(path, 'utf-8');

code = code.replace(
  `if (suspiciousPhase === "penalty") {
    return <GeniePenaltyModal lockEndTime={lockEndTime} onApologize={submitApology} onReset={resetSessionTime} />;
  }`,
  `if (suspiciousPhase === "locked" || suspiciousPhase === "apology") {
    return <GeniePenaltyModal suspiciousPhase={suspiciousPhase} lockEndTime={lockEndTime} onSubmitApology={submitApology} />;
  }`
);

fs.writeFileSync(path, code);
console.log("Patched DailyChallengeDetailScreen.tsx modal");
