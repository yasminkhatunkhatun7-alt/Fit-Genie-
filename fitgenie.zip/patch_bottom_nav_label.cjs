const fs = require('fs');
let content = fs.readFileSync('src/components/BottomNavigation.tsx', 'utf8');
content = content.replace(/label: "Trophies",/, 'label: "Rewards",');
fs.writeFileSync('src/components/BottomNavigation.tsx', content);
